/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    /** Simple generic holder used as a fixture. */
    static class Box<T> {
        T value;

        /** Non-static inner class used to exercise owner-type parameterization. */
        class Inner<U> {
        }
    }

    /** Subclass that fixes the type parameter of {@link Box} to {@link String}. */
    static class StringBox extends Box<String> {
    }

    /** Fixture with a bounded type parameter. */
    static class Bounded<T extends Number> {
    }

    /** Fixture used to exercise self-referential ("cyclical") generics. */
    interface SelfBound<T extends SelfBound<T>> {
    }

    static class SelfBoundImpl implements SelfBound<SelfBoundImpl> {
    }

    /** A {@link Type} implementation that is none of the known subinterfaces, used to probe default/error branches. */
    static final class UnknownType implements Type {
        @Override
        public String toString() {
            return "UnknownType";
        }
    }

    // --- containsTypeVariables ---

    @Test
    void testContainsTypeVariablesTrueForTypeVariable() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(tv));
    }

    @Test
    void testContainsTypeVariablesTrueForGenericClass() {
        assertTrue(TypeUtils.containsTypeVariables(Box.class));
    }

    @Test
    void testContainsTypeVariablesFalseForNonGenericClass() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
    }

    @Test
    void testContainsTypeVariablesParameterizedTypeWithVariableArgument() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final ParameterizedType pt = TypeUtils.parameterize(Box.class, tv);
        assertTrue(TypeUtils.containsTypeVariables(pt));
    }

    @Test
    void testContainsTypeVariablesParameterizedTypeWithConcreteArgument() {
        final ParameterizedType pt = TypeUtils.parameterize(Box.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(pt));
    }

    @Test
    void testContainsTypeVariablesGenericArrayType() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final GenericArrayType gat = TypeUtils.genericArrayType(tv);
        assertTrue(TypeUtils.containsTypeVariables(gat));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testContainsTypeVariablesWildcard() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final WildcardType wild = TypeUtils.wildcardType().withUpperBounds(tv).build();
        assertTrue(TypeUtils.containsTypeVariables(wild));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.WILDCARD_ALL));
    }

    // --- determineTypeArguments ---

    @Test
    void testDetermineTypeArguments() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(ArrayList.class, superType);
        assertNotNull(result);
        final TypeVariable<?> e = ArrayList.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(e));
    }

    @Test
    void testDetermineTypeArgumentsNotAssignableReturnsNull() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        assertNull(TypeUtils.determineTypeArguments(HashMap.class, superType));
    }

    @Test
    void testDetermineTypeArgumentsNullArguments() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, superType);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(ArrayList.class, null);
            }
        });
    }

    // --- equals ---

    @Test
    void testEqualsSameInstance() {
        assertTrue(TypeUtils.equals(String.class, String.class));
    }

    @Test
    void testEqualsParameterizedTypes() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.equals(a, b));
        final ParameterizedType c = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.equals(a, c));
    }

    @Test
    void testEqualsGenericArrayTypes() {
        final GenericArrayType a = TypeUtils.genericArrayType(String.class);
        final GenericArrayType b = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(a, b));
        assertFalse(TypeUtils.equals(a, TypeUtils.genericArrayType(Integer.class)));
    }

    @Test
    void testEqualsWildcardTypes() {
        final WildcardType a = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        final WildcardType b = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertTrue(TypeUtils.equals(a, b));
        assertFalse(TypeUtils.equals(a, TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testEqualsUnrelatedTypeFalse() {
        assertFalse(TypeUtils.equals(TypeUtils.parameterize(List.class, String.class), String.class));
    }

    // --- genericArrayType ---

    @Test
    void testGenericArrayType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
        assertEquals("java.lang.String[]", TypeUtils.toString(gat));
        assertEquals(gat.toString(), TypeUtils.toString(gat));
    }

    @Test
    void testGenericArrayTypeNullComponentThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    // --- getArrayComponentType ---

    @Test
    void testGetArrayComponentTypeForArrayClass() {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
    }

    @Test
    void testGetArrayComponentTypeForGenericArrayType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(gat));
    }

    @Test
    void testGetArrayComponentTypeNonArrayReturnsNull() {
        assertNull(TypeUtils.getArrayComponentType(String.class));
        assertNull(TypeUtils.getArrayComponentType(TypeUtils.parameterize(List.class, String.class)));
    }

    // --- getImplicitBounds ---

    @Test
    void testGetImplicitBoundsUnbounded() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(tv);
        assertEquals(1, bounds.length);
        assertEquals(Object.class, bounds[0]);
    }

    @Test
    void testGetImplicitBoundsExplicit() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(tv);
        assertEquals(1, bounds.length);
        assertEquals(Number.class, bounds[0]);
    }

    @Test
    void testGetImplicitBoundsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    // --- getImplicitLowerBounds / getImplicitUpperBounds ---

    @Test
    void testGetImplicitLowerBoundsDefault() {
        final Type[] lower = TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, lower.length);
        assertNull(lower[0]);
    }

    @Test
    void testGetImplicitLowerBoundsExplicit() {
        final WildcardType wild = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        final Type[] lower = TypeUtils.getImplicitLowerBounds(wild);
        assertEquals(1, lower.length);
        assertEquals(String.class, lower[0]);
    }

    @Test
    void testGetImplicitUpperBoundsDefault() {
        final Type[] upper = TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, upper.length);
        assertEquals(Object.class, upper[0]);
    }

    @Test
    void testGetImplicitBoundsWildcardNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    // --- getRawType(Type, Type) ---

    @Test
    void testGetRawTypeClass() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    void testGetRawTypeParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(pt, null));
    }

    @Test
    void testGetRawTypeTypeVariableWithAssigningType() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final ParameterizedType assigningType = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(tv, assigningType));
    }

    @Test
    void testGetRawTypeTypeVariableWithoutAssigningTypeReturnsNull() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(tv, null));
    }

    @Test
    void testGetRawTypeGenericArrayType() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final GenericArrayType gat = TypeUtils.genericArrayType(tv);
        final ParameterizedType assigningType = TypeUtils.parameterize(Box.class, String.class);
        final Class<?> raw = TypeUtils.getRawType(gat, assigningType);
        assertNotNull(raw);
        assertTrue(raw.isArray());
        assertEquals(String.class, raw.getComponentType());
    }

    @Test
    void testGetRawTypeWildcardReturnsNull() {
        assertNull(TypeUtils.getRawType(TypeUtils.WILDCARD_ALL, null));
    }

    @Test
    void testGetRawTypeUnknownTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getRawType(new UnknownType(), null);
            }
        });
    }

    // --- getTypeArguments(ParameterizedType) ---

    @Test
    void testGetTypeArgumentsOfParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(pt);
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(e));
    }

    // --- getTypeArguments(Type, Class) ---

    @Test
    void testGetTypeArgumentsSubtype() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringBox.class, Box.class);
        assertNotNull(args);
        final TypeVariable<?> t = Box.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(t));
    }

    @Test
    void testGetTypeArgumentsNotAssignableReturnsNull() {
        assertNull(TypeUtils.getTypeArguments(String.class, List.class));
    }

    @Test
    void testGetTypeArgumentsNoTypeParametersIsEmpty() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(Integer.class, Number.class);
        assertNotNull(args);
        assertTrue(args.isEmpty());
    }

    // --- isArrayType ---

    @Test
    void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertFalse(TypeUtils.isArrayType(TypeUtils.parameterize(List.class, String.class)));
    }

    // --- isAssignable ---

    @Test
    void testIsAssignableClasses() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(String.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(String.class, String.class));
    }

    @Test
    void testIsAssignableNullType() {
        assertTrue(TypeUtils.isAssignable(null, Object.class));
        assertFalse(TypeUtils.isAssignable(null, int.class));
    }

    @Test
    void testIsAssignableParameterizedTypes() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.isAssignable(listOfString, listOfString));
        assertFalse(TypeUtils.isAssignable(listOfString, listOfInteger));
        final ParameterizedType collectionOfWildcard = TypeUtils.parameterize(Collection.class,
                TypeUtils.wildcardType().withUpperBounds(Number.class).build());
        final ParameterizedType listOfInt = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.isAssignable(listOfInt, collectionOfWildcard));
    }

    @Test
    void testIsAssignableGenericArrayTypes() {
        final GenericArrayType stringArray = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.isAssignable(String[].class, stringArray));
        assertFalse(TypeUtils.isAssignable(Integer[].class, stringArray));
    }

    @Test
    void testIsAssignableWildcardTarget() {
        final WildcardType extendsNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.isAssignable(Integer.class, extendsNumber));
        assertFalse(TypeUtils.isAssignable(String.class, extendsNumber));
    }

    @Test
    void testIsAssignableTypeVariableTarget() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        assertTrue(TypeUtils.isAssignable(tv, tv));
        assertFalse(TypeUtils.isAssignable(Integer.class, tv));
    }

    @Test
    void testIsAssignableUnknownToTypeThrows() {
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.isAssignable(String.class, new UnknownType());
            }
        });
    }

    // --- isInstance ---

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("foo", String.class));
        assertFalse(TypeUtils.isInstance(1, String.class));
        assertFalse(TypeUtils.isInstance("foo", null));
    }

    @Test
    void testIsInstanceNullValue() {
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
    }

    // --- normalizeUpperBounds ---

    @Test
    void testNormalizeUpperBoundsSingleUnchanged() {
        final Type[] bounds = { String.class };
        assertSame(bounds, TypeUtils.normalizeUpperBounds(bounds));
    }

    @Test
    void testNormalizeUpperBoundsRemovesRedundantSupertype() {
        final Type[] normalized = TypeUtils.normalizeUpperBounds(new Type[] { Collection.class, List.class });
        assertEquals(1, normalized.length);
        assertEquals(List.class, normalized[0]);
    }

    @Test
    void testNormalizeUpperBoundsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    // --- parameterize ---

    @Test
    void testParameterizeWithTypeArguments() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
        assertNull(pt.getOwnerType());
    }

    @Test
    void testParameterizeWithMap() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(e, String.class);
        final ParameterizedType pt = TypeUtils.parameterize(List.class, map);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
    }

    @Test
    void testParameterizeNullArgumentsThrow() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(null, String.class);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Map<TypeVariable<?>, Type>) null);
            }
        });
    }

    @Test
    void testParameterizeMapMissingAssignmentThrows() {
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, map);
            }
        });
    }

    @Test
    void testParameterizeWrongArgumentCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        });
    }

    @Test
    void testParameterizeNullElementThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Type) null);
            }
        });
    }

    // --- parameterizeWithOwner ---

    @Test
    void testParameterizeWithOwnerTopLevelRejectsOwner() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(String.class, List.class, String.class);
            }
        });
    }

    @Test
    void testParameterizeWithOwnerInnerClass() {
        final ParameterizedType outer = TypeUtils.parameterize(Box.class, String.class);
        final ParameterizedType inner = TypeUtils.parameterizeWithOwner(outer, Box.Inner.class, Integer.class);
        assertEquals(outer, inner.getOwnerType());
        assertEquals(Integer.class, inner.getActualTypeArguments()[0]);
    }

    // --- toLongString ---

    @Test
    void testToLongString() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final String longString = TypeUtils.toLongString(tv);
        assertTrue(longString.contains(Box.class.getSimpleName()));
        assertTrue(longString.endsWith(":T"));
    }

    @Test
    void testToLongStringNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    // --- toString(Type) ---

    @Test
    void testToStringClass() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
    }

    @Test
    void testToStringArrayClass() {
        assertEquals("java.lang.String[]", TypeUtils.toString(String[].class));
    }

    @Test
    void testToStringParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(pt));
    }

    @Test
    void testToStringWildcardAll() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testToStringWildcardExtends() {
        final WildcardType wild = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertEquals("? extends java.lang.String", TypeUtils.toString(wild));
    }

    @Test
    void testToStringCyclicalGenericClass() {
        final String s = TypeUtils.toString(SelfBound.class);
        assertTrue(s.contains("(cycle)"));
    }

    @Test
    void testToStringNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    void testToStringUnknownTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(new UnknownType());
            }
        });
    }

    // --- typesSatisfyVariables ---

    @Test
    void testTypesSatisfyVariablesTrue() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    void testTypesSatisfyVariablesFalse() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    void testTypesSatisfyVariablesNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    // --- unrollVariables ---

    @Test
    void testUnrollVariables() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, String.class);
        assertEquals(String.class, TypeUtils.unrollVariables(map, tv));
    }

    @Test
    void testUnrollVariablesNullMapTreatedAsEmpty() {
        assertEquals(String.class, TypeUtils.unrollVariables(null, String.class));
    }

    @Test
    void testUnrollVariablesParameterizedType() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        final ParameterizedType pt = TypeUtils.parameterize(List.class, e);
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(e, String.class);
        final Type unrolled = TypeUtils.unrollVariables(map, pt);
        assertTrue(unrolled instanceof ParameterizedType);
        assertEquals(String.class, ((ParameterizedType) unrolled).getActualTypeArguments()[0]);
    }

    // --- wildcardType / WILDCARD_ALL ---

    @Test
    void testWildcardAllConstant() {
        assertEquals(1, TypeUtils.WILDCARD_ALL.getUpperBounds().length);
        assertEquals(Object.class, TypeUtils.WILDCARD_ALL.getUpperBounds()[0]);
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);
    }

    @Test
    void testWildcardTypeBuilder() {
        final WildcardType wild = TypeUtils.wildcardType().withUpperBounds(Number.class).withLowerBounds(Integer.class).build();
        assertEquals(Number.class, wild.getUpperBounds()[0]);
        assertEquals(Integer.class, wild.getLowerBounds()[0]);
    }

    // --- wrap ---

    @Test
    void testWrapClass() {
        final Typed<String> typed = TypeUtils.wrap(String.class);
        assertEquals(String.class, typed.getType());
    }

    @Test
    void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> typed = TypeUtils.wrap((Type) pt);
        assertSame(pt, typed.getType());
    }

    // --- constructor ---

    @Test
    void testPublicConstructor() {
        assertNotNull(new TypeUtils());
    }
}
