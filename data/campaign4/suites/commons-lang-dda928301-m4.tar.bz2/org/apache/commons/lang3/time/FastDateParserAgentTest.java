/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date utcDate(final int year, final int month, final int day) {
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day);
        return cal.getTime();
    }

    private static Date utcDateTime(final int year, final int month, final int day, final int hour, final int minute, final int second) {
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal.getTime();
    }

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date parsed = parser.parse("2020-01-15");
        assertEquals(utcDate(2020, Calendar.JANUARY, 15), parsed);
    }

    @Test
    void testParseDateTimeWithMillis() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm:ss.SSS", UTC, Locale.US);
        final Date parsed = parser.parse("2020-06-30 23:59:58.123");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(2020, Calendar.JUNE, 30, 23, 59, 58);
        cal.set(Calendar.MILLISECOND, 123);
        assertEquals(cal.getTime(), parsed);
    }

    @Test
    void testGetters() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    void testNullLocaleDefaultsToDefault() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testNullPatternThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser p3 = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertFalse(p1.equals(null));
        assertFalse(p1.equals("not a parser"));
    }

    @Test
    void testToStringContainsFields() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("UTC"));
        final String all = parser.toStringAll();
        assertTrue(all.contains("pattern=yyyy-MM-dd"));
    }

    @Test
    void testParseInvalidThrowsParseException() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertTrue(ex.getErrorOffset() >= 0);
    }

    @Test
    void testParseMismatchedLiteralErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("2020/01/15");
            }
        });
        assertEquals(4, ex.getErrorOffset());
    }

    @Test
    void testParsePartialWithParsePosition() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date parsed = parser.parse("2020extra", pos);
        assertNotNull(parsed);
        assertEquals(4, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());
        assertEquals(utcDate(2020, Calendar.JANUARY, 1), parsed);
    }

    @Test
    void testParseFailureSetsErrorIndexAndReturnsNull() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date parsed = parser.parse("2020-01", pos);
        assertNull(parsed);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParseWithCalendarOverloadSuccess() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2020-01-15", pos, cal);
        assertTrue(ok);
        assertEquals(10, pos.getIndex());
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithCalendarOverloadFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2020#01-15", pos, cal);
        assertFalse(ok);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testParseObjectReturnsDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object obj = parser.parseObject("2020-01-15");
        assertTrue(obj instanceof Date);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15), obj);
    }

    @Test
    void testParseObjectWithParsePosition() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj = parser.parseObject("2020-01-15", pos);
        assertNotNull(obj);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testTwoDigitYearAdjustment() throws ParseException {
        final Calendar centuryCal = Calendar.getInstance(UTC, Locale.US);
        centuryCal.clear();
        centuryCal.set(1970, Calendar.JANUARY, 1);
        final Date centuryStart = centuryCal.getTime();
        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStart);

        final Calendar cal69 = Calendar.getInstance(UTC, Locale.US);
        cal69.clear();
        cal69.set(Calendar.YEAR, 2069);
        assertEquals(cal69.getTime(), parser.parse("69"));

        final Calendar cal70 = Calendar.getInstance(UTC, Locale.US);
        cal70.clear();
        cal70.set(Calendar.YEAR, 1970);
        assertEquals(cal70.getTime(), parser.parse("70"));

        final Calendar cal99 = Calendar.getInstance(UTC, Locale.US);
        cal99.clear();
        cal99.set(Calendar.YEAR, 1999);
        assertEquals(cal99.getTime(), parser.parse("99"));
    }

    @Test
    void testFourDigitYearPatternIsLiteral() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final Date parsed = parser.parse("0007");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 7);
        assertEquals(cal.getTime(), parsed);
    }

    @Test
    void testUnterminatedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy'T", UTC, Locale.US);
            }
        });
        assertEquals("Unterminated quote", ex.getMessage());
    }

    @Test
    void testUnsupportedPatternCharThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-QQ", UTC, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    void testInvalidXWidthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testEscapedQuoteLiteral() throws ParseException {
        final FastDateParser parser = new FastDateParser("''yyyy", UTC, Locale.US);
        final Date parsed = parser.parse("'2020");
        assertEquals(utcDate(2020, Calendar.JANUARY, 1), parsed);
    }

    @Test
    void testLiteralTextBetweenFields() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy'T'HH:mm:ss", UTC, Locale.US);
        final Date parsed = parser.parse("2020T10:20:30");
        assertEquals(utcDateTime(2020, Calendar.JANUARY, 1, 10, 20, 30), parsed);
    }

    @Test
    void testIso8601TimeZoneWidths() throws ParseException {
        final FastDateParser parser1 = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssX", UTC, Locale.US);
        assertNotNull(parser1.parse("2020-01-15T10:20:30Z"));
        assertNotNull(parser1.parse("2020-01-15T10:20:30+02"));

        final FastDateParser parser2 = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXX", UTC, Locale.US);
        assertNotNull(parser2.parse("2020-01-15T10:20:30+0200"));

        final FastDateParser parser3 = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXX", UTC, Locale.US);
        assertNotNull(parser3.parse("2020-01-15T10:20:30+02:00"));
    }

    @Test
    void testHourStrategyModifiers() throws ParseException {
        final FastDateParser h = new FastDateParser("HH", UTC, Locale.US);
        final Calendar cal24 = Calendar.getInstance(UTC, Locale.US);
        cal24.clear();
        h.parse("24", new ParsePosition(0), cal24);

        final FastDateParser k = new FastDateParser("kk", UTC, Locale.US);
        final Calendar calK = Calendar.getInstance(UTC, Locale.US);
        calK.clear();
        final ParsePosition posK = new ParsePosition(0);
        assertTrue(k.parse("24", posK, calK));
        assertEquals(0, calK.get(Calendar.HOUR_OF_DAY));

        final FastDateParser hh = new FastDateParser("hh", UTC, Locale.US);
        final Calendar calHh = Calendar.getInstance(UTC, Locale.US);
        calHh.clear();
        final ParsePosition posHh = new ParsePosition(0);
        assertTrue(hh.parse("12", posHh, calHh));
        assertEquals(0, calHh.get(Calendar.HOUR));
    }

    @Test
    void testDayOfWeekStrategyModifier() throws ParseException {
        final FastDateParser parser = new FastDateParser("u", UTC, Locale.US);
        final Calendar calMon = Calendar.getInstance(UTC, Locale.US);
        calMon.clear();
        assertTrue(parser.parse("1", new ParsePosition(0), calMon));
        assertEquals(Calendar.MONDAY, calMon.get(Calendar.DAY_OF_WEEK));

        final Calendar calSun = Calendar.getInstance(UTC, Locale.US);
        calSun.clear();
        assertTrue(parser.parse("7", new ParsePosition(0), calSun));
        assertEquals(Calendar.SUNDAY, calSun.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testLeadingWhitespaceStrippedForLastNumericField() throws ParseException {
        final FastDateParser parser = new FastDateParser("d", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("  5", pos, cal);
        assertTrue(ok);
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(3, pos.getIndex());
    }

    @Test
    void testOverflowingNumberFailsGracefully() {
        final FastDateParser parser = new FastDateParser("d", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date parsed = parser.parse("99999999999", pos);
        assertNull(parsed);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testMonthNameRoundTripAgainstSimpleDateFormat() throws ParseException {
        final String pattern = "MMMM d, yyyy";
        final Date date = utcDate(2020, Calendar.JULY, 4);
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);
        final String formatted = sdf.format(date);

        final FastDateParser parser = new FastDateParser(pattern, UTC, Locale.US);
        assertEquals(date, parser.parse(formatted));
    }

    @Test
    void testEraAndWeekdayRoundTripAgainstSimpleDateFormat() throws ParseException {
        final String pattern = "G EEEE yyyy-MM-dd";
        final Date date = utcDate(2020, Calendar.JULY, 4);
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);
        final String formatted = sdf.format(date);

        final FastDateParser parser = new FastDateParser(pattern, UTC, Locale.US);
        assertEquals(date, parser.parse(formatted));
    }

    @Test
    void testAmPmRoundTripAgainstSimpleDateFormat() throws ParseException {
        final String pattern = "hh:mm a";
        final Date morning = utcDateTime(2020, Calendar.JANUARY, 1, 9, 15, 0);
        final Date evening = utcDateTime(2020, Calendar.JANUARY, 1, 21, 15, 0);
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);
        final FastDateParser parser = new FastDateParser(pattern, UTC, Locale.US);

        final ParsePosition morningPos = new ParsePosition(0);
        final Calendar morningCal = Calendar.getInstance(UTC, Locale.US);
        morningCal.clear();
        morningCal.set(Calendar.YEAR, 2020);
        morningCal.set(Calendar.MONTH, Calendar.JANUARY);
        morningCal.set(Calendar.DAY_OF_MONTH, 1);
        assertTrue(parser.parse(sdf.format(morning), morningPos, morningCal));
        assertEquals(9, morningCal.get(Calendar.HOUR_OF_DAY));

        final ParsePosition eveningPos = new ParsePosition(0);
        final Calendar eveningCal = Calendar.getInstance(UTC, Locale.US);
        eveningCal.clear();
        eveningCal.set(Calendar.YEAR, 2020);
        eveningCal.set(Calendar.MONTH, Calendar.JANUARY);
        eveningCal.set(Calendar.DAY_OF_MONTH, 1);
        assertTrue(parser.parse(sdf.format(evening), eveningPos, eveningCal));
        assertEquals(21, eveningCal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTimeZoneNameRoundTripAgainstSimpleDateFormat() throws ParseException {
        final String pattern = "yyyy-MM-dd zzz";
        final Date date = utcDate(2020, Calendar.JANUARY, 15);
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(gmt);
        final String formatted = sdf.format(date);

        final FastDateParser parser = new FastDateParser(pattern, gmt, Locale.US);
        final Date parsed = parser.parse(formatted);
        assertEquals(date.getTime(), parsed.getTime());
    }

    @Test
    void testJapaneseImperialLocaleErrorMessage() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("1868-01-01"));
    }

    @Test
    void testSkipTimeZoneHelper() {
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("GMT"));
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("gmt"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("UTC"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("America/Los_Angeles"));
    }

    @Test
    void testClearDoesNotBreakSubsequentParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15), parser.parse("2020-01-15"));
        FastDateParser.clear();
        assertEquals(utcDate(2020, Calendar.JANUARY, 15), parser.parse("2020-01-15"));
    }

    @Test
    void testSerializationRoundTrip() throws IOException, ClassNotFoundException, ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, deserialized);
        assertEquals(parser.getPattern(), deserialized.getPattern());
        assertEquals(utcDate(2020, Calendar.JANUARY, 15), deserialized.parse("2020-01-15"));
    }
}
