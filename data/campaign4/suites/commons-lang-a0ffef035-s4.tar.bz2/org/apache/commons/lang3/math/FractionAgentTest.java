package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained JUnit tests for {@link Fraction}, based solely on its documented contract.
 */
public class FractionAgentTest {

    private static final double DELTA = 0.0000001d;

    // ----- constant fields -----

    @Test
    public void testConstantZero() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
    }

    @Test
    public void testConstantOne() {
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
    }

    @Test
    public void testConstantOneHalf() {
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
    }

    @Test
    public void testConstantOneThird() {
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
    }

    @Test
    public void testConstantTwoThirds() {
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
    }

    @Test
    public void testConstantOneQuarter() {
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
    }

    @Test
    public void testConstantTwoQuarters() {
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantThreeQuarters() {
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantOneFifth() {
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
    }

    @Test
    public void testConstantTwoFifths() {
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantThreeFifths() {
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantFourFifths() {
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ----- getFraction(double) -----

    @Test
    public void testGetFractionFromDoubleHalf() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(0.5d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionFromDoubleWhole() {
        final Fraction f = Fraction.getFraction(2.0d);
        assertEquals(2.0d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionFromDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-0.25d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionFromDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionFromDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(((double) Integer.MAX_VALUE) + 10.0d);
            }
        });
    }

    // ----- getFraction(int, int) -----

    @Test
    public void testGetFractionTwoArgsPositive() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsNegativeNumerator() {
        final Fraction f = Fraction.getFraction(-3, 7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsBothNegativeBecomesPositive() {
        final Fraction f = Fraction.getFraction(-3, -7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionTwoArgsMinValueNumeratorNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    public void testGetFractionTwoArgsNotReduced() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ----- getFraction(int, int, int) -----

    @Test
    public void testGetFractionThreeArgsBasic() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsZeroWhole() {
        final Fraction f = Fraction.getFraction(0, 1, 2);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsNegativeWholeCarriesSign() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, 0);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, -7);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -3, 7);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            }
        });
    }

    // ----- getFraction(String) -----

    @Test
    public void testGetFractionFromStringSimpleFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionFromStringWholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionFromStringProperForm() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionFromStringWithDot() {
        final Fraction f = Fraction.getFraction("1.5");
        assertEquals(1.5d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionFromStringNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionFromStringInvalidFormatThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("not-a-fraction");
            }
        });
    }

    // ----- getReducedFraction(int, int) -----

    @Test
    public void testGetReducedFractionSimplifies() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionNegativeSignOnNumerator() {
        final Fraction f = Fraction.getReducedFraction(-2, 4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ----- abs() -----

    @Test
    public void testAbsOnPositiveReturnsEquivalent() {
        final Fraction f = Fraction.getFraction(3, 4);
        final Fraction result = f.abs();
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testAbsOnNegativeFlipsNumeratorSignOnly() {
        final Fraction f = Fraction.getFraction(-2, 4);
        final Fraction result = f.abs();
        assertEquals(2, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testAbsOnZero() {
        final Fraction result = Fraction.ZERO.abs();
        assertEquals(0, result.getNumerator());
    }

    // ----- add(Fraction) -----

    @Test
    public void testAddSameValueReducesResult() {
        final Fraction result = Fraction.ONE_HALF.add(Fraction.ONE_HALF);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testAddProducesReducedForm() {
        final Fraction result = Fraction.ONE_THIRD.add(Fraction.ONE_THIRD);
        assertEquals(2, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testAddNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.add(Fraction.ONE);
            }
        });
    }

    // ----- compareTo(Fraction) -----

    @Test
    public void testCompareToGreater() {
        assertEquals(1, Fraction.ONE_HALF.compareTo(Fraction.ONE_THIRD));
    }

    @Test
    public void testCompareToLess() {
        assertEquals(-1, Fraction.ONE_THIRD.compareTo(Fraction.ONE_HALF));
    }

    @Test
    public void testCompareToEqualValueDifferentRepresentation() {
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareToNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.compareTo(null);
            }
        });
    }

    // ----- divideBy(Fraction) -----

    @Test
    public void testDivideByEqualValueGivesOne() {
        final Fraction result = Fraction.ONE_HALF.divideBy(Fraction.ONE_HALF);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.divideBy(null);
            }
        });
    }

    // ----- doubleValue() -----

    @Test
    public void testDoubleValue() {
        assertEquals(0.5d, Fraction.getFraction(1, 2).doubleValue(), DELTA);
        assertEquals(1.5d, Fraction.getFraction(3, 2).doubleValue(), DELTA);
    }

    // ----- equals(Object) -----

    @Test
    public void testEqualsSameValue() {
        assertTrue(Fraction.getFraction(1, 2).equals(Fraction.getFraction(1, 2)));
    }

    @Test
    public void testEqualsDifferentRepresentationNotEqual() {
        assertFalse(Fraction.getFraction(1, 2).equals(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(Fraction.getFraction(1, 2).equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        assertFalse(Fraction.getFraction(1, 2).equals("1/2"));
    }

    // ----- floatValue() -----

    @Test
    public void testFloatValue() {
        assertEquals(0.5f, Fraction.getFraction(1, 2).floatValue(), 0.0000001f);
    }

    // ----- getDenominator() / getNumerator() -----

    @Test
    public void testGetNumeratorAndDenominatorImproperFraction() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ----- getProperNumerator() -----

    @Test
    public void testGetProperNumeratorPositive() {
        assertEquals(3, Fraction.getFraction(7, 4).getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAlwaysPositiveForNegativeFraction() {
        assertEquals(3, Fraction.getFraction(-7, 4).getProperNumerator());
    }

    // ----- getProperWhole() -----

    @Test
    public void testGetProperWholePositive() {
        assertEquals(1, Fraction.getFraction(7, 4).getProperWhole());
    }

    @Test
    public void testGetProperWholeNegativeIncludesSign() {
        assertEquals(-1, Fraction.getFraction(-7, 4).getProperWhole());
    }

    @Test
    public void testGetProperWholeZeroWhenProperFraction() {
        assertEquals(0, Fraction.getFraction(3, 4).getProperWhole());
    }

    // ----- hashCode() -----

    @Test
    public void testHashCodeConsistentForEqualObjects() {
        assertEquals(Fraction.getFraction(1, 2).hashCode(), Fraction.getFraction(1, 2).hashCode());
    }

    // ----- intValue() -----

    @Test
    public void testIntValueTruncatesTowardWholePart() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    // ----- invert() -----

    @Test
    public void testInvertSwapsNumeratorAndDenominatorValue() {
        final Fraction f = Fraction.getFraction(3, 4);
        final Fraction result = f.invert();
        assertEquals(4.0d / 3.0d, result.doubleValue(), DELTA);
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    // ----- longValue() -----

    @Test
    public void testLongValue() {
        assertEquals(3L, Fraction.getFraction(10, 3).longValue());
        assertEquals(-3L, Fraction.getFraction(-10, 3).longValue());
    }

    // ----- multiplyBy(Fraction) -----

    @Test
    public void testMultiplyByReducesResult() {
        final Fraction result = Fraction.ONE_HALF.multiplyBy(Fraction.TWO_THIRDS);
        assertEquals(1, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testMultiplyByNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.multiplyBy(Fraction.getFraction(2, 1));
            }
        });
    }

    // ----- negate() -----

    @Test
    public void testNegatePositive() {
        final Fraction result = Fraction.getFraction(3, 4).negate();
        assertEquals(-3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testNegateNegative() {
        final Fraction result = Fraction.getFraction(-3, 4).negate();
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    // ----- pow(int) -----

    @Test
    public void testPowPositive() {
        final Fraction result = Fraction.ONE_HALF.pow(2);
        assertEquals(1, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPowZeroGivesOneEvenForZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.pow(1));
    }

    @Test
    public void testPowNegative() {
        final Fraction result = Fraction.ONE_HALF.pow(-1);
        assertEquals(2.0d, result.doubleValue(), DELTA);
    }

    @Test
    public void testPowOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.pow(2);
            }
        });
    }

    // ----- reduce() -----

    @Test
    public void testReduceSimplifies() {
        final Fraction result = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyInLowestTermsKeepsValue() {
        final Fraction f = Fraction.getFraction(3, 5);
        final Fraction result = f.reduce();
        assertEquals(3, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    // ----- subtract(Fraction) -----

    @Test
    public void testSubtractProducesReducedResult() {
        final Fraction result = Fraction.ONE.subtract(Fraction.ONE_THIRD);
        assertEquals(2, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.subtract(null);
            }
        });
    }

    @Test
    public void testSubtractOverflowThrows() {
        final Fraction verySmall = Fraction.getFraction(Integer.MIN_VALUE + 1, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                verySmall.subtract(Fraction.getFraction(2, 1));
            }
        });
    }

    // ----- toProperString() -----

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringNegativeImproperFraction() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperStringOmitsZeroWhole() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    @Test
    public void testToProperStringOmitsFractionPartWhenNumeratorZero() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    // ----- toString() -----

    @Test
    public void testToStringAlwaysNumeratorOverDenominator() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
        assertEquals("-3/4", Fraction.getFraction(-3, 4).toString());
        assertEquals("7/4", Fraction.getFraction(7, 4).toString());
    }

    @Test
    public void testToStringZero() {
        assertEquals("0/1", Fraction.ZERO.toString());
    }

    // ----- sanity: Number subclass / Comparable implementation -----

    @Test
    public void testIsNumberAndComparable() {
        assertNotNull(Fraction.ONE);
        assertTrue(Fraction.ONE instanceof java.lang.Number);
        assertTrue(Fraction.ONE instanceof java.lang.Comparable);
    }
}
