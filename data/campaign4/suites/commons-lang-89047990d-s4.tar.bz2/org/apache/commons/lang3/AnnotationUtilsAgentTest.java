package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.junit.jupiter.api.Test;

public class AnnotationUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    private @interface SampleAnnotation {
        String value();
        int number();
    }

    @Retention(RetentionPolicy.RUNTIME)
    private @interface OtherAnnotation {
        String value();
    }

    private enum SampleEnum {
        A, B
    }

    @SampleAnnotation(value = "x", number = 5)
    private int field1;

    @SampleAnnotation(value = "x", number = 5)
    private int field2;

    @SampleAnnotation(value = "y", number = 5)
    private int field3;

    @OtherAnnotation(value = "x")
    private int field4;

    private static Annotation getAnnotation(String fieldName, Class<? extends Annotation> type) throws Exception {
        Field f = AnnotationUtilsAgentTest.class.getDeclaredField(fieldName);
        return f.getAnnotation(type);
    }

    // --- equals ---

    @Test
    public void testEqualsBothNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    public void testEqualsFirstNull() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        assertFalse(AnnotationUtils.equals(null, a1));
    }

    @Test
    public void testEqualsSecondNull() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        assertFalse(AnnotationUtils.equals(a1, null));
    }

    @Test
    public void testEqualsSameInstance() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        assertTrue(AnnotationUtils.equals(a1, a1));
    }

    @Test
    public void testEqualsSameValues() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        Annotation a2 = getAnnotation("field2", SampleAnnotation.class);
        assertTrue(AnnotationUtils.equals(a1, a2));
        assertEquals(a1.equals(a2), AnnotationUtils.equals(a1, a2));
    }

    @Test
    public void testEqualsDifferentValues() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        Annotation a3 = getAnnotation("field3", SampleAnnotation.class);
        assertFalse(AnnotationUtils.equals(a1, a3));
        assertEquals(a1.equals(a3), AnnotationUtils.equals(a1, a3));
    }

    @Test
    public void testEqualsDifferentAnnotationTypes() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        Annotation a4 = getAnnotation("field4", OtherAnnotation.class);
        assertFalse(AnnotationUtils.equals(a1, a4));
    }

    // --- hashCode ---

    @Test
    public void testHashCodeMatchesNaturalAnnotationHashCode() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        assertEquals(a1.hashCode(), AnnotationUtils.hashCode(a1));
    }

    @Test
    public void testHashCodeEqualAnnotationsHaveEqualHashCode() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        Annotation a2 = getAnnotation("field2", SampleAnnotation.class);
        assertEquals(AnnotationUtils.hashCode(a1), AnnotationUtils.hashCode(a2));
    }

    @Test
    public void testHashCodeThrowsRuntimeExceptionOnMemberAccessFailure() {
        SampleAnnotation proxy = throwingProxy();
        assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                AnnotationUtils.hashCode(proxy);
            }
        });
    }

    @Test
    public void testHashCodeThrowsIllegalStateExceptionOnNullMemberValue() {
        final SampleAnnotation proxy = nullReturningProxy();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                AnnotationUtils.hashCode(proxy);
            }
        });
    }

    private static SampleAnnotation throwingProxy() {
        InvocationHandler handler = new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                String name = method.getName();
                if ("annotationType".equals(name)) {
                    return SampleAnnotation.class;
                }
                if ("value".equals(name) || "number".equals(name)) {
                    throw new RuntimeException("member access failure");
                }
                if ("toString".equals(name)) {
                    return "@SampleAnnotation";
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(0);
                }
                if ("equals".equals(name)) {
                    return Boolean.FALSE;
                }
                throw new UnsupportedOperationException(name);
            }
        };
        return (SampleAnnotation) Proxy.newProxyInstance(
                AnnotationUtilsAgentTest.class.getClassLoader(),
                new Class[] { SampleAnnotation.class },
                handler);
    }

    private static SampleAnnotation nullReturningProxy() {
        InvocationHandler handler = new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                String name = method.getName();
                if ("annotationType".equals(name)) {
                    return SampleAnnotation.class;
                }
                if ("value".equals(name)) {
                    return null;
                }
                if ("number".equals(name)) {
                    return Integer.valueOf(1);
                }
                if ("toString".equals(name)) {
                    return "@SampleAnnotation";
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(0);
                }
                if ("equals".equals(name)) {
                    return Boolean.FALSE;
                }
                throw new UnsupportedOperationException(name);
            }
        };
        return (SampleAnnotation) Proxy.newProxyInstance(
                AnnotationUtilsAgentTest.class.getClassLoader(),
                new Class[] { SampleAnnotation.class },
                handler);
    }

    // --- isValidAnnotationMemberType ---

    @Test
    public void testIsValidAnnotationMemberTypeString() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeClass() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypePrimitive() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(boolean.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(double.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleAnnotation.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeEnum() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleEnum.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeSingleDimensionalArrays() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleEnum[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleAnnotation[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeRejectsNonPermittedType() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Integer.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeRejectsMultiDimensionalArray() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(String[][].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeRejectsArrayOfInvalidType() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeNull() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    // --- toString ---

    @Test
    public void testToStringNotNull() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        assertNotNull(AnnotationUtils.toString(a1));
    }

    @Test
    public void testToStringMatchesNaturalAnnotationToString() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        assertEquals(a1.toString(), AnnotationUtils.toString(a1));
    }

    @Test
    public void testToStringContainsMemberNamesAndValues() throws Exception {
        Annotation a1 = getAnnotation("field1", SampleAnnotation.class);
        String result = AnnotationUtils.toString(a1);
        assertTrue(result.startsWith("@"));
        assertTrue(result.contains("value=x"));
        assertTrue(result.contains("number=5"));
    }

    // --- deprecated public constructor ---

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructorDoesNotThrow() {
        assertNotNull(new AnnotationUtils());
    }
}
