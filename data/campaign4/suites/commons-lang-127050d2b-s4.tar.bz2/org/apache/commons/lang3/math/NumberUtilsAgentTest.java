package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0d);
        assertEquals(1d, NumberUtils.DOUBLE_ONE.doubleValue(), 0d);
        assertEquals(-1d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0d);
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0f, NumberUtils.FLOAT_ZERO.floatValue(), 0f);
        assertEquals(1f, NumberUtils.FLOAT_ONE.floatValue(), 0f);
        assertEquals(-1f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0f);
    }

    // ---------------------------------------------------------------
    // compare
    // ---------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 5) < 0);
        assertTrue(NumberUtils.compare((byte) 5, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 5) < 0);
        assertTrue(NumberUtils.compare(5, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 5L) < 0);
        assertTrue(NumberUtils.compare(5L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 5) < 0);
        assertTrue(NumberUtils.compare((short) 5, (short) 1) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal / createBigInteger / createDouble / createFloat /
    // createInteger / createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("123.45"), NumberUtils.createBigDecimal("123.45"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    @Test
    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("not a number");
            }
        });
    }

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    @Test
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    @Test
    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongQualifier() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatQualifier() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0f);
    }

    @Test
    public void testCreateNumberDoubleQualifier() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0d);
    }

    @Test
    public void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0x1A");
        assertTrue(n instanceof Integer);
        assertEquals(26, n.intValue());
    }

    @Test
    public void testCreateNumberOctal() {
        final Number n = NumberUtils.createNumber("010");
        assertTrue(n instanceof Integer);
        assertEquals(8, n.intValue());
    }

    @Test
    public void testCreateNumberDecimalWithoutQualifier() {
        final Number n = NumberUtils.createNumber("1.5");
        assertEquals(1.5d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberRejectsLeadingOrTrailingSpace() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber(" 1");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1 ");
            }
        });
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // isCreatable / isNumber (deprecated alias) / isDigits / isParsable
    // ---------------------------------------------------------------

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertTrue(NumberUtils.isCreatable("0.09"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("123L"));
        assertTrue(NumberUtils.isCreatable("1.2e-5"));
        assertTrue(NumberUtils.isCreatable("123"));
    }

    @Test
    public void testIsNumberDeprecatedAlias() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertFalse(NumberUtils.isNumber("09"));
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertTrue(NumberUtils.isNumber("123"));
    }

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("12a"));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("08"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable(" 1"));
    }

    // ---------------------------------------------------------------
    // max / min - varargs
    // ---------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5f, NumberUtils.max(1f, 5f, 3f), 0f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1f, NumberUtils.min(1f, 5f, 3f), 0f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5d, NumberUtils.max(1d, 5d, 3d), 0d);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1d, NumberUtils.min(1d, 5d, 3d), 0d);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // max / min - three-value overloads
    // ---------------------------------------------------------------

    @Test
    public void testMaxMinThreeByte() {
        assertEquals((byte) 9, NumberUtils.max((byte) 9, (byte) 2, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 9, (byte) 2, (byte) 5));
    }

    @Test
    public void testMaxMinThreeShort() {
        assertEquals((short) 9, NumberUtils.max((short) 9, (short) 2, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 2, (short) 5));
    }

    @Test
    public void testMaxMinThreeInt() {
        assertEquals(9, NumberUtils.max(9, 2, 5));
        assertEquals(2, NumberUtils.min(9, 2, 5));
    }

    @Test
    public void testMaxMinThreeLong() {
        assertEquals(9L, NumberUtils.max(9L, 2L, 5L));
        assertEquals(2L, NumberUtils.min(9L, 2L, 5L));
    }

    @Test
    public void testMaxMinThreeFloatRegular() {
        assertEquals(9f, NumberUtils.max(9f, 2f, 5f), 0f);
        assertEquals(2f, NumberUtils.min(9f, 2f, 5f), 0f);
    }

    @Test
    public void testMaxMinThreeFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1f, Float.NaN, 2f)));
        assertTrue(Float.isNaN(NumberUtils.min(1f, Float.NaN, 2f)));
    }

    @Test
    public void testMaxMinThreeDoubleRegular() {
        assertEquals(9d, NumberUtils.max(9d, 2d, 5d), 0d);
        assertEquals(2d, NumberUtils.min(9d, 2d, 5d), 0d);
    }

    @Test
    public void testMaxMinThreeDoubleNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1d, Double.NaN, 2d)));
        assertTrue(Double.isNaN(NumberUtils.min(1d, Double.NaN, 2d)));
    }

    // ---------------------------------------------------------------
    // toByte / toShort / toInt / toLong / toFloat / toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
    }

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a short", (short) 9));
    }

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not an int", 9));
    }

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a long", 9L));
    }

    @Test
    public void testToFloat() {
        assertEquals(0f, NumberUtils.toFloat(null), 0f);
        assertEquals(0f, NumberUtils.toFloat(""), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0f);
        assertEquals(9f, NumberUtils.toFloat("not a float", 9f), 0f);
    }

    @Test
    public void testToDoubleString() {
        assertEquals(0d, NumberUtils.toDouble((String) null), 0d);
        assertEquals(0d, NumberUtils.toDouble(""), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0d);
        assertEquals(9d, NumberUtils.toDouble("not a double", 9d), 0d);
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0d, NumberUtils.toDouble((BigDecimal) null), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0d);
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.345"));
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.34"), result);
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO,
                NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP);
        assertEquals(3, result.scale());
        assertEquals(new BigDecimal("1.235"), result);
    }

    @Test
    public void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.345d));
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.34"), result);
    }

    @Test
    public void testToScaledBigDecimalDoubleWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO,
                NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.HALF_UP));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(1.2345d), 3, RoundingMode.HALF_UP);
        assertEquals(3, result.scale());
        assertEquals(new BigDecimal("1.235"), result);
    }

    @Test
    public void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f));
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.50"), result);
    }

    @Test
    public void testToScaledBigDecimalFloatWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO,
                NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.HALF_UP));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.25f), 3, RoundingMode.HALF_UP);
        assertEquals(3, result.scale());
        assertEquals(new BigDecimal("1.250"), result);
    }

    @Test
    public void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal("2.345");
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.34"), result);
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO,
                NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.HALF_UP));
        final BigDecimal result = NumberUtils.toScaledBigDecimal("1.2345", 3, RoundingMode.HALF_UP);
        assertEquals(3, result.scale());
        assertEquals(new BigDecimal("1.235"), result);
    }
}
