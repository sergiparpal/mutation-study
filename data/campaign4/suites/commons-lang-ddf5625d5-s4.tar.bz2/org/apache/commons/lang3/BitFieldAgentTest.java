package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link BitField}, based solely on the documented contract in the javadoc.
 */
public class BitFieldAgentTest {

    // ----- The worked "paint instruction" example from the class javadoc (int mask) -----

    @Test
    public void testPaintInstructionExampleFromJavadoc() {
        BitField blue = new BitField(0xFF);
        BitField green = new BitField(0xFF00);
        BitField red = new BitField(0xFF0000);
        BitField anyColor = new BitField(0xFFFFFF);
        BitField isMetallic = new BitField(0x1000000);

        int paintInstruction = 0;
        paintInstruction = red.setValue(paintInstruction, 35);
        paintInstruction = green.setValue(paintInstruction, 100);
        paintInstruction = blue.setValue(paintInstruction, 255);

        assertTrue(anyColor.isSet(paintInstruction));
        assertEquals(35, red.getValue(paintInstruction));
        assertEquals(100, green.getValue(paintInstruction));
        assertEquals(255, blue.getValue(paintInstruction));
        assertFalse(isMetallic.isSet(paintInstruction));

        // blue's field occupies all 8 bits of its mask and was set to 255 (all ones),
        // so isAllSet must hold for it, unlike red/green which are not all ones.
        assertTrue(blue.isAllSet(paintInstruction));
        assertFalse(red.isAllSet(paintInstruction));
        assertFalse(green.isAllSet(paintInstruction));
    }

    // ----- getRawValue / getValue relationship (int) -----

    @Test
    public void testGetRawValueIsUnshiftedSelectedBits() {
        BitField field = new BitField(0xFF0000);
        int holder = 0x00ABCDEF;

        assertEquals(holder & 0xFF0000, field.getRawValue(holder));
        assertEquals(0xAB, field.getValue(holder));
    }

    @Test
    public void testGetRawValueLong() {
        BitField field = new BitField(0xFF00000000L);
        long holder = 0x1234000000L;

        assertEquals(0x1200000000L, field.getRawValue(holder));
        assertEquals(0x12L, field.getValue(holder));
    }

    // ----- clear -----

    @Test
    public void testClearOnlyAffectsMaskedBitsInt() {
        BitField field = new BitField(0x0F00);
        int holder = 0xFFFF;

        int cleared = field.clear(holder);
        assertEquals(0xF0FF, cleared);
        assertEquals(0, cleared & 0x0F00);
    }

    @Test
    public void testClearOnlyAffectsMaskedBitsLong() {
        BitField field = new BitField(0xFF00000000L);
        long holder = 0xFFFFFFFFFFL;

        long cleared = field.clear(holder);
        assertEquals(0xFFFFFFFFL, cleared);
    }

    @Test
    public void testClearByte() {
        BitField field = new BitField(0x0F);
        byte holder = (byte) 0xFF;

        assertEquals((byte) 0xF0, field.clearByte(holder));
    }

    @Test
    public void testClearShort() {
        BitField field = new BitField(0xFF00);
        short holder = (short) 0x1234;

        assertEquals((short) 0x0034, field.clearShort(holder));
    }

    // ----- set -----

    @Test
    public void testSetOnlyAffectsMaskedBitsInt() {
        BitField field = new BitField(0x0F00);
        int holder = 0;

        int result = field.set(holder);
        assertEquals(0x0F00, result);
    }

    @Test
    public void testSetOnlyAffectsMaskedBitsLong() {
        BitField field = new BitField(0xFF00000000L);
        long holder = 0L;

        long result = field.set(holder);
        assertEquals(0xFF00000000L, result);
    }

    @Test
    public void testSetByte() {
        BitField field = new BitField(0x0F);
        byte holder = 0;

        assertEquals((byte) 0x0F, field.setByte(holder));
    }

    @Test
    public void testSetShort() {
        BitField field = new BitField(0xFF00);
        short holder = 0x0034;

        assertEquals((short) 0xFF34, field.setShort(holder));
    }

    // ----- isSet / isAllSet -----

    @Test
    public void testIsSetDetectsAnyBitOfMultiBitFieldInt() {
        BitField field = new BitField(0x0F00);

        assertFalse(field.isSet(0));
        assertTrue(field.isSet(0x0100));
        assertTrue(field.isSet(0x0F00));
    }

    @Test
    public void testIsAllSetRequiresEveryBitInt() {
        BitField field = new BitField(0x0F00);

        assertFalse(field.isAllSet(0x0100));
        assertFalse(field.isAllSet(0x0E00));
        assertTrue(field.isAllSet(0x0F00));
        assertTrue(field.isAllSet(0xFFFF));
    }

    @Test
    public void testIsSetAndIsAllSetLong() {
        BitField field = new BitField(0xFF00000000L);

        assertFalse(field.isSet(0L));
        assertTrue(field.isSet(0x0100000000L));
        assertFalse(field.isAllSet(0x0100000000L));
        assertTrue(field.isAllSet(0xFF00000000L));
    }

    // ----- setBoolean / setByteBoolean / setShortBoolean -----

    @Test
    public void testSetBooleanMatchesSetAndClearInt() {
        BitField field = new BitField(0x0F00);
        int holder = 0x1234;

        assertEquals(field.set(holder), field.setBoolean(holder, true));
        assertEquals(field.clear(holder), field.setBoolean(holder, false));
    }

    @Test
    public void testSetBooleanMatchesSetAndClearLong() {
        BitField field = new BitField(0xFF00000000L);
        long holder = 0x123456789AL;

        assertEquals(field.set(holder), field.setBoolean(holder, true));
        assertEquals(field.clear(holder), field.setBoolean(holder, false));
    }

    @Test
    public void testSetByteBooleanMatchesSetByteAndClearByte() {
        BitField field = new BitField(0x0F);
        byte holder = (byte) 0xA5;

        assertEquals(field.setByte(holder), field.setByteBoolean(holder, true));
        assertEquals(field.clearByte(holder), field.setByteBoolean(holder, false));
    }

    @Test
    public void testSetShortBooleanMatchesSetShortAndClearShort() {
        BitField field = new BitField(0xFF00);
        short holder = (short) 0x1234;

        assertEquals(field.setShort(holder), field.setShortBoolean(holder, true));
        assertEquals(field.clearShort(holder), field.setShortBoolean(holder, false));
    }

    // ----- getShortValue / setShortValue (documented as a matching pair via @see) -----

    @Test
    public void testSetShortValueThenGetShortValueRoundTrips() {
        BitField field = new BitField(0xFF00);
        short holder = (short) 0x1234;

        short updated = field.setShortValue(holder, (short) 0x9A);
        assertEquals((short) 0x9A34, updated);
        assertEquals((short) 0x9A, field.getShortValue(updated));
        // bits outside the mask must be left untouched
        assertEquals((short) 0x0034, (short) (updated & 0x00FF));
    }

    @Test
    public void testGetShortRawValueIsUnshifted() {
        BitField field = new BitField(0xFF00);
        short holder = (short) 0x1234;

        assertEquals((short) 0x1200, field.getShortRawValue(holder));
        assertEquals((short) 0x12, field.getShortValue(holder));
    }

    // ----- setValue / getValue (documented as a matching pair via @see) -----

    @Test
    public void testSetValueThenGetValueRoundTripsInt() {
        BitField field = new BitField(0xFF0000);
        int holder = 0x00ABCDEF;

        int updated = field.setValue(holder, 0x42);
        assertEquals(0x0042CDEF, updated);
        assertEquals(0x42, field.getValue(updated));
    }

    @Test
    public void testSetValueThenGetValueRoundTripsLong() {
        BitField field = new BitField(0xFF00000000L);
        long holder = 0x1122334455L;

        long updated = field.setValue(holder, 0x42L);
        assertEquals(0x4222334455L, updated);
        assertEquals(0x42L, field.getValue(updated));
    }

    @Test
    public void testSetValueConfinesValueToMaskWidthInt() {
        // The mask defines exactly which bits this BitField operates on, so a value
        // wider than the field must have its extra high bits dropped.
        BitField field = new BitField(0xFF0000);

        int updated = field.setValue(0, 0x135);
        assertEquals(0x135 & 0xFF, field.getValue(updated));
    }

    @Test
    public void testSetValueConfinesValueToMaskWidthLong() {
        BitField field = new BitField(0xFF00000000L);

        long updated = field.setValue(0L, 0x1AAL);
        assertEquals(0x1AAL & 0xFFL, field.getValue(updated));
    }

    // ----- Boundary: zero mask -----

    @Test
    public void testZeroMaskInt() {
        BitField field = new BitField(0);
        int holder = 0x12345678;

        assertEquals(holder, field.clear(holder));
        assertEquals(holder, field.set(holder));
        assertFalse(field.isSet(holder));
        assertTrue(field.isAllSet(holder));
        assertEquals(0, field.getRawValue(holder));
        assertEquals(0, field.getValue(holder));
    }

    @Test
    public void testZeroMaskLong() {
        BitField field = new BitField(0L);
        long holder = 0x123456789ABCDEFL;

        assertEquals(holder, field.clear(holder));
        assertEquals(holder, field.set(holder));
        assertFalse(field.isSet(holder));
        assertTrue(field.isAllSet(holder));
        assertEquals(0L, field.getRawValue(holder));
        assertEquals(0L, field.getValue(holder));
    }

    // ----- Boundary: mask covering the entire register (shift of zero) -----

    @Test
    public void testFullMaskIntHasNoShift() {
        BitField field = new BitField(0xFFFFFFFF);
        int holder = 0x12345678;

        assertEquals(holder, field.getValue(holder));
        assertEquals(holder, field.getRawValue(holder));

        int value = 0x7EDCBA98;
        assertEquals(value, field.setValue(0, value));
        assertEquals(-1, field.set(0));
        assertEquals(0, field.clear(-1));
        assertTrue(field.isAllSet(-1));
        assertTrue(field.isSet(1));
        assertFalse(field.isSet(0));
    }

    @Test
    public void testFullMaskLongHasNoShift() {
        BitField field = new BitField(0xFFFFFFFFFFFFFFFFL);
        long holder = 0x123456789ABCDEF0L;

        assertEquals(holder, field.getValue(holder));
        assertEquals(holder, field.getRawValue(holder));
        assertEquals(-1L, field.set(0L));
        assertEquals(0L, field.clear(-1L));
        assertTrue(field.isAllSet(-1L));
    }

    // ----- Single-bit (boolean-style) field -----

    @Test
    public void testSingleBitFieldBehavesAsFlag() {
        BitField flag = new BitField(0x1000000);

        assertFalse(flag.isSet(0));
        assertFalse(flag.isAllSet(0));

        int holderWithFlag = flag.set(0);
        assertEquals(0x1000000, holderWithFlag);
        assertTrue(flag.isSet(holderWithFlag));
        assertTrue(flag.isAllSet(holderWithFlag));
        assertEquals(1, flag.getValue(holderWithFlag));

        assertEquals(0, flag.clear(holderWithFlag));
    }
}
