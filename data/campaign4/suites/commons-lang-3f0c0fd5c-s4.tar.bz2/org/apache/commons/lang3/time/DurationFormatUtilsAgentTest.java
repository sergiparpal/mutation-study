package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

public class DurationFormatUtilsAgentTest {

    private static final long MILLIS_PER_SECOND = 1000L;
    private static final long MILLIS_PER_MINUTE = 60L * MILLIS_PER_SECOND;
    private static final long MILLIS_PER_HOUR = 60L * MILLIS_PER_MINUTE;
    private static final long MILLIS_PER_DAY = 24L * MILLIS_PER_HOUR;

    // ----------------------------------------------------------------
    // formatDuration(long, String) / formatDuration(long, String, boolean)
    //
    // Expectations below are taken verbatim from the "Example Output" table
    // in the class-level javadoc, which maps patterns against
    // Duration.ofDays(1), Duration.ofHours(1), Duration.ofMinutes(1) and
    // Duration.ZERO.
    // ----------------------------------------------------------------

    @Test
    public void testFormatDurationExampleTableSimplePattern() {
        final String pattern = "d'd'H'h'm'm's's'";
        assertEquals("1d0h0m0s", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("0d1h0m0s", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("0d0h1m0s", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("0d0h0m0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTableSingleOptionalBlock() {
        final String pattern = "d'd'[H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTableLeadingOptionalBlock() {
        final String pattern = "[d'd'H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("1h0s", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("1m0s", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTableWhollyOptionalPattern() {
        final String pattern = "[d'd'H'h'm'm's's']";
        assertEquals("1d", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("1h", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("1m", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTableLeadingOptionalLiteral() {
        final String pattern = "['{'d'}']HH':'mm";
        assertEquals("{1}00:00", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("01:00", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("00:01", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("00:00", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTableMultipleOptionalBlocks() {
        final String pattern = "['{'dd'}']['<'HH'>']['('mm')']";
        assertEquals("{01}", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("<01>", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("(00)", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTableOptionalTokensWithoutLiterals() {
        final String pattern = "[dHms]";
        assertEquals("1", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(MILLIS_PER_MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationPaddingFlag() {
        assertEquals("05", DurationFormatUtils.formatDuration(5L * MILLIS_PER_SECOND, "ss"));
        assertEquals("05", DurationFormatUtils.formatDuration(5L * MILLIS_PER_SECOND, "ss", true));
        assertEquals("5", DurationFormatUtils.formatDuration(5L * MILLIS_PER_SECOND, "ss", false));
        assertEquals("5", DurationFormatUtils.formatDuration(5L * MILLIS_PER_SECOND, "s", false));
    }

    @Test
    public void testFormatDurationNegativeThrows() {
        try {
            DurationFormatUtils.formatDuration(-1L, "d'd'H'h'm'm's's'");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
        try {
            DurationFormatUtils.formatDuration(-1L, "d'd'H'h'm'm's's'", false);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // ----------------------------------------------------------------
    // formatDurationHMS(long): documented as "HH:mm:ss.SSS"
    // ----------------------------------------------------------------

    @Test
    public void testFormatDurationHMS() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
        assertEquals("00:00:00.001", DurationFormatUtils.formatDurationHMS(1L));
        assertEquals("00:00:01.000", DurationFormatUtils.formatDurationHMS(MILLIS_PER_SECOND));
        assertEquals("00:01:01.000", DurationFormatUtils.formatDurationHMS(MILLIS_PER_MINUTE + MILLIS_PER_SECOND));
        assertEquals("01:01:01.000",
                DurationFormatUtils.formatDurationHMS(MILLIS_PER_HOUR + MILLIS_PER_MINUTE + MILLIS_PER_SECOND));
        // the pattern has no day field, so hours are not truncated at 24
        assertEquals("25:00:00.000", DurationFormatUtils.formatDurationHMS(25L * MILLIS_PER_HOUR));
    }

    @Test
    public void testFormatDurationHMSNegativeThrows() {
        try {
            DurationFormatUtils.formatDurationHMS(-1L);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // ----------------------------------------------------------------
    // formatDurationISO(long): "the days and lower fields of the ISO
    // format pattern, such as P7D6TH5M4.321S" (read as the standard
    // ISO-8601 ordering P<days>DT<hours>H<minutes>M<seconds>S).
    // ----------------------------------------------------------------

    @Test
    public void testFormatDurationISO() {
        assertEquals("P0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
        assertEquals("P0DT0H0M0.001S", DurationFormatUtils.formatDurationISO(1L));
        final long sevenDaysSixHoursFiveMinutesFourSecondsAndChange =
                7L * MILLIS_PER_DAY + 6L * MILLIS_PER_HOUR + 5L * MILLIS_PER_MINUTE + 4321L;
        assertEquals("P7DT6H5M4.321S",
                DurationFormatUtils.formatDurationISO(sevenDaysSixHoursFiveMinutesFourSecondsAndChange));
    }

    @Test
    public void testFormatDurationISONegativeThrows() {
        try {
            DurationFormatUtils.formatDurationISO(-1L);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // ----------------------------------------------------------------
    // formatDurationWords(long, boolean, boolean): the javadoc only
    // promises a "pluralization correct" string plus the meaning of the
    // two suppress flags, so assertions below stick to what that contract
    // implies rather than an exact wording.
    // ----------------------------------------------------------------

    @Test
    public void testFormatDurationWordsPluralization() {
        final String oneDay = DurationFormatUtils.formatDurationWords(MILLIS_PER_DAY, false, false);
        assertTrue(oneDay.contains("1 day"));
        assertFalse(oneDay.contains("1 days"));

        final String twoDays = DurationFormatUtils.formatDurationWords(2L * MILLIS_PER_DAY, false, false);
        assertTrue(twoDays.contains("2 days"));
        assertFalse(twoDays.contains("2 day "));
    }

    @Test
    public void testFormatDurationWordsSuppressLeadingZeroElements() {
        final String notSuppressed = DurationFormatUtils.formatDurationWords(MILLIS_PER_MINUTE, false, false);
        assertTrue(notSuppressed.contains("0 days"));
        assertTrue(notSuppressed.contains("0 hours"));
        assertTrue(notSuppressed.contains("1 minute"));

        final String suppressed = DurationFormatUtils.formatDurationWords(MILLIS_PER_MINUTE, true, false);
        assertFalse(suppressed.contains("day"));
        assertFalse(suppressed.contains("hour"));
        assertTrue(suppressed.contains("1 minute"));
    }

    @Test
    public void testFormatDurationWordsSuppressTrailingZeroElements() {
        final String notSuppressed = DurationFormatUtils.formatDurationWords(2L * MILLIS_PER_DAY, false, false);
        assertTrue(notSuppressed.contains("0 hours"));
        assertTrue(notSuppressed.contains("0 minutes"));
        assertTrue(notSuppressed.contains("0 seconds"));

        final String suppressed = DurationFormatUtils.formatDurationWords(2L * MILLIS_PER_DAY, false, true);
        assertTrue(suppressed.contains("2 days"));
        assertFalse(suppressed.contains("hour"));
        assertFalse(suppressed.contains("minute"));
        assertFalse(suppressed.contains("second"));
    }

    @Test
    public void testFormatDurationWordsZeroDoesNotThrow() {
        assertNotNull(DurationFormatUtils.formatDurationWords(0L, true, true));
    }

    @Test
    public void testFormatDurationWordsNegativeThrows() {
        try {
            DurationFormatUtils.formatDurationWords(-1L, false, false);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // ----------------------------------------------------------------
    // formatPeriod(long, long, String[, boolean, TimeZone])
    // ----------------------------------------------------------------

    @Test
    public void testFormatPeriodZeroLengthPeriod() {
        final String pattern = "d'd'H'h'm'm's's'";
        assertEquals("0d0h0m0s", DurationFormatUtils.formatPeriod(0L, 0L, pattern));
        assertEquals("0d0h0m0s",
                DurationFormatUtils.formatPeriod(0L, 0L, pattern, true, TimeZone.getTimeZone("UTC")));
    }

    @Test
    public void testFormatPeriodMatchesDurationForSubMonthRanges() {
        final String pattern = "d'd'H'h'm'm's's'";
        assertEquals("1d0h0m0s",
                DurationFormatUtils.formatPeriod(0L, MILLIS_PER_DAY, pattern, true, TimeZone.getTimeZone("UTC")));
        assertEquals("0d1h0m0s",
                DurationFormatUtils.formatPeriod(0L, MILLIS_PER_HOUR, pattern, true, TimeZone.getTimeZone("UTC")));
    }

    @Test
    public void testFormatPeriodPaddingFlag() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        assertEquals("05",
                DurationFormatUtils.formatPeriod(0L, 5L * MILLIS_PER_HOUR, "HH", true, utc));
        assertEquals("5",
                DurationFormatUtils.formatPeriod(0L, 5L * MILLIS_PER_HOUR, "HH", false, utc));
    }

    @Test
    public void testFormatPeriodMonthsCalculatedBeforeDays() {
        // This is the exact scenario worked through in the class-level javadoc:
        // January 15th to March 10th is 1 month and 23 days (not 1 month and 26 days).
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Calendar cal = Calendar.getInstance(utc);
        cal.clear();
        cal.set(2021, Calendar.JANUARY, 15, 0, 0, 0);
        final long start = cal.getTimeInMillis();
        cal.clear();
        cal.set(2021, Calendar.MARCH, 10, 0, 0, 0);
        final long end = cal.getTimeInMillis();

        assertEquals("1M23D", DurationFormatUtils.formatPeriod(start, end, "M'M'd'D'", true, utc));
    }

    @Test
    public void testFormatPeriodStartAfterEndThrows() {
        try {
            DurationFormatUtils.formatPeriod(1L, 0L, "d'd'H'h'm'm's's'");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
        try {
            DurationFormatUtils.formatPeriod(1L, 0L, "d'd'H'h'm'm's's'", true, TimeZone.getTimeZone("UTC"));
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // ----------------------------------------------------------------
    // formatPeriodISO(long, long)
    // ----------------------------------------------------------------

    @Test
    public void testFormatPeriodISOZeroLengthPeriod() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(0L, 0L));
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(123L, 123L));
    }

    @Test
    public void testFormatPeriodISOStartAfterEndThrows() {
        try {
            DurationFormatUtils.formatPeriodISO(1L, 0L);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // ----------------------------------------------------------------
    // Package-private helpers: lexx(String), format(Token[], ...) and the
    // nested Token class. These are reachable because this test lives in
    // the same package as the class under test.
    // ----------------------------------------------------------------

    @Test
    public void testLexxGroupsRepeatedTokenCharacters() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertEquals(1, tokens.length);
        assertEquals(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
    }

    @Test
    public void testLexxProducesOneTokenPerField() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyyMM");
        assertEquals(2, tokens.length);
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.M));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
    }

    @Test
    public void testLexxLiteralText() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("'hello'");
        assertEquals(1, tokens.length);
        assertEquals("hello", tokens[0].getValue());
        assertEquals(1, tokens[0].getCount());
    }

    @Test
    public void testLexxEscapedSingleQuote() {
        // "A literal single quote is represented by a pair of consecutive single quotes ('')."
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("''");
        assertEquals(1, tokens.length);
        assertEquals("'", tokens[0].getValue());
    }

    @Test
    public void testTokenHashCodeIgnoresCount() {
        // "Returns a hash code for the token equal to the hash code for the token's value.
        //  Thus 'TT' and 'TTTT' will have the same hash code."
        final DurationFormatUtils.Token[] shortRun = DurationFormatUtils.lexx("yy");
        final DurationFormatUtils.Token[] longRun = DurationFormatUtils.lexx("yyyy");
        assertEquals(2, shortRun[0].getCount());
        assertEquals(4, longRun[0].getCount());
        assertEquals(shortRun[0].hashCode(), longRun[0].hashCode());
    }

    @Test
    public void testTokenEqualsForMatchingConfiguration() {
        final DurationFormatUtils.Token[] a = DurationFormatUtils.lexx("yy");
        final DurationFormatUtils.Token[] b = DurationFormatUtils.lexx("yy");
        assertTrue(a[0].equals(b[0]));
    }

    @Test
    public void testTokenIncrement() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("y");
        assertEquals(1, tokens[0].getCount());
        tokens[0].increment();
        assertEquals(2, tokens[0].getCount());
    }

    @Test
    public void testTokenToStringNotNull() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertNotNull(tokens[0].toString());
    }

    @Test
    public void testFormatInternalMethodMatchesPublicContract() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'H'h'm'm's's'");
        assertEquals("1d0h0m0s", DurationFormatUtils.format(tokens, 0L, 0L, 1L, 0L, 0L, 0L, 0L, true));
        assertEquals("0d1h0m0s", DurationFormatUtils.format(tokens, 0L, 0L, 0L, 1L, 0L, 0L, 0L, true));
        assertEquals("0d0h1m0s", DurationFormatUtils.format(tokens, 0L, 0L, 0L, 0L, 1L, 0L, 0L, true));
        assertEquals("0d0h0m0s", DurationFormatUtils.format(tokens, 0L, 0L, 0L, 0L, 0L, 0L, 0L, true));
    }

    @Test
    public void testFormatInternalMethodPadding() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("dd'd'");
        assertEquals("05d", DurationFormatUtils.format(tokens, 0L, 0L, 5L, 0L, 0L, 0L, 0L, true));
        assertEquals("5d", DurationFormatUtils.format(tokens, 0L, 0L, 5L, 0L, 0L, 0L, 0L, false));
    }
}
