/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface AgentMarker {
    }

    public interface AgentAnimal {
        String speak();
    }

    public static class AgentBase {
        public String overloaded(final Object o) {
            return "Object";
        }

        public String overloaded(final String s) {
            return "String:" + s;
        }

        public static String staticGreet(final String name) {
            return "Hello, " + name;
        }

        @AgentMarker
        public void markedMethod() {
            // no-op
        }

        protected String protectedMethod() {
            return "protected";
        }

        private String privateMethod(final String s) {
            return "private:" + s;
        }

        public void varArgsMethod(final String first, final int... rest) {
            lastVarArgsResult = first + ":" + rest.length;
        }

        String lastVarArgsResult;
    }

    public static class AgentChild extends AgentBase implements AgentAnimal {
        @Override
        public String speak() {
            return "woof";
        }

        public String childOnly() {
            return "childOnly";
        }

        public void throwingMethod() {
            throw new IllegalStateException("boom");
        }
    }

    @Test
    void testGetAccessibleMethodByClassNameTypes() {
        final Method method = MethodUtils.getAccessibleMethod(AgentChild.class, "speak");
        assertNotNull(method);
        assertEquals("speak", method.getName());
    }

    @Test
    void testGetAccessibleMethodReturnsNullWhenNotPublic() {
        final Method privateMethod = MethodUtils.getMatchingMethod(AgentBase.class, "privateMethod", String.class);
        assertNotNull(privateMethod);
        assertNull(MethodUtils.getAccessibleMethod(privateMethod));
    }

    @Test
    void testGetAnnotationDirect() throws NoSuchMethodException {
        final Method method = AgentBase.class.getMethod("markedMethod");
        final AgentMarker annotation = MethodUtils.getAnnotation(method, AgentMarker.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    void testGetAnnotationNotPresentReturnsNull() throws NoSuchMethodException {
        final Method method = AgentBase.class.getMethod("staticGreet", String.class);
        assertNull(MethodUtils.getAnnotation(method, AgentMarker.class, true, true));
    }

    @Test
    void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, AgentMarker.class, false, false));
    }

    @Test
    void testGetMatchingAccessibleMethodExactMatch() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(AgentBase.class, "overloaded", String.class);
        assertNotNull(method);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(AgentBase.class, "doesNotExist", Integer.class));
    }

    @Test
    void testGetMatchingMethodFindsDeclaredPrivateMethod() {
        final Method method = MethodUtils.getMatchingMethod(AgentBase.class, "privateMethod", String.class);
        assertNotNull(method);
        assertEquals("privateMethod", method.getName());
    }

    @Test
    void testGetMatchingMethodNoSuchMethodReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(AgentBase.class, "noSuchMethodAtAll"));
    }

    @Test
    void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "anything"));
    }

    @Test
    void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(AgentBase.class, ""));
    }

    @Test
    void testGetMethodObjectReturnsNullOnNoSuchMethod() {
        assertNull(MethodUtils.getMethodObject(AgentBase.class, "noSuchMethodAtAll"));
    }

    @Test
    void testGetMethodObjectNullClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "speak"));
    }

    @Test
    void testGetMethodObjectFound() {
        final Method method = MethodUtils.getMethodObject(AgentChild.class, "speak");
        assertNotNull(method);
    }

    @Test
    void testGetMethodsListWithAnnotation() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentBase.class, AgentMarker.class);
        assertEquals(1, methods.size());
        assertEquals("markedMethod", methods.get(0).getName());
    }

    @Test
    void testGetMethodsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, AgentMarker.class));
    }

    @Test
    void testGetMethodsListWithAnnotationNullAnnotationThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(AgentBase.class, null));
    }

    @Test
    void testGetMethodsWithAnnotationEmptyWhenNoneMatch() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentChild.class, Deprecated.class);
        assertEquals(0, methods.length);
    }

    @Test
    void testGetOverrideHierarchy() throws NoSuchMethodException {
        final Method method = AgentChild.class.getMethod("speak");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.INCLUDE);
        assertTrue(hierarchy.contains(method));
        assertTrue(hierarchy.size() >= 2);
    }

    @Test
    void testGetOverrideHierarchyNullThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE));
    }

    @Test
    void testInvokeExactMethodNoArgs() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeExactMethod(child, "speak");
        assertEquals("woof", result);
    }

    @Test
    void testInvokeExactMethodWithArgs() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final AgentBase base = new AgentBase();
        final Object result = MethodUtils.invokeExactMethod(base, "overloaded", "hi");
        assertEquals("String:hi", result);
    }

    @Test
    void testInvokeExactMethodNoSuchMethod() {
        final AgentBase base = new AgentBase();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(base, "overloaded", 1));
    }

    @Test
    void testInvokeExactMethodNullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeExactMethod(null, "speak"));
    }

    @Test
    void testInvokeExactStaticMethod() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final Object result = MethodUtils.invokeExactStaticMethod(AgentBase.class, "staticGreet", "World");
        assertEquals("Hello, World", result);
    }

    @Test
    void testInvokeMethodNoForceAccessFailsOnProtected() {
        final AgentBase base = new AgentBase();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(base, false, "protectedMethod"));
    }

    @Test
    void testInvokeMethodForceAccessSucceedsOnProtected()
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final AgentBase base = new AgentBase();
        final Object result = MethodUtils.invokeMethod(base, true, "protectedMethod");
        assertEquals("protected", result);
    }

    @Test
    void testInvokeMethodOnSubclassMethod() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeMethod(child, "childOnly");
        assertEquals("childOnly", result);
    }

    @Test
    void testInvokeMethodPropagatesTargetException() {
        final AgentChild child = new AgentChild();
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class,
                () -> MethodUtils.invokeMethod(child, "throwingMethod"));
        assertTrue(ex.getCause() instanceof IllegalStateException);
        assertEquals("boom", ex.getCause().getMessage());
    }

    @Test
    void testInvokeMethodWithVarArgs() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final AgentBase base = new AgentBase();
        MethodUtils.invokeMethod(base, "varArgsMethod", "first", 1, 2, 3);
        assertEquals("first:3", base.lastVarArgsResult);
    }

    @Test
    void testInvokeMethodNoSuchMethodThrows() {
        final AgentBase base = new AgentBase();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(base, "totallyMissingMethod"));
    }

    @Test
    void testInvokeStaticMethod() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final Object result = MethodUtils.invokeStaticMethod(AgentBase.class, "staticGreet", "Agent");
        assertEquals("Hello, Agent", result);
    }

    @Test
    void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(AgentBase.class, "noSuchStaticMethod"));
    }

    @Test
    void testConstructorIsDeprecatedButUsable() {
        assertNotNull(new MethodUtils());
    }

    @Test
    void testGetAccessibleMethodFromInterface() {
        final Method method = MethodUtils.getAccessibleMethod(AgentChild.class, "speak", (Class<?>[]) null);
        assertNotNull(method);
        assertArrayEquals(new Class<?>[0], method.getParameterTypes());
    }

    @Test
    void testGetAnnotationIgnoreAccessFalseOnPrivateUnderlyingReturnsNull() throws NoSuchMethodException {
        final Method method = AgentBase.class.getDeclaredMethod("privateMethod", String.class);
        final Annotation result = MethodUtils.getAnnotation(method, AgentMarker.class, false, false);
        assertNull(result);
    }

    @Test
    void testGetMatchingMethodMultipleCandidatesPicksBestDistance() {
        final Method method = MethodUtils.getMatchingMethod(AgentBase.class, "overloaded", String.class);
        assertNotNull(method);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    void testInvokeExactStaticMethodNullArgsTreatedAsEmpty()
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        final Object result = MethodUtils.invokeExactStaticMethod(AgentBase.class, "staticGreet", new Object[] {"X"}, new Class<?>[] {String.class});
        assertEquals("Hello, X", result);
    }

    @Test
    void testFalseAssertionsSanityOnOverriddenMethodNotFoundWithWrongTypes() {
        assertFalse(MethodUtils.getMethodsListWithAnnotation(AgentChild.class, AgentMarker.class, true, false).isEmpty());
    }
}
