/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum HeaderEnum {
        NAME, EMAIL, PHONE
    }

    // ---------------------------------------------------------------
    // Predefined format sanity checks
    // ---------------------------------------------------------------

    @Test
    void testDefaultFormatValues() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
        final CSVFormat rebuilt = CSVFormat.RFC4180.builder().setIgnoreEmptyLines(true).get();
        assertEquals(CSVFormat.DEFAULT, rebuilt);
    }

    @Test
    void testExcelFormat() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testTdfFormat() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormat() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("DoesNotExist"));
    }

    // ---------------------------------------------------------------
    // newFormat
    // ---------------------------------------------------------------

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\n'));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\r'));
    }

    // ---------------------------------------------------------------
    // Builder validation (boundary / error cases)
    // ---------------------------------------------------------------

    @Test
    void testBuilderRejectsEmptyDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("").get());
    }

    @Test
    void testBuilderRejectsLineBreakDelimiterString() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("a\nb").get());
    }

    @Test
    void testBuilderRejectsLineBreakCommentMarker() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setCommentMarker('\n'));
    }

    @Test
    void testBuilderRejectsLineBreakEscape() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setEscape('\r'));
    }

    @Test
    void testBuilderRejectsLineBreakQuote() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuote('\r'));
    }

    @Test
    void testQuoteSameAsDelimiterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setDelimiter(',').setQuote(',').get());
        assertTrue(ex.getMessage().contains("quoteChar"));
    }

    @Test
    void testEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testQuoteSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setDelimiter(',').setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testEscapeSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setDelimiter(',').setQuote(null).setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = Builder.create().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderNamesAllowedByDefault() {
        final CSVFormat format = Builder.create().setHeader("A", "B", "A").get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertEquals(3, format.getHeader().length);
    }

    @Test
    void testDuplicateHeaderNamesRejectedWithDisallowMode() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B", "A").get());
    }

    @Test
    void testDuplicateHeaderNamesAllowedWithAllowAllMode() {
        final CSVFormat format = Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("A", "B", "A").get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertEquals(3, format.getHeader().length);
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowedWithAllowEmptyMode() {
        final CSVFormat format = Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "").get();
        assertEquals("A", format.getHeader()[0]);
    }

    @Test
    void testDuplicateNonEmptyHeaderNamesRejectedWithAllowEmptyMode() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get());
    }

    @Test
    void testSetDuplicateHeaderModeNullThrows() {
        assertThrows(NullPointerException.class, () -> Builder.create().setDuplicateHeaderMode(null));
    }

    // ---------------------------------------------------------------
    // Getters / state accessors
    // ---------------------------------------------------------------

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final String[] original = {"A", "B"};
        final CSVFormat format = Builder.create().setHeader(original).get();
        original[0] = "MUTATED";
        assertEquals("A", format.getHeader()[0]);
        final String[] returned = format.getHeader();
        returned[0] = "MUTATED-2";
        assertEquals("A", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderNullWhenNotSet() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.MYSQL.isQuoteCharacterSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.MYSQL.isNullStringSet());
    }

    @Test
    void testGetDelimiterString() {
        final CSVFormat format = Builder.create().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
        assertEquals(':', format.getDelimiter());
    }

    @Test
    void testMaxRowsDefaultIsZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    void testEqualsReflexiveAndWithDifferentType() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(CSVFormat.DEFAULT, "not a CSVFormat");
        assertNotEquals(null, CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsAndHashCodeConsistentForEquivalentFormats() {
        final CSVFormat a = Builder.create().setDelimiter(';').setHeader("X", "Y").get();
        final CSVFormat b = Builder.create().setDelimiter(';').setHeader("X", "Y").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsFalseForDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotEquals(a, b);
    }

    // ---------------------------------------------------------------
    // builder()/copy semantics
    // ---------------------------------------------------------------

    @Test
    void testBuilderRoundTripPreservesEquality() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("A", "B").setNullString("NULL").get();
        final CSVFormat rebuilt = original.builder().get();
        assertEquals(original, rebuilt);
        assertNotNull(rebuilt);
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testFormatEmptyArgs() {
        final String result = CSVFormat.DEFAULT.format();
        assertEquals("", result);
    }

    // ---------------------------------------------------------------
    // print(Object, Appendable, boolean)
    // ---------------------------------------------------------------

    @Test
    void testPrintSingleValueNewRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintValueNotNewRecordPrependsDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, false);
        assertEquals(",hello", writer.toString());
    }

    @Test
    void testPrintNullValueWithoutNullStringIsEmpty() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueWithNullStringConfigured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    // ---------------------------------------------------------------
    // parse(Reader)
    // ---------------------------------------------------------------

    @Test
    void testParseProducesExpectedRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n1,2,3\r\n"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("3", records.get(1).get(2));
        parser.close();
    }

    @Test
    void testParseWithHeaderAllowsNameAccess() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        final CSVParser parser = format.parse(new StringReader("v1,v2\r\n"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("v1", records.get(0).get("col1"));
        parser.close();
    }

    // ---------------------------------------------------------------
    // print(Appendable) / printer round trip
    // ---------------------------------------------------------------

    @Test
    void testPrintToAppendableAndParseBack() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        printer.printRecord("x", "y");
        printer.close();
        assertEquals("x,y\r\n", writer.toString());
    }

    // ---------------------------------------------------------------
    // withXxx deprecated convenience methods
    // ---------------------------------------------------------------

    @Test
    void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', format.getDelimiter());
    }

    @Test
    void testWithHeaderVarargs() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertEquals(2, format.getHeader().length);
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(HeaderEnum.class);
        assertEquals(3, format.getHeader().length);
        assertEquals("NAME", format.getHeader()[0]);
        assertEquals("PHONE", format.getHeader()[2]);
    }

    @Test
    void testWithHeaderNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(format.getHeader());
    }

    @Test
    void testWithQuoteModeAndWithQuote() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'').withQuoteMode(QuoteMode.ALL);
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testWithNullStringSetsBothNullStringAndQuotedNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testWithTrimAndWithTrailingDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrim().withTrailingDelimiter();
        assertTrue(format.getTrim());
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    void testWithIgnoreEmptyLinesAndSurroundingSpacesAndHeaderCase() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false).withIgnoreSurroundingSpaces().withIgnoreHeaderCase();
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreHeaderCase());
    }

    @Test
    void testWithSkipHeaderRecordAndAllowMissingColumnNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord().withAllowMissingColumnNames();
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    void testWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    void testWithCommentMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("line1", "line2");
        assertEquals(2, format.getHeaderComments().length);
        assertEquals("line1", format.getHeaderComments()[0]);
    }

    @Test
    void testWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @Test
    void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testWithAllowDuplicateHeaderNamesDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    // ---------------------------------------------------------------
    // toString
    // ---------------------------------------------------------------

    @Test
    void testToStringContainsDelimiterAndSkipHeaderRecord() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringIncludesHeaderWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final String str = format.toString();
        assertTrue(str.contains("Header:[a, b]"));
    }

    // ---------------------------------------------------------------
    // Predefined enum
    // ---------------------------------------------------------------

    @Test
    void testPredefinedGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
    }

    // ---------------------------------------------------------------
    // Builder.get() vs build()
    // ---------------------------------------------------------------

    @Test
    void testBuilderGetAndBuildReturnEquivalentFormats() {
        final Builder builder = Builder.create().setDelimiter('|');
        final CSVFormat fromGet = builder.get();
        final CSVFormat fromBuild = builder.build();
        assertEquals(fromGet, fromBuild);
    }

    @Test
    void testMaxRowsLimitsParsedRecords() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        final CSVParser parser = format.parse(new StringReader("1,2\r\n3,4\r\n5,6\r\n"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        parser.close();
    }
}
