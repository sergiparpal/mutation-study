package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class LocaleUtilsAgentTest {

    // ---------------------------------------------------------------
    // availableLocaleList()
    // ---------------------------------------------------------------

    @Test
    public void testAvailableLocaleListNotEmptyAndContainsUs() {
        List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                list.add(Locale.CANADA);
            }
        });
    }

    @Test
    public void testAvailableLocaleListMatchesSet() {
        List<Locale> list = LocaleUtils.availableLocaleList();
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertEquals(set, new HashSet<Locale>(list));
        assertEquals(set.size(), list.size());
    }

    @Test
    public void testAvailableLocaleListCachedSameContent() {
        List<Locale> first = LocaleUtils.availableLocaleList();
        List<Locale> second = LocaleUtils.availableLocaleList();
        assertEquals(first, second);
    }

    // ---------------------------------------------------------------
    // availableLocaleSet()
    // ---------------------------------------------------------------

    @Test
    public void testAvailableLocaleSetNotEmptyAndContainsUs() {
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleSetIsUnmodifiable() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                set.add(Locale.CANADA);
            }
        });
    }

    // ---------------------------------------------------------------
    // countriesByLanguage(String)
    // ---------------------------------------------------------------

    @Test
    public void testCountriesByLanguageNull() {
        List<Locale> result = LocaleUtils.countriesByLanguage(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageEnglish() {
        List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Locale locale : result) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testCountriesByLanguageIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                result.add(Locale.US);
            }
        });
    }

    @Test
    public void testCountriesByLanguageIsCached() {
        List<Locale> first = LocaleUtils.countriesByLanguage("en");
        List<Locale> second = LocaleUtils.countriesByLanguage("en");
        assertEquals(first, second);
    }

    @Test
    public void testCountriesByLanguageUnknown() {
        List<Locale> result = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ---------------------------------------------------------------
    // languagesByCountry(String)
    // ---------------------------------------------------------------

    @Test
    public void testLanguagesByCountryNull() {
        List<Locale> result = LocaleUtils.languagesByCountry(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryGb() {
        List<Locale> result = LocaleUtils.languagesByCountry("GB");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Locale locale : result) {
            assertEquals("GB", locale.getCountry());
            assertFalse(locale.getLanguage().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testLanguagesByCountryIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.languagesByCountry("GB");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                result.add(Locale.US);
            }
        });
    }

    @Test
    public void testLanguagesByCountryUnknown() {
        List<Locale> result = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ---------------------------------------------------------------
    // isAvailableLocale(Locale)
    // ---------------------------------------------------------------

    @Test
    public void testIsAvailableLocaleTrue() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
    }

    @Test
    public void testIsAvailableLocaleFalseForUnknownLocale() {
        Locale fake = new Locale("xx", "XX");
        assertFalse(LocaleUtils.isAvailableLocale(fake));
    }

    @Test
    public void testIsAvailableLocaleNull() {
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    // ---------------------------------------------------------------
    // isLanguageUndetermined(Locale)
    // ---------------------------------------------------------------

    @Test
    public void testIsLanguageUndeterminedExplicitUnd() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("und")));
    }

    @Test
    public void testIsLanguageUndeterminedEmptyLanguage() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
    }

    @Test
    public void testIsLanguageUndeterminedNotWellFormedShort() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
    }

    @Test
    public void testIsLanguageUndeterminedNotWellFormedWithDigit() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("e2")));
    }

    @Test
    public void testIsLanguageUndeterminedWellFormedLanguage() {
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("en")));
    }

    // ---------------------------------------------------------------
    // localeLookupList(Locale)
    // ---------------------------------------------------------------

    @Test
    public void testLocaleLookupListSingleArgDocumentedExample() {
        Locale locale = new Locale("fr", "CA", "xxx");
        List<Locale> result = LocaleUtils.localeLookupList(locale);
        assertEquals(3, result.size());
        assertEquals(new Locale("fr", "CA", "xxx"), result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
    }

    @Test
    public void testLocaleLookupListSingleArgNull() {
        List<Locale> result = LocaleUtils.localeLookupList(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListSingleArgIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.US);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                result.add(Locale.FRANCE);
            }
        });
    }

    @Test
    public void testLocaleLookupListSingleArgLanguageOnly() {
        List<Locale> result = LocaleUtils.localeLookupList(new Locale("en"));
        assertEquals(1, result.size());
        assertEquals(new Locale("en"), result.get(0));
    }

    // ---------------------------------------------------------------
    // localeLookupList(Locale, Locale)
    // ---------------------------------------------------------------

    @Test
    public void testLocaleLookupListTwoArgDocumentedExample() {
        Locale locale = new Locale("fr", "CA", "xxx");
        Locale defaultLocale = new Locale("en");
        List<Locale> result = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertEquals(4, result.size());
        assertEquals(new Locale("fr", "CA", "xxx"), result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
        assertEquals(new Locale("en"), result.get(3));
    }

    @Test
    public void testLocaleLookupListTwoArgNullLocale() {
        List<Locale> result = LocaleUtils.localeLookupList(null, Locale.US);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListTwoArgNoDuplicates() {
        List<Locale> result = LocaleUtils.localeLookupList(Locale.US, Locale.US);
        assertEquals(2, result.size());
        assertEquals(Locale.US, result.get(0));
        assertEquals(new Locale("en"), result.get(1));
    }

    @Test
    public void testLocaleLookupListTwoArgIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.US, Locale.FRANCE);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                result.add(Locale.GERMANY);
            }
        });
    }

    // ---------------------------------------------------------------
    // ofCountry(String) [package-private]
    // ---------------------------------------------------------------

    @Test
    public void testOfCountryNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                LocaleUtils.ofCountry(null);
            }
        });
    }

    @Test
    public void testOfCountryValid() {
        Locale locale = LocaleUtils.ofCountry("US");
        assertNotNull(locale);
        assertEquals("US", locale.getCountry());
        assertEquals("", locale.getLanguage());
    }

    // ---------------------------------------------------------------
    // toLocale(Locale)
    // ---------------------------------------------------------------

    @Test
    public void testToLocaleFromLocaleNonNull() {
        assertEquals(Locale.FRANCE, LocaleUtils.toLocale(Locale.FRANCE));
    }

    @Test
    public void testToLocaleFromLocaleNullReturnsDefault() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    // ---------------------------------------------------------------
    // toLocale(String)
    // ---------------------------------------------------------------

    @Test
    public void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en", ""), LocaleUtils.toLocale("en"));
    }

    @Test
    public void testToLocaleStringLanguageCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    public void testToLocaleStringLanguageCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    public void testToLocaleStringNumericCountry() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    public void testToLocaleStringWithVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    public void testToLocaleStringCountryOnlySpecialCase() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    public void testToLocaleStringInvalidLowercaseCountry() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidUppercaseLanguage() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                LocaleUtils.toLocale("EN_GB");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidFormatTooManyParts() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_GB_xxx_extra_extra");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidShortCountry() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_G");
            }
        });
    }
}
