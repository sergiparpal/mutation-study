/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    private interface Box<T> {
        // marker generic interface
    }

    private static class StringBox implements Box<String> {
        // concrete implementation binding T to String
    }

    private static class Outer<K> {
        class Inner<V> {
            // non-static member class, used to test owner handling
        }
    }

    private static class NumBox<N extends Number> {
        // used to get a bounded type variable
    }

    private static class Fixture<T> {
        List<String> stringList;
        List<T> listOfT;
        List<? extends Number> listOfExtendsNumber;
        List<? super Integer> listOfSuperInteger;
        List<?> listOfWildcard;
        Map<String, List<Integer>> nestedMap;
        T[] arrayOfT;
        String[] stringArray;
    }

    private static final Type CUSTOM_TYPE = new Type() {
        @Override
        public String toString() {
            return "custom";
        }
    };

    private static Type genericFieldType(final String name) throws NoSuchFieldException {
        final Field field = Fixture.class.getDeclaredField(name);
        return field.getGenericType();
    }

    private static void assertThrowsNpe(final Executable executable) {
        assertThrows(NullPointerException.class, executable);
    }

    // --- containsTypeVariables -------------------------------------------------

    @Test
    void testContainsTypeVariables() throws Exception {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertFalse(TypeUtils.containsTypeVariables(genericFieldType("stringList")));
        assertTrue(TypeUtils.containsTypeVariables(genericFieldType("listOfT")));
        assertTrue(TypeUtils.containsTypeVariables(genericFieldType("arrayOfT")));
        assertTrue(TypeUtils.containsTypeVariables(List.class));
        final TypeVariable<?> t = Fixture.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(t));
    }

    // --- determineTypeArguments --------------------------------------------------

    @Test
    void testDetermineTypeArguments() {
        final ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(StringBox.class, boxOfString);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(String.class, result.values().iterator().next());

        assertNull(TypeUtils.determineTypeArguments(Integer.class, boxOfString));

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, boxOfString);
            }
        });
        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(StringBox.class, null);
            }
        });
    }

    // --- equals -------------------------------------------------------------------

    @Test
    void testEquals() throws Exception {
        assertTrue(TypeUtils.equals(null, null));
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
        assertFalse(TypeUtils.equals(String.class, null));

        final Type listOfStringField = genericFieldType("stringList");
        final ParameterizedType listOfStringBuilt = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.equals(listOfStringField, listOfStringBuilt));

        final GenericArrayType arrayBuilt = TypeUtils.genericArrayType(String.class);
        final GenericArrayType arrayBuiltAgain = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(arrayBuilt, arrayBuiltAgain));
        // A GenericArrayType never equals a plain array Class, even with the same component type.
        assertFalse(TypeUtils.equals(arrayBuilt, String[].class));
    }

    // --- genericArrayType -----------------------------------------------------

    @Test
    void testGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, arrayType.getGenericComponentType());
        assertEquals("java.lang.String[]", arrayType.toString());
        assertEquals(arrayType, arrayType);
        assertFalse(arrayType.equals(String[].class));

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    // --- getArrayComponentType --------------------------------------------------

    @Test
    void testGetArrayComponentType() throws Exception {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
        assertNull(TypeUtils.getArrayComponentType(genericFieldType("listOfT")));

        final Type arrayOfTType = genericFieldType("arrayOfT");
        final Type componentType = TypeUtils.getArrayComponentType(arrayOfTType);
        assertTrue(componentType instanceof TypeVariable<?>);
    }

    // --- getImplicitBounds / getImplicitLowerBounds / getImplicitUpperBounds ---

    @Test
    void testGetImplicitBounds() {
        final TypeVariable<?> unbounded = Fixture.class.getTypeParameters()[0];
        final Type[] unboundedBounds = TypeUtils.getImplicitBounds(unbounded);
        assertEquals(1, unboundedBounds.length);
        assertEquals(Object.class, unboundedBounds[0]);

        final TypeVariable<?> bounded = NumBox.class.getTypeParameters()[0];
        final Type[] boundedBounds = TypeUtils.getImplicitBounds(bounded);
        assertEquals(1, boundedBounds.length);
        assertEquals(Number.class, boundedBounds[0]);

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitLowerBounds() throws Exception {
        final Type[] noLowerBound = TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, noLowerBound.length);
        assertNull(noLowerBound[0]);

        final WildcardType superInteger = (WildcardType) ((ParameterizedType) genericFieldType("listOfSuperInteger")).getActualTypeArguments()[0];
        final Type[] lowerBounds = TypeUtils.getImplicitLowerBounds(superInteger);
        assertEquals(1, lowerBounds.length);
        assertEquals(Integer.class, lowerBounds[0]);

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitUpperBounds() throws Exception {
        final Type[] defaultUpper = TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, defaultUpper.length);
        assertEquals(Object.class, defaultUpper[0]);

        final WildcardType extendsNumber = (WildcardType) ((ParameterizedType) genericFieldType("listOfExtendsNumber")).getActualTypeArguments()[0];
        final Type[] upperBounds = TypeUtils.getImplicitUpperBounds(extendsNumber);
        assertEquals(1, upperBounds.length);
        assertEquals(Number.class, upperBounds[0]);

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    // --- getRawType(Type, Type) --------------------------------------------------

    @Test
    void testGetRawType() throws Exception {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
        assertEquals(List.class, TypeUtils.getRawType(genericFieldType("stringList"), null));
        assertNull(TypeUtils.getRawType(Fixture.class.getTypeParameters()[0], null));

        final Type arrayOfTType = genericFieldType("arrayOfT");
        assertNull(TypeUtils.getRawType(arrayOfTType, null));

        final WildcardType extendsNumber = (WildcardType) ((ParameterizedType) genericFieldType("listOfExtendsNumber")).getActualTypeArguments()[0];
        assertNull(TypeUtils.getRawType(extendsNumber, null));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getRawType(CUSTOM_TYPE, null);
            }
        });
    }

    // --- getTypeArguments ---------------------------------------------------------

    @Test
    void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(boxOfString);
        assertEquals(1, args.size());
        assertEquals(String.class, args.values().iterator().next());
    }

    @Test
    void testGetTypeArgumentsTypeClass() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringBox.class, Box.class);
        assertNotNull(args);
        assertEquals(1, args.size());
        assertEquals(String.class, args.values().iterator().next());

        assertNull(TypeUtils.getTypeArguments(Integer.class, Box.class));
    }

    // --- isArrayType ----------------------------------------------------------

    @Test
    void testIsArrayType() throws Exception {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertTrue(TypeUtils.isArrayType(genericFieldType("arrayOfT")));
        assertFalse(TypeUtils.isArrayType(genericFieldType("listOfT")));
    }

    // --- isAssignable --------------------------------------------------------

    @Test
    void testIsAssignable() throws Exception {
        assertTrue(TypeUtils.isAssignable(String.class, Object.class));
        assertFalse(TypeUtils.isAssignable(Object.class, String.class));
        assertTrue(TypeUtils.isAssignable(null, Object.class));
        assertFalse(TypeUtils.isAssignable(null, int.class));

        final Type listOfString = genericFieldType("stringList");
        assertTrue(TypeUtils.isAssignable(listOfString, List.class));

        final ParameterizedType arrayListOfString = TypeUtils.parameterize(ArrayList.class, String.class);
        final ParameterizedType listOfStringParam = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isAssignable(arrayListOfString, listOfStringParam));

        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.isAssignable(arrayListOfString, listOfInteger));

        assertTrue(TypeUtils.isAssignable(String[].class, TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isAssignable(String.class, TypeUtils.genericArrayType(String.class)));
    }

    // --- isInstance ---------------------------------------------------------

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("foo", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(1), String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("foo", null));
    }

    // --- normalizeUpperBounds ---------------------------------------------------

    @Test
    void testNormalizeUpperBounds() {
        final Type[] single = { Number.class };
        assertEquals(single, TypeUtils.normalizeUpperBounds(single));

        final Type[] redundant = { Number.class, Integer.class };
        final Type[] normalized = TypeUtils.normalizeUpperBounds(redundant);
        assertEquals(1, normalized.length);
        assertEquals(Integer.class, normalized[0]);

        final Type[] unrelated = { java.io.Serializable.class, Comparable.class };
        final Type[] normalizedUnrelated = TypeUtils.normalizeUpperBounds(unrelated);
        assertEquals(2, normalizedUnrelated.length);

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    // --- parameterize / parameterizeWithOwner -----------------------------------

    @Test
    void testParameterize() {
        final ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(Box.class, boxOfString.getRawType());
        assertEquals(1, boxOfString.getActualTypeArguments().length);
        assertEquals(String.class, boxOfString.getActualTypeArguments()[0]);
        // Box is a non-static nested type, so its default owner is its enclosing class.
        assertEquals(TypeUtilsAgentTest.class, boxOfString.getOwnerType());

        final Map<TypeVariable<?>, Type> typeVarMap = new HashMap<TypeVariable<?>, Type>();
        typeVarMap.put(Box.class.getTypeParameters()[0], Integer.class);
        final ParameterizedType boxOfInteger = TypeUtils.parameterize(Box.class, typeVarMap);
        assertEquals(Integer.class, boxOfInteger.getActualTypeArguments()[0]);

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(Box.class, String.class, Integer.class);
            }
        });

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(Box.class, (Type) null);
            }
        });

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(null, String.class);
            }
        });
    }

    @Test
    void testParameterizeWithOwner() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // ArrayList has no enclosing class, so it cannot be given an owner.
                TypeUtils.parameterizeWithOwner(Outer.class, ArrayList.class, String.class);
            }
        });

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // Outer is not a valid owner type for Box's enclosing class.
                TypeUtils.parameterizeWithOwner(Outer.class, Box.class, String.class);
            }
        });

        final ParameterizedType innerType = TypeUtils.parameterizeWithOwner(null, Outer.Inner.class, String.class);
        assertEquals(Outer.class, innerType.getOwnerType());
        assertEquals(String.class, innerType.getActualTypeArguments()[0]);

        final ParameterizedType outerOfNumber = TypeUtils.parameterize(Outer.class, Number.class);
        final ParameterizedType innerWithOwner = TypeUtils.parameterizeWithOwner(outerOfNumber, Outer.Inner.class, String.class);
        assertEquals(outerOfNumber, innerWithOwner.getOwnerType());

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // String is not a valid owner type for Outer.Inner.
                TypeUtils.parameterizeWithOwner(String.class, Outer.Inner.class, String.class);
            }
        });
    }

    // --- toLongString / toString -------------------------------------------------

    @Test
    void testToString() throws Exception {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
        assertEquals("java.lang.String[]", TypeUtils.toString(String[].class));
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(genericFieldType("stringList")));

        final WildcardType extendsNumber = (WildcardType) ((ParameterizedType) genericFieldType("listOfExtendsNumber")).getActualTypeArguments()[0];
        assertEquals("? extends java.lang.Number", TypeUtils.toString(extendsNumber));

        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    void testToLongString() {
        final TypeVariable<?> t = Fixture.class.getTypeParameters()[0];
        final String longString = TypeUtils.toLongString(t);
        assertEquals(TypeUtilsAgentTest.class.getName() + ".Fixture:T", longString);

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    // --- typesSatisfyVariables -----------------------------------------------

    @Test
    void testTypesSatisfyVariables() {
        final Map<TypeVariable<?>, Type> unboundedAssign = new HashMap<TypeVariable<?>, Type>();
        unboundedAssign.put(Fixture.class.getTypeParameters()[0], String.class);
        assertTrue(TypeUtils.typesSatisfyVariables(unboundedAssign));

        final Map<TypeVariable<?>, Type> badAssign = new HashMap<TypeVariable<?>, Type>();
        badAssign.put(NumBox.class.getTypeParameters()[0], String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(badAssign));

        final Map<TypeVariable<?>, Type> goodAssign = new HashMap<TypeVariable<?>, Type>();
        goodAssign.put(NumBox.class.getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(goodAssign));

        assertThrowsNpe(new Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    // --- wildcardType / WILDCARD_ALL -----------------------------------------

    @Test
    void testWildcardType() {
        assertEquals(1, TypeUtils.WILDCARD_ALL.getUpperBounds().length);
        assertEquals(Object.class, TypeUtils.WILDCARD_ALL.getUpperBounds()[0]);
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);

        final WildcardType extendsNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals(Number.class, extendsNumber.getUpperBounds()[0]);
        assertEquals(0, extendsNumber.getLowerBounds().length);

        final WildcardType superInteger = TypeUtils.wildcardType().withLowerBounds(Integer.class).build();
        assertEquals(Integer.class, superInteger.getLowerBounds()[0]);
        // Lower-bounded wildcards still carry an implicit Object upper bound.
        assertEquals(Object.class, superInteger.getUpperBounds()[0]);
    }

    @Test
    void testWildcardTypeEqualityWithReflectedWildcard() throws Exception {
        final WildcardType extendsNumberBuilt = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType extendsNumberReflected = (WildcardType) ((ParameterizedType) genericFieldType("listOfExtendsNumber")).getActualTypeArguments()[0];
        assertTrue(TypeUtils.equals(extendsNumberBuilt, extendsNumberReflected));
        assertEquals(extendsNumberBuilt.hashCode(), extendsNumberReflected.hashCode());
    }

    // --- wrap ------------------------------------------------------------------

    @Test
    void testWrap() {
        final Typed<String> wrappedClass = TypeUtils.wrap(String.class);
        assertEquals(String.class, wrappedClass.getType());

        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> wrappedType = TypeUtils.wrap((Type) listOfString);
        assertEquals(listOfString, wrappedType.getType());
    }

    // --- deprecated public constructor ------------------------------------------

    @Test
    void testConstructor() {
        assertNotNull(new TypeUtils());
    }
}
