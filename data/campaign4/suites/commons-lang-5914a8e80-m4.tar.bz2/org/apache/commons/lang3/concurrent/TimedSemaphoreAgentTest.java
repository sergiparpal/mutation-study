/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link TimedSemaphore}.
 */
class TimedSemaphoreAgentTest {

    /** A period long enough that the internal timer never fires during a test. */
    private static final long LONG_PERIOD = 1;
    private static final TimeUnit LONG_PERIOD_UNIT = TimeUnit.DAYS;

    @Test
    void testNoLimitConstant() {
        assertEquals(0, TimedSemaphore.NO_LIMIT);
    }

    @Test
    void testDeprecatedConstructorRejectsNonPositivePeriod() {
        assertThrows(IllegalArgumentException.class, () -> new TimedSemaphore(0, TimeUnit.SECONDS, 1));
        assertThrows(IllegalArgumentException.class, () -> new TimedSemaphore(-1, TimeUnit.SECONDS, 1));
    }

    @Test
    void testBuilderRejectsNonPositivePeriod() {
        assertThrows(IllegalArgumentException.class,
                () -> TimedSemaphore.builder().setPeriod(0).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get());
        assertThrows(IllegalArgumentException.class,
                () -> TimedSemaphore.builder().setLimit(1).setTimeUnit(TimeUnit.SECONDS).get());
    }

    @Test
    void testGetPeriodAndUnitFromBuilder() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(5).setTimeUnit(TimeUnit.SECONDS).setLimit(10).get();
        try {
            assertEquals(5, sem.getPeriod());
            assertEquals(TimeUnit.SECONDS, sem.getUnit());
            assertEquals(10, sem.getLimit());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testGetExecutorServiceReturnsSuppliedService() {
        final ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        final TimedSemaphore sem = TimedSemaphore.builder().setService(service).setPeriod(LONG_PERIOD)
                .setTimeUnit(LONG_PERIOD_UNIT).setLimit(1).get();
        try {
            assertEquals(service, sem.getExecutorService());
        } finally {
            sem.shutdown();
            service.shutdownNow();
        }
    }

    @Test
    void testSetLimitAndGetLimit() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 2);
        try {
            assertEquals(2, sem.getLimit());
            sem.setLimit(7);
            assertEquals(7, sem.getLimit());
            sem.setLimit(TimedSemaphore.NO_LIMIT);
            assertEquals(TimedSemaphore.NO_LIMIT, sem.getLimit());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testTryAcquireWithinAndAtLimit() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 2);
        try {
            assertTrue(sem.tryAcquire());
            assertEquals(1, sem.getAcquireCount());
            assertEquals(1, sem.getAvailablePermits());

            assertTrue(sem.tryAcquire());
            assertEquals(2, sem.getAcquireCount());
            assertEquals(0, sem.getAvailablePermits());

            assertFalse(sem.tryAcquire());
            assertEquals(2, sem.getAcquireCount());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testTryAcquireWithNoLimit() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, TimedSemaphore.NO_LIMIT);
        try {
            for (int i = 0; i < 5; i++) {
                assertTrue(sem.tryAcquire());
            }
            assertEquals(5, sem.getAcquireCount());
            assertEquals(-5, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testNegativeLimitActsAsNoLimit() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 2);
        try {
            sem.setLimit(-3);
            for (int i = 0; i < 4; i++) {
                assertTrue(sem.tryAcquire());
            }
            assertEquals(4, sem.getAcquireCount());
            assertEquals(-7, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testEndOfPeriodResetsCounterAndUpdatesStatistics() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 3);
        try {
            assertEquals(0, sem.getAverageCallsPerPeriod(), 0.0001);
            assertEquals(0, sem.getLastAcquiresPerPeriod());

            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            sem.endOfPeriod();

            assertEquals(2, sem.getLastAcquiresPerPeriod());
            assertEquals(0, sem.getAcquireCount());
            assertEquals(2.0, sem.getAverageCallsPerPeriod(), 0.0001);

            assertTrue(sem.tryAcquire());
            sem.endOfPeriod();

            assertEquals(1, sem.getLastAcquiresPerPeriod());
            assertEquals(0, sem.getAcquireCount());
            assertEquals(1.5, sem.getAverageCallsPerPeriod(), 0.0001);
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testIsShutdownAndShutdownIsIdempotent() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 1);
        assertFalse(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
    }

    @Test
    void testShutdownStopsOwnExecutorService() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 1);
        assertTrue(sem.tryAcquire());
        sem.shutdown();
        assertTrue(sem.getExecutorService().isShutdown());
    }

    @Test
    void testShutdownDoesNotStopExternallySuppliedExecutorService() {
        final ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        final TimedSemaphore sem = TimedSemaphore.builder().setService(service).setPeriod(LONG_PERIOD)
                .setTimeUnit(LONG_PERIOD_UNIT).setLimit(1).get();
        try {
            assertTrue(sem.tryAcquire());
            sem.shutdown();
            assertTrue(sem.isShutdown());
            assertFalse(service.isShutdown());
        } finally {
            service.shutdownNow();
        }
    }

    @Test
    void testAcquireAfterShutdownThrows() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 1);
        sem.shutdown();
        assertThrows(IllegalStateException.class, sem::acquire);
    }

    @Test
    void testTryAcquireAfterShutdownThrows() {
        final TimedSemaphore sem = new TimedSemaphore(LONG_PERIOD, LONG_PERIOD_UNIT, 1);
        sem.shutdown();
        assertThrows(IllegalStateException.class, sem::tryAcquire);
    }

    @Test
    void testAcquireBlocksAndIsReleasedWhenPeriodEnds() throws InterruptedException {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(50).setTimeUnit(TimeUnit.MILLISECONDS).setLimit(1).get();
        try {
            sem.acquire();
            assertEquals(1, sem.getAcquireCount());
            assertFalse(sem.tryAcquire());

            final CountDownLatch latch = new CountDownLatch(1);
            final Thread blockedAcquirer = new Thread(() -> {
                try {
                    sem.acquire();
                    latch.countDown();
                } catch (final InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            blockedAcquirer.start();

            assertTrue(latch.await(2, TimeUnit.SECONDS), "second acquire() did not unblock after period rollover");
            blockedAcquirer.join(2000);
            assertFalse(blockedAcquirer.isAlive());
            assertEquals(1, sem.getAcquireCount());
        } finally {
            sem.shutdown();
        }
    }
}
