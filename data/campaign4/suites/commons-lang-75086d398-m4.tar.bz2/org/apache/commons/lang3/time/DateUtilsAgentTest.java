/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar gmtCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date defaultDate(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    // ---------------------------------------------------------------- add*

    @Test
    void testAddDays() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 3);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(31, cal.get(Calendar.DATE));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    @Test
    void testAddDaysNegativeAmount() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        final Date result = DateUtils.addDays(date, -1);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(28, cal.get(Calendar.DATE));
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
    }

    @Test
    void testAddDaysDoesNotMutateOriginal() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final long originalMillis = date.getTime();
        DateUtils.addDays(date, 5);
        assertEquals(originalMillis, date.getTime());
    }

    @Test
    void testAddDaysNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
    }

    @Test
    void testAddHoursAcrossDayBoundary() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 23, 0, 0, 0);
        final Date result = DateUtils.addHours(date, 2);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(29, cal.get(Calendar.DATE));
    }

    @Test
    void testAddMinutes() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 59, 0, 0);
        final Date result = DateUtils.addMinutes(date, 2);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(11, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, cal.get(Calendar.MINUTE));
    }

    @Test
    void testAddSeconds() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 0, 59, 0);
        final Date result = DateUtils.addSeconds(date, 2);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.MINUTE));
        assertEquals(1, cal.get(Calendar.SECOND));
    }

    @Test
    void testAddMilliseconds() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 0, 0, 998);
        final Date result = DateUtils.addMilliseconds(date, 5);
        assertEquals(5, result.getTime() - date.getTime());
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(3, cal.get(Calendar.MILLISECOND));
        assertEquals(1, cal.get(Calendar.SECOND));
    }

    @Test
    void testAddMonths() {
        final Date date = defaultDate(2002, Calendar.JANUARY, 31, 0, 0, 0, 0);
        final Date result = DateUtils.addMonths(date, 1);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        // Calendar normalizes Jan 31 + 1 month to Feb 28 (non-leap year)
        assertEquals(28, cal.get(Calendar.DATE));
    }

    @Test
    void testAddWeeks() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date result = DateUtils.addWeeks(date, 1);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DATE));
    }

    @Test
    void testAddYears() {
        final Date date = defaultDate(2000, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        final Date result = DateUtils.addYears(date, 1);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2001, cal.get(Calendar.YEAR));
        // Calendar.add(YEAR, ...) clamps Feb 29 to Feb 28 in a non-leap year rather than rolling into March
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DATE));
    }

    // ------------------------------------------------------------- ceiling

    @Test
    void testCeilingCalendarHour() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
        assertEquals(0, result.get(Calendar.SECOND));
        assertEquals(0, result.get(Calendar.MILLISECOND));
        assertEquals(28, result.get(Calendar.DATE));
    }

    @Test
    void testCeilingCalendarDoesNotMutateInput() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long originalMillis = cal.getTimeInMillis();
        DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(originalMillis, cal.getTimeInMillis());
    }

    @Test
    void testCeilingCalendarMonth() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(cal, Calendar.MONTH);
        assertEquals(Calendar.APRIL, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DATE));
        assertEquals(0, result.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingObjectDispatchesCalendarAndDate() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        cal.set(Calendar.MILLISECOND, 231);
        final Date fromCal = DateUtils.ceiling((Object) cal, Calendar.HOUR_OF_DAY);
        final Date fromDate = DateUtils.ceiling((Object) cal.getTime(), Calendar.HOUR_OF_DAY);
        assertEquals(fromCal, fromDate);
    }

    @Test
    void testCeilingObjectWrongTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) "not-a-date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingYearTooLargeThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(Calendar.YEAR, 280000001);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DATE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(cal, Calendar.MONTH);
            }
        });
    }

    // --------------------------------------------------------- getFragment*

    @Test
    void testGetFragmentInDaysYear() {
        final Calendar cal = gmtCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(cal, Calendar.YEAR));
        final Date date = defaultDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(date, Calendar.YEAR));
    }

    @Test
    void testGetFragmentInDaysMonth() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInDaysBelowDayIsZero() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 28, 23, 59, 59, 999);
        assertEquals(0, DateUtils.getFragmentInDays(cal, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(cal, Calendar.DAY_OF_YEAR));
        assertEquals(127, DateUtils.getFragmentInHours(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(cal, Calendar.HOUR_OF_DAY));
        // (dayOfMonth - 1) * 24h * 60 + 7h * 60 + 15m = (6-1)*1440 + 420 + 15 = 7635
        assertEquals(7635, DateUtils.getFragmentInMinutes(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
        assertEquals(26110, DateUtils.getFragmentInSeconds(cal, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(cal, Calendar.MINUTE));
        assertEquals(0, DateUtils.getFragmentInMilliseconds(cal, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentUnsupportedThrowsIllegalArgumentException() {
        final Calendar cal = gmtCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testGetFragmentNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
    }

    // ------------------------------------------------------------ isSame*

    @Test
    void testIsSameDayTrueAndFalse() {
        final Calendar cal1 = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = gmtCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Calendar cal3 = gmtCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertFalse(DateUtils.isSameDay(cal1, cal3));

        final Date date1 = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date date2 = defaultDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date date3 = defaultDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(date1, date2));
        assertFalse(DateUtils.isSameDay(date1, date3));
    }

    @Test
    void testIsSameDayNullThrowsNpe() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay(cal, null);
            }
        });
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = new Date(1000L);
        final Date d2 = new Date(1000L);
        final Date d3 = new Date(2000L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));

        final Calendar c1 = Calendar.getInstance(GMT);
        c1.setTimeInMillis(1000L);
        final Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        c2.setTimeInMillis(1000L);
        // isSameInstant compares millis, ignoring the calendar's time zone
        assertTrue(DateUtils.isSameInstant(c1, c2));
    }

    @Test
    void testIsSameInstantNullThrowsNpe() {
        final Date d = new Date();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant(d, null);
            }
        });
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar c1 = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar c2 = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));

        final Calendar c3 = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        c3.clear();
        c3.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        c3.set(Calendar.MILLISECOND, 231);
        // Same field values but different absolute instant since the zone differs,
        // and isSameInstant would be false while isSameLocalTime is true.
        assertTrue(DateUtils.isSameLocalTime(c1, c3));
        assertFalse(DateUtils.isSameInstant(c1, c3));
    }

    @Test
    void testIsSameLocalTimeNullThrowsNpe() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(null, cal);
            }
        });
    }

    // ------------------------------------------------------------ iterator

    @Test
    void testIteratorRangeMonthSunday() {
        // Thursday, July 4, 2002
        final Calendar focus = gmtCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        assertTrue(it.hasNext());
        Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DATE));

        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DATE));
        assertEquals(35, count);
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIteratorRangeWeekSunday() {
        final Calendar focus = gmtCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Calendar first = it.next();
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DATE));
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
        }
        assertEquals(Calendar.JULY, last.get(Calendar.MONTH));
        assertEquals(6, last.get(Calendar.DATE));
    }

    @Test
    void testIteratorDateAndObjectOverloads() {
        final Calendar focus = Calendar.getInstance();
        focus.clear();
        focus.set(2002, Calendar.JULY, 4, 0, 0, 0);
        final Iterator<Calendar> fromCalendar = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Iterator<Calendar> fromDate = DateUtils.iterator(focus.getTime(), DateUtils.RANGE_WEEK_SUNDAY);
        final Iterator<?> fromObjectDate = DateUtils.iterator((Object) focus.getTime(), DateUtils.RANGE_WEEK_SUNDAY);
        final Iterator<?> fromObjectCal = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(fromCalendar.next(), fromDate.next());
        assertEquals(((Calendar) fromObjectDate.next()).getTime(), ((Calendar) fromObjectCal.next()).getTime());
    }

    @Test
    void testIteratorObjectWrongTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) "not-a-date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        final Calendar focus = gmtCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.iterator(focus, -999);
            }
        });
    }

    @Test
    void testIteratorNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorRemoveThrowsUnsupportedOperationException() {
        final Calendar focus = gmtCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    // ------------------------------------------------------------ parseDate

    @Test
    void testParseDateSuccess() throws ParseException {
        final Date result = DateUtils.parseDate("2002-03-28", "yyyy-MM-dd");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DATE));
    }

    @Test
    void testParseDateTriesPatternsInOrder() throws ParseException {
        final Date result = DateUtils.parseDate("28.03.2002", "yyyy-MM-dd", "dd.MM.yyyy");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DATE));
    }

    @Test
    void testParseDateWithLocale() throws ParseException {
        final Date result = DateUtils.parseDate("28.03.2002", Locale.GERMANY, "dd.MM.yyyy");
        assertNotNull(result);
    }

    @Test
    void testParseDateNoPatternMatchesThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("not a date at all", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNoPatternsThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("2002-03-28");
            }
        });
    }

    @Test
    void testParseDateNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("2002-03-28", (String[]) null);
            }
        });
    }

    @Test
    void testParseDateIsLenient() throws ParseException {
        // Day-of-month 32 overflows into February with a lenient parse.
        final Date result = DateUtils.parseDate("32/01/2003", "dd/MM/yyyy");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DATE));
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDateStrictly("32/01/2003", "dd/MM/yyyy");
            }
        });
    }

    @Test
    void testParseDateStrictlySuccess() throws ParseException {
        final Date result = DateUtils.parseDateStrictly("28/01/2003", "dd/MM/yyyy");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(28, cal.get(Calendar.DATE));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }

    @Test
    void testParseDateStrictlyWithLocale() throws ParseException {
        final Date result = DateUtils.parseDateStrictly("28.01.2003", Locale.GERMANY, "dd.MM.yyyy");
        assertNotNull(result);
    }

    // --------------------------------------------------------------- round

    @Test
    void testRoundCalendarHour() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.round(cal, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
    }

    @Test
    void testRoundSemiMonth() {
        assertEquals(1, roundDay(5));
        assertEquals(Calendar.MARCH, roundMonth(5));
        assertEquals(16, roundDay(20));
        assertEquals(Calendar.MARCH, roundMonth(20));
        assertEquals(1, roundDay(28));
        assertEquals(Calendar.APRIL, roundMonth(28));
    }

    private static int roundDay(final int day) {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, day, 10, 0, 0, 0);
        return DateUtils.round(cal, DateUtils.SEMI_MONTH).get(Calendar.DATE);
    }

    private static int roundMonth(final int day) {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, day, 10, 0, 0, 0);
        return DateUtils.round(cal, DateUtils.SEMI_MONTH).get(Calendar.MONTH);
    }

    @Test
    void testRoundObjectDispatch() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        cal.set(Calendar.MILLISECOND, 231);
        final Date fromCal = DateUtils.round((Object) cal, Calendar.HOUR_OF_DAY);
        final Date fromDate = DateUtils.round((Object) cal.getTime(), Calendar.HOUR_OF_DAY);
        assertEquals(fromCal, fromDate);
    }

    @Test
    void testRoundObjectWrongTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) Integer.valueOf(1), Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundUnsupportedFieldThrowsIllegalArgumentException() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testRoundYearTooLargeThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round(cal, Calendar.MONTH);
            }
        });
    }

    // ---------------------------------------------------------------- set*

    @Test
    void testSetDaysValid() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setDays(date, 28);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(28, cal.get(Calendar.DATE));
    }

    @Test
    void testSetDaysInvalidThrowsIllegalArgumentException() {
        // February of a non-leap year has 28 days
        final Date date = defaultDate(2002, Calendar.FEBRUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(date, 30);
            }
        });
    }

    @Test
    void testSetHoursBoundaries() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setHours(date, 23);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(23, cal.get(Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(date, 24);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(date, -1);
            }
        });
    }

    @Test
    void testSetMillisecondsBoundaries() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setMilliseconds(date, 999);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(999, cal.get(Calendar.MILLISECOND));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(date, 1000);
            }
        });
    }

    @Test
    void testSetMinutesBoundaries() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setMinutes(date, 59);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(59, cal.get(Calendar.MINUTE));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(date, 60);
            }
        });
    }

    @Test
    void testSetMonthsBoundaries() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setMonths(date, 11);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(date, 12);
            }
        });
    }

    @Test
    void testSetSecondsBoundaries() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setSeconds(date, 59);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(59, cal.get(Calendar.SECOND));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(date, 60);
            }
        });
    }

    @Test
    void testSetYears() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.setYears(date, 2020);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2020, cal.get(Calendar.YEAR));
    }

    @Test
    void testSetNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(null, 1);
            }
        });
    }

    // ------------------------------------------------------------ toCalendar

    @Test
    void testToCalendar() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = new Date(0L);
        final Calendar cal = DateUtils.toCalendar(date, GMT);
        assertEquals(1970, cal.get(Calendar.YEAR));
        assertEquals(GMT, cal.getTimeZone());
    }

    @Test
    void testToCalendarWithTimeZoneNullDateThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null, GMT);
            }
        });
    }

    // ---------------------------------------------- toLocalDateTime / etc.

    @Test
    void testToLocalDateTime() {
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, GMT);
        assertEquals(1970, ldt.getYear());
        assertEquals(1, ldt.getMonthValue());
        assertEquals(1, ldt.getDayOfMonth());
        assertEquals(0, ldt.getHour());
    }

    @Test
    void testToLocalDateTimeDefaultZone() {
        final Date date = new Date(0L);
        final LocalDateTime withDefault = DateUtils.toLocalDateTime(date);
        final LocalDateTime withExplicitDefault = DateUtils.toLocalDateTime(date, TimeZone.getDefault());
        assertEquals(withExplicitDefault, withDefault);
    }

    @Test
    void testToOffsetDateTime() {
        final Date date = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, GMT);
        assertEquals(1970, odt.getYear());
        assertEquals(0, odt.getOffset().getTotalSeconds());
    }

    @Test
    void testToZonedDateTime() {
        final Date date = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, GMT);
        assertEquals(1970, zdt.getYear());
        assertEquals(date.toInstant(), zdt.toInstant());
    }

    // ------------------------------------------------------------ truncate

    @Test
    void testTruncateCalendarMonth() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.truncate(cal, Calendar.MONTH);
        assertEquals(Calendar.MARCH, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DATE));
        assertEquals(0, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MILLISECOND));
    }

    @Test
    void testTruncateCalendarHour() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
        assertEquals(13, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
    }

    @Test
    void testTruncateObjectDispatch() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        cal.set(Calendar.MILLISECOND, 231);
        final Date fromCal = DateUtils.truncate((Object) cal, Calendar.MONTH);
        final Date fromDate = DateUtils.truncate((Object) cal.getTime(), Calendar.MONTH);
        assertEquals(fromCal, fromDate);
    }

    @Test
    void testTruncateObjectWrongTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) new Object(), Calendar.MONTH);
            }
        });
    }

    @Test
    void testTruncateNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.MONTH);
            }
        });
    }

    @Test
    void testTruncateYearTooLargeThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(cal, Calendar.MONTH);
            }
        });
    }

    // ------------------------------------------------- truncatedCompareTo/Equals

    @Test
    void testTruncatedEqualsAndCompareToSameDayDifferentTime() {
        final Calendar cal1 = gmtCalendar(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Calendar cal2 = gmtCalendar(2002, Calendar.MARCH, 28, 20, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(cal1, cal2, Calendar.DATE));
        assertEquals(0, DateUtils.truncatedCompareTo(cal1, cal2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(cal1.getTime(), cal2.getTime(), Calendar.DATE));
    }

    @Test
    void testTruncatedCompareToOrdering() {
        final Calendar earlier = gmtCalendar(2002, Calendar.MARCH, 27, 23, 0, 0, 0);
        final Calendar later = gmtCalendar(2002, Calendar.MARCH, 28, 1, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.DATE) > 0);
        assertFalse(DateUtils.truncatedEquals(earlier, later, Calendar.DATE));
    }

    @Test
    void testTruncatedCompareToNullThrowsNpe() {
        final Calendar cal = gmtCalendar(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedCompareTo(cal, null, Calendar.DATE);
            }
        });
    }

    // -------------------------------------------------------------- constants

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    void testRangeConstantsAreDistinct() {
        final int[] ranges = {DateUtils.RANGE_WEEK_SUNDAY, DateUtils.RANGE_WEEK_MONDAY, DateUtils.RANGE_WEEK_RELATIVE,
                DateUtils.RANGE_WEEK_CENTER, DateUtils.RANGE_MONTH_SUNDAY, DateUtils.RANGE_MONTH_MONDAY};
        for (int i = 0; i < ranges.length; i++) {
            for (int j = i + 1; j < ranges.length; j++) {
                if (ranges[i] == ranges[j]) {
                    fail("Range constants at " + i + " and " + j + " collide: " + ranges[i]);
                }
            }
        }
    }
}
