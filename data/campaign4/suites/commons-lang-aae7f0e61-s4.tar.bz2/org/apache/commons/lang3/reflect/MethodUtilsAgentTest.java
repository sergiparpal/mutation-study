package org.apache.commons.lang3.reflect;

import org.apache.commons.lang3.ClassUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface MyAnnotation {
    }

    public static class Base {
        @MyAnnotation
        public void baseAnnotated() {
        }

        @MyAnnotation
        private void basePrivateAnnotated() {
        }

        public String foo() {
            return "Base.foo";
        }

        @MyAnnotation
        public void overridableAnnotated() {
        }
    }

    public static class Sample extends Base {
        @MyAnnotation
        public void annotated() {
        }

        @MyAnnotation
        private void privateAnnotated() {
        }

        @Override
        public String foo() {
            return "Sample.foo";
        }

        @Override
        public void overridableAnnotated() {
        }

        public String noArgs() {
            return "noArgs";
        }

        public String echo(String s) {
            return s;
        }

        public String fromInt(int i) {
            return "int:" + i;
        }

        public String concat(String a, String b) {
            return a + b;
        }

        public static String staticNoArgs() {
            return "staticNoArgs";
        }

        public static String staticEcho(String s) {
            return "staticEcho:" + s;
        }

        private String secret() {
            return "secret";
        }

        public void boom() {
            throw new IllegalStateException("boom");
        }
    }

    // ---------- getAccessibleMethod ----------

    @Test
    public void testGetAccessibleMethodByMethod() throws NoSuchMethodException {
        Method m = Sample.class.getMethod("noArgs");
        Method result = MethodUtils.getAccessibleMethod(m);
        assertNotNull(result);
        assertEquals("noArgs", result.getName());
    }

    @Test
    public void testGetAccessibleMethodByMethodNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethodClassAndMethod() throws NoSuchMethodException {
        Method m = Sample.class.getMethod("noArgs");
        Method result = MethodUtils.getAccessibleMethod(Sample.class, m);
        assertNotNull(result);
        assertEquals("noArgs", result.getName());
    }

    @Test
    public void testGetAccessibleMethodClassAndNullMethod() {
        assertNull(MethodUtils.getAccessibleMethod(Sample.class, (Method) null));
    }

    @Test
    public void testGetAccessibleMethodByNameAndParams() {
        Method result = MethodUtils.getAccessibleMethod(Sample.class, "echo", String.class);
        assertNotNull(result);
        assertEquals("echo", result.getName());
    }

    @Test
    public void testGetAccessibleMethodByNameNotFound() {
        Method result = MethodUtils.getAccessibleMethod(Sample.class, "doesNotExist");
        assertNull(result);
    }

    // ---------- getAnnotation ----------

    @Test
    public void testGetAnnotationDirectlyPresent() throws NoSuchMethodException {
        Method m = Sample.class.getMethod("annotated");
        MyAnnotation annotation = MethodUtils.getAnnotation(m, MyAnnotation.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationNotPresentWithoutSearchSupers() throws NoSuchMethodException {
        Method m = Sample.class.getMethod("overridableAnnotated");
        MyAnnotation annotation = MethodUtils.getAnnotation(m, MyAnnotation.class, false, false);
        assertNull(annotation);
    }

    @Test
    public void testGetAnnotationFoundWithSearchSupers() throws NoSuchMethodException {
        Method m = Sample.class.getMethod("overridableAnnotated");
        MyAnnotation annotation = MethodUtils.getAnnotation(m, MyAnnotation.class, true, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, MyAnnotation.class, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotationNullAnnotationClassThrowsNpe() throws NoSuchMethodException {
        final Method m = Sample.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(m, null, false, false);
            }
        });
    }

    // ---------- getMatchingAccessibleMethod ----------

    @Test
    public void testGetMatchingAccessibleMethodWithWrapper() {
        Method result = MethodUtils.getMatchingAccessibleMethod(Sample.class, "fromInt", Integer.class);
        assertNotNull(result);
        assertEquals("fromInt", result.getName());
        assertEquals(int.class, result.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodNotFound() {
        Method result = MethodUtils.getMatchingAccessibleMethod(Sample.class, "doesNotExist");
        assertNull(result);
    }

    // ---------- getMatchingMethod ----------

    @Test
    public void testGetMatchingMethodFindsPrivateMethod() {
        Method result = MethodUtils.getMatchingMethod(Sample.class, "secret");
        assertNotNull(result);
        assertEquals("secret", result.getName());
        assertTrue(Modifier.isPrivate(result.getModifiers()));
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "secret");
            }
        });
    }

    // ---------- getMethodObject ----------

    @Test
    public void testGetMethodObjectFound() {
        Method result = MethodUtils.getMethodObject(Sample.class, "noArgs");
        assertNotNull(result);
        assertEquals("noArgs", result.getName());
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        Method result = MethodUtils.getMethodObject(Sample.class, "doesNotExist");
        assertNull(result);
    }

    // ---------- getMethodsListWithAnnotation (2-arg) ----------

    @Test
    public void testGetMethodsListWithAnnotationTwoArgEmpty() {
        List<Method> result = MethodUtils.getMethodsListWithAnnotation(Object.class, MyAnnotation.class);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotationTwoArgIncludesInheritedPublic() {
        List<Method> result = MethodUtils.getMethodsListWithAnnotation(Sample.class, MyAnnotation.class);
        assertNotNull(result);
        Set<String> names = namesOf(result);
        assertTrue(names.contains("annotated"));
        assertTrue(names.contains("baseAnnotated"));
        assertFalse(names.contains("privateAnnotated"));
        assertEquals(2, result.size());
    }

    @Test
    public void testGetMethodsListWithAnnotationTwoArgNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, MyAnnotation.class);
            }
        });
    }

    @Test
    public void testGetMethodsListWithAnnotationTwoArgNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(Sample.class, null);
            }
        });
    }

    // ---------- getMethodsListWithAnnotation (4-arg) ----------

    @Test
    public void testGetMethodsListWithAnnotationFourArgNoSupersIgnoreAccess() {
        List<Method> result = MethodUtils.getMethodsListWithAnnotation(Sample.class, MyAnnotation.class, false, true);
        Set<String> names = namesOf(result);
        assertTrue(names.contains("annotated"));
        assertTrue(names.contains("privateAnnotated"));
        assertFalse(names.contains("baseAnnotated"));
        assertFalse(names.contains("basePrivateAnnotated"));
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgSupersIgnoreAccess() {
        List<Method> result = MethodUtils.getMethodsListWithAnnotation(Sample.class, MyAnnotation.class, true, true);
        Set<String> names = namesOf(result);
        assertTrue(names.contains("annotated"));
        assertTrue(names.contains("privateAnnotated"));
        assertTrue(names.contains("baseAnnotated"));
        assertTrue(names.contains("basePrivateAnnotated"));
        assertEquals(4, result.size());
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgSupersNoIgnoreAccess() {
        List<Method> result = MethodUtils.getMethodsListWithAnnotation(Sample.class, MyAnnotation.class, true, false);
        Set<String> names = namesOf(result);
        assertTrue(names.contains("annotated"));
        assertTrue(names.contains("baseAnnotated"));
        assertFalse(names.contains("privateAnnotated"));
        assertFalse(names.contains("basePrivateAnnotated"));
        assertEquals(2, result.size());
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, MyAnnotation.class, true, true);
            }
        });
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(Sample.class, null, true, true);
            }
        });
    }

    // ---------- getMethodsWithAnnotation (array variants) ----------

    @Test
    public void testGetMethodsWithAnnotationTwoArg() {
        Method[] result = MethodUtils.getMethodsWithAnnotation(Sample.class, MyAnnotation.class);
        assertNotNull(result);
        Set<String> names = namesOf(result);
        assertTrue(names.contains("annotated"));
        assertTrue(names.contains("baseAnnotated"));
        assertEquals(2, result.length);
    }

    @Test
    public void testGetMethodsWithAnnotationTwoArgEmpty() {
        Method[] result = MethodUtils.getMethodsWithAnnotation(Object.class, MyAnnotation.class);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testGetMethodsWithAnnotationTwoArgNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsWithAnnotation(null, MyAnnotation.class);
            }
        });
    }

    @Test
    public void testGetMethodsWithAnnotationFourArgSupersIgnoreAccess() {
        Method[] result = MethodUtils.getMethodsWithAnnotation(Sample.class, MyAnnotation.class, true, true);
        assertNotNull(result);
        Set<String> names = namesOf(result);
        assertTrue(names.contains("annotated"));
        assertTrue(names.contains("privateAnnotated"));
        assertTrue(names.contains("baseAnnotated"));
        assertTrue(names.contains("basePrivateAnnotated"));
        assertEquals(4, result.length);
    }

    @Test
    public void testGetMethodsWithAnnotationFourArgNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsWithAnnotation(Sample.class, null, true, true);
            }
        });
    }

    // ---------- getOverrideHierarchy ----------

    @Test
    public void testGetOverrideHierarchyAscendingOrder() throws NoSuchMethodException {
        Method m = Sample.class.getMethod("foo");
        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, ClassUtils.Interfaces.EXCLUDE);
        assertNotNull(hierarchy);
        assertEquals(2, hierarchy.size());
        Iterator<Method> it = hierarchy.iterator();
        assertEquals(Sample.class, it.next().getDeclaringClass());
        assertEquals(Base.class, it.next().getDeclaringClass());
    }

    @Test
    public void testGetOverrideHierarchyNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, ClassUtils.Interfaces.EXCLUDE);
            }
        });
    }

    // ---------- invokeExactMethod ----------

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Sample(), "noArgs");
        assertEquals("noArgs", result);
    }

    @Test
    public void testInvokeExactMethodVarArgs() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Sample(), "echo", "hi");
        assertEquals("hi", result);
    }

    @Test
    public void testInvokeExactMethodWithParameterTypes() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Sample(), "concat",
                new Object[] {"a", "b"}, new Class[] {String.class, String.class});
        assertEquals("ab", result);
    }

    @Test
    public void testInvokeExactMethodNoWrapperMatchThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeExactMethod(new Sample(), "fromInt", Integer.valueOf(5));
            }
        });
    }

    @Test
    public void testInvokeExactMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeExactMethod(null, "noArgs");
            }
        });
    }

    @Test
    public void testInvokeExactMethodPropagatesInvocationTarget() {
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeExactMethod(new Sample(), "boom");
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    // ---------- invokeExactStaticMethod ----------

    @Test
    public void testInvokeExactStaticMethodNoArgs() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Sample.class, "staticNoArgs");
        assertEquals("staticNoArgs", result);
    }

    @Test
    public void testInvokeExactStaticMethodVarArgs() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Sample.class, "staticEcho", "yo");
        assertEquals("staticEcho:yo", result);
    }

    @Test
    public void testInvokeExactStaticMethodWithParameterTypes() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Sample.class, "staticEcho",
                new Object[] {"z"}, new Class[] {String.class});
        assertEquals("staticEcho:z", result);
    }

    // ---------- invokeMethod ----------

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        Object result = MethodUtils.invokeMethod(new Sample(), "noArgs");
        assertEquals("noArgs", result);
    }

    @Test
    public void testInvokeMethodVarArgsWithPrimitiveWrapperMatch() throws Exception {
        Object result = MethodUtils.invokeMethod(new Sample(), "fromInt", Integer.valueOf(7));
        assertEquals("int:7", result);
    }

    @Test
    public void testInvokeMethodWithParameterTypes() throws Exception {
        Object result = MethodUtils.invokeMethod(new Sample(), "concat",
                new Object[] {"a", "b"}, new Class[] {String.class, String.class});
        assertEquals("ab", result);
    }

    @Test
    public void testInvokeMethodPrivateWithoutForceAccessThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeMethod(new Sample(), false, "secret");
            }
        });
    }

    @Test
    public void testInvokeMethodPrivateWithForceAccess() throws Exception {
        Object result = MethodUtils.invokeMethod(new Sample(), true, "secret");
        assertEquals("secret", result);
    }

    @Test
    public void testInvokeMethodForceAccessWithParameterTypes() throws Exception {
        Object result = MethodUtils.invokeMethod(new Sample(), true, "concat",
                new Object[] {"x", "y"}, new Class[] {String.class, String.class});
        assertEquals("xy", result);
    }

    @Test
    public void testInvokeMethodVarArgsNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeMethod(null, "echo", "x");
            }
        });
    }

    // ---------- invokeStaticMethod ----------

    @Test
    public void testInvokeStaticMethodVarArgs() throws Exception {
        Object result = MethodUtils.invokeStaticMethod(Sample.class, "staticEcho", "world");
        assertEquals("staticEcho:world", result);
    }

    @Test
    public void testInvokeStaticMethodWithParameterTypes() throws Exception {
        Object result = MethodUtils.invokeStaticMethod(Sample.class, "staticEcho",
                new Object[] {"q"}, new Class[] {String.class});
        assertEquals("staticEcho:q", result);
    }

    @Test
    public void testInvokeStaticMethodNotFoundThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeStaticMethod(Sample.class, "doesNotExist");
            }
        });
    }

    // ---------- helpers ----------

    private static Set<String> namesOf(List<Method> methods) {
        Set<String> names = new HashSet<String>();
        for (Method m : methods) {
            names.add(m.getName());
        }
        return names;
    }

    private static Set<String> namesOf(Method[] methods) {
        Set<String> names = new HashSet<String>();
        for (Method m : methods) {
            names.add(m.getName());
        }
        return names;
    }
}
