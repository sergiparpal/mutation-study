/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    @Test
    void testParseBasicDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date date = parser.parse("2023-06-15");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsParseExceptionOnMismatch() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("2023/06/15");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertEquals(4, ex.getErrorOffset());
    }

    @Test
    void testParseWithParsePositionReturnsNullAndSetsErrorIndexOnShortInput() {
        final FastDateParser parser = new FastDateParser("MM/dd/yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("03/23", pos);
        assertNull(date);
        assertEquals(5, pos.getErrorIndex());
    }

    @Test
    void testParseWithParsePositionDoesNotConsumeTrailingInput() {
        final FastDateParser parser = new FastDateParser("MM/dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("3/23/61", pos);
        assertNotNull(date);
        assertEquals(4, pos.getIndex());
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParsePositionPastEndOfSourceFails() {
        final FastDateParser parser = new FastDateParser("MM/dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(20);
        final Date date = parser.parse("3/23", pos);
        assertNull(date);
        assertEquals(20, pos.getErrorIndex());
    }

    @Test
    void testParseIntoCalendarReturnsBooleanAndUpdatesFields() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("2024-01-05", pos, cal);
        assertTrue(success);
        assertEquals(10, pos.getIndex());
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseIntoCalendarFailureLeavesErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("xxxx-01-05", pos, cal);
        assertFalse(success);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testGetters() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(UTC, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final TimeZone myZone = TimeZone.getTimeZone("America/New_York");
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", myZone, Locale.US);
        final TimeZone returned = parser.getTimeZone();
        assertEquals(myZone, returned);
        assertNotEquals(TimeZone.getTimeZone("UTC"), returned);
    }

    @Test
    void testNullLocaleMapsToDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser diffPattern = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);
        final FastDateParser diffLocale = new FastDateParser("yyyy-MM-dd", UTC, Locale.FRANCE);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffLocale);
        assertNotEquals(a, diffZone);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a parser");
        assertEquals(a, a);
    }

    @Test
    void testToStringContainsPatternLocaleAndZoneId() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String str = parser.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("UTC"));
    }

    @Test
    void testToStringAllContainsPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String str = parser.toStringAll();
        assertTrue(str.contains("pattern=yyyy-MM-dd"));
    }

    @Test
    void testGetPatternsCountsTokens() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(5, parser.getPatterns().size());
    }

    @Test
    void testTwoDigitYearAdjustmentBelowStartYearRollsToNextCentury() throws ParseException {
        final Calendar centuryStartCal = Calendar.getInstance(UTC, Locale.US);
        centuryStartCal.clear();
        centuryStartCal.set(1950, Calendar.JUNE, 15);
        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStartCal.getTime());
        final Date date = parser.parse("30");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(2030, cal.get(Calendar.YEAR));
    }

    @Test
    void testTwoDigitYearAdjustmentAboveOrEqualStartYearStaysInCentury() throws ParseException {
        final Calendar centuryStartCal = Calendar.getInstance(UTC, Locale.US);
        centuryStartCal.clear();
        centuryStartCal.set(1950, Calendar.JUNE, 15);
        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStartCal.getTime());
        final Date date = parser.parse("60");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(1960, cal.get(Calendar.YEAR));
    }

    @Test
    void testFullMonthNameParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", UTC, Locale.US);
        final Date date = parser.parse("June 15, 2023");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAbbreviatedMonthNameParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMM d, yyyy", UTC, Locale.US);
        final Date date = parser.parse("Jun 15, 2023");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
    }

    @Test
    void testInvalidTextFieldValueFailsToParse() {
        final FastDateParser parser = new FastDateParser("EEEE, MM/dd/yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Notaday, 03/23/1961", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testIso8601ExtendedTimeZoneOffsetParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZZZ", UTC, Locale.US);
        final Date date = parser.parse("2023-06-15T10:30:00+05:30");
        final Calendar expected = Calendar.getInstance(TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        expected.clear();
        expected.set(2023, Calendar.JUNE, 15, 10, 30, 0);
        assertEquals(expected.getTime(), date);
    }

    @Test
    void testRfc822TimeZoneOffsetParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZ", UTC, Locale.US);
        final Date date = parser.parse("2023-06-15T10:30:00-0500");
        final Calendar expected = Calendar.getInstance(TimeZone.getTimeZone("GMT-05:00"), Locale.US);
        expected.clear();
        expected.set(2023, Calendar.JUNE, 15, 10, 30, 0);
        assertEquals(expected.getTime(), date);
    }

    @Test
    void testWeekYearPatternResolvesViaSetWeekDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", UTC, Locale.US);
        final Date date = parser.parse("2023-W24-4");
        final Calendar expected = Calendar.getInstance(UTC, Locale.US);
        expected.clear();
        expected.setWeekDate(2023, 24, Calendar.THURSDAY);
        assertEquals(expected.getTime(), date);
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd A", UTC, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy'bad", UTC, Locale.US);
            }
        });
        assertEquals("Unterminated quote", ex.getMessage());
    }

    @Test
    void testInvalidIsoWidthThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-ddXXXX", UTC, Locale.US);
            }
        });
        assertEquals("Invalid number of X", ex.getMessage());
    }

    @Test
    void testIntegerOverflowDigitRunFailsGracefully() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testJapaneseImperialLocaleParseFailureMessage() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("abcd-01-01");
            }
        });
        assertTrue(ex.getMessage().contains("does not support dates before 1868-01-01"));
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object obj = parser.parseObject("2023-06-15");
        assertTrue(obj instanceof Date);
        assertEquals(parser.parse("2023-06-15"), obj);
    }

    @Test
    void testParseObjectWithPositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj = parser.parseObject("2023-06-15", pos);
        assertNotNull(obj);
        assertTrue(obj instanceof Date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testLenientOverflowMinutesRollIntoHours() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm", UTC, Locale.US);
        final Date date = parser.parse("2023-06-15 10:90");
        final GregorianCalendar expected = new GregorianCalendar(UTC, Locale.US);
        expected.clear();
        expected.set(2023, Calendar.JUNE, 15, 11, 30);
        assertEquals(expected.getTime(), date);
    }
}
