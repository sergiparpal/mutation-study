/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link AnnotationUtils}.
 */
public class AnnotationUtilsAgentTest {

    enum Color {
        RED, BLUE
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface Nested {
        int num();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface Simple {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface Complex {
        String name();
        int[] numbers();
        Color color();
        Class<?> type();
        Nested nested();
    }

    @Simple("red")
    static class SimpleHolder1 {
    }

    @Simple("red")
    static class SimpleHolder2 {
    }

    @Simple("blue")
    static class SimpleHolder3 {
    }

    @Complex(name = "foo", numbers = {1, 2, 3}, color = Color.RED, type = String.class, nested = @Nested(num = 5))
    static class ComplexHolder1 {
    }

    @Complex(name = "foo", numbers = {1, 2, 3}, color = Color.RED, type = String.class, nested = @Nested(num = 5))
    static class ComplexHolder2 {
    }

    @Complex(name = "bar", numbers = {1, 2, 3}, color = Color.RED, type = String.class, nested = @Nested(num = 5))
    static class ComplexHolder3 {
    }

    @Complex(name = "foo", numbers = {1, 2, 9}, color = Color.RED, type = String.class, nested = @Nested(num = 5))
    static class ComplexHolder4 {
    }

    @Complex(name = "foo", numbers = {1, 2, 3}, color = Color.RED, type = String.class, nested = @Nested(num = 99))
    static class ComplexHolder5 {
    }

    /**
     * Implements the {@link Simple} annotation interface directly (not via a
     * dynamic proxy) so {@link Annotation#annotationType()} can be made to
     * return {@code null}, exercising the defensive null check in
     * {@link AnnotationUtils#equals(Annotation, Annotation)}.
     */
    static final class NullTypeSimple implements Simple {

        @Override
        public Class<? extends Annotation> annotationType() {
            return null;
        }

        @Override
        public String value() {
            return "red";
        }
    }

    private Simple simple(final Class<?> c) {
        return c.getAnnotation(Simple.class);
    }

    private Complex complex(final Class<?> c) {
        return c.getAnnotation(Complex.class);
    }

    @Test
    public void testEqualsSameInstance() {
        final Simple a = simple(SimpleHolder1.class);
        assertTrue(AnnotationUtils.equals(a, a));
    }

    @Test
    public void testEqualsBothNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    public void testEqualsOneNull() {
        final Simple a = simple(SimpleHolder1.class);
        assertFalse(AnnotationUtils.equals(a, null));
        assertFalse(AnnotationUtils.equals(null, a));
    }

    @Test
    public void testEqualsEqualValuesDifferentInstances() {
        final Simple a = simple(SimpleHolder1.class);
        final Simple b = simple(SimpleHolder2.class);
        assertNotNull(a);
        assertNotNull(b);
        assertTrue(a != b);
        assertTrue(AnnotationUtils.equals(a, b));
        assertTrue(AnnotationUtils.equals(b, a));
    }

    @Test
    public void testEqualsDifferentValues() {
        final Simple a = simple(SimpleHolder1.class);
        final Simple c = simple(SimpleHolder3.class);
        assertFalse(AnnotationUtils.equals(a, c));
    }

    @Test
    public void testEqualsDifferentAnnotationTypes() {
        final Simple a = simple(SimpleHolder1.class);
        final Complex c = complex(ComplexHolder1.class);
        assertFalse(AnnotationUtils.equals(a, c));
        assertFalse(AnnotationUtils.equals(c, a));
    }

    @Test
    public void testEqualsComplexEqualMembersArraysAndNested() {
        final Complex c1 = complex(ComplexHolder1.class);
        final Complex c2 = complex(ComplexHolder2.class);
        assertTrue(AnnotationUtils.equals(c1, c2));
    }

    @Test
    public void testEqualsComplexDifferentStringMember() {
        final Complex c1 = complex(ComplexHolder1.class);
        final Complex c3 = complex(ComplexHolder3.class);
        assertFalse(AnnotationUtils.equals(c1, c3));
    }

    @Test
    public void testEqualsComplexDifferentArrayMember() {
        final Complex c1 = complex(ComplexHolder1.class);
        final Complex c4 = complex(ComplexHolder4.class);
        assertFalse(AnnotationUtils.equals(c1, c4));
    }

    @Test
    public void testEqualsComplexDifferentNestedAnnotationMember() {
        final Complex c1 = complex(ComplexHolder1.class);
        final Complex c5 = complex(ComplexHolder5.class);
        assertFalse(AnnotationUtils.equals(c1, c5));
    }

    @Test
    public void testEqualsThrowsNullPointerExceptionWhenAnnotationTypeIsNull() {
        final Simple fake = new NullTypeSimple();
        final Simple real = simple(SimpleHolder1.class);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                AnnotationUtils.equals(fake, real);
            }
        });
    }

    @Test
    public void testHashCodeEqualForEqualAnnotations() {
        final Simple a = simple(SimpleHolder1.class);
        final Simple b = simple(SimpleHolder2.class);
        assertEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(b));
    }

    @Test
    public void testHashCodeStableAcrossCalls() {
        final Complex c1 = complex(ComplexHolder1.class);
        assertEquals(AnnotationUtils.hashCode(c1), AnnotationUtils.hashCode(c1));
    }

    @Test
    public void testHashCodeDifferentForDifferentValues() {
        final Simple a = simple(SimpleHolder1.class);
        final Simple c = simple(SimpleHolder3.class);
        assertNotEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(c));
    }

    @Test
    public void testHashCodeComplexEqualForEqualComplexAnnotations() {
        final Complex c1 = complex(ComplexHolder1.class);
        final Complex c2 = complex(ComplexHolder2.class);
        assertEquals(AnnotationUtils.hashCode(c1), AnnotationUtils.hashCode(c2));
    }

    @Test
    public void testIsValidAnnotationMemberTypeNull() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    public void testIsValidAnnotationMemberTypePrimitives() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(boolean.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(double.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeStringAndClass() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeEnum() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Color.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Simple.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeArrayOfValidComponent() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Simple[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeInvalidType() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(java.util.List.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeArrayOfInvalidComponent() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
    }

    @Test
    public void testToStringNotNullAndContainsAnnotationNameAndMember() {
        final Simple a = simple(SimpleHolder1.class);
        final String s = AnnotationUtils.toString(a);
        assertNotNull(s);
        assertTrue(s.contains(Simple.class.getName()));
        assertTrue(s.contains("value=red"));
    }

    @Test
    public void testToStringEqualForEqualAnnotations() {
        final Simple a = simple(SimpleHolder1.class);
        final Simple b = simple(SimpleHolder2.class);
        assertEquals(AnnotationUtils.toString(a), AnnotationUtils.toString(b));
    }

    @Test
    public void testToStringDifferentForDifferentValues() {
        final Simple a = simple(SimpleHolder1.class);
        final Simple c = simple(SimpleHolder3.class);
        assertNotEquals(AnnotationUtils.toString(a), AnnotationUtils.toString(c));
    }

    @Test
    public void testToStringComplexContainsNestedAnnotationAndArray() {
        final Complex c1 = complex(ComplexHolder1.class);
        final String s = AnnotationUtils.toString(c1);
        assertNotNull(s);
        assertTrue(s.contains("name=foo"));
        assertTrue(s.contains("nested="));
        assertTrue(s.contains("num=5"));
    }

    @Test
    public void testConstructorIsPublicAndInstantiable() {
        final AnnotationUtils instance = new AnnotationUtils();
        assertNotNull(instance);
    }
}
