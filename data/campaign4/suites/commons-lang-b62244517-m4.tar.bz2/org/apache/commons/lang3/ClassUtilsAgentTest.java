/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private interface AgentInterfaceA {
        // marker
    }

    private interface AgentInterfaceB extends AgentInterfaceA {
        // marker
    }

    private static class AgentSuper implements AgentInterfaceB {
        // marker
    }

    private static class AgentChild extends AgentSuper {
        // marker
    }

    private static class AgentOuter {
        class AgentInner {
            // marker
        }
    }

    // comparator()

    @Test
    public void testComparatorOrdersByName() {
        final List<Class<?>> classes = new ArrayList<Class<?>>(Arrays.asList(String.class, Integer.class, Boolean.class));
        classes.sort(ClassUtils.comparator());
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), classes);
    }

    // convertClassesToClassNames / convertClassNamesToClasses

    @Test
    public void testConvertClassesToClassNamesNullInput() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNamesWithNullElement() {
        final List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        final List<String> result = ClassUtils.convertClassesToClassNames(input);
        assertEquals(Arrays.asList("java.lang.String", null), result);
    }

    @Test
    public void testConvertClassNamesToClassesNullInput() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClassesUnknownAndNull() {
        final List<String> input = new ArrayList<String>();
        input.add("java.lang.String");
        input.add("org.apache.commons.lang3.DoesNotExistXYZ");
        input.add(null);
        final List<Class<?>> result = ClassUtils.convertClassNamesToClasses(input);
        assertEquals(3, result.size());
        assertSame(String.class, result.get(0));
        assertNull(result.get(1));
        assertNull(result.get(2));
    }

    // getAbbreviatedName

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameLengthZeroThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameLengthNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameVariants() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
        assertEquals("String", ClassUtils.getAbbreviatedName("String", 1));
    }

    @Test
    public void testGetAbbreviatedNameClassOverload() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    // getAllInterfaces

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfacesOrderAndContent() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertEquals(2, interfaces.size());
        assertEquals(AgentInterfaceB.class, interfaces.get(0));
        assertEquals(AgentInterfaceA.class, interfaces.get(1));
    }

    @Test
    public void testGetAllInterfacesNoInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Object.class);
        assertTrue(interfaces.isEmpty());
    }

    // getAllSuperclasses

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclassesOrder() {
        final List<Class<?>> supers = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentSuper.class, Object.class), supers);
    }

    @Test
    public void testGetAllSuperclassesOfObject() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    // getCanonicalName

    @Test
    public void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetCanonicalNameClassWithDefault() {
        assertEquals("fallback", ClassUtils.getCanonicalName((Class<?>) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "fallback"));
    }

    @Test
    public void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("fallback", ClassUtils.getCanonicalName((Object) null, "fallback"));
    }

    @Test
    public void testGetCanonicalNameObjectNonNull() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hi", "fallback"));
    }

    // getClass(classLoader/thread-context, className[, initialize])

    @Test
    public void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassPrimitive() throws ClassNotFoundException {
        assertSame(int.class, ClassUtils.getClass("int"));
    }

    @Test
    public void testGetClassSimpleName() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    public void testGetClassArraySyntaxes() throws ClassNotFoundException {
        assertSame(int[].class, ClassUtils.getClass("int[]"));
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertSame(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassInnerClassDotSyntax() throws ClassNotFoundException {
        assertSame(AgentOuter.AgentInner.class, ClassUtils.getClass(
                "org.apache.commons.lang3.ClassUtilsAgentTest.AgentOuter.AgentInner"));
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("does.not.Exist");
            }
        });
    }

    @Test
    public void testGetClassWithExplicitLoader() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertSame(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertSame(String.class, ClassUtils.getClass(loader, "java.lang.String", false));
    }

    @Test
    public void testGetClassLongNameNoStackOverflow() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5000; i++) {
            sb.append("a.");
        }
        sb.append("b");
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(sb.toString());
            }
        });
    }

    // getComponentType

    @Test
    public void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetComponentTypeArray() {
        assertSame(String.class, ClassUtils.getComponentType(String[].class));
    }

    // getName

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getName((Class<?>) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("fallback", ClassUtils.getName((Object) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
        assertEquals("java.lang.String", ClassUtils.getName("hi", "fallback"));
    }

    // getPackageCanonicalName

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObject() {
        assertEquals("fallback", ClassUtils.getPackageCanonicalName((Object) null, "fallback"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hi", "fallback"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    // getPackageName

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObject() {
        assertEquals("fallback", ClassUtils.getPackageName((Object) null, "fallback"));
        assertEquals("java.lang", ClassUtils.getPackageName("hi", "fallback"));
    }

    @Test
    public void testGetPackageNameStringEmptyAndNoPackage() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("NoPackageClass"));
    }

    @Test
    public void testGetPackageNameStringArrayAndObjectEncoding() {
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    // getPublicMethod

    @Test
    public void testGetPublicMethodFound() throws Exception {
        final java.lang.reflect.Method m = ClassUtils.getPublicMethod(AgentChild.class, "toString");
        assertEquals("toString", m.getName());
        assertTrue(ClassUtils.isPublic(m.getDeclaringClass()));
    }

    @Test
    public void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(AgentChild.class, "doesNotExistMethod");
            }
        });
    }

    @Test
    public void testGetPublicMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "toString");
            }
        });
    }

    // getShortCanonicalName

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
    }

    @Test
    public void testGetShortCanonicalNameObject() {
        assertEquals("fallback", ClassUtils.getShortCanonicalName((Object) null, "fallback"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hi", "fallback"));
    }

    @Test
    public void testGetShortCanonicalNameStringArrays() {
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
    }

    // getShortClassName

    @Test
    public void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    public void testGetShortClassNameClassSimple() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("fallback", ClassUtils.getShortClassName((Object) null, "fallback"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "fallback"));
    }

    @Test
    public void testGetShortClassNameStringNullAndEmpty() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    public void testGetShortClassNameStringInnerClass() {
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    @Test
    public void testGetShortClassNameStringArrayEncoded() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("int[][]", ClassUtils.getShortClassName("[[I"));
    }

    // getSimpleName

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Class<?>) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Object) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
        assertEquals("String", ClassUtils.getSimpleName("hi", "fallback"));
    }

    // hierarchy

    @Test
    public void testHierarchyExcludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(AgentChild.class);
        final List<Class<?>> result = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        assertEquals(Arrays.asList(AgentChild.class, AgentSuper.class, Object.class), result);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE);
        final List<Class<?>> result = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        assertTrue(result.contains(AgentChild.class));
        assertTrue(result.contains(AgentSuper.class));
        assertTrue(result.contains(Object.class));
        assertTrue(result.contains(AgentInterfaceA.class));
        assertTrue(result.contains(AgentInterfaceB.class));
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        it.next();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                it.remove();
            }
        });
    }

    // isAssignable

    @Test
    public void testIsAssignableNullToClassFalse() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
    }

    @Test
    public void testIsAssignableNullClassToNonPrimitiveTrue() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, String.class));
    }

    @Test
    public void testIsAssignableNullClassToPrimitiveFalse() {
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
    }

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, float.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableSameClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
    }

    @Test
    public void testIsAssignableReferenceHierarchy() {
        assertTrue(ClassUtils.isAssignable(AgentChild.class, AgentSuper.class));
        assertFalse(ClassUtils.isAssignable(AgentSuper.class, AgentChild.class));
    }

    @Test
    public void testIsAssignableArraysBothNullTrue() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsAssignableArraysDifferentLengthFalse() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, Integer.class}));
    }

    @Test
    public void testIsAssignableArraysMatching() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {int.class, String.class}, new Class<?>[] {Integer.class, Object.class}));
    }

    @Test
    public void testIsAssignableArraysNonMatching() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {Integer.class}));
    }

    // isInnerClass

    @Test
    public void testIsInnerClassNullFalse() {
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    public void testIsInnerClassTopLevelFalse() {
        assertFalse(ClassUtils.isInnerClass(String.class));
    }

    @Test
    public void testIsInnerClassNestedTrue() {
        assertTrue(ClassUtils.isInnerClass(AgentOuter.AgentInner.class));
    }

    // isPrimitiveOrWrapper / isPrimitiveWrapper

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    // isPublic

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentChild.class));
    }

    @Test
    public void testIsPublicNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    // primitivesToWrappers / primitiveToWrapper

    @Test
    public void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    public void testPrimitivesToWrappersEmpty() {
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.primitivesToWrappers(empty));
    }

    @Test
    public void testPrimitivesToWrappersMixed() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(3, result.length);
        assertSame(Integer.class, result[0]);
        assertSame(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertSame(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertSame(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    // toClass

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        final Class<?>[] result = ClassUtils.toClass();
        assertEquals(0, result.length);
    }

    @Test
    public void testToClassMixedWithNull() {
        final Class<?>[] result = ClassUtils.toClass("a", Integer.valueOf(1), null);
        assertEquals(3, result.length);
        assertSame(String.class, result[0]);
        assertSame(Integer.class, result[1]);
        assertNull(result[2]);
    }

    // wrappersToPrimitives / wrapperToPrimitive

    @Test
    public void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    public void testWrappersToPrimitivesEmpty() {
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.wrappersToPrimitives(empty));
    }

    @Test
    public void testWrappersToPrimitivesMixed() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(3, result.length);
        assertSame(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertSame(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    // constructor is public, deprecated, but instantiable

    @Test
    public void testPublicConstructor() {
        assertTrue(new ClassUtils() instanceof ClassUtils);
    }

    /**
     * Minimal stand-in for {@code org.junit.jupiter.api.function.Executable} usage via anonymous classes,
     * avoiding lambda syntax per project constraints.
     */
    private interface Executable extends org.junit.jupiter.api.function.Executable {
        // marker, inherits execute()
    }
}
