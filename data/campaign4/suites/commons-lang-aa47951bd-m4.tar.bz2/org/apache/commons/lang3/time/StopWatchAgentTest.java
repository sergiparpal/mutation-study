/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link StopWatch}.
 */
class StopWatchAgentTest {

    private static void busyWaitMillis(final long millis) {
        final long start = System.nanoTime();
        final long target = millis * 1_000_000L;
        while (System.nanoTime() - start < target) {
            // busy wait
        }
    }

    @Test
    void testCreate() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertNull(watch.getMessage());
    }

    @Test
    void testCreateStarted() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testConstructorWithMessage() {
        final StopWatch watch = new StopWatch("myMessage");
        assertEquals("myMessage", watch.getMessage());
        final StopWatch watchNoMessage = new StopWatch();
        assertNull(watchNoMessage.getMessage());
    }

    @Test
    void testInitialState() {
        final StopWatch watch = new StopWatch();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
        assertEquals(Duration.ZERO, watch.getDuration());
        assertTrue(watch.getSplits().isEmpty());
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::start);
        assertEquals("Stopwatch already started.", e.getMessage());
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::start);
        assertEquals("Stopwatch must be reset before being restarted.", e.getMessage());
    }

    @Test
    void testStartAfterResetSucceeds() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    void testStopWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::stop);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testStopTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::stop);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testStopThenGetTimeStable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        busyWaitMillis(5);
        watch.stop();
        final long time1 = watch.getTime();
        busyWaitMillis(5);
        final long time2 = watch.getTime();
        assertEquals(time1, time2);
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
    }

    @Test
    void testSuspendWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::suspend);
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::suspend);
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::resume);
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    void testResumeOnUnstartedThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::resume);
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    void testSuspendResumeExcludesSuspendedTime() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        busyWaitMillis(10);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedTime = watch.getTime();
        Thread.sleep(50);
        // time must not advance while suspended
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        busyWaitMillis(5);
        watch.stop();
        assertTrue(watch.getTime() >= suspendedTime);
    }

    @Test
    void testSplitWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::split);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getSplitTime);
        assertEquals("Stopwatch must be split to get the split time.", e.getMessage());
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::unsplit);
        assertEquals("Stopwatch has not been split.", e.getMessage());
    }

    @Test
    void testSplitAndUnsplit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        busyWaitMillis(5);
        watch.split();
        final long splitTime = watch.getSplitTime();
        assertTrue(splitTime >= 0);
        assertEquals(1, watch.getSplits().size());
        final StopWatch.Split split = watch.getSplits().get(0);
        assertEquals("0", split.getLabel());
        assertNotNull(split.getDuration());
        watch.unsplit();
        assertTrue(watch.getSplits().isEmpty());
        // after unsplit, getSplitTime should fail again
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        assertEquals(1, watch.getSplits().size());
        assertEquals("first", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testSplitTwiceAccumulates() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        watch.unsplit();
        watch.split("b");
        assertEquals(1, watch.getSplits().size());
        assertEquals("b", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testGetSplitsIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testResetClearsSplitsAndState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.reset();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getSplits().isEmpty());
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    void testGetStartInstantWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getStartInstant);
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    void testGetStopInstantWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getStopInstant);
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    void testGetStartAndStopInstant() {
        final StopWatch watch = new StopWatch();
        final Instant before = Instant.now();
        watch.start();
        busyWaitMillis(2);
        watch.stop();
        final Instant after = Instant.now();
        final Instant start = watch.getStartInstant();
        final Instant stop = watch.getStopInstant();
        assertNotNull(start);
        assertNotNull(stop);
        assertFalse(start.isBefore(before.minusMillis(1)));
        assertFalse(stop.isAfter(after.plusMillis(1)));
        assertFalse(stop.isBefore(start));
        assertEquals(start.toEpochMilli(), watch.getStartTime());
        assertEquals(stop.toEpochMilli(), watch.getStopTime());
    }

    @Test
    void testGetTimeTimeUnitConversion() {
        final StopWatch watch = new StopWatch();
        watch.start();
        busyWaitMillis(5);
        watch.stop();
        final long millis = watch.getTime();
        assertEquals(millis, watch.getTime(TimeUnit.MILLISECONDS));
        assertEquals(TimeUnit.MILLISECONDS.toSeconds(millis), watch.getTime(TimeUnit.SECONDS));
        assertTrue(watch.getTime(TimeUnit.NANOSECONDS) >= watch.getNanoTime() - 1);
    }

    @Test
    void testGetDurationMatchesGetTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        busyWaitMillis(3);
        watch.stop();
        assertEquals(watch.getNanoTime(), watch.getDuration().toNanos());
        assertEquals(watch.getTime(), watch.getDuration().toMillis());
    }

    @Test
    void testToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String str = watch.toString();
        assertNotNull(str);
        assertFalse(str.startsWith(" "));
    }

    @Test
    void testToStringWithMessage() {
        final StopWatch watch = new StopWatch("label");
        watch.start();
        watch.stop();
        final String str = watch.toString();
        assertTrue(str.startsWith("label "));
    }

    @Test
    void testToSplitStringWithMessage() {
        final StopWatch watch = new StopWatch("label");
        watch.start();
        watch.split();
        final String str = watch.toSplitString();
        assertTrue(str.startsWith("label "));
    }

    @Test
    void testToSplitStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String str = watch.toSplitString();
        assertFalse(str.contains("null"));
    }

    @Test
    void testFormatTimeAndFormatSplitTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String splitFormatted = watch.formatSplitTime();
        assertNotNull(splitFormatted);
        assertTrue(splitFormatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
        watch.stop();
        final String timeFormatted = watch.formatTime();
        assertNotNull(timeFormatted);
        assertTrue(timeFormatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    void testRunRunnableRecordsDuration() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = {false};
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
                busyWaitMillis(5);
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getTime() >= 0);
    }

    @Test
    void testRunAccumulatesAcrossMultipleCalls() {
        final StopWatch watch = new StopWatch();
        watch.run(new Runnable() {
            @Override
            public void run() {
                busyWaitMillis(5);
            }
        });
        final long firstTime = watch.getTime();
        watch.run(new Runnable() {
            @Override
            public void run() {
                busyWaitMillis(5);
            }
        });
        final long secondTime = watch.getTime();
        assertTrue(secondTime >= firstTime);
    }

    @Test
    void testGetSupplierReturnsValueAndRecordsDuration() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                busyWaitMillis(5);
                return "result";
            }
        });
        assertEquals("result", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTPropagatesException() {
        final StopWatch watch = new StopWatch();
        final Exception thrown = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getT(new org.apache.commons.lang3.function.FailableSupplier<String, Exception>() {
                    @Override
                    public String get() throws Exception {
                        throw new Exception("boom");
                    }
                });
            }
        });
        assertEquals("boom", thrown.getMessage());
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesException() {
        final StopWatch watch = new StopWatch();
        final Exception thrown = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new org.apache.commons.lang3.function.FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw new Exception("kapow");
                    }
                });
            }
        });
        assertEquals("kapow", thrown.getMessage());
        assertTrue(watch.isSuspended());
    }

    @Test
    void testSplitClassAccessors() {
        final Duration duration = Duration.ofMillis(42);
        final StopWatch.Split split = new StopWatch.Split("label", duration);
        assertEquals("label", split.getLabel());
        assertEquals(duration, split.getDuration());
        assertEquals("label", split.getLeft());
        assertEquals(duration, split.getRight());
        assertTrue(split.toString().contains("label"));
    }

    @Test
    void testGetTimeWhileRunningIncreasesMonotonically() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final long t1 = watch.getNanoTime();
        busyWaitMillis(5);
        final long t2 = watch.getNanoTime();
        assertTrue(t2 >= t1);
    }
}
