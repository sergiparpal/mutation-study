package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link NumericEntityUnescaper}, based solely on the documented
 * contract in the generated javadoc under api/.
 */
public class NumericEntityUnescaperAgentTest {

    // -- isSet() ----------------------------------------------------------

    @Test
    public void testIsSetReturnsFalseForAllOptionsWhenNoneSet() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    public void testIsSetReturnsTrueOnlyForOptionPassedToConstructor() {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    public void testIsSetReturnsTrueForEachOptionPassedWhenMultiplePassed() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonRequired,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
    }

    // -- translate(): basic matching --------------------------------------

    @Test
    public void testTranslateDecimalEntityWithSemicolon() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65;", 0, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateHexEntityLowercaseX() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#x41;", 0, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateHexEntityUppercaseX() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#X41;", 0, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateAtNonZeroIndexWithinLargerSequence() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        CharSequence input = "a&#65;b";
        int consumed = unescaper.translate(input, 1, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateZeroCodePoint() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#0;", 0, out);
        assertEquals(4, consumed);
        assertEquals(1, out.toString().length());
        assertEquals(0, out.toString().codePointAt(0));
    }

    @Test
    public void testTranslateSupplementaryCodePoint() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int codePoint = 0x1F600;
        String entity = "&#" + codePoint + ";";
        int consumed = unescaper.translate(entity, 0, out);
        assertEquals(entity.length(), consumed);
        String written = out.toString();
        assertEquals(Character.charCount(codePoint), written.length());
        assertEquals(codePoint, written.codePointAt(0));
    }

    // -- translate(): default (no options) semicolon handling --------------

    @Test
    public void testTranslateDefaultIgnoresMissingSemicolonAtEndOfInput() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65", 0, out);
        assertEquals(4, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateDefaultStopsAtNonDigitWithoutConsumingIt() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65X", 0, out);
        assertEquals(4, consumed);
        assertEquals("A", out.toString());
    }

    // -- translate(): no match cases (consumed == 0, nothing written) ------

    @Test
    public void testTranslateReturnsZeroForLoneAmpersand() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testTranslateReturnsZeroForHashWithNoDigits() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#;", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testTranslateReturnsZeroWhenNoHashAfterAmpersand() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&amp;", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testTranslateReturnsZeroWhenCharacterAtIndexIsNotAmpersand() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("x&#65;", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    // -- translate(): semiColonRequired option ------------------------------

    @Test
    public void testSemiColonRequiredRejectsEntityMissingSemicolon() throws IOException {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonRequired);
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testSemiColonRequiredAcceptsEntityWithSemicolon() throws IOException {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonRequired);
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65;", 0, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    // -- translate(): errorIfNoSemiColon option -----------------------------

    @Test
    public void testErrorIfNoSemiColonThrowsWhenSemicolonMissing() {
        final NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final StringWriter out = new StringWriter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                unescaper.translate("&#65", 0, out);
            }
        });
    }

    @Test
    public void testErrorIfNoSemiColonSucceedsWhenSemicolonPresent() throws IOException {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65;", 0, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    // -- OPTION enum ---------------------------------------------------------

    @Test
    public void testOptionValuesOrderAndCount() {
        NumericEntityUnescaper.OPTION[] values = NumericEntityUnescaper.OPTION.values();
        assertEquals(3, values.length);
        assertEquals(NumericEntityUnescaper.OPTION.semiColonRequired, values[0]);
        assertEquals(NumericEntityUnescaper.OPTION.semiColonOptional, values[1]);
        assertEquals(NumericEntityUnescaper.OPTION.errorIfNoSemiColon, values[2]);
    }

    @Test
    public void testOptionValueOfValidName() {
        assertEquals(NumericEntityUnescaper.OPTION.semiColonRequired,
                NumericEntityUnescaper.OPTION.valueOf("semiColonRequired"));
        assertEquals(NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.valueOf("semiColonOptional"));
        assertEquals(NumericEntityUnescaper.OPTION.errorIfNoSemiColon,
                NumericEntityUnescaper.OPTION.valueOf("errorIfNoSemiColon"));
    }

    @Test
    public void testOptionValueOfInvalidNameThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                NumericEntityUnescaper.OPTION.valueOf("notAnOption");
            }
        });
    }

    @Test
    public void testOptionValueOfNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                NumericEntityUnescaper.OPTION.valueOf((String) null);
            }
        });
    }
}
