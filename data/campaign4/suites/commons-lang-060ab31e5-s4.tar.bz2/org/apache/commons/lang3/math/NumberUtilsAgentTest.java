package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // Fields
    // ---------------------------------------------------------------

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    // ---------------------------------------------------------------
    // compare (deprecated)
    // ---------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 3, (byte) 5) < 0);
        assertTrue(NumberUtils.compare((byte) 5, (byte) 3) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(3, 5) < 0);
        assertTrue(NumberUtils.compare(5, 3) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(3L, 5L) < 0);
        assertTrue(NumberUtils.compare(5L, 3L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 3, (short) 5) < 0);
        assertTrue(NumberUtils.compare((short) 5, (short) 3) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("0x7B"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("0173"));
    }

    @Test
    public void testCreateBigIntegerInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createDouble
    // ---------------------------------------------------------------

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createFloat
    // ---------------------------------------------------------------

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateIntegerInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
    }

    @Test
    public void testCreateLongOctal() {
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
    }

    @Test
    public void testCreateLongInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        Number n = NumberUtils.createNumber("12345");
        assertTrue(n instanceof Integer);
        assertEquals(12345, n.intValue());
    }

    @Test
    public void testCreateNumberTooBigForInt() {
        // Does not fit in an int; the javadoc says it will try successively
        // larger types from Integer to BigInteger.
        Number n = NumberUtils.createNumber("12345678901");
        assertEquals(12345678901L, n.longValue());
    }

    @Test
    public void testCreateNumberHexSmall() {
        Number n = NumberUtils.createNumber("0x1A");
        assertEquals(26, n.intValue());
    }

    @Test
    public void testCreateNumberHexNegative() {
        Number n = NumberUtils.createNumber("-0x1A");
        assertEquals(-26, n.intValue());
    }

    @Test
    public void testCreateNumberHexTooBigForLong() {
        // More than 16 hex digits after the prefix: BigInteger.
        Number n = NumberUtils.createNumber("0x1234567890ABCDEF1");
        assertTrue(n instanceof BigInteger);
    }

    @Test
    public void testCreateNumberLongSuffix() {
        Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        Number n = NumberUtils.createNumber("3.14f");
        assertTrue(n instanceof Float);
        assertEquals(3.14f, n.floatValue(), 0.0001f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        Number n = NumberUtils.createNumber("3.14d");
        assertTrue(n instanceof Double);
        assertEquals(3.14d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberDecimalValue() {
        Number n = NumberUtils.createNumber("3.14");
        assertEquals(3.14d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberLeadingZeroOctal() {
        Number n = NumberUtils.createNumber("010");
        assertEquals(8, n.intValue());
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("not a number");
            }
        });
    }

    @Test
    public void testCreateNumberNotTrimmed() {
        // The javadoc states leading/trailing spaces are not trimmed and
        // generate NumberFormatExceptions.
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber(" 123 ");
            }
        });
    }

    // ---------------------------------------------------------------
    // isCreatable
    // ---------------------------------------------------------------

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("123L"));
        assertTrue(NumberUtils.isCreatable("0x1F"));
        assertTrue(NumberUtils.isCreatable("3.14"));
        // Leading zero followed by a non-octal digit is invalid.
        assertFalse(NumberUtils.isCreatable("09"));
        // Leading "0." is decimal, not octal.
        assertTrue(NumberUtils.isCreatable("0.09"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12a"));
    }

    // ---------------------------------------------------------------
    // isNumber (deprecated)
    // ---------------------------------------------------------------

    @Test
    public void testIsNumber() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("123"));
        assertTrue(NumberUtils.isNumber("0x1F"));
        assertFalse(NumberUtils.isNumber("09"));
        assertFalse(NumberUtils.isNumber("abc"));
    }

    // ---------------------------------------------------------------
    // isParsable
    // ---------------------------------------------------------------

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("+Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
        // Not understood by Integer/Long/Float/Double parse methods.
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ---------------------------------------------------------------
    // max / min - varargs
    // ---------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 7, NumberUtils.max((byte) 7));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0f);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0f);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d), 0.0d);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 5.0d, 3.0d), 0.0d);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // max / min - three-arg overloads
    // ---------------------------------------------------------------

    @Test
    public void testMaxMinThreeByte() {
        assertEquals((byte) 7, NumberUtils.max((byte) 7, (byte) 2, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 7, (byte) 2, (byte) 5));
    }

    @Test
    public void testMaxMinThreeShort() {
        assertEquals((short) 7, NumberUtils.max((short) 7, (short) 2, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 7, (short) 2, (short) 5));
    }

    @Test
    public void testMaxMinThreeInt() {
        assertEquals(7, NumberUtils.max(7, 2, 5));
        assertEquals(2, NumberUtils.min(7, 2, 5));
    }

    @Test
    public void testMaxMinThreeLong() {
        assertEquals(7L, NumberUtils.max(7L, 2L, 5L));
        assertEquals(2L, NumberUtils.min(7L, 2L, 5L));
    }

    @Test
    public void testMaxMinThreeFloat() {
        assertEquals(7.0f, NumberUtils.max(7.0f, 2.0f, 5.0f), 0.0f);
        assertEquals(2.0f, NumberUtils.min(7.0f, 2.0f, 5.0f), 0.0f);
    }

    @Test
    public void testMaxMinThreeDouble() {
        assertEquals(7.0d, NumberUtils.max(7.0d, 2.0d, 5.0d), 0.0d);
        assertEquals(2.0d, NumberUtils.min(7.0d, 2.0d, 5.0d), 0.0d);
    }

    @Test
    public void testMaxThreeDoubleNaN() {
        // If any value is NaN, NaN is returned.
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMinThreeDoubleNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMaxThreeFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    public void testMinThreeFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    // ---------------------------------------------------------------
    // toByte
    // ---------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        // Out of byte range: conversion fails, zero is returned.
        assertEquals((byte) 0, NumberUtils.toByte("128"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    // ---------------------------------------------------------------
    // toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---------------------------------------------------------------
    // toFloat
    // ---------------------------------------------------------------

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // ---------------------------------------------------------------
    // toInt
    // ---------------------------------------------------------------

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        // Out of int range: conversion fails, zero is returned.
        assertEquals(0, NumberUtils.toInt("99999999999"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    // ---------------------------------------------------------------
    // toLong
    // ---------------------------------------------------------------

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("not a number"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    // ---------------------------------------------------------------
    // toShort
    // ---------------------------------------------------------------

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        // Out of short range: conversion fails, zero is returned.
        assertEquals((short) 0, NumberUtils.toShort("32768"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((BigDecimal) null)));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        // 5.125 rounded to scale 2 with HALF_EVEN rounds to the even
        // neighbor 5.12.
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("5.125"));
        assertEquals(0, new BigDecimal("5.12").compareTo(result));
        assertEquals(2, result.scale());
    }

    @Test
    public void testToScaledBigDecimalBigDecimalCustom() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 0, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("3").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Double) null)));
    }

    @Test
    public void testToScaledBigDecimalDoubleDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(5.125d));
        assertEquals(0, new BigDecimal("5.12").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalDoubleCustom() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d), 0, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("3").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Float) null)));
    }

    @Test
    public void testToScaledBigDecimalFloatDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(5.125f));
        assertEquals(0, new BigDecimal("5.12").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalFloatCustom() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f), 0, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("3").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((String) null)));
    }

    @Test
    public void testToScaledBigDecimalStringDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("5.125");
        assertEquals(0, new BigDecimal("5.12").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalStringCustom() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.5", 0, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("3").compareTo(result));
    }

    // ---------------------------------------------------------------
    // Deprecated public constructor remains callable.
    // ---------------------------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new NumberUtils());
    }
}
