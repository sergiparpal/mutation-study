/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    private static boolean isAlphabetic(final String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isLetter(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAlphanumeric(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (!Character.isLetter(c) && !Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private static boolean isNumeric(final String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    // ---- singletons ----

    @Test
    void testInsecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSecureStrongSingleton() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSingletonsAreDistinct() {
        assertTrue(RandomStringUtils.insecure() != RandomStringUtils.secure());
        assertTrue(RandomStringUtils.secure() != RandomStringUtils.secureStrong());
    }

    @Test
    void testDeprecatedConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertEquals(5, instance.next(5).length());
    }

    @Test
    void testToString() {
        final String s = RandomStringUtils.insecure().toString();
        assertNotNull(s);
        assertTrue(s.startsWith("RandomStringUtils ["));
    }

    // ---- next(int) ----

    @Test
    void testNextZeroLength() {
        assertEquals("", RandomStringUtils.insecure().next(0));
    }

    @Test
    void testNextPositiveLength() {
        final String s = RandomStringUtils.insecure().next(10);
        assertEquals(10, s.length());
    }

    @Test
    void testNextNegativeLengthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1);
            }
        });
    }

    // ---- next(int, boolean, boolean) ----

    @Test
    void testNextLettersOnly() {
        final String s = RandomStringUtils.insecure().next(50, true, false);
        assertEquals(50, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testNextNumbersOnly() {
        final String s = RandomStringUtils.insecure().next(50, false, true);
        assertEquals(50, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    void testNextLettersAndNumbers() {
        final String s = RandomStringUtils.insecure().next(50, true, true);
        assertEquals(50, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testNextNeitherLettersNorNumbersZeroLength() {
        assertEquals("", RandomStringUtils.insecure().next(0, false, false));
    }

    // ---- next(int, char...) ----

    @Test
    void testNextWithCharsArray() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.insecure().next(20, chars);
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z');
        }
    }

    @Test
    void testNextWithNullCharsArray() {
        final char[] chars = null;
        final String s = RandomStringUtils.insecure().next(5, chars);
        assertEquals(5, s.length());
    }

    @Test
    void testNextWithEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, new char[0]);
            }
        });
    }

    @Test
    void testNextZeroCountWithEmptyCharsArray() {
        // count == 0 short-circuits before the chars-empty check
        assertEquals("", RandomStringUtils.insecure().next(0, new char[0]));
    }

    // ---- next(int, int, int, boolean, boolean, char...) ----

    @Test
    void testNextRangeEndLessThanOrEqualStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, 10, 10, false, false);
            }
        });
    }

    @Test
    void testNextRangeNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, -1, 10, false, false);
            }
        });
    }

    @Test
    void testNextRangeStartExceedingCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, 5, 6, false, false, chars);
            }
        });
    }

    @Test
    void testNextRangeEndExceedingCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, 0, 10, false, false, chars);
            }
        });
    }

    @Test
    void testNextRangeValid() {
        final String s = RandomStringUtils.insecure().next(15, 'a', 'd', false, false);
        assertEquals(15, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 'a' && c < 'd');
        }
    }

    // ---- next(int, String) ----

    @Test
    void testNextWithStringChars() {
        final String s = RandomStringUtils.insecure().next(10, "ab");
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b');
        }
    }

    @Test
    void testNextWithNullStringChars() {
        final String nullChars = null;
        final String s = RandomStringUtils.insecure().next(5, nullChars);
        assertEquals(5, s.length());
    }

    @Test
    void testNextWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, "");
            }
        });
    }

    // ---- nextAlphabetic ----

    @Test
    void testNextAlphabetic() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(30);
        assertEquals(30, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testNextAlphabeticZero() {
        assertEquals("", RandomStringUtils.insecure().nextAlphabetic(0));
    }

    @Test
    void testNextAlphabeticNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAlphabetic(-5);
            }
        });
    }

    @Test
    void testNextAlphabeticRange() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(3, 4);
        assertEquals(3, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testNextAlphabeticRangeEqualBoundsReturnsFixedLength() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(4, 4);
        assertEquals(4, s.length());
    }

    @Test
    void testNextAlphabeticRangeInvertedThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAlphabetic(10, 5);
            }
        });
    }

    // ---- nextAlphanumeric ----

    @Test
    void testNextAlphanumeric() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(30);
        assertEquals(30, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testNextAlphanumericRange() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(2, 3);
        assertEquals(2, s.length());
        assertTrue(isAlphanumeric(s));
    }

    // ---- nextAscii ----

    @Test
    void testNextAscii() {
        final String s = RandomStringUtils.insecure().nextAscii(40);
        assertEquals(40, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c < 127);
        }
    }

    @Test
    void testNextAsciiRange() {
        final String s = RandomStringUtils.insecure().nextAscii(1, 2);
        assertEquals(1, s.length());
    }

    // ---- nextGraph ----

    @Test
    void testNextGraph() {
        final String s = RandomStringUtils.insecure().nextGraph(40);
        assertEquals(40, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c < 127);
            assertTrue(c != ' ');
        }
    }

    @Test
    void testNextGraphRange() {
        final String s = RandomStringUtils.insecure().nextGraph(5, 6);
        assertEquals(5, s.length());
    }

    // ---- nextNumeric ----

    @Test
    void testNextNumeric() {
        final String s = RandomStringUtils.insecure().nextNumeric(25);
        assertEquals(25, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    void testNextNumericRange() {
        final String s = RandomStringUtils.insecure().nextNumeric(6, 7);
        assertEquals(6, s.length());
        assertTrue(isNumeric(s));
    }

    // ---- nextPrint ----

    @Test
    void testNextPrint() {
        final String s = RandomStringUtils.insecure().nextPrint(40);
        assertEquals(40, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c < 127);
        }
    }

    @Test
    void testNextPrintRange() {
        final String s = RandomStringUtils.insecure().nextPrint(8, 9);
        assertEquals(8, s.length());
    }

    // ---- static random(...) factory methods using the default secure() instance ----

    @Test
    void testStaticRandomCount() {
        final String s = RandomStringUtils.random(12);
        assertEquals(12, s.length());
    }

    @Test
    void testStaticRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    void testStaticRandomCountNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-3);
            }
        });
    }

    @Test
    void testStaticRandomLettersNumbers() {
        final String s = RandomStringUtils.random(20, true, false);
        assertEquals(20, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testStaticRandomChars() {
        final char[] chars = { '1', '2' };
        final String s = RandomStringUtils.random(10, chars);
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == '1' || c == '2');
        }
    }

    @Test
    void testStaticRandomStartEndLettersNumbers() {
        final String s = RandomStringUtils.random(10, 'a', 'd', true, false);
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 'a' && c < 'd');
        }
    }

    @Test
    void testStaticRandomStartEndLettersNumbersChars() {
        final char[] chars = { 'a', 'b', 'c', 'd' };
        final String s = RandomStringUtils.random(10, 0, 4, false, false, chars);
        assertEquals(10, s.length());
    }

    @Test
    void testStaticRandomString() {
        final String s = RandomStringUtils.random(6, "z");
        assertEquals(6, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertEquals('z', s.charAt(i));
        }
    }

    @Test
    void testStaticRandomAlphabetic() {
        final String s = RandomStringUtils.randomAlphabetic(14);
        assertEquals(14, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testStaticRandomAlphabeticRange() {
        final String s = RandomStringUtils.randomAlphabetic(2, 3);
        assertEquals(2, s.length());
    }

    @Test
    void testStaticRandomAlphanumeric() {
        final String s = RandomStringUtils.randomAlphanumeric(14);
        assertEquals(14, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testStaticRandomAlphanumericRange() {
        final String s = RandomStringUtils.randomAlphanumeric(3, 4);
        assertEquals(3, s.length());
    }

    @Test
    void testStaticRandomAscii() {
        final String s = RandomStringUtils.randomAscii(14);
        assertEquals(14, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c < 127);
        }
    }

    @Test
    void testStaticRandomAsciiRange() {
        final String s = RandomStringUtils.randomAscii(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testStaticRandomGraph() {
        final String s = RandomStringUtils.randomGraph(14);
        assertEquals(14, s.length());
    }

    @Test
    void testStaticRandomGraphRange() {
        final String s = RandomStringUtils.randomGraph(5, 6);
        assertEquals(5, s.length());
    }

    @Test
    void testStaticRandomNumeric() {
        final String s = RandomStringUtils.randomNumeric(14);
        assertEquals(14, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    void testStaticRandomNumericRange() {
        final String s = RandomStringUtils.randomNumeric(6, 7);
        assertEquals(6, s.length());
    }

    @Test
    void testStaticRandomPrint() {
        final String s = RandomStringUtils.randomPrint(14);
        assertEquals(14, s.length());
    }

    @Test
    void testStaticRandomPrintRange() {
        final String s = RandomStringUtils.randomPrint(7, 8);
        assertEquals(7, s.length());
    }

    // ---- surrogate pair handling when using the full Unicode range ----

    @Test
    void testNextFullUnicodeRangeProducesValidString() {
        final String s = RandomStringUtils.insecure().next(100, false, false);
        assertNotNull(s);
        assertTrue(s.codePointCount(0, s.length()) <= 100);
        assertTrue(s.length() >= 100);
    }
}
