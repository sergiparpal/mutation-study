package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class TextStyleAgentTest {

    // ---- constants ----

    @Test
    public void testUnsetMaxWidthConstant() {
        assertEquals(Integer.MAX_VALUE, TextStyle.UNSET_MAX_WIDTH);
    }

    @Test
    public void testDefaultConstant() {
        TextStyle style = TextStyle.DEFAULT;
        assertNotNull(style);
        assertEquals(TextStyle.Alignment.LEFT, style.getAlignment());
        assertEquals(0, style.getLeftPad());
        assertEquals(0, style.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, style.getMaxWidth());
        assertTrue(style.isScalable());
    }

    // ---- builder() factory ----

    @Test
    public void testBuilderCreatesNewInstanceEachCall() {
        TextStyle.Builder b1 = TextStyle.builder();
        TextStyle.Builder b2 = TextStyle.builder();
        assertNotNull(b1);
        assertNotNull(b2);
        assertNotSame(b1, b2);
    }

    @Test
    public void testBuilderDefaultValues() {
        TextStyle.Builder builder = TextStyle.builder();
        assertEquals(0, builder.getLeftPad());
        assertEquals(0, builder.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, builder.getMaxWidth());
        assertTrue(builder.isScalable());
        assertEquals(TextStyle.Alignment.LEFT, builder.get().getAlignment());
    }

    // ---- builder setters return "this" for chaining ----

    @Test
    public void testSetAlignmentReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setAlignment(TextStyle.Alignment.RIGHT));
    }

    @Test
    public void testSetIndentReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setIndent(4));
    }

    @Test
    public void testSetLeftPadReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setLeftPad(2));
    }

    @Test
    public void testSetMinWidthReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setMinWidth(3));
    }

    @Test
    public void testSetMaxWidthReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setMaxWidth(20));
    }

    @Test
    public void testSetScalableReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setScalable(false));
    }

    @Test
    public void testSetTextStyleReturnsSameBuilder() {
        TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setTextStyle(TextStyle.DEFAULT));
    }

    // ---- builder getters reflect what was set ----

    @Test
    public void testBuilderIndentRoundTrip() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setIndent(7);
        assertEquals(7, builder.getIndent());
    }

    @Test
    public void testBuilderLeftPadRoundTrip() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setLeftPad(5);
        assertEquals(5, builder.getLeftPad());
    }

    @Test
    public void testBuilderMinWidthRoundTrip() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setMinWidth(9);
        assertEquals(9, builder.getMinWidth());
    }

    @Test
    public void testBuilderMaxWidthRoundTrip() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setMaxWidth(42);
        assertEquals(42, builder.getMaxWidth());
    }

    @Test
    public void testBuilderScalableRoundTrip() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setScalable(false);
        assertFalse(builder.isScalable());
        builder.setScalable(true);
        assertTrue(builder.isScalable());
    }

    // ---- get() builds a TextStyle reflecting the builder's state ----

    @Test
    public void testGetBuildsTextStyleWithConfiguredValues() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.CENTER);
        builder.setIndent(3);
        builder.setLeftPad(2);
        builder.setMinWidth(5);
        builder.setMaxWidth(50);
        builder.setScalable(false);

        TextStyle style = builder.get();

        assertEquals(TextStyle.Alignment.CENTER, style.getAlignment());
        assertEquals(3, style.getIndent());
        assertEquals(2, style.getLeftPad());
        assertEquals(5, style.getMinWidth());
        assertEquals(50, style.getMaxWidth());
        assertFalse(style.isScalable());
    }

    @Test
    public void testSetTextStyleCopiesAllProperties() {
        TextStyle.Builder source = TextStyle.builder();
        source.setAlignment(TextStyle.Alignment.RIGHT);
        source.setIndent(6);
        source.setLeftPad(4);
        source.setMinWidth(8);
        source.setMaxWidth(80);
        source.setScalable(false);
        TextStyle sourceStyle = source.get();

        TextStyle.Builder target = TextStyle.builder();
        target.setTextStyle(sourceStyle);
        TextStyle copied = target.get();

        assertEquals(sourceStyle.getAlignment(), copied.getAlignment());
        assertEquals(sourceStyle.getIndent(), copied.getIndent());
        assertEquals(sourceStyle.getLeftPad(), copied.getLeftPad());
        assertEquals(sourceStyle.getMinWidth(), copied.getMinWidth());
        assertEquals(sourceStyle.getMaxWidth(), copied.getMaxWidth());
        assertEquals(sourceStyle.isScalable(), copied.isScalable());
    }

    // ---- toString sanity ----

    @Test
    public void testToStringIsNotNull() {
        assertNotNull(TextStyle.DEFAULT.toString());
    }

    // ---- pad() ----

    @Test
    public void testPadLeftAlignmentNoIndent() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.LEFT);
        builder.setMaxWidth(10);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "ab");

        assertEquals(10, result.length());
        assertEquals("ab        ", result.toString());
    }

    @Test
    public void testPadLeftAlignmentWithIndent() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.LEFT);
        builder.setMaxWidth(10);
        builder.setIndent(3);
        TextStyle style = builder.get();

        CharSequence result = style.pad(true, "ab");

        // target length = maxWidth - indent = 7
        assertEquals(7, result.length());
        assertEquals("ab     ", result.toString());
    }

    @Test
    public void testPadRightAlignment() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.RIGHT);
        builder.setMaxWidth(5);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "ab");

        assertEquals(5, result.length());
        assertEquals("   ab", result.toString());
    }

    @Test
    public void testPadCenterAlignmentEvenPadding() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.CENTER);
        builder.setMaxWidth(6);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "ab");

        assertEquals(6, result.length());
        assertEquals("  ab  ", result.toString());
    }

    @Test
    public void testPadCenterAlignmentOddPadding() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.CENTER);
        builder.setMaxWidth(7);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "ab");
        String s = result.toString();

        assertEquals(7, s.length());
        assertTrue(s.contains("ab"));
        assertEquals(5, countSpaces(s));
    }

    @Test
    public void testPadReturnsUnchangedWhenTextLongerThanTarget() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.LEFT);
        builder.setMaxWidth(3);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "abcdef");

        assertEquals("abcdef", result.toString());
    }

    @Test
    public void testPadReturnsUnchangedWhenTextExactlyTargetLength() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.LEFT);
        builder.setMaxWidth(4);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "abcd");

        assertEquals("abcd", result.toString());
        assertEquals(4, result.length());
    }

    @Test
    public void testPadWithEmptyText() {
        TextStyle.Builder builder = TextStyle.builder();
        builder.setAlignment(TextStyle.Alignment.LEFT);
        builder.setMaxWidth(5);
        TextStyle style = builder.get();

        CharSequence result = style.pad(false, "");

        assertEquals(5, result.length());
        assertEquals("     ", result.toString());
    }

    private static int countSpaces(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ') {
                count++;
            }
        }
        return count;
    }

    // ---- TextStyle.Alignment enum ----

    @Test
    public void testAlignmentValues() {
        TextStyle.Alignment[] values = TextStyle.Alignment.values();
        assertEquals(3, values.length);
        assertEquals(TextStyle.Alignment.LEFT, values[0]);
        assertEquals(TextStyle.Alignment.CENTER, values[1]);
        assertEquals(TextStyle.Alignment.RIGHT, values[2]);
    }

    @Test
    public void testAlignmentValueOf() {
        assertEquals(TextStyle.Alignment.LEFT, TextStyle.Alignment.valueOf("LEFT"));
        assertEquals(TextStyle.Alignment.CENTER, TextStyle.Alignment.valueOf("CENTER"));
        assertEquals(TextStyle.Alignment.RIGHT, TextStyle.Alignment.valueOf("RIGHT"));
    }

    @Test
    public void testAlignmentValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                TextStyle.Alignment.valueOf("NOT_A_VALUE");
            }
        });
    }

    @Test
    public void testAlignmentValueOfNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                TextStyle.Alignment.valueOf(null);
            }
        });
    }
}
