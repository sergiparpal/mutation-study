/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private static final class PrivateFixture {
        // used only to exercise isPublic(Class) with a non-public class
    }

    @Test
    void testComparator() {
        final Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        final List<Class<?>> classes = new ArrayList<Class<?>>(Arrays.asList(String.class, Integer.class, Boolean.class));
        Collections.sort(classes, comparator);
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), classes);
    }

    @Test
    void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        final List<String> result = ClassUtils.convertClassesToClassNames(input);
        assertEquals(2, result.size());
        assertEquals("java.lang.String", result.get(0));
        assertNull(result.get(1));
    }

    @Test
    void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("does.not.Exist");
        names.add(null);
        final List<Class<?>> result = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, result.size());
        assertEquals(String.class, result.get(0));
        assertNull(result.get(1));
        assertNull(result.get(2));
    }

    @Test
    void testGetAbbreviatedNameFromClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 10));
    }

    @Test
    void testGetAbbreviatedNameFromString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(ArrayList.class);
        assertTrue(interfaces.contains(List.class));
        assertTrue(interfaces.contains(Collection.class));
    }

    @Test
    void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Integer.class);
        assertEquals(Arrays.asList(Number.class, Object.class), superclasses);
        assertEquals(Collections.emptyList(), ClassUtils.getAllSuperclasses(Object.class));
    }

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName((Object) "hello"));
    }

    @Test
    void testGetClassLoaderClassNameHappyPath() throws ClassNotFoundException {
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(int.class, ClassUtils.getClass(loader, "int"));
        assertEquals(int[].class, ClassUtils.getClass(loader, "int[]"));
        assertEquals(int[].class, ClassUtils.getClass(loader, "[I"));
        assertEquals(String[].class, ClassUtils.getClass(loader, "[Ljava.lang.String;"));
        assertEquals(Map.Entry.class, ClassUtils.getClass(loader, "java.util.Map.Entry"));
        assertEquals(Map.Entry.class, ClassUtils.getClass(loader, "java.util.Map$Entry"));
    }

    @Test
    void testGetClassNormalizesWhitespace() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass(" java.lang.String "));
    }

    @Test
    void testGetClassNotFound() {
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, "does.not.Exist");
            }
        });
    }

    @Test
    void testGetClassNullNameThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassArrayDimensionTooLarge() {
        final StringBuilder sb = new StringBuilder("int");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String tooManyDims = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(tooManyDims);
            }
        });
    }

    @Test
    void testGetClassNameTooLong() {
        final char[] chars = new char[70000];
        Arrays.fill(chars, 'a');
        final String longName = new String(chars);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(longName);
            }
        });
    }

    @Test
    void testGetClassMalformedArrayName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("java.lang.String[]junk[]");
            }
        });
    }

    @Test
    void testGetClassStrictDoesNotNormalizeWhitespace() {
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClassStrict(loader, " java.lang.String", true);
            }
        });
    }

    @Test
    void testGetClassStrictHappyPath() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClassStrict("java.lang.String"));
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        assertEquals(String.class, ClassUtils.getClassStrict(loader, "java.lang.String", true));
    }

    @Test
    void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("N/A", ClassUtils.getName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName((Object) "hello"));
    }

    @Test
    void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName((Object) "hello", "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName(int[].class));
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageName((Object) "hello", "N/A"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
    }

    @Test
    void testGetPublicMethodHappyPath() throws Exception {
        final Set<String> set = Collections.unmodifiableSet(new HashSet<String>());
        final Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty");
        assertNotNull(method);
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        assertEquals(Boolean.TRUE, method.invoke(set));
    }

    @Test
    void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodAtAll");
            }
        });
    }

    @Test
    void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
    }

    @Test
    void testGetShortCanonicalNameObjectAndString() {
        assertEquals("N/A", ClassUtils.getShortCanonicalName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortCanonicalName((Object) "hello", "N/A"));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getCanonicalName()));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    @Test
    void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("String[][]", ClassUtils.getShortClassName(String[][].class));
    }

    @Test
    void testGetShortClassNameObject() {
        assertEquals("N/A", ClassUtils.getShortClassName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortClassName((Object) "hello", "N/A"));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortClassName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortClassName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    @Test
    void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getSimpleName((Class<?>) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("N/A", ClassUtils.getSimpleName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName((Object) "hello"));
    }

    @Test
    void testHierarchyExcludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Integer.class);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        for (final Class<?> c : hierarchy) {
            list.add(c);
        }
        assertEquals(Arrays.asList(Integer.class, Number.class, Object.class), list);
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Integer.class, ClassUtils.Interfaces.INCLUDE);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        assertTrue(list.contains(Integer.class));
        assertTrue(list.contains(Comparable.class));
        assertTrue(list.contains(Object.class));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                hierarchy.iterator().remove();
            }
        });
    }

    @Test
    void testIsAssignable() {
        assertFalse(ClassUtils.isAssignable(Object.class, null));
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertFalse(ClassUtils.isAssignable(Object.class, int.class));
    }

    @Test
    void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class[] { int.class, String.class }, int.class, String.class));
        assertFalse(ClassUtils.isAssignable(new Class[] { int.class }, int.class, String.class));
        assertFalse(ClassUtils.isAssignable(new Class[] { boolean.class }, new Class[] { int.class }, false));
    }

    @Test
    void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
        assertTrue(ClassUtils.isInnerClass(PrivateFixture.class));
    }

    @Test
    void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateFixture.class));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        final Class<?>[] empty = ClassUtils.primitivesToWrappers();
        assertEquals(0, empty.length);
        assertArrayEquals(new Class<?>[] { Integer.class, String.class }, ClassUtils.primitivesToWrappers(int.class, String.class));
    }

    @Test
    void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, ClassUtils.toClass("foo", 1, null));
    }

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        final Class<?>[] empty = ClassUtils.wrappersToPrimitives();
        assertEquals(0, empty.length);
        assertArrayEquals(new Class<?>[] { int.class, null }, ClassUtils.wrappersToPrimitives(Integer.class, String.class));
    }

    @Test
    void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    void testConstructor() {
        assertNotNull(new ClassUtils());
    }
}
