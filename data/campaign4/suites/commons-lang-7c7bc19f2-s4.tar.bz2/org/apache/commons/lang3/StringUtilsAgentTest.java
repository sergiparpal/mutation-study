package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link StringUtils}, based on the documented contract in the javadoc.
 */
@SuppressWarnings("deprecation")
public class StringUtilsAgentTest {

    // ---------------------------------------------------------------- fields

    @Test
    public void testFields() {
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("", StringUtils.EMPTY);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }

    @Test
    public void testConstructorIsPublic() {
        // deprecated but public; should not throw
        assertNotNull(new StringUtils());
    }

    // ---------------------------------------------------------------- isEmpty / isBlank family

    @Test
    public void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));
        assertFalse(StringUtils.isEmpty("  bob  "));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));
        assertTrue(StringUtils.isNotEmpty("bob"));
    }

    @Test
    public void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));
    }

    @Test
    public void testIsNotBlank() {
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(""));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
    }

    @Test
    public void testIsAnyEmpty() {
        assertTrue(StringUtils.isAnyEmpty((CharSequence) null));
        assertFalse(StringUtils.isAnyEmpty((CharSequence[]) null));
        assertTrue(StringUtils.isAnyEmpty(null, "foo"));
        assertTrue(StringUtils.isAnyEmpty("", "bar"));
        assertTrue(StringUtils.isAnyEmpty("bob", ""));
        assertFalse(StringUtils.isAnyEmpty(" ", "bar"));
        assertFalse(StringUtils.isAnyEmpty("foo", "bar"));
        assertFalse(StringUtils.isAnyEmpty(new String[] {}));
        assertTrue(StringUtils.isAnyEmpty(new String[] { "" }));
    }

    @Test
    public void testIsAllEmpty() {
        assertTrue(StringUtils.isAllEmpty((CharSequence[]) null));
        assertTrue(StringUtils.isAllEmpty());
        assertTrue(StringUtils.isAllEmpty((CharSequence) null));
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "foo"));
        assertFalse(StringUtils.isAllEmpty("", "bar"));
        assertFalse(StringUtils.isAllEmpty("bob", ""));
        assertFalse(StringUtils.isAllEmpty("  bob  ", null));
        assertFalse(StringUtils.isAllEmpty(" ", "bar"));
        assertFalse(StringUtils.isAllEmpty("foo", "bar"));
    }

    @Test
    public void testIsAnyBlank() {
        assertTrue(StringUtils.isAnyBlank((CharSequence) null));
        assertFalse(StringUtils.isAnyBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAnyBlank(null, "foo"));
        assertTrue(StringUtils.isAnyBlank(null, null));
        assertTrue(StringUtils.isAnyBlank("", "bar"));
        assertTrue(StringUtils.isAnyBlank("bob", ""));
        assertTrue(StringUtils.isAnyBlank("  bob  ", null));
        assertTrue(StringUtils.isAnyBlank(" ", "bar"));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));
    }

    @Test
    public void testIsAllBlank() {
        assertTrue(StringUtils.isAllBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank(null, " "));
        assertFalse(StringUtils.isAllBlank(null, "foo"));
        assertFalse(StringUtils.isAllBlank("", "bar"));
        assertFalse(StringUtils.isAllBlank("bob", ""));
        assertFalse(StringUtils.isAllBlank("  bob  ", null));
        assertFalse(StringUtils.isAllBlank(" ", "bar"));
    }

    @Test
    public void testIsNoneEmpty() {
        assertFalse(StringUtils.isNoneEmpty((CharSequence) null));
        assertTrue(StringUtils.isNoneEmpty((CharSequence[]) null));
        assertFalse(StringUtils.isNoneEmpty(null, "foo"));
        assertFalse(StringUtils.isNoneEmpty("", "bar"));
        assertTrue(StringUtils.isNoneEmpty(" ", "bar"));
        assertTrue(StringUtils.isNoneEmpty("foo", "bar"));
    }

    @Test
    public void testIsNoneBlank() {
        assertFalse(StringUtils.isNoneBlank((CharSequence) null));
        assertTrue(StringUtils.isNoneBlank((CharSequence[]) null));
        assertFalse(StringUtils.isNoneBlank(null, "foo"));
        assertFalse(StringUtils.isNoneBlank("", "bar"));
        assertFalse(StringUtils.isNoneBlank(" ", "bar"));
        assertTrue(StringUtils.isNoneBlank("foo", "bar"));
    }

    // ---------------------------------------------------------------- trim / strip family

    @Test
    public void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("abc"));
        assertEquals("abc", StringUtils.trim("    abc    "));
    }

    @Test
    public void testTrimAsciiControl() {
        assertNull(StringUtils.trimAsciiControl(null));
        assertEquals("", StringUtils.trimAsciiControl(""));
        assertEquals("abc", StringUtils.trimAsciiControl("abc\u0001"));
        assertEquals("abc", StringUtils.trimAsciiControl("abc"));
        // regular space (32) is not an ASCII control character, so it is preserved
        assertEquals(" abc ", StringUtils.trimAsciiControl(" abc "));
    }

    @Test
    public void testTrimToEmpty() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty(""));
        assertEquals("", StringUtils.trimToEmpty("     "));
        assertEquals("abc", StringUtils.trimToEmpty("abc"));
        assertEquals("abc", StringUtils.trimToEmpty("    abc    "));
    }

    @Test
    public void testTrimToNull() {
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull(""));
        assertNull(StringUtils.trimToNull("     "));
        assertEquals("abc", StringUtils.trimToNull("abc"));
        assertEquals("abc", StringUtils.trimToNull("    abc    "));
    }

    @Test
    public void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip(""));
        assertEquals("abc", StringUtils.strip("  abc  "));
    }

    @Test
    public void testStripWithChars() {
        assertNull(StringUtils.strip(null, "xyz"));
        assertEquals("", StringUtils.strip("", "xyz"));
        assertEquals("abc", StringUtils.strip("  abc  ", null));
        assertEquals("abc", StringUtils.strip("yxabcxy", "xy"));
    }

    @Test
    public void testStripStart() {
        assertNull(StringUtils.stripStart(null, "*"));
        assertEquals("", StringUtils.stripStart("", "*"));
        assertEquals("abc", StringUtils.stripStart("abc", ""));
        assertEquals("abc", StringUtils.stripStart("abc", null));
        assertEquals("abc", StringUtils.stripStart("  abc", null));
        assertEquals("abc  ", StringUtils.stripStart("abc  ", null));
        assertEquals("abc ", StringUtils.stripStart(" abc ", null));
        assertEquals("abc  ", StringUtils.stripStart("yxabc  ", "xyz"));
    }

    @Test
    public void testStripEnd() {
        assertNull(StringUtils.stripEnd(null, "*"));
        assertEquals("", StringUtils.stripEnd("", "*"));
        assertEquals("abc", StringUtils.stripEnd("abc", ""));
        assertEquals("abc", StringUtils.stripEnd("abc", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc", null));
        assertEquals("abc", StringUtils.stripEnd("abc  ", null));
        assertEquals(" abc", StringUtils.stripEnd(" abc ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abcyx", "xyz"));
        assertEquals("12", StringUtils.stripEnd("120.00", ".0"));
        assertEquals("85123", StringUtils.stripEnd("85123116", "16"));
    }

    @Test
    public void testStripToEmpty() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty(""));
        assertEquals("", StringUtils.stripToEmpty("   "));
        assertEquals("ab c", StringUtils.stripToEmpty(" ab c "));
    }

    @Test
    public void testStripToNull() {
        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull(""));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("ab c", StringUtils.stripToNull(" ab c "));
    }

    @Test
    public void testStripAll() {
        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {}, StringUtils.stripAll());
        assertArrayEquals(new String[] { "abc", "abc" }, StringUtils.stripAll("abc", "  abc"));
        assertArrayEquals(new String[] { "abc", null }, StringUtils.stripAll("abc  ", null));
    }

    @Test
    public void testStripAllWithChars() {
        assertNull(StringUtils.stripAll(null, "xy"));
        assertArrayEquals(new String[] {}, StringUtils.stripAll(new String[] {}, "xy"));
        assertArrayEquals(new String[] { "abc", "abc" }, StringUtils.stripAll(new String[] { "abc", "  abc" }, null));
        assertArrayEquals(new String[] { "abc  ", null }, StringUtils.stripAll(new String[] { "abc  ", null }, "yz"));
        assertArrayEquals(new String[] { "abc", null }, StringUtils.stripAll(new String[] { "yabcz", null }, "yz"));
    }

    @Test
    public void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("abc"));
        assertEquals("abc", StringUtils.deleteWhitespace("   ab  c  "));
    }

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("a b", StringUtils.normalizeSpace("  a   b  "));
        assertEquals("a b", StringUtils.normalizeSpace("a\tb"));
    }

    // ---------------------------------------------------------------- equals / compare

    @Test
    public void testEqualsDeprecated() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsIgnoreCaseDeprecated() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "ABD"));
    }

    @Test
    public void testEqualsAnyDeprecated() {
        assertFalse(StringUtils.equalsAny("abc"));
        assertTrue(StringUtils.equalsAny("abc", "abc"));
        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "ABC"));
    }

    @Test
    public void testEqualsAnyIgnoreCaseDeprecated() {
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "def"));
    }

    @Test
    public void testCompareTwoArg() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertTrue(StringUtils.compare("b", "a") > 0);
        assertTrue(StringUtils.compare("ab", "abc") < 0);
    }

    @Test
    public void testCompareThreeArg() {
        assertEquals(0, StringUtils.compare(null, null, true));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);
        assertEquals(0, StringUtils.compare("abc", "abc", true));
    }

    @Test
    public void testCompareIgnoreCaseTwoArg() {
        assertEquals(0, StringUtils.compareIgnoreCase(null, null));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
        assertTrue(StringUtils.compareIgnoreCase("a", null) > 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
    }

    @Test
    public void testCompareIgnoreCaseThreeArg() {
        assertEquals(0, StringUtils.compareIgnoreCase(null, null, true));
        assertTrue(StringUtils.compareIgnoreCase(null, "a", true) < 0);
        assertTrue(StringUtils.compareIgnoreCase(null, "a", false) > 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC", true));
    }

    // ---------------------------------------------------------------- startsWith / endsWith

    @Test
    public void testStartsWithDeprecated() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "def"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithIgnoreCaseDeprecated() {
        assertTrue(StringUtils.startsWithIgnoreCase(null, null));
        assertFalse(StringUtils.startsWithIgnoreCase(null, "def"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAnyDeprecated() {
        assertFalse(StringUtils.startsWithAny(null, "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", (CharSequence[]) null));
        assertFalse(StringUtils.startsWithAny("abcxyz"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "", "xyz"));
        assertFalse(StringUtils.startsWithAny("abcxyz", null));
    }

    @Test
    public void testEndsWithDeprecated() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertFalse(StringUtils.endsWith("abcdef", null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
    }

    @Test
    public void testEndsWithIgnoreCaseDeprecated() {
        assertTrue(StringUtils.endsWithIgnoreCase(null, null));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
    }

    @Test
    public void testEndsWithAnyDeprecated() {
        assertFalse(StringUtils.endsWithAny(null, "abc"));
        assertFalse(StringUtils.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(StringUtils.endsWithAny("abcxyz", "", "xyz"));
        assertTrue(StringUtils.endsWithAny("abcxyz", null, "xyz"));
        assertFalse(StringUtils.endsWithAny("abcxyz", null, "xyz".toUpperCase(Locale.ROOT)));
    }

    // ---------------------------------------------------------------- indexOf / lastIndexOf / contains

    @Test
    public void testIndexOfChar() {
        assertEquals(-1, StringUtils.indexOf(null, 'a'));
        assertEquals(-1, StringUtils.indexOf("", 'a'));
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
    }

    @Test
    public void testIndexOfCharWithStartPos() {
        assertEquals(-1, StringUtils.indexOf(null, 'a', 0));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", 'b', 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", 'b', 9));
        // negative start is treated as zero
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', -1));
    }

    @Test
    public void testIndexOfCharSequenceDeprecated() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("a", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOfIgnoreCaseDeprecated() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("", ""));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "AB"));
    }

    @Test
    public void testLastIndexOfChar() {
        assertEquals(-1, StringUtils.lastIndexOf(null, 'a'));
        assertEquals(-1, StringUtils.lastIndexOf("", 'a'));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b'));
    }

    @Test
    public void testLastIndexOfCharWithStartPos() {
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a', 8));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", 'b', -1));
        assertEquals(0, StringUtils.lastIndexOf("aabaabaa", 'a', 0));
    }

    @Test
    public void testLastIndexOfCharSequenceDeprecated() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(8, StringUtils.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfCharSequenceWithStartPosDeprecated() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a", 5));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b", 2));
    }

    @Test
    public void testLastIndexOfIgnoreCaseDeprecated() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase(null, "a"));
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("AABAABAA", "a"));
    }

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(-1, StringUtils.ordinalIndexOf("a", null, 1));
        assertEquals(0, StringUtils.ordinalIndexOf("", "", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(2, StringUtils.ordinalIndexOf("aabaabaa", "b", 1));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "b", 2));
        // overlapping matches
        assertEquals(0, StringUtils.ordinalIndexOf("ababab", "aba", 1));
        assertEquals(2, StringUtils.ordinalIndexOf("ababab", "aba", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("ababab", "aba", 3));
    }

    @Test
    public void testLastOrdinalIndexOf() {
        assertEquals(-1, StringUtils.lastOrdinalIndexOf(null, "a", 1));
        assertEquals(-1, StringUtils.lastOrdinalIndexOf("a", null, 1));
        assertEquals(0, StringUtils.lastOrdinalIndexOf("", "", 1));
        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
        assertEquals(5, StringUtils.lastOrdinalIndexOf("aabaabaa", "b", 1));
        assertEquals(2, StringUtils.lastOrdinalIndexOf("aabaabaa", "b", 2));
    }

    @Test
    public void testIndexOfAnyChars() {
        assertEquals(-1, StringUtils.indexOfAny(null, 'a', 'b'));
        assertEquals(-1, StringUtils.indexOfAny("", 'a', 'b'));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", (char[]) null));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 'b', 'y'));
    }

    @Test
    public void testIndexOfAnyCharSequence() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, "ab"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", (String) null));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "za"));
    }

    @Test
    public void testIndexOfAnyStrings() {
        assertEquals(-1, StringUtils.indexOfAny(null, "ab"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", (CharSequence[]) null));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", "mn", "op"));
    }

    @Test
    public void testIndexOfAnyBut() {
        assertEquals(-1, StringUtils.indexOfAnyBut(null, 'a', 'b'));
        assertEquals(-1, StringUtils.indexOfAnyBut("", 'a', 'b'));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", 'b', 'y'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));
    }

    @Test
    public void testIndexOfAnyButCharSequence() {
        assertEquals(-1, StringUtils.indexOfAnyBut((CharSequence) null, "ab"));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", "ab"));
    }

    @Test
    public void testLastIndexOfAny() {
        assertEquals(-1, StringUtils.lastIndexOfAny(null, "ab"));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", (CharSequence[]) null));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
    }

    @Test
    public void testIndexOfDifferenceTwoArg() {
        assertEquals(-1, StringUtils.indexOfDifference(null, null));
        assertEquals(-1, StringUtils.indexOfDifference("", ""));
        assertEquals(0, StringUtils.indexOfDifference("", "abc"));
        assertEquals(0, StringUtils.indexOfDifference("abc", ""));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("ab", "abxyz"));
        assertEquals(2, StringUtils.indexOfDifference("abcde", "abxyz"));
        assertEquals(0, StringUtils.indexOfDifference("abcde", "xyz"));
    }

    @Test
    public void testIndexOfDifferenceVarargs() {
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] {}));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] { "abc" }));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] { null, null }));
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[] { "", null }));
        assertEquals(1, StringUtils.indexOfDifference(new CharSequence[] { "abc", "a" }));
        assertEquals(7, StringUtils.indexOfDifference(new CharSequence[] { "i am a machine", "i am a robot" }));
    }

    @Test
    public void testContainsChar() {
        assertFalse(StringUtils.contains(null, 'a'));
        assertFalse(StringUtils.contains("", 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContainsCharSequenceDeprecated() {
        assertFalse(StringUtils.contains((CharSequence) null, (CharSequence) "a"));
        assertFalse(StringUtils.contains((CharSequence) "a", (CharSequence) null));
        assertTrue(StringUtils.contains("", ""));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsIgnoreCaseDeprecated() {
        assertFalse(StringUtils.containsIgnoreCase(null, ""));
        assertFalse(StringUtils.containsIgnoreCase("abc", null));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));
    }

    @Test
    public void testContainsAnyChars() {
        assertFalse(StringUtils.containsAny(null, 'z', 'a'));
        assertFalse(StringUtils.containsAny("", 'z', 'a'));
        assertFalse(StringUtils.containsAny("zzabyycdxx", (char[]) null));
        assertFalse(StringUtils.containsAny("zzabyycdxx", new char[] {}));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("aba", 'z'));
    }

    @Test
    public void testContainsAnyCharSequence() {
        assertFalse(StringUtils.containsAny((CharSequence) null, "za"));
        assertFalse(StringUtils.containsAny("", "za"));
        assertFalse(StringUtils.containsAny("zzabyycdxx", (CharSequence) null));
        assertFalse(StringUtils.containsAny("zzabyycdxx", ""));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));
        assertFalse(StringUtils.containsAny("aba", "z"));
    }

    @Test
    public void testContainsAnyCharSequencesDeprecated() {
        assertFalse(StringUtils.containsAny((CharSequence) null, "ab"));
        assertFalse(StringUtils.containsAny("abcd", (CharSequence[]) null));
        assertTrue(StringUtils.containsAny("abcd", "ab", null));
        assertTrue(StringUtils.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAnyIgnoreCaseDeprecated() {
        assertFalse(StringUtils.containsAnyIgnoreCase(null, "ab"));
        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "D", "ABC"));
        assertTrue(StringUtils.containsAnyIgnoreCase("ABC", "d", "abc"));
    }

    @Test
    public void testContainsNoneChars() {
        assertTrue(StringUtils.containsNone(null, 'x', 'y', 'z'));
        assertTrue(StringUtils.containsNone("", 'x', 'y', 'z'));
        assertTrue(StringUtils.containsNone("abab", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abz", 'x', 'y', 'z'));
    }

    @Test
    public void testContainsNoneString() {
        assertTrue(StringUtils.containsNone(null, "xyz"));
        assertTrue(StringUtils.containsNone("", "xyz"));
        assertTrue(StringUtils.containsNone("abab", "xyz"));
        assertFalse(StringUtils.containsNone("abz", "xyz"));
    }

    @Test
    public void testContainsOnlyChars() {
        assertFalse(StringUtils.containsOnly(null, 'a', 'b'));
        assertFalse(StringUtils.containsOnly("ab", (char[]) null));
        assertTrue(StringUtils.containsOnly("", 'a', 'b'));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("abz", 'a', 'b', 'c'));
    }

    @Test
    public void testContainsOnlyString() {
        assertFalse(StringUtils.containsOnly(null, "ab"));
        assertFalse(StringUtils.containsOnly("ab", (String) null));
        assertTrue(StringUtils.containsOnly("", "ab"));
        assertTrue(StringUtils.containsOnly("abab", "abc"));
        assertFalse(StringUtils.containsOnly("abz", "abc"));
    }

    @Test
    public void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace(""));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("a b"));
        assertTrue(StringUtils.containsWhitespace(" "));
    }

    // ---------------------------------------------------------------- substring / left / right / mid

    @Test
    public void testSubstringOneArg() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 5));
        assertEquals("abc", StringUtils.substring("abc", 0));
        assertEquals("c", StringUtils.substring("abc", 2));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", -2));
        assertEquals("abc", StringUtils.substring("abc", -4));
    }

    @Test
    public void testSubstringTwoArg() {
        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("", StringUtils.substring("", 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("", StringUtils.substring("abc", 4, 6));
        assertEquals("", StringUtils.substring("abc", 2, 2));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    public void testSubstringAfterChar() {
        assertNull(StringUtils.substringAfter(null, 'a'));
        assertEquals("", StringUtils.substringAfter("", 'a'));
        assertEquals("bc", StringUtils.substringAfter("abc", 'a'));
        assertEquals("cba", StringUtils.substringAfter("abcba", 'b'));
        assertEquals("", StringUtils.substringAfter("abc", 'c'));
        assertEquals("", StringUtils.substringAfter("abc", 'd'));
    }

    @Test
    public void testSubstringAfterString() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("abc", StringUtils.substringAfter("abc", ""));
    }

    @Test
    public void testSubstringAfterLastChar() {
        assertNull(StringUtils.substringAfterLast(null, 'a'));
        assertEquals("", StringUtils.substringAfterLast("", 'a'));
        assertEquals("bc", StringUtils.substringAfterLast("abc", 'a'));
        assertEquals("a", StringUtils.substringAfterLast("abcba", 'b'));
        assertEquals("", StringUtils.substringAfterLast("a", 'a'));
        assertEquals("", StringUtils.substringAfterLast("a", 'z'));
    }

    @Test
    public void testSubstringAfterLastString() {
        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("", StringUtils.substringAfterLast("", "a"));
        assertEquals("", StringUtils.substringAfterLast("abc", ""));
        assertEquals("", StringUtils.substringAfterLast("abc", (String) null));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("a", "a"));
    }

    @Test
    public void testSubstringBeforeChar() {
        assertNull(StringUtils.substringBefore(null, 'a'));
        assertEquals("", StringUtils.substringBefore("", 'a'));
        assertEquals("", StringUtils.substringBefore("abc", 'a'));
        assertEquals("a", StringUtils.substringBefore("abcba", 'b'));
        assertEquals("ab", StringUtils.substringBefore("abc", 'c'));
        assertEquals("abc", StringUtils.substringBefore("abc", 'd'));
    }

    @Test
    public void testSubstringBeforeString() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("", StringUtils.substringBefore("abc", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("", StringUtils.substringBefore("abc", ""));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));
    }

    @Test
    public void testSubstringBeforeLast() {
        assertNull(StringUtils.substringBeforeLast(null, "a"));
        assertEquals("", StringUtils.substringBeforeLast("", "a"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("ab", StringUtils.substringBeforeLast("abc", "c"));
        assertEquals("", StringUtils.substringBeforeLast("a", "a"));
        assertEquals("a", StringUtils.substringBeforeLast("a", "z"));
        assertEquals("a", StringUtils.substringBeforeLast("a", (String) null));
        assertEquals("a", StringUtils.substringBeforeLast("a", ""));
    }

    @Test
    public void testSubstringBetweenOneTag() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertNull(StringUtils.substringBetween("tagabctag", (String) null));
        assertEquals("", StringUtils.substringBetween("tagabctag", ""));
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
    }

    @Test
    public void testSubstringBetweenOpenClose() {
        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertNull(StringUtils.substringBetween(null, "[", "]"));
        assertNull(StringUtils.substringBetween("wx[b]yz", null, "]"));
        assertNull(StringUtils.substringBetween("wx[b]yz", "[", null));
        assertEquals("", StringUtils.substringBetween("", "", ""));
        assertNull(StringUtils.substringBetween("", "", "]"));
        assertNull(StringUtils.substringBetween("", "[", "]"));
        assertEquals("abc", StringUtils.substringBetween("yabcz", "y", "z"));
        assertEquals("abc", StringUtils.substringBetween("yabczyabcz", "y", "z"));
    }

    @Test
    public void testSubstringsBetween() {
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertNull(StringUtils.substringsBetween("[a]", null, "]"));
        assertNull(StringUtils.substringsBetween("[a]", "[", null));
        assertArrayEquals(new String[] {}, StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    public void testLeft() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("", StringUtils.left("", 3));
        assertEquals("", StringUtils.left("abc", 0));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testRight() {
        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("", StringUtils.right("", 3));
        assertEquals("", StringUtils.right("abc", 0));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testMid() {
        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("", 0, 2));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("abc", StringUtils.mid("abc", 0, 4));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    // ---------------------------------------------------------------- padding / center

    @Test
    public void testLeftPadDefault() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("bat", StringUtils.leftPad("bat", 3));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", 1));
        assertEquals("bat", StringUtils.leftPad("bat", -1));
    }

    @Test
    public void testLeftPadChar() {
        assertNull(StringUtils.leftPad(null, 3, 'z'));
        assertEquals("zzz", StringUtils.leftPad("", 3, 'z'));
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
        assertEquals("bat", StringUtils.leftPad("bat", -1, 'z'));
    }

    @Test
    public void testLeftPadString() {
        assertNull(StringUtils.leftPad(null, 3, "z"));
        assertEquals("zzz", StringUtils.leftPad("", 3, "z"));
        assertEquals("bat", StringUtils.leftPad("bat", 3, "yz"));
        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));
        assertEquals("yzyzybat", StringUtils.leftPad("bat", 8, "yz"));
        assertEquals("  bat", StringUtils.leftPad("bat", 5, (String) null));
        assertEquals("  bat", StringUtils.leftPad("bat", 5, ""));
    }

    @Test
    public void testRightPadDefault() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("   ", StringUtils.rightPad("", 3));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("bat", StringUtils.rightPad("bat", -1));
    }

    @Test
    public void testRightPadChar() {
        assertNull(StringUtils.rightPad(null, 3, 'z'));
        assertEquals("zzz", StringUtils.rightPad("", 3, 'z'));
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
    }

    @Test
    public void testRightPadString() {
        assertNull(StringUtils.rightPad(null, 3, "z"));
        assertEquals("batyz", StringUtils.rightPad("bat", 5, "yz"));
        assertEquals("batyzyzy", StringUtils.rightPad("bat", 8, "yz"));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5, (String) null));
    }

    @Test
    public void testCenterDefault() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals(" a  ", StringUtils.center("a", 4));
    }

    @Test
    public void testCenterChar() {
        assertNull(StringUtils.center(null, 4, 'y'));
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    public void testCenterString() {
        assertNull(StringUtils.center(null, 4, " "));
        assertEquals("    ", StringUtils.center("", 4, " "));
        assertEquals("ab", StringUtils.center("ab", -1, " "));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
        // padStr null/empty is treated as a single space, not an error, per the documented examples.
        assertEquals("  a  ", StringUtils.center("a", 5, (String) null));
    }

    // ---------------------------------------------------------------- repeat

    @Test
    public void testRepeatChar() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat('e', -2));
    }

    @Test
    public void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("", 0));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));
    }

    @Test
    public void testRepeatStringWithSeparator() {
        assertNull(StringUtils.repeat(null, null, 2));
        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("", StringUtils.repeat("", null, 0));
        assertEquals("", StringUtils.repeat("", "", 2));
        assertEquals("xx", StringUtils.repeat("", "x", 3));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    // ---------------------------------------------------------------- remove / replace

    @Test
    public void testRemoveChar() {
        assertNull(StringUtils.remove(null, 'u'));
        assertEquals("", StringUtils.remove("", 'u'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("queued", StringUtils.remove("queued", 'z'));
    }

    @Test
    public void testRemoveStringDeprecated() {
        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("", StringUtils.remove("", "ue"));
        assertEquals("queued", StringUtils.remove("queued", (String) null));
        assertEquals("queued", StringUtils.remove("queued", ""));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("queued", StringUtils.remove("queued", "zz"));
    }

    @Test
    public void testRemoveStartChar() {
        assertNull(StringUtils.removeStart(null, '/'));
        assertEquals("", StringUtils.removeStart("", '/'));
        assertEquals("path", StringUtils.removeStart("/path", '/'));
        assertEquals("path", StringUtils.removeStart("path", '/'));
        assertEquals("path", StringUtils.removeStart("path", '\0'));
    }

    @Test
    public void testRemoveStartStringDeprecated() {
        assertNull(StringUtils.removeStart(null, "www."));
        assertEquals("", StringUtils.removeStart("", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", (String) null));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "domain"));
        assertEquals("abc", StringUtils.removeStart("abc", ""));
    }

    @Test
    public void testRemoveEndDeprecated() {
        assertNull(StringUtils.removeEnd(null, ".com"));
        assertEquals("", StringUtils.removeEnd("", ".com"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", (String) null));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", StringUtils.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveIgnoreCaseDeprecated() {
        assertNull(StringUtils.removeIgnoreCase(null, "ue"));
        assertEquals("qd", StringUtils.removeIgnoreCase("queued", "ue"));
        assertEquals("queued", StringUtils.removeIgnoreCase("queued", "zz"));
        assertEquals("qd", StringUtils.removeIgnoreCase("quEUed", "UE"));
    }

    @Test
    public void testRemoveStartIgnoreCaseDeprecated() {
        assertNull(StringUtils.removeStartIgnoreCase(null, "www."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "WWW."));
        assertEquals("www.domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEndIgnoreCaseDeprecated() {
        assertNull(StringUtils.removeEndIgnoreCase(null, ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".COM"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));
    }

    @Test
    public void testReplaceDeprecated() {
        assertNull(StringUtils.replace(null, "a", "z"));
        assertEquals("", StringUtils.replace("", "a", "z"));
        assertEquals("any", StringUtils.replace("any", (String) null, "z"));
        assertEquals("any", StringUtils.replace("any", "a", (String) null));
        assertEquals("any", StringUtils.replace("any", "", "z"));
        assertEquals("aba", StringUtils.replace("aba", "a", (String) null));
        assertEquals("b", StringUtils.replace("aba", "a", ""));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceWithMaxDeprecated() {
        assertNull(StringUtils.replace(null, "a", "z", -1));
        assertEquals("any", StringUtils.replace("any", "a", "z", 0));
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
        assertEquals("zbza", StringUtils.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", StringUtils.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceIgnoreCaseDeprecated() {
        assertNull(StringUtils.replaceIgnoreCase(null, "a", "z"));
        assertEquals("b", StringUtils.replaceIgnoreCase("abA", "A", ""));
    }

    @Test
    public void testReplaceOnceDeprecated() {
        assertNull(StringUtils.replaceOnce(null, "a", "z"));
        assertEquals("", StringUtils.replaceOnce("", "a", "z"));
        assertEquals("any", StringUtils.replaceOnce("any", (String) null, "z"));
        assertEquals("any", StringUtils.replaceOnce("any", "a", (String) null));
        assertEquals("any", StringUtils.replaceOnce("any", "", "z"));
        assertEquals("aba", StringUtils.replaceOnce("aba", "a", (String) null));
        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceIgnoreCaseDeprecated() {
        assertNull(StringUtils.replaceOnceIgnoreCase(null, "a", "z"));
        assertEquals("", StringUtils.replaceOnceIgnoreCase("", "a", "z"));
        assertEquals("zba", StringUtils.replaceOnceIgnoreCase("aba", "a", "z"));
        assertEquals("Foofoo", StringUtils.replaceOnceIgnoreCase("FoOFoofoo", "foo", ""));
    }

    @Test
    public void testReplaceCharsSingle() {
        assertNull(StringUtils.replaceChars(null, 'b', 'y'));
        assertEquals("", StringUtils.replaceChars("", 'b', 'y'));
        assertEquals("aycya", StringUtils.replaceChars("abcba", 'b', 'y'));
        assertEquals("abcba", StringUtils.replaceChars("abcba", 'z', 'y'));
    }

    @Test
    public void testReplaceCharsMultiple() {
        assertNull(StringUtils.replaceChars(null, "bc", "yz"));
        assertEquals("", StringUtils.replaceChars("", "bc", "yz"));
        assertEquals("abc", StringUtils.replaceChars("abc", (String) null, "yz"));
        assertEquals("abc", StringUtils.replaceChars("abc", "", "yz"));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", (String) null));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", ""));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yz"));
        assertEquals("ayya", StringUtils.replaceChars("abcba", "bc", "y"));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yzx"));
    }

    @Test
    public void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] { "a" }, new String[] { "b" }));
        assertEquals("", StringUtils.replaceEach("", new String[] { "a" }, new String[] { "b" }));
        assertEquals("aba", StringUtils.replaceEach("aba", null, null));
        assertEquals("aba", StringUtils.replaceEach("aba", new String[] {}, null));
        assertEquals("aba", StringUtils.replaceEach("aba", new String[] { "a" }, null));
        assertEquals("b", StringUtils.replaceEach("aba", new String[] { "a" }, new String[] { "" }));
        assertEquals("aba", StringUtils.replaceEach("aba", new String[] { null }, new String[] { "a" }));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] { "ab", "d" }, new String[] { "w", "t" }));
        assertEquals("dcte", StringUtils.replaceEach("abcde", new String[] { "ab", "d" }, new String[] { "d", "t" }));
    }

    @Test
    public void testReplaceEachInvalidArrayLengths() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.replaceEach("abcde", new String[] { "ab" }, new String[] { "x", "y" });
            }
        });
    }

    @Test
    public void testReplaceEachRepeatedly() {
        assertNull(StringUtils.replaceEachRepeatedly(null, new String[] { "a" }, new String[] { "b" }));
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] { "ab", "d" }, new String[] { "d", "t" }));
    }

    @Test
    public void testReplaceEachRepeatedlyThrowsOnEndlessLoop() {
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] { "ab", "d" }, new String[] { "d", "ab" });
            }
        });
    }

    // ---------------------------------------------------------------- reverse

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    public void testReverseDelimited() {
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("", StringUtils.reverseDelimited("", '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("a b c", StringUtils.reverseDelimited("a b c", '.'));
    }

    // ---------------------------------------------------------------- rotate

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", -7));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -9));
    }

    // ---------------------------------------------------------------- split

    @Test
    public void testSplitWhitespace() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[] {}, StringUtils.split(""));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc def"));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] { "abc" }, StringUtils.split(" abc "));
    }

    @Test
    public void testSplitChar() {
        assertNull(StringUtils.split(null, '.'));
        assertArrayEquals(new String[] {}, StringUtils.split("", '.'));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[] { "a:b:c" }, StringUtils.split("a:b:c", '.'));
    }

    @Test
    public void testSplitCharSequence() {
        assertNull(StringUtils.split(null, "."));
        assertArrayEquals(new String[] {}, StringUtils.split("", "."));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc def", (String) null));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.split("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitWithMax() {
        assertNull(StringUtils.split(null, ":", 0));
        assertArrayEquals(new String[] {}, StringUtils.split("", ":", 0));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.split("ab:cd:ef", ":", 0));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.split("ab:cd:ef", ":", 2));
    }

    @Test
    public void testSplitPreserveAllTokensWhitespace() {
        assertNull(StringUtils.splitPreserveAllTokens(null));
        assertArrayEquals(new String[] { "", "abc", "" }, StringUtils.splitPreserveAllTokens(" abc "));
    }

    @Test
    public void testSplitPreserveAllTokensChar() {
        assertArrayEquals(new String[] { "a", "", "b", "c" }, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokensCharSequence() {
        assertArrayEquals(new String[] { "a", "", "b", "c" }, StringUtils.splitPreserveAllTokens("a..b.c", "."));
    }

    @Test
    public void testSplitPreserveAllTokensWithMax() {
        assertArrayEquals(new String[] { "a", "..b.c" }, StringUtils.splitPreserveAllTokens("a..b.c", ".", 2));
    }

    @Test
    public void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "."));
        assertArrayEquals(new String[] {}, StringUtils.splitByWholeSeparator("", "."));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.splitByWholeSeparator("ab de fg", null));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByWholeSeparatorWithMax() {
        assertArrayEquals(new String[] { "ab", "cd-!-ef" }, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-", 2));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens() {
        assertNull(StringUtils.splitByWholeSeparatorPreserveAllTokens(null, "."));
        assertArrayEquals(new String[] { "ab", "", "cd", "ef" }, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab--cd-ef", "-"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokensWithMax() {
        assertArrayEquals(new String[] { "ab", "-cd-ef" }, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab--cd-ef", "-", 2));
    }

    @Test
    public void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[] {}, StringUtils.splitByCharacterType(""));
        assertArrayEquals(new String[] { "ab", " ", "de", " ", "fg" }, StringUtils.splitByCharacterType("ab de fg"));
        assertArrayEquals(new String[] { "number", "5" }, StringUtils.splitByCharacterType("number5"));
        assertArrayEquals(new String[] { "foo", "B", "ar" }, StringUtils.splitByCharacterType("fooBar"));
        assertArrayEquals(new String[] { "ASFR", "ules" }, StringUtils.splitByCharacterType("ASFRules"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase() {
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
        assertArrayEquals(new String[] { "foo", "Bar" }, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
    }

    // ---------------------------------------------------------------- join / joinWith

    @Test
    public void testJoinObjectArrayChar() {
        assertNull(StringUtils.join((Object[]) null, ';'));
        assertEquals("", StringUtils.join(new Object[] {}, ';'));
        assertEquals("", StringUtils.join(new Object[] { null }, ';'));
        assertEquals("a;b;c", StringUtils.join(new Object[] { "a", "b", "c" }, ';'));
    }

    @Test
    public void testJoinObjectArrayString() {
        assertNull(StringUtils.join((Object[]) null, "--"));
        assertEquals("a--b--c", StringUtils.join(new Object[] { "a", "b", "c" }, "--"));
        assertEquals("abc", StringUtils.join(new Object[] { "a", "b", "c" }, (String) null));
        assertEquals(",,a", StringUtils.join(new Object[] { null, "", "a" }, ","));
    }

    @Test
    public void testJoinObjectArrayStringWithRange() {
        assertNull(StringUtils.join((Object[]) null, "--", 0, 1));
        assertEquals("", StringUtils.join(new Object[] {}, "--", 0, 0));
        assertEquals("b--c", StringUtils.join(new Object[] { "a", "b", "c" }, "--", 1, 3));
        assertEquals("", StringUtils.join(new Object[] { "a", "b", "c" }, "--", 2, 2));
        assertThrows(ArrayIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.join(new Object[] { "a", "b", "c" }, "--", 0, 4);
            }
        });
    }

    @Test
    public void testJoinVarargs() {
        assertNull(StringUtils.join((Object[]) null));
        assertEquals("", StringUtils.join());
        assertEquals("abc", StringUtils.join("a", "b", "c"));
    }

    @Test
    public void testJoinPrimitiveArrays() {
        assertNull(StringUtils.join((int[]) null, ';'));
        assertEquals("", StringUtils.join(new int[] {}, ';'));
        assertEquals("1;2;3", StringUtils.join(new int[] { 1, 2, 3 }, ';'));

        assertNull(StringUtils.join((boolean[]) null, ';'));
        assertEquals("false;true", StringUtils.join(new boolean[] { false, true }, ';'));

        assertNull(StringUtils.join((char[]) null, ';'));
        assertEquals("a;b", StringUtils.join(new char[] { 'a', 'b' }, ';'));

        assertEquals("2;3", StringUtils.join(new int[] { 1, 2, 3 }, ';', 1, 3));
    }

    @Test
    public void testJoinIterable() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertNull(StringUtils.join((Iterable<?>) null, ','));
        assertEquals("a,b", StringUtils.join((Iterable<?>) list, ','));
        assertEquals("a,b", StringUtils.join((Iterable<?>) list, ","));
    }

    @Test
    public void testJoinIterator() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        Iterator<String> it = list.iterator();
        assertEquals("a,b", StringUtils.join((Iterator<?>) it, ','));
        assertNull(StringUtils.join((Iterator<?>) null, ','));
        assertEquals("", StringUtils.join(new ArrayList<String>().iterator(), ','));
    }

    @Test
    public void testJoinListWithRange() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        assertEquals("a;b;c", StringUtils.join(list, ';', 0, 3));
        assertEquals("b;c", StringUtils.join(list, ';', 1, 3));
        assertNull(StringUtils.join((List<?>) null, ';', 0, 1));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a,b", StringUtils.joinWith(",", "a", "b"));
        assertEquals("a,b,", StringUtils.joinWith(",", "a", "b", ""));
        assertEquals("a,,b", StringUtils.joinWith(",", "a", null, "b"));
        assertEquals("ab", StringUtils.joinWith(null, "a", "b"));
    }

    @Test
    public void testJoinWithThrowsOnNullArray() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    // ---------------------------------------------------------------- case conversion

    @Test
    public void testCapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));
    }

    @Test
    public void testUncapitalize() {
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("cat"));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testUpperCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
    }

    @Test
    public void testUpperCaseLocale() {
        assertNull(StringUtils.upperCase(null, Locale.ENGLISH));
        assertEquals("ABC", StringUtils.upperCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testLowerCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("", StringUtils.lowerCase(""));
        assertEquals("abc", StringUtils.lowerCase("aBc"));
    }

    @Test
    public void testLowerCaseLocale() {
        assertNull(StringUtils.lowerCase(null, Locale.ENGLISH));
        assertEquals("abc", StringUtils.lowerCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testToRootUpperCase() {
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("aBc"));
    }

    @Test
    public void testToRootLowerCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("aBc"));
    }

    // ---------------------------------------------------------------- is* character class checks

    @Test
    public void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));
    }

    @Test
    public void testIsAlphaSpace() {
        assertFalse(StringUtils.isAlphaSpace(null));
        assertTrue(StringUtils.isAlphaSpace(""));
        assertTrue(StringUtils.isAlphaSpace("  "));
        assertTrue(StringUtils.isAlphaSpace("abc"));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2c"));
        assertFalse(StringUtils.isAlphaSpace("ab-c"));
    }

    @Test
    public void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertFalse(StringUtils.isAlphanumeric("  "));
        assertTrue(StringUtils.isAlphanumeric("abc"));
        assertFalse(StringUtils.isAlphanumeric("ab c"));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    public void testIsAlphanumericSpace() {
        assertFalse(StringUtils.isAlphanumericSpace(null));
        assertTrue(StringUtils.isAlphanumericSpace(""));
        assertTrue(StringUtils.isAlphanumericSpace("  "));
        assertTrue(StringUtils.isAlphanumericSpace("abc"));
        assertTrue(StringUtils.isAlphanumericSpace("ab c"));
        assertTrue(StringUtils.isAlphanumericSpace("ab2c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab-c"));
    }

    @Test
    public void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric("  "));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("ab2c"));
        assertFalse(StringUtils.isNumeric("12-3"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertFalse(StringUtils.isNumeric("+123"));
    }

    @Test
    public void testIsNumericSpace() {
        assertFalse(StringUtils.isNumericSpace(null));
        assertTrue(StringUtils.isNumericSpace(""));
        assertTrue(StringUtils.isNumericSpace("  "));
        assertTrue(StringUtils.isNumericSpace("123"));
        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("ab2c"));
    }

    @Test
    public void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace("abc"));
    }

    @Test
    public void testIsAsciiPrintable() {
        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable(" "));
        assertTrue(StringUtils.isAsciiPrintable("Ceki"));
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
        assertFalse(StringUtils.isAsciiPrintable("Ceki Gülcü"));
    }

    @Test
    public void testIsAllLowerCase() {
        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertFalse(StringUtils.isAllLowerCase("  "));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab c"));
        assertFalse(StringUtils.isAllLowerCase("ab1c"));
    }

    @Test
    public void testIsAllUpperCase() {
        assertFalse(StringUtils.isAllUpperCase(null));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));
        assertFalse(StringUtils.isAllUpperCase("A1C"));
    }

    @Test
    public void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase(" "));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
        assertTrue(StringUtils.isMixedCase("A1c"));
    }

    // ---------------------------------------------------------------- default / first-non

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("", StringUtils.defaultString(""));
        assertEquals("bat", StringUtils.defaultString("bat"));
    }

    @Test
    public void testDefaultStringWithDefaultDeprecated() {
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("", StringUtils.defaultString("", "NULL"));
        assertEquals("bat", StringUtils.defaultString("bat", "NULL"));
    }

    @Test
    public void testDefaultIfBlank() {
        assertEquals("NULL", StringUtils.defaultIfBlank((String) null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfBlank("bat", "NULL"));
        assertNull(StringUtils.defaultIfBlank("", (String) null));
    }

    @Test
    public void testDefaultIfEmpty() {
        assertEquals("NULL", StringUtils.defaultIfEmpty((String) null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals(" ", StringUtils.defaultIfEmpty(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfEmpty("bat", "NULL"));
        assertNull(StringUtils.defaultIfEmpty("", (String) null));
    }

    @Test
    public void testGetIfBlank() {
        Supplier<String> nullSupplier = new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        };
        assertEquals("NULL", StringUtils.getIfBlank((String) null, nullSupplier));
        assertEquals("NULL", StringUtils.getIfBlank("", nullSupplier));
        assertEquals("NULL", StringUtils.getIfBlank(" ", nullSupplier));
        assertEquals("bat", StringUtils.getIfBlank("bat", nullSupplier));
        assertNull(StringUtils.getIfBlank("", (Supplier<String>) null));
    }

    @Test
    public void testGetIfEmpty() {
        Supplier<String> nullSupplier = new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        };
        assertEquals("NULL", StringUtils.getIfEmpty((String) null, nullSupplier));
        assertEquals("NULL", StringUtils.getIfEmpty("", nullSupplier));
        assertEquals(" ", StringUtils.getIfEmpty(" ", nullSupplier));
        assertEquals("bat", StringUtils.getIfEmpty("bat", nullSupplier));
        assertNull(StringUtils.getIfEmpty("", (Supplier<String>) null));
    }

    @Test
    public void testFirstNonBlank() {
        assertNull(StringUtils.firstNonBlank((String) null, (String) null, (String) null));
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("abc", StringUtils.firstNonBlank("abc"));
        assertEquals("xyz", StringUtils.firstNonBlank(null, "xyz"));
        assertEquals("xyz", StringUtils.firstNonBlank(null, "", " ", "xyz"));
        assertNull(StringUtils.firstNonBlank());
    }

    @Test
    public void testFirstNonEmpty() {
        assertNull(StringUtils.firstNonEmpty((String) null, (String) null, (String) null));
        assertNull(StringUtils.firstNonEmpty(null, null, ""));
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
        assertEquals("abc", StringUtils.firstNonEmpty("abc"));
        assertEquals("xyz", StringUtils.firstNonEmpty("", "xyz"));
        assertNull(StringUtils.firstNonEmpty());
    }

    // ---------------------------------------------------------------- misc utilities

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    public void testCountMatchesChar() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(0, StringUtils.countMatches("abba", 'x'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'b'));
    }

    @Test
    public void testCountMatchesSubstring() {
        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abba", null));
        assertEquals(0, StringUtils.countMatches("", "ab"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abababa", "aba"));
    }

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", ""));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("", StringUtils.difference("abc", "ab"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "xyz"));
    }

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {}));
        assertEquals("abc", StringUtils.getCommonPrefix(new String[] { "abc" }));
        assertEquals("", StringUtils.getCommonPrefix(new String[] { null, null }));
        assertEquals("", StringUtils.getCommonPrefix(new String[] { "", "abc" }));
        assertEquals("abc", StringUtils.getCommonPrefix(new String[] { "abc", "abc" }));
        assertEquals("a", StringUtils.getCommonPrefix(new String[] { "abc", "a" }));
        assertEquals("ab", StringUtils.getCommonPrefix(new String[] { "ab", "abxyz" }));
        assertEquals("", StringUtils.getCommonPrefix(new String[] { "abcde", "xyz" }));
        assertEquals("i am a ", StringUtils.getCommonPrefix(new String[] { "i am a machine", "i am a robot" }));
    }

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1000", StringUtils.getDigits("1000$"));
        assertEquals("112345", StringUtils.getDigits("1123~45"));
        assertEquals("5417543010", StringUtils.getDigits("(541) 754-3010"));
    }

    @Test
    public void testGetBytesCharset() {
        assertArrayEquals(new byte[0], StringUtils.getBytes(null, (Charset) null));
        assertArrayEquals("abc".getBytes(StandardCharsets.UTF_8), StringUtils.getBytes("abc", StandardCharsets.UTF_8));
    }

    @Test
    public void testGetBytesCharsetName() throws java.io.UnsupportedEncodingException {
        assertArrayEquals(new byte[0], StringUtils.getBytes(null, (String) null));
        assertArrayEquals("abc".getBytes("UTF-8"), StringUtils.getBytes("abc", "UTF-8"));
        assertThrows(java.io.UnsupportedEncodingException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                StringUtils.getBytes("abc", "this-charset-does-not-exist");
            }
        });
    }

    @Test
    public void testToEncodedString() {
        assertEquals("abc", StringUtils.toEncodedString("abc".getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.toEncodedString(null, StandardCharsets.UTF_8);
            }
        });
    }

    @Test
    public void testToStringDeprecated() throws java.io.UnsupportedEncodingException {
        assertEquals("abc", StringUtils.toString("abc".getBytes("UTF-8"), "UTF-8"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                StringUtils.toString(null, "UTF-8");
            }
        });
    }

    @Test
    public void testGetLevenshteinDistanceDeprecated() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
        assertEquals(8, StringUtils.getLevenshteinDistance("hippo", "zzzzzzzz"));
        assertEquals(1, StringUtils.getLevenshteinDistance("hello", "hallo"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance("a", null);
            }
        });
    }

    @Test
    public void testGetLevenshteinDistanceWithThresholdDeprecated() {
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog", 2));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 3));
    }

    @Test
    public void testToCodePoints() {
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[] {}, StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] { 'a', 'b', 'c' }, StringUtils.toCodePoints("abc"));
    }

    @Test
    public void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] { 'a', 'b', 'c' }));
        assertEquals("", StringUtils.valueOf(new char[] {}));
    }

    // ---------------------------------------------------------------- chomp / chop

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc ", StringUtils.chomp("abc \r"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
        assertEquals("abc\n", StringUtils.chomp("abc\n\r"));
        assertEquals("abc\n\rabc", StringUtils.chomp("abc\n\rabc"));
        assertEquals("", StringUtils.chomp("\r"));
        assertEquals("", StringUtils.chomp("\n"));
        assertEquals("", StringUtils.chomp("\r\n"));
    }

    @Test
    public void testChompWithSeparatorDeprecated() {
        assertNull(StringUtils.chomp(null, "x"));
        assertEquals("", StringUtils.chomp("", "x"));
        assertEquals("foo", StringUtils.chomp("foobar", "bar"));
        assertEquals("foobar", StringUtils.chomp("foobar", "baz"));
        assertEquals("", StringUtils.chomp("foo", "foo"));
        assertEquals("foo ", StringUtils.chomp("foo ", "foo"));
        assertEquals(" ", StringUtils.chomp(" foo", "foo"));
        assertEquals("foo", StringUtils.chomp("foo", "foooo"));
        assertEquals("foo", StringUtils.chomp("foo", ""));
        assertEquals("foo", StringUtils.chomp("foo", (String) null));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc ", StringUtils.chop("abc \r"));
        assertEquals("abc", StringUtils.chop("abc\n"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("abc\nab", StringUtils.chop("abc\nabc"));
        assertEquals("", StringUtils.chop("a"));
        assertEquals("", StringUtils.chop("\r"));
        assertEquals("", StringUtils.chop("\n"));
        assertEquals("", StringUtils.chop("\r\n"));
    }

    // ---------------------------------------------------------------- abbreviate / abbreviateMiddle / truncate

    @Test
    public void testAbbreviateTwoArg() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testAbbreviateThreeArgOffset() {
        assertNull(StringUtils.abbreviate(null, 5, 10));
        assertEquals("", StringUtils.abbreviate("", 0, 4));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", -1, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 0, 10));
        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 8, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 10, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 12, 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefghij", 0, 3);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefghij", 5, 6);
            }
        });
    }

    @Test
    public void testAbbreviateMarker() {
        assertNull(StringUtils.abbreviate(null, "...", 4));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", (String) null, 4));
        assertEquals("", StringUtils.abbreviate("", "...", 4));
        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", ".", 7));
        assertEquals("ab..", StringUtils.abbreviate("abcdefg", "..", 4));
        assertEquals("a..", StringUtils.abbreviate("abcdefg", "..", 3));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", "..", 2);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", "...", 3);
            }
        });
    }

    @Test
    public void testAbbreviateMarkerOffset() {
        assertNull(StringUtils.abbreviate(null, null, 5, 10));
        assertEquals("abcdefghijklmno", StringUtils.abbreviate("abcdefghijklmno", (String) null, 5, 10));
        assertEquals("", StringUtils.abbreviate("", "...", 0, 4));
        assertEquals("abcdefg---", StringUtils.abbreviate("abcdefghijklmno", "---", -1, 10));
        assertEquals("abcdefghi,", StringUtils.abbreviate("abcdefghijklmno", ",", 0, 10));
        assertEquals("::efghij::", StringUtils.abbreviate("abcdefghijklmno", "::", 4, 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefghij", "abra", 0, 4);
            }
        });
    }

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    public void testTruncateTwoArg() {
        assertNull(StringUtils.truncate(null, 0));
        assertNull(StringUtils.truncate(null, 2));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdef", StringUtils.truncate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 8));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    public void testTruncateThreeArg() {
        assertNull(StringUtils.truncate(null, 0, 0));
        assertNull(StringUtils.truncate(null, 2, 4));
        assertEquals("", StringUtils.truncate("", 0, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghijklmno", 0, 10));
        assertEquals("bcdefghijk", StringUtils.truncate("abcdefghijklmno", 1, 10));
        assertEquals("klm", StringUtils.truncate("abcdefghijklmno", 10, 3));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghijklmno", -1, 10);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghij", 3, -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghij", -2, 4);
            }
        });
    }

    // ---------------------------------------------------------------- overlay

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, "x", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abef", StringUtils.overlay("abcdef", "", 4, 2));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("abzzzz", StringUtils.overlay("abcdef", "zzzz", 2, 8));
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    // ---------------------------------------------------------------- wrap / unwrap

    @Test
    public void testWrapChar() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("'ab'", StringUtils.wrap("ab", '\''));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", '\"'));
    }

    @Test
    public void testWrapString() {
        assertNull(StringUtils.wrap(null, "x"));
        assertEquals("", StringUtils.wrap("", "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("\"ab\"", StringUtils.wrap("ab", "\""));
        assertEquals("'ab'", StringUtils.wrap("ab", "'"));
        assertEquals("''abcd''", StringUtils.wrap("'abcd'", "'"));
    }

    @Test
    public void testWrapIfMissingChar() {
        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("", StringUtils.wrapIfMissing("", 'x'));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", '\0'));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", 'x'));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", '\"'));
        assertEquals("/", StringUtils.wrapIfMissing("/", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("/a/b/c", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c/", '/'));
    }

    @Test
    public void testWrapIfMissingString() {
        assertNull(StringUtils.wrapIfMissing(null, "x"));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", (String) null));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", "x"));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", "\""));
        assertEquals("'abcd'", StringUtils.wrapIfMissing("'abcd'", "'"));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", "/"));
    }

    @Test
    public void testUnwrapChar() {
        assertNull(StringUtils.unwrap(null, '1'));
        assertEquals("a", StringUtils.unwrap("a", 'a'));
        assertEquals("", StringUtils.unwrap("aa", 'a'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("ABabcBA", StringUtils.unwrap("AABabcBAA", 'A'));
        assertEquals("A", StringUtils.unwrap("A", '#'));
        assertEquals("#A", StringUtils.unwrap("#A", '#'));
        assertEquals("A#", StringUtils.unwrap("A#", '#'));
    }

    @Test
    public void testUnwrapString() {
        assertNull(StringUtils.unwrap(null, "1"));
        assertEquals("a", StringUtils.unwrap("a", "a"));
        assertEquals("", StringUtils.unwrap("aa", "a"));
        assertEquals("abc", StringUtils.unwrap("'abc'", "'"));
        assertEquals("BabcB", StringUtils.unwrap("AABabcBAA", "AA"));
        assertEquals("A", StringUtils.unwrap("A", "#"));
        assertEquals("#A", StringUtils.unwrap("#A", "#"));
        assertEquals("A#", StringUtils.unwrap("A#", "#"));
    }

    // ---------------------------------------------------------------- appendIfMissing / prependIfMissing

    @Test
    public void testAppendIfMissingDeprecated() {
        assertNull(StringUtils.appendIfMissing(null, null));
        assertEquals("abc", StringUtils.appendIfMissing("abc", null));
        assertEquals("xyz", StringUtils.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", StringUtils.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissingWithAdditionalSuffixesDeprecated() {
        assertEquals("abc", StringUtils.appendIfMissing("abc", null, (CharSequence[]) null));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz", new CharSequence[] { null }));
        assertEquals("abc", StringUtils.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcmno", StringUtils.appendIfMissing("abcmno", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissingIgnoreCaseDeprecated() {
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));
        assertEquals("abcMNO", StringUtils.appendIfMissingIgnoreCase("abcMNO", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingDeprecated() {
        assertNull(StringUtils.prependIfMissing(null, null));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", StringUtils.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingIgnoreCaseDeprecated() {
        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }
}
