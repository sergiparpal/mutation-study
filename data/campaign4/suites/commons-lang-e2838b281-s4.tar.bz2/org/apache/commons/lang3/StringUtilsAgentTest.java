package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained JUnit 5 tests for {@link StringUtils}, based solely on the documented contract.
 */
public class StringUtilsAgentTest {

    // ------------------------------------------------------------------
    // Fields
    // ------------------------------------------------------------------

    @Test
    public void testFields() {
        assertEquals("", StringUtils.EMPTY);
        assertEquals("\r", StringUtils.CR);
        assertEquals("\n", StringUtils.LF);
        assertEquals(" ", StringUtils.SPACE);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }

    // ------------------------------------------------------------------
    // isEmpty / isNotEmpty / isBlank / isNotBlank
    // ------------------------------------------------------------------

    @Test
    public void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));
        assertFalse(StringUtils.isEmpty("  bob  "));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));
        assertTrue(StringUtils.isNotEmpty("bob"));
    }

    @Test
    public void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));
    }

    @Test
    public void testIsNotBlank() {
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(""));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
        assertTrue(StringUtils.isNotBlank("  bob  "));
    }

    @Test
    public void testIsAnyAllNoneBlankEmpty() {
        assertTrue(StringUtils.isAnyBlank((CharSequence) null));
        assertFalse(StringUtils.isAnyBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAnyBlank(null, "foo"));
        assertTrue(StringUtils.isAnyBlank("", "bar"));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));

        assertTrue(StringUtils.isAnyEmpty((CharSequence) null));
        assertFalse(StringUtils.isAnyEmpty((CharSequence[]) null));
        assertTrue(StringUtils.isAnyEmpty(null, "foo"));
        assertFalse(StringUtils.isAnyEmpty(" ", "bar"));

        assertTrue(StringUtils.isAllBlank(null, null));
        assertFalse(StringUtils.isAllBlank(null, "foo"));
        assertTrue(StringUtils.isAllBlank(new String[] {}));

        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "foo"));

        assertFalse(StringUtils.isNoneBlank((CharSequence) null));
        assertTrue(StringUtils.isNoneBlank((CharSequence[]) null));
        assertTrue(StringUtils.isNoneBlank("foo", "bar"));

        assertFalse(StringUtils.isNoneEmpty((CharSequence) null));
        assertTrue(StringUtils.isNoneEmpty((CharSequence[]) null));
        assertTrue(StringUtils.isNoneEmpty(" ", "bar"));
    }

    // ------------------------------------------------------------------
    // trim / strip family
    // ------------------------------------------------------------------

    @Test
    public void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("abc"));
        assertEquals("abc", StringUtils.trim("    abc    "));
    }

    @Test
    public void testTrimToNullAndEmpty() {
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull(""));
        assertNull(StringUtils.trimToNull("     "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("     "));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));
    }

    @Test
    public void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("ab c", StringUtils.strip(" ab c "));
    }

    @Test
    public void testStripWithChars() {
        assertNull(StringUtils.strip(null, "xyz"));
        assertEquals("", StringUtils.strip("", "xyz"));
        assertEquals("abc", StringUtils.strip("abc", null));
        assertEquals("  abc", StringUtils.strip("  abcyx", "xyz"));
    }

    @Test
    public void testStripStartEnd() {
        assertNull(StringUtils.stripStart(null, "xyz"));
        assertEquals("abc  ", StringUtils.stripStart("abc  ", null));
        assertEquals("abc  ", StringUtils.stripStart("yxabc  ", "xyz"));

        assertNull(StringUtils.stripEnd(null, "xyz"));
        assertEquals("  abc", StringUtils.stripEnd("  abc", null));
        assertEquals("12", StringUtils.stripEnd("120.00", ".0"));
    }

    @Test
    public void testStripToNullAndEmpty() {
        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull(" abc "));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));
        assertEquals("abc", StringUtils.stripToEmpty(" abc "));
    }

    @Test
    public void testStripAll() {
        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {}, StringUtils.stripAll(new String[] {}));
        assertArrayEquals(new String[] {"abc", "abc"}, StringUtils.stripAll("abc", "  abc"));
        assertArrayEquals(new String[] {"abc", null}, StringUtils.stripAll("abc  ", null));
    }

    @Test
    public void testStripAllWithChars() {
        assertNull(StringUtils.stripAll(null, "xyz"));
        assertArrayEquals(new String[] {}, StringUtils.stripAll(new String[] {}, "xyz"));
        assertArrayEquals(new String[] {"abc  ", null}, StringUtils.stripAll(new String[] {"abc  ", null}, "yz"));
        assertArrayEquals(new String[] {"abc", null}, StringUtils.stripAll(new String[] {"yabcz", null}, "yz"));
    }

    @Test
    public void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    // ------------------------------------------------------------------
    // equals / compare family
    // ------------------------------------------------------------------

    @Test
    public void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    public void testEqualsAny() {
        assertFalse(StringUtils.equalsAny(null, (CharSequence[]) null));
        assertTrue(StringUtils.equalsAny(null, null, null));
        assertFalse(StringUtils.equalsAny(null, "abc", "def"));
        assertTrue(StringUtils.equalsAny("abc", "abc", "def"));
        assertFalse(StringUtils.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAnyIgnoreCase() {
        assertFalse(StringUtils.equalsAnyIgnoreCase(null, (CharSequence[]) null));
        assertTrue(StringUtils.equalsAnyIgnoreCase(null, null, null));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "ABC", "DEF"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", null, "def"));
    }

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertTrue(StringUtils.compare("a", "B") > 0);
    }

    @Test
    public void testCompareWithNullIsLess() {
        assertEquals(0, StringUtils.compare(null, null, true));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);
    }

    @Test
    public void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase(null, null));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
    }

    @Test
    public void testCompareIgnoreCaseWithNullIsLess() {
        assertEquals(0, StringUtils.compareIgnoreCase(null, null, true));
        assertTrue(StringUtils.compareIgnoreCase(null, "a", false) > 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC", true));
    }

    // ------------------------------------------------------------------
    // contains family
    // ------------------------------------------------------------------

    @Test
    public void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("a", null));
        assertTrue(StringUtils.contains("", ""));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsChar() {
        assertFalse(StringUtils.contains(null, 'a'));
        assertFalse(StringUtils.contains("", 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContainsAny() {
        assertFalse(StringUtils.containsAny(null, 'z', 'a'));
        assertFalse(StringUtils.containsAny("", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertFalse(StringUtils.containsAny("abc", new char[] {}));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("aba", 'z'));
    }

    @Test
    public void testContainsAnyCharSequence() {
        assertFalse(StringUtils.containsAny(null, "za"));
        assertFalse(StringUtils.containsAny("", "za"));
        assertFalse(StringUtils.containsAny("abc", (CharSequence) null));
        assertFalse(StringUtils.containsAny("abc", ""));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));
        assertFalse(StringUtils.containsAny("aba", "z"));
    }

    @Test
    public void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));
    }

    @Test
    public void testContainsAnyIgnoreCase() {
        assertFalse(StringUtils.containsAnyIgnoreCase(null, "abc"));
        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "D", "ABC"));
        assertTrue(StringUtils.containsAnyIgnoreCase("ABC", "d", "abc"));
    }

    @Test
    public void testContainsNone() {
        assertTrue(StringUtils.containsNone(null, 'x', 'y'));
        assertTrue(StringUtils.containsNone("ab1", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abz", 'x', 'y', 'z'));

        assertTrue(StringUtils.containsNone(null, "xyz"));
        assertTrue(StringUtils.containsNone("ab1", "xyz"));
        assertFalse(StringUtils.containsNone("abz", "xyz"));
    }

    @Test
    public void testContainsOnly() {
        assertFalse(StringUtils.containsOnly(null, 'a', 'b'));
        assertTrue(StringUtils.containsOnly("", 'a', 'b'));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("ab1", 'a', 'b', 'c'));

        assertFalse(StringUtils.containsOnly(null, "abc"));
        assertTrue(StringUtils.containsOnly("", "abc"));
        assertTrue(StringUtils.containsOnly("abab", "abc"));
        assertFalse(StringUtils.containsOnly("ab1", "abc"));
    }

    @Test
    public void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace(""));
        assertFalse(StringUtils.containsWhitespace("ab"));
        assertTrue(StringUtils.containsWhitespace(" ab"));
        assertTrue(StringUtils.containsWhitespace("a b"));
    }

    // ------------------------------------------------------------------
    // indexOf family
    // ------------------------------------------------------------------

    @Test
    public void testIndexOfCharSequence() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("a", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(-1, StringUtils.indexOf("", "a"));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOfCharSequenceWithStart() {
        assertEquals(-1, StringUtils.indexOf(null, "a", 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", "b", 9));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", -1));
        assertEquals(3, StringUtils.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfChar() {
        assertEquals(-1, StringUtils.indexOf(null, 'a'));
        assertEquals(-1, StringUtils.indexOf("", 'a'));
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
        assertEquals(-1, StringUtils.indexOf("aaaaaaaa", 'Z'));
    }

    @Test
    public void testIndexOfCharWithStart() {
        assertEquals(-1, StringUtils.indexOf(null, 'b', 0));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", 'b', 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", 'b', 9));
    }

    @Test
    public void testIndexOfAnyChars() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("aba", 'z'));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 'b', 'y'));
    }

    @Test
    public void testIndexOfAnyCharSequences() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, "ab"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", "mn", "op"));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", ""));
    }

    @Test
    public void testIndexOfAnyWithStart() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 0, 'z', 'a'));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 0, 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 0, 'b', 'y'));
    }

    @Test
    public void testIndexOfAnyString() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, "za"));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", "za"));
        assertEquals(-1, StringUtils.indexOfAny("aba", "z"));
    }

    @Test
    public void testIndexOfAnyBut() {
        assertEquals(-1, StringUtils.indexOfAnyBut(null, 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));

        assertEquals(-1, StringUtils.indexOfAnyBut((CharSequence) null, "za"));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", "ab"));
    }

    @Test
    public void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] {}));
        assertEquals(-1, StringUtils.indexOfDifference("abc"));
        assertEquals(0, StringUtils.indexOfDifference("", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("ab", "abxyz"));
        assertEquals(7, StringUtils.indexOfDifference("i am a machine", "i am a robot"));

        assertEquals(-1, StringUtils.indexOfDifference(null, null));
        assertEquals(0, StringUtils.indexOfDifference("abc", ""));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
    }

    @Test
    public void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("", ""));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "ab"));

        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a", 0));
        assertEquals(5, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 3));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("abc", "", 9));
    }

    // ------------------------------------------------------------------
    // Character-class checks
    // ------------------------------------------------------------------

    @Test
    public void testIsAllLowerCaseUpperCase() {
        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));
    }

    @Test
    public void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
    }

    @Test
    public void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab c"));
    }

    @Test
    public void testIsAlphanumericSpace() {
        assertFalse(StringUtils.isAlphanumericSpace(null));
        assertTrue(StringUtils.isAlphanumericSpace(""));
        assertTrue(StringUtils.isAlphanumericSpace("ab c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab-c"));
    }

    @Test
    public void testIsAlphaSpace() {
        assertFalse(StringUtils.isAlphaSpace(null));
        assertTrue(StringUtils.isAlphaSpace(""));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2c"));
    }

    @Test
    public void testIsAsciiPrintable() {
        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
        assertFalse(StringUtils.isAsciiPrintable("Ceki Gülcü"));
    }

    @Test
    public void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    @Test
    public void testIsNumericAndNumericSpace() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertFalse(StringUtils.isNumeric("12.3"));

        assertFalse(StringUtils.isNumericSpace(null));
        assertTrue(StringUtils.isNumericSpace(""));
        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("12.3"));
    }

    @Test
    public void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace("abc"));
    }

    // ------------------------------------------------------------------
    // join family
    // ------------------------------------------------------------------

    @Test
    public void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[] {}, ','));
        assertEquals("", StringUtils.join(new Object[] {null}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
    }

    @Test
    public void testJoinObjectArrayWithRange() {
        assertNull(StringUtils.join((Object[]) null, ',', 0, 1));
        assertEquals("b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ',', 1, 3));
        assertEquals("", StringUtils.join(new Object[] {"a", "b", "c"}, ',', 1, 1));
    }

    @Test
    public void testJoinVarargs() {
        assertNull(StringUtils.join((Object[]) null));
        assertEquals("", StringUtils.join());
        assertEquals("", StringUtils.join((Object) null));
        assertEquals("abc", StringUtils.join("a", "b", "c"));
    }

    @Test
    public void testJoinIterableAndIterator() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        assertEquals("a,b,c", StringUtils.join((Iterable<?>) list, ','));
        assertEquals("a,b,c", StringUtils.join((Iterable<?>) list, ","));

        Iterator<String> it = list.iterator();
        assertEquals("a,b,c", StringUtils.join(it, ','));

        Iterator<String> it2 = list.iterator();
        assertEquals("a,b,c", StringUtils.join(it2, ","));

        assertNull(StringUtils.join((Iterator<?>) null, ','));
    }

    @Test
    public void testJoinPrimitiveArrays() {
        assertNull(StringUtils.join((int[]) null, ';'));
        assertEquals("", StringUtils.join(new int[] {}, ';'));
        assertEquals("1;2;3", StringUtils.join(new int[] {1, 2, 3}, ';'));

        assertNull(StringUtils.join((boolean[]) null, ';'));
        assertEquals("", StringUtils.join(new boolean[] {}, ';'));
        assertEquals("false;false", StringUtils.join(new boolean[] {false, false}, ';'));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a,b", StringUtils.joinWith(",", "a", "b"));
        assertEquals("a,b,", StringUtils.joinWith(",", "a", "b", ""));
        assertEquals("a,,b", StringUtils.joinWith(",", "a", null, "b"));
        assertEquals("ab", StringUtils.joinWith(null, "a", "b"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    // ------------------------------------------------------------------
    // lastIndexOf family
    // ------------------------------------------------------------------

    @Test
    public void testLastIndexOfCharSequence() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(0, StringUtils.lastIndexOf("", ""));
        assertEquals(4, StringUtils.lastIndexOf("aabaabaa", "ab"));
    }

    @Test
    public void testLastIndexOfCharSequenceWithStart() {
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", "b", -1));
    }

    @Test
    public void testLastIndexOfChar() {
        assertEquals(-1, StringUtils.lastIndexOf(null, 'a'));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b'));
    }

    @Test
    public void testLastIndexOfCharWithStart() {
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b', 8));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", 'b', 4));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", 'b', 0));
    }

    @Test
    public void testLastIndexOfAny() {
        assertEquals(-1, StringUtils.lastIndexOfAny(null, "ab"));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", "mn", "op"));
    }

    @Test
    public void testLastIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase(null, "A"));
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(4, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "AB", 8));
    }

    @Test
    public void testLastOrdinalIndexOf() {
        assertEquals(-1, StringUtils.lastOrdinalIndexOf(null, "a", 1));
        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
        assertEquals(1, StringUtils.lastOrdinalIndexOf("aabaabaa", "ab", 2));
    }

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "ab", 2));
    }

    // ------------------------------------------------------------------
    // left / right / mid / pad / length
    // ------------------------------------------------------------------

    @Test
    public void testLeftRightMid() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));

        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    @Test
    public void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", 1));

        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));

        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));
        assertEquals("yzyzybat", StringUtils.leftPad("bat", 8, "yz"));
        assertEquals("  bat", StringUtils.leftPad("bat", 5, (String) null));
        assertEquals("  bat", StringUtils.leftPad("bat", 5, ""));
    }

    @Test
    public void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("   ", StringUtils.rightPad("", 3));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));

        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));

        assertEquals("batyz", StringUtils.rightPad("bat", 5, "yz"));
        assertEquals("batyzyzy", StringUtils.rightPad("bat", 8, "yz"));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5, (String) null));
    }

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals(" a  ", StringUtils.center("a", 4));

        assertEquals("yayy", StringUtils.center("a", 4, 'y'));

        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
    }

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    // ------------------------------------------------------------------
    // case conversion
    // ------------------------------------------------------------------

    @Test
    public void testLowerUpperCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("aBc"));
        assertEquals("abc", StringUtils.lowerCase("aBc", Locale.ENGLISH));

        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
        assertEquals("ABC", StringUtils.upperCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testCapitalizeUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testToRootLowerUpperCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));

        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    // ------------------------------------------------------------------
    // normalizeSpace / overlay / rotate
    // ------------------------------------------------------------------

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
    }

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
    }

    // ------------------------------------------------------------------
    // prepend / append if missing
    // ------------------------------------------------------------------

    @Test
    public void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, null));
        assertEquals("abc", StringUtils.appendIfMissing("abc", null));
        assertEquals("xyz", StringUtils.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", StringUtils.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abcmno", StringUtils.appendIfMissing("abcmno", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissingIgnoreCase() {
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));
        assertEquals("abc", StringUtils.appendIfMissingIgnoreCase("abc", null));
    }

    @Test
    public void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, null));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", StringUtils.prependIfMissing("XYZabc", "xyz"));
        assertEquals("mnoabc", StringUtils.prependIfMissing("mnoabc", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingIgnoreCase() {
        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }

    // ------------------------------------------------------------------
    // remove family
    // ------------------------------------------------------------------

    @Test
    public void testRemoveChar() {
        assertNull(StringUtils.remove(null, 'u'));
        assertEquals("", StringUtils.remove("", 'u'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("queued", StringUtils.remove("queued", 'z'));
    }

    @Test
    public void testRemoveString() {
        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("", StringUtils.remove("", "ue"));
        assertEquals("queued", StringUtils.remove("queued", (String) null));
        assertEquals("queued", StringUtils.remove("queued", ""));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
    }

    @Test
    public void testRemoveAllAndFirstAndPattern() {
        assertNull(StringUtils.removeAll(null, ".*"));
        assertEquals("any", StringUtils.removeAll("any", (String) null));
        assertEquals("", StringUtils.removeAll("any", ".*"));
        assertEquals("ABC123", StringUtils.removeAll("ABCabc123", "[a-z]"));

        assertNull(StringUtils.removeFirst(null, ".*"));
        assertEquals("bc", StringUtils.removeFirst("abc", ".?"));

        assertEquals("AB", StringUtils.removePattern("A<__>\n<__>B", "<.*>"));
    }

    @Test
    public void testRemoveEndAndStart() {
        assertNull(StringUtils.removeEnd(null, "x"));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", "domain"));

        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));

        assertNull(StringUtils.removeStart(null, '/'));
        assertEquals("path", StringUtils.removeStart("/path", '/'));
        assertEquals("path", StringUtils.removeStart("path", '/'));

        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "WWW."));
    }

    @Test
    public void testRemoveIgnoreCase() {
        assertNull(StringUtils.removeIgnoreCase(null, "ue"));
        assertEquals("qd", StringUtils.removeIgnoreCase("quEUed", "UE"));
        assertEquals("queued", StringUtils.removeIgnoreCase("queued", "zZ"));
    }

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("abc", StringUtils.deleteWhitespace("   ab  c  "));
    }

    // ------------------------------------------------------------------
    // repeat
    // ------------------------------------------------------------------

    @Test
    public void testRepeatChar() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat('e', -2));
    }

    @Test
    public void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("", StringUtils.repeat("a", -2));
    }

    @Test
    public void testRepeatWithSeparator() {
        assertNull(StringUtils.repeat(null, null, 2));
        assertEquals("", StringUtils.repeat("", null, 0));
        assertEquals("xx", StringUtils.repeat("", "x", 3));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    // ------------------------------------------------------------------
    // replace family
    // ------------------------------------------------------------------

    @Test
    public void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", (String) null, "b"));
        assertEquals("aba", StringUtils.replace("aba", "a", (String) null));
        assertEquals("b", StringUtils.replace("aba", "a", ""));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceWithMax() {
        assertEquals("abaa", StringUtils.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
        assertEquals("zbza", StringUtils.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", StringUtils.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceIgnoreCase() {
        assertEquals("b", StringUtils.replaceIgnoreCase("abA", "A", ""));
        assertEquals("zbz", StringUtils.replaceIgnoreCase("aba", "A", "z"));
        assertEquals("zbza", StringUtils.replaceIgnoreCase("abAa", "a", "z", 2));
    }

    @Test
    public void testReplaceOnce() {
        assertNull(StringUtils.replaceOnce(null, "a", "b"));
        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceIgnoreCase() {
        assertEquals("Foofoo", StringUtils.replaceOnceIgnoreCase("FoOFoofoo", "foo", ""));
    }

    @Test
    public void testReplaceAllAndFirstAndPatternRegex() {
        assertNull(StringUtils.replaceAll(null, "x", "y"));
        assertEquals("ABC_123", StringUtils.replaceAll("ABCabc123", "[a-z]", "_"));
        assertEquals("ABC_bc123", StringUtils.replaceFirst("ABCabc123", "[a-z]", "_"));
        assertEquals("AB", StringUtils.replacePattern("A<__>\n<__>B", "<.*>", ""));
    }

    @Test
    public void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, 'b', 'y'));
        assertEquals("aycya", StringUtils.replaceChars("abcba", 'b', 'y'));
        assertEquals("abcba", StringUtils.replaceChars("abcba", 'z', 'y'));

        assertNull(StringUtils.replaceChars(null, "bc", "yz"));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", null));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yzx"));
    }

    @Test
    public void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, null, null));
        assertEquals("aba", StringUtils.replaceEach("aba", null, null));
        assertEquals("b", StringUtils.replaceEach("aba", new String[] {"a"}, new String[] {""}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("dcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
    }

    @Test
    public void testReplaceEachRepeatedly() {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "ab"});
            }
        });
    }

    // ------------------------------------------------------------------
    // reverse
    // ------------------------------------------------------------------

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("tab", StringUtils.reverse("bat"));
    }

    @Test
    public void testReverseDelimited() {
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("", StringUtils.reverseDelimited("", '.'));
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    // ------------------------------------------------------------------
    // split family
    // ------------------------------------------------------------------

    @Test
    public void testSplitWhitespace() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[] {}, StringUtils.split(""));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] {"abc"}, StringUtils.split(" abc "));
    }

    @Test
    public void testSplitChar() {
        assertNull(StringUtils.split(null, '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[] {"a:b:c"}, StringUtils.split("a:b:c", '.'));
    }

    @Test
    public void testSplitChars() {
        assertNull(StringUtils.split(null, "sep"));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc def", (String) null));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitCharsWithMax() {
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":", 0));
    }

    @Test
    public void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[] {"foo", "B", "ar"}, StringUtils.splitByCharacterType("fooBar"));
        assertArrayEquals(new String[] {"foo", "200", "B", "ar"}, StringUtils.splitByCharacterType("foo200Bar"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase() {
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
        assertArrayEquals(new String[] {"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] {"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    public void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "-!-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab   de fg", null));
    }

    @Test
    public void testSplitByWholeSeparatorWithMax() {
        assertArrayEquals(new String[] {"ab", "cd-!-ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-", 2));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens() {
        assertNull(StringUtils.splitByWholeSeparatorPreserveAllTokens(null, "-!-"));
        assertArrayEquals(new String[] {"ab", "", "", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab   de fg", null));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokensWithMax() {
        assertArrayEquals(new String[] {"ab", "cd-!-ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!-cd-!-ef", "-!-", 2));
    }

    @Test
    public void testSplitPreserveAllTokens() {
        assertNull(StringUtils.splitPreserveAllTokens(null));
        assertArrayEquals(new String[] {"abc", "", "def"}, StringUtils.splitPreserveAllTokens("abc  def"));
        assertArrayEquals(new String[] {"", "abc", ""}, StringUtils.splitPreserveAllTokens(" abc "));
    }

    @Test
    public void testSplitPreserveAllTokensChar() {
        assertNull(StringUtils.splitPreserveAllTokens(null, '.'));
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokensCharsWithMax() {
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":", 2));
    }

    // ------------------------------------------------------------------
    // startsWith / endsWith family
    // ------------------------------------------------------------------

    @Test
    public void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAny() {
        assertFalse(StringUtils.startsWithAny(null, (CharSequence[]) null));
        assertTrue(StringUtils.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    @Test
    public void testStartsWithIgnoreCase() {
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
        assertFalse(StringUtils.startsWithIgnoreCase("abcdef", null));
    }

    @Test
    public void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
    }

    @Test
    public void testEndsWithAny() {
        assertFalse(StringUtils.endsWithAny(null, (CharSequence) null));
        assertTrue(StringUtils.endsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertTrue(StringUtils.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(StringUtils.endsWithAny("abcXYZ", "def", "xyz"));
    }

    @Test
    public void testEndsWithIgnoreCase() {
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertFalse(StringUtils.endsWithIgnoreCase("ABCDEF", "cde"));
    }

    // ------------------------------------------------------------------
    // substring family
    // ------------------------------------------------------------------

    @Test
    public void testSubstringStart() {
        assertNull(StringUtils.substring(null, 2));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("c", StringUtils.substring("abc", 2));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", -2));
        assertEquals("abc", StringUtils.substring("abc", -4));
    }

    @Test
    public void testSubstringStartEnd() {
        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("", StringUtils.substring("abc", 2, 2));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    public void testSubstringAfterAndBefore() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "x"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("abc", StringUtils.substringAfter("abc", ""));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));
        assertEquals("", StringUtils.substringBefore("abc", ""));
    }

    @Test
    public void testSubstringAfterAndBeforeChar() {
        assertNull(StringUtils.substringAfter(null, 'a'));
        assertEquals("bc", StringUtils.substringAfter("abc", 'a'));
        assertEquals("", StringUtils.substringAfter("abc", 'd'));

        assertNull(StringUtils.substringBefore(null, 'a'));
        assertEquals("", StringUtils.substringBefore("abc", 'a'));
        assertEquals("abc", StringUtils.substringBefore("abc", 'd'));
    }

    @Test
    public void testSubstringAfterLastAndBeforeLast() {
        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("a", "a"));
        assertEquals("", StringUtils.substringAfterLast("a", "z"));
        assertEquals("", StringUtils.substringAfterLast("", "z"));
        assertEquals("", StringUtils.substringAfterLast("abc", ""));

        assertNull(StringUtils.substringBeforeLast(null, "b"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("", StringUtils.substringBeforeLast("a", "a"));
        assertEquals("a", StringUtils.substringBeforeLast("a", "z"));
        assertEquals("a", StringUtils.substringBeforeLast("a", (String) null));
    }

    @Test
    public void testSubstringAfterLastAndBeforeLastChar() {
        assertNull(StringUtils.substringAfterLast(null, 'a'));
        assertEquals("a", StringUtils.substringAfterLast("abcba", 'b'));
        assertEquals("", StringUtils.substringAfterLast("a", 'a'));
        assertEquals("", StringUtils.substringAfterLast("a", 'z'));
    }

    @Test
    public void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));

        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertNull(StringUtils.substringBetween(null, "[", "]"));
        assertEquals("", StringUtils.substringBetween("yabcz", "", ""));
        assertEquals("abc", StringUtils.substringBetween("yabczyabcz", "y", "z"));
    }

    @Test
    public void testSubstringsBetween() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[] {}, StringUtils.substringsBetween("", "[", "]"));
    }

    // ------------------------------------------------------------------
    // toCodePoints / toEncodedString / toString
    // ------------------------------------------------------------------

    @Test
    public void testToCodePoints() {
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[] {}, StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
    }

    @Test
    public void testToEncodedString() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                StringUtils.toEncodedString(null, StandardCharsets.UTF_8);
            }
        });
        assertEquals("abc", StringUtils.toEncodedString(new byte[] {'a', 'b', 'c'}, StandardCharsets.UTF_8));
        assertEquals("abc", StringUtils.toEncodedString(new byte[] {'a', 'b', 'c'}, StandardCharsets.US_ASCII));
    }

    @Test
    public void testToStringByteArray() throws UnsupportedEncodingException {
        assertEquals("abc", StringUtils.toString(new byte[] {'a', 'b', 'c'}, "UTF-8"));
    }

    @Test
    public void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    // ------------------------------------------------------------------
    // truncate / unwrap / wrap
    // ------------------------------------------------------------------

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 0));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 8));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    public void testTruncateWithOffset() {
        assertNull(StringUtils.truncate(null, 2, 4));
        assertEquals("", StringUtils.truncate("", 2, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghijklmno", -1, 10);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghij", 3, -1);
            }
        });
    }

    @Test
    public void testUnwrapChar() {
        assertNull(StringUtils.unwrap(null, 'a'));
        assertEquals("a", StringUtils.unwrap("a", 'a'));
        assertEquals("", StringUtils.unwrap("aa", 'a'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("A", StringUtils.unwrap("A", '#'));
        assertEquals("#A", StringUtils.unwrap("#A", '#'));
    }

    @Test
    public void testUnwrapString() {
        assertNull(StringUtils.unwrap(null, "1"));
        assertEquals("a", StringUtils.unwrap("a", "a"));
        assertEquals("", StringUtils.unwrap("aa", "a"));
        assertEquals("BabcB", StringUtils.unwrap("AABabcBAA", "AA"));
        assertEquals("A", StringUtils.unwrap("A", "#"));
    }

    @Test
    public void testWrapChar() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", '\"'));
    }

    @Test
    public void testWrapString() {
        assertNull(StringUtils.wrap(null, "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("''abcd''", StringUtils.wrap("'abcd'", "'"));
    }

    @Test
    public void testWrapIfMissingChar() {
        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", 'x'));
        assertEquals("/", StringUtils.wrapIfMissing("/", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("/a/b/c", '/'));
    }

    @Test
    public void testWrapIfMissingString() {
        assertNull(StringUtils.wrapIfMissing(null, "x"));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", (String) null));
        assertEquals("'abcd'", StringUtils.wrapIfMissing("'abcd'", "'"));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c/", "/"));
    }

    // ------------------------------------------------------------------
    // default / firstNonX / getIfX
    // ------------------------------------------------------------------

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("bat", StringUtils.defaultString("bat"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("", StringUtils.defaultString("", "NULL"));
    }

    @Test
    public void testDefaultIfBlankAndEmpty() {
        assertEquals("NULL", StringUtils.defaultIfBlank(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfBlank("bat", "NULL"));
        assertNull(StringUtils.defaultIfBlank("", null));

        assertEquals("NULL", StringUtils.defaultIfEmpty(null, "NULL"));
        assertEquals(" ", StringUtils.defaultIfEmpty(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfEmpty("bat", "NULL"));
    }

    @Test
    public void testFirstNonBlankAndEmpty() {
        assertNull(StringUtils.firstNonBlank((String) null, null, null));
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("xyz", StringUtils.firstNonBlank(null, "", " ", "xyz"));
        assertNull(StringUtils.firstNonBlank());

        assertNull(StringUtils.firstNonEmpty((String) null, null, null));
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
        assertEquals("xyz", StringUtils.firstNonEmpty("", "xyz"));
        assertNull(StringUtils.firstNonEmpty());
    }

    @Test
    public void testGetIfBlankAndEmpty() {
        Supplier<String> nullSupplier = new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        };
        assertEquals("NULL", StringUtils.getIfBlank(null, nullSupplier));
        assertEquals("NULL", StringUtils.getIfBlank(" ", nullSupplier));
        assertEquals("bat", StringUtils.getIfBlank("bat", nullSupplier));
        assertNull(StringUtils.getIfBlank("", null));

        assertEquals("NULL", StringUtils.getIfEmpty(null, nullSupplier));
        assertEquals(" ", StringUtils.getIfEmpty(" ", nullSupplier));
        assertNull(StringUtils.getIfEmpty("", null));
    }

    // ------------------------------------------------------------------
    // common prefix / digits / bytes / distances / difference
    // ------------------------------------------------------------------

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {}));
        assertEquals("abc", StringUtils.getCommonPrefix(new String[] {"abc"}));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {null, null}));
        assertEquals("a", StringUtils.getCommonPrefix(new String[] {"abc", "a"}));
        assertEquals("ab", StringUtils.getCommonPrefix(new String[] {"ab", "abxyz"}));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {"abcde", "xyz"}));
    }

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1000", StringUtils.getDigits("1000$"));
        assertEquals("5417543010", StringUtils.getDigits("(541) 754-3010"));
    }

    @Test
    public void testGetBytes() throws UnsupportedEncodingException {
        assertArrayEquals(new byte[] {}, StringUtils.getBytes(null, (java.nio.charset.Charset) null));
        assertArrayEquals("abc".getBytes(StandardCharsets.UTF_8), StringUtils.getBytes("abc", StandardCharsets.UTF_8));

        assertArrayEquals(new byte[] {}, StringUtils.getBytes(null, "UTF-8"));
        assertArrayEquals("abc".getBytes("UTF-8"), StringUtils.getBytes("abc", "UTF-8"));
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "x");
            }
        });
    }

    @Test
    public void testGetLevenshteinDistanceWithThreshold() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 0));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 8));
        assertEquals(-1, StringUtils.getLevenshteinDistance("aaapppp", "", 6));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    @Test
    public void testGetFuzzyDistance() {
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Room", "o", Locale.ENGLISH));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.getFuzzyDistance(null, null, null);
            }
        });
    }

    @Test
    public void testGetJaroWinklerDistance() {
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("", ""), 0.0001);
        assertEquals(0.93, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.01);
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, null);
            }
        });
    }

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", "ab"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "xyz"));
    }

    // ------------------------------------------------------------------
    // chomp / chop
    // ------------------------------------------------------------------

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
        assertEquals("", StringUtils.chomp("\r\n"));
    }

    @Test
    public void testChompWithSeparator() {
        assertNull(StringUtils.chomp(null, "x"));
        assertEquals("foo", StringUtils.chomp("foobar", "bar"));
        assertEquals("foobar", StringUtils.chomp("foobar", "baz"));
        assertEquals("foo", StringUtils.chomp("foo", null));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("", StringUtils.chop("a"));
    }

    // ------------------------------------------------------------------
    // abbreviate family
    // ------------------------------------------------------------------

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testAbbreviateWithOffset() {
        assertNull(StringUtils.abbreviate(null, -1, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", -1, 10));
        assertEquals("...ghij...", StringUtils.abbreviate("abcdefghijklmno", 6, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 10, 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefghij", 5, 6);
            }
        });
    }

    @Test
    public void testAbbreviateWithMarker() {
        assertNull(StringUtils.abbreviate(null, "...", 4));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", (String) null, 4));
        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("ab..", StringUtils.abbreviate("abcdefg", "..", 4));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", "...", 3);
            }
        });
    }

    @Test
    public void testAbbreviateWithMarkerAndOffset() {
        assertNull(StringUtils.abbreviate(null, null, 0, 0));
        assertEquals("abcdefghijklmno", StringUtils.abbreviate("abcdefghijklmno", (String) null, 0, 0));
        assertEquals("abcdefghi,", StringUtils.abbreviate("abcdefghijklmno", ",", 0, 10));
        assertEquals("*ghijklmno", StringUtils.abbreviate("abcdefghijklmno", "*", 9, 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefghij", "abra", 0, 4);
            }
        });
    }

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    // ------------------------------------------------------------------
    // countMatches
    // ------------------------------------------------------------------

    @Test
    public void testCountMatchesChar() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));
        assertEquals(0, StringUtils.countMatches("abba", 'x'));
    }

    @Test
    public void testCountMatchesCharSequence() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abba", (CharSequence) null));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
        assertEquals(1, StringUtils.countMatches("ababa", "aba"));
    }

    // ------------------------------------------------------------------
    // Misc shared static behavior sanity checks
    // ------------------------------------------------------------------

    @Test
    public void testIdentityOnNoOpCases() {
        String original = "abc";
        assertEquals(original, StringUtils.remove(original, 'z'));
        assertNotNull(StringUtils.trim(original));
    }
}
