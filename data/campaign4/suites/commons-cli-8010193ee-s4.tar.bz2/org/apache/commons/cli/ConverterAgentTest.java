package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

public class ConverterAgentTest {

    /**
     * Minimal, explicit implementation of the functional interface used to verify
     * the documented contract of {@link Converter#apply(String)}: it returns a T
     * and may throw the declared checked exception type E.
     */
    private static class UpperCaseConverter implements Converter<String, IOException> {
        public String apply(final String string) throws IOException {
            if (string == null) {
                throw new IOException("null input");
            }
            return string.toUpperCase();
        }
    }

    @Test
    public void testCustomImplementationAppliesConversion() throws IOException {
        final Converter<String, IOException> converter = new UpperCaseConverter();
        assertEquals("HELLO", converter.apply("hello"));
        assertEquals("", converter.apply(""));
    }

    @Test
    public void testCustomImplementationPropagatesDeclaredException() {
        final Converter<String, IOException> converter = new UpperCaseConverter();
        try {
            converter.apply(null);
            fail("Expected IOException to be thrown");
        } catch (final IOException expected) {
            assertEquals("null input", expected.getMessage());
        }
    }

    @Test
    public void testDefaultFieldIsNotNull() {
        assertNotNull(Converter.DEFAULT);
    }

    @Test
    public void testDefaultConverterReturnsInputUnchanged() throws RuntimeException {
        final Object result = Converter.DEFAULT.apply("hello world");
        assertEquals("hello world", result);
    }

    @Test
    public void testDefaultConverterOnNullReturnsNull() throws RuntimeException {
        final Object result = Converter.DEFAULT.apply(null);
        assertNull(result);
    }

    @Test
    public void testClassFieldIsNotNull() {
        assertNotNull(Converter.CLASS);
    }

    @Test
    public void testClassConverterConvertsValidClassName() throws ClassNotFoundException {
        final Class<?> result = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, result);
    }

    @Test
    public void testClassConverterThrowsOnUnknownClassName() {
        try {
            Converter.CLASS.apply("no.such.package.NoSuchClassAgentTest");
            fail("Expected ClassNotFoundException to be thrown");
        } catch (final ClassNotFoundException expected) {
            // documented behavior
        }
    }

    @Test
    public void testFileFieldIsNotNull() {
        assertNotNull(Converter.FILE);
    }

    @Test
    public void testFileConverterConvertsStringToFile() throws NullPointerException {
        final File result = Converter.FILE.apply("test.txt");
        assertEquals(new File("test.txt"), result);
        assertEquals("test.txt", result.getName());
    }

    @Test
    public void testFileConverterAcceptsEmptyString() throws NullPointerException {
        final File result = Converter.FILE.apply("");
        assertEquals(new File(""), result);
    }

    @Test
    public void testFileConverterThrowsOnNullInput() {
        try {
            Converter.FILE.apply(null);
            fail("Expected NullPointerException to be thrown");
        } catch (final NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void testPathFieldIsNotNull() {
        assertNotNull(Converter.PATH);
    }

    @Test
    public void testPathConverterConvertsStringToPath() throws InvalidPathException {
        final Path result = Converter.PATH.apply("abc/def");
        assertEquals(Paths.get("abc/def"), result);
    }

    @Test
    public void testPathConverterThrowsOnInvalidPath() {
        try {
            Converter.PATH.apply("abc\u0000def");
            fail("Expected InvalidPathException to be thrown");
        } catch (final InvalidPathException expected) {
            // documented behavior
        }
    }

    @Test
    public void testNumberFieldIsNotNull() {
        assertNotNull(Converter.NUMBER);
    }

    @Test
    public void testNumberConverterReturnsLongWhenNoDecimalPoint() throws NumberFormatException {
        final Number result = Converter.NUMBER.apply("123");
        assertEquals(Long.valueOf(123L), result);
    }

    @Test
    public void testNumberConverterReturnsLongForNegativeInteger() throws NumberFormatException {
        final Number result = Converter.NUMBER.apply("-5");
        assertEquals(Long.valueOf(-5L), result);
    }

    @Test
    public void testNumberConverterReturnsDoubleWhenDecimalPointPresent() throws NumberFormatException {
        final Number result = Converter.NUMBER.apply("123.45");
        assertEquals(Double.valueOf(123.45), result);
    }

    @Test
    public void testNumberConverterThrowsOnInvalidNumber() {
        try {
            Converter.NUMBER.apply("not-a-number");
            fail("Expected NumberFormatException to be thrown");
        } catch (final NumberFormatException expected) {
            // documented behavior
        }
    }

    @Test
    public void testObjectFieldIsNotNull() {
        assertNotNull(Converter.OBJECT);
    }

    @Test
    public void testObjectConverterCreatesInstanceUsingDefaultConstructor() throws ReflectiveOperationException {
        final Object result = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(result);
        assertEquals(Object.class, result.getClass());
    }

    @Test
    public void testObjectConverterThrowsOnUnknownClassName() {
        try {
            Converter.OBJECT.apply("no.such.package.NoSuchClassAgentTest");
            fail("Expected ReflectiveOperationException to be thrown");
        } catch (final ReflectiveOperationException expected) {
            // documented behavior: uses CLASS converter internally, which fails first
        }
    }

    @Test
    public void testObjectConverterThrowsWhenNoDefaultConstructor() {
        try {
            // java.lang.Integer has no public no-arg constructor.
            Converter.OBJECT.apply("java.lang.Integer");
            fail("Expected ReflectiveOperationException to be thrown");
        } catch (final ReflectiveOperationException expected) {
            // documented behavior
        }
    }

    @Test
    public void testUrlFieldIsNotNull() {
        assertNotNull(Converter.URL);
    }

    @Test
    public void testUrlConverterConvertsValidUrlString() throws MalformedURLException {
        final URL result = Converter.URL.apply("http://example.com/path");
        assertEquals(new URL("http://example.com/path"), result);
        assertEquals("example.com", result.getHost());
    }

    @Test
    public void testUrlConverterThrowsOnMissingProtocol() {
        try {
            Converter.URL.apply("not a url with no protocol");
            fail("Expected MalformedURLException to be thrown");
        } catch (final MalformedURLException expected) {
            // documented behavior
        }
    }

    @Test
    public void testDateFieldIsNotNull() {
        assertNotNull(Converter.DATE);
    }

    @Test
    public void testDateConverterParsesExpectedFormat() throws ParseException {
        final Date result = Converter.DATE.apply("Mon Jan 02 03:04:05 UTC 2023");
        assertNotNull(result);
        final Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.setTime(result);
        assertEquals(2023, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, calendar.get(Calendar.MONTH));
        assertEquals(2, calendar.get(Calendar.DAY_OF_MONTH));
        assertEquals(3, calendar.get(Calendar.HOUR_OF_DAY));
        assertEquals(4, calendar.get(Calendar.MINUTE));
        assertEquals(5, calendar.get(Calendar.SECOND));
    }

    @Test
    public void testDateConverterThrowsOnUnparseableString() {
        try {
            Converter.DATE.apply("not a date at all");
            fail("Expected ParseException to be thrown");
        } catch (final ParseException expected) {
            // documented behavior
        }
    }
}
