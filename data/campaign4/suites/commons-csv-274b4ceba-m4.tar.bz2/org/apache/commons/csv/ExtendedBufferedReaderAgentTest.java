/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createReader(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testEmptyInputBoundaries() throws IOException {
        final ExtendedBufferedReader br = createReader("");
        try {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getLineNumber());
            assertEquals(0, br.getPosition());
            assertEquals(EOF, br.peek());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
            assertNull(br.readLine());
            assertEquals(0, br.read(new char[10], 0, 0));
        } finally {
            br.close();
        }
    }

    @Test
    void testCloseSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        br.read();
        assertEquals('a', br.getLastChar());
        br.close();
        assertEquals(EOF, br.getLastChar());
    }

    @Test
    void testResetWithoutMarkThrows() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        try {
            assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.reset();
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndReset() throws IOException {
        final ExtendedBufferedReader br = createReader("ab\ncd\nef");
        try {
            assertEquals('a', br.read());
            assertEquals('b', br.read());
            br.mark(10);
            final long markedPosition = br.getPosition();
            final long markedLineNumber = br.getLineNumber();
            final int markedLastChar = br.getLastChar();

            assertEquals('\n', br.read());
            assertEquals('c', br.read());
            assertEquals('d', br.read());

            br.reset();
            assertEquals(markedPosition, br.getPosition());
            assertEquals(markedLineNumber, br.getLineNumber());
            assertEquals(markedLastChar, br.getLastChar());
            // Reading after reset continues from the marked point.
            assertEquals('\n', br.read());
            assertEquals('c', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekDoesNotAdvanceState() throws IOException {
        final ExtendedBufferedReader br = createReader("xy");
        try {
            final long positionBefore = br.getPosition();
            final int lastCharBefore = br.getLastChar();
            final long lineNumberBefore = br.getLineNumber();

            assertEquals('x', br.peek());
            assertEquals('x', br.peek());

            assertEquals(positionBefore, br.getPosition());
            assertEquals(lastCharBefore, br.getLastChar());
            assertEquals(lineNumberBefore, br.getLineNumber());

            assertEquals('x', br.read());
            assertEquals('x', br.getLastChar());
            assertEquals(1, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLineNumberMidLineVersusAtEol() throws IOException {
        final ExtendedBufferedReader br = createReader("ab\ncd");
        try {
            assertEquals(0, br.getLineNumber());
            br.read(); // 'a'
            // Mid-line: counter is incremented by one beyond the accurate count.
            assertEquals(1, br.getLineNumber());
            br.read(); // 'b'
            assertEquals(1, br.getLineNumber());
            br.read(); // '\n'
            // At EOL: counter is accurate.
            assertEquals(1, br.getLineNumber());
            br.read(); // 'c'
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadZeroLengthDoesNotConsume() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        try {
            assertEquals(0, br.read(new char[5], 0, 0));
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('a', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadAtEofReducesPositionByOne() throws IOException {
        final ExtendedBufferedReader br = createReader("ab");
        try {
            assertEquals('a', br.read());
            assertEquals('b', br.read());
            assertEquals(2, br.getPosition());
            final char[] buf = new char[5];
            assertEquals(EOF, br.read(buf, 0, 5));
            assertEquals(EOF, br.getLastChar());
            // position += len, and len is EOF (-1) when the stream is already exhausted.
            assertEquals(1, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadingInDifferentBufferOffsets() throws IOException {
        final char[] destination = new char[6];
        final ExtendedBufferedReader br = createReader("abcdef");
        try {
            assertEquals(3, br.read(destination, 0, 3));
            assertEquals(3, br.read(destination, 3, 3));
            assertArrayEquals(new char[] { 'a', 'b', 'c', 'd', 'e', 'f' }, destination);
            assertEquals('f', br.getLastChar());
            assertEquals(6, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineWithoutTrailingNewline() throws IOException {
        final ExtendedBufferedReader br = createReader("lastline");
        try {
            assertEquals("lastline", br.readLine());
            assertEquals(EOF, br.getLastChar());
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testConstructorDefaultsHaveNoByteTracking() throws IOException {
        final String input = "hello";
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input));
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testTrackBytesFalseIgnoresCharset() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, false);
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testTrackBytesTrueWithNullCharsetIgnoresTracking() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), null, true);
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadAsciiTrackingViaSingleCharRead() throws IOException {
        final String input = "hello";
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        try {
            int count = 0;
            while (br.read() != EOF) {
                count++;
            }
            assertEquals(input.length(), count);
            assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadMultiByteCharacterViaBulkRead() throws IOException {
        final String input = "café"; // trailing e-acute is 2 bytes in UTF-8
        final char[] buffer = new char[input.length()];
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        try {
            assertEquals(input.length(), br.read(buffer, 0, buffer.length));
            assertArrayEquals(input.toCharArray(), buffer);
            assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testLoneHighSurrogateContributesZeroBytesWithoutThrowing() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uD800"), StandardCharsets.UTF_8, true);
        try {
            assertEquals('\uD800', br.read());
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testLoneLowSurrogateThrowsCharacterCodingException() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uDC00"), StandardCharsets.UTF_8, true);
        try {
            assertThrows(CharacterCodingException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read();
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testMismatchedSurrogatePairViaBulkReadThrows() throws IOException {
        // A plain character followed by a low surrogate with no preceding high surrogate.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("a\uDC00"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[2];
        try {
            assertThrows(CharacterCodingException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read(buf, 0, 2);
                }
            });
        } finally {
            br.close();
        }
    }
}
