/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link StrSubstitutor}.
 */
@Deprecated
class StrSubstitutorAgentTest {

    private Map<String, String> newMap() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("animal", "quick brown fox");
        map.put("target", "lazy dog");
        return map;
    }

    @Test
    void testReplaceStaticMap() {
        final Map<String, String> map = newMap();
        final String result = StrSubstitutor.replace("The ${animal} jumps over the ${target}.", map);
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testReplaceStaticMapWithPrefixSuffix() {
        final Map<String, String> map = newMap();
        final String result = StrSubstitutor.replace("The <animal> jumps over the <target>.", map, "<", ">");
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testReplaceStaticMapWithPrefixSuffixNullThrows() {
        final Map<String, String> map = newMap();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StrSubstitutor.replace("x", map, null, ">");
            }
        });
    }

    @Test
    void testReplaceStaticPropertiesNull() {
        assertEquals("abc", StrSubstitutor.replace("abc", (Properties) null));
    }

    @Test
    void testReplaceStaticProperties() {
        final Properties props = new Properties();
        props.setProperty("name", "world");
        final String result = StrSubstitutor.replace("Hello ${name}", props);
        assertEquals("Hello world", result);
    }

    @Test
    void testReplaceSystemProperties() {
        final String osName = System.getProperty("os.name");
        final String result = StrSubstitutor.replaceSystemProperties("My OS is ${os.name}");
        assertEquals("My OS is " + osName, result);
    }

    @Test
    void testDefaultConstructorNoVariablesReplaced() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertEquals("${foo}", sub.replace("${foo}"));
        assertEquals(StrSubstitutor.DEFAULT_ESCAPE, sub.getEscapeChar());
        assertSame(StrSubstitutor.DEFAULT_PREFIX, sub.getVariablePrefixMatcher());
        assertSame(StrSubstitutor.DEFAULT_SUFFIX, sub.getVariableSuffixMatcher());
        assertNull(sub.getVariableResolver());
    }

    @Test
    void testMapConstructor() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals("quick brown fox", sub.replace("${animal}"));
    }

    @Test
    void testMapConstructorWithPrefixSuffix() {
        final StrSubstitutor sub = new StrSubstitutor(newMap(), "<", ">");
        assertEquals("quick brown fox", sub.replace("<animal>"));
        assertEquals("${animal}", sub.replace("${animal}"));
    }

    @Test
    void testMapConstructorWithEscape() {
        final StrSubstitutor sub = new StrSubstitutor(newMap(), "${", "}", '!');
        assertEquals("quick brown fox", sub.replace("${animal}"));
        assertEquals("${animal}", sub.replace("!${animal}"));
    }

    @Test
    void testMapConstructorWithValueDelimiter() {
        final StrSubstitutor sub = new StrSubstitutor(newMap(), "${", "}", '$', "|");
        assertEquals("default", sub.replace("${missing|default}"));
        assertEquals("quick brown fox", sub.replace("${animal|default}"));
    }

    @Test
    void testResolverConstructor() {
        final StrSubstitutor sub = new StrSubstitutor(StrLookup.mapLookup(newMap()));
        assertEquals("lazy dog", sub.replace("${target}"));
    }

    @Test
    void testResolverConstructorWithPrefixSuffixEscape() {
        final StrSubstitutor sub = new StrSubstitutor(StrLookup.mapLookup(newMap()), "[", "]", '~');
        assertEquals("lazy dog", sub.replace("[target]"));
        assertEquals("[target]", sub.replace("~[target]"));
    }

    @Test
    void testResolverConstructorWithPrefixSuffixEscapeValueDelimiter() {
        final StrSubstitutor sub = new StrSubstitutor(StrLookup.mapLookup(newMap()), "[", "]", '~', "??");
        assertEquals("fallback", sub.replace("[missing??fallback]"));
    }

    @Test
    void testMatcherConstructor() {
        final StrSubstitutor sub = new StrSubstitutor(StrLookup.mapLookup(newMap()), StrMatcher.stringMatcher("${"),
                StrMatcher.stringMatcher("}"), '$');
        assertEquals("lazy dog", sub.replace("${target}"));
    }

    @Test
    void testMatcherConstructorWithValueDelimiterMatcher() {
        final StrSubstitutor sub = new StrSubstitutor(StrLookup.mapLookup(newMap()), StrMatcher.stringMatcher("${"),
                StrMatcher.stringMatcher("}"), '$', StrMatcher.stringMatcher(":-"));
        assertEquals("fallback", sub.replace("${missing:-fallback}"));
    }

    @Test
    void testUnknownVariableLeftUnresolved() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals("${unknown}", sub.replace("${unknown}"));
    }

    @Test
    void testNullSourceReturnsNull() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertNull(sub.replace((String) null));
        assertNull(sub.replace((Object) null));
        assertNull(sub.replace((char[]) null));
        assertNull(sub.replace((CharSequence) null));
        assertNull(sub.replace((StrBuilder) null));
        assertNull(sub.replace((StringBuffer) null));
    }

    @Test
    void testReplaceCharArray() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final char[] source = "The ${animal}".toCharArray();
        assertEquals("The quick brown fox", sub.replace(source));
        assertEquals("The ${animal}", new String(source));
    }

    @Test
    void testReplaceCharArrayOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final char[] source = "XX${animal}YY".toCharArray();
        assertEquals("quick brown fox", sub.replace(source, 2, 9));
    }

    @Test
    void testReplaceCharSequence() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final CharSequence source = new StringBuilder("The ${target}");
        assertEquals("The lazy dog", sub.replace(source));
    }

    @Test
    void testReplaceCharSequenceOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final CharSequence source = "XX${target}YY";
        assertEquals("lazy dog", sub.replace(source, 2, 9));
    }

    @Test
    void testReplaceStrBuilderNotAltered() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("${animal}");
        final String result = sub.replace(source);
        assertEquals("quick brown fox", result);
        assertEquals("${animal}", source.toString());
    }

    @Test
    void testReplaceStrBuilderOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("XX${animal}YY");
        assertEquals("quick brown fox", sub.replace(source, 2, 9));
    }

    @Test
    void testReplaceStringBuffer() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("${target}");
        assertEquals("lazy dog", sub.replace(source));
        assertEquals("${target}", source.toString());
    }

    @Test
    void testReplaceStringBufferOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("XX${target}YY");
        assertEquals("lazy dog", sub.replace(source, 2, 9));
    }

    @Test
    void testReplaceStringOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "XX${animal}YY";
        assertEquals("quick brown fox", sub.replace(source, 2, 9));
    }

    @Test
    void testReplaceStringUnalteredReturnsSameContent() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "no vars here";
        assertEquals(source, sub.replace(source));
    }

    @Test
    void testReplaceInStrBuilderNullReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StrBuilder) null));
        assertFalse(sub.replaceIn((StrBuilder) null, 0, 0));
    }

    @Test
    void testReplaceInStrBuilderAltersInPlace() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("${animal}");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("quick brown fox", source.toString());
    }

    @Test
    void testReplaceInStrBuilderNoVariablesReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("no vars");
        assertFalse(sub.replaceIn(source));
        assertEquals("no vars", source.toString());
    }

    @Test
    void testReplaceInStrBuilderOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("XX${animal}YY");
        final boolean altered = sub.replaceIn(source, 2, 9);
        assertTrue(altered);
        assertEquals("XXquick brown foxYY", source.toString());
    }

    @Test
    void testReplaceInStringBufferNullReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StringBuffer) null));
        assertFalse(sub.replaceIn((StringBuffer) null, 0, 0));
    }

    @Test
    void testReplaceInStringBufferAltersInPlace() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("${target}");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("lazy dog", source.toString());
    }

    @Test
    void testReplaceInStringBufferOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("XX${target}YY");
        final boolean altered = sub.replaceIn(source, 2, 9);
        assertTrue(altered);
        assertEquals("XXlazy dogYY", source.toString());
    }

    @Test
    void testReplaceInStringBuilderNullReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StringBuilder) null));
        assertFalse(sub.replaceIn((StringBuilder) null, 0, 0));
    }

    @Test
    void testReplaceInStringBuilderAltersInPlace() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuilder source = new StringBuilder("${target}");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("lazy dog", source.toString());
    }

    @Test
    void testReplaceInStringBuilderOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuilder source = new StringBuilder("XX${target}YY");
        final boolean altered = sub.replaceIn(source, 2, 9);
        assertTrue(altered);
        assertEquals("XXlazy dogYY", source.toString());
    }

    @Test
    void testEscapeCharacterPreventsReplacement() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals("${animal}", sub.replace("$${animal}"));
    }

    @Test
    void testPreserveEscapesFlag() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.isPreserveEscapes());
        sub.setPreserveEscapes(true);
        assertTrue(sub.isPreserveEscapes());
        assertEquals("$${animal}", sub.replace("$${animal}"));
    }

    @Test
    void testRecursiveSubstitution() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("name", "x");
        map.put("x", "resolved");
        final StrSubstitutor sub = new StrSubstitutor(map);
        sub.setEnableSubstitutionInVariables(true);
        assertEquals("resolved", sub.replace("${${name}}"));
    }

    @Test
    void testCyclicSubstitutionThrows() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("a", "${b}");
        map.put("b", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${a}");
            }
        });
    }

    @Test
    void testSelfReferenceCyclicSubstitutionThrows() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("a", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${a}");
            }
        });
    }

    @Test
    void testEnableSubstitutionInVariablesDefaultFalse() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("name", "x");
        map.put("x", "resolved");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertFalse(sub.isEnableSubstitutionInVariables());
        assertEquals("${${name}}", sub.replace("${${name}}"));
    }

    @Test
    void testEnableSubstitutionInVariablesToggle() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setEnableSubstitutionInVariables(true);
        assertTrue(sub.isEnableSubstitutionInVariables());
        sub.setEnableSubstitutionInVariables(false);
        assertFalse(sub.isEnableSubstitutionInVariables());
    }

    @Test
    void testDefaultValueDelimiterDisabledWhenNull() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiterMatcher(null);
        assertNull(sub.getValueDelimiterMatcher());
        assertEquals("${missing:-default}", sub.replace("${missing:-default}"));
    }

    @Test
    void testSetValueDelimiterCharUsed() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter('|');
        assertEquals("default", sub.replace("${missing|default}"));
    }

    @Test
    void testSetValueDelimiterStringEmptyDisables() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter("");
        assertNull(sub.getValueDelimiterMatcher());
        assertEquals("${missing:-default}", sub.replace("${missing:-default}"));
    }

    @Test
    void testSetValueDelimiterStringNullDisables() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter((String) null);
        assertNull(sub.getValueDelimiterMatcher());
    }

    @Test
    void testDefaultValueUsedWhenVariableMissing() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals("1234567890", sub.replace("${undefined.number:-1234567890}"));
    }

    @Test
    void testEscapeCharGetterSetter() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals('$', sub.getEscapeChar());
        sub.setEscapeChar('!');
        assertEquals('!', sub.getEscapeChar());
        assertEquals("${animal}", sub.replace("!${animal}"));
    }

    @Test
    void testVariablePrefixSuffixCharSetters() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setVariablePrefix('<');
        sub.setVariableSuffix('>');
        assertEquals("quick brown fox", sub.replace("<animal>"));
        assertEquals("${animal}", sub.replace("${animal}"));
    }

    @Test
    void testVariablePrefixSuffixStringSetters() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setVariablePrefix("[[");
        sub.setVariableSuffix("]]");
        assertEquals("lazy dog", sub.replace("[[target]]"));
    }

    @Test
    void testSetVariablePrefixNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefix((String) null);
            }
        });
    }

    @Test
    void testSetVariableSuffixNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffix((String) null);
            }
        });
    }

    @Test
    void testSetVariablePrefixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefixMatcher(null);
            }
        });
    }

    @Test
    void testSetVariableSuffixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffixMatcher(null);
            }
        });
    }

    @Test
    void testGetSetVariableResolver() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertNull(sub.getVariableResolver());
        final StrLookup<String> lookup = StrLookup.mapLookup(newMap());
        sub.setVariableResolver(lookup);
        assertSame(lookup, sub.getVariableResolver());
        assertEquals("lazy dog", sub.replace("${target}"));
    }

    @Test
    void testSetVariableResolverNullDisablesResolution() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setVariableResolver(null);
        assertNull(sub.getVariableResolver());
        assertEquals("${animal}", sub.replace("${animal}"));
    }

    @Test
    void testEmptyAndNoVariableSource() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals("", sub.replace(""));
        assertEquals("plain text", sub.replace("plain text"));
    }

    @Test
    void testResolveVariableProtectedMethodOverride() {
        final StrSubstitutor sub = new StrSubstitutor(newMap()) {
            @Override
            protected String resolveVariable(final String variableName, final StrBuilder buf, final int startPos, final int endPos) {
                if ("shout".equals(variableName)) {
                    return "LOUD";
                }
                return super.resolveVariable(variableName, buf, startPos, endPos);
            }
        };
        assertEquals("LOUD and quick brown fox", sub.replace("${shout} and ${animal}"));
    }

    @Test
    void testNumericValueConvertedToString() {
        final Map<String, Object> map = new HashMap<String, Object>();
        map.put("number", Integer.valueOf(2));
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertEquals("2", sub.replace("${number}"));
    }

    @Test
    void testNullValueInMapTreatedAsMissing() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("key", null);
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertEquals("${key}", sub.replace("${key}"));
    }

    @Test
    void testConstantsAreExpectedValues() {
        assertEquals('$', StrSubstitutor.DEFAULT_ESCAPE);
        assertNotNull(StrSubstitutor.DEFAULT_PREFIX);
        assertNotNull(StrSubstitutor.DEFAULT_SUFFIX);
        assertNotNull(StrSubstitutor.DEFAULT_VALUE_DELIMITER);
    }
}
