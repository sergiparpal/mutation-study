/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
public class ExtendedMessageFormatAgentTest {

    /**
     * Format that upper-cases its argument, ignoring any style text.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    /**
     * Format that repeats its argument N times, where N comes from the format style.
     */
    private static final class RepeatFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final int times;

        RepeatFormat(final int times) {
            this.times = times;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            final String s = String.valueOf(obj);
            for (int i = 0; i < times; i++) {
                toAppendTo.append(s);
            }
            return toAppendTo;
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    private static final class UpperCaseFormatFactory implements FormatFactory {
        // a single shared instance so two formats built from equivalent registries compare equal
        private static final UpperCaseFormat INSTANCE = new UpperCaseFormat();

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return "upper".equals(name) ? INSTANCE : null;
        }
    }

    private static final class RepeatFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            if (!"repeat".equals(name)) {
                return null;
            }
            final int times = arguments == null ? 1 : Integer.parseInt(arguments.trim());
            return new RepeatFormat(times);
        }
    }

    private static Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperCaseFormatFactory());
        return registry;
    }

    private static Map<String, FormatFactory> repeatRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("repeat", new RepeatFormatFactory());
        return registry;
    }

    @Test
    public void testConstructorDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("Hello {0}", emf.toPattern());
    }

    @Test
    public void testConstructorWithLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    @Test
    public void testConstructorNullLocaleDefaultsToSystemDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", (Locale) null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    public void testConstructorWithNullRegistryBehavesLikePlain() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", Locale.US, null);
        assertEquals("Hello {0}", emf.toPattern());
        assertEquals("Hello World", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructorWithRegistryDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    public void testFormatWithCustomUpperFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", Locale.US, upperRegistry());
        assertEquals("Name: JOHN", emf.format(new Object[] {"john"}));
    }

    @Test
    public void testFormatWithCustomFormatStyleArgument() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,repeat,3}", Locale.US, repeatRegistry());
        assertEquals("xxx", emf.format(new Object[] {"x"}));
    }

    @Test
    public void testFormatUnknownNameIsRejectedByUnderlyingMessageFormat() {
        // a format name the registry does not resolve is passed through to
        // java.text.MessageFormat verbatim, which rejects it
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknownFormat}", Locale.US, upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("unknown format"));
    }

    @Test
    public void testToPatternRoundTripsCustomFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    public void testToPatternWithoutRegistryMatchesSuperPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}", Locale.US);
        assertEquals("{0} and {1}", emf.toPattern());
    }

    @Test
    public void testToPatternWithWhitespaceAroundArgumentIndex() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 ,upper}", Locale.US, upperRegistry());
        assertEquals("ZZZ", emf.format(new Object[] {"zzz"}));
    }

    @Test
    public void testQuotedLiteralBraceIsPreserved() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{'{0}'}'", Locale.US, upperRegistry());
        assertEquals("{abc}", emf.format(new Object[] {"abc"}));
    }

    @Test
    public void testEqualsAndHashCodeSamePatternLocaleRegistry() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsReflexive() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        assertEquals(a, a);
    }

    @Test
    public void testNotEqualsDifferentPattern() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0} ", Locale.US);
        assertNotEquals(a, b);
    }

    @Test
    public void testNotEqualsDifferentRegistry() {
        // same pattern/locale and no custom format is actually triggered by it, so the
        // only difference between a and b is the registry instance itself
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US, upperRegistry());
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US, repeatRegistry());
        assertFalse(a.equals(b));
    }

    @Test
    public void testNotEqualsNullAndOtherType() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(a.equals(null));
        assertFalse(a.equals("{0}"));
    }

    @Test
    public void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    public void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    public void testUnterminatedQuotedStringThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("'abc", Locale.US, upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated quoted string"));
    }

    @Test
    public void testUnterminatedFormatElementThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", Locale.US, upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    public void testInvalidArgumentIndexThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0a}", Locale.US, upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    public void testBuiltInChoiceFormatStillWorksWithRegistryPresent() {
        // "choice" is not in the registry, so parsing falls back to the plain
        // java.text.MessageFormat choice sub-format, exercising the nested "|" content
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,choice,0#none|1#one|2#many}", Locale.US, upperRegistry());
        assertEquals("none", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("many", emf.format(new Object[] {Integer.valueOf(2)}));
    }

    @Test
    public void testMalformedPatternWithoutRegistryStillThrows() {
        // delegates straight to java.text.MessageFormat when there is no registry
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    public void testOverridingBuiltInFormatName() {
        // Use a factory keyed to the built-in "number" name to confirm the custom
        // format takes precedence over MessageFormat's own number formatting.
        final Map<String, FormatFactory> overrideRegistry = new HashMap<>();
        overrideRegistry.put("number", new FormatFactory() {
            @Override
            public Format getFormat(final String name, final String arguments, final Locale locale) {
                return new UpperCaseFormat();
            }
        });
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, overrideRegistry);
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    public void testMultipleArgumentsWithMixedFormats() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} - {1}", Locale.US, registry);
        assertEquals("HELLO - world", emf.format(new Object[] {"hello", "world"}));
    }

    @Test
    public void testApplyPatternIsIdempotentlyReapplicable() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        emf.applyPattern("{0} plain");
        assertEquals("{0} plain", emf.toPattern());
        assertEquals("abc plain", emf.format(new Object[] {"abc"}));
    }
}
