/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Strings}.
 */
public class StringsAgentTest {

    // --- appendIfMissing ---

    @Test
    public void testAppendIfMissing_nullString() {
        assertNull(Strings.CS.appendIfMissing(null, "xyz"));
    }

    @Test
    public void testAppendIfMissing_nullSuffix() {
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
    }

    @Test
    public void testAppendIfMissing_emptyString() {
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
    }

    @Test
    public void testAppendIfMissing_appends() {
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
    }

    @Test
    public void testAppendIfMissing_alreadyPresent() {
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
    }

    @Test
    public void testAppendIfMissing_caseSensitiveDoesAppend() {
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissing_caseInsensitiveDoesNotAppend() {
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissing_withAdditionalSuffixes() {
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissing_withNullElementInSuffixes() {
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", new CharSequence[] {null}));
    }

    // --- compare ---

    @Test
    public void testCompare_bothNull() {
        assertEquals(0, Strings.CS.compare(null, null));
    }

    @Test
    public void testCompare_nullLessThanValue() {
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
    }

    @Test
    public void testCompare_equalStrings() {
        assertEquals(0, Strings.CS.compare("abc", "abc"));
    }

    @Test
    public void testCompare_caseSensitiveDiffers() {
        assertTrue(Strings.CS.compare("a", "B") > 0);
    }

    @Test
    public void testCompare_caseInsensitiveEqualIgnoringCase() {
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
    }

    @Test
    public void testCompare_caseInsensitiveOrdering() {
        assertTrue(Strings.CI.compare("a", "B") < 0);
    }

    // --- contains ---

    @Test
    public void testContains_nullCharSequence() {
        assertFalse(Strings.CS.contains(null, "a"));
    }

    @Test
    public void testContains_nullSearch() {
        assertFalse(Strings.CS.contains("abc", null));
    }

    @Test
    public void testContains_emptySearchInEmptyString() {
        assertTrue(Strings.CS.contains("", ""));
    }

    @Test
    public void testContains_emptySearchAlwaysMatches() {
        assertTrue(Strings.CS.contains("abc", ""));
    }

    @Test
    public void testContains_found() {
        assertTrue(Strings.CS.contains("abc", "a"));
    }

    @Test
    public void testContains_notFound() {
        assertFalse(Strings.CS.contains("abc", "z"));
    }

    @Test
    public void testContains_caseInsensitiveFound() {
        assertTrue(Strings.CI.contains("abc", "A"));
    }

    @Test
    public void testContains_caseSensitiveNotFoundForDifferentCase() {
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    // --- containsAny ---

    @Test
    public void testContainsAny_nullCharSequence() {
        assertFalse(Strings.CS.containsAny(null, "a"));
    }

    @Test
    public void testContainsAny_emptySearchArray() {
        assertFalse(Strings.CS.containsAny("abcd"));
    }

    @Test
    public void testContainsAny_nullSearchArray() {
        assertFalse(Strings.CS.containsAny("abcd", (CharSequence[]) null));
    }

    @Test
    public void testContainsAny_matches() {
        assertTrue(Strings.CS.containsAny("abcd", "ab", null));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAny_caseInsensitiveMatches() {
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    // --- endsWith ---

    @Test
    public void testEndsWith_bothNull() {
        assertTrue(Strings.CS.endsWith(null, null));
    }

    @Test
    public void testEndsWith_oneNull() {
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
    }

    @Test
    public void testEndsWith_matches() {
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
    }

    @Test
    public void testEndsWith_caseSensitiveMismatch() {
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
    }

    @Test
    public void testEndsWith_emptySuffixAlwaysMatches() {
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWith_suffixLongerThanString() {
        assertFalse(Strings.CS.endsWith("ab", "abc"));
    }

    @Test
    public void testEndsWith_caseInsensitiveMatches() {
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
    }

    // --- endsWithAny ---

    @Test
    public void testEndsWithAny_nullSequence() {
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
    }

    @Test
    public void testEndsWithAny_nullSearchStrings() {
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
    }

    @Test
    public void testEndsWithAny_emptySearchStringMatches() {
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
    }

    @Test
    public void testEndsWithAny_matchWithNullElement() {
        assertTrue(Strings.CS.endsWithAny("abcxyz", null, "xyz", "abc"));
    }

    @Test
    public void testEndsWithAny_caseSensitiveNoMatch() {
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // --- equals (CharSequence) ---

    @Test
    public void testEqualsCharSequence_bothNull() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
    }

    @Test
    public void testEqualsCharSequence_oneNull() {
        assertFalse(Strings.CS.equals((CharSequence) null, (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) null));
    }

    @Test
    public void testEqualsCharSequence_sameObject() {
        final CharSequence cs = "abc";
        assertTrue(Strings.CS.equals(cs, cs));
    }

    @Test
    public void testEqualsCharSequence_differentLength() {
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ab"));
    }

    @Test
    public void testEqualsCharSequence_caseSensitiveMismatch() {
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    public void testEqualsCharSequence_caseInsensitiveMatch() {
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    public void testEqualsCharSequence_nonStringCharSequences() {
        final CharSequence cs1 = new StringBuilder("abc");
        final CharSequence cs2 = new StringBuilder("abc");
        assertTrue(Strings.CS.equals(cs1, cs2));
    }

    // --- equals (String) ---

    @Test
    public void testEqualsString_bothNull() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
    }

    @Test
    public void testEqualsString_oneNull() {
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
    }

    @Test
    public void testEqualsString_caseSensitive() {
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsString_caseInsensitive() {
        assertTrue(Strings.CI.equals("abc", "ABC"));
    }

    // --- equalsAny ---

    @Test
    public void testEqualsAny_nullSearchStrings() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
    }

    @Test
    public void testEqualsAny_nullStringMatchesNullElement() {
        assertTrue(Strings.CS.equalsAny(null, null, null));
    }

    @Test
    public void testEqualsAny_match() {
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
    }

    @Test
    public void testEqualsAny_caseSensitiveNoMatch() {
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAny_caseInsensitiveMatch() {
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // --- indexOf (2-arg) ---

    @Test
    public void testIndexOf_nullInputs() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
    }

    @Test
    public void testIndexOf_emptyInEmpty() {
        assertEquals(0, Strings.CS.indexOf("", ""));
    }

    @Test
    public void testIndexOf_emptyInNonEmptySearch() {
        assertEquals(-1, Strings.CS.indexOf("", "a"));
    }

    @Test
    public void testIndexOf_found() {
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOf_caseInsensitive() {
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A"));
    }

    // --- indexOf (3-arg) ---

    @Test
    public void testIndexOf3_negativeStartTreatedAsZero() {
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
    }

    @Test
    public void testIndexOf3_startPastEnd() {
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
    }

    @Test
    public void testIndexOf3_emptySearchAtPosition() {
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
    }

    @Test
    public void testIndexOf3_emptySearchBeyondLength() {
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOf3_caseInsensitiveEmptySearchBeyondLengthReturnsNotFound() {
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOf3_startAfterFirstMatch() {
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
    }

    // --- isCaseSensitive ---

    @Test
    public void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // --- lastIndexOf (2-arg) ---

    @Test
    public void testLastIndexOf_nullInputs() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
    }

    @Test
    public void testLastIndexOf_emptySearch() {
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOf_found() {
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
    }

    @Test
    public void testLastIndexOf_caseInsensitive() {
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
    }

    // --- lastIndexOf (3-arg) ---

    @Test
    public void testLastIndexOf3_negativeStartPosReturnsNotFound() {
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
    }

    @Test
    public void testLastIndexOf3_startBeyondLengthSearchesWhole() {
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
    }

    @Test
    public void testLastIndexOf3_exactBoundaryMatch() {
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
    }

    @Test
    public void testLastIndexOf3_matchAtStartPos() {
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
    }

    // --- prependIfMissing ---

    @Test
    public void testPrependIfMissing_nullString() {
        assertNull(Strings.CS.prependIfMissing(null, "xyz"));
    }

    @Test
    public void testPrependIfMissing_nullPrefix() {
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
    }

    @Test
    public void testPrependIfMissing_emptyString() {
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
    }

    @Test
    public void testPrependIfMissing_prepends() {
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
    }

    @Test
    public void testPrependIfMissing_alreadyPresent() {
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
    }

    @Test
    public void testPrependIfMissing_caseSensitiveDoesPrepend() {
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissing_caseInsensitiveDoesNotPrepend() {
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissing_withAdditionalPrefixes() {
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
    }

    // --- remove ---

    @Test
    public void testRemove_nullSource() {
        assertNull(Strings.CS.remove(null, "a"));
    }

    @Test
    public void testRemove_emptySource() {
        assertEquals("", Strings.CS.remove("", "a"));
    }

    @Test
    public void testRemove_nullRemove() {
        assertEquals("queued", Strings.CS.remove("queued", null));
    }

    @Test
    public void testRemove_emptyRemove() {
        assertEquals("queued", Strings.CS.remove("queued", ""));
    }

    @Test
    public void testRemove_removesAllOccurrences() {
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
    }

    @Test
    public void testRemove_noMatch() {
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    public void testRemove_caseInsensitive() {
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
    }

    // --- removeEnd ---

    @Test
    public void testRemoveEnd_nullSource() {
        assertNull(Strings.CS.removeEnd(null, "a"));
    }

    @Test
    public void testRemoveEnd_emptySource() {
        assertEquals("", Strings.CS.removeEnd("", "a"));
    }

    @Test
    public void testRemoveEnd_nullRemove() {
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
    }

    @Test
    public void testRemoveEnd_notAtEnd() {
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEnd_removed() {
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
    }

    @Test
    public void testRemoveEnd_notMatchingDueToTrailingChar() {
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
    }

    @Test
    public void testRemoveEnd_caseInsensitive() {
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
    }

    // --- removeStart ---

    @Test
    public void testRemoveStart_nullSource() {
        assertNull(Strings.CS.removeStart(null, "a"));
    }

    @Test
    public void testRemoveStart_emptySource() {
        assertEquals("", Strings.CS.removeStart("", "a"));
    }

    @Test
    public void testRemoveStart_nullRemove() {
        assertEquals("abc", Strings.CS.removeStart("abc", null));
    }

    @Test
    public void testRemoveStart_removed() {
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
    }

    @Test
    public void testRemoveStart_notAtStart() {
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveStart_caseInsensitive() {
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
    }

    // --- replace (3-arg) ---

    @Test
    public void testReplace3_nullText() {
        assertNull(Strings.CS.replace(null, "a", "b"));
    }

    @Test
    public void testReplace3_emptyText() {
        assertEquals("", Strings.CS.replace("", "a", "b"));
    }

    @Test
    public void testReplace3_nullSearch() {
        assertEquals("any", Strings.CS.replace("any", null, "b"));
    }

    @Test
    public void testReplace3_nullReplacement() {
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
    }

    @Test
    public void testReplace3_emptySearch() {
        assertEquals("any", Strings.CS.replace("any", "", "z"));
    }

    @Test
    public void testReplace3_replacesAllOccurrences() {
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplace3_replaceWithEmpty() {
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
    }

    @Test
    public void testReplace3_caseInsensitive() {
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    // --- replace (4-arg, max) ---

    @Test
    public void testReplace4_maxZeroNoOp() {
        assertEquals("any", Strings.CS.replace("any", "a", "z", 0));
    }

    @Test
    public void testReplace4_maxOneReplacesFirstOnly() {
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
    }

    @Test
    public void testReplace4_maxTwo() {
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
    }

    @Test
    public void testReplace4_negativeMaxReplacesAll() {
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplace4_nullReplacement() {
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
    }

    @Test
    public void testReplace4_replacementLongerThanSearch() {
        assertEquals("abcdabcd", Strings.CS.replace("aa", "a", "abcd", -1));
    }

    // --- replaceOnce ---

    @Test
    public void testReplaceOnce_nullText() {
        assertNull(Strings.CS.replaceOnce(null, "a", "b"));
    }

    @Test
    public void testReplaceOnce_replacesOnlyFirst() {
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnce_removeFirstOnly() {
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
    }

    @Test
    public void testReplaceOnce_caseInsensitive() {
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // --- startsWith ---

    @Test
    public void testStartsWith_bothNull() {
        assertTrue(Strings.CS.startsWith(null, null));
    }

    @Test
    public void testStartsWith_oneNull() {
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
    }

    @Test
    public void testStartsWith_matches() {
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
    }

    @Test
    public void testStartsWith_caseSensitiveMismatch() {
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWith_prefixLongerThanString() {
        assertFalse(Strings.CS.startsWith("ab", "abc"));
    }

    @Test
    public void testStartsWith_caseInsensitiveMatches() {
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    // --- startsWithAny ---

    @Test
    public void testStartsWithAny_nullSequence() {
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
    }

    @Test
    public void testStartsWithAny_nullSearchStrings() {
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
    }

    @Test
    public void testStartsWithAny_emptySearchStringMatches() {
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
    }

    @Test
    public void testStartsWithAny_matchWithNullElement() {
        assertTrue(Strings.CS.startsWithAny("abcxyz", null, "xyz", "abc"));
    }

    @Test
    public void testStartsWithAny_caseSensitiveNoMatch() {
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
    }

    @Test
    public void testStartsWithAny_caseInsensitiveMatch() {
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
    }

    // --- builder ---

    @Test
    public void testBuilder_defaultIsCaseSensitive() {
        final Strings strings = Strings.builder().get();
        assertNotNull(strings);
        assertTrue(strings.isCaseSensitive());
    }

    @Test
    public void testBuilder_setIgnoreCaseTrueProducesCaseInsensitive() {
        final Strings strings = Strings.builder().setIgnoreCase(true).get();
        assertFalse(strings.isCaseSensitive());
        assertTrue(strings.equals("abc", "ABC"));
    }

    @Test
    public void testBuilder_setIgnoreCaseFalseProducesCaseSensitive() {
        final Strings strings = Strings.builder().setIgnoreCase(false).get();
        assertTrue(strings.isCaseSensitive());
        assertFalse(strings.equals("abc", "ABC"));
    }

    @Test
    public void testBuilder_nullIsLessAffectsCompare() {
        final Strings nullLess = Strings.builder().setNullIsLess(true).get();
        final Strings nullGreater = Strings.builder().setNullIsLess(false).get();
        assertTrue(nullLess.compare(null, "a") < 0);
        assertTrue(nullGreater.compare(null, "a") > 0);
    }

    // --- singletons ---

    @Test
    public void testSingletons_csIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
    }

    @Test
    public void testSingletons_ciIsCaseInsensitive() {
        assertFalse(Strings.CI.isCaseSensitive());
    }
}
