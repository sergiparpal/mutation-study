package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Self-contained tests for {@link ToStringStyle} based solely on its documented contract.
 */
public class ToStringStyleAgentTest {

    /** Minimal concrete subclass: the class is abstract only to force subclassing/singleton use. */
    static final class BareStyle extends ToStringStyle {
    }

    /** Trivial fixture used only to obtain a class name / identity hash code. */
    static final class Fixture {
    }

    private BareStyle style;

    @BeforeEach
    public void setUp() {
        style = new BareStyle();
    }

    // ---------------------------------------------------------------
    // Singleton constants
    // ---------------------------------------------------------------

    @Test
    public void testSingletonConstantsAreNotNullAndAreToStringStyles() {
        assertNotNull(ToStringStyle.DEFAULT_STYLE);
        assertNotNull(ToStringStyle.MULTI_LINE_STYLE);
        assertNotNull(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertNotNull(ToStringStyle.SHORT_PREFIX_STYLE);
        assertNotNull(ToStringStyle.SIMPLE_STYLE);
        assertNotNull(ToStringStyle.NO_CLASS_NAME_STYLE);
        assertNotNull(ToStringStyle.JSON_STYLE);
        assertTrue(ToStringStyle.DEFAULT_STYLE instanceof ToStringStyle);
        assertTrue(ToStringStyle.DEFAULT_STYLE instanceof java.io.Serializable);
    }

    // ---------------------------------------------------------------
    // Documented per-style output examples (see class javadoc)
    // ---------------------------------------------------------------

    @Test
    public void testDefaultStyleFormat() {
        String result = renderPerson(ToStringStyle.DEFAULT_STYLE);
        assertTrue(result.matches("(?s).*Fixture@[0-9a-f]+\\[name=John Doe,age=33,smoker=false\\]"));
    }

    @Test
    public void testNoFieldNamesStyleFormat() {
        String result = renderPerson(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertTrue(result.matches("(?s).*Fixture@[0-9a-f]+\\[John Doe,33,false\\]"));
    }

    @Test
    public void testShortPrefixStyleFormat() {
        String result = renderPerson(ToStringStyle.SHORT_PREFIX_STYLE);
        assertTrue(result.matches("(?s).*Fixture\\[name=John Doe,age=33,smoker=false\\]"));
        assertFalse(result.contains("@"));
    }

    @Test
    public void testSimpleStyleFormat() {
        String result = renderPerson(ToStringStyle.SIMPLE_STYLE);
        assertEquals("John Doe,33,false", result);
    }

    @Test
    public void testNoClassNameStyleFormat() {
        String result = renderPerson(ToStringStyle.NO_CLASS_NAME_STYLE);
        assertEquals("[name=John Doe,age=33,smoker=false]", result);
    }

    @Test
    public void testJsonStyleFormat() {
        String result = renderPerson(ToStringStyle.JSON_STYLE);
        assertEquals("{\"name\": \"John Doe\", \"age\": 33, \"smoker\": false}", result);
    }

    @Test
    public void testMultiLineStyleFormat() {
        String result = renderPerson(ToStringStyle.MULTI_LINE_STYLE);
        assertTrue(result.matches("(?s).*Fixture@[0-9a-f]+\\[.*"));
        assertTrue(result.contains("name=John Doe"));
        assertTrue(result.contains("age=33"));
        assertTrue(result.contains("smoker=false"));
        assertTrue(result.contains("\n"));
        assertTrue(result.trim().endsWith("]"));
    }

    @Test
    public void testJsonStyleThrowsOnMissingFieldNameForPrimitive() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                ToStringStyle.JSON_STYLE.append(buffer, null, true);
            }
        });
    }

    @Test
    public void testJsonStyleThrowsOnMissingFieldNameForObject() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                ToStringStyle.JSON_STYLE.append(buffer, null, "value", Boolean.TRUE);
            }
        });
    }

    private String renderPerson(ToStringStyle toStringStyle) {
        StringBuffer buffer = new StringBuffer();
        Fixture obj = new Fixture();
        toStringStyle.appendStart(buffer, obj);
        toStringStyle.append(buffer, "name", "John Doe", Boolean.TRUE);
        toStringStyle.append(buffer, "age", 33);
        toStringStyle.append(buffer, "smoker", false);
        toStringStyle.appendEnd(buffer, obj);
        return buffer.toString();
    }

    // ---------------------------------------------------------------
    // appendNullText / appendSummarySize documented defaults
    // ---------------------------------------------------------------

    @Test
    public void testAppendNullTextDefaultIndicator() {
        StringBuffer buffer = new StringBuffer();
        style.appendNullText(buffer, "field");
        assertEquals("<null>", buffer.toString());
        assertEquals("<null>", style.getNullText());
    }

    @Test
    public void testAppendNullTextIsInvariantToFieldName() {
        StringBuffer b1 = new StringBuffer();
        style.appendNullText(b1, "fieldOne");
        StringBuffer b2 = new StringBuffer();
        style.appendNullText(b2, "fieldTwo");
        assertEquals(b1.toString(), b2.toString());
    }

    @Test
    public void testAppendSummarySizeDefaultFormat() {
        StringBuffer buffer = new StringBuffer();
        style.appendSummarySize(buffer, "field", 5);
        assertEquals("<size=5>", buffer.toString());
    }

    @Test
    public void testAppendSummarySizeIsInvariantToFieldName() {
        StringBuffer b1 = new StringBuffer();
        style.appendSummarySize(b1, "fieldOne", 7);
        StringBuffer b2 = new StringBuffer();
        style.appendSummarySize(b2, "fieldTwo", 7);
        assertEquals(b1.toString(), b2.toString());
    }

    // ---------------------------------------------------------------
    // getShortClassName
    // ---------------------------------------------------------------

    @Test
    public void testGetShortClassNameExcludesPackageName() {
        assertEquals("String", style.getShortClassName(String.class));
        assertEquals("ArrayList", style.getShortClassName(ArrayList.class));
    }

    // ---------------------------------------------------------------
    // Setters that accept null and convert it to an empty String
    // ---------------------------------------------------------------

    @Test
    public void testSetArrayTextsAcceptNullAsEmptyString() {
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());

        style.setArrayStart("<<");
        assertEquals("<<", style.getArrayStart());
        style.setArraySeparator("|");
        assertEquals("|", style.getArraySeparator());
        style.setArrayEnd(">>");
        assertEquals(">>", style.getArrayEnd());
    }

    @Test
    public void testSetContentTextsAcceptNullAsEmptyString() {
        style.setContentStart(null);
        assertEquals("", style.getContentStart());
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());

        style.setContentStart("(");
        assertEquals("(", style.getContentStart());
        style.setContentEnd(")");
        assertEquals(")", style.getContentEnd());
    }

    @Test
    public void testSetFieldSeparatorTextsAcceptNullAsEmptyString() {
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());

        style.setFieldSeparator(";");
        assertEquals(";", style.getFieldSeparator());
        style.setFieldNameValueSeparator(":");
        assertEquals(":", style.getFieldNameValueSeparator());
    }

    @Test
    public void testSetNullTextAcceptsNullAsEmptyString() {
        style.setNullText(null);
        assertEquals("", style.getNullText());
        style.setNullText("NULL");
        assertEquals("NULL", style.getNullText());
    }

    @Test
    public void testSetSizeTextsAcceptNullAsEmptyString() {
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());

        style.setSizeStartText("{");
        assertEquals("{", style.getSizeStartText());
        style.setSizeEndText("}");
        assertEquals("}", style.getSizeEndText());
    }

    @Test
    public void testSetSummaryObjectTextsAcceptNullAsEmptyString() {
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());

        style.setSummaryObjectStartText("~");
        assertEquals("~", style.getSummaryObjectStartText());
        style.setSummaryObjectEndText("~");
        assertEquals("~", style.getSummaryObjectEndText());
    }

    // ---------------------------------------------------------------
    // Boolean flag round trips
    // ---------------------------------------------------------------

    @Test
    public void testBooleanFlagsRoundTrip() {
        style.setArrayContentDetail(true);
        assertTrue(style.isArrayContentDetail());
        style.setArrayContentDetail(false);
        assertFalse(style.isArrayContentDetail());

        style.setDefaultFullDetail(true);
        assertTrue(style.isDefaultFullDetail());
        style.setDefaultFullDetail(false);
        assertFalse(style.isDefaultFullDetail());

        style.setFieldSeparatorAtStart(true);
        assertTrue(style.isFieldSeparatorAtStart());
        style.setFieldSeparatorAtStart(false);
        assertFalse(style.isFieldSeparatorAtStart());

        style.setFieldSeparatorAtEnd(true);
        assertTrue(style.isFieldSeparatorAtEnd());
        style.setFieldSeparatorAtEnd(false);
        assertFalse(style.isFieldSeparatorAtEnd());

        style.setUseClassName(true);
        assertTrue(style.isUseClassName());
        style.setUseClassName(false);
        assertFalse(style.isUseClassName());

        style.setUseFieldNames(true);
        assertTrue(style.isUseFieldNames());
        style.setUseFieldNames(false);
        assertFalse(style.isUseFieldNames());

        style.setUseIdentityHashCode(true);
        assertTrue(style.isUseIdentityHashCode());
        style.setUseIdentityHashCode(false);
        assertFalse(style.isUseIdentityHashCode());

        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
        style.setUseShortClassName(false);
        assertFalse(style.isUseShortClassName());
    }

    // ---------------------------------------------------------------
    // isFullDetail
    // ---------------------------------------------------------------

    @Test
    public void testIsFullDetailHonorsExplicitRequest() {
        assertTrue(style.isFullDetail(Boolean.TRUE));
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    @Test
    public void testIsFullDetailDefersToDefaultFullDetailWhenNull() {
        style.setDefaultFullDetail(true);
        assertTrue(style.isFullDetail(null));
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    // ---------------------------------------------------------------
    // appendClassName / appendFieldStart depend on their matching flags
    // ---------------------------------------------------------------

    @Test
    public void testAppendClassNameIsConditionalOnUseClassName() {
        style.setUseClassName(false);
        StringBuffer buffer = new StringBuffer();
        style.appendClassName(buffer, new Fixture());
        assertEquals(0, buffer.length());

        style.setUseClassName(true);
        style.setUseShortClassName(true);
        StringBuffer buffer2 = new StringBuffer();
        style.appendClassName(buffer2, new Fixture());
        assertEquals(style.getShortClassName(Fixture.class), buffer2.toString());

        style.setUseShortClassName(false);
        StringBuffer buffer3 = new StringBuffer();
        style.appendClassName(buffer3, new Fixture());
        assertEquals(Fixture.class.getName(), buffer3.toString());
    }

    @Test
    public void testAppendFieldStartIsConditionalOnUseFieldNames() {
        style.setUseFieldNames(true);
        StringBuffer buffer = new StringBuffer();
        style.appendFieldStart(buffer, "myField");
        assertTrue(buffer.toString().contains("myField"));

        style.setUseFieldNames(false);
        StringBuffer buffer2 = new StringBuffer();
        style.appendFieldStart(buffer2, "myField");
        assertFalse(buffer2.toString().contains("myField"));
    }

    @Test
    public void testAppendFieldEndIsInvariantToFieldName() {
        StringBuffer b1 = new StringBuffer();
        style.appendFieldEnd(b1, "fieldOne");
        StringBuffer b2 = new StringBuffer();
        style.appendFieldEnd(b2, "fieldTwo");
        assertEquals(b1.toString(), b2.toString());
    }

    @Test
    public void testAppendFieldSeparatorMatchesItsGetter() {
        StringBuffer buffer = new StringBuffer();
        style.appendFieldSeparator(buffer);
        assertEquals(style.getFieldSeparator(), buffer.toString());
    }

    @Test
    public void testRemoveLastFieldSeparatorUndoesAppendFieldSeparator() {
        StringBuffer buffer = new StringBuffer("prefix");
        style.appendFieldSeparator(buffer);
        assertEquals("prefix" + style.getFieldSeparator(), buffer.toString());
        style.removeLastFieldSeparator(buffer);
        assertEquals("prefix", buffer.toString());
    }

    // ---------------------------------------------------------------
    // appendIdentityHashCode
    // ---------------------------------------------------------------

    @Test
    public void testAppendIdentityHashCodeContainsTheHashValue() {
        Object target = new Fixture();
        int hash = System.identityHashCode(target);
        StringBuffer buffer = new StringBuffer();
        style.appendIdentityHashCode(buffer, target);
        String result = buffer.toString();
        assertTrue(result.equals(Integer.toHexString(hash)) || result.equals(String.valueOf(hash)));
    }

    // ---------------------------------------------------------------
    // appendDetail for primitive scalar values
    // ---------------------------------------------------------------

    @Test
    public void testAppendDetailForPrimitiveScalarsYieldsValueText() {
        StringBuffer b;

        b = new StringBuffer();
        style.appendDetail(b, "f", true);
        assertEquals(String.valueOf(true), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", (byte) 5);
        assertEquals(String.valueOf((byte) 5), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", 'x');
        assertEquals(String.valueOf('x'), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", 1.5d);
        assertEquals(String.valueOf(1.5d), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", 1.5f);
        assertEquals(String.valueOf(1.5f), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", 42);
        assertEquals(String.valueOf(42), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", 42L);
        assertEquals(String.valueOf(42L), b.toString());

        b = new StringBuffer();
        style.appendDetail(b, "f", (short) 7);
        assertEquals(String.valueOf((short) 7), b.toString());
    }

    @Test
    public void testAppendDetailForObjectIsItsToString() {
        StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", "hello");
        assertEquals("hello", buffer.toString());
    }

    // ---------------------------------------------------------------
    // appendCyclicObject
    // ---------------------------------------------------------------

    @Test
    public void testAppendCyclicObjectUsesStandardToString() {
        StringBuffer buffer = new StringBuffer();
        style.appendCyclicObject(buffer, "f", "cyclicValue");
        assertEquals("cyclicValue", buffer.toString());
    }

    @Test
    public void testAppendCyclicObjectIsInvariantToFieldName() {
        StringBuffer b1 = new StringBuffer();
        style.appendCyclicObject(b1, "fieldOne", "sameValue");
        StringBuffer b2 = new StringBuffer();
        style.appendCyclicObject(b2, "fieldTwo", "sameValue");
        assertEquals(b1.toString(), b2.toString());
    }

    // ---------------------------------------------------------------
    // appendDetail for Collection and Map
    // ---------------------------------------------------------------

    @Test
    public void testAppendDetailForCollectionReflectsContentNotFieldName() {
        Collection<String> empty = new ArrayList<String>();
        List<String> populated = new ArrayList<String>();
        populated.add("a");
        populated.add("b");

        StringBuffer emptyBuf = new StringBuffer();
        style.appendDetail(emptyBuf, "f", empty);
        StringBuffer populatedBuf = new StringBuffer();
        style.appendDetail(populatedBuf, "f", populated);
        assertNotEquals(emptyBuf.toString(), populatedBuf.toString());

        StringBuffer b1 = new StringBuffer();
        style.appendDetail(b1, "fieldOne", populated);
        StringBuffer b2 = new StringBuffer();
        style.appendDetail(b2, "fieldTwo", populated);
        assertEquals(b1.toString(), b2.toString());
    }

    @Test
    public void testAppendDetailForMapReflectsContentNotFieldName() {
        Map<String, String> empty = new HashMap<String, String>();
        Map<String, String> populated = new HashMap<String, String>();
        populated.put("k", "v");

        StringBuffer emptyBuf = new StringBuffer();
        style.appendDetail(emptyBuf, "f", empty);
        StringBuffer populatedBuf = new StringBuffer();
        style.appendDetail(populatedBuf, "f", populated);
        assertNotEquals(emptyBuf.toString(), populatedBuf.toString());

        StringBuffer b1 = new StringBuffer();
        style.appendDetail(b1, "fieldOne", populated);
        StringBuffer b2 = new StringBuffer();
        style.appendDetail(b2, "fieldTwo", populated);
        assertEquals(b1.toString(), b2.toString());
    }

    // ---------------------------------------------------------------
    // appendDetail / appendSummary for arrays use the documented delimiter getters
    // ---------------------------------------------------------------

    @Test
    public void testAppendDetailForIntArrayUsesArrayDelimiters() {
        int[] array = {1, 2, 3};
        StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", array);
        String expected = style.getArrayStart() + "1" + style.getArraySeparator()
                + "2" + style.getArraySeparator() + "3" + style.getArrayEnd();
        assertEquals(expected, buffer.toString());
    }

    @Test
    public void testAppendSummaryForIntArrayUsesSizeText() {
        int[] array = {1, 2, 3, 4, 5};
        StringBuffer buffer = new StringBuffer();
        style.appendSummary(buffer, "f", array);
        String expected = style.getSizeStartText() + array.length + style.getSizeEndText();
        assertEquals(expected, buffer.toString());
    }

    @Test
    public void testAppendSummaryForObjectArrayUsesSizeText() {
        Object[] array = {"a", "b", "c"};
        StringBuffer buffer = new StringBuffer();
        style.appendSummary(buffer, "f", array);
        String expected = style.getSizeStartText() + array.length + style.getSizeEndText();
        assertEquals(expected, buffer.toString());
    }

    @Test
    public void testAppendSummaryForObjectWrapsWithSummaryObjectText() {
        StringBuffer buffer = new StringBuffer();
        style.appendSummary(buffer, "f", "hello");
        String result = buffer.toString();
        assertTrue(result.startsWith(style.getSummaryObjectStartText()));
        assertTrue(result.endsWith(style.getSummaryObjectEndText()));
    }

    // ---------------------------------------------------------------
    // appendInternal routes to the correct detail/summary method by type
    // ---------------------------------------------------------------

    @Test
    public void testAppendInternalRoutesArraysByDetailFlag() {
        int[] array = {1, 2, 3};

        StringBuffer viaInternalDetail = new StringBuffer();
        style.appendInternal(viaInternalDetail, "f", array, true);
        StringBuffer viaDirectDetail = new StringBuffer();
        style.appendDetail(viaDirectDetail, "f", array);
        assertEquals(viaDirectDetail.toString(), viaInternalDetail.toString());

        StringBuffer viaInternalSummary = new StringBuffer();
        style.appendInternal(viaInternalSummary, "f", array, false);
        StringBuffer viaDirectSummary = new StringBuffer();
        style.appendSummary(viaDirectSummary, "f", array);
        assertEquals(viaDirectSummary.toString(), viaInternalSummary.toString());
    }

    @Test
    public void testAppendInternalRoutesPlainObjectsByDetailFlag() {
        String value = "hello";

        StringBuffer viaInternalDetail = new StringBuffer();
        style.appendInternal(viaInternalDetail, "f", value, true);
        StringBuffer viaDirectDetail = new StringBuffer();
        style.appendDetail(viaDirectDetail, "f", value);
        assertEquals(viaDirectDetail.toString(), viaInternalDetail.toString());

        StringBuffer viaInternalSummary = new StringBuffer();
        style.appendInternal(viaInternalSummary, "f", value, false);
        StringBuffer viaDirectSummary = new StringBuffer();
        style.appendSummary(viaDirectSummary, "f", value);
        assertEquals(viaDirectSummary.toString(), viaInternalSummary.toString());
    }

    @Test
    public void testAppendInternalRoutesCollectionsToDetailMethod() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");

        StringBuffer viaInternal = new StringBuffer();
        style.appendInternal(viaInternal, "f", list, true);
        StringBuffer viaDirect = new StringBuffer();
        style.appendDetail(viaDirect, "f", (Collection<?>) list);
        assertEquals(viaDirect.toString(), viaInternal.toString());
    }

    @Test
    public void testAppendInternalRoutesMapsToDetailMethod() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");

        StringBuffer viaInternal = new StringBuffer();
        style.appendInternal(viaInternal, "f", map, true);
        StringBuffer viaDirect = new StringBuffer();
        style.appendDetail(viaDirect, "f", (Map<?, ?>) map);
        assertEquals(viaDirect.toString(), viaInternal.toString());
    }

    @Test
    public void testAppendInternalIsInvariantToFieldName() {
        String value = "hello";
        StringBuffer b1 = new StringBuffer();
        style.appendInternal(b1, "fieldOne", value, true);
        StringBuffer b2 = new StringBuffer();
        style.appendInternal(b2, "fieldTwo", value, true);
        assertEquals(b1.toString(), b2.toString());
    }

    // ---------------------------------------------------------------
    // appendSuper / appendToString ignore null, otherwise append the given text
    // ---------------------------------------------------------------

    @Test
    public void testAppendSuperIgnoresNull() {
        StringBuffer buffer = new StringBuffer("existing");
        style.appendSuper(buffer, null);
        assertEquals("existing", buffer.toString());
    }

    @Test
    public void testAppendSuperAppendsNonNullSuperToString() {
        StringBuffer buffer = new StringBuffer();
        style.appendSuper(buffer, "SuperFragment");
        assertTrue(buffer.toString().contains("SuperFragment"));
    }

    @Test
    public void testAppendToStringIgnoresNull() {
        StringBuffer buffer = new StringBuffer("existing");
        style.appendToString(buffer, null);
        assertEquals("existing", buffer.toString());
    }

    @Test
    public void testAppendToStringAppendsNonNullToString() {
        StringBuffer buffer = new StringBuffer();
        style.appendToString(buffer, "OtherFragment");
        assertTrue(buffer.toString().contains("OtherFragment"));
    }

    // ---------------------------------------------------------------
    // reflectionAppendArrayDetail matches the typed appendDetail(array) methods
    // ---------------------------------------------------------------

    @Test
    public void testReflectionAppendArrayDetailMatchesTypedPrimitiveArrayDetail() {
        int[] array = {1, 2, 3};
        StringBuffer viaReflection = new StringBuffer();
        style.reflectionAppendArrayDetail(viaReflection, "f", array);
        StringBuffer viaTyped = new StringBuffer();
        style.appendDetail(viaTyped, "f", array);
        assertEquals(viaTyped.toString(), viaReflection.toString());
    }

    @Test
    public void testReflectionAppendArrayDetailMatchesTypedObjectArrayDetail() {
        String[] array = {"a", "b"};
        StringBuffer viaReflection = new StringBuffer();
        style.reflectionAppendArrayDetail(viaReflection, "f", array);
        StringBuffer viaTyped = new StringBuffer();
        style.appendDetail(viaTyped, "f", array);
        assertEquals(viaTyped.toString(), viaReflection.toString());
    }

    // ---------------------------------------------------------------
    // Null value handling for the public append dispatch methods
    // ---------------------------------------------------------------

    @Test
    public void testAppendNullObjectValueUsesNullText() {
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (Object) null, Boolean.TRUE);
        assertTrue(buffer.toString().contains(style.getNullText()));
    }

    @Test
    public void testAppendNullArrayValueUsesNullText() {
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (int[]) null, Boolean.TRUE);
        assertTrue(buffer.toString().contains(style.getNullText()));
    }

    // ---------------------------------------------------------------
    // Package-private registry / visited tracking (static, thread scoped)
    // ---------------------------------------------------------------

    @Test
    public void testRegistryLifecycle() {
        Object target = new Fixture();
        assertFalse(ToStringStyle.isRegistered(target));
        ToStringStyle.register(target);
        assertTrue(ToStringStyle.isRegistered(target));
        Map<Object, Object> registry = ToStringStyle.getRegistry();
        assertNotNull(registry);
        assertTrue(registry.containsKey(target));
        ToStringStyle.unregister(target);
        assertFalse(ToStringStyle.isRegistered(target));
    }

    @Test
    public void testVisitedMarkIsClearedWhenRegistryStackEmpties() {
        Object target = new Fixture();
        assertFalse(ToStringStyle.isVisited(target));

        ToStringStyle.register(target);
        ToStringStyle.markVisited(target);
        assertTrue(ToStringStyle.isVisited(target));

        ToStringStyle.unregister(target);
        assertFalse(ToStringStyle.isVisited(target));
    }

    // ---------------------------------------------------------------
    // Public append wrappers include the value and, conditionally, the field name
    // ---------------------------------------------------------------

    @Test
    public void testPublicAppendBooleanIncludesValueAndConditionalFieldName() {
        style.setUseFieldNames(true);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "flag", true);
        String result = buffer.toString();
        assertTrue(result.contains("true"));
        assertTrue(result.contains("flag"));

        style.setUseFieldNames(false);
        StringBuffer buffer2 = new StringBuffer();
        style.append(buffer2, "flag", true);
        assertFalse(buffer2.toString().contains("flag"));
    }

    @Test
    public void testPublicAppendIntIncludesValueAndConditionalFieldName() {
        style.setUseFieldNames(true);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "count", 99);
        String result = buffer.toString();
        assertTrue(result.contains("99"));
        assertTrue(result.contains("count"));

        style.setUseFieldNames(false);
        StringBuffer buffer2 = new StringBuffer();
        style.append(buffer2, "count", 99);
        assertFalse(buffer2.toString().contains("count"));
    }
}
