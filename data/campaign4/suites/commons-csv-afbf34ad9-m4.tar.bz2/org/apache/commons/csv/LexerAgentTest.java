/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    // --- nextToken() basic cases -------------------------------------------------

    @Test
    void testNextTokenSimpleFields() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b,c");
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("b", t2.content.toString());

        final Token t3 = new Token();
        lexer.nextToken(t3);
        // No trailing newline, so the last field is reported directly as EOF with content.
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("c", t3.content.toString());
        assertTrue(t3.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenEmptyInputIsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenTrailingDataAtEofIsReady() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("abc", token.content.toString());
        assertTrue(token.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenCrLfEndOfRecord() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\r\nb");
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());
        assertEquals(Constants.CRLF, lexer.getFirstEol());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("b", t2.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEmptyLineIgnored() throws IOException {
        // DEFAULT has ignoreEmptyLines=true
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\n\na\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEmptyLineAtEndOfFileWhenIgnored() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenEmptyLineNotIgnored() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "\na");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("", token.content.toString());
        lexer.close();
    }

    // --- comments -----------------------------------------------------------------

    @Test
    void testNextTokenComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "# a comment\nvalue");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        final Token token2 = new Token();
        lexer.nextToken(token2);
        assertEquals(Token.Type.EOF, token2.type);
        assertEquals("value", token2.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenCommentAtEofWithNoContentIsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "#");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    // --- quoting / encapsulation -----------------------------------------------

    @Test
    void testNextTokenQuotedSimple() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"hello\",b");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("hello", token.content.toString());
        assertTrue(token.isQuoted);
        lexer.close();
    }

    @Test
    void testNextTokenQuotedWithEscapedQuote() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"he said \"\"hi\"\"\"");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("he said \"hi\"", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenUnexpectedEofThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"unterminated");
        final Token token = new Token();
        final CSVException exception = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(exception.getMessage().contains("EOF"));
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenLenientEofReturnsPartialToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"unterminated");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("unterminated", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenInvalidCharAfterQuoteThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"b,c");
        final Token token = new Token();
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenTrailingDataAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"a\"trailing,c");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("atrailing", token.content.toString());
        lexer.close();
    }

    // --- escaping -----------------------------------------------------------------

    @Test
    void testReadEscapeKnownSequences() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        Lexer lexer = createLexer(format, "r");
        assertEquals(Constants.CR, lexer.readEscape());
        lexer.close();

        lexer = createLexer(format, "n");
        assertEquals(Constants.LF, lexer.readEscape());
        lexer.close();

        lexer = createLexer(format, "t");
        assertEquals(Constants.TAB, lexer.readEscape());
        lexer.close();

        lexer = createLexer(format, "b");
        assertEquals(Constants.BACKSPACE, lexer.readEscape());
        lexer.close();

        lexer = createLexer(format, "f");
        assertEquals(Constants.FF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeUnknownCharReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "z");
        final int result = lexer.readEscape();
        assertEquals(org.apache.commons.io.IOUtils.EOF, result);
        lexer.close();
    }

    @Test
    void testReadEscapeAtEofThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "");
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        lexer.close();
    }

    @Test
    void testNextTokenWithEscapedDelimiterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\,b,c");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenWithUnexpectedCharAfterEscape() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\zb");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a\\zb", token.content.toString());
        lexer.close();
    }

    // --- isDelimiter / isEscapeDelimiter with multi-char delimiter ----------------

    @Test
    void testIsDelimiterMultiCharDelimiter() throws IOException {
        // isDelimiter(ch) assumes ch was just consumed from the reader via reader.read(),
        // so the reader must be advanced in lockstep with the character under test.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(":x"));
        final Lexer lexer = new Lexer(format, reader);
        final int c = reader.read();
        // first char matches delimiter[0] but the rest does not match -> not a delimiter
        assertFalse(lexer.isDelimiter(c));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("::rest"));
        final Lexer lexer = new Lexer(format, reader);
        final int c = reader.read();
        assertTrue(lexer.isDelimiter(c));
        lexer.close();
    }

    @Test
    void testIsDelimiterWrongFirstChar() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertFalse(lexer.isDelimiter('x'));
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterMatchesUpcomingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, ",rest");
        assertTrue(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterNoMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "xrest");
        assertFalse(lexer.isEscapeDelimiter());
        lexer.close();
    }

    // --- isCommentStart / isQuoteChar / isEscape / isEndOfFile / isStartOfLine ----

    @Test
    void testIsCommentStartDisabledByDefault() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "#");
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    void testIsCommentStartEnabled() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "#");
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    @Test
    void testIsQuoteChar() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"");
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
    }

    @Test
    void testIsEscapeDisabledByDefault() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\\");
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    void testIsEscapeEnabled() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "\\");
        assertTrue(lexer.isEscape('\\'));
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(org.apache.commons.io.IOUtils.EOF));
        assertFalse(lexer.isEndOfFile('a'));
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    // --- readEndOfLine ---------------------------------------------------------

    @Test
    void testReadEndOfLineLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.readEndOfLine(Constants.LF));
        assertEquals(Character.toString(Constants.LF), lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCr() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals(Character.toString(Constants.CR), lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineNotEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.readEndOfLine('a'));
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrLfConsumesLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\nrest");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals(Constants.CRLF, lexer.getFirstEol());
        // The LF should have been consumed as part of the CRLF sequence, so the
        // next token starts right at "rest" rather than seeing a leading blank line.
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals("rest", token.content.toString());
        lexer.close();
    }

    // --- trimTrailingSpaces -----------------------------------------------------

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testTrimTrailingSpacesNoTrailingSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testTrimTrailingSpacesAllSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("", sb.toString());
    }

    // --- ignoreSurroundingSpaces -------------------------------------------------

    @Test
    void testIgnoreSurroundingSpacesTrimsSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  ,b");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesFalseKeepsSpaces() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(false).get();
        final Lexer lexer = createLexer(format, "  a  ,b");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("  a  ", token.content.toString());
        lexer.close();
    }

    // --- position/line number/bytes read/close/isClosed --------------------------

    @Test
    void testGetCharacterPositionAdvancesWithReads() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "ab,cd");
        assertEquals(0, lexer.getCharacterPosition());
        final Token token = new Token();
        lexer.nextToken(token);
        assertTrue(lexer.getCharacterPosition() > 0);
        lexer.close();
    }

    @Test
    void testGetCurrentLineNumberIncrementsOnEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\nb\nc");
        assertEquals(0, lexer.getCurrentLineNumber());
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(1, lexer.getCurrentLineNumber());
        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(2, lexer.getCurrentLineNumber());
        lexer.close();
    }

    @Test
    void testGetBytesReadWithoutTrackingIsZero() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        final Token token = new Token();
        lexer.nextToken(token);
        // No charset/byte tracking configured via this constructor path, so byte count stays 0.
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testIsClosedAndClose() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testNextTokenAfterCloseThrowsIOException() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        lexer.close();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
    }

    // --- getFirstEol default -----------------------------------------------------

    @Test
    void testGetFirstEolInitiallyNull() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        assertNull(lexer.getFirstEol());
    }
}
