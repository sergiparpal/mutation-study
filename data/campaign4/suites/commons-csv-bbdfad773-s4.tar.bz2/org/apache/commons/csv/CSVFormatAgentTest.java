package org.apache.commons.csv;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/**
 * Self-contained tests for {@link CSVFormat} based on the documented contract in api/.
 */
public class CSVFormatAgentTest {

    private enum Header {
        NAME, EMAIL
    }

    // ---- Predefined format: DEFAULT ----

    @Test
    public void testDefaultFormat() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
    }

    // ---- Predefined format: EXCEL ----

    @Test
    public void testExcelFormat() {
        assertEquals(",", CSVFormat.EXCEL.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.EXCEL.getDuplicateHeaderMode());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    // ---- Predefined format: RFC4180 ----

    @Test
    public void testRfc4180Format() {
        assertEquals(",", CSVFormat.RFC4180.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    // ---- Predefined format: TDF ----

    @Test
    public void testTdfFormat() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    // ---- Predefined format: MYSQL ----

    @Test
    public void testMySqlFormat() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    // ---- Predefined format: ORACLE ----

    @Test
    public void testOracleFormat() {
        assertEquals(",", CSVFormat.ORACLE.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.ORACLE.getEscapeCharacter());
        assertFalse(CSVFormat.ORACLE.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), CSVFormat.ORACLE.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.ORACLE.getNullString());
        assertTrue(CSVFormat.ORACLE.getTrim());
        assertEquals(System.lineSeparator(), CSVFormat.ORACLE.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.ORACLE.getQuoteMode());
    }

    // ---- Predefined format: POSTGRESQL_CSV ----

    @Test
    public void testPostgreSqlCsvFormat() {
        assertEquals(",", CSVFormat.POSTGRESQL_CSV.getDelimiterString());
        assertNull(CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertFalse(CSVFormat.POSTGRESQL_CSV.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), CSVFormat.POSTGRESQL_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_CSV.getRecordSeparator());
        assertEquals("", CSVFormat.POSTGRESQL_CSV.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_CSV.getQuoteMode());
    }

    // ---- Predefined format: POSTGRESQL_TEXT ----

    @Test
    public void testPostgreSqlTextFormat() {
        assertEquals("\t", CSVFormat.POSTGRESQL_TEXT.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.POSTGRESQL_TEXT.getEscapeCharacter());
        assertNull(CSVFormat.POSTGRESQL_TEXT.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_TEXT.getRecordSeparator());
        assertEquals("\\N", CSVFormat.POSTGRESQL_TEXT.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_TEXT.getQuoteMode());
    }

    // ---- Predefined format: INFORMIX_UNLOAD / INFORMIX_UNLOAD_CSV ----

    @Test
    public void testInformixUnloadFormat() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD_CSV.getRecordSeparator());
    }

    // ---- Predefined format: MONGODB_CSV / MONGODB_TSV ----

    @Test
    public void testMongoDbCsvFormat() {
        assertEquals(",", CSVFormat.MONGODB_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_CSV.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFormat() {
        assertEquals("\t", CSVFormat.MONGODB_TSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_TSV.getQuoteMode());
        assertFalse(CSVFormat.MONGODB_TSV.getSkipHeaderRecord());
    }

    // ---- Predefined enum ----

    @Test
    public void testPredefinedEnumMapsToStaticFields() {
        assertEquals(12, CSVFormat.Predefined.values().length);
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.ORACLE, CSVFormat.Predefined.Oracle.getFormat());
        assertEquals(CSVFormat.POSTGRESQL_CSV, CSVFormat.Predefined.PostgreSQLCsv.getFormat());
        assertEquals(CSVFormat.POSTGRESQL_TEXT, CSVFormat.Predefined.PostgreSQLText.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
        assertEquals(CSVFormat.MONGODB_CSV, CSVFormat.Predefined.MongoDBCsv.getFormat());
        assertEquals(CSVFormat.MONGODB_TSV, CSVFormat.Predefined.MongoDBTsv.getFormat());
    }

    // ---- valueOf(String) ----

    @Test
    public void testValueOfKnownName() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
    }

    @Test
    public void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotARealFormat");
            }
        });
    }

    @Test
    public void testValueOfNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf(null);
            }
        });
    }

    // ---- newFormat(char) ----

    @Test
    public void testNewFormatInitializesOtherFieldsToDefaults() {
        CSVFormat format = CSVFormat.newFormat('|');
        assertEquals("|", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertNull(format.getNullString());
        assertNull(format.getRecordSeparator());
        assertNull(format.getQuoteMode());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.isNullStringSet());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // ---- builder() / Builder.create() ----

    @Test
    public void testBuilderCreateDefaults() {
        CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getTrim());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
    }

    @Test
    public void testBuilderCreateFromFormatIsIndependent() {
        CSVFormat.Builder builder = CSVFormat.Builder.create(CSVFormat.DEFAULT);
        CSVFormat modified = builder.setDelimiter(';').get();
        assertEquals(";", modified.getDelimiterString());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    public void testBuilderOnInstanceProducesEquivalentFormat() {
        CSVFormat modified = CSVFormat.DEFAULT.builder().setNullString("N/A").setIgnoreSurroundingSpaces(true).get();
        assertEquals("N/A", modified.getNullString());
        assertTrue(modified.getIgnoreSurroundingSpaces());
        assertEquals(",", modified.getDelimiterString());
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testBuilderGetAndDeprecatedBuildAreEquivalent() {
        CSVFormat viaGet = CSVFormat.Builder.create().setDelimiter(';').setTrim(true).get();
        CSVFormat viaBuild = CSVFormat.Builder.create().setDelimiter(';').setTrim(true).build();
        assertEquals(viaGet, viaBuild);
    }

    // ---- Builder setters: header ----

    @Test
    public void testSetHeaderKeepsCopyOfInputArray() {
        String[] header = { "a", "b" };
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        header[0] = "changed";
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    public void testGetHeaderReturnsIndependentCopy() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        String[] first = format.getHeader();
        first[0] = "mutated";
        String[] second = format.getHeader();
        assertEquals("a", second[0]);
    }

    @Test
    public void testSetHeaderWithEnumClass() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL" }, format.getHeader());
    }

    @Test
    public void testSetHeaderNullDisablesHeader() {
        CSVFormat withHeader = CSVFormat.DEFAULT.builder().setHeader("a").get();
        CSVFormat withoutHeader = withHeader.builder().setHeader((String[]) null).get();
        assertNull(withoutHeader.getHeader());
    }

    @Test
    public void testSetHeaderEmptyMeansParseAutomatically() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    // ---- Builder setters: header comments ----

    @Test
    public void testGetHeaderCommentsReturnsIndependentCopy() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", "two").get();
        String[] first = format.getHeaderComments();
        assertArrayEquals(new String[] { "one", "two" }, first);
        first[0] = "mutated";
        String[] second = format.getHeaderComments();
        assertEquals("one", second[0]);
    }

    @Test
    public void testHeaderCommentsNullByDefault() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // ---- Builder setters: delimiter ----

    @Test
    public void testSetDelimiterString() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
        assertArrayEquals(new char[] { ':', ':' }, format.getDelimiterCharArray());
    }

    @Test
    public void testGetDelimiterReturnsFirstCharacter() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
    }

    // ---- Builder setters: comment marker ----

    @Test
    public void testCommentMarkerDefaultUnset() {
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
    }

    @Test
    public void testSetCommentMarkerChar() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    public void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker('\n');
            }
        });
    }

    // ---- Builder setters: escape ----

    @Test
    public void testSetEscapeChar() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals('\\', format.getEscapeChar());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    public void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setEscape('\r');
            }
        });
    }

    @Test
    public void testEscapeCharDefaultsToZeroWhenUnset() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertEquals((char) 0, CSVFormat.DEFAULT.getEscapeChar());
    }

    // ---- Builder setters: quote ----

    @Test
    public void testSetQuoteCharacter() {
        CSVFormat format = CSVFormat.newFormat(',').builder().setQuote('\'').get();
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());
    }

    @Test
    public void testSetQuoteCharacterNullDisables() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void testSetQuoteModeAndGet() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL_NON_NULL).get();
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    // ---- Builder setters: null string ----

    @Test
    public void testNullStringDefaultUnset() {
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
    }

    @Test
    public void testSetNullString() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    // ---- Builder setters: max rows ----

    @Test
    public void testMaxRowsDefaultsToZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    public void testSetMaxRowsRoundTrips() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    public void testUseMaxRowsDiffersBetweenNoLimitAndLimit() {
        CSVFormat noLimit = CSVFormat.DEFAULT.builder().setMaxRows(0L).get();
        CSVFormat limited = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertNotEquals(noLimit.useMaxRows(), limited.useMaxRows());
    }

    // ---- Builder setters: boolean flags ----

    @Test
    public void testBooleanFlagSetters() {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setAllowMissingColumnNames(true)
                .setAutoFlush(true)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setSkipHeaderRecord(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .setLenientEof(true)
                .setTrailingData(true)
                .get();
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getAutoFlush());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
        assertTrue(format.getLenientEof());
        assertTrue(format.getTrailingData());
    }

    // ---- equals / hashCode ----

    @Test
    public void testEqualsReflexiveAndTypeSafe() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(null, CSVFormat.DEFAULT);
        assertNotEquals("not a format", CSVFormat.DEFAULT);
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentFormats() {
        CSVFormat a = CSVFormat.newFormat(',').builder().setQuote('"').setRecordSeparator("\n").get();
        CSVFormat b = CSVFormat.newFormat(',').builder().setQuote('"').setRecordSeparator("\n").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsFalseForDifferentDelimiter() {
        CSVFormat a = CSVFormat.newFormat(',');
        CSVFormat b = CSVFormat.newFormat(';');
        assertNotEquals(a, b);
    }

    // ---- toString ----

    @Test
    public void testToStringIsDeterministicAndNotNull() {
        String first = CSVFormat.DEFAULT.toString();
        String second = CSVFormat.DEFAULT.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }

    // ---- format(Object...) ----

    @Test
    public void testFormatNoValues() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    public void testFormatEscapesEmbeddedQuoteCharacter() {
        assertEquals("\"a\"\"b\"", CSVFormat.DEFAULT.format("a\"b"));
    }

    @Test
    public void testFormatNullValueWithoutNullStringIsEmpty() {
        assertEquals("", CSVFormat.DEFAULT.format((Object) null));
    }

    @Test
    public void testFormatNullValueWithNullStringSubstitutes() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL", format.format((Object) null));
    }

    // ---- print(Object, Appendable, boolean) ----

    @Test
    public void testPrintValueNewRecordVsContinuation() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a", sb, true);
        CSVFormat.DEFAULT.print("b", sb, false);
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testPrintTrimsValueWhenTrimIsSet() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        StringBuilder sb = new StringBuilder();
        format.print("  hello  ", sb, true);
        assertEquals("hello", sb.toString());
    }

    // ---- println(Appendable) ----

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(format.getDelimiterString() + "\n", sb.toString());
    }

    @Test
    public void testPrintlnWithoutTrailingDelimiter() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").setTrailingDelimiter(false).get();
        StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals("\n", sb.toString());
    }

    // ---- printRecord(Appendable, Object...) ----

    @Test
    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "x", "y", "z");
        assertEquals("x,y,z\r\n", sb.toString());
    }

    // ---- print(Appendable) / printer() returning CSVPrinter ----

    @Test
    public void testPrintToAppendableReturnsUsablePrinter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        assertNotNull(printer);
        printer.close();
    }

    @Test
    public void testPrinterReturnsNonNullPrinter() throws IOException {
        CSVPrinter printer = CSVFormat.DEFAULT.printer();
        assertNotNull(printer);
        printer.close();
    }

    // ---- print(File, Charset) / print(Path, Charset) ----

    @Test
    public void testPrintToFileWritesNoContentWithoutExplicitWrites() throws IOException {
        File tempFile = File.createTempFile("csvformatagenttest", ".csv");
        tempFile.deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(tempFile, StandardCharsets.UTF_8);
        printer.close();
        assertEquals(0L, tempFile.length());
        tempFile.delete();
    }

    @Test
    public void testPrintToPathReturnsClosablePrinter() throws IOException {
        Path tempPath = Files.createTempFile("csvformatagenttest", ".csv");
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(tempPath, StandardCharsets.UTF_8);
            assertNotNull(printer);
            printer.close();
        } finally {
            Files.deleteIfExists(tempPath);
        }
    }

    // ---- parse(Reader) ----

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n"));
        assertNotNull(parser);
        parser.close();
    }

    // ---- package-private helpers exposed by the javadoc ----

    @Test
    public void testCopyInstanceIsEqualToOriginal() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @Test
    public void testStaticCopyIsNullSafe() {
        assertNull(CSVFormat.copy(null));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.copy(CSVFormat.DEFAULT));
    }

    @Test
    public void testCloneIsNullSafeAndCopiesArray() {
        String[] source = { "a", "b" };
        String[] cloned = CSVFormat.clone(source);
        assertArrayEquals(source, cloned);
        assertNotSame(source, cloned);
        assertNull(CSVFormat.<String>clone((String[]) null));
    }

    @Test
    public void testGetDelimiterCharArrayMatchesDelimiterString() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertTrue(Arrays.equals(new char[] { ':', ':' }, format.getDelimiterCharArray()));
    }
}
