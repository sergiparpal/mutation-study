package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;

/**
 * Self-contained JUnit tests for
 * {@link org.apache.commons.lang3.text.translate.NumericEntityUnescaper}.
 */
public class NumericEntityUnescaperAgentTest {

    /** A Writer that always fails, used to verify IOException propagation. */
    private static final class FailingWriter extends Writer {
        @Override
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public void flush() throws IOException {
            // no-op
        }

        @Override
        public void close() throws IOException {
            // no-op
        }
    }

    // ---- isSet() / constructor option tracking ----

    @Test
    public void testNoOptionsSetByDefault() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    public void testSingleOptionIsSet() {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    public void testMultipleOptionsAreAllSet() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    public void testDuplicateOptionStillSet() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
    }

    @Test
    public void testNoArgumentOptionsLeavesEverythingUnset() {
        NumericEntityUnescaper.OPTION[] noOptions = new NumericEntityUnescaper.OPTION[0];
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper(noOptions);
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    // ---- translate(): decimal / hex entities, with semicolon ----

    @Test
    public void testTranslateDecimalEntityWithSemicolon() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65;", 0, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateHexEntityLowerX() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#x41;", 0, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateHexEntityUpperX() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#X41;", 0, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testTranslateMultiDigitDecimalEntity() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#8364;", 0, out);
        assertEquals(7, consumed);
        assertEquals("€", out.toString());
    }

    @Test
    public void testTranslateSupplementaryCodePoint() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        String entity = "&#128512;";
        int consumed = unescaper.translate(entity, 0, out);
        assertEquals(entity.length(), consumed);
        assertEquals(new String(Character.toChars(128512)), out.toString());
    }

    @Test
    public void testTranslateZeroCodePoint() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#0;", 0, out);
        assertEquals(4, consumed);
        assertEquals("\u0000", out.toString());
    }

    @Test
    public void testTranslateAtNonZeroIndex() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("xy&#65;z", 2, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    // ---- translate(): non-matching input ----

    @Test
    public void testTranslateNonEntityTextConsumesNothing() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("abc", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testTranslateNamedEntityConsumesNothing() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&amp;", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testTranslateEntityWithNoDigitsConsumesNothing() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#;", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testTranslateHexEntityWithNoDigitsConsumesNothing() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#x;", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    // ---- translate(): semicolon-optional behaviour ----

    @Test
    public void testDefaultConstructorIgnoresMissingSemicolon() throws IOException {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65", 0, out);
        assertEquals(4, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testSemiColonOptionalAllowsMissingSemicolon() throws IOException {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65", 0, out);
        assertEquals(4, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testSemiColonOptionalStillHandlesPresentSemicolon() throws IOException {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65;", 0, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    // ---- translate(): errorIfNoSemiColon behaviour ----

    @Test
    public void testErrorIfNoSemiColonThrowsWhenSemicolonMissing() {
        final NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final StringWriter out = new StringWriter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("&#65", 0, out);
            }
        });
    }

    @Test
    public void testErrorIfNoSemiColonAcceptsPresentSemicolon() throws IOException {
        NumericEntityUnescaper unescaper =
                new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("&#65;", 0, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    // ---- translate(): IOException propagation from the Writer ----

    @Test
    public void testTranslatePropagatesIOExceptionFromWriter() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final Writer failingWriter = new FailingWriter();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("&#65;", 0, failingWriter);
            }
        });
    }

    // ---- inheritance contract ----

    @Test
    public void testIsSubclassOfCharSequenceTranslator() {
        NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertTrue(unescaper instanceof CharSequenceTranslator);
    }
}
