package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Formattable;
import java.util.FormattableFlags;
import java.util.Formatter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FormattableUtils}, based solely on the
 * documented contract: the append(...) overloads perform a
 * truncate-pad-append operation on a {@link Formatter} and return that same
 * formatter instance, and toString(Formattable) returns the formattable's
 * default formatted representation.
 */
public class FormattableUtilsAgentTest {

    /** A Formattable that records the flags/width/precision it receives and writes fixed text. */
    private static final class RecordingFormattable implements Formattable {
        private final String text;
        private int lastFlags = Integer.MIN_VALUE;
        private int lastWidth = Integer.MIN_VALUE;
        private int lastPrecision = Integer.MIN_VALUE;

        RecordingFormattable(String text) {
            this.text = text;
        }

        public void formatTo(Formatter formatter, int flags, int width, int precision) {
            this.lastFlags = flags;
            this.lastWidth = width;
            this.lastPrecision = precision;
            formatter.format(text);
        }
    }

    // ---- append(seq, formatter, flags, width, precision) ----

    @Test
    public void testAppendBasicNoWidthNoPrecision() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hello", formatter, 0, 0, -1);
        assertSame(formatter, result, "append must return the same formatter instance it was given");
        assertEquals("Hello", result.toString());
    }

    @Test
    public void testAppendPadsWithSpacesRightJustifiedByDefault() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hi", formatter, 0, 5, -1);
        assertEquals("   Hi", result.toString());
    }

    @Test
    public void testAppendLeftJustifyPadsOnRight() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hi", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1);
        assertEquals("Hi   ", result.toString());
    }

    @Test
    public void testAppendWidthSmallerThanContentCausesNoPadding() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, 2, -1);
        assertEquals("HelloWorld", result.toString());
    }

    @Test
    public void testAppendHardTruncatesWhenPrecisionLessThanLength() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, -1, 5);
        assertEquals("Hello", result.toString());
    }

    @Test
    public void testAppendPrecisionZeroTruncatesToEmpty() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hello", formatter, 0, -1, 0);
        assertEquals("", result.toString());
    }

    @Test
    public void testAppendPrecisionGreaterThanLengthHasNoEffect() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hi", formatter, 0, -1, 10);
        assertEquals("Hi", result.toString());
    }

    @Test
    public void testAppendNullSequenceThrows() {
        Formatter formatter = new Formatter();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FormattableUtils.append(null, formatter, 0, 0, -1);
            }
        });
    }

    @Test
    public void testAppendNullFormatterThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FormattableUtils.append("Hello", null, 0, 0, -1);
            }
        });
    }

    // ---- append(seq, formatter, flags, width, precision, padChar) ----

    @Test
    public void testAppendWithCustomPadChar() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hi", formatter, 0, 5, -1, '*');
        assertEquals("***Hi", result.toString());
    }

    @Test
    public void testAppendWithCustomPadCharLeftJustified() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hi", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1, '-');
        assertEquals("Hi---", result.toString());
    }

    @Test
    public void testAppendWithPadCharNoPaddingNeeded() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hello", formatter, 0, 3, -1, '*');
        assertEquals("Hello", result.toString());
    }

    @Test
    public void testAppendWithPadCharAndTruncation() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, 8, 5, '*');
        assertEquals("***Hello", result.toString());
    }

    // ---- append(seq, formatter, flags, width, precision, ellipsis) ----

    @Test
    public void testAppendWithEllipsisTruncation() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, -1, 5, "...");
        assertEquals("He...", result.toString());
    }

    @Test
    public void testAppendWithEmptyEllipsisIsHardTruncation() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, -1, 5, "");
        assertEquals("Hello", result.toString());
    }

    @Test
    public void testAppendWithNullEllipsisIsHardTruncation() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, -1, 5, (CharSequence) null);
        assertEquals("Hello", result.toString());
    }

    @Test
    public void testAppendWithEllipsisAndPaddingDefaultSpace() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, 8, 5, "...");
        assertEquals("   He...", result.toString());
    }

    @Test
    public void testAppendEllipsisLongerThanPrecisionThrows() {
        final Formatter formatter = new Formatter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FormattableUtils.append("HelloWorld", formatter, 0, -1, 2, "...");
            }
        });
    }

    // ---- append(seq, formatter, flags, width, precision, padChar, ellipsis) ----

    @Test
    public void testAppendFullSignatureTruncatesPadsAndAppends() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append(
                "HelloWorld", formatter, FormattableFlags.LEFT_JUSTIFY, 8, 5, '-', "..");
        assertSame(formatter, result);
        assertEquals("Hel..---", result.toString());
    }

    @Test
    public void testAppendFullSignatureRightJustifiedWithCustomPad() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, 8, 5, '-', "..");
        assertEquals("---Hel..", result.toString());
    }

    @Test
    public void testAppendFullSignatureEllipsisEqualToPrecision() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("HelloWorld", formatter, 0, -1, 3, ' ', "...");
        assertEquals("...", result.toString());
    }

    @Test
    public void testAppendFullSignatureNegativeWidthAndPrecisionLeavesSeqUnchanged() {
        Formatter formatter = new Formatter();
        Formatter result = FormattableUtils.append("Hello", formatter, 0, -1, -1, '*', (CharSequence) null);
        assertEquals("Hello", result.toString());
    }

    // ---- toString(Formattable) ----

    @Test
    public void testToStringReturnsFormattableDefaultRepresentation() {
        RecordingFormattable formattable = new RecordingFormattable("recorded-text");
        String result = FormattableUtils.toString(formattable);
        assertNotNull(result);
        assertEquals("recorded-text", result);
    }

    @Test
    public void testToStringUsesDefaultFlagsWidthAndPrecision() {
        RecordingFormattable formattable = new RecordingFormattable("x");
        FormattableUtils.toString(formattable);
        // Per java.util.Formattable's contract, a default/unspecified width or
        // precision is represented as -1, and no flags are set.
        assertEquals(0, formattable.lastFlags);
        assertEquals(-1, formattable.lastWidth);
        assertEquals(-1, formattable.lastPrecision);
    }

    @Test
    public void testToStringNullFormattableThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FormattableUtils.toString(null);
            }
        });
    }

    @Test
    public void testToStringWithEmptyFormattedRepresentation() {
        RecordingFormattable formattable = new RecordingFormattable("");
        String result = FormattableUtils.toString(formattable);
        assertNotNull(result);
        assertEquals("", result);
    }

    // ---- constructor ----

    @Test
    public void testPublicConstructorIsUsable() {
        FormattableUtils instance = new FormattableUtils();
        assertTrue(instance instanceof FormattableUtils);
    }
}
