/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
public class CSVParserAgentTest {

    @Test
    public void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,42\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, headerMap.size());

            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(2, headerNames.size());
            assertEquals("name", headerNames.get(0));
            assertEquals("age", headerNames.get(1));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("42", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapIsCopyNotLive() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            final Map<String, Integer> first = parser.getHeaderMap();
            first.put("z", 99);
            final Map<String, Integer> second = parser.getHeaderMap();
            assertFalse(second.containsKey("z"));
            assertEquals(2, second.size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoHeaderMeansNullHeaderMap() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDuplicateHeaderThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,a\n1,2\n", format);
            }
        });
    }

    @Test
    public void testMissingHeaderNameNotAllowedThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setAllowMissingColumnNames(false).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,,c\n1,2,3\n", format);
            }
        });
    }

    @Test
    public void testMissingHeaderNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setAllowMissingColumnNames(true).get();
        final CSVParser parser = CSVParser.parse("a,,c\n1,2,3\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(3, headerNames.size());
            assertEquals("a", headerNames.get(0));
            assertEquals("", headerNames.get(1));
            assertEquals("c", headerNames.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextAndNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            final CSVRecord first = it.next();
            assertEquals("1", first.get(0));
            assertTrue(it.hasNext());
            final CSVRecord second = it.next();
            assertEquals("3", second.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutHasNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertEquals("1", record.get(0));
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCloseMakesIteratorEmptyAndNextThrows() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    public void testRecordNumberIncrementsPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = parser.nextRecord();
            assertEquals(3, r3.getRecordNumber());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testRecordNumberStartOffsetFromDeprecatedConstructor() throws IOException {
        final StringReader reader = new StringReader("a\nb\n");
        final CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT, 0, 5);
        try {
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(5, r1.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(6, r2.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testBuilderRecordNumberOffset() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(10)
                .get();
        try {
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(10, r1.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedFieldsAndEmbeddedDelimiter() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a,b", records.get(0).get(0));
            assertEquals("c", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingDelimiterDropsEmptyLastField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedEmptyFieldKeptEvenWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\"\"\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals(3, record.size());
            assertEquals("", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullStringHandling() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreSkippedAndNotInRecords() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("# comment line\na,b\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderCommentCapturedWhenPrecedingHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();
        final CSVParser parser = CSVParser.parse("# header comment\nname,age\nJohn,42\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoHeaderCommentByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailerCommentCapturedAfterLastRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("a,b\n# trailer comment", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer comment", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetFirstEndOfLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testStreamProducesSameRecordsAsGetRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.stream().collect(java.util.stream.Collectors.toList());
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get(0));
            assertEquals("4", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testMaxRowsLimitsIterationAndRecordCount() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get(0));
            assertEquals("2", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidTokenThrowsCsvException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser = CSVParser.parse("\"a\"b,c\n", format);
        try {
            final java.io.UncheckedIOException thrown = assertThrows(java.io.UncheckedIOException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    parser.getRecords();
                }
            });
            assertTrue(thrown.getCause() instanceof CSVException);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullFileThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.io.File) null, java.nio.charset.StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testNullPathThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.nio.file.Path) null, java.nio.charset.StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testNullUrlThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.net.URL) null, java.nio.charset.StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testNullFormatDefaultsToCsvFormatDefault() throws IOException {
        final CSVParser parser = CSVParser.parse(new StringReader("a,b\n"), null);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n\nb\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderIgnoreCaseMatchesColumn() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setIgnoreHeaderCase(true).get();
        final CSVParser parser = CSVParser.parse("Name,Age\nJohn,42\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("John", record.get("name"));
            assertEquals("42", record.get("AGE"));
        } finally {
            parser.close();
        }
    }
}
