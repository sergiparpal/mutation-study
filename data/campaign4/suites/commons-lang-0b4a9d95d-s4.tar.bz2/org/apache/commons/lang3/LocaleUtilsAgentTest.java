package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

public class LocaleUtilsAgentTest {

    // --- availableLocaleList() ---

    @Test
    public void testAvailableLocaleListNotNullAndNotEmpty() {
        List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
    }

    @Test
    public void testAvailableLocaleListUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                list.add(Locale.CANADA);
            }
        });
    }

    @Test
    public void testAvailableLocaleListSameContentAsSet() {
        List<Locale> list = LocaleUtils.availableLocaleList();
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertEquals(set.size(), list.size());
        assertTrue(set.containsAll(list));
        assertTrue(list.containsAll(set));
    }

    // --- availableLocaleSet() ---

    @Test
    public void testAvailableLocaleSetNotNullAndNotEmpty() {
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
    }

    @Test
    public void testAvailableLocaleSetUnmodifiable() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                set.add(Locale.CANADA);
            }
        });
    }

    // --- countriesByLanguage(String) ---

    @Test
    public void testCountriesByLanguageNullReturnsEmpty() {
        List<Locale> result = LocaleUtils.countriesByLanguage(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageEnglish() {
        List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Iterator<Locale> it = result.iterator(); it.hasNext();) {
            Locale locale = it.next();
            assertEquals("en", locale.getLanguage());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testCountriesByLanguageUnknownLanguageReturnsEmpty() {
        List<Locale> result = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageUnmodifiable() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.CANADA);
            }
        });
    }

    @Test
    public void testCountriesByLanguageIsCached() {
        List<Locale> first = LocaleUtils.countriesByLanguage("en");
        List<Locale> second = LocaleUtils.countriesByLanguage("en");
        assertEquals(first, second);
    }

    // --- languagesByCountry(String) ---

    @Test
    public void testLanguagesByCountryNullReturnsEmpty() {
        List<Locale> result = LocaleUtils.languagesByCountry(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUs() {
        List<Locale> result = LocaleUtils.languagesByCountry("US");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (Iterator<Locale> it = result.iterator(); it.hasNext();) {
            Locale locale = it.next();
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testLanguagesByCountryUnknownCountryReturnsEmpty() {
        List<Locale> result = LocaleUtils.languagesByCountry("zz");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUnmodifiable() {
        final List<Locale> result = LocaleUtils.languagesByCountry("US");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.CANADA);
            }
        });
    }

    // --- isAvailableLocale(Locale) ---

    @Test
    public void testIsAvailableLocaleMatchesSetMembership() {
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        Locale known = set.iterator().next();
        assertTrue(LocaleUtils.isAvailableLocale(known));
        assertEquals(set.contains(known), LocaleUtils.isAvailableLocale(known));
    }

    @Test
    public void testIsAvailableLocaleFalseForUnknownLocale() {
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        Locale unknown = new Locale("zz", "QQ", "nonexistentvariant");
        assertEquals(set.contains(unknown), LocaleUtils.isAvailableLocale(unknown));
    }

    // --- isLanguageUndetermined(Locale) ---

    @Test
    public void testIsLanguageUndeterminedTrueForUnd() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("und")));
    }

    @Test
    public void testIsLanguageUndeterminedTrueForEmptyLanguage() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
    }

    @Test
    public void testIsLanguageUndeterminedTrueForNotWellFormed() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("e2")));
    }

    @Test
    public void testIsLanguageUndeterminedFalseForWellFormedLanguage() {
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("en")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.FRANCE));
    }

    // --- localeLookupList(Locale) ---

    @Test
    public void testLocaleLookupListSingleArgExample() {
        Locale locale = new Locale("fr", "CA", "xxx");
        List<Locale> result = LocaleUtils.localeLookupList(locale);
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(locale, result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
    }

    @Test
    public void testLocaleLookupListSingleArgNullReturnsEmpty() {
        List<Locale> result = LocaleUtils.localeLookupList(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListSingleArgUnmodifiable() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.FRANCE);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.CANADA);
            }
        });
    }

    @Test
    public void testLocaleLookupListSingleArgSimpleLocale() {
        List<Locale> result = LocaleUtils.localeLookupList(new Locale("en"));
        assertEquals(1, result.size());
        assertEquals(new Locale("en"), result.get(0));
    }

    // --- localeLookupList(Locale, Locale) ---

    @Test
    public void testLocaleLookupListTwoArgsExample() {
        Locale locale = new Locale("fr", "CA", "xxx");
        Locale defaultLocale = new Locale("en");
        List<Locale> result = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertNotNull(result);
        assertEquals(4, result.size());
        assertEquals(locale, result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
        assertEquals(defaultLocale, result.get(3));
    }

    @Test
    public void testLocaleLookupListTwoArgsNullLocaleReturnsEmpty() {
        List<Locale> result = LocaleUtils.localeLookupList(null, new Locale("en"));
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListTwoArgsNoDuplicates() {
        Locale locale = new Locale("en");
        Locale defaultLocale = new Locale("en");
        List<Locale> result = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertEquals(1, result.size());
        assertEquals(locale, result.get(0));
    }

    @Test
    public void testLocaleLookupListTwoArgsUnmodifiable() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.FRANCE, Locale.ENGLISH);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.CANADA);
            }
        });
    }

    // --- ofCountry(String) (package-private) ---

    @Test
    public void testOfCountryCreatesCountryOnlyLocale() {
        Locale locale = LocaleUtils.ofCountry("GB");
        assertNotNull(locale);
        assertEquals("GB", locale.getCountry());
        assertTrue(locale.getLanguage().isEmpty());
    }

    @Test
    public void testOfCountryNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.ofCountry(null);
            }
        });
    }

    // --- toLocale(Locale) ---

    @Test
    public void testToLocaleLocaleNonNullReturnsSame() {
        Locale input = Locale.CANADA;
        Locale result = LocaleUtils.toLocale(input);
        assertSame(input, result);
    }

    @Test
    public void testToLocaleLocaleNullReturnsDefault() {
        Locale result = LocaleUtils.toLocale((Locale) null);
        assertEquals(Locale.getDefault(), result);
    }

    // --- toLocale(String) ---

    @Test
    public void testToLocaleStringNullReturnsNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        Locale result = LocaleUtils.toLocale("");
        assertEquals("", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        Locale result = LocaleUtils.toLocale("en");
        assertEquals("en", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageAndCountryUnderscore() {
        Locale result = LocaleUtils.toLocale("en_GB");
        assertEquals("en", result.getLanguage());
        assertEquals("GB", result.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageAndCountryDash() {
        Locale result = LocaleUtils.toLocale("en-GB");
        assertEquals("en", result.getLanguage());
        assertEquals("GB", result.getCountry());
    }

    @Test
    public void testToLocaleStringNumericCountry() {
        Locale result = LocaleUtils.toLocale("en_001");
        assertEquals("en", result.getLanguage());
        assertEquals("001", result.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryVariant() {
        Locale result = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", result.getLanguage());
        assertEquals("GB", result.getCountry());
        assertEquals("xxx", result.getVariant());
    }

    @Test
    public void testToLocaleStringCountryOnly() {
        Locale result = LocaleUtils.toLocale("US");
        assertEquals("", result.getLanguage());
        assertEquals("US", result.getCountry());
    }

    @Test
    public void testToLocaleStringInvalidLowercaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidCountryLengthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_G");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidUppercaseLanguageThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("EN_GB");
            }
        });
    }
}
