package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testEmptyConstants() {
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHAR_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CLASS_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FIELD_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_METHOD_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_THROWABLE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_TYPE_ARRAY.length);

        boolean[] booleanArray = ArrayUtils.EMPTY_BOOLEAN_ARRAY;
        assertNotNull(booleanArray);
        Class<?>[] classArray = ArrayUtils.EMPTY_CLASS_ARRAY;
        assertNotNull(classArray);
        Field[] fieldArray = ArrayUtils.EMPTY_FIELD_ARRAY;
        assertNotNull(fieldArray);
        Method[] methodArray = ArrayUtils.EMPTY_METHOD_ARRAY;
        assertNotNull(methodArray);
        Throwable[] throwableArray = ArrayUtils.EMPTY_THROWABLE_ARRAY;
        assertNotNull(throwableArray);
    }

    @Test
    public void testIndexNotFoundConstant() {
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    @Test
    public void testSafeMaxArrayLengthConstant() {
        assertTrue(ArrayUtils.SAFE_MAX_ARRAY_LENGTH > 0);
    }

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    public void testIsEmptyBoolean() {
        assertTrue(ArrayUtils.isEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isEmpty(new boolean[0]));
        assertFalse(ArrayUtils.isEmpty(new boolean[] {true}));
        assertFalse(ArrayUtils.isNotEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new boolean[] {true}));
    }

    @Test
    public void testIsEmptyByte() {
        assertTrue(ArrayUtils.isEmpty((byte[]) null));
        assertTrue(ArrayUtils.isEmpty(new byte[0]));
        assertFalse(ArrayUtils.isEmpty(new byte[] {1}));
    }

    @Test
    public void testIsEmptyChar() {
        assertTrue(ArrayUtils.isEmpty((char[]) null));
        assertTrue(ArrayUtils.isEmpty(new char[0]));
        assertFalse(ArrayUtils.isEmpty(new char[] {'a'}));
    }

    @Test
    public void testIsEmptyDouble() {
        assertTrue(ArrayUtils.isEmpty((double[]) null));
        assertTrue(ArrayUtils.isEmpty(new double[0]));
        assertFalse(ArrayUtils.isEmpty(new double[] {1.0}));
    }

    @Test
    public void testIsEmptyFloat() {
        assertTrue(ArrayUtils.isEmpty((float[]) null));
        assertTrue(ArrayUtils.isEmpty(new float[0]));
        assertFalse(ArrayUtils.isEmpty(new float[] {1.0f}));
    }

    @Test
    public void testIsEmptyInt() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));
        assertFalse(ArrayUtils.isNotEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));
    }

    @Test
    public void testIsEmptyLong() {
        assertTrue(ArrayUtils.isEmpty((long[]) null));
        assertTrue(ArrayUtils.isEmpty(new long[0]));
        assertFalse(ArrayUtils.isEmpty(new long[] {1L}));
    }

    @Test
    public void testIsEmptyShort() {
        assertTrue(ArrayUtils.isEmpty((short[]) null));
        assertTrue(ArrayUtils.isEmpty(new short[0]));
        assertFalse(ArrayUtils.isEmpty(new short[] {1}));
    }

    @Test
    public void testIsEmptyObject() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    // ---------------------------------------------------------------
    // getLength / getComponentType / getDimensions / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] {null}));
        assertEquals(2, ArrayUtils.getLength(new boolean[] {true, false}));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(3, ArrayUtils.getLength(new String[] {"a", "b", "c"}));
    }

    @Test
    public void testGetLengthThrowsForNonArray() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    public void testGetComponentType() {
        assertSame(String.class, ArrayUtils.getComponentType(new String[0]));
        assertSame(Integer.class, ArrayUtils.getComponentType(new Integer[0]));
    }

    @Test
    public void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[] {1, 2}));
        assertEquals(1, ArrayUtils.getDimensions(new String[] {"a"}));
        assertEquals(2, ArrayUtils.getDimensions(new int[][] {{1}, {2}}));
        assertEquals(3, ArrayUtils.getDimensions(new int[1][1][1]));
    }

    @Test
    public void testHashCode() {
        assertEquals(0, ArrayUtils.hashCode(null));
        int[] a = {1, 2, 3};
        int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
        int[][] multiA = {{1, 2}, {3}};
        int[][] multiB = {{1, 2}, {3}};
        assertEquals(ArrayUtils.hashCode(multiA), ArrayUtils.hashCode(multiB));
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    public void testCloneNull() {
        assertNull(ArrayUtils.clone((boolean[]) null));
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    public void testCloneValue() {
        int[] original = {1, 2, 3};
        int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);

        boolean[] originalBool = {true, false};
        boolean[] clonedBool = ArrayUtils.clone(originalBool);
        assertArrayEquals(originalBool, clonedBool);
        assertNotSame(originalBool, clonedBool);

        String[] originalObj = {"a", "b"};
        String[] clonedObj = ArrayUtils.clone(originalObj);
        assertArrayEquals(originalObj, clonedObj);
        assertNotSame(originalObj, clonedObj);
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType
    // ---------------------------------------------------------------

    @Test
    public void testIsSameLengthPrimitive() {
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertTrue(ArrayUtils.isSameLength(new int[0], (int[]) null));
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
    }

    @Test
    public void testIsSameLengthObjectArray() {
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
        assertTrue(ArrayUtils.isSameLength(new Object[] {"a"}, new Object[] {"b"}));
        assertFalse(ArrayUtils.isSameLength(new Object[] {"a"}, new Object[] {"b", "c"}));
    }

    @Test
    public void testIsSameLengthGenericObject() {
        assertTrue(ArrayUtils.isSameLength((Object) null, (Object) null));
        assertTrue(ArrayUtils.isSameLength((Object) new int[] {1, 2}, (Object) new String[] {"a", "b"}));
        assertFalse(ArrayUtils.isSameLength((Object) new int[] {1, 2}, (Object) new String[] {"a"}));
    }

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[] {1}));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
    }

    @Test
    public void testIsSameTypeThrowsOnNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(new int[0], null);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSorted / isArrayIndexValid
    // ---------------------------------------------------------------

    @Test
    public void testIsSortedPrimitive() {
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new boolean[] {false, false, true}));
        assertFalse(ArrayUtils.isSorted(new boolean[] {true, false}));
    }

    @Test
    public void testIsSortedComparable() {
        assertTrue(ArrayUtils.isSorted(new Integer[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new Integer[] {3, 1, 2}));
    }

    @Test
    public void testIsSortedComparator() {
        Comparator<Integer> reverseOrder = new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return b.compareTo(a);
            }
        };
        assertTrue(ArrayUtils.isSorted(new Integer[] {3, 2, 1}, reverseOrder));
        assertFalse(ArrayUtils.isSorted(new Integer[] {1, 2, 3}, reverseOrder));
    }

    @Test
    public void testIsSortedComparatorThrowsOnNullComparator() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSorted(new Integer[] {1, 2}, null);
            }
        });
    }

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // ---------------------------------------------------------------
    // add(array, element)
    // ---------------------------------------------------------------

    @Test
    public void testAddBoolean() {
        assertArrayEquals(new boolean[] {true}, ArrayUtils.add((boolean[]) null, true));
        assertArrayEquals(new boolean[] {true, false}, ArrayUtils.add(new boolean[] {true}, false));
    }

    @Test
    public void testAddByte() {
        assertArrayEquals(new byte[] {1}, ArrayUtils.add((byte[]) null, (byte) 1));
        assertArrayEquals(new byte[] {1, 2}, ArrayUtils.add(new byte[] {1}, (byte) 2));
    }

    @Test
    public void testAddChar() {
        assertArrayEquals(new char[] {'a'}, ArrayUtils.add((char[]) null, 'a'));
        assertArrayEquals(new char[] {'a', 'b'}, ArrayUtils.add(new char[] {'a'}, 'b'));
    }

    @Test
    public void testAddDouble() {
        assertArrayEquals(new double[] {1.0}, ArrayUtils.add((double[]) null, 1.0), 0.0);
        assertArrayEquals(new double[] {1.0, 2.0}, ArrayUtils.add(new double[] {1.0}, 2.0), 0.0);
    }

    @Test
    public void testAddFloat() {
        assertArrayEquals(new float[] {1.0f}, ArrayUtils.add((float[]) null, 1.0f), 0.0f);
        assertArrayEquals(new float[] {1.0f, 2.0f}, ArrayUtils.add(new float[] {1.0f}, 2.0f), 0.0f);
    }

    @Test
    public void testAddInt() {
        assertArrayEquals(new int[] {1}, ArrayUtils.add((int[]) null, 1));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.add(new int[] {1}, 2));
    }

    @Test
    public void testAddLong() {
        assertArrayEquals(new long[] {1L}, ArrayUtils.add((long[]) null, 1L));
        assertArrayEquals(new long[] {1L, 2L}, ArrayUtils.add(new long[] {1L}, 2L));
    }

    @Test
    public void testAddShort() {
        assertArrayEquals(new short[] {1}, ArrayUtils.add((short[]) null, (short) 1));
        assertArrayEquals(new short[] {1, 2}, ArrayUtils.add(new short[] {1}, (short) 2));
    }

    @Test
    public void testAddGeneric() {
        String[] result = ArrayUtils.add((String[]) null, "a");
        assertArrayEquals(new String[] {"a"}, result);
        assertArrayEquals(new String[] {"a", "b"}, ArrayUtils.add(new String[] {"a"}, "b"));
    }

    @Test
    public void testAddGenericThrowsWhenBothNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add((Object[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // add(array, index, element) - deprecated, superseded by insert
    // ---------------------------------------------------------------

    @Test
    public void testAddAtIndexInt() {
        int[] result = ArrayUtils.add(new int[] {1, 3}, 1, 2);
        assertArrayEquals(new int[] {1, 2, 3}, result);
        assertArrayEquals(new int[] {1}, ArrayUtils.add(new int[0], 0, 1));
    }

    @Test
    public void testAddAtIndexIntThrowsOutOfRange() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] {1, 2}, -1, 3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] {1, 2}, 3, 3);
            }
        });
    }

    @Test
    public void testAddAtIndexGeneric() {
        String[] result = ArrayUtils.add(new String[] {"a", "c"}, 1, "b");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
    }

    @Test
    public void testAddAtIndexGenericThrowsWhenBothNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add((Object[]) null, 0, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // addFirst
    // ---------------------------------------------------------------

    @Test
    public void testAddFirstBoolean() {
        assertArrayEquals(new boolean[] {true}, ArrayUtils.addFirst((boolean[]) null, true));
        assertArrayEquals(new boolean[] {false, true}, ArrayUtils.addFirst(new boolean[] {true}, false));
        assertArrayEquals(new boolean[] {true, true, false}, ArrayUtils.addFirst(new boolean[] {true, false}, true));
    }

    @Test
    public void testAddFirstInt() {
        assertArrayEquals(new int[] {1}, ArrayUtils.addFirst((int[]) null, 1));
        assertArrayEquals(new int[] {0, 1}, ArrayUtils.addFirst(new int[] {1}, 0));
        assertArrayEquals(new int[] {1, 1, 0}, ArrayUtils.addFirst(new int[] {1, 0}, 1));
    }

    @Test
    public void testAddFirstGeneric() {
        assertArrayEquals(new String[] {"a"}, ArrayUtils.addFirst((String[]) null, "a"));
        assertArrayEquals(new String[] {null, "a"}, ArrayUtils.addFirst(new String[] {"a"}, null));
        assertArrayEquals(new String[] {"b", "a"}, ArrayUtils.addFirst(new String[] {"a"}, "b"));
        assertArrayEquals(new String[] {"c", "a", "b"}, ArrayUtils.addFirst(new String[] {"a", "b"}, "c"));
    }

    @Test
    public void testAddFirstGenericThrowsWhenBothNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.addFirst((Object[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // addAll
    // ---------------------------------------------------------------

    @Test
    public void testAddAllInt() {
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll((int[]) null, new int[] {1, 2}));
        assertArrayEquals(new int[0], ArrayUtils.addAll(new int[0], new int[0]));
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.addAll(new int[] {1, 2}, 3, 4));
    }

    @Test
    public void testAddAllIntReturnsNewArray() {
        int[] array1 = {1, 2};
        int[] result = ArrayUtils.addAll(array1, (int[]) null);
        assertNotSame(array1, result);
    }

    @Test
    public void testAddAllGeneric() {
        assertNull(ArrayUtils.addAll((String[]) null, (String[]) null));
        assertArrayEquals(new String[] {"a", "b"}, ArrayUtils.addAll(new String[] {"a"}, "b"));
    }

    // ---------------------------------------------------------------
    // arraycopy
    // ---------------------------------------------------------------

    @Test
    public void testArraycopyWithDestinationArray() {
        int[] source = {1, 2, 3, 4, 5};
        int[] dest = new int[5];
        int[] result = ArrayUtils.arraycopy(source, 1, dest, 0, 3);
        assertSame(dest, result);
        assertArrayEquals(new int[] {2, 3, 4, 0, 0}, result);
    }

    @Test
    public void testArraycopyWithSupplierAllocator() {
        int[] source = {1, 2, 3};
        int[] result = ArrayUtils.arraycopy(source, 0, 0, 3, new Supplier<int[]>() {
            @Override
            public int[] get() {
                return new int[3];
            }
        });
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testArraycopyWithFunctionAllocator() {
        int[] source = {1, 2, 3};
        int[] result = ArrayUtils.arraycopy(source, 0, 0, 3, new Function<Integer, int[]>() {
            @Override
            public int[] apply(Integer size) {
                return new int[size];
            }
        });
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testArraycopyThrowsOnOutOfBounds() {
        final int[] source = {1, 2, 3};
        final int[] dest = new int[3];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.arraycopy(source, 0, dest, 0, 10);
            }
        });
    }

    @Test
    public void testArraycopyThrowsOnNullSource() {
        final int[] dest = new int[3];
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.arraycopy((int[]) null, 0, dest, 0, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // concat
    // ---------------------------------------------------------------

    @Test
    public void testConcatInt() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.concat(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0][]));
        assertArrayEquals(new int[] {1}, ArrayUtils.concat(new int[] {1}));
    }

    @Test
    public void testConcatThrowsOnNullArrayOfArrays() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.concat((int[][]) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // contains / containsAny
    // ---------------------------------------------------------------

    @Test
    public void testContainsInt() {
        assertFalse(ArrayUtils.contains((int[]) null, 1));
        assertTrue(ArrayUtils.contains(new int[] {1, 2, 3}, 2));
        assertFalse(ArrayUtils.contains(new int[] {1, 2, 3}, 4));
    }

    @Test
    public void testContainsDoubleWithTolerance() {
        assertTrue(ArrayUtils.contains(new double[] {1.0, 2.0}, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(new double[] {1.0, 2.0}, 2.5, 0.1));
    }

    @Test
    public void testContainsObject() {
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
        assertTrue(ArrayUtils.contains(new Object[] {"a", "b"}, "a"));
        assertFalse(ArrayUtils.contains(new Object[] {"a", "b"}, "c"));
        assertTrue(ArrayUtils.contains(new Object[] {"a", null}, null));
    }

    @Test
    public void testContainsAnyInt() {
        assertTrue(ArrayUtils.containsAny(new int[] {1, 2, 3}, 5, 3));
        assertFalse(ArrayUtils.containsAny(new int[] {1, 2, 3}, 5, 6));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
    }

    @Test
    public void testContainsAnyObject() {
        assertTrue(ArrayUtils.containsAny(new Object[] {"a", "b"}, "x", "b"));
        assertFalse(ArrayUtils.containsAny(new Object[] {"a", "b"}, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "a"));
    }

    // ---------------------------------------------------------------
    // get
    // ---------------------------------------------------------------

    @Test
    public void testGet() {
        String[] array = {"a", "b", "c"};
        assertEquals("b", ArrayUtils.get(array, 1));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get(array, -1));
        assertNull(ArrayUtils.get((String[]) null, 0));
    }

    @Test
    public void testGetWithDefault() {
        String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0, "default"));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("default", ArrayUtils.get((String[]) null, 0, "default"));
    }

    // ---------------------------------------------------------------
    // indexesOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexesOfBoolean() {
        BitSet result = ArrayUtils.indexesOf(new boolean[] {true, false, true}, true);
        assertTrue(result.get(0));
        assertFalse(result.get(1));
        assertTrue(result.get(2));
        assertEquals(2, result.cardinality());

        BitSet empty = ArrayUtils.indexesOf((boolean[]) null, true);
        assertTrue(empty.isEmpty());
    }

    @Test
    public void testIndexesOfIntWithStartIndex() {
        BitSet result = ArrayUtils.indexesOf(new int[] {1, 2, 1, 2, 1}, 1, 1);
        assertFalse(result.get(0));
        assertTrue(result.get(2));
        assertTrue(result.get(4));
        assertEquals(2, result.cardinality());
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexOfInt() {
        assertEquals(-1, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(1, ArrayUtils.indexOf(new int[] {5, 1, 2, 1}, 1));
        assertEquals(-1, ArrayUtils.indexOf(new int[] {5, 1, 2}, 9));
    }

    @Test
    public void testIndexOfIntWithStartIndex() {
        int[] array = {5, 1, 2, 1};
        assertEquals(3, ArrayUtils.indexOf(array, 1, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 1, -5));
        assertEquals(-1, ArrayUtils.indexOf(array, 1, 10));
    }

    @Test
    public void testIndexOfDoubleWithTolerance() {
        double[] array = {1.0, 2.0, 3.0};
        assertEquals(1, ArrayUtils.indexOf(array, 2.05, 0.1));
        assertEquals(-1, ArrayUtils.indexOf(array, 2.5, 0.1));
    }

    @Test
    public void testIndexOfObject() {
        Object[] array = {"a", "b", "a"};
        assertEquals(0, ArrayUtils.indexOf(array, "a"));
        assertEquals(2, ArrayUtils.indexOf(array, "a", 1));
        assertEquals(-1, ArrayUtils.indexOf(array, "z"));
        assertEquals(-1, ArrayUtils.indexOf((Object[]) null, "a"));
    }

    @Test
    public void testLastIndexOfInt() {
        int[] array = {5, 1, 2, 1};
        assertEquals(3, ArrayUtils.lastIndexOf(array, 1));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(-1, ArrayUtils.lastIndexOf((int[]) null, 1));
    }

    @Test
    public void testLastIndexOfIntWithStartIndex() {
        int[] array = {5, 1, 2, 1};
        assertEquals(1, ArrayUtils.lastIndexOf(array, 1, 2));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 1, -1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 1, 100));
    }

    @Test
    public void testLastIndexOfObject() {
        Object[] array = {"a", "b", "a"};
        assertEquals(2, ArrayUtils.lastIndexOf(array, "a"));
        assertEquals(0, ArrayUtils.lastIndexOf(array, "a", 1));
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    public void testInsertInt() {
        assertNull(ArrayUtils.insert(0, (int[]) null, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.insert(0, new int[] {1, 2}, (int[]) null));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1, 2));
        assertArrayEquals(new int[] {1, 5, 6, 2, 3}, ArrayUtils.insert(1, new int[] {1, 2, 3}, 5, 6));
    }

    @Test
    public void testInsertIntReturnsNewArray() {
        int[] array = {1, 2, 3};
        int[] result = ArrayUtils.insert(0, array, (int[]) null);
        assertNotSame(array, result);
        assertArrayEquals(array, result);
    }

    @Test
    public void testInsertIntThrowsOutOfBounds() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, array, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(4, array, 9);
            }
        });
    }

    @Test
    public void testInsertGeneric() {
        assertNull(ArrayUtils.insert(0, (String[]) null, (String[]) null));
        String[] result = ArrayUtils.insert(1, new String[] {"a", "d"}, "b", "c");
        assertArrayEquals(new String[] {"a", "b", "c", "d"}, result);
    }

    // ---------------------------------------------------------------
    // isEquals (deprecated)
    // ---------------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    public void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(null, new int[] {1}));
    }

    // ---------------------------------------------------------------
    // nullToEmpty
    // ---------------------------------------------------------------

    @Test
    public void testNullToEmptyInt() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        int[] array = {1, 2};
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    public void testNullToEmptyObjectArrays() {
        assertSame(ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Integer[]) null));
        assertSame(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
    }

    @Test
    public void testNullToEmptyWithClass() {
        String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);
        String[] array = {"a"};
        assertSame(array, ArrayUtils.nullToEmpty(array, String[].class));
    }

    @Test
    public void testNullToEmptyWithClassThrowsOnNullType() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.nullToEmpty((String[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // remove
    // ---------------------------------------------------------------

    @Test
    public void testRemoveInt() {
        assertArrayEquals(new int[0], ArrayUtils.remove(new int[] {1}, 0));
        assertArrayEquals(new int[] {6}, ArrayUtils.remove(new int[] {2, 6}, 0));
        assertArrayEquals(new int[] {2}, ArrayUtils.remove(new int[] {2, 6}, 1));
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.remove(new int[] {2, 6, 3}, 1));
    }

    @Test
    public void testRemoveIntThrowsOnNullArray() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    public void testRemoveIntThrowsOnOutOfRangeIndex() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(array, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(array, 3);
            }
        });
    }

    @Test
    public void testRemoveGeneric() {
        String[] result = ArrayUtils.remove(new String[] {"a", "b", "c"}, 1);
        assertArrayEquals(new String[] {"a", "c"}, result);
    }

    // ---------------------------------------------------------------
    // removeAll (by indices)
    // ---------------------------------------------------------------

    @Test
    public void testRemoveAllInt() {
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {1}, 0));
        assertArrayEquals(new int[] {6}, ArrayUtils.removeAll(new int[] {2, 6}, 0));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {2, 6}, 0, 1));
        assertArrayEquals(new int[] {2}, ArrayUtils.removeAll(new int[] {2, 6, 3}, 1, 2));
        assertArrayEquals(new int[] {6}, ArrayUtils.removeAll(new int[] {2, 6, 3}, 0, 2));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {2, 6, 3}, 0, 1, 2));
    }

    @Test
    public void testRemoveAllIntThrowsOnOutOfRangeIndex() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.removeAll(array, 5);
            }
        });
    }

    @Test
    public void testRemoveAllGeneric() {
        String[] result = ArrayUtils.removeAll(new String[] {"a", "b", "c"}, 0, 2);
        assertArrayEquals(new String[] {"b"}, result);
    }

    // ---------------------------------------------------------------
    // removeAllOccurrences
    // ---------------------------------------------------------------

    @Test
    public void testRemoveAllOccurrencesInt() {
        assertNull(ArrayUtils.removeAllOccurrences((int[]) null, 1));
        assertArrayEquals(new int[] {3}, ArrayUtils.removeAllOccurrences(new int[] {1, 3, 1}, 1));
        assertArrayEquals(new int[] {1, 3, 1}, ArrayUtils.removeAllOccurrences(new int[] {1, 3, 1}, 9));
    }

    @Test
    public void testRemoveAllOccurrencesGeneric() {
        String[] result = ArrayUtils.removeAllOccurrences(new String[] {"a", "b", "a"}, "a");
        assertArrayEquals(new String[] {"b"}, result);
    }

    // ---------------------------------------------------------------
    // removeElement
    // ---------------------------------------------------------------

    @Test
    public void testRemoveElementBoolean() {
        assertNull(ArrayUtils.removeElement((boolean[]) null, true));
        assertArrayEquals(new boolean[0], ArrayUtils.removeElement(new boolean[0], true));
        assertArrayEquals(new boolean[] {true}, ArrayUtils.removeElement(new boolean[] {true}, false));
        assertArrayEquals(new boolean[] {true}, ArrayUtils.removeElement(new boolean[] {true, false}, false));
        assertArrayEquals(new boolean[] {false, true}, ArrayUtils.removeElement(new boolean[] {true, false, true}, true));
    }

    @Test
    public void testRemoveElementGeneric() {
        String[] result = ArrayUtils.removeElement(new String[] {"a", "b", "a"}, "a");
        assertArrayEquals(new String[] {"b", "a"}, result);
        assertArrayEquals(new String[] {"a"}, ArrayUtils.removeElement(new String[] {"a"}, "z"));
    }

    // ---------------------------------------------------------------
    // removeElements
    // ---------------------------------------------------------------

    @Test
    public void testRemoveElementsBoolean() {
        assertNull(ArrayUtils.removeElements((boolean[]) null, true, false));
        assertArrayEquals(new boolean[0], ArrayUtils.removeElements(new boolean[0], true, false));
        assertArrayEquals(new boolean[] {true}, ArrayUtils.removeElements(new boolean[] {true}, false, false));
        assertArrayEquals(new boolean[] {false}, ArrayUtils.removeElements(new boolean[] {true, false}, true, true));
        assertArrayEquals(new boolean[] {false, true}, ArrayUtils.removeElements(new boolean[] {true, false, true}, true));
        assertArrayEquals(new boolean[] {false}, ArrayUtils.removeElements(new boolean[] {true, false, true}, true, true));
    }

    @Test
    public void testRemoveElementsInt() {
        assertArrayEquals(new int[] {1}, ArrayUtils.removeElements(new int[] {1}, 2, 3));
        assertArrayEquals(new int[] {3}, ArrayUtils.removeElements(new int[] {1, 3}, 1, 2));
        assertArrayEquals(new int[] {3, 1}, ArrayUtils.removeElements(new int[] {1, 3, 1}, 1));
        assertArrayEquals(new int[] {3}, ArrayUtils.removeElements(new int[] {1, 3, 1}, 1, 1));
    }

    @Test
    public void testRemoveElementsGeneric() {
        String[] result = ArrayUtils.removeElements(new String[] {"a", "b", "a"}, "a");
        assertArrayEquals(new String[] {"b", "a"}, result);
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    public void testReverseIntWholeArray() {
        int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testReverseIntDoesNothingForNullOrEmpty() {
        ArrayUtils.reverse((int[]) null);
        int[] empty = new int[0];
        ArrayUtils.reverse(empty);
        assertEquals(0, empty.length);
    }

    @Test
    public void testReverseIntRange() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseObjectWholeArray() {
        String[] array = {"a", "b", "c"};
        ArrayUtils.reverse(array);
        assertArrayEquals(new String[] {"c", "b", "a"}, array);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    public void testShiftDoesNothingForNullOrEmpty() {
        ArrayUtils.shift((int[]) null, 1);
        int[] empty = new int[0];
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    public void testShiftByZeroOrArrayLengthLeavesArrayUnchanged() {
        int[] array = {1, 2, 3, 4};
        int[] expected = array.clone();
        ArrayUtils.shift(array, 0);
        assertArrayEquals(expected, array);

        int[] array2 = {1, 2, 3, 4};
        ArrayUtils.shift(array2, array2.length);
        assertArrayEquals(expected, array2);
    }

    @Test
    public void testShiftPreservesElementsAndIsModular() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 2);
        int[] expectedModulo = {1, 2, 3, 4, 5};
        ArrayUtils.shift(expectedModulo, 2 + expectedModulo.length * 3);
        assertArrayEquals(expectedModulo, array);

        int[] sortedCopy = array.clone();
        java.util.Arrays.sort(sortedCopy);
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, sortedCopy);
    }

    @Test
    public void testShiftRangeDoesNothingOutsideRange() {
        int[] array = {1, 2, 3, 4, 5};
        int[] expected = array.clone();
        ArrayUtils.shift(array, 10, 20, 1);
        assertArrayEquals(expected, array);
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    public void testSubarrayInt() {
        int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSubarrayIntClampsUndervalueStart() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.subarray(array, -2, 3));
    }

    @Test
    public void testSubarrayIntOvervalueStartProducesEmpty() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 10, 20));
    }

    @Test
    public void testSubarrayIntUndervalueEndProducesEmpty() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 1));
    }

    @Test
    public void testSubarrayIntOvervalueEndIsDemoted() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 100));
    }

    @Test
    public void testSubarrayGeneric() {
        String[] array = {"a", "b", "c", "d"};
        String[] result = ArrayUtils.subarray(array, 1, 3);
        assertArrayEquals(new String[] {"b", "c"}, result);
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    public void testSwapTwoElements() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);

        int[] array2 = {1, 2, 3};
        ArrayUtils.swap(array2, 0, 0);
        assertArrayEquals(new int[] {1, 2, 3}, array2);

        int[] array3 = {1, 2, 3};
        ArrayUtils.swap(array3, 1, 0);
        assertArrayEquals(new int[] {2, 1, 3}, array3);
    }

    @Test
    public void testSwapDoesNothingForOverflowIndex() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, array);
    }

    @Test
    public void testSwapNegativeIndexIsPromotedToZero() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, -1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, array);
    }

    @Test
    public void testSwapDoesNothingForNullOrEmpty() {
        ArrayUtils.swap((int[]) null, 0, 1);
        int[] empty = new int[0];
        ArrayUtils.swap(empty, 0, 1);
        assertEquals(0, empty.length);
    }

    @Test
    public void testSwapWithLength() {
        int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 3, 3);
        assertArrayEquals(new int[] {4, 2, 3, 1}, array);

        int[] array2 = {1, 2, 3, 4};
        ArrayUtils.swap(array2, 2, 0, 2);
        assertArrayEquals(new int[] {3, 4, 1, 2}, array2);
    }

    @Test
    public void testSwapObjectArray() {
        String[] array = {"a", "b", "c"};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new String[] {"c", "b", "a"}, array);
    }

    // ---------------------------------------------------------------
    // toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    public void testToObjectBoolean() {
        assertNull(ArrayUtils.toObject((boolean[]) null));
        assertArrayEquals(new Boolean[] {Boolean.TRUE, Boolean.FALSE}, ArrayUtils.toObject(new boolean[] {true, false}));
    }

    @Test
    public void testToObjectInt() {
        assertNull(ArrayUtils.toObject((int[]) null));
        assertArrayEquals(new Integer[] {1, 2, 3}, ArrayUtils.toObject(new int[] {1, 2, 3}));
    }

    @Test
    public void testToObjectByteCharLongFloatShortDouble() {
        assertArrayEquals(new Byte[] {(byte) 1}, ArrayUtils.toObject(new byte[] {1}));
        assertArrayEquals(new Character[] {'a'}, ArrayUtils.toObject(new char[] {'a'}));
        assertArrayEquals(new Long[] {1L}, ArrayUtils.toObject(new long[] {1L}));
        assertArrayEquals(new Float[] {1.0f}, ArrayUtils.toObject(new float[] {1.0f}));
        assertArrayEquals(new Short[] {(short) 1}, ArrayUtils.toObject(new short[] {1}));
        assertArrayEquals(new Double[] {1.0}, ArrayUtils.toObject(new double[] {1.0}));
    }

    @Test
    public void testToPrimitiveBoolean() {
        assertNull(ArrayUtils.toPrimitive((Boolean[]) null));
        assertArrayEquals(new boolean[] {true, false}, ArrayUtils.toPrimitive(new Boolean[] {true, false}));
        assertArrayEquals(new boolean[] {false}, ArrayUtils.toPrimitive(new Boolean[] {null}));
    }

    @Test
    public void testToPrimitiveBooleanWithDefault() {
        assertArrayEquals(new boolean[] {true, true}, ArrayUtils.toPrimitive(new Boolean[] {null, true}, true));
    }

    @Test
    public void testToPrimitiveIntegerThrowsOnNullElement() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] {1, null});
            }
        });
    }

    @Test
    public void testToPrimitiveIntegerWithDefault() {
        assertArrayEquals(new int[] {1, 9}, ArrayUtils.toPrimitive(new Integer[] {1, null}, 9));
    }

    @Test
    public void testToPrimitiveByteCharLongFloatShortDoubleWithDefault() {
        assertArrayEquals(new byte[] {1, 9}, ArrayUtils.toPrimitive(new Byte[] {1, null}, (byte) 9));
        assertArrayEquals(new char[] {'a', 'z'}, ArrayUtils.toPrimitive(new Character[] {'a', null}, 'z'));
        assertArrayEquals(new long[] {1L, 9L}, ArrayUtils.toPrimitive(new Long[] {1L, null}, 9L));
        assertArrayEquals(new float[] {1.0f, 9.0f}, ArrayUtils.toPrimitive(new Float[] {1.0f, null}, 9.0f));
        assertArrayEquals(new short[] {1, 9}, ArrayUtils.toPrimitive(new Short[] {1, null}, (short) 9));
        assertArrayEquals(new double[] {1.0, 9.0}, ArrayUtils.toPrimitive(new Double[] {1.0, null}, 9.0));
    }

    @Test
    public void testToPrimitiveObjectDispatch() {
        Object result = ArrayUtils.toPrimitive((Object) new Integer[] {1, 2, 3});
        assertTrue(result instanceof int[]);
        assertArrayEquals(new int[] {1, 2, 3}, (int[]) result);
        assertNull(ArrayUtils.toPrimitive((Object) null));
    }

    // ---------------------------------------------------------------
    // toString / toStringArray
    // ---------------------------------------------------------------

    @Test
    public void testToString() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("{a,b}", ArrayUtils.toString(new String[] {"a", "b"}));
    }

    @Test
    public void testToStringWithDefault() {
        assertEquals("NULL", ArrayUtils.toString(null, "NULL"));
        assertEquals("{a,b}", ArrayUtils.toString(new String[] {"a", "b"}, "NULL"));
    }

    @Test
    public void testToStringArray() {
        assertNull(ArrayUtils.toStringArray((Object[]) null));
        assertArrayEquals(new String[] {"1", "true"}, ArrayUtils.toStringArray(new Object[] {Integer.valueOf(1), Boolean.TRUE}));
    }

    @Test
    public void testToStringArrayWithDefaultForNullElements() {
        String[] result = ArrayUtils.toStringArray(new Object[] {"a", null}, "NULL");
        assertArrayEquals(new String[] {"a", "NULL"}, result);
    }

    // ---------------------------------------------------------------
    // toMap
    // ---------------------------------------------------------------

    @Test
    public void testToMapFromEntries() {
        assertNull(ArrayUtils.toMap(null));
        Map<Object, Object> map = ArrayUtils.toMap(new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
        assertEquals(2, map.size());
    }

    @Test
    public void testToMapThrowsForShortSubArray() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {new String[] {"onlyOneElement"}});
            }
        });
    }

    @Test
    public void testToMapThrowsForInvalidElementType() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {"not a map entry or array"});
            }
        });
    }

    // ---------------------------------------------------------------
    // toArray
    // ---------------------------------------------------------------

    @Test
    public void testToArray() {
        String[] result = ArrayUtils.toArray("1", "2");
        assertArrayEquals(new String[] {"1", "2"}, result);
        String[] emptyResult = ArrayUtils.<String>toArray();
        assertEquals(0, emptyResult.length);
    }
}
