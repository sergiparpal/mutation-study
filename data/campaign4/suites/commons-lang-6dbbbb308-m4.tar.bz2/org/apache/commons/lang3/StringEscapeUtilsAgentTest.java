/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StringEscapeUtils}.
 */
public class StringEscapeUtilsAgentTest {

    @Test
    public void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    @Test
    public void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    @Test
    public void testEscapeJavaBasic() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    @Test
    public void testEscapeJavaControlChars() {
        assertEquals("\\t\\n\\r\\f\\b", StringEscapeUtils.escapeJava("\t\n\r\f\b"));
    }

    @Test
    public void testEscapeJavaBackslash() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    @Test
    public void testEscapeJavaUnicodeOutsideAscii() {
        // Characters outside 32..0x7f are unicode-escaped
        assertEquals("\\u00E9", StringEscapeUtils.escapeJava("é"));
    }

    @Test
    public void testEscapeJavaDoesNotEscapeForwardSlash() {
        assertEquals("/", StringEscapeUtils.escapeJava("/"));
    }

    @Test
    public void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    @Test
    public void testUnescapeJavaBasic() {
        assertEquals("He didn't say, \"Stop!\"", StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
    }

    @Test
    public void testUnescapeJavaUnicode() {
        assertEquals("é", StringEscapeUtils.unescapeJava("\\u00e9"));
    }

    @Test
    public void testUnescapeJavaOctal() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\101"));
    }

    @Test
    public void testUnescapeJavaTrailingBackslashRemoved() {
        assertEquals("", StringEscapeUtils.unescapeJava("\\"));
    }

    @Test
    public void testEscapeUnescapeJavaRoundTrip() {
        final String original = "Line1\nLine2\tTabbed\\Backslash\"Quoted\"";
        final String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    @Test
    public void testEscapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.escapeEcmaScript(null));
    }

    @Test
    public void testEscapeEcmaScriptQuotesAndSlash() {
        assertEquals("He didn\\'t say, \\\"Stop!\\\"", StringEscapeUtils.escapeEcmaScript("He didn't say, \"Stop!\""));
        assertEquals("http:\\/\\/example.com", StringEscapeUtils.escapeEcmaScript("http://example.com"));
    }

    @Test
    public void testUnescapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.unescapeEcmaScript(null));
    }

    @Test
    public void testUnescapeEcmaScriptBasic() {
        assertEquals("'quoted'", StringEscapeUtils.unescapeEcmaScript("\\'quoted\\'"));
    }

    @Test
    public void testEscapeJsonNull() {
        assertNull(StringEscapeUtils.escapeJson(null));
    }

    @Test
    public void testEscapeJsonForwardSlashAndQuote() {
        assertEquals("\\\"a\\/b\\\"", StringEscapeUtils.escapeJson("\"a/b\""));
    }

    @Test
    public void testEscapeJsonDoesNotEscapeSingleQuote() {
        // Json does not escape single quotes (unlike EcmaScript)
        assertEquals("'", StringEscapeUtils.escapeJson("'"));
    }

    @Test
    public void testUnescapeJsonNull() {
        assertNull(StringEscapeUtils.unescapeJson(null));
    }

    @Test
    public void testUnescapeJsonBasic() {
        assertEquals("\"a/b\"", StringEscapeUtils.unescapeJson("\\\"a\\/b\\\""));
    }

    @Test
    public void testEscapeHtml3Null() {
        assertNull(StringEscapeUtils.escapeHtml3(null));
    }

    @Test
    public void testEscapeHtml3Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeHtml3("\"bread\" & \"butter\""));
    }

    @Test
    public void testEscapeHtml3DoesNotEscapeApostrophe() {
        assertEquals("it's", StringEscapeUtils.escapeHtml3("it's"));
    }

    @Test
    public void testUnescapeHtml3Null() {
        assertNull(StringEscapeUtils.unescapeHtml3(null));
    }

    @Test
    public void testUnescapeHtml3Basic() {
        assertEquals("\"bread\" & \"butter\"", StringEscapeUtils.unescapeHtml3("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    @Test
    public void testUnescapeHtml3UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml3("&gt;&zzzz;x"));
    }

    @Test
    public void testEscapeHtml4Null() {
        assertNull(StringEscapeUtils.escapeHtml4(null));
    }

    @Test
    public void testEscapeHtml4Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeHtml4("\"bread\" & \"butter\""));
    }

    @Test
    public void testEscapeHtml4ExtendedEntity() {
        assertEquals("&euro;", StringEscapeUtils.escapeHtml4("€"));
    }

    @Test
    public void testEscapeHtml4DoesNotEscapeApostrophe() {
        // apostrophe is not a legal HTML4 entity and is not escaped
        assertEquals("it's", StringEscapeUtils.escapeHtml4("it's"));
    }

    @Test
    public void testUnescapeHtml4Null() {
        assertNull(StringEscapeUtils.unescapeHtml4(null));
    }

    @Test
    public void testUnescapeHtml4Basic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml4("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    public void testUnescapeHtml4NumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeHtml4("&#65;"));
        assertEquals("A", StringEscapeUtils.unescapeHtml4("&#x41;"));
    }

    @Test
    public void testUnescapeHtml4UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml4("&gt;&zzzz;x"));
    }

    @Test
    public void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    @Test
    public void testEscapeXmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    @Test
    public void testEscapeXmlApostrophe() {
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
    }

    @Test
    public void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    public void testUnescapeXmlBasic() {
        assertEquals("\"bread\" & \"butter\"", StringEscapeUtils.unescapeXml("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    @Test
    public void testEscapeXml10Null() {
        assertNull(StringEscapeUtils.escapeXml10(null));
    }

    @Test
    public void testEscapeXml10RemovesControlChars() {
        // \u0000 and other illegal XML 1.0 control chars are stripped entirely
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0000b"));
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0001b"));
    }

    @Test
    public void testEscapeXml10EscapesNearControlRange() {
        assertEquals("a&#127;b", StringEscapeUtils.escapeXml10("a\u007fb"));
    }

    @Test
    public void testEscapeXml10KeepsTabNewlineCr() {
        assertEquals("a\tb\nc\rd", StringEscapeUtils.escapeXml10("a\tb\nc\rd"));
    }

    @Test
    public void testEscapeXml11Null() {
        assertNull(StringEscapeUtils.escapeXml11(null));
    }

    @Test
    public void testEscapeXml11RemovesNullByte() {
        assertEquals("ab", StringEscapeUtils.escapeXml11("a\u0000b"));
    }

    @Test
    public void testEscapeXml11EscapesControlChar() {
        assertEquals("a&#1;b", StringEscapeUtils.escapeXml11("a\u0001b"));
    }

    @Test
    public void testEscapeCsvNull() {
        assertNull(StringEscapeUtils.escapeCsv(null));
    }

    @Test
    public void testEscapeCsvEmpty() {
        assertEquals("", StringEscapeUtils.escapeCsv(""));
    }

    @Test
    public void testEscapeCsvNoSpecialChars() {
        assertEquals("abc", StringEscapeUtils.escapeCsv("abc"));
    }

    @Test
    public void testEscapeCsvWithComma() {
        assertEquals("\"a,b\"", StringEscapeUtils.escapeCsv("a,b"));
    }

    @Test
    public void testEscapeCsvWithQuote() {
        assertEquals("\"a\"\"b\"", StringEscapeUtils.escapeCsv("a\"b"));
    }

    @Test
    public void testEscapeCsvWithNewline() {
        assertEquals("\"a\nb\"", StringEscapeUtils.escapeCsv("a\nb"));
    }

    @Test
    public void testUnescapeCsvNull() {
        assertNull(StringEscapeUtils.unescapeCsv(null));
    }

    @Test
    public void testUnescapeCsvEmpty() {
        assertEquals("", StringEscapeUtils.unescapeCsv(""));
    }

    @Test
    public void testUnescapeCsvNotQuoted() {
        assertEquals("abc", StringEscapeUtils.unescapeCsv("abc"));
    }

    @Test
    public void testUnescapeCsvQuoted() {
        assertEquals("a,b", StringEscapeUtils.unescapeCsv("\"a,b\""));
    }

    @Test
    public void testUnescapeCsvEscapedQuotes() {
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("\"a\"\"b\""));
    }

    @Test
    public void testUnescapeCsvSingleQuoteCharLeftAlone() {
        // Length 1, not touched because it can't contain both opening and closing quote
        assertEquals("\"", StringEscapeUtils.unescapeCsv("\""));
    }

    @Test
    public void testUnescapeCsvQuotedButNoSpecialCharsInsideReturnedAsIs() {
        // Quoted value without comma/quote/newline inside is returned unchanged including quotes
        assertEquals("\"abc\"", StringEscapeUtils.unescapeCsv("\"abc\""));
    }

    @Test
    public void testConstructorIsPublic() throws Exception {
        final StringEscapeUtils instance = new StringEscapeUtils();
        assertNotNull(instance);
    }

    @Test
    public void testTranslatorConstantsAreNotNull() {
        assertNotNull(StringEscapeUtils.ESCAPE_JAVA);
        assertNotNull(StringEscapeUtils.ESCAPE_ECMASCRIPT);
        assertNotNull(StringEscapeUtils.ESCAPE_JSON);
        assertNotNull(StringEscapeUtils.ESCAPE_XML);
        assertNotNull(StringEscapeUtils.ESCAPE_XML10);
        assertNotNull(StringEscapeUtils.ESCAPE_XML11);
        assertNotNull(StringEscapeUtils.ESCAPE_HTML3);
        assertNotNull(StringEscapeUtils.ESCAPE_HTML4);
        assertNotNull(StringEscapeUtils.ESCAPE_CSV);
        assertNotNull(StringEscapeUtils.UNESCAPE_JAVA);
        assertNotNull(StringEscapeUtils.UNESCAPE_ECMASCRIPT);
        assertNotNull(StringEscapeUtils.UNESCAPE_JSON);
        assertNotNull(StringEscapeUtils.UNESCAPE_HTML3);
        assertNotNull(StringEscapeUtils.UNESCAPE_HTML4);
        assertNotNull(StringEscapeUtils.UNESCAPE_XML);
        assertNotNull(StringEscapeUtils.UNESCAPE_CSV);
    }

    @Test
    public void testUnescapeEcmaScriptIsSameAsUnescapeJava() {
        assertSame(StringEscapeUtils.UNESCAPE_JAVA, StringEscapeUtils.UNESCAPE_ECMASCRIPT);
    }

    @Test
    public void testUnescapeJsonIsSameAsUnescapeJava() {
        assertSame(StringEscapeUtils.UNESCAPE_JAVA, StringEscapeUtils.UNESCAPE_JSON);
    }
}
