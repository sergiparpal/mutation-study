package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

@SuppressWarnings("deprecation")
public class ExtendedMessageFormatAgentTest {

    private static Map<String, FormatFactory> emptyRegistry() {
        return new HashMap<String, FormatFactory>();
    }

    @Test
    public void testConstructorPatternOnly_StoresPatternAndFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}!");
        assertEquals("Hello {0}!", emf.toPattern());
        assertEquals("Hello World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructorPatternOnly_NoArgumentsNoBraces() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("just text");
        assertEquals("just text", emf.toPattern());
        assertEquals("just text", emf.format(new Object[0]));
    }

    @Test
    public void testConstructorPatternOnly_EmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    @Test
    public void testConstructorPatternOnly_BadPatternThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    public void testConstructorPatternAndLocale_UsesSuppliedLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,0.0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
        assertEquals("1234,5", emf.format(new Object[] {Double.valueOf(1234.5d)}));
    }

    @Test
    public void testConstructorPatternAndLocale_DifferentLocaleProducesDifferentOutput() {
        ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number,0.0}", Locale.US);
        assertEquals(Locale.US, us.getLocale());
        assertEquals("1234.5", us.format(new Object[] {Double.valueOf(1234.5d)}));
    }

    @Test
    public void testConstructorPatternAndLocale_BadPatternThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0", Locale.US);
            }
        });
    }

    @Test
    public void testConstructorPatternLocaleRegistry_NullRegistryBehavesAsPlainMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", Locale.US, null);
        assertEquals("Hi {0}", emf.toPattern());
        assertEquals("Hi Bob", emf.format(new Object[] {"Bob"}));
    }

    @Test
    public void testConstructorPatternLocaleRegistry_EmptyRegistryBehavesAsPlainMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", Locale.US, emptyRegistry());
        assertEquals("Hi {0}", emf.toPattern());
        assertEquals("Hi Bob", emf.format(new Object[] {"Bob"}));
    }

    @Test
    public void testConstructorPatternLocaleRegistry_BadPatternThrows() {
        final Map<String, FormatFactory> registry = emptyRegistry();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0", Locale.US, registry);
            }
        });
    }

    @Test
    public void testConstructorPatternRegistry_NullRegistryDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", (Map<String, FormatFactory>) null);
        assertEquals("Hi {0}", emf.toPattern());
        assertEquals("Hi Bob", emf.format(new Object[] {"Bob"}));
    }

    @Test
    public void testConstructorPatternRegistry_EmptyRegistryDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", emptyRegistry());
        assertEquals("Hi {0}", emf.toPattern());
        assertEquals("Hi Bob", emf.format(new Object[] {"Bob"}));
    }

    @Test
    public void testConstructorPatternRegistry_BadPatternThrows() {
        final Map<String, FormatFactory> registry = emptyRegistry();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0", registry);
            }
        });
    }

    @Test
    public void testApplyPattern_ChangesPatternAndFormatting() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("A {0}");
        emf.applyPattern("B {0}");
        assertEquals("B {0}", emf.toPattern());
        assertEquals("B x", emf.format(new Object[] {"x"}));
    }

    @Test
    public void testApplyPattern_BadPatternThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("ok");
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                emf.applyPattern("{0");
            }
        });
    }

    @Test
    public void testToPattern_ReturnsExactPatternWithMultipleArguments() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{1} {0}");
        assertEquals("{1} {0}", emf.toPattern());
        assertEquals("B A", emf.format(new Object[] {"A", "B"}));
    }

    @Test
    public void testFormat_ChoiceSubformat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,choice,0#zero|1#one|2#many}");
        assertEquals("zero", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("many", emf.format(new Object[] {Integer.valueOf(2)}));
    }

    @Test
    public void testEquals_ReflexiveAndNullAndDifferentType() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", Locale.US);
        assertTrue(emf.equals(emf));
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("Hello {0}"));
    }

    @Test
    public void testEquals_SamePatternAndLocaleAreEqual() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("Hello {0}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("Hello {0}", Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEquals_DifferentPatternsAreNotEqual() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("Hello {0}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("Goodbye {0}", Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testHashCode_IsRepeatable() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}", Locale.US);
        int first = emf.hashCode();
        int second = emf.hashCode();
        assertEquals(first, second);
    }

    @Test
    public void testSetFormat_AlwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        final Format replacement = NumberFormat.getInstance();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormat(0, replacement);
            }
        });
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    public void testSetFormatByArgumentIndex_AlwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormatByArgumentIndex(0, null);
            }
        });
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    public void testSetFormats_AlwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        final Format[] formats = new Format[0];
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormats(formats);
            }
        });
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    public void testSetFormatsByArgumentIndex_AlwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        final Format[] formats = new Format[0];
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormatsByArgumentIndex(formats);
            }
        });
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    public void testInstanceIsSerializableAndCloneable() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf instanceof java.io.Serializable);
        assertTrue(emf instanceof Cloneable);
        assertNotNull(emf);
    }
}
