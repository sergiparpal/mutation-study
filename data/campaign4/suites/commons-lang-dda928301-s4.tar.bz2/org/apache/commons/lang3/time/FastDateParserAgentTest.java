package org.apache.commons.lang3.time;

import java.io.Serializable;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link FastDateParser}, written against the javadoc contract only.
 * This class is in the same package as FastDateParser so it can use the
 * protected constructors and package-private clear()/JAPANESE_IMPERIAL members.
 */
public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar newCalendar() {
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        return cal;
    }

    // ---- constructor / getters ----

    @Test
    public void testThreeArgConstructorStoresGivenValues() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorNullLocaleMapsToDefault() {
        Date centuryStart = newCenturyStart(1950);
        FastDateParser parser = new FastDateParser("yy", UTC, null, centuryStart);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    public void testConstructorRejectsNullPattern() {
        assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    public void testImplementsDocumentedInterfacesAndIsSerializable() {
        FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        assertTrue(parser instanceof Serializable);
        assertTrue(parser instanceof DateParser);
    }

    // ---- parse(String) ----

    @Test
    public void testParseStringSuccess() throws ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("2017-06-23");

        Calendar expected = newCalendar();
        expected.set(2017, Calendar.JUNE, 23);

        assertEquals(expected.getTime(), actual);
    }

    @Test
    public void testParseStringWithTimeFields() throws ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        Date actual = parser.parse("2017-06-23 13:45:30");

        Calendar expected = newCalendar();
        expected.set(2017, Calendar.JUNE, 23, 13, 45, 30);

        assertEquals(expected.getTime(), actual);
    }

    @Test
    public void testParseStringThrowsParseExceptionWhenBeginningCannotBeParsed() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Exception {
                parser.parse("not-a-date");
            }
        });
    }

    // ---- parse(String, ParsePosition) ----

    @Test
    public void testParseWithPositionFullyConsumesInput() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);

        Date actual = parser.parse("2017-06-23", pos);

        assertNotNull(actual);
        assertEquals(10, pos.getIndex());

        Calendar expected = newCalendar();
        expected.set(2017, Calendar.JUNE, 23);
        assertEquals(expected.getTime(), actual);
    }

    @Test
    public void testParseWithPositionDoesNotRequireFullConsumption() {
        FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);

        Date actual = parser.parse("2017extra", pos);

        assertNotNull(actual);
        assertEquals(4, pos.getIndex());
    }

    @Test
    public void testParseWithPositionReturnsNullAndSetsErrorIndexOnFailure() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);

        Date actual = parser.parse("2017/06/23", pos);

        assertNull(actual);
        assertEquals(0, pos.getIndex());
        assertTrue(pos.getErrorIndex() >= 0);
    }

    // ---- parse(String, ParsePosition, Calendar) ----

    @Test
    public void testParseWithCalendarSuccessUpdatesCalendarAndPosition() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        Calendar calendar = newCalendar();
        ParsePosition pos = new ParsePosition(0);

        boolean result = parser.parse("2017-06-23 13:45:30", pos, calendar);

        assertTrue(result);
        assertEquals(19, pos.getIndex());
        assertEquals(2017, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, calendar.get(Calendar.MONTH));
        assertEquals(23, calendar.get(Calendar.DAY_OF_MONTH));
        assertEquals(13, calendar.get(Calendar.HOUR_OF_DAY));
        assertEquals(45, calendar.get(Calendar.MINUTE));
        assertEquals(30, calendar.get(Calendar.SECOND));
    }

    @Test
    public void testParseWithCalendarLenientFieldOverflowRollsOver() {
        FastDateParser parser = new FastDateParser("HH:mm", UTC, Locale.US);
        Calendar calendar = newCalendar();
        calendar.setLenient(true);
        ParsePosition pos = new ParsePosition(0);

        boolean result = parser.parse("01:90", pos, calendar);

        assertTrue(result);
        assertEquals(2, calendar.get(Calendar.HOUR_OF_DAY));
        assertEquals(30, calendar.get(Calendar.MINUTE));
    }

    @Test
    public void testParseWithCalendarNonLenientOutOfRangeThrowsIllegalArgumentException() {
        final FastDateParser parser = new FastDateParser("HH:mm", UTC, Locale.US);
        final Calendar calendar = newCalendar();
        calendar.setLenient(false);
        final ParsePosition pos = new ParsePosition(0);

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                parser.parse("01:90", pos, calendar);
            }
        });
    }

    @Test
    public void testParseWithCalendarFailureReturnsFalseAndSetsErrorIndex() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Calendar calendar = newCalendar();
        ParsePosition pos = new ParsePosition(0);

        boolean result = parser.parse("2017/06/23", pos, calendar);

        assertFalse(result);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    // ---- parseObject(String) ----

    @Test
    public void testParseObjectStringSuccess() throws ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        Object actual = parser.parseObject("2017-06-23");

        assertTrue(actual instanceof Date);

        Calendar expected = newCalendar();
        expected.set(2017, Calendar.JUNE, 23);
        assertEquals(expected.getTime(), actual);
    }

    @Test
    public void testParseObjectStringThrowsParseExceptionWhenBeginningCannotBeParsed() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Exception {
                parser.parseObject("not-a-date");
            }
        });
    }

    // ---- parseObject(String, ParsePosition) ----

    @Test
    public void testParseObjectWithPositionSuccess() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);

        Object actual = parser.parseObject("2017-06-23", pos);

        assertNotNull(actual);
        assertTrue(actual instanceof Date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    public void testParseObjectWithPositionReturnsNullOnFailure() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);

        Object actual = parser.parseObject("2017/06/23", pos);

        assertNull(actual);
    }

    // ---- equals / hashCode ----

    @Test
    public void testEqualsAndHashCodeForEquivalentParsers() {
        FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsReflexive() {
        FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(a.equals(a));
    }

    @Test
    public void testEqualsFalseForDifferentPattern() {
        FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = new FastDateParser("MM/dd/yyyy", UTC, Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForNullAndForDifferentType() {
        FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
    }

    // ---- toString / toStringAll ----

    @Test
    public void testToStringReturnsNonEmptyDebugString() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        String s = parser.toString();
        assertNotNull(s);
        assertTrue(s.length() > 0);
    }

    @Test
    public void testToStringAllReturnsNonEmptyDebugString() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        String s = parser.toStringAll();
        assertNotNull(s);
        assertTrue(s.length() > 0);
    }

    // ---- clear() ----

    @Test
    public void testClearDoesNotBreakSubsequentParsing() throws ParseException {
        FastDateParser.clear();

        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("2017-06-23");

        Calendar expected = newCalendar();
        expected.set(2017, Calendar.JUNE, 23);
        assertEquals(expected.getTime(), actual);
    }

    // ---- JAPANESE_IMPERIAL field ----

    @Test
    public void testJapaneseImperialLocaleFieldIsUsableLocale() {
        assertNotNull(FastDateParser.JAPANESE_IMPERIAL);
        assertTrue(FastDateParser.JAPANESE_IMPERIAL instanceof Locale);

        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        assertEquals(FastDateParser.JAPANESE_IMPERIAL, parser.getLocale());
    }

    // ---- centuryStart boundary ----

    @Test
    public void testCenturyStartDefinesHundredYearWindowForTwoDigitYears() {
        Date centuryStart = newCenturyStart(1950);
        FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStart);

        assertYearWithinCenturyWindow(parser, "00", 1950, 2049);
        assertYearWithinCenturyWindow(parser, "49", 1950, 2049);
        assertYearWithinCenturyWindow(parser, "50", 1950, 2049);
        assertYearWithinCenturyWindow(parser, "99", 1950, 2049);
    }

    private static void assertYearWithinCenturyWindow(FastDateParser parser, String twoDigitYear,
            int minYear, int maxYear) {
        Calendar calendar = newCalendar();
        ParsePosition pos = new ParsePosition(0);

        boolean result = parser.parse(twoDigitYear, pos, calendar);

        assertTrue(result);
        int year = calendar.get(Calendar.YEAR);
        assertTrue(year >= minYear && year <= maxYear);
    }

    private static Date newCenturyStart(int year) {
        Calendar cal = newCalendar();
        cal.set(year, Calendar.JANUARY, 1);
        return cal.getTime();
    }
}
