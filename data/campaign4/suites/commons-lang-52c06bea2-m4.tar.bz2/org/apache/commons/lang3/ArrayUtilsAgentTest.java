/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    //
    // add
    //

    @Test
    void testAddIntElement() {
        final int[] result = ArrayUtils.add(new int[] { 1, 2 }, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        final int[] fromNull = ArrayUtils.add((int[]) null, 9);
        assertArrayEquals(new int[] { 9 }, fromNull);
    }

    @Test
    void testAddIntElementAtIndex() {
        final int[] result = ArrayUtils.add(new int[] { 1, 3 }, 1, 2);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
    }

    @Test
    void testAddIntElementAtIndexOutOfBounds() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, 5, 3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, -1, 3);
            }
        });
    }

    @Test
    void testAddObjectElement() {
        final String[] result = ArrayUtils.add(new String[] { "a", "b" }, "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
        final Object[] fromNull = ArrayUtils.add((Object[]) null, "x");
        assertArrayEquals(new Object[] { "x" }, fromNull);
    }

    @Test
    void testAddAllIntArrays() {
        final int[] result = ArrayUtils.addAll(new int[] { 1, 2 }, 3, 4);
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, result);
        assertArrayEquals(new int[] { 3, 4 }, ArrayUtils.addAll((int[]) null, 3, 4));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll(new int[] { 1, 2 }, (int[]) null));
    }

    @Test
    void testAddAllObjectArrays() {
        final String[] result = ArrayUtils.addAll(new String[] { "a" }, "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
    }

    @Test
    void testAddFirstInt() {
        final int[] result = ArrayUtils.addFirst(new int[] { 2, 3 }, 1);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        assertArrayEquals(new int[] { 1 }, ArrayUtils.addFirst((int[]) null, 1));
    }

    //
    // arraycopy / clone
    //

    @Test
    void testArraycopy() {
        final int[] source = { 1, 2, 3, 4, 5 };
        final int[] dest = new int[5];
        final int[] returned = ArrayUtils.arraycopy(source, 1, dest, 0, 3);
        assertSame(dest, returned);
        assertArrayEquals(new int[] { 2, 3, 4, 0, 0 }, dest);
    }

    @Test
    void testArraycopyOutOfBoundsThrows() {
        final int[] source = { 1, 2, 3 };
        final int[] dest = new int[3];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.arraycopy(source, 0, dest, 0, 10);
            }
        });
    }

    @Test
    void testCloneIntArray() {
        final int[] array = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertNotSame(array, cloned);
        assertNull(ArrayUtils.clone((int[]) null));
    }

    @Test
    void testCloneObjectArray() {
        final Object[] array = { "a", "b" };
        final Object[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertNotSame(array, cloned);
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    //
    // concat
    //

    @Test
    void testConcatIntArrays() {
        final int[] result = ArrayUtils.concat(new int[] { 1, 2 }, new int[] { 3 }, new int[] { 4, 5 });
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, result);
    }

    @Test
    void testConcatNullArrayOfArraysThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.concat((int[][]) null);
            }
        });
    }

    //
    // contains / containsAny
    //

    @Test
    void testContainsObject() {
        final Object[] array = { "a", "b", "c" };
        assertTrue(ArrayUtils.contains(array, "b"));
        assertFalse(ArrayUtils.contains(array, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
        assertTrue(ArrayUtils.contains(new Object[] { null, "a" }, null));
    }

    @Test
    void testContainsDoubleWithTolerance() {
        final double[] array = { 1.0, 2.0, 3.0 };
        assertTrue(ArrayUtils.contains(array, 2.0001, 0.01));
        assertFalse(ArrayUtils.contains(array, 2.5, 0.01));
    }

    @Test
    void testContainsAnyObject() {
        final Object[] array = { "a", "b", "c" };
        assertTrue(ArrayUtils.containsAny(array, "z", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "a"));
    }

    //
    // get
    //

    @Test
    void testGet() {
        final String[] array = { "a", "b" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
    }

    @Test
    void testGetWithDefault() {
        final String[] array = { "a", "b" };
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("default", ArrayUtils.get((String[]) null, 0, "default"));
    }

    @Test
    void testGetComponentType() {
        final String[] array = { "a" };
        assertEquals(String.class, ArrayUtils.getComponentType(array));
        assertNull(ArrayUtils.getComponentType((String[]) null));
    }

    @Test
    void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[] { 1 }));
        assertEquals(2, ArrayUtils.getDimensions(new int[1][1]));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
    }

    @Test
    void testGetLengthNotAnArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        assertEquals(ArrayUtils.hashCode(new int[] { 1, 2 }), ArrayUtils.hashCode(new int[] { 1, 2 }));
        assertTrue(ArrayUtils.hashCode(new int[] { 1, 2 }) != ArrayUtils.hashCode(new int[] { 1, 3 }));
    }

    @Test
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(new int[] { 1 }, null));
    }

    //
    // indexesOf / indexOf / lastIndexOf
    //

    @Test
    void testIndexesOfInt() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, bits.cardinality());
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertTrue(ArrayUtils.indexesOf((int[]) null, 1).isEmpty());
    }

    @Test
    void testIndexOfInt() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
    }

    @Test
    void testIndexOfObjectWithNull() {
        final Object[] array = { "a", null, "b" };
        assertEquals(1, ArrayUtils.indexOf(array, null));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, "z"));
    }

    @Test
    void testIndexOfDoubleWithTolerance() {
        final double[] array = { 1.0, 2.0, 3.0 };
        assertEquals(1, ArrayUtils.indexOf(array, 2.005, 0.01));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2.5, 0.01));
    }

    @Test
    void testLastIndexOfInt() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
    }

    //
    // insert
    //

    @Test
    void testInsertInt() {
        final int[] result = ArrayUtils.insert(1, new int[] { 1, 3 }, 2);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
        final int[] original = { 1, 2 };
        final int[] clonedUnchanged = ArrayUtils.insert(0, original);
        assertArrayEquals(original, clonedUnchanged);
        assertNotSame(original, clonedUnchanged);
    }

    @Test
    void testInsertIntOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new int[] { 1, 2 }, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(5, new int[] { 1, 2 }, 9);
            }
        });
    }

    @Test
    void testInsertObject() {
        final String[] result = ArrayUtils.insert(1, new String[] { "a", "c" }, "b");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
    }

    //
    // isArrayIndexValid
    //

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, -1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 1));
    }

    //
    // isEmpty / isNotEmpty
    //

    @Test
    void testIsEmptyAndIsNotEmptyIntArray() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));
    }

    @Test
    void testIsEmptyObjectArray() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));
    }

    //
    // isSameLength / isSameType
    //

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1 }, (int[]) null));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new Object[0], new String[0]));
    }

    @Test
    void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(new int[0], null);
            }
        });
    }

    //
    // isSorted
    //

    @Test
    void testIsSortedInt() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 1, 2 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    @Test
    void testIsSortedWithComparator() {
        final Comparator<String> byLength = new Comparator<String>() {
            @Override
            public int compare(final String a, final String b) {
                return Integer.compare(a.length(), b.length());
            }
        };
        assertTrue(ArrayUtils.isSorted(new String[] { "a", "bb", "ccc" }, byLength));
        assertFalse(ArrayUtils.isSorted(new String[] { "ccc", "a" }, byLength));
    }

    @Test
    void testIsSortedComparatorNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSorted(new String[] { "a" }, null);
            }
        });
    }

    //
    // newInstance / nullTo / nullToEmpty
    //

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertEquals(String.class, array.getClass().getComponentType());
    }

    @Test
    void testNullTo() {
        final String[] defaultArray = { "default" };
        assertSame(defaultArray, ArrayUtils.nullTo((String[]) null, defaultArray));
        assertSame(defaultArray, ArrayUtils.nullTo(new String[0], defaultArray));
        final String[] array = { "a" };
        assertSame(array, ArrayUtils.nullTo(array, defaultArray));
    }

    @Test
    void testNullToEmptyIntArray() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = { 1 };
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    void testNullToEmptyObjectArrayWithType() {
        final String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    //
    // remove / removeAll / removeAllOccurrences / removeElement / removeElements
    //

    @Test
    void testRemoveInt() {
        assertArrayEquals(new int[] { 1, 3 }, ArrayUtils.remove(new int[] { 1, 2, 3 }, 1));
    }

    @Test
    void testRemoveIntOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2 }, 5);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2 }, -1);
            }
        });
    }

    @Test
    void testRemoveNullArrayThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    void testRemoveAllInt() {
        final int[] result = ArrayUtils.removeAll(new int[] { 1, 2, 3, 4, 5 }, 1, 3);
        assertArrayEquals(new int[] { 1, 3, 5 }, result);
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] { 1, 2, 1, 3, 1 }, 1);
        assertArrayEquals(new int[] { 2, 3 }, result);
    }

    @Test
    void testRemoveElement() {
        final int[] result = ArrayUtils.removeElement(new int[] { 1, 2, 3, 2 }, 2);
        assertArrayEquals(new int[] { 1, 3, 2 }, result);
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.removeElement(new int[] { 1, 2 }, 99));
    }

    @Test
    void testRemoveElementObject() {
        final Object[] result = ArrayUtils.removeElement(new Object[] { "a", "b", "a" }, "a");
        assertArrayEquals(new Object[] { "b", "a" }, result);
    }

    @Test
    void testRemoveElements() {
        final int[] result = ArrayUtils.removeElements(new int[] { 1, 2, 2, 3 }, 2);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        final int[] removeTwo = ArrayUtils.removeElements(new int[] { 1, 2, 2, 3 }, 2, 2);
        assertArrayEquals(new int[] { 1, 3 }, removeTwo);
    }

    //
    // reverse
    //

    @Test
    void testReverseInt() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);
    }

    @Test
    void testReverseIntNullIsNoOp() {
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testReverseIntRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array);
    }

    @Test
    void testReverseObjectArray() {
        final String[] array = { "a", "b", "c" };
        ArrayUtils.reverse(array);
        assertArrayEquals(new String[] { "c", "b", "a" }, array);
    }

    //
    // setAll
    //

    @Test
    void testSetAllWithIntFunction() {
        final Integer[] array = new Integer[3];
        final Integer[] result = ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            @Override
            public Integer apply(final int value) {
                return value * value;
            }
        });
        assertArrayEquals(new Integer[] { 0, 1, 4 }, result);
        assertSame(array, result);
    }

    //
    // shift
    //

    @Test
    void testShiftInt() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] { 5, 1, 2, 3, 4 }, array);
    }

    @Test
    void testShiftIntNegativeOffset() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, -1);
        assertArrayEquals(new int[] { 2, 3, 4, 5, 1 }, array);
    }

    @Test
    void testShiftIntRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 1, 4, 1);
        assertArrayEquals(new int[] { 1, 4, 2, 3, 5 }, array);
    }

    @Test
    void testShiftEmptyOrNullIsNoOp() {
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    //
    // shuffle
    //

    @Test
    void testShuffleDeterministicWithSeededRandom() {
        final int[] array = { 1, 2, 3, 4, 5 };
        final int[] copy = array.clone();
        ArrayUtils.shuffle(array, new java.util.Random(42));
        ArrayUtils.shuffle(copy, new java.util.Random(42));
        assertArrayEquals(array, copy);
        final int[] sorted = array.clone();
        java.util.Arrays.sort(sorted);
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, sorted);
    }

    //
    // startsWith
    //

    @Test
    void testStartsWith() {
        final byte[] data = { 1, 2, 3, 4 };
        assertTrue(ArrayUtils.startsWith(data, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(data, new byte[] { 2, 3 }));
        assertFalse(ArrayUtils.startsWith(data, new byte[] { 1, 2, 3, 4, 5 }));
        assertTrue(ArrayUtils.startsWith(data, data));
        assertTrue(ArrayUtils.startsWith(null, null));
        assertFalse(ArrayUtils.startsWith(data, null));
        assertFalse(ArrayUtils.startsWith(null, data));
        assertTrue(ArrayUtils.startsWith(data, new byte[] { 1, 2, 3, 4 }));
    }

    //
    // subarray
    //

    @Test
    void testSubarrayInt() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    void testSubarrayIntUndervalueOvervalue() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 2, 3 }, ArrayUtils.subarray(array, -5, 10));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 1));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 5, 10));
    }

    @Test
    void testSubarrayObject() {
        final String[] array = { "a", "b", "c" };
        assertArrayEquals(new String[] { "b", "c" }, ArrayUtils.subarray(array, 1, 3));
    }

    //
    // swap
    //

    @Test
    void testSwapInt() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);
    }

    @Test
    void testSwapIntOverflowIndexIsNoOp() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array);
    }

    @Test
    void testSwapIntNegativeIndexPromotedToZero() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, -1, 1);
        assertArrayEquals(new int[] { 2, 1, 3 }, array);
    }

    @Test
    void testSwapIntWithLength() {
        final int[] array = { 1, 2, 3, 4, 5, 6 };
        ArrayUtils.swap(array, 0, 3, 2);
        assertArrayEquals(new int[] { 4, 5, 3, 1, 2, 6 }, array);
    }

    @Test
    void testSwapNullOrEmptyIsNoOp() {
        ArrayUtils.swap((int[]) null, 0, 1);
        final int[] empty = {};
        ArrayUtils.swap(empty, 0, 1);
        assertEquals(0, empty.length);
    }

    //
    // toArray
    //

    @Test
    void testToArray() {
        final String[] result = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
    }

    //
    // toMap
    //

    @Test
    void testToMapFromEntryArrays() {
        final Map<Object, Object> map = ArrayUtils.toMap(new Object[][] { { "k1", "v1" }, { "k2", "v2" } });
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));
    }

    @Test
    void testToMapNull() {
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    void testToMapEntryTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[][] { { "onlyone" } });
            }
        });
    }

    @Test
    void testToMapInvalidElementThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] { "not a pair or entry" });
            }
        });
    }

    //
    // toObject / toPrimitive
    //

    @Test
    void testToObjectInt() {
        final Integer[] result = ArrayUtils.toObject(new int[] { 1, 2, 3 });
        assertArrayEquals(new Integer[] { 1, 2, 3 }, result);
        assertNull(ArrayUtils.toObject((int[]) null));
    }

    @Test
    void testToPrimitiveInteger() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] { 1, 2, 3 });
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    void testToPrimitiveIntegerWithNullElementThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] { 1, null });
            }
        });
    }

    @Test
    void testToPrimitiveIntegerWithDefaultForNull() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] { 1, null, 3 }, -1);
        assertArrayEquals(new int[] { 1, -1, 3 }, result);
    }

    @Test
    void testToPrimitiveGenericObjectDispatch() {
        final Object result = ArrayUtils.toPrimitive((Object) new Integer[] { 1, 2 });
        assertArrayEquals(new int[] { 1, 2 }, (int[]) result);
        assertNull(ArrayUtils.toPrimitive((Object) null));
    }

    //
    // toString / toStringArray
    //

    @Test
    void testToStringArray() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] { 1, 2, 3 }));
    }

    @Test
    void testToStringArrayMethod() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", 1, null });
        assertEquals("a", result[0]);
        assertEquals("1", result[1]);
        assertEquals("null", result[2]);
    }

    @Test
    void testToStringArrayMethodWithDefaultForNulls() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", null }, "N/A");
        assertArrayEquals(new String[] { "a", "N/A" }, result);
    }

    @Test
    void testToStringArrayNullArrayReturnsNull() {
        assertNull(ArrayUtils.toStringArray(null));
    }
}
