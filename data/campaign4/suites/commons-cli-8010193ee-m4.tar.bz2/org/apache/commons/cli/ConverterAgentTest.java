/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

class ConverterAgentTest {

    @Test
    void testDefaultReturnsSameString() {
        final Object result;
        try {
            result = Converter.DEFAULT.apply("hello");
        } catch (final RuntimeException e) {
            throw e;
        }
        assertEquals("hello", result);
    }

    @Test
    void testDefaultWithEmptyString() throws Exception {
        assertEquals("", Converter.DEFAULT.apply(""));
    }

    @Test
    void testClassConverterFindsExistingClass() throws Exception {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    void testClassConverterThrowsOnUnknownClass() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.Class");
            }
        });
    }

    @Test
    void testFileConverterCreatesFile() throws Exception {
        final File file = Converter.FILE.apply("some/path.txt");
        assertEquals("some/path.txt", file.getPath());
    }

    @Test
    void testFileConverterThrowsOnNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathConverterCreatesPath() throws Exception {
        final Path path = Converter.PATH.apply("a/b/c");
        assertEquals("a/b/c", path.toString().replace(File.separatorChar, '/'));
    }

    @Test
    void testPathConverterThrowsOnInvalidPath() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("inv\u0000alid");
            }
        });
    }

    @Test
    void testNumberConverterReturnsLongForIntegerString() throws Exception {
        final Number number = Converter.NUMBER.apply("42");
        assertTrue(number instanceof Long);
        assertEquals(42L, number.longValue());
    }

    @Test
    void testNumberConverterReturnsDoubleForDecimalString() throws Exception {
        final Number number = Converter.NUMBER.apply("3.14");
        assertTrue(number instanceof Double);
        assertEquals(3.14d, number.doubleValue(), 0.0001);
    }

    @Test
    void testNumberConverterThrowsOnNonNumeric() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("notanumber");
            }
        });
    }

    @Test
    void testNumberConverterThrowsOnMalformedDecimal() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("1.2.3");
            }
        });
    }

    @Test
    void testObjectConverterInstantiatesClass() throws Exception {
        final Object obj = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(obj);
        assertEquals(Object.class, obj.getClass());
    }

    @Test
    void testObjectConverterThrowsOnUnknownClass() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.Class");
            }
        });
    }

    @Test
    void testUrlConverterCreatesUrl() throws Exception {
        final URL url = Converter.URL.apply("https://example.com/path");
        assertEquals("https://example.com/path", url.toString());
    }

    @Test
    void testUrlConverterThrowsOnMalformedUrl() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    void testDateConverterParsesValidDate() throws Exception {
        final Date date = Converter.DATE.apply("Wed Jan 04 00:00:00 UTC 2023");
        final GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.setTime(date);
        assertEquals(2023, calendar.get(GregorianCalendar.YEAR));
        assertEquals(GregorianCalendar.JANUARY, calendar.get(GregorianCalendar.MONTH));
        assertEquals(4, calendar.get(GregorianCalendar.DAY_OF_MONTH));
    }

    @Test
    void testDateConverterThrowsOnInvalidDay() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                // Day 30 does not exist in February; lenient parsing is disabled.
                Converter.DATE.apply("Thu Feb 30 00:00:00 UTC 2023");
            }
        });
    }

    @Test
    void testDateConverterThrowsOnGarbageInput() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date at all");
            }
        });
    }

    @Test
    void testCustomLambdaImplementationCanThrowCheckedException() {
        final Converter<Integer, ParseException> doubler = new Converter<Integer, ParseException>() {
            @Override
            public Integer apply(final String string) throws ParseException {
                if (string.isEmpty()) {
                    throw new ParseException("empty", 0);
                }
                return Integer.parseInt(string) * 2;
            }
        };

        try {
            assertEquals(Integer.valueOf(10), doubler.apply("5"));
        } catch (final ParseException e) {
            fail("Unexpected ParseException for valid input");
        }

        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                doubler.apply("");
            }
        });
    }

    @Test
    void testDefaultConverterIsNotEqualToOtherConstants() {
        final Object defaultConverter = Converter.DEFAULT;
        final Object classConverter = Converter.CLASS;
        assertFalse(defaultConverter == classConverter);
    }
}
