/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    static class ExcludeFixture {
        private final int a;
        private final int b;

        ExcludeFixture(final int a, final int b) {
            this.a = a;
            this.b = b;
        }
    }

    static class HashCodeExcludeFixture {
        private final int included;
        @HashCodeExclude
        private final int excluded;

        HashCodeExcludeFixture(final int included, final int excluded) {
            this.included = included;
            this.excluded = excluded;
        }
    }

    static class ReflectBase {
        @SuppressWarnings("unused")
        private final int base;

        ReflectBase(final int base) {
            this.base = base;
        }
    }

    static class ReflectSub extends ReflectBase {
        @SuppressWarnings("unused")
        private final int sub;

        ReflectSub(final int base, final int sub) {
            super(base);
            this.sub = sub;
        }
    }

    static class TransientFixture {
        @SuppressWarnings("unused")
        private final int i;
        private final transient int t;

        TransientFixture(final int i, final int t) {
            this.i = i;
            this.t = t;
        }
    }

    // --- Constructors ---

    @Test
    void testDefaultConstructorInitialValue() {
        assertEquals(17, new HashCodeBuilder().toHashCode());
    }

    @Test
    void testConstructorEvenInitialThrows() {
        assertThrows(IllegalArgumentException.class, () -> new HashCodeBuilder(4, 37));
    }

    @Test
    void testConstructorEvenMultiplierThrows() {
        assertThrows(IllegalArgumentException.class, () -> new HashCodeBuilder(17, 38));
    }

    @Test
    void testConstructorCustomOddNumbers() {
        assertEquals(5, new HashCodeBuilder(5, 7).toHashCode());
    }

    // --- Builder ---

    @Test
    void testBuilderProducesConfiguredHashCodeBuilder() {
        final HashCodeBuilder hcb = HashCodeBuilder.builder().setInitialOddNumber(5).setMultiplierOddNumber(7).get();
        assertEquals(5, hcb.toHashCode());
        hcb.append(2);
        assertEquals(5 * 7 + 2, hcb.toHashCode());
    }

    @Test
    void testBuilderEvenInitialThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> HashCodeBuilder.builder().setInitialOddNumber(4).setMultiplierOddNumber(7).get());
    }

    @Test
    void testBuilderEvenMultiplierThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> HashCodeBuilder.builder().setInitialOddNumber(5).setMultiplierOddNumber(8).get());
    }

    // --- append(primitive) ---

    @Test
    void testAppendBoolean() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(true).toHashCode());
        assertEquals(17 * 37 + 1, new HashCodeBuilder(17, 37).append(false).toHashCode());
    }

    @Test
    void testAppendByte() {
        assertEquals(17 * 37 + 5, new HashCodeBuilder(17, 37).append((byte) 5).toHashCode());
    }

    @Test
    void testAppendChar() {
        assertEquals(17 * 37 + 'A', new HashCodeBuilder(17, 37).append('A').toHashCode());
    }

    @Test
    void testAppendInt() {
        assertEquals(17 * 37 + 42, new HashCodeBuilder(17, 37).append(42).toHashCode());
    }

    @Test
    void testAppendShort() {
        assertEquals(17 * 37 + 9, new HashCodeBuilder(17, 37).append((short) 9).toHashCode());
    }

    @Test
    void testAppendLong() {
        final long value = 123456789012345L;
        final int expected = 17 * 37 + (int) (value ^ value >> 32);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void testAppendFloat() {
        final int expected = 17 * 37 + Float.floatToIntBits(3.14f);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(3.14f).toHashCode());
    }

    @Test
    void testAppendDouble() {
        final long bits = Double.doubleToLongBits(3.14d);
        final int expected = 17 * 37 + (int) (bits ^ bits >> 32);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(3.14d).toHashCode());
    }

    @Test
    void testAppendReturnsThis() {
        final HashCodeBuilder hcb = new HashCodeBuilder();
        assertSame(hcb, hcb.append(1));
        assertSame(hcb, hcb.append("x"));
        assertSame(hcb, hcb.append(true));
    }

    // --- append(array) ---

    @Test
    void testAppendNullArraysOnlyMultiply() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((int[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((long[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((short[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((char[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((byte[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((double[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((float[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((boolean[]) null).toHashCode());
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((Object[]) null).toHashCode());
    }

    @Test
    void testAppendEmptyArrayLeavesTotalUnchanged() {
        assertEquals(17, new HashCodeBuilder(17, 37).append(new int[0]).toHashCode());
    }

    @Test
    void testAppendIntArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append(1).append(2).append(3).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new int[] {1, 2, 3}).toHashCode());
    }

    @Test
    void testAppendLongArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append(1L).append(2L).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new long[] {1L, 2L}).toHashCode());
    }

    @Test
    void testAppendShortArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append((short) 1).append((short) 2).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new short[] {1, 2}).toHashCode());
    }

    @Test
    void testAppendCharArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append('a').append('b').toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new char[] {'a', 'b'}).toHashCode());
    }

    @Test
    void testAppendByteArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append((byte) 1).append((byte) 2).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new byte[] {1, 2}).toHashCode());
    }

    @Test
    void testAppendDoubleArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append(1.1d).append(2.2d).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new double[] {1.1d, 2.2d}).toHashCode());
    }

    @Test
    void testAppendFloatArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append(1.1f).append(2.2f).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new float[] {1.1f, 2.2f}).toHashCode());
    }

    @Test
    void testAppendBooleanArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append(true).append(false).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new boolean[] {true, false}).toHashCode());
    }

    @Test
    void testAppendObjectArraySameAsSequentialAppends() {
        final int expected = new HashCodeBuilder(17, 37).append("a").append("b").toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(new Object[] {"a", "b"}).toHashCode());
    }

    @Test
    void testAppendMultiDimensionalArray() {
        final int[][] array = {{1, 2}, {3, 4}};
        // Must not throw and must be consistent across repeated calls.
        final int first = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int second = new HashCodeBuilder(17, 37).append(array).toHashCode();
        assertEquals(first, second);
    }

    // --- append(Object) ---

    @Test
    void testAppendObjectNull() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((Object) null).toHashCode());
    }

    @Test
    void testAppendObjectNonArray() {
        final String s = "hello";
        assertEquals(17 * 37 + s.hashCode(), new HashCodeBuilder(17, 37).append((Object) s).toHashCode());
    }

    @Test
    void testAppendObjectDispatchesPrimitiveArray() {
        final int[] array = {1, 2, 3};
        final int viaObject = new HashCodeBuilder(17, 37).append((Object) array).toHashCode();
        final int viaTyped = new HashCodeBuilder(17, 37).append(array).toHashCode();
        assertEquals(viaTyped, viaObject);
    }

    @Test
    void testAppendObjectDispatchesObjectArray() {
        final Object[] array = {"a", "b"};
        final int viaObject = new HashCodeBuilder(17, 37).append((Object) array).toHashCode();
        final int viaTyped = new HashCodeBuilder(17, 37).append(array).toHashCode();
        assertEquals(viaTyped, viaObject);
    }

    @Test
    void testAppendObjectSelfReferencingArrayDoesNotStackOverflow() {
        final Object[] array = new Object[1];
        array[0] = array;
        final int result = new HashCodeBuilder().append((Object) array).toHashCode();
        assertNotNull(Integer.valueOf(result));
    }

    // --- appendSuper ---

    @Test
    void testAppendSuper() {
        assertEquals(17 * 37 + 100, new HashCodeBuilder(17, 37).appendSuper(100).toHashCode());
    }

    // --- build() ---

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37).append(42);
        assertEquals(Integer.valueOf(hcb.toHashCode()), hcb.build());
    }

    // --- equals/hashCode of HashCodeBuilder itself ---

    @Test
    void testEqualsSameInstance() {
        final HashCodeBuilder hcb = new HashCodeBuilder();
        assertTrue(hcb.equals(hcb));
    }

    @Test
    void testEqualsDifferentType() {
        final HashCodeBuilder hcb = new HashCodeBuilder();
        assertFalse(hcb.equals("not a HashCodeBuilder"));
    }

    @Test
    void testEqualsNull() {
        assertFalse(new HashCodeBuilder().equals(null));
    }

    @Test
    void testEqualsBasedOnTotalRegardlessOfConstants() {
        final HashCodeBuilder a = new HashCodeBuilder(3, 5).append(10);
        final HashCodeBuilder b = new HashCodeBuilder(3, 5).append(10);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentTotals() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(2);
        assertFalse(a.equals(b));
    }

    @Test
    void testHashCodeMatchesToHashCode() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37).append("value");
        assertEquals(hcb.toHashCode(), hcb.hashCode());
    }

    // --- reflectionHashCode ---

    @Test
    void testReflectionHashCodeConsistentForEqualFields() {
        final ExcludeFixture f1 = new ExcludeFixture(1, 2);
        final ExcludeFixture f2 = new ExcludeFixture(1, 2);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f2));
    }

    @Test
    void testReflectionHashCodeDiffersForDifferentFields() {
        final ExcludeFixture f1 = new ExcludeFixture(1, 2);
        final ExcludeFixture f2 = new ExcludeFixture(1, 3);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f2));
    }

    @Test
    void testReflectionHashCodeNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, () -> HashCodeBuilder.reflectionHashCode(null, false));
    }

    @Test
    void testReflectionHashCodeNullObjectVarargsThrowsNpe() {
        assertThrows(NullPointerException.class, () -> HashCodeBuilder.reflectionHashCode((Object) null, "a"));
    }

    @Test
    void testReflectionHashCodeEvenInitialThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> HashCodeBuilder.reflectionHashCode(4, 37, new ExcludeFixture(1, 2)));
    }

    @Test
    void testReflectionHashCodeEvenMultiplierThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> HashCodeBuilder.reflectionHashCode(17, 38, new ExcludeFixture(1, 2)));
    }

    @Test
    void testReflectionHashCodeExcludeFieldsVarargs() {
        final ExcludeFixture f1 = new ExcludeFixture(1, 2);
        final ExcludeFixture f2 = new ExcludeFixture(1, 999);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1, "b"), HashCodeBuilder.reflectionHashCode(f2, "b"));
    }

    @Test
    void testReflectionHashCodeExcludeFieldsCollection() {
        final ExcludeFixture f1 = new ExcludeFixture(1, 2);
        final ExcludeFixture f2 = new ExcludeFixture(1, 999);
        final int h1 = HashCodeBuilder.reflectionHashCode(f1, Collections.singletonList("b"));
        final int h2 = HashCodeBuilder.reflectionHashCode(f2, Collections.singletonList("b"));
        assertEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeExcludeFieldsCollectionNotMasking() {
        final ExcludeFixture f1 = new ExcludeFixture(1, 2);
        final ExcludeFixture f2 = new ExcludeFixture(1, 999);
        final int h1 = HashCodeBuilder.reflectionHashCode(f1, Arrays.asList("someOtherField"));
        final int h2 = HashCodeBuilder.reflectionHashCode(f2, Arrays.asList("someOtherField"));
        assertNotEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeHashCodeExcludeAnnotation() {
        final HashCodeExcludeFixture f1 = new HashCodeExcludeFixture(1, 2);
        final HashCodeExcludeFixture f2 = new HashCodeExcludeFixture(1, 999);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f2));
    }

    @Test
    void testReflectionHashCodeTransientsExcludedByDefault() {
        final TransientFixture f1 = new TransientFixture(1, 2);
        final TransientFixture f2 = new TransientFixture(1, 999);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1, false), HashCodeBuilder.reflectionHashCode(f2, false));
    }

    @Test
    void testReflectionHashCodeTransientsIncludedWhenRequested() {
        final TransientFixture f1 = new TransientFixture(1, 2);
        final TransientFixture f2 = new TransientFixture(1, 999);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(f1, true), HashCodeBuilder.reflectionHashCode(f2, true));
    }

    @Test
    void testReflectionHashCodeReflectUpToClassExcludesSuperclassFields() {
        final ReflectSub s1 = new ReflectSub(1, 5);
        final ReflectSub s2 = new ReflectSub(2, 5);
        final int h1 = HashCodeBuilder.reflectionHashCode(17, 37, s1, false, ReflectSub.class);
        final int h2 = HashCodeBuilder.reflectionHashCode(17, 37, s2, false, ReflectSub.class);
        assertEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeFullHierarchyIncludesSuperclassFields() {
        final ReflectSub s1 = new ReflectSub(1, 5);
        final ReflectSub s2 = new ReflectSub(2, 5);
        final int h1 = HashCodeBuilder.reflectionHashCode(17, 37, s1, false, null);
        final int h2 = HashCodeBuilder.reflectionHashCode(17, 37, s2, false, null);
        assertNotEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeThreeArgOverloadMatchesFiveArgDefaultTransients() {
        final ExcludeFixture f = new ExcludeFixture(3, 4);
        assertEquals(HashCodeBuilder.reflectionHashCode(21, 41, f),
                HashCodeBuilder.reflectionHashCode(21, 41, f, false, null));
    }
}
