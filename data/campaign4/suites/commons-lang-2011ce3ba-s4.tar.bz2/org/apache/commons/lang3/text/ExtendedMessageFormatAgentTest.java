package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}, based solely on the
 * documented contract in the generated javadoc under api/.
 */
public class ExtendedMessageFormatAgentTest {

    /** A Format that upper-cases the String value of whatever it is given. */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    /** A FormatFactory that always hands out an {@link UpperCaseFormat}. */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(String name, String arguments, Locale locale) {
            return new UpperCaseFormat();
        }
    }

    /**
     * A FormatFactory that records the name/arguments/locale it was invoked
     * with, and returns a Format that simply prints back the captured
     * "arguments" (format-style) text, ignoring the value being formatted.
     * Used to verify that format-name/format-style are passed through
     * (trimmed of surrounding whitespace, per the class javadoc).
     */
    private static final class CapturingFormatFactory implements FormatFactory {
        private String lastName;
        private String lastArguments;
        private Locale lastLocale;

        @Override
        public Format getFormat(String name, String arguments, Locale locale) {
            this.lastName = name;
            this.lastArguments = arguments;
            this.lastLocale = locale;
            final String captured = arguments;
            return new Format() {
                private static final long serialVersionUID = 1L;

                @Override
                public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
                    return toAppendTo.append("STYLE:" + captured);
                }

                @Override
                public Object parseObject(String source, ParsePosition pos) {
                    return source;
                }
            };
        }
    }

    // ------------------------------------------------------------------
    // Constructors - bad pattern -> IllegalArgumentException
    // ------------------------------------------------------------------

    @Test
    public void testSingleArgConstructorThrowsOnBadPattern() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    public void testLocaleConstructorThrowsOnBadPattern() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new ExtendedMessageFormat("{0", Locale.US);
            }
        });
    }

    @Test
    public void testRegistryConstructorThrowsOnBadPattern() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new ExtendedMessageFormat("{0", registry);
            }
        });
    }

    @Test
    public void testLocaleAndRegistryConstructorThrowsOnBadPattern() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new ExtendedMessageFormat("{0", Locale.US, registry);
            }
        });
    }

    @Test
    public void testConstructorThrowsOnUnknownFormatNameNotInRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new ExtendedMessageFormat("{0,totallyBogusFormatName}", registry);
            }
        });
    }

    @Test
    public void testConstructorWithNullPatternThrows() {
        assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new ExtendedMessageFormat(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // Constructors - registry may be null
    // ------------------------------------------------------------------

    @Test
    public void testRegistryMayBeNull() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Map<String, FormatFactory>) null);
        assertEquals("abc", emf.format(new Object[] {"abc"}));
    }

    @Test
    public void testLocaleWithNullRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, null);
        assertEquals("xyz", emf.format(new Object[] {"xyz"}));
    }

    // ------------------------------------------------------------------
    // Basic formatting behaviour (inherited contract, used as plumbing)
    // ------------------------------------------------------------------

    @Test
    public void testPlainArgumentFormatting() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testStandardNumberFormatStillWorksWithoutRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
    }

    @Test
    public void testLocaleAffectsStandardFormatting() {
        ExtendedMessageFormat usFormat = new ExtendedMessageFormat("{0,number,currency}", Locale.US);
        ExtendedMessageFormat frFormat = new ExtendedMessageFormat("{0,number,currency}", Locale.FRANCE);
        String usResult = usFormat.format(new Object[] {Double.valueOf(1234.5)});
        String frResult = frFormat.format(new Object[] {Double.valueOf(1234.5)});
        assertNotEquals(usResult, frResult);
        assertTrue(usResult.indexOf('$') >= 0);
    }

    // ------------------------------------------------------------------
    // Custom registry usage
    // ------------------------------------------------------------------

    @Test
    public void testCustomRegistryFormatIsUsed() {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("HELLO", emf.format(new Object[] {"hello"}));
    }

    @Test
    public void testRegistryFallsBackToStandardFormatsForUnregisteredNames() {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} {1,number,integer}", registry);
        assertEquals("HELLO 7", emf.format(new Object[] {"hello", Integer.valueOf(7)}));
    }

    @Test
    public void testFormatNameAndStyleAreTrimmedAndPassedToFactory() {
        CapturingFormatFactory factory = new CapturingFormatFactory();
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("echo", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0, echo , styleValue }", Locale.US, registry);
        String result = emf.format(new Object[] {"ignoredValue"});
        assertEquals("echo", factory.lastName);
        assertEquals("styleValue", factory.lastArguments);
        assertEquals(Locale.US, factory.lastLocale);
        assertEquals("STYLE:styleValue", result);
    }

    @Test
    public void testMultipleArgumentsMixingCustomAndPlain() {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{1,upper}-{0}", registry);
        assertEquals("WORLD-hello", emf.format(new Object[] {"hello", "world"}));
    }

    // ------------------------------------------------------------------
    // applyPattern / toPattern
    // ------------------------------------------------------------------

    @Test
    public void testApplyPatternChangesBehaviour() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals("a", emf.format(new Object[] {"a"}));
        emf.applyPattern("[{0}]");
        assertEquals("[a]", emf.format(new Object[] {"a"}));
    }

    @Test
    public void testApplyPatternThrowsOnBadPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.applyPattern("{0");
            }
        });
    }

    @Test
    public void testToPatternReturnsNonNull() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertNotNull(emf.toPattern());
    }

    @Test
    public void testToPatternRoundTripIsFunctionallyEquivalent() {
        ExtendedMessageFormat original = new ExtendedMessageFormat("Hello, {0}! {1,number,integer}", Locale.US);
        String pattern = original.toPattern();
        ExtendedMessageFormat reconstructed = new ExtendedMessageFormat(pattern, Locale.US);
        Object[] args = {"World", Integer.valueOf(3)};
        assertEquals(original.format(args), reconstructed.format(args));
    }

    @Test
    public void testToPatternRoundTripWithRegistry() {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat original = new ExtendedMessageFormat("{0,upper}", registry);
        String pattern = original.toPattern();
        ExtendedMessageFormat reconstructed = new ExtendedMessageFormat(pattern, registry);
        assertEquals(original.format(new Object[] {"abc"}), reconstructed.format(new Object[] {"abc"}));
    }

    // ------------------------------------------------------------------
    // equals / hashCode
    // ------------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    public void testEqualsWithNullIsFalse() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
    }

    @Test
    public void testEqualsWithDifferentTypeIsFalse() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals("{0}"));
    }

    @Test
    public void testEqualsWithSamePatternAndLocaleIsTrue() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsWithDifferentPatternIsFalse() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0}!", Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsWithDifferentLocaleIsFalse() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0,number,currency}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0,number,currency}", Locale.FRANCE);
        assertFalse(a.equals(b));
    }

    // ------------------------------------------------------------------
    // Disabled mutator methods - always throw UnsupportedOperationException
    // ------------------------------------------------------------------

    @Test
    public void testSetFormatAlwaysThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.setFormat(0, NumberFormat.getInstance());
            }
        });
    }

    @Test
    public void testSetFormatThrowsEvenWithInvalidIndex() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.setFormat(-1, null);
            }
        });
    }

    @Test
    public void testSetFormatByArgumentIndexAlwaysThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.setFormatByArgumentIndex(0, NumberFormat.getInstance());
            }
        });
    }

    @Test
    public void testSetFormatsAlwaysThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.setFormats(new Format[] {NumberFormat.getInstance()});
            }
        });
    }

    @Test
    public void testSetFormatsThrowsEvenWithNullArray() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.setFormats(null);
            }
        });
    }

    @Test
    public void testSetFormatsByArgumentIndexAlwaysThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                emf.setFormatsByArgumentIndex(new Format[] {NumberFormat.getInstance()});
            }
        });
    }

    // ------------------------------------------------------------------
    // applyPattern is declared "public final" per javadoc
    // ------------------------------------------------------------------

    @Test
    public void testApplyPatternIsPublicFinal() throws Exception {
        Method method = ExtendedMessageFormat.class.getMethod("applyPattern", String.class);
        assertTrue(Modifier.isPublic(method.getModifiers()));
        assertTrue(Modifier.isFinal(method.getModifiers()));
        assertEquals(void.class, method.getReturnType());
    }

    @Test
    public void testExtendedMessageFormatIsAMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf instanceof java.text.MessageFormat);
    }
}
