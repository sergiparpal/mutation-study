/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @FunctionalInterface
    private interface Executable {
        void execute() throws Throwable;
    }

    private static void assertThrows(final Class<? extends Throwable> expectedType, final Executable executable) {
        try {
            executable.execute();
        } catch (final Throwable actual) {
            if (!expectedType.isInstance(actual)) {
                throw new AssertionError("Unexpected exception type: " + actual.getClass().getName(), actual);
            }
            return;
        }
        throw new AssertionError("Expected " + expectedType.getName() + " to be thrown, but nothing was thrown.");
    }

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("abc"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
    }

    @Test
    void testIsAllAnyNoneEmptyBlank() {
        assertTrue(StringUtils.isAllEmpty((CharSequence) null));
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "foo"));
        assertFalse(StringUtils.isAllEmpty("foo", "bar"));

        assertTrue(StringUtils.isAllBlank(null, " "));
        assertFalse(StringUtils.isAllBlank(" ", "bar"));

        assertTrue(StringUtils.isAnyEmpty((String) null));
        assertFalse(StringUtils.isAnyEmpty((String[]) null));
        assertTrue(StringUtils.isAnyEmpty(null, "foo"));
        assertFalse(StringUtils.isAnyEmpty("foo", "bar"));

        assertTrue(StringUtils.isAnyBlank("  bob  ", null));
        assertTrue(StringUtils.isAnyBlank(" ", "bar"));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));

        assertTrue(StringUtils.isNoneEmpty("foo", "bar"));
        assertFalse(StringUtils.isNoneEmpty("", "bar"));

        assertTrue(StringUtils.isNoneBlank("foo", "bar"));
        assertFalse(StringUtils.isNoneBlank("foo", " "));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(" \t\r\n\b "));
        assertEquals("abc", StringUtils.trim(" abc "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty(" \t\r\n\b "));

        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull(" \t\r\n\b "));

        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc"));
        assertEquals("abc", StringUtils.strip("abc  "));
        assertEquals("  abc", StringUtils.strip("  abcyx", "xyz"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));
        assertEquals("abc", StringUtils.stripToEmpty("  abc"));

        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull(" abc "));

        assertNull(StringUtils.stripStart(null, "*"));
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("abc  ", StringUtils.stripStart("yxabc  ", "xyz"));

        assertNull(StringUtils.stripEnd(null, "*"));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abcyx", "xyz"));

        assertArrayEquals(new String[] { "abc", "abc" }, StringUtils.stripAll(new String[] { "abc", "  abc" }, null));
    }

    @Test
    void testEqualsAndEqualsIgnoreCase() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "ABCD"));

        assertTrue(StringUtils.equalsAny("abc", "abc", "def"));
        assertFalse(StringUtils.equalsAny("abc", "def", "ghi"));
        assertFalse(StringUtils.equalsAny(null, "abc"));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "ABC", "def"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertEquals(0, StringUtils.compare(null, null, false));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);

        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.compareIgnoreCase("a", "b") < 0);
    }

    @Test
    void testIndexOfLastIndexOfOrdinal() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(4, StringUtils.lastIndexOf("aabaabaa", "ab"));

        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "ab", 1));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "ab", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "", 1));

        assertEquals(2, StringUtils.lastOrdinalIndexOf("aabaabaa", "b", 2));

        assertEquals(2, StringUtils.indexOfIgnoreCase("ABCDEF", "cde"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("ABCDEF", "xyz"));

        assertEquals(3, StringUtils.lastIndexOfIgnoreCase("ABCDEF", "DEF"));
    }

    @Test
    void testIndexOfAnyAndBut() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a', 'b'));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 'b', 'y'));
        assertEquals(-1, StringUtils.indexOfAny("aba", 'z'));

        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", "mn", "op"));

        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", 'z', 'a'));
        assertEquals(0, StringUtils.indexOfAnyBut("aba", 'z'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "x"));
        assertTrue(StringUtils.contains("abc", 'b'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));
        assertFalse(StringUtils.containsIgnoreCase(null, "b"));

        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("aba", 'z'));
        assertTrue(StringUtils.containsAny("abcd", "ab", "cd"));

        assertTrue(StringUtils.containsNone("abab", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsOnly("ab", 'z'));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));

        assertTrue(StringUtils.containsWhitespace("ab de fg"));
        assertFalse(StringUtils.containsWhitespace("abdefg"));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
        assertFalse(StringUtils.startsWithIgnoreCase("abcdef", "abcd "));

        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "def"));

        assertTrue(StringUtils.endsWith(null, null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));

        assertTrue(StringUtils.endsWithIgnoreCase("abcdef", "DEF"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "def"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abc", 10));

        assertEquals("c", StringUtils.substring("abc", -4, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertNull(StringUtils.substring(null, 0, 1));

        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "c"));
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertNull(StringUtils.substringAfter("abc", null));

        assertEquals("a", StringUtils.substringBefore("abc", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));

        assertEquals("abcb", StringUtils.substringBeforeLast("abcba", "a"));
        assertEquals("a", StringUtils.substringAfterLast("abc", "b"));

        assertEquals("bar", StringUtils.substringBetween("wx[bar]yz", "[", "]"));
        assertNull(StringUtils.substringBetween("abc", "1", "2"));
        assertEquals("bar", StringUtils.substringBetween("tagbartag", "tag"));

        assertArrayEquals(new String[] { "bar", "baz" }, StringUtils.substringsBetween("[bar][baz]", "[", "]"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   bat", StringUtils.leftPad("bat", 6));
        assertEquals("bat", StringUtils.leftPad("bat", 1));
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("bat   ", StringUtils.rightPad("bat", 6));
        assertEquals("bat", StringUtils.rightPad("bat", -1));
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));

        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    void testCapitalizeUncapitalizeSwapCaseReverse() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));

        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));
    }

    @Test
    void testIsAlphaNumericChecks() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric("  "));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("ab2c"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));

        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab1c"));

        assertTrue(StringUtils.isAlphanumericSpace("ab c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab-c"));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace(null));

        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace(" a "));
        assertFalse(StringUtils.isWhitespace(null));

        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
        assertFalse(StringUtils.isAsciiPrintable("Ceki Gülcü"));
        assertFalse(StringUtils.isAsciiPrintable(null));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));

        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    @Test
    void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ';'));
        assertEquals("", StringUtils.join(new Object[0], ';'));
        assertEquals("", StringUtils.join(new Object[] { null }, ';'));
        assertEquals("a;b;c", StringUtils.join(new Object[] { "a", "b", "c" }, ';'));
        assertEquals(";;a", StringUtils.join(new Object[] { null, "", "a" }, ';'));

        assertEquals("a--b--c", StringUtils.join(new Object[] { "a", "b", "c" }, "--", 0, 3));
        assertEquals("b--c", StringUtils.join(new Object[] { "a", "b", "c" }, "--", 1, 3));

        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c"), ','));

        final List<String> list = Arrays.asList("a", "b", "c", "d");
        assertEquals("b,c", StringUtils.join(list, ',', 1, 3));

        assertEquals("1;2;3", StringUtils.join(new int[] { 1, 2, 3 }, ';'));
        assertEquals("true,false", StringUtils.join(new boolean[] { true, false }, ','));

        assertEquals("x", StringUtils.joinWith(",", "x"));
        assertEquals("x,y", StringUtils.joinWith(",", "x", "y"));
    }

    @Test
    void testJoinWithNullArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertEquals(0, StringUtils.split("").length);
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc def"));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a..b.c", "."));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.split("ab:cd:ef", ":", 2));

        assertArrayEquals(new String[] { "a", "b", "c", "" }, StringUtils.splitPreserveAllTokens("a b c ", ' '));
        assertArrayEquals(new String[] { "", "a", "b", "c" }, StringUtils.splitPreserveAllTokens(" a b c", ' '));

        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.splitByWholeSeparator("ab:cd:ef", ":", 2));

        assertArrayEquals(new String[] { "ab", "", "", "de", "fg" }, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab   de fg", null));
    }

    @Test
    void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[0], StringUtils.splitByCharacterType(""));
        assertArrayEquals(new String[] { "number", "5" }, StringUtils.splitByCharacterType("number5"));
        assertArrayEquals(new String[] { "foo", "B", "ar" }, StringUtils.splitByCharacterType("fooBar"));

        assertArrayEquals(new String[] { "foo", "Bar" }, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] { "ASF", "Rules" }, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    void testReplaceAndRemove() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", "", "b"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
        assertEquals("b", StringUtils.replace("aba", "a", ""));

        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
        assertEquals("zbzz", StringUtils.replace("abaa", "a", "z", -1));

        assertEquals("foofoo", StringUtils.replaceOnce("barfoo", "bar", "foo"));

        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("queued", StringUtils.remove("queued", "zz"));

        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "xyz"));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".net"));

        assertEquals("qd", StringUtils.removeIgnoreCase("quEUed", "UE"));

        assertEquals("www.domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "xyz"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".COM"));
    }

    @Test
    void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
        assertEquals("ac", StringUtils.replaceChars("abc", 'b', 'c'));

        assertNull(StringUtils.replaceChars(null, "a", "b"));
        assertEquals("abc", StringUtils.replaceChars("abc", "", "x"));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", null));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yz"));
        assertEquals("ayya", StringUtils.replaceChars("abcba", "bc", "y"));
    }

    @Test
    void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] { "a" }, new String[] { "b" }));
        assertEquals("aba", StringUtils.replaceEach("aba", null, null));
        assertEquals("b", StringUtils.replaceEach("aba", new String[] { "a" }, new String[] { "" }));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] { "ab", "d" }, new String[] { "w", "t" }));
    }

    @Test
    void testReplaceEachInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abc", new String[] { "a" }, new String[] { "b", "c" });
            }
        });
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));

        assertEquals("", StringUtils.abbreviate("", "...", 4));
        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", ".", 7));
        assertEquals("ab..", StringUtils.abbreviate("abcdefg", "..", 4));
        assertEquals("a..", StringUtils.abbreviate("abcdefg", "..", 3));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", "..", 2);
            }
        });

        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("", StringUtils.chomp("\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));

        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("ababa", "aba"));
    }

    @Test
    void testDefaults() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));

        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfBlank(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfBlank("bat", "NULL"));
        assertNull(StringUtils.defaultIfBlank("", null));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
    }

    @Test
    void testDeleteWhitespaceDifference() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));

        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));
    }

    @Test
    void testGetCommonPrefixAndIndexOfDifference() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String) null));
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));

        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("abcde", "abxyz"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
    }

    @Test
    void testLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting"));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });

        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    @Test
    void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat((String) null, 2));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));

        assertEquals("", StringUtils.repeat('x', 0));
        assertEquals("xxx", StringUtils.repeat('x', 3));

        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c "));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("", StringUtils.wrap("", '"'));
        assertEquals("'ab'", StringUtils.wrap("ab", '\''));

        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("abc", StringUtils.unwrap("abc", '\''));
        assertNull(StringUtils.unwrap(null, '\''));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));

        assertEquals("'ab'", StringUtils.wrapIfMissing("ab", '\''));
        assertEquals("'ab'", StringUtils.wrapIfMissing("'ab'", '\''));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 0, 0));
        assertEquals("", StringUtils.truncate("", 0, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghijklmno", -1, 10);
            }
        });

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", 0, -1);
            }
        });

        assertEquals("abc", StringUtils.truncate("abc", 5));
        assertEquals("ab", StringUtils.truncate("abc", 2));
    }

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("", StringUtils.lowerCase(""));
        assertEquals("abc", StringUtils.lowerCase("aBc"));
    }

    @Test
    void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    void testFirstNonBlankEmpty() {
        assertNull(StringUtils.firstNonBlank());
        assertEquals("zz", StringUtils.firstNonBlank(null, "", " ", "zz"));
        assertNull(StringUtils.firstNonBlank(null, ""));

        assertNull(StringUtils.firstNonEmpty());
        assertEquals("zz", StringUtils.firstNonEmpty(null, "", "zz"));
        assertNull(StringUtils.firstNonEmpty(null, null));
    }

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] { 'a', 'b', 'c' }));
        assertEquals("", StringUtils.valueOf(new char[0]));
    }
}
