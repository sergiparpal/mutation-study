/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link BitField}.
 */
class BitFieldAgentTest {

    private static final BitField BF_MULTI = new BitField(0x3F80);
    private static final BitField BF_SINGLE = new BitField(0x4000);
    private static final BitField BF_ZERO = new BitField(0);

    @Test
    void testClearInt() {
        assertEquals(0, BF_MULTI.clear(0x3F80));
        assertEquals(~0x3F80, BF_MULTI.clear(-1));
        assertEquals(0, BF_SINGLE.clear(0x4000));
        assertEquals(-1, BF_ZERO.clear(-1));
    }

    @Test
    void testClearIntKeepsOtherBits() {
        final int holder = 0xFFFF;
        assertEquals(0xFFFF & ~0x3F80, BF_MULTI.clear(holder));
    }

    @Test
    void testClearLong() {
        final BitField bf = new BitField(0x3F80L);
        assertEquals(0L, bf.clear(0x3F80L));
        assertEquals(0xFFFFFFFFFFFFC07FL, bf.clear(-1L));
    }

    @Test
    void testClearByte() {
        final BitField bf = new BitField(0x40);
        final byte cleared = bf.clearByte((byte) 0x7F);
        assertEquals((byte) 0x3F, cleared);
        assertFalse(bf.isSet(cleared));
    }

    @Test
    void testClearShort() {
        final BitField bf = new BitField(0x4000);
        final short cleared = bf.clearShort((short) 0x7FFF);
        assertEquals((short) 0x3FFF, cleared);
        assertFalse(bf.isSet(cleared));
    }

    @Test
    void testGetRawValueInt() {
        assertEquals(0x3F80, BF_MULTI.getRawValue(0xFFFF));
        assertEquals(0, BF_MULTI.getRawValue(0x007F));
        assertEquals(0x4000, BF_SINGLE.getRawValue(0xFFFF));
    }

    @Test
    void testGetRawValueLong() {
        final BitField bf = new BitField(0x3F80_0000_0000_0000L);
        assertEquals(0x3F80_0000_0000_0000L, bf.getRawValue(-1L));
        assertEquals(0L, bf.getRawValue(0x007FL));
    }

    @Test
    void testGetShortRawValue() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 0x4000, bf.getShortRawValue((short) 0xFFFF));
    }

    @Test
    void testGetShortValue() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 1, bf.getShortValue((short) 0xFFFF));
    }

    @Test
    void testGetValueInt() {
        assertEquals(127, BF_MULTI.getValue(0xFFFF));
        assertEquals(0, BF_MULTI.getValue(0x007F));
        assertEquals(1, BF_SINGLE.getValue(0xFFFF));
        assertEquals(0, BF_SINGLE.getValue(0x3FFF));
    }

    @Test
    void testGetValueLong() {
        final BitField bf = new BitField(0x3F80L);
        assertEquals(127L, bf.getValue(0xFFFFL));
        assertEquals(0L, bf.getValue(0x007FL));
    }

    @Test
    void testZeroMaskGetValueReturnsZero() {
        assertEquals(0, BF_ZERO.getValue(0xFFFF));
        assertEquals(0, BF_ZERO.getRawValue(0xFFFF));
    }

    @Test
    void testIsAllSetInt() {
        assertFalse(BF_MULTI.isAllSet(0));
        for (int i = 0; i < 127; i++) {
            assertFalse(BF_MULTI.isAllSet(i << 7));
        }
        assertTrue(BF_MULTI.isAllSet(0x3F80));
        assertTrue(BF_MULTI.isAllSet(0xFFFF));
    }

    @Test
    void testIsAllSetLong() {
        final BitField bf = new BitField(0x3F80L);
        assertFalse(bf.isAllSet(0L));
        assertTrue(bf.isAllSet(0x3F80L));
        assertTrue(bf.isAllSet(-1L));
    }

    @Test
    void testIsAllSetZeroMask() {
        assertTrue(BF_ZERO.isAllSet(0));
        assertTrue(BF_ZERO.isAllSet(0xFFFF));
    }

    @Test
    void testIsSetInt() {
        assertFalse(BF_MULTI.isSet(0));
        assertTrue(BF_MULTI.isSet(0x3F80));
        assertTrue(BF_MULTI.isSet(0x0080));
        assertFalse(BF_SINGLE.isSet(0x3FFF));
        assertTrue(BF_SINGLE.isSet(0x4000));
    }

    @Test
    void testIsSetLong() {
        final BitField bf = new BitField(0x3F80L);
        assertFalse(bf.isSet(0L));
        assertTrue(bf.isSet(0x0080L));
    }

    @Test
    void testIsSetZeroMaskAlwaysFalse() {
        assertFalse(BF_ZERO.isSet(0));
        assertFalse(BF_ZERO.isSet(-1));
        assertFalse(BF_ZERO.isSet(0xFFFF));
    }

    @Test
    void testSetInt() {
        assertEquals(0x3F80, BF_MULTI.set(0));
        assertEquals(0xFFFF, BF_MULTI.set(0xFFFF));
        assertEquals(0x4000, BF_SINGLE.set(0));
    }

    @Test
    void testSetLong() {
        final BitField bf = new BitField(0x3F80L);
        assertEquals(0x3F80L, bf.set(0L));
        assertEquals(-1L, bf.set(-1L));
    }

    @Test
    void testSetBooleanInt() {
        assertEquals(0x4000, BF_SINGLE.setBoolean(0, true));
        assertEquals(0, BF_SINGLE.setBoolean(0x4000, false));
        assertEquals(0x3F80, BF_MULTI.setBoolean(0, true));
        assertEquals(0, BF_MULTI.setBoolean(0x3F80, false));
    }

    @Test
    void testSetBooleanLong() {
        final BitField bf = new BitField(0x4000L);
        assertEquals(0x4000L, bf.setBoolean(0L, true));
        assertEquals(0L, bf.setBoolean(0x4000L, false));
    }

    @Test
    void testSetByte() {
        final BitField bf = new BitField(0x40);
        assertEquals((byte) 0x40, bf.setByte((byte) 0));
        assertEquals((byte) 0x7F, bf.setByte((byte) 0x3F));
    }

    @Test
    void testSetByteBoolean() {
        final BitField bf = new BitField(0x40);
        assertEquals((byte) 0x40, bf.setByteBoolean((byte) 0, true));
        assertEquals((byte) 0, bf.setByteBoolean((byte) 0x40, false));
    }

    @Test
    void testSetShort() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 0x4000, bf.setShort((short) 0));
    }

    @Test
    void testSetShortBoolean() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 0x4000, bf.setShortBoolean((short) 0, true));
        assertEquals((short) 0, bf.setShortBoolean((short) 0x4000, false));
    }

    @Test
    void testSetShortValue() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 0x4000, bf.setShortValue((short) 0, (short) 1));
        assertEquals((short) 0, bf.setShortValue((short) 0x4000, (short) 0));
    }

    @Test
    void testSetValueInt() {
        assertEquals(0, BF_MULTI.setValue(0x3F80, 0));
        assertEquals(0x0100, BF_MULTI.setValue(0, 2));
        assertEquals(0x3F80, BF_MULTI.setValue(0, 127));
        final int value = BF_MULTI.setValue(0, 128);
        assertEquals(0, value);
    }

    @Test
    void testSetValuePreservesUnrelatedBits() {
        final int holder = 0xC07F;
        final int result = BF_MULTI.setValue(holder, 5);
        assertEquals(0xC2FF, result);
        assertEquals(0x007F, result & 0x007F);
        assertEquals(0xC000, result & 0xC000);
    }

    @Test
    void testSetValueLong() {
        final BitField bf = new BitField(0x3F80L);
        assertEquals(0L, bf.setValue(0x3F80L, 0L));
        assertEquals(0x0100L, bf.setValue(0L, 2L));
        assertEquals(0x3F80L, bf.setValue(0L, 127L));
    }

    @Test
    void testConstructorFromLongBeyondIntRange() {
        final BitField bf = new BitField(0x3F80_0000_0000_0000L);
        assertTrue(bf.isSet(0x3F80_0000_0000_0000L));
        assertFalse(bf.isSet(0L));
        assertEquals(127L, bf.getValue(-1L));
    }

    @Test
    void testZeroMaskShiftCountIsZero() {
        assertEquals(0, BF_ZERO.setValue(0, 5));
        assertEquals(5, BF_ZERO.setValue(5, 1));
    }
}
