package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.exception.CloneFailedException;
import org.junit.jupiter.api.Test;

public class ObjectUtilsAgentTest {

    private static class CloneableThing implements Cloneable {
        private final int value;

        CloneableThing(int value) {
            this.value = value;
        }

        int getValue() {
            return value;
        }

        @Override
        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

    private static class FailingCloneable implements Cloneable {
        @Override
        public Object clone() throws CloneNotSupportedException {
            throw new CloneNotSupportedException("cannot clone");
        }
    }

    private static class NotCloneable {
        // deliberately does not implement Cloneable
    }

    private static final class ConstSupplier<T> implements Supplier<T> {
        private final T value;
        private boolean called;

        ConstSupplier(T value) {
            this.value = value;
        }

        boolean wasCalled() {
            return called;
        }

        @Override
        public T get() {
            called = true;
            return value;
        }
    }

    private static final class ThrowingSupplier<T> implements Supplier<T> {
        @Override
        public T get() {
            throw new IllegalStateException("should not be called");
        }
    }

    // --- NULL field ---

    @Test
    public void testNullFieldIsNonNullSerializableSingleton() throws Exception {
        assertNotNull(ObjectUtils.NULL);
        assertTrue(ObjectUtils.NULL instanceof Serializable);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(ObjectUtils.NULL);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        Object deserialized = ois.readObject();
        ois.close();

        assertNotNull(deserialized);
        assertTrue(deserialized instanceof ObjectUtils.Null);
    }

    // --- allNotNull / allNull / anyNotNull / anyNull ---

    @Test
    public void testAllNotNull() {
        assertTrue(ObjectUtils.allNotNull());
        assertTrue(ObjectUtils.allNotNull("a"));
        assertTrue(ObjectUtils.allNotNull("a", "b"));
        assertFalse(ObjectUtils.allNotNull((Object[]) null));
        assertFalse(ObjectUtils.allNotNull((Object) null));
        assertFalse(ObjectUtils.allNotNull(null, null));
        assertFalse(ObjectUtils.allNotNull(null, "a"));
        assertFalse(ObjectUtils.allNotNull("a", null));
    }

    @Test
    public void testAllNull() {
        assertTrue(ObjectUtils.allNull());
        assertTrue(ObjectUtils.allNull((Object[]) null));
        assertTrue(ObjectUtils.allNull((Object) null));
        assertTrue(ObjectUtils.allNull(null, null));
        assertFalse(ObjectUtils.allNull("a"));
        assertFalse(ObjectUtils.allNull("a", null));
        assertFalse(ObjectUtils.allNull(null, "a"));
    }

    @Test
    public void testAnyNotNull() {
        assertFalse(ObjectUtils.anyNotNull());
        assertFalse(ObjectUtils.anyNotNull((Object[]) null));
        assertFalse(ObjectUtils.anyNotNull((Object) null));
        assertFalse(ObjectUtils.anyNotNull(null, null));
        assertTrue(ObjectUtils.anyNotNull("a"));
        assertTrue(ObjectUtils.anyNotNull("a", null));
        assertTrue(ObjectUtils.anyNotNull(null, "a"));
    }

    @Test
    public void testAnyNull() {
        assertFalse(ObjectUtils.anyNull());
        assertFalse(ObjectUtils.anyNull("a"));
        assertFalse(ObjectUtils.anyNull("a", "b"));
        assertTrue(ObjectUtils.anyNull((Object[]) null));
        assertTrue(ObjectUtils.anyNull((Object) null));
        assertTrue(ObjectUtils.anyNull(null, null));
        assertTrue(ObjectUtils.anyNull("a", null));
    }

    // --- clone / cloneIfPossible ---

    @Test
    public void testCloneNullReturnsNull() {
        assertNull(ObjectUtils.clone(null));
    }

    @Test
    public void testCloneNonCloneableReturnsNull() {
        NotCloneable thing = new NotCloneable();
        assertNull(ObjectUtils.clone(thing));
    }

    @Test
    public void testCloneCloneableReturnsDistinctEqualClone() {
        CloneableThing thing = new CloneableThing(42);
        CloneableThing clone = ObjectUtils.clone(thing);
        assertNotNull(clone);
        assertEquals(42, clone.getValue());
    }

    @Test
    public void testCloneCloneableThatFailsThrowsCloneFailedException() {
        FailingCloneable thing = new FailingCloneable();
        assertThrows(CloneFailedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.clone(thing);
            }
        });
    }

    @Test
    public void testCloneIfPossibleNullReturnsNull() {
        assertNull(ObjectUtils.cloneIfPossible(null));
    }

    @Test
    public void testCloneIfPossibleNonCloneableReturnsSameInstance() {
        NotCloneable thing = new NotCloneable();
        NotCloneable result = ObjectUtils.cloneIfPossible(thing);
        assertSame(thing, result);
    }

    @Test
    public void testCloneIfPossibleCloneableReturnsClone() {
        CloneableThing thing = new CloneableThing(7);
        CloneableThing result = ObjectUtils.cloneIfPossible(thing);
        assertNotNull(result);
        assertEquals(7, result.getValue());
    }

    @Test
    public void testCloneIfPossibleThatFailsThrowsCloneFailedException() {
        final FailingCloneable thing = new FailingCloneable();
        assertThrows(CloneFailedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.cloneIfPossible(thing);
            }
        });
    }

    // --- compare ---

    @Test
    public void testCompareTwoArg() {
        assertEquals(0, ObjectUtils.compare(null, null));
        assertTrue(ObjectUtils.compare(null, "a") < 0);
        assertTrue(ObjectUtils.compare("a", null) > 0);
        assertEquals(0, ObjectUtils.compare("a", "a"));
        assertTrue(ObjectUtils.compare("a", "b") < 0);
    }

    @Test
    public void testCompareThreeArgNullGreater() {
        assertTrue(ObjectUtils.compare(null, "a", true) > 0);
        assertTrue(ObjectUtils.compare("a", null, true) < 0);
        assertEquals(0, ObjectUtils.compare(null, null, true));
        assertTrue(ObjectUtils.compare(null, "a", false) < 0);
        assertTrue(ObjectUtils.compare("a", null, false) > 0);
    }

    // --- CONST ---

    @Test
    public void testConstOverloads() {
        assertTrue(ObjectUtils.CONST(true));
        assertFalse(ObjectUtils.CONST(false));
        assertEquals((byte) 5, ObjectUtils.CONST((byte) 5));
        assertEquals('a', ObjectUtils.CONST('a'));
        assertEquals(1.5d, ObjectUtils.CONST(1.5d), 0.0d);
        assertEquals(1.5f, ObjectUtils.CONST(1.5f), 0.0f);
        assertEquals(123, ObjectUtils.CONST(123));
        assertEquals(123L, ObjectUtils.CONST(123L));
        assertEquals((short) 123, ObjectUtils.CONST((short) 123));
        assertEquals("abc", ObjectUtils.CONST("abc"));
        assertNull(ObjectUtils.CONST((String) null));
    }

    @Test
    public void testConstByte() {
        assertEquals((byte) 127, ObjectUtils.CONST_BYTE(127));
        assertEquals((byte) -128, ObjectUtils.CONST_BYTE(-128));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(128);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(-129);
            }
        });
    }

    @Test
    public void testConstShort() {
        assertEquals((short) 32767, ObjectUtils.CONST_SHORT(32767));
        assertEquals((short) -32768, ObjectUtils.CONST_SHORT(-32768));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(32768);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(-32769);
            }
        });
    }

    // --- defaultIfNull (deprecated) ---

    @Test
    @SuppressWarnings("deprecation")
    public void testDefaultIfNull() {
        assertNull(ObjectUtils.defaultIfNull(null, null));
        assertEquals("", ObjectUtils.defaultIfNull(null, ""));
        assertEquals("zz", ObjectUtils.defaultIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.defaultIfNull("abc", "xx"));
    }

    // --- equals (deprecated) ---

    @Test
    @SuppressWarnings("deprecation")
    public void testEquals() {
        assertTrue(ObjectUtils.equals(null, null));
        assertFalse(ObjectUtils.equals(null, ""));
        assertFalse(ObjectUtils.equals("", null));
        assertTrue(ObjectUtils.equals("", ""));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, null));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, "true"));
        assertTrue(ObjectUtils.equals(Boolean.TRUE, Boolean.TRUE));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, Boolean.FALSE));
    }

    // --- firstNonNull ---

    @Test
    public void testFirstNonNull() {
        assertNull(ObjectUtils.firstNonNull());
        assertNull(ObjectUtils.firstNonNull((Object[]) null));
        assertNull(ObjectUtils.firstNonNull(null, null));
        assertEquals("", ObjectUtils.firstNonNull(null, ""));
        assertEquals("", ObjectUtils.firstNonNull(null, null, ""));
        assertEquals("zz", ObjectUtils.firstNonNull(null, "zz"));
        assertEquals("abc", ObjectUtils.firstNonNull("abc", "other"));
        assertEquals("xyz", ObjectUtils.firstNonNull(null, "xyz", "other"));
    }

    // --- getClass ---

    @Test
    public void testGetClass() {
        assertEquals(String.class, ObjectUtils.getClass("abc"));
        assertNull(ObjectUtils.<String>getClass(null));
    }

    // --- getFirstNonNull ---

    @Test
    public void testGetFirstNonNull() {
        assertNull(ObjectUtils.getFirstNonNull());

        ConstSupplier<String> first = new ConstSupplier<String>(null);
        ConstSupplier<String> second = new ConstSupplier<String>("");
        assertEquals("", ObjectUtils.getFirstNonNull(first, second));
        assertTrue(first.wasCalled());
        assertTrue(second.wasCalled());

        ConstSupplier<String> earlyNonNull = new ConstSupplier<String>("abc");
        ThrowingSupplier<String> shouldNotRun = new ThrowingSupplier<String>();
        assertEquals("abc", ObjectUtils.getFirstNonNull(earlyNonNull, shouldNotRun));

        assertEquals("zz", ObjectUtils.getFirstNonNull(null, new ConstSupplier<String>("zz")));
    }

    // --- getIfNull (Supplier variant) ---

    @Test
    public void testGetIfNullWithSupplier() {
        assertNull(ObjectUtils.getIfNull(null, (Supplier<Object>) null));

        ConstSupplier<String> nullSupplier = new ConstSupplier<String>(null);
        assertNull(ObjectUtils.getIfNull(null, nullSupplier));
        assertTrue(nullSupplier.wasCalled());

        ConstSupplier<String> zzSupplier = new ConstSupplier<String>("zz");
        assertEquals("zz", ObjectUtils.getIfNull(null, zzSupplier));

        ThrowingSupplier<String> shouldNotRun = new ThrowingSupplier<String>();
        assertEquals("abc", ObjectUtils.getIfNull("abc", shouldNotRun));
    }

    // --- getIfNull (value variant) ---

    @Test
    public void testGetIfNullWithValue() {
        assertNull(ObjectUtils.getIfNull(null, (String) null));
        assertEquals("", ObjectUtils.getIfNull(null, ""));
        assertEquals("zz", ObjectUtils.getIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.getIfNull("abc", "xx"));
    }

    // --- hashCode (deprecated) ---

    @Test
    @SuppressWarnings("deprecation")
    public void testHashCode() {
        assertEquals(0, ObjectUtils.hashCode(null));
        assertEquals("abc".hashCode(), ObjectUtils.hashCode("abc"));
    }

    // --- hashCodeHex ---

    @Test
    public void testHashCodeHex() {
        assertEquals(Integer.toHexString(0), ObjectUtils.hashCodeHex(null));
        Integer value = Integer.valueOf(42);
        assertEquals(Integer.toHexString(value.hashCode()), ObjectUtils.hashCodeHex(value));
    }

    // --- hashCodeMulti (deprecated) ---

    @Test
    @SuppressWarnings("deprecation")
    public void testHashCodeMulti() {
        assertEquals(1, ObjectUtils.hashCodeMulti());
        assertEquals(1, ObjectUtils.hashCodeMulti((Object[]) null));
        String a = "a";
        String b = "b";
        assertEquals(31 + a.hashCode(), ObjectUtils.hashCodeMulti(a));
        assertEquals((31 + a.hashCode()) * 31 + b.hashCode(), ObjectUtils.hashCodeMulti(a, b));
    }

    // --- identityHashCodeHex ---

    @Test
    public void testIdentityHashCodeHex() {
        Object obj = new Object();
        assertEquals(Integer.toHexString(System.identityHashCode(obj)), ObjectUtils.identityHashCodeHex(obj));
    }

    // --- identityToString(Object) ---

    @Test
    public void testIdentityToStringObject() {
        assertNull(ObjectUtils.identityToString(null));
        String value = "";
        String expected = value.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(value));
        assertEquals(expected, ObjectUtils.identityToString(value));
    }

    // --- identityToString(Appendable, Object) ---

    @Test
    public void testIdentityToStringAppendable() throws IOException {
        Object value = Boolean.TRUE;
        StringBuilder appendable = new StringBuilder();
        ObjectUtils.identityToString((Appendable) appendable, value);
        assertEquals(ObjectUtils.identityToString(value), appendable.toString());

        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.identityToString((Appendable) new StringBuilder(), null);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.identityToString((Appendable) null, "x");
            }
        });
    }

    // --- identityToString(StringBuffer, Object) ---

    @Test
    public void testIdentityToStringStringBuffer() {
        Object value = Boolean.TRUE;
        StringBuffer buffer = new StringBuffer();
        ObjectUtils.identityToString(buffer, value);
        assertEquals(ObjectUtils.identityToString(value), buffer.toString());

        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(new StringBuffer(), null);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString((StringBuffer) null, "x");
            }
        });
    }

    // --- identityToString(StringBuilder, Object) ---

    @Test
    public void testIdentityToStringStringBuilder() {
        Object value = Boolean.TRUE;
        StringBuilder builder = new StringBuilder();
        ObjectUtils.identityToString(builder, value);
        assertEquals(ObjectUtils.identityToString(value), builder.toString());

        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(new StringBuilder(), null);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString((StringBuilder) null, "x");
            }
        });
    }

    // --- isArray ---

    @Test
    public void testIsArray() {
        assertFalse(ObjectUtils.isArray(null));
        assertFalse(ObjectUtils.isArray(""));
        assertFalse(ObjectUtils.isArray("ab"));
        assertTrue(ObjectUtils.isArray(new int[]{}));
        assertTrue(ObjectUtils.isArray(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isArray(Integer.valueOf(1234)));
        assertTrue(ObjectUtils.isArray(new String[]{"a"}));
    }

    // --- isEmpty / isNotEmpty ---

    @Test
    public void testIsEmpty() {
        assertTrue(ObjectUtils.isEmpty(null));
        assertTrue(ObjectUtils.isEmpty(""));
        assertFalse(ObjectUtils.isEmpty("ab"));
        assertTrue(ObjectUtils.isEmpty(new int[]{}));
        assertFalse(ObjectUtils.isEmpty(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isEmpty(Integer.valueOf(1234)));
        assertFalse(ObjectUtils.isEmpty(Optional.of("")));
        assertTrue(ObjectUtils.isEmpty(Optional.empty()));
        assertTrue(ObjectUtils.isEmpty(Collections.emptyList()));
        List<String> list = new ArrayList<String>();
        list.add("a");
        assertFalse(ObjectUtils.isEmpty(list));
        assertTrue(ObjectUtils.isEmpty(Collections.emptyMap()));
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertFalse(ObjectUtils.isEmpty(map));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(ObjectUtils.isNotEmpty(null));
        assertFalse(ObjectUtils.isNotEmpty(""));
        assertTrue(ObjectUtils.isNotEmpty("ab"));
        assertFalse(ObjectUtils.isNotEmpty(new int[]{}));
        assertTrue(ObjectUtils.isNotEmpty(new int[]{1, 2, 3}));
        assertTrue(ObjectUtils.isNotEmpty(Integer.valueOf(1234)));
        assertTrue(ObjectUtils.isNotEmpty(Optional.of("")));
        assertFalse(ObjectUtils.isNotEmpty(Optional.empty()));
    }

    // --- max / min ---

    @Test
    public void testMax() {
        assertNull(ObjectUtils.max((Integer[]) null));
        assertNull(ObjectUtils.max((Integer) null, (Integer) null));
        assertEquals(Integer.valueOf(1), ObjectUtils.max(Integer.valueOf(1)));
        assertEquals(Integer.valueOf(2), ObjectUtils.max(Integer.valueOf(1), Integer.valueOf(2)));
        assertEquals(Integer.valueOf(2), ObjectUtils.max(Integer.valueOf(2), (Integer) null));
        assertEquals(Integer.valueOf(2), ObjectUtils.max((Integer) null, Integer.valueOf(2)));
        assertEquals(Integer.valueOf(3), ObjectUtils.max(Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(2)));
    }

    @Test
    public void testMin() {
        assertNull(ObjectUtils.min((Integer[]) null));
        assertNull(ObjectUtils.min((Integer) null, (Integer) null));
        assertEquals(Integer.valueOf(1), ObjectUtils.min(Integer.valueOf(1)));
        assertEquals(Integer.valueOf(1), ObjectUtils.min(Integer.valueOf(1), Integer.valueOf(2)));
        assertEquals(Integer.valueOf(2), ObjectUtils.min(Integer.valueOf(2), (Integer) null));
        assertEquals(Integer.valueOf(2), ObjectUtils.min((Integer) null, Integer.valueOf(2)));
        assertEquals(Integer.valueOf(1), ObjectUtils.min(Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(2)));
    }

    // --- median ---

    @Test
    public void testMedianVarargs() {
        assertEquals(Integer.valueOf(2),
                ObjectUtils.median(Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3)));
        assertEquals(Integer.valueOf(2), ObjectUtils.median(Integer.valueOf(1), Integer.valueOf(2),
                Integer.valueOf(3), Integer.valueOf(4)));

        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((Integer[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median();
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median(Integer.valueOf(1), null, Integer.valueOf(3));
            }
        });
    }

    @Test
    public void testMedianWithComparator() {
        Comparator<Integer> reverse = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o2.compareTo(o1);
            }
        };
        assertEquals(Integer.valueOf(2),
                ObjectUtils.median(reverse, Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3)));

        final Comparator<Integer> natural = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1.compareTo(o2);
            }
        };
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((Comparator<Integer>) null, Integer.valueOf(1));
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median(natural, new Integer[0]);
            }
        });
    }

    // --- mode ---

    @Test
    public void testMode() {
        assertNull(ObjectUtils.mode());
        assertEquals(Integer.valueOf(1), ObjectUtils.mode(Integer.valueOf(1)));
        assertEquals(Integer.valueOf(2),
                ObjectUtils.mode(Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(3)));
        assertNull(ObjectUtils.mode(Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2)));
    }

    // --- notEqual ---

    @Test
    public void testNotEqual() {
        assertFalse(ObjectUtils.notEqual(null, null));
        assertTrue(ObjectUtils.notEqual(null, ""));
        assertTrue(ObjectUtils.notEqual("", null));
        assertFalse(ObjectUtils.notEqual("", ""));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, null));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, "true"));
        assertFalse(ObjectUtils.notEqual(Boolean.TRUE, Boolean.TRUE));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, Boolean.FALSE));
    }

    // --- requireNonEmpty ---

    @Test
    public void testRequireNonEmptyOneArg() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("");
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty(Collections.emptyList());
            }
        });
    }

    @Test
    public void testRequireNonEmptyTwoArg() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc", "message"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null, "bar");
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("", "bar");
            }
        });
    }

    // --- toString(Object) ---

    @Test
    public void testToStringObject() {
        assertEquals("", ObjectUtils.toString(null));
        assertEquals("", ObjectUtils.toString(""));
        assertEquals("bat", ObjectUtils.toString("bat"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE));
    }

    // --- toString(Object, String) (deprecated) ---

    @Test
    @SuppressWarnings("deprecation")
    public void testToStringObjectWithNullStr() {
        assertNull(ObjectUtils.toString((Object) null, (String) null));
        assertEquals("null", ObjectUtils.toString((Object) null, "null"));
        assertEquals("", ObjectUtils.toString("", "null"));
        assertEquals("bat", ObjectUtils.toString("bat", "null"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE, "null"));
    }

    // --- toString(Supplier<Object>, Supplier<String>) ---

    @Test
    public void testToStringSupplierSupplier() {
        Supplier<Object> nullObjSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return null;
            }
        };
        ConstSupplier<String> fallback = new ConstSupplier<String>("fallback");
        assertEquals("fallback", ObjectUtils.toString(nullObjSupplier, fallback));
        assertTrue(fallback.wasCalled());

        Supplier<Object> batSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return "bat";
            }
        };
        ThrowingSupplier<String> shouldNotRun = new ThrowingSupplier<String>();
        assertEquals("bat", ObjectUtils.toString(batSupplier, shouldNotRun));
    }

    // --- toString(T, Supplier<String>) ---

    @Test
    public void testToStringObjectSupplier() {
        ConstSupplier<String> fallback = new ConstSupplier<String>("fallback");
        assertEquals("fallback", ObjectUtils.toString((Object) null, fallback));
        assertTrue(fallback.wasCalled());

        ThrowingSupplier<String> shouldNotRun = new ThrowingSupplier<String>();
        assertEquals("bat", ObjectUtils.toString("bat", shouldNotRun));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE, new ThrowingSupplier<String>()));
    }

    // --- wait ---

    @Test
    public void testWaitNegativeDurationThrowsIllegalArgumentException() {
        final Object lock = new Object();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.wait(lock, Duration.ofMillis(-1));
            }
        });
    }

    @Test
    public void testWaitWithoutMonitorOwnershipThrowsIllegalMonitorStateException() {
        final Object lock = new Object();
        assertThrows(IllegalMonitorStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.wait(lock, Duration.ofMillis(10));
            }
        });
    }

    @Test
    public void testWaitReturnsAfterNotify() throws InterruptedException {
        final Object lock = new Object();
        final boolean[] notified = new boolean[]{false};
        Thread notifier = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                synchronized (lock) {
                    notified[0] = true;
                    lock.notifyAll();
                }
            }
        });
        synchronized (lock) {
            notifier.start();
            try {
                ObjectUtils.wait(lock, Duration.ofSeconds(5));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        notifier.join();
        assertTrue(notified[0]);
    }
}
