/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private FastDatePrinter newPrinter(final String pattern) {
        return new FastDatePrinter(pattern, UTC, Locale.US);
    }

    private FastDatePrinter newPrinter(final String pattern, final TimeZone tz) {
        return new FastDatePrinter(pattern, tz, Locale.US);
    }

    @Test
    void testFormatDate_basicPattern() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JUNE, 15);
        assertEquals("2023-06-15", printer.format(cal.getTime()));
    }

    @Test
    void testFormatLong_millis() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss");
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("2023-01-01 00:00:00", printer.format(cal.getTimeInMillis()));
    }

    @Test
    void testEmptyPattern() {
        final FastDatePrinter printer = newPrinter("");
        assertEquals("", printer.format(new Date(0)));
        assertEquals(0, printer.getMaxLengthEstimate());
    }

    @Test
    void testLiteralOnlyPattern() {
        final FastDatePrinter printer = newPrinter("---");
        assertEquals("---", printer.format(new Date(0)));
        assertEquals(3, printer.getMaxLengthEstimate());
    }

    @Test
    void testGetMaxLengthEstimate() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        // 4 (yyyy) + 1 (-) + 2 (MM) + 1 (-) + 2 (dd) = 10
        assertEquals(10, printer.getMaxLengthEstimate());
        assertEquals(10, printer.format(new Date(0)).length());
    }

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        assertEquals("yyyy", printer.getPattern());
        assertEquals(Locale.US, printer.getLocale());
        assertEquals(UTC, printer.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        final TimeZone tz1 = printer.getTimeZone();
        final TimeZone tz2 = printer.getTimeZone();
        assertNotSame(tz1, tz2);
        assertEquals(tz1, tz2);
    }

    @Test
    void testConstructor_nullPattern_throwsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testConstructor_nullTimeZone_throwsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructor_nullLocale_usesDefault() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testIllegalPatternComponent_throwsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                newPrinter("q");
            }
        });
        assertTrue(ex.getMessage().contains("Illegal pattern component"));
    }

    @Test
    void testIso8601InvalidLength_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                newPrinter("XXXX");
            }
        });
    }

    @Test
    void testIso8601Pattern() {
        final TimeZone plusFive = TimeZone.getTimeZone("Etc/GMT-5");
        final FastDatePrinter utcPrinter = newPrinter("X", UTC);
        assertEquals("Z", utcPrinter.format(new Date(0)));

        final FastDatePrinter p1 = newPrinter("X", plusFive);
        final FastDatePrinter p2 = newPrinter("XX", plusFive);
        final FastDatePrinter p3 = newPrinter("XXX", plusFive);
        assertEquals("+05", p1.format(new Date(0)));
        assertEquals("+0500", p2.format(new Date(0)));
        assertEquals("+05:00", p3.format(new Date(0)));
    }

    @Test
    void testTimeZoneNumberPattern_Z() {
        final TimeZone plusFive = TimeZone.getTimeZone("Etc/GMT-5");
        assertEquals("+0000", newPrinter("Z", UTC).format(new Date(0)));
        // 'ZZ' uses the ISO8601 rule, which prints "Z" for a zero offset.
        assertEquals("Z", newPrinter("ZZ", UTC).format(new Date(0)));
        assertEquals("+00:00", newPrinter("ZZZ", UTC).format(new Date(0)));

        assertEquals("+0500", newPrinter("Z", plusFive).format(new Date(0)));
        assertEquals("+05:00", newPrinter("ZZ", plusFive).format(new Date(0)));
        assertEquals("+05:00", newPrinter("ZZZ", plusFive).format(new Date(0)));
    }

    @Test
    void testTwoDigitYear() {
        final FastDatePrinter printer = newPrinter("yy");
        assertEquals("00", printer.format(dateWithYear(2000)));
        assertEquals("05", printer.format(dateWithYear(2005)));
        assertEquals("98", printer.format(dateWithYear(1998)));
    }

    @Test
    void testFourDigitYear_smallValue() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 5);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        assertEquals("0005-01-01", printer.format(cal));
    }

    @Test
    void testFourDigitYear_largeValue() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 12345);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        assertEquals("12345-01-01", printer.format(cal));
    }

    @Test
    void testTwoDigitNumberField_overflowsPast99() {
        final FastDatePrinter printer = newPrinter("ss.SS");
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JANUARY, 1, 0, 0, 1);
        cal.set(Calendar.MILLISECOND, 150);
        // The "SS" field is a two-digit field, but millisecond values >= 100
        // are not truncated - they overflow past the nominal width.
        assertEquals("01.150", printer.format(cal));
    }

    @Test
    void testPaddedMillisecondField() {
        final FastDatePrinter printer = newPrinter("SSS");
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JANUARY, 1);
        cal.set(Calendar.MILLISECOND, 7);
        assertEquals("007", printer.format(cal));
    }

    @Test
    void testDayInWeekField_isoNumbering() {
        final FastDatePrinter printer = newPrinter("u");
        // 2024-01-01 is a Monday.
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.JANUARY, 1);
        assertEquals(Calendar.MONDAY, cal.get(Calendar.DAY_OF_WEEK));
        assertEquals("1", printer.format(cal));
    }

    @Test
    void testHourFields_atMidnight() {
        final Calendar midnight = new GregorianCalendar(UTC, Locale.US);
        midnight.clear();
        midnight.set(2023, Calendar.JANUARY, 1, 0, 0, 0);

        assertEquals("00", newPrinter("HH").format(midnight));
        assertEquals("24", newPrinter("kk").format(midnight));
        assertEquals("12", newPrinter("hh").format(midnight));
        assertEquals("0", newPrinter("K").format(midnight));
    }

    @Test
    void testHourFields_atNoon() {
        final Calendar noon = new GregorianCalendar(UTC, Locale.US);
        noon.clear();
        noon.set(2023, Calendar.JANUARY, 1, 12, 0, 0);

        assertEquals("12", newPrinter("HH").format(noon));
        assertEquals("12", newPrinter("kk").format(noon));
        assertEquals("12", newPrinter("hh").format(noon));
        assertEquals("0", newPrinter("K").format(noon));
    }

    @Test
    void testEraField_bcAndAd() {
        final FastDatePrinter printer = newPrinter("GG");

        final Calendar bc = new GregorianCalendar(UTC, Locale.US);
        bc.clear();
        bc.set(Calendar.ERA, GregorianCalendar.BC);
        bc.set(Calendar.YEAR, 1);
        bc.set(Calendar.MONTH, Calendar.JANUARY);
        bc.set(Calendar.DAY_OF_MONTH, 1);
        assertEquals("BC", printer.format(bc));

        final Calendar ad = new GregorianCalendar(UTC, Locale.US);
        ad.clear();
        ad.set(2023, Calendar.JANUARY, 1);
        assertEquals("AD", printer.format(ad));
    }

    @Test
    void testWeekYearField_negativeProleptic() {
        final FastDatePrinter printer = newPrinter("YYYY", UTC);
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.setMinimalDaysInFirstWeek(4);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.setWeekDate(-5, 1, Calendar.MONDAY);

        assertEquals(-5, cal.getWeekYear());
        assertEquals("-0005", printer.format(cal));
    }

    @Test
    void testTimeZoneNameField_notEmpty() {
        final FastDatePrinter shortName = newPrinter("z", UTC);
        final FastDatePrinter longName = newPrinter("zzzz", UTC);
        final String shortOut = shortName.format(new Date(0));
        final String longOut = longName.format(new Date(0));
        assertNotNull(shortOut);
        assertFalse(shortOut.isEmpty());
        assertNotNull(longOut);
        assertFalse(longOut.isEmpty());
    }

    @Test
    void testFormatCalendar_usesPrinterTimeZoneNotCalendarTimeZone() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss", UTC);
        final TimeZone ny = TimeZone.getTimeZone("America/New_York");
        final Calendar calInNy = new GregorianCalendar(ny, Locale.US);
        calInNy.setTimeInMillis(1_700_000_000_000L);

        final String viaCalendar = printer.format(calInNy);
        final String viaMillis = printer.format(1_700_000_000_000L);
        assertEquals(viaMillis, viaCalendar);
        // Original calendar must not be mutated by format(Calendar).
        assertEquals(ny, calInNy.getTimeZone());
    }

    @Test
    void testFormatCalendarStringBuffer_ignoresCalendarTimeZone() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss", UTC);
        final TimeZone ny = TimeZone.getTimeZone("America/New_York");
        final Calendar calInNy = new GregorianCalendar(ny, Locale.US);
        calInNy.setTimeInMillis(1_700_000_000_000L);

        final StringBuffer buf = new StringBuffer();
        final StringBuffer result = printer.format(calInNy, buf);
        assertEquals(printer.format(1_700_000_000_000L), result.toString());
        assertSame(buf, result);
    }

    @Test
    void testFormatCalendar_sameTimeZone_noMutation() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC);
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.MARCH, 10);
        final TimeZone before = cal.getTimeZone();
        assertEquals("2023-03-10", printer.format(cal));
        assertEquals(before, cal.getTimeZone());
    }

    @Test
    void testFormatObject_dispatchesByType() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC);
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.MARCH, 10);

        assertEquals(printer.format(cal.getTime()), printer.format((Object) cal.getTime()));
        assertEquals(printer.format(cal), printer.format((Object) cal));
        assertEquals(printer.format(cal.getTimeInMillis()), printer.format((Object) Long.valueOf(cal.getTimeInMillis())));
    }

    @Test
    void testFormatObject_unknownType_throwsIllegalArgumentException() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
    }

    @Test
    void testDeprecatedFormatObjectStringBufferFieldPosition() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC);
        final Date date = new Date(0);
        final StringBuffer buf = new StringBuffer();
        final StringBuffer result = printer.format((Object) date, buf, new FieldPosition(0));
        assertEquals(printer.format(date), result.toString());

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) "bogus", new StringBuffer(), new FieldPosition(0));
            }
        });
    }

    @Test
    void testEquals_and_hashCode() {
        final FastDatePrinter p1 = newPrinter("yyyy-MM-dd", UTC);
        final FastDatePrinter p2 = newPrinter("yyyy-MM-dd", UTC);
        final FastDatePrinter differentPattern = newPrinter("yyyy", UTC);
        final FastDatePrinter differentZone = newPrinter("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"));

        assertEquals(p1, p1);
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertFalse(p1.equals(differentPattern));
        assertFalse(p1.equals(differentZone));
        assertFalse(p1.equals("yyyy-MM-dd"));
        assertFalse(p1.equals(null));
    }

    @Test
    void testToString() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        assertEquals("FastDatePrinter[yyyy,en_US,UTC]", printer.toString());
    }

    @Test
    void testParseToken_singleRunOfLetters() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        final int[] indexRef = {0};
        final String token = printer.parseToken("aaab", indexRef);
        assertEquals("aaa", token);
        assertEquals(2, indexRef[0]);
    }

    @Test
    void testParseToken_singleDifferentLetters() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        final int[] indexRef = {0};
        final String token = printer.parseToken("ab", indexRef);
        assertEquals("a", token);
        assertEquals(0, indexRef[0]);
    }

    @Test
    void testParseToken_unquotedLiteral() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        final int[] indexRef = {0};
        final String token = printer.parseToken("-", indexRef);
        assertEquals("'-", token);
        assertEquals(1, indexRef[0]);
    }

    @Test
    void testParseToken_quotedLiteralWithEscapedQuote() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC);
        final int[] indexRef = {0};
        final String token = printer.parseToken("'a''b'", indexRef);
        assertEquals("'a'b", token);
        assertEquals(6, indexRef[0]);
    }

    @Test
    void testSerialization_roundTrip() throws Exception {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss.SSS", UTC);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(printer);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(printer, deserialized);
        assertEquals(printer.getPattern(), deserialized.getPattern());
        assertEquals(printer.getMaxLengthEstimate(), deserialized.getMaxLengthEstimate());

        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.MARCH, 10, 1, 2, 3);
        cal.set(Calendar.MILLISECOND, 456);
        assertEquals(printer.format(cal), deserialized.format(cal));
    }

    @Test
    void testClearTimeZoneDisplayCache_doesNotBreakFormatting() {
        final FastDatePrinter printer = newPrinter("zzzz", UTC);
        final String before = printer.format(new Date(0));
        FastDatePrinter.clear();
        final String after = printer.format(new Date(0));
        assertEquals(before, after);
    }

    @Test
    void testGetTimeZoneDisplay_cachesAndReturnsSameValue() {
        final String first = FastDatePrinter.getTimeZoneDisplay(UTC, false, TimeZone.LONG, Locale.US);
        final String second = FastDatePrinter.getTimeZoneDisplay(UTC, false, TimeZone.LONG, Locale.US);
        assertEquals(first, second);
        assertNotNull(first);
        assertFalse(first.isEmpty());
    }

    private static Date dateWithYear(final int year) {
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(year, Calendar.JANUARY, 1);
        return cal.getTime();
    }
}
