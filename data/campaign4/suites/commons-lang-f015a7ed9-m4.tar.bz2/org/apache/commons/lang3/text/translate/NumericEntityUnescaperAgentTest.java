/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetWithExplicitOptions() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("foo<bar", neu.translate("foo&#60;bar"));
    }

    @Test
    void testHexWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("foo<bar", neu.translate("foo&#x3c;bar"));
        assertEquals("foo<bar", neu.translate("foo&#X3C;bar"));
    }

    @Test
    void testSupplementaryCharacter() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final int codePoint = 0x1D7FF;
        final String expected = new String(Character.toChars(codePoint));
        assertEquals(expected, neu.translate("&#120831;"));
        assertEquals(2, expected.length());
    }

    @Test
    void testSemiColonRequiredFailsWhenMissing() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonRequired);
        assertEquals("foo&#60bar", neu.translate("foo&#60bar"));
    }

    @Test
    void testSemiColonOptionalSucceedsWhenMissing() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("foo<bar", neu.translate("foo&#60bar"));
    }

    @Test
    void testErrorIfNoSemiColonThrows() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                neu.translate("foo&#60bar");
            }
        });
    }

    @Test
    void testInvalidNumberFormatReturnsZeroConsumed() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#;", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testOutOfRangeCodePointReturnsZeroConsumed() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#99999999;", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testHexMarkerAloneReturnsZeroConsumed() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#x", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testNotAnEntityReturnsZeroConsumed() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        assertEquals(0, neu.translate("plain text", 0, writer));
        assertEquals("", writer.toString());

        final StringWriter writer2 = new StringWriter();
        assertEquals(0, neu.translate("&amp;", 0, writer2));
        assertEquals("", writer2.toString());
    }

    @Test
    void testTooShortInputNearEndReturnsZeroConsumed() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        // "&#" at the very end: index < seqEnd - 2 fails, so nothing is consumed.
        assertEquals(0, neu.translate("a&#", 1, writer));
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateReturnsConsumedLengthIncludingAmpersandHashAndSemiColon() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#60;", 0, writer);
        assertEquals(5, consumed);
        assertEquals("<", writer.toString());
    }

    @Test
    void testTranslateHexConsumedLengthIncludesXMarker() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#x3c;", 0, writer);
        assertEquals(6, consumed);
        assertEquals("<", writer.toString());
    }

    @Test
    void testIoExceptionPropagatedFromWriter() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final Writer failingWriter = new Writer() {
            @Override
            public void write(final char[] cbuf, final int off, final int len) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public void flush() throws IOException {
                // no-op
            }

            @Override
            public void close() throws IOException {
                // no-op
            }
        };
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                neu.translate("&#60;", 0, failingWriter);
            }
        });
    }
}
