/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty / isBlank / isNotBlank
    // ---------------------------------------------------------------

    @Test
    void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));
    }

    @Test
    void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank("  abc  "));
    }

    @Test
    void testIsNotBlank() {
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank("  "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    // ---------------------------------------------------------------
    // trim / strip
    // ---------------------------------------------------------------

    @Test
    void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    void testTrimToEmpty() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));
    }

    @Test
    void testTrimToNull() {
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));
    }

    @Test
    void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
        assertNull(StringUtils.strip(null, "x"));
    }

    // ---------------------------------------------------------------
    // equals / equalsIgnoreCase
    // ---------------------------------------------------------------

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
        assertTrue(StringUtils.equals(new StringBuilder("abc"), "abc"));
    }

    @Test
    void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abcd"));
    }

    // ---------------------------------------------------------------
    // indexOf family
    // ---------------------------------------------------------------

    @Test
    void testIndexOf() {
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOf(null, "a"));
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("abcabc", "c"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
    }

    @Test
    void testLastIndexOf() {
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.lastIndexOf(null, "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b", 4));
    }

    @Test
    void testIndexOfIgnoreCase() {
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));
    }

    // ---------------------------------------------------------------
    // contains family
    // ---------------------------------------------------------------

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertFalse(StringUtils.containsIgnoreCase("abc", null));
        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
    }

    @Test
    void testContainsAny() {
        assertFalse(StringUtils.containsAny(null, 'a', 'b'));
        assertFalse(StringUtils.containsAny("abc", new char[0]));
        assertTrue(StringUtils.containsAny("zzabyy", 'b'));
        assertFalse(StringUtils.containsAny("zzabyy", 'q'));
    }

    @Test
    void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(""));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("ab c"));
        assertFalse(StringUtils.containsWhitespace(null));
    }

    // ---------------------------------------------------------------
    // startsWith / endsWith
    // ---------------------------------------------------------------

    @Test
    void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    void testStartsWithIgnoreCase() {
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }

    @Test
    void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
    }

    // ---------------------------------------------------------------
    // substring family
    // ---------------------------------------------------------------

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));
    }

    @Test
    void testSubstringStartEnd() {
        assertNull(StringUtils.substring(null, 0, 1));
        assertEquals("", StringUtils.substring("abc", 2, 1));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("bc", StringUtils.substring("abc", -2, 3));
    }

    @Test
    void testSubstringBeforeAfter() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", null));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
        assertEquals("", StringUtils.substringAfter("abc", null));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
    }

    // ---------------------------------------------------------------
    // split
    // ---------------------------------------------------------------

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":"));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
    }

    @Test
    void testSplitPreserveAllTokens() {
        assertArrayEquals(new String[] {"a", "", "b"}, StringUtils.splitPreserveAllTokens("a..b", '.'));
    }

    // ---------------------------------------------------------------
    // join
    // ---------------------------------------------------------------

    @Test
    void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    void testJoinWithSeparatorString() {
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
    }

    @Test
    void testJoinIterable() {
        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c"), ','));
        assertNull(StringUtils.join((Iterable<?>) null, ','));
    }

    // ---------------------------------------------------------------
    // replace
    // ---------------------------------------------------------------

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "b"));
        assertEquals("abc", StringUtils.replace("abc", "a", null));
        assertEquals("bbb", StringUtils.replace("aba", "a", "b"));
        assertEquals("bbb", StringUtils.replace("aba", "a", "b", -1));
        assertEquals("bba", StringUtils.replace("aba", "a", "b", 1));
    }

    @Test
    void testReplaceOnce() {
        assertEquals("foobaa", StringUtils.replaceOnce("foobaabaa", "baa", ""));
    }

    @Test
    void testReplaceChars() {
        assertEquals("by", StringUtils.replaceChars("ay", 'a', 'b'));
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
    }

    // ---------------------------------------------------------------
    // remove
    // ---------------------------------------------------------------

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("abc", StringUtils.remove("abc", (String) null));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
    }

    @Test
    void testRemoveStartEnd() {
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertNull(StringUtils.removeStart(null, "a"));
    }

    // ---------------------------------------------------------------
    // pad / center
    // ---------------------------------------------------------------

    @Test
    void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));
    }

    @Test
    void testRightPad() {
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
    }

    // ---------------------------------------------------------------
    // case conversions
    // ---------------------------------------------------------------

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
    }

    @Test
    void testCapitalizeUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    // ---------------------------------------------------------------
    // repeat
    // ---------------------------------------------------------------

    @Test
    void testRepeatChar() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat('e', -2));
    }

    @Test
    void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat("ab", -1));
    }

    // ---------------------------------------------------------------
    // abbreviate
    // ---------------------------------------------------------------

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
    }

    @Test
    void testAbbreviateThrowsOnTooSmallWidth() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    // ---------------------------------------------------------------
    // truncate
    // ---------------------------------------------------------------

    @Test
    void testTruncate() {
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("", StringUtils.truncate("abcdefg", 0));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertNull(StringUtils.truncate(null, 10));
    }

    @Test
    void testTruncateNegativeMaxWidthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    void testTruncateNegativeOffsetThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1, 3);
            }
        });
    }

    // ---------------------------------------------------------------
    // defaultString / defaultIfEmpty / defaultIfBlank
    // ---------------------------------------------------------------

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
    }

    @Test
    void testDefaultIfEmpty() {
        assertEquals("default", StringUtils.defaultIfEmpty("", "default"));
        assertEquals("default", StringUtils.defaultIfEmpty(null, "default"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "default"));
    }

    @Test
    void testDefaultIfBlank() {
        assertEquals("default", StringUtils.defaultIfBlank("  ", "default"));
        assertEquals("default", StringUtils.defaultIfBlank(null, "default"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "default"));
    }

    // ---------------------------------------------------------------
    // isNumeric / isAlpha / isAlphanumeric
    // ---------------------------------------------------------------

    @Test
    void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("ab2c"));
        assertFalse(StringUtils.isNumeric("-123"));
    }

    @Test
    void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab c"));
    }

    @Test
    void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    // ---------------------------------------------------------------
    // compare
    // ---------------------------------------------------------------

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("abc", "abd") < 0);
    }

    @Test
    void testCompareNullIsLessFalse() {
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);
    }

    // ---------------------------------------------------------------
    // length / getBytes
    // ---------------------------------------------------------------

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testGetBytesWithCharset() {
        byte[] bytes = StringUtils.getBytes("abc", java.nio.charset.StandardCharsets.UTF_8);
        assertArrayEquals(new byte[] {'a', 'b', 'c'}, bytes);
        assertArrayEquals(new byte[0], StringUtils.getBytes(null, java.nio.charset.StandardCharsets.UTF_8));
    }

    // ---------------------------------------------------------------
    // countMatches
    // ---------------------------------------------------------------

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(2, StringUtils.countMatches("aaaa", "aa"));
    }

    // ---------------------------------------------------------------
    // wrap / unwrap
    // ---------------------------------------------------------------

    @Test
    void testWrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("'abc'", StringUtils.wrap("abc", '\''));
        assertEquals("xabcx", StringUtils.wrap("abc", 'x'));
    }

    @Test
    void testUnwrap() {
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("abc", StringUtils.unwrap("abc", 'x'));
    }

    // ---------------------------------------------------------------
    // ordinalIndexOf
    // ---------------------------------------------------------------

    @Test
    void testOrdinalIndexOf() {
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
    }

    // ---------------------------------------------------------------
    // constants / unmodifiable singletons
    // ---------------------------------------------------------------

    @Test
    void testConstants() {
        assertEquals("", StringUtils.EMPTY);
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }

    // ---------------------------------------------------------------
    // identity: same instance returned where documented
    // ---------------------------------------------------------------

    @Test
    void testTrimReturnsSameWhenNoChange() {
        String s = "abc";
        assertSame(s, StringUtils.trim(s));
    }

    @Test
    void testEqualsSameInstance() {
        String s = "abc";
        assertTrue(StringUtils.equals(s, s));
    }
}
