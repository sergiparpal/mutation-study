/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
class ExtendedMessageFormatAgentTest {

    /**
     * Simple {@link FormatFactory} that always returns the same fixed-text format,
     * regardless of arguments, so tests can detect that the custom format was used.
     */
    private static final class ConstantFormatFactory implements FormatFactory {
        private final String text;

        ConstantFormatFactory(final String text) {
            this.text = text;
        }

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new Format() {
                private static final long serialVersionUID = 1L;

                @Override
                public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
                    return toAppendTo.append(text);
                }

                @Override
                public Object parseObject(final String source, final java.text.ParsePosition pos) {
                    pos.setIndex(source.length());
                    return source;
                }
            };
        }
    }

    /**
     * Records the name/arguments/locale passed when the registry is consulted.
     */
    private static final class RecordingFormatFactory implements FormatFactory {
        String lastName;
        String lastArguments;
        Locale lastLocale;

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            lastName = name;
            lastArguments = arguments;
            lastLocale = locale;
            return new Format() {
                private static final long serialVersionUID = 1L;

                @Override
                public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
                    return toAppendTo.append(String.valueOf(obj));
                }

                @Override
                public Object parseObject(final String source, final java.text.ParsePosition pos) {
                    pos.setIndex(source.length());
                    return source;
                }
            };
        }
    }

    @Test
    void testSimplePatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] { "World" }));
    }

    @Test
    void testConstructorWithNullRegistryBehavesAsPlainMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, null);
        assertEquals("123", emf.format(new Object[] { 123 }));
        assertEquals("{0,number}", emf.toPattern());
    }

    @Test
    void testCustomFormatFromRegistryIsUsed() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new ConstantFormatFactory("CUSTOM"));
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("CUSTOM", emf.format(new Object[] { "ignored" }));
    }

    @Test
    void testToPatternReinsertsCustomFormatDescription() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new ConstantFormatFactory("X"));
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,style}", registry);
        assertEquals("{0,upper,style}", emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsBackToStandardMessageFormat() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new ConstantFormatFactory("X"));
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", registry);
        assertEquals("42", emf.format(new Object[] { 42 }));
        assertEquals("{0,number}", emf.toPattern());
    }

    @Test
    void testFormatFactoryReceivesNameArgumentsAndLocale() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        registry.put("custom", factory);
        new ExtendedMessageFormat("{0,custom, some args }", Locale.GERMANY, registry);
        assertEquals("custom", factory.lastName);
        assertEquals("some args", factory.lastArguments);
        assertEquals(Locale.GERMANY, factory.lastLocale);
    }

    @Test
    void testQuotedTextIsLiteralAndNotParsedAsFormatElement() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new ConstantFormatFactory("X"));
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s a '{0}' literal, {0,upper}", registry);
        final String result = emf.format(new Object[] { "val" });
        assertTrue(result.contains("{0}"), "Expected literal braces to remain, got: " + result);
        assertTrue(result.contains("X"), "Expected custom format output, got: " + result);
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", new HashMap<String, FormatFactory>());
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{abc}", new HashMap<String, FormatFactory>());
            }
        });
    }

    @Test
    void testUnterminatedQuoteTreatedAsClosedAtEndOfPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it has an 'unterminated quote");
        assertEquals("it has an unterminated quote", emf.format(new Object[0]));
    }

    @Test
    void testApplyPatternUpdatesToPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals("{0}", emf.toPattern());
        emf.applyPattern("{0} and {1}");
        assertEquals("{0} and {1}", emf.toPattern());
        assertEquals("a and b", emf.format(new Object[] { "a", "b" }));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[0]);
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[0]);
            }
        });
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(emf1.equals(emf2));
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsReturnsFalseForDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0} {1}", Locale.US);
        assertFalse(emf1.equals(emf2));
    }

    @Test
    void testEqualsReturnsFalseForDifferentRegistry() {
        final Map<String, FormatFactory> registry1 = new HashMap<>();
        registry1.put("upper", new ConstantFormatFactory("X"));
        final Map<String, FormatFactory> registry2 = new HashMap<>();
        registry2.put("upper", new ConstantFormatFactory("X"));
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", registry1);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,upper}", registry2);
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testEqualsReturnsFalseForNullAndOtherType() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("not a format"));
    }

    @Test
    void testParseRoundTripsFormattedOutput() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{1}", Locale.US);
        final Object[] args = { "foo", "bar" };
        final String formatted = emf.format(args);
        final Object[] parsed = emf.parse(formatted);
        assertEquals("foo", parsed[0]);
        assertEquals("bar", parsed[1]);
    }

    @Test
    void testChoiceFormatNestedBracesHandled() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#zero|1#one|2#{0,number} items}", Locale.US);
        assertEquals("zero", emf.format(new Object[] { 0 }));
        assertEquals("one", emf.format(new Object[] { 1 }));
    }
}
