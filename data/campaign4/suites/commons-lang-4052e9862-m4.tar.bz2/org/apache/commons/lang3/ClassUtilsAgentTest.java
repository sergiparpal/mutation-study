/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    interface AgentInterfaceA {
        // marker
    }

    interface AgentInterfaceB extends AgentInterfaceA {
        // marker
    }

    public interface AgentPublicInterface {
        void publicMethod();
    }

    static class AgentParent implements AgentInterfaceB {
        // empty
    }

    static class AgentChild extends AgentParent implements Serializable, AgentPublicInterface {
        private static final long serialVersionUID = 1L;

        @Override
        public void publicMethod() {
            // empty
        }
    }

    static class AgentOuter {
        class AgentInner {
            // empty
        }
    }

    // ---- comparator ----

    @Test
    void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>(Arrays.asList(String.class, Integer.class, Boolean.class));
        list.sort(ClassUtils.comparator());
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), list);
    }

    // ---- convertClassesToClassNames / convertClassNamesToClasses ----

    @Test
    void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    void testConvertClassesToClassNames() {
        final List<Class<?>> input = Arrays.asList(String.class, null, Integer.class);
        final List<String> names = ClassUtils.convertClassesToClassNames(input);
        assertEquals(Arrays.asList("java.lang.String", null, "java.lang.Integer"), names);
    }

    @Test
    void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    void testConvertClassNamesToClasses() {
        final List<String> input = Arrays.asList("java.lang.String", "not.a.real.ClassName", null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(input);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    // ---- getAbbreviatedName ----

    @Test
    void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 10));
    }

    @Test
    void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    void testGetAbbreviatedNameLengthHintNotPositiveThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    void testGetAbbreviatedNameVariousLengths() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 16));
    }

    // ---- getAllInterfaces ----

    @Test
    void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertTrue(interfaces.contains(AgentInterfaceA.class));
        assertTrue(interfaces.contains(AgentInterfaceB.class));
        assertTrue(interfaces.contains(Serializable.class));
        assertTrue(interfaces.contains(AgentPublicInterface.class));
        assertEquals(4, interfaces.size());
    }

    @Test
    void testGetAllInterfacesNoInterfaces() {
        assertTrue(ClassUtils.getAllInterfaces(Object.class).isEmpty());
    }

    // ---- getAllSuperclasses ----

    @Test
    void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclassesObject() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    @Test
    void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentParent.class, Object.class), superclasses);
    }

    // ---- getCanonicalName ----

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    void testGetCanonicalNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "NULL"));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    @Test
    void testGetCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang.Integer", ClassUtils.getCanonicalName(Integer.valueOf(1), "NULL"));
    }

    // ---- getClass ----

    @Test
    void testGetClassSimple() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    void testGetClassPrimitive() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
    }

    @Test
    void testGetClassArraySyntaxes() throws ClassNotFoundException {
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertEquals(int[].class, ClassUtils.getClass("int[]"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
    }

    @Test
    void testGetClassInnerClassDotSyntax() throws ClassNotFoundException {
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("this.does.not.Exist");
            }
        });
    }

    @Test
    void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassWithClassLoader() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", false));
    }

    // ---- getComponentType ----

    @Test
    void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // ---- getName ----

    @Test
    void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    void testGetNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "NULL"));
    }

    @Test
    void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
    }

    @Test
    void testGetNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
        assertEquals("java.lang.Integer", ClassUtils.getName(Integer.valueOf(1), "NULL"));
    }

    // ---- getPackageCanonicalName / getPackageName ----

    @Test
    void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
    }

    @Test
    void testGetPackageCanonicalNameObject() {
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(new String[0], "NULL"));
    }

    @Test
    void testGetPackageCanonicalNameString() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    void testGetPackageNameObject() {
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageName("hello", "NULL"));
    }

    @Test
    void testGetPackageNameStringEmptyAndNull() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
    }

    @Test
    void testGetPackageNameStringDefaultPackage() {
        assertEquals("", ClassUtils.getPackageName("NoPackageClassName"));
    }

    @Test
    void testGetPackageNameStringArrayEncoding() {
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    // ---- getPublicMethod ----

    @Test
    void testGetPublicMethod() throws Exception {
        final Method method = ClassUtils.getPublicMethod(AgentChild.class, "publicMethod");
        assertNotNull(method);
        assertEquals("publicMethod", method.getName());
    }

    @Test
    void testGetPublicMethodNotFoundThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(AgentChild.class, "noSuchMethod");
            }
        });
    }

    // ---- getShortCanonicalName ----

    @Test
    void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
    }

    @Test
    void testGetShortCanonicalNameObject() {
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hello", "NULL"));
    }

    @Test
    void testGetShortCanonicalNameString() {
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
    }

    // ---- getShortClassName ----

    @Test
    void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    void testGetShortClassNameClass() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
    }

    @Test
    void testGetShortClassNameInnerClass() {
        assertEquals("ClassUtilsAgentTest.AgentOuter.AgentInner", ClassUtils.getShortClassName(AgentOuter.AgentInner.class));
    }

    @Test
    void testGetShortClassNameObject() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "NULL"));
    }

    @Test
    void testGetShortClassNameStringNullAndEmpty() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    void testGetShortClassNameStringArrayAndInner() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    // ---- getSimpleName ----

    @Test
    void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    void testGetSimpleNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
    }

    @Test
    void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
    }

    @Test
    void testGetSimpleNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
    }

    // ---- hierarchy ----

    @Test
    void testHierarchyExcludeInterfaces() {
        final List<Class<?>> result = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class)) {
            result.add(c);
        }
        assertEquals(Arrays.asList(AgentChild.class, AgentParent.class, Object.class), result);
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final List<Class<?>> result = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class, Interfaces.INCLUDE)) {
            result.add(c);
        }
        assertTrue(result.contains(AgentChild.class));
        assertTrue(result.contains(AgentParent.class));
        assertTrue(result.contains(Object.class));
        assertTrue(result.contains(Serializable.class));
        assertTrue(result.contains(AgentInterfaceA.class));
        assertTrue(result.contains(AgentInterfaceB.class));
    }

    @Test
    void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> iterator = ClassUtils.hierarchy(AgentChild.class).iterator();
        assertTrue(iterator.hasNext());
        iterator.next();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                iterator.remove();
            }
        });
    }

    // ---- isAssignable ----

    @Test
    void testIsAssignableNulls() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
    }

    @Test
    void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
    }

    @Test
    void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    void testIsAssignableSameClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    void testIsAssignableArray() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { String.class, int.class }, new Class<?>[] { Object.class, Integer.class }));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { String.class }, new Class<?>[] { Object.class, Integer.class }));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    // ---- isInnerClass ----

    @Test
    void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(AgentOuter.AgentInner.class));
    }

    // ---- isPrimitiveOrWrapper / isPrimitiveWrapper ----

    @Test
    void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    // ---- isPublic ----

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentParent.class));
    }

    @Test
    void testIsPublicNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    // ---- primitivesToWrappers / primitiveToWrapper ----

    @Test
    void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    void testPrimitivesToWrappersEmpty() {
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
    }

    @Test
    void testPrimitivesToWrappers() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertArrayEquals(new Class<?>[] { Integer.class, String.class, null }, result);
    }

    @Test
    void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    // ---- toClass ----

    @Test
    void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    void testToClassEmpty() {
        assertEquals(0, ClassUtils.toClass().length);
    }

    @Test
    void testToClass() {
        final Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, result);
    }

    // ---- wrappersToPrimitives / wrapperToPrimitive ----

    @Test
    void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    void testWrappersToPrimitivesEmpty() {
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
    }

    @Test
    void testWrappersToPrimitives() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertArrayEquals(new Class<?>[] { int.class, null, null }, result);
    }

    @Test
    void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    // ---- constants / enum / constructor ----

    @Test
    void testConstants() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    @Test
    void testInterfacesEnum() {
        assertEquals(2, Interfaces.values().length);
        assertEquals(Interfaces.INCLUDE, Interfaces.valueOf("INCLUDE"));
        assertEquals(Interfaces.EXCLUDE, Interfaces.valueOf("EXCLUDE"));
    }

    @Test
    void testConstructor() {
        assertNotNull(new ClassUtils());
    }
}
