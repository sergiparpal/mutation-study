/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private interface AgentInterfaceA {
        // empty
    }

    private interface AgentInterfaceB extends AgentInterfaceA {
        // empty
    }

    private static class AgentBase implements AgentInterfaceB {
        // empty
    }

    private static class AgentChild extends AgentBase {
        // empty
    }

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        list.sort(ClassUtils.comparator());
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    @Test
    public void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<>();
        names.add("java.lang.String");
        names.add("not.a.real.ClassName");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameStringNullLengthPositive() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameLengthHintZeroOrNegativeThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", 0));
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", -1));
    }

    @Test
    public void testGetAbbreviatedNameVariousLengths() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 16));
    }

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfacesOfObject() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Object.class);
        assertTrue(interfaces.isEmpty());
    }

    @Test
    public void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertEquals(2, interfaces.size());
        assertTrue(interfaces.contains(AgentInterfaceA.class));
        assertTrue(interfaces.contains(AgentInterfaceB.class));
    }

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclassesOfObject() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    @Test
    public void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(2, superclasses.size());
        assertEquals(AgentBase.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    @Test
    public void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("X", ClassUtils.getCanonicalName((Class<?>) null, "X"));
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    public void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("X", ClassUtils.getCanonicalName((Object) null, "X"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    @Test
    public void testGetClassLoaderPrimitiveAndArray() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    public void testGetClassNullNameThrows() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getClass((String) null));
    }

    @Test
    public void testGetClassNotFoundThrows() {
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass("this.does.not.Exist"));
    }

    @Test
    public void testGetClassEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getClass(""));
    }

    @Test
    public void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("X", ClassUtils.getName((Class<?>) null, "X"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("X", ClassUtils.getName((Object) null, "X"));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObject() {
        assertEquals("X", ClassUtils.getPackageCanonicalName((Object) null, "X"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hi", "X"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObject() {
        assertEquals("X", ClassUtils.getPackageName((Object) null, "X"));
        assertEquals("java.lang", ClassUtils.getPackageName("hi", "X"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        final Method method = ClassUtils.getPublicMethod(String.class, "length");
        assertNotNull(method);
        assertEquals("length", method.getName());
    }

    @Test
    public void testGetPublicMethodNotFoundThrows() {
        assertThrows(NoSuchMethodException.class, () -> ClassUtils.getPublicMethod(String.class, "noSuchMethod"));
    }

    @Test
    public void testGetPublicMethodNullClassThrows() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getPublicMethod(null, "length"));
    }

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
    }

    @Test
    public void testGetShortCanonicalNameObject() {
        assertEquals("X", ClassUtils.getShortCanonicalName((Object) null, "X"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hi", "X"));
    }

    @Test
    public void testGetShortCanonicalNameString() {
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    @Test
    public void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("X", ClassUtils.getShortClassName((Object) null, "X"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "X"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("X", ClassUtils.getSimpleName((Class<?>) null, "X"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("X", ClassUtils.getSimpleName((Object) null, "X"));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    @Test
    public void testHierarchyExcludeInterfaces() {
        final List<Class<?>> result = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class)) {
            result.add(c);
        }
        assertEquals(Arrays.asList(AgentChild.class, AgentBase.class, Object.class), result);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> result = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE)) {
            result.add(c);
        }
        assertTrue(result.contains(AgentChild.class));
        assertTrue(result.contains(AgentBase.class));
        assertTrue(result.contains(AgentInterfaceA.class));
        assertTrue(result.contains(AgentInterfaceB.class));
        assertTrue(result.contains(Object.class));
    }

    @Test
    public void testHierarchyIteratorRemoveThrows() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    public void testIsAssignableNullCls() {
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
    }

    @Test
    public void testIsAssignableNullToClass() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, (Class<?>) null));
    }

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableSameClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignableArraysNullBothEmpty() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsAssignableArraysDifferentLength() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, Integer.class}));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {String.class, Integer.class}, new Class<?>[] {Object.class, Number.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class, Object.class}, new Class<?>[] {Object.class, String.class}));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
        assertTrue(ClassUtils.isInnerClass(AgentBase.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentBase.class));
    }

    @Test
    public void testIsPublicNullThrows() {
        assertThrows(NullPointerException.class, () -> ClassUtils.isPublic(null));
    }

    @Test
    public void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    public void testPrimitivesToWrappersEmpty() {
        final Class<?>[] empty = new Class<?>[0];
        assertArrayEquals(empty, ClassUtils.primitivesToWrappers());
    }

    @Test
    public void testPrimitivesToWrappers() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, null}, result);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        assertArrayEquals(new Class<?>[0], ClassUtils.toClass());
    }

    @Test
    public void testToClass() {
        final Class<?>[] result = ClassUtils.toClass("hi", 1, null);
        assertArrayEquals(new Class<?>[] {String.class, Integer.class, null}, result);
    }

    @Test
    public void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    public void testWrappersToPrimitivesEmpty() {
        assertArrayEquals(new Class<?>[0], ClassUtils.wrappersToPrimitives());
    }

    @Test
    public void testWrappersToPrimitives() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertArrayEquals(new Class<?>[] {int.class, null, null}, result);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new ClassUtils());
    }
}
