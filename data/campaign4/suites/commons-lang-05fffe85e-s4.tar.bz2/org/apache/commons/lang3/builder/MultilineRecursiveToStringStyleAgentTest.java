package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MultilineRecursiveToStringStyle}, based solely on the
 * documented contract (javadoc) of the class: it is a public, no-arg-constructible,
 * {@link Serializable} style that produces a multiline, recursive representation of an
 * object's fields, similar to {@code ToStringStyle.MULTI_LINE_STYLE}, as illustrated by the
 * Person/Job example in the class javadoc.
 */
class MultilineRecursiveToStringStyleAgentTest {

    /** Simple fixture with public fields so reflection-based recursion can see them regardless of access rules. */
    static class Nested {
        public String label = "lbl";
        public int number = 7;
    }

    /** Fixture with a nested object field, mirroring the Person/Job example from the class javadoc. */
    static class Outer {
        public String name = "Stephen";
        public int age = 29;
        public Nested job = new Nested();
    }

    private static final String LS = System.lineSeparator();

    // ---- Construction / type contract ----------------------------------------------------

    @Test
    void constructorCreatesUsableInstance() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        assertNotNull(style);
    }

    @Test
    void classImplementsSerializable() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        assertTrue(style instanceof Serializable, "Class javadoc states Serializable is implemented");
    }

    @Test
    void serializationRoundTripPreservesBehavior() throws IOException, ClassNotFoundException {
        MultilineRecursiveToStringStyle original = new MultilineRecursiveToStringStyle();

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bis);
        Object restoredObj = ois.readObject();
        ois.close();

        assertNotNull(restoredObj);
        assertTrue(restoredObj instanceof MultilineRecursiveToStringStyle);
        MultilineRecursiveToStringStyle restored = (MultilineRecursiveToStringStyle) restoredObj;

        StringBuffer bufOriginal = new StringBuffer();
        original.appendDetail(bufOriginal, "field", new int[] {100, 200, 300});

        StringBuffer bufRestored = new StringBuffer();
        restored.appendDetail(bufRestored, "field", new int[] {100, 200, 300});

        assertEquals(bufOriginal.toString(), bufRestored.toString(),
                "A deserialized instance must behave identically to the original");
    }

    // ---- appendDetail(StringBuffer, String, Object) ---------------------------------------

    @Test
    void appendDetailObjectAppendsSimpleValueRepresentation() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "count", Integer.valueOf(42));

        assertTrue(buffer.toString().contains("42"));
    }

    @Test
    void appendDetailObjectAppendsRatherThanReplacesBufferContent() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer("PREFIX-");

        style.appendDetail(buffer, "count", Integer.valueOf(1));

        assertTrue(buffer.toString().startsWith("PREFIX-"));
        assertTrue(buffer.length() > "PREFIX-".length());
    }

    @Test
    void appendDetailObjectRecursesIntoNestedObjectFields() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();
        Nested nested = new Nested();

        style.appendDetail(buffer, "nested", nested);
        String result = buffer.toString();

        // Per the class javadoc example (e.g. "job=Job@43cd2[ ... title=Manager ... ]"),
        // a nested object's own class name and its field=value pairs are rendered.
        assertTrue(result.contains("Nested@"), "Expected class-name@identity-hash prefix: " + result);
        assertTrue(result.contains("label=lbl"), "Expected field=value pair: " + result);
        assertTrue(result.contains("number=7"), "Expected field=value pair: " + result);
        assertTrue(result.indexOf('[') >= 0 && result.indexOf(']') > result.indexOf('['),
                "Expected bracketed content block: " + result);
        assertTrue(result.contains(LS), "Class javadoc states the style produces a multiline String: " + result);
    }

    @Test
    void appendDetailObjectRecursesThroughMultipleNestingLevels() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();
        Outer outer = new Outer();

        style.appendDetail(buffer, "outer", outer);
        String result = buffer.toString();

        assertTrue(result.contains("Outer@"));
        assertTrue(result.contains("name=Stephen"));
        assertTrue(result.contains("age=29"));
        assertTrue(result.contains("Nested@"));
        assertTrue(result.contains("label=lbl"));
        assertTrue(result.contains("number=7"));
    }

    @Test
    void appendDetailObjectFieldNameIsNotUsedInOutput() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer bufferA = new StringBuffer();
        StringBuffer bufferB = new StringBuffer();
        Nested nested = new Nested();

        style.appendDetail(bufferA, "fieldOne", nested);
        style.appendDetail(bufferB, "aCompletelyDifferentFieldName", nested);

        assertEquals(bufferA.toString(), bufferB.toString(),
                "Javadoc states fieldName is typically not used as already appended");
    }

    // ---- appendDetail(StringBuffer, String, <primitive array>) ----------------------------

    @Test
    void appendDetailBooleanArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "flags", new boolean[] {true, false});
        String result = buffer.toString();

        assertTrue(result.contains("true"));
        assertTrue(result.contains("false"));
    }

    @Test
    void appendDetailBooleanArrayEmptyArrayStillAppendsSomething() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "flags", new boolean[0]);

        assertTrue(buffer.length() > 0, "Even an empty array should produce start/end markers");
    }

    @Test
    void appendDetailByteArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "bytes", new byte[] {11, 22, 33});
        String result = buffer.toString();

        assertTrue(result.contains("11"));
        assertTrue(result.contains("22"));
        assertTrue(result.contains("33"));
        assertTrue(result.indexOf("11") < result.indexOf("22"));
        assertTrue(result.indexOf("22") < result.indexOf("33"));
    }

    @Test
    void appendDetailCharArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "chars", new char[] {'x', 'y', 'z'});
        String result = buffer.toString();

        assertTrue(result.indexOf('x') >= 0);
        assertTrue(result.indexOf('y') >= 0);
        assertTrue(result.indexOf('z') >= 0);
        assertTrue(result.indexOf('x') < result.indexOf('y'));
        assertTrue(result.indexOf('y') < result.indexOf('z'));
    }

    @Test
    void appendDetailDoubleArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "doubles", new double[] {1.5, 2.5});
        String result = buffer.toString();

        assertTrue(result.contains("1.5"));
        assertTrue(result.contains("2.5"));
        assertTrue(result.indexOf("1.5") < result.indexOf("2.5"));
    }

    @Test
    void appendDetailFloatArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "floats", new float[] {3.5f, 4.5f});
        String result = buffer.toString();

        assertTrue(result.contains("3.5"));
        assertTrue(result.contains("4.5"));
        assertTrue(result.indexOf("3.5") < result.indexOf("4.5"));
    }

    @Test
    void appendDetailIntArrayPreservesElementOrder() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "ints", new int[] {100, 200, 300});
        String result = buffer.toString();

        assertTrue(result.contains("100"));
        assertTrue(result.contains("200"));
        assertTrue(result.contains("300"));
        assertTrue(result.indexOf("100") < result.indexOf("200"));
        assertTrue(result.indexOf("200") < result.indexOf("300"));
    }

    @Test
    void appendDetailIntArrayMultipleElementsProducesMultilineOutput() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "ints", new int[] {1, 2, 3});

        assertTrue(buffer.toString().contains(LS),
                "Class javadoc states the overall style produces a multiline String");
    }

    @Test
    void appendDetailLongArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "longs", new long[] {123456789L, 987654321L});
        String result = buffer.toString();

        assertTrue(result.contains("123456789"));
        assertTrue(result.contains("987654321"));
        assertTrue(result.indexOf("123456789") < result.indexOf("987654321"));
    }

    @Test
    void appendDetailShortArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "shorts", new short[] {(short) 5, (short) 9});
        String result = buffer.toString();

        assertTrue(result.contains("5"));
        assertTrue(result.contains("9"));
        assertTrue(result.indexOf("5") < result.indexOf("9"));
    }

    @Test
    void appendDetailObjectArrayContainsElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "strings", new Object[] {"alpha", "beta"});
        String result = buffer.toString();

        assertTrue(result.contains("alpha"));
        assertTrue(result.contains("beta"));
        assertTrue(result.indexOf("alpha") < result.indexOf("beta"));
    }

    @Test
    void appendDetailArrayFieldNameIsNotUsedInOutput() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer bufferA = new StringBuffer();
        StringBuffer bufferB = new StringBuffer();
        int[] values = {7, 8, 9};

        style.appendDetail(bufferA, "fieldOne", values);
        style.appendDetail(bufferB, "aCompletelyDifferentFieldName", values);

        assertEquals(bufferA.toString(), bufferB.toString(),
                "Javadoc states fieldName is typically not used as already appended");
    }

    // ---- reflectionAppendArrayDetail(StringBuffer, String, Object) ------------------------

    @Test
    void reflectionAppendArrayDetailAppendsArrayElementRepresentations() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.reflectionAppendArrayDetail(buffer, "ints", new int[] {41, 42});
        String result = buffer.toString();

        assertTrue(result.contains("41"));
        assertTrue(result.contains("42"));
        assertTrue(result.indexOf("41") < result.indexOf("42"));
    }

    @Test
    void reflectionAppendArrayDetailOnEmptyArrayStillAppendsSomething() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.reflectionAppendArrayDetail(buffer, "ints", new int[0]);

        assertTrue(buffer.length() > 0, "Even an empty array should produce start/end markers");
    }

    @Test
    void reflectionAppendArrayDetailAppendsRatherThanReplacesBufferContent() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer("PREFIX-");

        style.reflectionAppendArrayDetail(buffer, "ints", new int[] {1});

        assertTrue(buffer.toString().startsWith("PREFIX-"));
        assertTrue(buffer.length() > "PREFIX-".length());
    }

    // ---- Instance statelessness across independent calls ----------------------------------

    @Test
    void sameStyleInstanceProducesIndependentResultsForDifferentBuffers() {
        MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        StringBuffer bufferA = new StringBuffer();
        StringBuffer bufferB = new StringBuffer();

        style.appendDetail(bufferA, "a", new int[] {1, 2});
        style.appendDetail(bufferB, "b", new int[] {3, 4});

        String resultA = bufferA.toString();
        String resultB = bufferB.toString();

        assertTrue(resultA.contains("1") && resultA.contains("2"));
        assertFalse(resultA.contains("3") || resultA.contains("4"));
        assertTrue(resultB.contains("3") && resultB.contains("4"));
        assertFalse(resultB.contains("1") || resultB.contains("2"));
    }
}
