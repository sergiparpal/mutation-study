package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RandomStringUtils}, based solely on the
 * documented contract in the generated javadoc.
 */
public class RandomStringUtilsAgentTest {

    private static boolean isAsciiPrintableRange(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c < 32 || c > 126) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAsciiGraphRange(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c < 33 || c > 126) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAsciiDigitsOnly(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

    private static boolean isLatinAlphabeticOnly(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            final boolean upper = c >= 'A' && c <= 'Z';
            final boolean lower = c >= 'a' && c <= 'z';
            if (!upper && !lower) {
                return false;
            }
        }
        return true;
    }

    private static boolean isLatinAlphanumericOnly(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            final boolean upper = c >= 'A' && c <= 'Z';
            final boolean lower = c >= 'a' && c <= 'z';
            final boolean digit = c >= '0' && c <= '9';
            if (!upper && !lower && !digit) {
                return false;
            }
        }
        return true;
    }

    private static boolean containsOnly(final String s, final char[] allowed) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            boolean found = false;
            for (int j = 0; j < allowed.length; j++) {
                if (allowed[j] == c) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    private static boolean onlyLettersOrDigits(final String s) {
        for (int i = 0; i < s.codePointCount(0, s.length()); i++) {
            final int cp = s.codePointAt(s.offsetByCodePoints(0, i));
            if (!Character.isLetter(cp) && !Character.isDigit(cp)) {
                return false;
            }
        }
        return true;
    }

    private static boolean onlyLetters(final String s) {
        for (int i = 0; i < s.codePointCount(0, s.length()); i++) {
            final int cp = s.codePointAt(s.offsetByCodePoints(0, i));
            if (!Character.isLetter(cp)) {
                return false;
            }
        }
        return true;
    }

    private static boolean onlyDigits(final String s) {
        for (int i = 0; i < s.codePointCount(0, s.length()); i++) {
            final int cp = s.codePointAt(s.offsetByCodePoints(0, i));
            if (!Character.isDigit(cp)) {
                return false;
            }
        }
        return true;
    }

    // ---------------------------------------------------------------
    // Constructor / toString
    // ---------------------------------------------------------------

    @Test
    public void testConstructorAndToString() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertNotNull(instance.toString());
    }

    // ---------------------------------------------------------------
    // secure() / secureStrong() / insecure() singletons
    // ---------------------------------------------------------------

    @Test
    public void testSecureIsSingleton() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testSecureStrongIsSingleton() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testInsecureIsSingleton() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertSame(a, b);
    }

    // ---------------------------------------------------------------
    // static random(int)
    // ---------------------------------------------------------------

    @Test
    public void testRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    public void testRandomCountLength() {
        assertEquals(10, RandomStringUtils.random(10).length());
    }

    @Test
    public void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    // ---------------------------------------------------------------
    // static random(int, boolean, boolean)
    // ---------------------------------------------------------------

    @Test
    public void testRandomLettersOnly() {
        final String s = RandomStringUtils.random(50, true, false);
        assertEquals(50, s.length());
        assertTrue(onlyLetters(s));
    }

    @Test
    public void testRandomNumbersOnly() {
        final String s = RandomStringUtils.random(50, false, true);
        assertEquals(50, s.length());
        assertTrue(onlyDigits(s));
    }

    @Test
    public void testRandomLettersAndNumbers() {
        final String s = RandomStringUtils.random(50, true, true);
        assertEquals(50, s.length());
        assertTrue(onlyLettersOrDigits(s));
    }

    @Test
    public void testRandomLettersNumbersNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, true, true);
            }
        });
    }

    // ---------------------------------------------------------------
    // static random(int, char...)
    // ---------------------------------------------------------------

    @Test
    public void testRandomCharsArray() {
        final char[] set = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(30, set);
        assertEquals(30, s.length());
        assertTrue(containsOnly(s, set));
    }

    @Test
    public void testRandomCharsArrayNullUsesAllChars() {
        final String s = RandomStringUtils.random(10, (char[]) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomCharsArrayNegativeCountThrows() {
        final char[] set = { 'a', 'b' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, set);
            }
        });
    }

    // ---------------------------------------------------------------
    // static random(int, String)
    // ---------------------------------------------------------------

    @Test
    public void testRandomStringChars() {
        final String s = RandomStringUtils.random(20, "ab");
        assertEquals(20, s.length());
        assertTrue(containsOnly(s, new char[] { 'a', 'b' }));
    }

    @Test
    public void testRandomStringCharsEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @Test
    public void testRandomStringCharsNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, "abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // static random(int, int, int, boolean, boolean)
    // ---------------------------------------------------------------

    @Test
    public void testRandomRangeLettersOnly() {
        final String s = RandomStringUtils.random(40, 0, 0, true, false);
        assertEquals(40, s.length());
        assertTrue(onlyLetters(s));
    }

    @Test
    public void testRandomRangeNumbersOnly() {
        final String s = RandomStringUtils.random(40, 0, 0, false, true);
        assertEquals(40, s.length());
        assertTrue(onlyDigits(s));
    }

    @Test
    public void testRandomRangeNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true);
            }
        });
    }

    // ---------------------------------------------------------------
    // static random(int, int, int, boolean, boolean, char...)
    // ---------------------------------------------------------------

    @Test
    public void testRandomRangeCharsArray() {
        final char[] set = { 'a', 'b', 'c' };
        final String s = RandomStringUtils.random(25, 0, 3, false, false, set);
        assertEquals(25, s.length());
        assertTrue(containsOnly(s, set));
    }

    @Test
    public void testRandomRangeCharsArrayOutOfBoundsThrows() {
        final char[] set = { 'a', 'b' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 2, 5, false, false, set);
            }
        });
    }

    @Test
    public void testRandomRangeCharsArrayNegativeCountThrows() {
        final char[] set = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 3, false, false, set);
            }
        });
    }

    // ---------------------------------------------------------------
    // static random(int, int, int, boolean, boolean, char[], Random) - master method
    // ---------------------------------------------------------------

    @Test
    public void testRandomMasterDeterministicWithSeededRandom() {
        final String s1 = RandomStringUtils.random(20, 0, 0, true, true, null, new Random(42));
        final String s2 = RandomStringUtils.random(20, 0, 0, true, true, null, new Random(42));
        assertEquals(s1, s2);
        assertEquals(20, s1.length());
    }

    @Test
    public void testRandomMasterWithCharsArray() {
        final char[] set = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(15, 0, 3, false, false, set, new Random(1));
        assertEquals(15, s.length());
        assertTrue(containsOnly(s, set));
    }

    @Test
    public void testRandomMasterZeroStartEndUsesPrintableAsciiWhenLettersAndNumbersFalse() {
        final String s = RandomStringUtils.random(30, 0, 0, false, false, null, new Random(7));
        assertEquals(30, s.length());
        assertTrue(isAsciiPrintableRange(s));
    }

    @Test
    public void testRandomMasterNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true, null, new Random());
            }
        });
    }

    @Test
    public void testRandomMasterEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 0, false, false, new char[0], new Random());
            }
        });
    }

    @Test
    public void testRandomMasterCharsArrayOutOfBoundsThrows() {
        final char[] set = { 'a', 'b' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 2, 5, false, false, set, new Random());
            }
        });
    }

    // ---------------------------------------------------------------
    // static randomAlphabetic / randomAlphanumeric / randomAscii / randomGraph /
    // randomNumeric / randomPrint - count based
    // ---------------------------------------------------------------

    @Test
    public void testRandomAlphabeticCount() {
        final String s = RandomStringUtils.randomAlphabetic(40);
        assertEquals(40, s.length());
        assertTrue(isLatinAlphabeticOnly(s));
    }

    @Test
    public void testRandomAlphabeticZero() {
        assertEquals("", RandomStringUtils.randomAlphabetic(0));
    }

    @Test
    public void testRandomAlphabeticNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(-1);
            }
        });
    }

    @Test
    public void testRandomAlphanumericCount() {
        final String s = RandomStringUtils.randomAlphanumeric(40);
        assertEquals(40, s.length());
        assertTrue(isLatinAlphanumericOnly(s));
    }

    @Test
    public void testRandomAlphanumericNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphanumeric(-1);
            }
        });
    }

    @Test
    public void testRandomAsciiCount() {
        final String s = RandomStringUtils.randomAscii(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiPrintableRange(s));
    }

    @Test
    public void testRandomAsciiNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAscii(-1);
            }
        });
    }

    @Test
    public void testRandomGraphCount() {
        final String s = RandomStringUtils.randomGraph(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiGraphRange(s));
    }

    @Test
    public void testRandomGraphNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomGraph(-1);
            }
        });
    }

    @Test
    public void testRandomNumericCount() {
        final String s = RandomStringUtils.randomNumeric(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiDigitsOnly(s));
    }

    @Test
    public void testRandomNumericNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomNumeric(-1);
            }
        });
    }

    @Test
    public void testRandomPrintCount() {
        final String s = RandomStringUtils.randomPrint(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiPrintableRange(s));
    }

    @Test
    public void testRandomPrintNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomPrint(-1);
            }
        });
    }

    // ---------------------------------------------------------------
    // static randomXxx(minLengthInclusive, maxLengthExclusive)
    // ---------------------------------------------------------------

    @Test
    public void testRandomAlphabeticRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isLatinAlphabeticOnly(s));
        }
    }

    @Test
    public void testRandomAlphabeticRangeDegenerateZero() {
        assertEquals("", RandomStringUtils.randomAlphabetic(0, 1));
    }

    @Test
    public void testRandomAlphanumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphanumeric(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isLatinAlphanumericOnly(s));
        }
    }

    @Test
    public void testRandomAsciiRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAscii(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiPrintableRange(s));
        }
    }

    @Test
    public void testRandomGraphRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomGraph(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiGraphRange(s));
        }
    }

    @Test
    public void testRandomNumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomNumeric(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiDigitsOnly(s));
        }
    }

    @Test
    public void testRandomPrintRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomPrint(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiPrintableRange(s));
        }
    }

    // ---------------------------------------------------------------
    // instance next(int) / next(int, boolean, boolean) / next(int, char...) /
    // next(int, String)
    // ---------------------------------------------------------------

    @Test
    public void testNextCountZero() {
        assertEquals("", RandomStringUtils.secure().next(0));
    }

    @Test
    public void testNextCountLength() {
        assertEquals(15, RandomStringUtils.secure().next(15).length());
    }

    @Test
    public void testNextNegativeCountThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1);
            }
        });
    }

    @Test
    public void testNextLettersOnly() {
        final String s = RandomStringUtils.insecure().next(50, true, false);
        assertEquals(50, s.length());
        assertTrue(onlyLetters(s));
    }

    @Test
    public void testNextNumbersOnly() {
        final String s = RandomStringUtils.insecure().next(50, false, true);
        assertEquals(50, s.length());
        assertTrue(onlyDigits(s));
    }

    @Test
    public void testNextLettersAndNumbersNegativeCountThrows() {
        final RandomStringUtils r = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, true, true);
            }
        });
    }

    @Test
    public void testNextCharsArray() {
        final char[] set = { '1', '2', '3' };
        final String s = RandomStringUtils.insecure().next(30, set);
        assertEquals(30, s.length());
        assertTrue(containsOnly(s, set));
    }

    @Test
    public void testNextCharsArrayNegativeCountThrows() {
        final char[] set = { '1', '2' };
        final RandomStringUtils r = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, set);
            }
        });
    }

    @Test
    public void testNextStringChars() {
        final String s = RandomStringUtils.insecure().next(20, "pq");
        assertEquals(20, s.length());
        assertTrue(containsOnly(s, new char[] { 'p', 'q' }));
    }

    @Test
    public void testNextStringCharsEmptyThrows() {
        final RandomStringUtils r = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(5, "");
            }
        });
    }

    // ---------------------------------------------------------------
    // instance next(int, int, int, boolean, boolean) / next(..., char...)
    // ---------------------------------------------------------------

    @Test
    public void testNextRangeLettersOnly() {
        final String s = RandomStringUtils.insecure().next(40, 0, 0, true, false);
        assertEquals(40, s.length());
        assertTrue(onlyLetters(s));
    }

    @Test
    public void testNextRangeNumbersOnly() {
        final String s = RandomStringUtils.insecure().next(40, 0, 0, false, true);
        assertEquals(40, s.length());
        assertTrue(onlyDigits(s));
    }

    @Test
    public void testNextRangeNegativeCountThrows() {
        final RandomStringUtils r = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, 0, 0, true, true);
            }
        });
    }

    @Test
    public void testNextRangeCharsArray() {
        final char[] set = { 'a', 'b', 'c' };
        final String s = RandomStringUtils.insecure().next(25, 0, 3, false, false, set);
        assertEquals(25, s.length());
        assertTrue(containsOnly(s, set));
    }

    @Test
    public void testNextRangeCharsArrayOutOfBoundsThrows() {
        final char[] set = { 'a', 'b' };
        final RandomStringUtils r = RandomStringUtils.insecure();
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                r.next(5, 2, 5, false, false, set);
            }
        });
    }

    @Test
    public void testNextRangeCharsArrayNegativeCountThrows() {
        final char[] set = { 'a', 'b', 'c' };
        final RandomStringUtils r = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, 0, 3, false, false, set);
            }
        });
    }

    // ---------------------------------------------------------------
    // instance nextAlphabetic / nextAlphanumeric / nextAscii / nextGraph /
    // nextNumeric / nextPrint - count based
    // ---------------------------------------------------------------

    @Test
    public void testNextAlphabeticCount() {
        final String s = RandomStringUtils.secure().nextAlphabetic(40);
        assertEquals(40, s.length());
        assertTrue(isLatinAlphabeticOnly(s));
    }

    @Test
    public void testNextAlphabeticZero() {
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0));
    }

    @Test
    public void testNextAlphabeticNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextAlphabetic(-1);
            }
        });
    }

    @Test
    public void testNextAlphanumericCount() {
        final String s = RandomStringUtils.secure().nextAlphanumeric(40);
        assertEquals(40, s.length());
        assertTrue(isLatinAlphanumericOnly(s));
    }

    @Test
    public void testNextAlphanumericNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextAlphanumeric(-1);
            }
        });
    }

    @Test
    public void testNextAsciiCount() {
        final String s = RandomStringUtils.secure().nextAscii(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiPrintableRange(s));
    }

    @Test
    public void testNextAsciiNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextAscii(-1);
            }
        });
    }

    @Test
    public void testNextGraphCount() {
        final String s = RandomStringUtils.secure().nextGraph(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiGraphRange(s));
    }

    @Test
    public void testNextGraphNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextGraph(-1);
            }
        });
    }

    @Test
    public void testNextNumericCount() {
        final String s = RandomStringUtils.secure().nextNumeric(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiDigitsOnly(s));
    }

    @Test
    public void testNextNumericNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextNumeric(-1);
            }
        });
    }

    @Test
    public void testNextPrintCount() {
        final String s = RandomStringUtils.secure().nextPrint(40);
        assertEquals(40, s.length());
        assertTrue(isAsciiPrintableRange(s));
    }

    @Test
    public void testNextPrintNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextPrint(-1);
            }
        });
    }

    // ---------------------------------------------------------------
    // instance nextXxx(minLengthInclusive, maxLengthExclusive)
    // ---------------------------------------------------------------

    @Test
    public void testNextAlphabeticRange() {
        final RandomStringUtils r = RandomStringUtils.secure();
        for (int i = 0; i < 20; i++) {
            final String s = r.nextAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isLatinAlphabeticOnly(s));
        }
    }

    @Test
    public void testNextAlphabeticRangeDegenerateZero() {
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0, 1));
    }

    @Test
    public void testNextAlphanumericRange() {
        final RandomStringUtils r = RandomStringUtils.secure();
        for (int i = 0; i < 20; i++) {
            final String s = r.nextAlphanumeric(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isLatinAlphanumericOnly(s));
        }
    }

    @Test
    public void testNextAsciiRange() {
        final RandomStringUtils r = RandomStringUtils.secure();
        for (int i = 0; i < 20; i++) {
            final String s = r.nextAscii(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiPrintableRange(s));
        }
    }

    @Test
    public void testNextGraphRange() {
        final RandomStringUtils r = RandomStringUtils.secure();
        for (int i = 0; i < 20; i++) {
            final String s = r.nextGraph(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiGraphRange(s));
        }
    }

    @Test
    public void testNextNumericRange() {
        final RandomStringUtils r = RandomStringUtils.secure();
        for (int i = 0; i < 20; i++) {
            final String s = r.nextNumeric(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiDigitsOnly(s));
        }
    }

    @Test
    public void testNextPrintRange() {
        final RandomStringUtils r = RandomStringUtils.secure();
        for (int i = 0; i < 20; i++) {
            final String s = r.nextPrint(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10);
            assertTrue(isAsciiPrintableRange(s));
        }
    }
}
