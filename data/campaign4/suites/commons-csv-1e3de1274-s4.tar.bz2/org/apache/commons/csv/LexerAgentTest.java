package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Lexer}, based on the documented contract in
 * the generated javadoc.
 */
public class LexerAgentTest {

    private static Lexer newLexer(final String input) {
        return new Lexer(CSVFormat.DEFAULT, new ExtendedBufferedReader(new StringReader(input)));
    }

    private static Lexer newLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    // --- close() / isClosed() ---------------------------------------------------

    @Test
    public void testIsClosedInitiallyFalse() {
        final Lexer lexer = newLexer("a,b,c");
        assertFalse(lexer.isClosed());
    }

    @Test
    public void testCloseMakesIsClosedTrue() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        lexer.close();
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    // --- getBytesRead() -----------------------------------------------------

    @Test
    public void testGetBytesReadInitiallyZero() {
        final Lexer lexer = newLexer("a,b,c");
        assertEquals(0, lexer.getBytesRead());
    }

    @Test
    public void testGetBytesReadIncreasesAfterReading() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        final Token token = new Token();
        lexer.nextToken(token);
        assertTrue(lexer.getBytesRead() > 0);
    }

    // --- getCharacterPosition() ----------------------------------------------

    @Test
    public void testGetCharacterPositionInitiallyZero() {
        final Lexer lexer = newLexer("a,b,c");
        assertEquals(0, lexer.getCharacterPosition());
    }

    @Test
    public void testGetCharacterPositionAdvances() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        final Token token = new Token();
        lexer.nextToken(token);
        assertTrue(lexer.getCharacterPosition() > 0);
    }

    // --- getCurrentLineNumber() -----------------------------------------------

    @Test
    public void testGetCurrentLineNumberInitiallyZero() {
        final Lexer lexer = newLexer("a,b,c\nd,e,f");
        assertEquals(0, lexer.getCurrentLineNumber());
    }

    @Test
    public void testGetCurrentLineNumberAdvancesAfterNewline() throws IOException {
        final Lexer lexer = newLexer("a,b\nc,d");
        final Token token = new Token();
        // Read through first record (a, b, end-of-record).
        lexer.nextToken(token);
        token.reset();
        lexer.nextToken(token);
        token.reset();
        lexer.nextToken(token);
        assertEquals(1, lexer.getCurrentLineNumber());
    }

    // --- getFirstEol() --------------------------------------------------------

    @Test
    public void testGetFirstEolInitiallyNull() {
        final Lexer lexer = newLexer("a,b,c");
        assertEquals(null, lexer.getFirstEol());
    }

    @Test
    public void testGetFirstEolCapturesLineFeed() throws IOException {
        final Lexer lexer = newLexer("a,b\nc,d");
        final Token token = new Token();
        Token.Type type = Token.Type.INVALID;
        while (type != Token.Type.EOF) {
            lexer.nextToken(token);
            type = token.type;
            token.reset();
        }
        assertEquals("\n", lexer.getFirstEol());
    }

    @Test
    public void testGetFirstEolCapturesCarriageReturnLineFeed() throws IOException {
        final Lexer lexer = newLexer("a,b\r\nc,d");
        final Token token = new Token();
        Token.Type type = Token.Type.INVALID;
        while (type != Token.Type.EOF) {
            lexer.nextToken(token);
            type = token.type;
            token.reset();
        }
        assertEquals("\r\n", lexer.getFirstEol());
    }

    // --- isCommentStart(int) --------------------------------------------------

    @Test
    public void testIsCommentStartTrueForConfiguredMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = newLexer(format, "a,b,c");
        assertTrue(lexer.isCommentStart('#'));
    }

    @Test
    public void testIsCommentStartFalseWhenNotConfigured() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    public void testIsCommentStartFalseForOtherCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = newLexer(format, "a,b,c");
        assertFalse(lexer.isCommentStart('x'));
    }

    // --- isDelimiter(int) -------------------------------------------------------

    @Test
    public void testIsDelimiterTrueForDelimiterCharacter() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        assertTrue(lexer.isDelimiter(','));
    }

    @Test
    public void testIsDelimiterFalseForNonDelimiterCharacter() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        assertFalse(lexer.isDelimiter('a'));
    }

    // --- isEndOfFile(int) -------------------------------------------------------

    @Test
    public void testIsEndOfFileTrueForMinusOne() {
        final Lexer lexer = newLexer("a,b,c");
        assertTrue(lexer.isEndOfFile(-1));
    }

    @Test
    public void testIsEndOfFileFalseForOrdinaryCharacter() {
        final Lexer lexer = newLexer("a,b,c");
        assertFalse(lexer.isEndOfFile('a'));
    }

    // --- isEscape(int) ------------------------------------------------------

    @Test
    public void testIsEscapeTrueForConfiguredEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = newLexer(format, "a,b,c");
        assertTrue(lexer.isEscape('\\'));
    }

    @Test
    public void testIsEscapeFalseWhenNotConfigured() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        assertFalse(lexer.isEscape('\\'));
    }

    // --- isEscapeDelimiter() -----------------------------------------------------

    @Test
    public void testIsEscapeDelimiterTrueWhenEscapedDelimiterFollows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('!').get();
        // Position the reader right after the escape character, looking at "!,".
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!!,"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read();
        assertTrue(lexer.isEscapeDelimiter());
    }

    @Test
    public void testIsEscapeDelimiterFalseWhenNotFollowedByDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!!x"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read();
        assertFalse(lexer.isEscapeDelimiter());
    }

    // --- isQuoteChar(int) -----------------------------------------------------

    @Test
    public void testIsQuoteCharTrueForConfiguredQuote() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        assertTrue(lexer.isQuoteChar('"'));
    }

    @Test
    public void testIsQuoteCharFalseWhenDisabled() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).get();
        final Lexer lexer = newLexer(format, "a,b,c");
        assertFalse(lexer.isQuoteChar('"'));
    }

    // --- isStartOfLine(int) -----------------------------------------------------

    @Test
    public void testIsStartOfLineTrueForLineFeed() {
        final Lexer lexer = newLexer("a,b,c");
        assertTrue(lexer.isStartOfLine('\n'));
    }

    @Test
    public void testIsStartOfLineTrueForCarriageReturn() {
        final Lexer lexer = newLexer("a,b,c");
        assertTrue(lexer.isStartOfLine('\r'));
    }

    @Test
    public void testIsStartOfLineTrueForEndOfFileSentinel() {
        final Lexer lexer = newLexer("a,b,c");
        assertTrue(lexer.isStartOfLine(-1));
    }

    @Test
    public void testIsStartOfLineFalseForOrdinaryCharacter() {
        final Lexer lexer = newLexer("a,b,c");
        assertFalse(lexer.isStartOfLine('a'));
    }

    // --- nextToken(Token) -----------------------------------------------------

    @Test
    public void testNextTokenSimpleFields() throws IOException {
        final Lexer lexer = newLexer("a,b,c");
        Token token = new Token();

        token = lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
    }

    @Test
    public void testNextTokenOnEmptyInputReturnsEof() throws IOException {
        final Lexer lexer = newLexer("");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    public void testNextTokenAfterEofKeepsReturningEof() throws IOException {
        final Lexer lexer = newLexer("a");
        Token token = new Token();

        token = lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    public void testNextTokenQuotedField() throws IOException {
        final Lexer lexer = newLexer("\"a,b\",c");
        Token token = new Token();

        token = lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());
        assertTrue(token.isQuoted);

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
        assertFalse(token.isQuoted);
    }

    @Test
    public void testNextTokenSkipsCommentLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = newLexer(format, "# a comment\na,b");
        Token token = new Token();

        token = lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token.reset();
        token = lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
    }

    @Test
    public void testNextTokenThrowsOnUnterminatedQuotedField() {
        final Lexer lexer = newLexer("\"a,b");
        final Token token = new Token();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
    }

    // --- readEndOfLine(int) -----------------------------------------------------

    @Test
    public void testReadEndOfLineTrueForLineFeed() throws IOException {
        final Lexer lexer = newLexer("\n");
        assertTrue(lexer.readEndOfLine('\n'));
    }

    @Test
    public void testReadEndOfLineTrueForCarriageReturn() throws IOException {
        final Lexer lexer = newLexer("");
        assertTrue(lexer.readEndOfLine('\r'));
    }

    @Test
    public void testReadEndOfLineFalseForOrdinaryCharacter() throws IOException {
        final Lexer lexer = newLexer("abc");
        assertFalse(lexer.readEndOfLine('a'));
    }

    @Test
    public void testReadEndOfLineConsumesCrLfPair() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\na"));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertTrue(lexer.readEndOfLine('\r'));
        // The trailing '\n' of the CRLF pair must have been consumed silently,
        // so the next character read is the one following the line terminator.
        assertEquals('a', reader.read());
    }

    // --- readEscape() -----------------------------------------------------

    @Test
    public void testReadEscapeTranslatesKnownSequences() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("n"));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertEquals('\n', lexer.readEscape());
    }

    @Test
    public void testReadEscapePassesThroughUnknownCharacter() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("x"));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertEquals('x', lexer.readEscape());
    }

    @Test
    public void testReadEscapeAtEndOfStreamThrows() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
    }

    // --- trimTrailingSpaces(StringBuilder) -----------------------------------

    @Test
    public void testTrimTrailingSpacesRemovesTrailingWhitespace() {
        final Lexer lexer = newLexer("a,b,c");
        final StringBuilder buffer = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("abc", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesLeavesNonTrailingWhitespaceAlone() {
        final Lexer lexer = newLexer("a,b,c");
        final StringBuilder buffer = new StringBuilder("  abc  ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("  abc", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesOnAllWhitespaceEmptiesBuffer() {
        final Lexer lexer = newLexer("a,b,c");
        final StringBuilder buffer = new StringBuilder("    ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesOnEmptyBufferStaysEmpty() {
        final Lexer lexer = newLexer("a,b,c");
        final StringBuilder buffer = new StringBuilder("");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }
}
