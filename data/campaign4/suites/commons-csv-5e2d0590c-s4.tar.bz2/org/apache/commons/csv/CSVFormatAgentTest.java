package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link CSVFormat} based solely on its published javadoc contract.
 */
public class CSVFormatAgentTest {

    private enum HeaderEnum {
        Name, Email, Phone
    }

    // -----------------------------------------------------------------
    // Class level contract
    // -----------------------------------------------------------------

    @Test
    public void testClassIsFinal() {
        assertTrue(Modifier.isFinal(CSVFormat.class.getModifiers()));
    }

    @Test
    public void testIsSerializable() {
        assertTrue(CSVFormat.DEFAULT instanceof java.io.Serializable);
    }

    @Test
    public void testBuilderImplementsSupplier() {
        assertTrue(CSVFormat.Builder.create() instanceof java.util.function.Supplier);
    }

    // -----------------------------------------------------------------
    // Predefined static formats
    // -----------------------------------------------------------------

    @Test
    public void testDefaultFormat() {
        CSVFormat f = CSVFormat.DEFAULT;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testExcelFormat() {
        CSVFormat f = CSVFormat.EXCEL;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
        assertFalse(f.getIgnoreEmptyLines());
        assertTrue(f.getAllowMissingColumnNames());
        assertTrue(f.getTrailingData());
        assertTrue(f.getLenientEof());
    }

    @Test
    public void testInformixUnloadFormat() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertFalse(f.isEscapeCharacterSet());
    }

    @Test
    public void testMongoDbCsvFormat() {
        CSVFormat f = CSVFormat.MONGODB_CSV;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFormat() {
        CSVFormat f = CSVFormat.MONGODB_TSV;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
        assertFalse(f.getSkipHeaderRecord());
    }

    @Test
    public void testMySqlFormat() {
        CSVFormat f = CSVFormat.MYSQL;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.isQuoteCharacterSet());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals("\\N", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testOracleFormat() {
        CSVFormat f = CSVFormat.ORACLE;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\\N", f.getNullString());
        assertTrue(f.getTrim());
        assertEquals(System.lineSeparator(), f.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testPostgresqlCsvFormat() {
        CSVFormat f = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", f.getDelimiterString());
        assertFalse(f.isEscapeCharacterSet());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals("", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testPostgresqlTextFormat() {
        CSVFormat f = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.isQuoteCharacterSet());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals("\\N", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testRfc4180Format() {
        CSVFormat f = CSVFormat.RFC4180;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfFormat() {
        CSVFormat f = CSVFormat.TDF;
        assertEquals("\t", f.getDelimiterString());
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    // -----------------------------------------------------------------
    // newFormat(char)
    // -----------------------------------------------------------------

    @Test
    public void testNewFormatBasic() {
        CSVFormat f = CSVFormat.newFormat(';');
        assertEquals(";", f.getDelimiterString());
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
        assertNull(f.getEscapeCharacter());
        assertFalse(f.isEscapeCharacterSet());
        assertNull(f.getCommentMarker());
        assertFalse(f.isCommentMarkerSet());
        assertNull(f.getHeader());
        assertNull(f.getNullString());
        assertFalse(f.isNullStringSet());
        assertFalse(f.getSkipHeaderRecord());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getIgnoreHeaderCase());
        assertFalse(f.getTrim());
        assertFalse(f.getTrailingDelimiter());
        assertFalse(f.getAutoFlush());
        assertFalse(f.getAllowMissingColumnNames());
        assertFalse(f.getLenientEof());
        assertFalse(f.getTrailingData());
        assertEquals(0L, f.getMaxRows());
        assertNull(f.getRecordSeparator());
        assertNull(f.getQuoteMode());
    }

    @Test
    public void testNewFormatRejectsLineFeedDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.newFormat('\n');
            }
        });
    }

    @Test
    public void testNewFormatRejectsCarriageReturnDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // -----------------------------------------------------------------
    // valueOf(String)
    // -----------------------------------------------------------------

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    public void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.valueOf("NOT_A_FORMAT");
            }
        });
    }

    @Test
    public void testValueOfNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.valueOf(null);
            }
        });
    }

    // -----------------------------------------------------------------
    // builder() / copy()
    // -----------------------------------------------------------------

    @Test
    public void testBuilderReturnsEquivalentFormat() {
        CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertNotNull(builder);
        assertEquals(CSVFormat.DEFAULT, builder.get());
    }

    @Test
    public void testCopyProducesEqualInstance() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @Test
    public void testStaticCopyNullSafe() {
        assertNull(CSVFormat.copy(null));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.copy(CSVFormat.DEFAULT));
    }

    @Test
    public void testCloneNullSafe() {
        assertNull(CSVFormat.clone((String[]) null));
        String[] arr = {"a", "b"};
        String[] cloned = CSVFormat.clone(arr);
        assertArrayEquals(arr, cloned);
        assertNotSame(arr, cloned);
    }

    // -----------------------------------------------------------------
    // equals()/hashCode()
    // -----------------------------------------------------------------

    @Test
    public void testEqualsAndHashCode() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
        assertEquals(CSVFormat.DEFAULT.hashCode(), CSVFormat.DEFAULT.hashCode());
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.EXCEL));
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
    }

    // -----------------------------------------------------------------
    // format(Object...)
    // -----------------------------------------------------------------

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format(new Object[] {"a", "b", "c"}));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format(new Object[] {"a,b", "c"}));
    }

    @Test
    public void testFormatNoValuesProducesEmptyString() {
        assertEquals("", CSVFormat.DEFAULT.format(new Object[] {}));
    }

    @Test
    public void testFormatNullValueWithoutNullString() {
        assertEquals(",b", CSVFormat.DEFAULT.format(new Object[] {null, "b"}));
    }

    @Test
    public void testFormatNullValueWithNullStringSet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL,b", f.format(new Object[] {null, "b"}));
    }

    // -----------------------------------------------------------------
    // header / headerComments defensive copies
    // -----------------------------------------------------------------

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader(new String[] {"a", "b"}).get();
        String[] h1 = f.getHeader();
        assertArrayEquals(new String[] {"a", "b"}, h1);
        h1[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, f.getHeader());
    }

    @Test
    public void testSetHeaderKeepsCopyOfInputArray() {
        String[] input = new String[] {"x", "y"};
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader(input).get();
        input[0] = "mutated";
        assertArrayEquals(new String[] {"x", "y"}, f.getHeader());
    }

    @Test
    public void testHeaderNullWhenDisabled() {
        assertNull(CSVFormat.newFormat(',').getHeader());
    }

    @Test
    public void testSetHeaderNullDisablesHeader() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader((String[]) null).get();
        assertNull(f.getHeader());
    }

    @Test
    public void testHeaderEmptyWhenParsedAutomatically() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader().get();
        assertArrayEquals(new String[0], f.getHeader());
    }

    @Test
    public void testSetHeaderFromEnumClass() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, f.getHeader());
    }

    @Test
    public void testGetHeaderCommentsDefensiveCopy() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setCommentMarker('#')
                .setHeaderComments(new Object[] {"c1", "c2"}).get();
        String[] hc1 = f.getHeaderComments();
        hc1[0] = "mutated";
        assertEquals("c1", f.getHeaderComments()[0]);
    }

    @Test
    public void testHeaderCommentsConvertedToStrings() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setCommentMarker('#')
                .setHeaderComments(new Object[] {"c1", Integer.valueOf(42)}).get();
        assertArrayEquals(new String[] {"c1", "42"}, f.getHeaderComments());
    }

    // -----------------------------------------------------------------
    // isXxxSet() / getXxxCharacter() boundary cases
    // -----------------------------------------------------------------

    @Test
    public void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.newFormat(',').isQuoteCharacterSet());
    }

    @Test
    public void testIsEscapeCharacterSet() {
        assertTrue(CSVFormat.MYSQL.isEscapeCharacterSet());
        assertFalse(CSVFormat.newFormat(',').isEscapeCharacterSet());
    }

    @Test
    public void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        CSVFormat f = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(f.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), f.getCommentMarker());
    }

    @Test
    public void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        CSVFormat f = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(f.isNullStringSet());
        assertEquals("NULL", f.getNullString());
    }

    @Test
    public void testGetEscapeCharDefaultZero() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
    }

    @Test
    public void testGetEscapeCharWhenSet() {
        assertEquals('\\', CSVFormat.MYSQL.getEscapeChar());
    }

    @Test
    public void testGetDelimiterCharArray() {
        assertArrayEquals(new char[] {','}, CSVFormat.DEFAULT.getDelimiterCharArray());
    }

    // -----------------------------------------------------------------
    // getMaxRows()/setMaxRows()
    // -----------------------------------------------------------------

    @Test
    public void testMaxRowsDefaultAndSetter() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        CSVFormat f = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, f.getMaxRows());
    }

    @Test
    public void testSetMaxRowsNegativeMeansNoLimitValue() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setMaxRows(-5L).get();
        assertEquals(-5L, f.getMaxRows());
    }

    // -----------------------------------------------------------------
    // Builder.create() / Builder.create(CSVFormat)
    // -----------------------------------------------------------------

    @Test
    public void testBuilderCreateDefaults() {
        CSVFormat f = CSVFormat.Builder.create().get();
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testBuilderCreateFromFormatCopiesSettings() {
        CSVFormat.Builder builder = CSVFormat.Builder.create(CSVFormat.MYSQL);
        assertEquals(CSVFormat.MYSQL, builder.get());
    }

    @Test
    public void testDeprecatedBuildEquivalentToGet() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertEquals(CSVFormat.Builder.create().get(), builder.build());
    }

    // -----------------------------------------------------------------
    // Builder fluent setters
    // -----------------------------------------------------------------

    @Test
    public void testBuilderFluentChainAppliesAllSettings() {
        CSVFormat f = CSVFormat.Builder.create()
                .setDelimiter(';')
                .setQuote('\'')
                .setRecordSeparator("\n")
                .setSkipHeaderRecord(true)
                .setTrim(true)
                .setNullString("NULL")
                .setAllowMissingColumnNames(true)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setTrailingDelimiter(true)
                .setAutoFlush(true)
                .setLenientEof(true)
                .setTrailingData(true)
                .get();
        assertEquals(";", f.getDelimiterString());
        assertEquals(Character.valueOf('\''), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertTrue(f.getSkipHeaderRecord());
        assertTrue(f.getTrim());
        assertEquals("NULL", f.getNullString());
        assertTrue(f.getAllowMissingColumnNames());
        assertTrue(f.getIgnoreHeaderCase());
        assertTrue(f.getIgnoreSurroundingSpaces());
        assertTrue(f.getTrailingDelimiter());
        assertTrue(f.getAutoFlush());
        assertTrue(f.getLenientEof());
        assertTrue(f.getTrailingData());
    }

    @Test
    public void testSetDelimiterStringForm() {
        CSVFormat f = CSVFormat.Builder.create().setDelimiter(";").get();
        assertEquals(";", f.getDelimiterString());
    }

    @Test
    public void testSetQuoteMode() {
        CSVFormat f = CSVFormat.Builder.create().setQuoteMode(QuoteMode.MINIMAL).get();
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testSetDuplicateHeaderMode() {
        CSVFormat f = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testSetAllowDuplicateHeaderNamesDeprecatedBuilder() {
        CSVFormat f = CSVFormat.Builder.create().setAllowDuplicateHeaderNames(true).get();
        assertTrue(f.getAllowDuplicateHeaderNames());
    }

    @Test
    public void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                builder.setDelimiter('\n');
            }
        });
    }

    @Test
    public void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                builder.setQuote('\r');
            }
        });
    }

    @Test
    public void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                builder.setEscape('\n');
            }
        });
    }

    @Test
    public void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                builder.setCommentMarker('\r');
            }
        });
    }

    // -----------------------------------------------------------------
    // Deprecated with*() methods
    // -----------------------------------------------------------------

    @Test
    public void testWithMethodsDoNotMutateOriginal() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat modified = original.withDelimiter(';');
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
    }

    @Test
    public void testWithDelimiterDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', f.getDelimiter());
        assertEquals(";", f.getDelimiterString());
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithQuoteDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), f.getQuoteCharacter());
    }

    @Test
    public void testWithQuoteCharacterNullDisables() {
        CSVFormat f = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
    }

    @Test
    public void testWithEscapeDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertTrue(f.isEscapeCharacterSet());
    }

    @Test
    public void testWithNullStringDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", f.getNullString());
        assertTrue(f.isNullStringSet());
    }

    @Test
    public void testWithTrimDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    public void testWithSkipHeaderRecordDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithIgnoreEmptyLinesDeprecated() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCaseDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
    }

    @Test
    public void testWithAllowMissingColumnNamesDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
    }

    @Test
    public void testWithHeaderDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader("a", "b", "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, f.getHeader());
    }

    @Test
    public void testWithHeaderEnumDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader(HeaderEnum.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, f.getHeader());
    }

    @Test
    public void testWithHeaderCommentsDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withHeaderComments(new Object[] {"hi"});
        assertArrayEquals(new String[] {"hi"}, f.getHeaderComments());
    }

    @Test
    public void testWithCommentMarkerDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), f.getCommentMarker());
        assertTrue(f.isCommentMarkerSet());
    }

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withCommentMarker('\n');
            }
        });
    }

    @Test
    public void testWithRecordSeparatorCharDeprecated() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorStringAcceptsCrLf() {
        assertEquals("\r\n", CSVFormat.DEFAULT.withRecordSeparator("\r\n").getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorStringRejectsInvalidValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withRecordSeparator("not-a-separator");
            }
        });
    }

    @Test
    public void testWithQuoteModeDeprecated() {
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL).getQuoteMode());
    }

    @Test
    public void testWithTrailingDelimiterDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
    }

    @Test
    public void testWithAutoFlushDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
    }

    @Test
    public void testWithSystemRecordSeparatorDeprecated() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    public void testWithFirstRecordAsHeaderDeprecated() {
        CSVFormat f = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], f.getHeader());
        assertTrue(f.getSkipHeaderRecord());
    }

    @Test
    public void testWithAllowDuplicateHeaderNamesDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
    }

    @Test
    public void testWithAllowDuplicateHeaderNamesBooleanDeprecated() {
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    // -----------------------------------------------------------------
    // print / println / printRecord / parse
    // -----------------------------------------------------------------

    @Test
    public void testPrintWritesHeaderToAppendable() throws IOException {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = f.print(sb);
        assertNotNull(printer);
        assertTrue(sb.toString().contains("col1"));
        assertTrue(sb.toString().contains("col2"));
    }

    @Test
    public void testPrintValueWritesEscapedOrPlainValue() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("hello", sb, true);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testPrintValueQuotesWhenContainsDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testPrintValueAddsDelimiterForSubsequentValues() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a", sb, true);
        CSVFormat.DEFAULT.print("b", sb, false);
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testPrintValueTrimsWhenTrimEnabled() throws IOException {
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrim(true).get();
        StringBuilder sb = new StringBuilder();
        f.print("  hello  ", sb, true);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        f.println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordWritesValuesAndSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, new Object[] {"a", "b", "c"});
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        StringReader reader = new StringReader("a,b,c\n");
        CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
    }

    // -----------------------------------------------------------------
    // toString()
    // -----------------------------------------------------------------

    @Test
    public void testToStringNotNullNorEmpty() {
        String s = CSVFormat.DEFAULT.toString();
        assertNotNull(s);
        assertFalse(s.isEmpty());
    }

    // -----------------------------------------------------------------
    // CSVFormat.Predefined
    // -----------------------------------------------------------------

    @Test
    public void testPredefinedValuesCount() {
        assertEquals(12, CSVFormat.Predefined.values().length);
    }

    @Test
    public void testPredefinedGetFormatMatchesStaticField() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertEquals(CSVFormat.ORACLE, CSVFormat.Predefined.Oracle.getFormat());
        assertEquals(CSVFormat.POSTGRESQL_CSV, CSVFormat.Predefined.PostgreSQLCsv.getFormat());
        assertEquals(CSVFormat.POSTGRESQL_TEXT, CSVFormat.Predefined.PostgreSQLText.getFormat());
        assertEquals(CSVFormat.MONGODB_CSV, CSVFormat.Predefined.MongoDBCsv.getFormat());
        assertEquals(CSVFormat.MONGODB_TSV, CSVFormat.Predefined.MongoDBTsv.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
    }

    @Test
    public void testPredefinedValueOf() {
        assertEquals(CSVFormat.Predefined.Default, CSVFormat.Predefined.valueOf("Default"));
    }

    @Test
    public void testPredefinedValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.Predefined.valueOf("NoSuchFormat");
            }
        });
    }

    @Test
    public void testPredefinedValueOfNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.Predefined.valueOf(null);
            }
        });
    }
}
