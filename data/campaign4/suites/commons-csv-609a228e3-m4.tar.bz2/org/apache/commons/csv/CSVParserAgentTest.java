/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
class CSVParserAgentTest {

    @Test
    void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseWithHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nAlice,30\nBob,25\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("name", parser.getHeaderNames().get(0));
            assertEquals("age", parser.getHeaderNames().get(1));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("Alice", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
            assertEquals("Bob", records.get(1).get("name"));
            assertEquals("25", records.get(1).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapReturnsCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("z", 99);
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse(map2.containsKey("z"));
            assertEquals(2, map2.size());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapNullWhenNoHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDuplicateHeaderNameThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,a\n1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").setAllowMissingColumnNames(true).get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("a", parser.getHeaderNames().get(0));
            assertEquals("", parser.getHeaderNames().get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorHasNextAndNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            final CSVRecord first = it.next();
            assertEquals("1", first.get(0));
            assertTrue(it.hasNext());
            final CSVRecord second = it.next();
            assertEquals("3", second.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorNextWithoutHasNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord r = it.next();
            assertEquals("1", r.get(0));
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testCloseMakesIteratorEmptyAndThrowOnNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    void testRecordNumberIncrementsAndStartsAtOne() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.iterator().next();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailingDelimiterDropsLastEmptyField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testQuotedEmptyFieldKeptWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\"\"\n", format);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertEquals("", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testNullStringHandling() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testCommentsAreCapturedOnRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("# a comment\na,b\n", format);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertTrue(record.hasComment());
            assertEquals("a comment", record.getComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderCommentCaptured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("# header comment\nname,age\nAlice,30\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoHeaderCommentWhenAbsent() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailerCommentCapturedAfterLastRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("a,b\n# trailer\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testStreamProducesSameRecordsAsIterator() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final long count = parser.stream().count();
            assertEquals(3, count);
        } finally {
            parser.close();
        }
    }

    @Test
    void testMaxRowsLimitsIteration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get(0));
            assertEquals("2", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetCurrentLineNumberAdvances() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.iterator().next();
            assertEquals(1, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidParseSequenceThrowsCSVException() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser0;
        try {
            parser0 = CSVParser.parse("a,\"b\"c\n", format);
        } catch (final IOException e) {
            throw new AssertionError(e);
        }
        final CSVParser parser = parser0;
        try {
            final java.io.UncheckedIOException thrown = assertThrows(java.io.UncheckedIOException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    parser.getRecords();
                }
            });
            assertTrue(thrown.getCause() instanceof CSVException);
        } finally {
            try {
                parser.close();
            } catch (final IOException e) {
                // ignore for test cleanup
            }
        }
    }

    @Test
    void testParseStringNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseFileNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.io.File) null, java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testBuilderWithReaderAndRecordNumberOffset() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(5)
                .get();
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(5, record.getRecordNumber());
            assertEquals(5, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDeprecatedConstructorWithOffsets() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\n"), CSVFormat.DEFAULT, 0, 3);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(3, record.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testIgnoreHeaderCaseMakesHeaderMapCaseInsensitive() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("Name", "Age").setIgnoreHeaderCase(true).setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nAlice,30\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertTrue(headerMap.containsKey("name"));
            assertTrue(headerMap.containsKey("NAME"));
        } finally {
            parser.close();
        }
    }
}
