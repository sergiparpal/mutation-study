package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link UnicodeUnescaper}, based on the documented
 * contract: it translates backslash-u style escapes back to Unicode,
 * supports multiple 'u' characters, and works with or without the '+'.
 * The translate method must return the number of code points consumed
 * at the given index, and may only throw IOException when the Writer does.
 */
public class UnicodeUnescaperAgentTest {

    /** A Writer that always fails, to verify IOException propagation from the Writer only. */
    private static class ThrowingWriter extends Writer {
        @Override
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public void flush() throws IOException {
            // no-op
        }

        @Override
        public void close() throws IOException {
            // no-op
        }
    }

    @Test
    public void testConstructor() {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        assertNotNull(unescaper);
    }

    @Test
    public void testBasicEscape() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\u0041", 0, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testEscapeWithPlus() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\u+0041", 0, out);
        assertEquals(7, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testEscapeWithMultipleU() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\uu0041", 0, out);
        assertEquals(7, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testEscapeWithMultipleUAndPlus() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\uuu+0041", 0, out);
        assertEquals(9, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testLowercaseHexDigits() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\uabcd", 0, out);
        assertEquals(6, consumed);
        assertEquals(String.valueOf((char) 0xabcd), out.toString());
    }

    @Test
    public void testUppercaseHexDigits() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\uFFFF", 0, out);
        assertEquals(6, consumed);
        assertEquals(String.valueOf((char) 0xFFFF), out.toString());
    }

    @Test
    public void testEscapeEmbeddedInLargerString() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        String input = "ab\\u0041cd";
        int consumed = unescaper.translate(input, 2, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    public void testNoBackslashReturnsZero() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("abc", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testBackslashNotFollowedByUReturnsZero() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\n", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testLoneBackslashAtEndOfStringReturnsZero() throws IOException {
        UnicodeUnescaper unescaper = new UnicodeUnescaper();
        StringWriter out = new StringWriter();
        int consumed = unescaper.translate("\\", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    public void testIncompleteHexDigitsThrows() {
        final UnicodeUnescaper unescaper = new UnicodeUnescaper();
        final StringWriter out = new StringWriter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("\\u12", 0, out);
            }
        });
    }

    @Test
    public void testInvalidHexDigitsThrows() {
        final UnicodeUnescaper unescaper = new UnicodeUnescaper();
        final StringWriter out = new StringWriter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("\\uZZZZ", 0, out);
            }
        });
    }

    @Test
    public void testWriterIOExceptionPropagates() {
        final UnicodeUnescaper unescaper = new UnicodeUnescaper();
        final Writer throwingWriter = new ThrowingWriter();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("\\u0041", 0, throwingWriter);
            }
        });
    }
}
