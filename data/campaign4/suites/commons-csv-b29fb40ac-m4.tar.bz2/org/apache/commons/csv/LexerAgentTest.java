/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testSimpleRecordWithoutTrailingNewline() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b,c");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.TOKEN, t1.type);
            assertEquals("a", t1.content.toString());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.TOKEN, t2.type);
            assertEquals("b", t2.content.toString());

            final Token t3 = new Token();
            lexer.nextToken(t3);
            assertEquals(Token.Type.EOF, t3.type);
            assertTrue(t3.isReady);
            assertEquals("c", t3.content.toString());

            final Token t4 = new Token();
            lexer.nextToken(t4);
            assertEquals(Token.Type.EOF, t4.type);
            assertFalse(t4.isReady);
            assertEquals("", t4.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCrLfRecordSeparator() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\r\nc,d\r\n");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.TOKEN, t1.type);
            assertEquals("a", t1.content.toString());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.EORECORD, t2.type);
            assertEquals("b", t2.content.toString());
            assertEquals(Constants.CRLF, lexer.getFirstEol());

            final Token t3 = new Token();
            lexer.nextToken(t3);
            assertEquals(Token.Type.TOKEN, t3.type);
            assertEquals("c", t3.content.toString());

            final Token t4 = new Token();
            lexer.nextToken(t4);
            assertEquals(Token.Type.EORECORD, t4.type);
            assertEquals("d", t4.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testFirstEolDetectionLfOnly() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "x\n");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("x", token.content.toString());
            assertEquals("\n", lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testFirstEolDetectionCrOnly() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "x\r");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("x", token.content.toString());
            assertEquals("\r", lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLeadingLine() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\r\na\r\n");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEmptyLineAtEndOfFileProducesEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\r\n\r\n");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.EORECORD, t1.type);
            assertEquals("a", t1.content.toString());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.EOF, t2.type);
            assertFalse(t2.isReady);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsLeadingAndTrailing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  ,b");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "# a comment \r\na,b\r\n");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.COMMENT, t1.type);
            assertEquals("a comment", t1.content.toString());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.TOKEN, t2.type);
            assertEquals("a", t2.content.toString());

            final Token t3 = new Token();
            lexer.nextToken(t3);
            assertEquals(Token.Type.EORECORD, t3.type);
            assertEquals("b", t3.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCommentMarkerWithNothingAfterItYieldsEof() throws IOException {
        // The comment marker is the very last character in the stream, so readLine() finds
        // nothing left to read and the lexer reports EOF rather than an (empty) comment.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "a\r\n#");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.EORECORD, t1.type);

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.EOF, t2.type);
            assertFalse(t2.isReady);
            assertEquals("", t2.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEncapsulatedTokenWithDoubledQuote() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\"b\"\r\n");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a\"b", token.content.toString());
            assertTrue(token.isQuoted);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEncapsulatedTokenEndingAtEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "\"a\\\"b\"");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("a\"b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEncapsulatedTokenEofBeforeClosingQuoteThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc");
        try {
            final Token token = new Token();
            final CSVException ex = assertThrows(CSVException.class, new ThrowingRunnable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(token);
                }
            });
            assertTrue(ex.getMessage().contains("EOF reached before encapsulated token finished"));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEncapsulatedTokenLenientEofDoesNotThrow() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"abc");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("abc", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testInvalidCharacterBetweenEncapsulatedTokenAndDelimiterThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc\"xyz,d");
        try {
            final Token token = new Token();
            final CSVException ex = assertThrows(CSVException.class, new ThrowingRunnable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(token);
                }
            });
            assertTrue(ex.getMessage().contains("Invalid character between encapsulated token and delimiter"));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrailingDataAppendsCharactersAfterClosingQuote() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"abc\"xyz,d");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("abcxyz", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEscapeStandardSequencesInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\tb\\nc,d");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a\tb\nc", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEscapeOfUnexpectedCharacterKeepsBothChars() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\xb,c");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a\\xb", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEscapeAtEofThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\");
        try {
            final Token token = new Token();
            final CSVException ex = assertThrows(CSVException.class, new ThrowingRunnable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(token);
                }
            });
            assertTrue(ex.getMessage().contains("EOF while processing escape sequence"));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeDirectlyForAllStandardSequences() throws IOException {
        assertEquals(Constants.CR, createLexerForEscape('r').readEscape());
        assertEquals(Constants.LF, createLexerForEscape('n').readEscape());
        assertEquals(Constants.TAB, createLexerForEscape('t').readEscape());
        assertEquals(Constants.BACKSPACE, createLexerForEscape('b').readEscape());
        assertEquals(Constants.FF, createLexerForEscape('f').readEscape());
    }

    private Lexer createLexerForEscape(final char next) {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        return createLexer(format, String.valueOf(next));
    }

    @Test
    void testReadEscapeOfMetaCharacterReturnsItself() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "\"");
        try {
            assertEquals('"', lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeOfUnexpectedCharacterReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "x");
        try {
            assertEquals(EOF, lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testMultiCharDelimiterWithEscapedDelimiterSequence() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("[|]").setEscape('!').get();
        final Lexer lexer = createLexer(format, "a![!|!]b");
        try {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("a[|]b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testMultiCharDelimiterSplitsTokens() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "a::b::c");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.TOKEN, t1.type);
            assertEquals("a", t1.content.toString());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.TOKEN, t2.type);
            assertEquals("b", t2.content.toString());

            final Token t3 = new Token();
            lexer.nextToken(t3);
            assertEquals(Token.Type.EOF, t3.type);
            assertTrue(t3.isReady);
            assertEquals("c", t3.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterDirectMultiCharMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("::xyz"));
        final Lexer lexer = new Lexer(format, reader);
        try {
            final int first = reader.read();
            assertEquals(':', first);
            assertTrue(lexer.isDelimiter(first));
            // Both delimiter characters were consumed; next char read is 'x'.
            assertEquals('x', reader.read());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterDirectMismatchDoesNotConsume() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(":x"));
        final Lexer lexer = new Lexer(format, reader);
        try {
            final int c = reader.read();
            assertEquals(':', c);
            assertFalse(lexer.isDelimiter(c));
            // Mismatch means the peeked character was not consumed.
            assertEquals('x', reader.read());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterDirectFirstCharMismatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        final Lexer lexer = new Lexer(format, reader);
        try {
            final int c = reader.read();
            assertEquals('a', c);
            assertFalse(lexer.isDelimiter(c));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterDirectSingleCharDelimiter() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(",x"));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        try {
            final int c = reader.read();
            assertEquals(',', c);
            assertTrue(lexer.isDelimiter(c));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testPredicateHelpers() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "");
        try {
            assertTrue(lexer.isEscape('\\'));
            assertFalse(lexer.isEscape('a'));
            assertTrue(lexer.isQuoteChar('"'));
            assertFalse(lexer.isQuoteChar('\''));
            assertTrue(lexer.isCommentStart('#'));
            assertFalse(lexer.isCommentStart('a'));
            assertTrue(lexer.isEndOfFile(EOF));
            assertFalse(lexer.isEndOfFile('a'));
            assertTrue(lexer.isStartOfLine(Constants.LF));
            assertTrue(lexer.isStartOfLine(Constants.CR));
            assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
            assertFalse(lexer.isStartOfLine('a'));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        try {
            final StringBuilder withTrailing = new StringBuilder("abc   ");
            lexer.trimTrailingSpaces(withTrailing);
            assertEquals("abc", withTrailing.toString());

            final StringBuilder allWhitespace = new StringBuilder("   ");
            lexer.trimTrailingSpaces(allWhitespace);
            assertEquals("", allWhitespace.toString());

            final StringBuilder noTrailing = new StringBuilder("abc");
            lexer.trimTrailingSpaces(noTrailing);
            assertEquals("abc", noTrailing.toString());

            final StringBuilder empty = new StringBuilder("");
            lexer.trimTrailingSpaces(empty);
            assertEquals("", empty.toString());
        } finally {
            closeQuietly(lexer);
        }
    }

    private void closeQuietly(final Lexer lexer) {
        try {
            lexer.close();
        } catch (final IOException e) {
            // ignore for test cleanup
        }
    }

    @Test
    void testCloseSetsClosedState() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testReadAfterCloseThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        lexer.close();
        assertThrows(IOException.class, new ThrowingRunnable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
    }

    @Test
    void testPositionAndLineNumberTracking() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "ab\ncd");
        try {
            assertEquals(0, lexer.getCharacterPosition());
            assertEquals(0, lexer.getCurrentLineNumber());
            assertEquals(0, lexer.getBytesRead());

            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.EORECORD, t1.type);
            assertEquals("ab", t1.content.toString());
            assertEquals(1, lexer.getCurrentLineNumber());
            assertTrue(lexer.getCharacterPosition() > 0);
            assertEquals(0, lexer.getBytesRead());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.EOF, t2.type);
            assertTrue(t2.isReady);
            assertEquals("cd", t2.content.toString());
        } finally {
            lexer.close();
        }
    }

    /**
     * Minimal stand-in for {@code org.junit.jupiter.api.function.Executable} usage above, avoiding any dependency
     * beyond what JUnit already provides via {@code assertThrows}.
     */
    private interface ThrowingRunnable extends org.junit.jupiter.api.function.Executable {
    }
}
