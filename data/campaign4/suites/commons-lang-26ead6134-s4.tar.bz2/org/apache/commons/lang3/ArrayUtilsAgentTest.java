package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.AbstractMap;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;
import java.util.function.IntFunction;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils} based on its documented contract in api/.
 */
class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    void emptyArrayConstantsAreEmptyAndCorrectlyTyped() {
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHAR_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CLASS_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_THROWABLE_ARRAY.length);
        assertEquals(String.class, ArrayUtils.EMPTY_STRING_ARRAY.getClass().getComponentType());
        assertEquals(int.class, ArrayUtils.EMPTY_INT_ARRAY.getClass().getComponentType());
    }

    @Test
    void indexNotFoundConstantIsMinusOne() {
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    @Test
    void safeMaxArrayLengthIsASensiblePositiveBound() {
        assertTrue(ArrayUtils.SAFE_MAX_ARRAY_LENGTH > 0);
        assertTrue(ArrayUtils.SAFE_MAX_ARRAY_LENGTH <= Integer.MAX_VALUE);
    }

    // ---------------------------------------------------------------
    // add(array, element)
    // ---------------------------------------------------------------

    @Test
    void addBooleanElementAppendsAndHandlesNullArray() {
        assertArrayEquals(new boolean[] {true}, ArrayUtils.add((boolean[]) null, true));
        assertArrayEquals(new boolean[] {true, false}, ArrayUtils.add(new boolean[] {true}, false));
    }

    @Test
    void addIntElementAppendsAndHandlesNullArray() {
        assertArrayEquals(new int[] {5}, ArrayUtils.add((int[]) null, 5));
        assertArrayEquals(new int[] {1, 0}, ArrayUtils.add(new int[] {1}, 0));
    }

    @Test
    void addObjectElementAppendsAndHandlesNulls() {
        assertArrayEquals(new String[] {"a"}, ArrayUtils.add((String[]) null, "a"));
        assertArrayEquals(new String[] {"a", null}, ArrayUtils.add(new String[] {"a"}, (String) null));
        assertArrayEquals(new String[] {"a", "b"}, ArrayUtils.add(new String[] {"a"}, "b"));
    }

    @Test
    void addObjectElementThrowsWhenBothArrayAndElementAreNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add((Object[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // add(array, index, element) - deprecated insert-at-index variant
    // ---------------------------------------------------------------

    @Test
    void addWithIndexInsertsAtPositionAndHandlesNullArray() {
        assertArrayEquals(new boolean[] {true}, ArrayUtils.add((boolean[]) null, 0, true));
        assertArrayEquals(new boolean[] {false, true}, ArrayUtils.add(new boolean[] {true}, 0, false));
        assertArrayEquals(new boolean[] {true, true, false}, ArrayUtils.add(new boolean[] {true, false}, 1, true));
    }

    @Test
    void addWithIndexThrowsWhenIndexOutOfRange() {
        final boolean[] array = {true, false};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(array, -1, true);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(array, array.length + 1, true);
            }
        });
    }

    @Test
    void addWithIndexObjectVersionAllowsNullElementButNotBothNull() {
        assertArrayEquals(new String[] {"a", null}, ArrayUtils.add(new String[] {"a"}, 1, null));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add((String[]) null, 0, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // addFirst
    // ---------------------------------------------------------------

    @Test
    void addFirstPrependsAndHandlesNullArray() {
        assertArrayEquals(new int[] {1}, ArrayUtils.addFirst((int[]) null, 1));
        assertArrayEquals(new int[] {0, 1}, ArrayUtils.addFirst(new int[] {1}, 0));
        assertArrayEquals(new String[] {"c", "a", "b"}, ArrayUtils.addFirst(new String[] {"a", "b"}, "c"));
    }

    @Test
    void addFirstThrowsWhenBothArrayAndElementAreNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.addFirst((Object[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // addAll
    // ---------------------------------------------------------------

    @Test
    void addAllCombinesArraysAndHandlesNulls() {
        final int[] array1 = {1, 2};
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(array1, (int[]) null));
        assertNotSame(array1, ArrayUtils.addAll(array1, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll((int[]) null, array1));
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
        assertArrayEquals(new int[0], ArrayUtils.addAll(new int[0], new int[0]));
        assertArrayEquals(new String[] {"a", "b", "c", "1", "2", "3"},
                ArrayUtils.addAll(new String[] {"a", "b", "c"}, "1", "2", "3"));
    }

    @Test
    void addAllThrowsForIncompatibleArrayTypes() {
        final Object[] strings = new String[] {"a", "b"};
        final Object[] longs = new Long[] {1L, 2L};
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.addAll(strings, longs);
            }
        });
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    void cloneReturnsNullForNullInput() {
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    void clonePrimitiveArrayProducesIndependentCopy() {
        final int[] original = {1, 2, 3};
        final int[] copy = ArrayUtils.clone(original);
        assertArrayEquals(original, copy);
        assertNotSame(original, copy);
        copy[0] = 99;
        assertEquals(1, original[0]);
    }

    @Test
    void cloneObjectArrayIsShallow() {
        final StringBuilder element = new StringBuilder("x");
        final StringBuilder[] original = {element};
        final StringBuilder[] copy = ArrayUtils.clone(original);
        assertNotSame(original, copy);
        assertSame(original[0], copy[0]);
    }

    // ---------------------------------------------------------------
    // concat
    // ---------------------------------------------------------------

    @Test
    void concatCombinesArraysInOrder() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.concat(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0]));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.concat(new int[] {1, 2}, null));
    }

    // ---------------------------------------------------------------
    // contains / containsAny
    // ---------------------------------------------------------------

    @Test
    void containsFindsValuesAndHandlesNullArray() {
        assertTrue(ArrayUtils.contains(new int[] {1, 2, 3}, 2));
        assertFalse(ArrayUtils.contains(new int[] {1, 2, 3}, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
        assertTrue(ArrayUtils.contains(new String[] {"a", "b"}, "a"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    void containsWithToleranceMatchesWithinRange() {
        final double[] array = {1.0, 5.0};
        assertTrue(ArrayUtils.contains(array, 1.1, 0.2));
        assertFalse(ArrayUtils.contains(array, 1.5, 0.2));
    }

    @Test
    void containsAnyFindsAnyMatchingValue() {
        assertTrue(ArrayUtils.containsAny(new int[] {1, 2, 3}, 9, 2));
        assertFalse(ArrayUtils.containsAny(new int[] {1, 2, 3}, 8, 9));
        assertTrue(ArrayUtils.containsAny(new Object[] {"a", "b"}, "x", "b"));
    }

    // ---------------------------------------------------------------
    // get
    // ---------------------------------------------------------------

    @Test
    void getReturnsElementOrNullWhenOutOfBounds() {
        final String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
    }

    @Test
    void getWithDefaultReturnsDefaultWhenOutOfBounds() {
        final String[] array = {"a", "b"};
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
    }

    // ---------------------------------------------------------------
    // getComponentType / getDimensions / getLength
    // ---------------------------------------------------------------

    @Test
    void getComponentTypeReturnsElementType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
    }

    @Test
    void getDimensionsCountsArrayNesting() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[0]));
        assertEquals(2, ArrayUtils.getDimensions(new int[0][0]));
        assertEquals(3, ArrayUtils.getDimensions(new String[0][0][0]));
    }

    @Test
    void getLengthMatchesDocumentedExamples() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] {null}));
        assertEquals(2, ArrayUtils.getLength(new boolean[] {true, false}));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(3, ArrayUtils.getLength(new String[] {"a", "b", "c"}));
    }

    @Test
    void getLengthThrowsForNonArrayArgument() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    // ---------------------------------------------------------------
    // hashCode
    // ---------------------------------------------------------------

    @Test
    void hashCodeIsZeroForNullAndConsistentForEqualContent() {
        assertEquals(0, ArrayUtils.hashCode(null));
        final int[] a = {1, 2, 3};
        final int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    // ---------------------------------------------------------------
    // indexesOf
    // ---------------------------------------------------------------

    @Test
    void indexesOfFindsAllMatchingPositions() {
        final BitSet expected = new BitSet();
        expected.set(0);
        expected.set(2);
        assertEquals(expected, ArrayUtils.indexesOf(new int[] {1, 2, 1, 3}, 1));
        assertTrue(ArrayUtils.indexesOf((int[]) null, 1).isEmpty());
    }

    @Test
    void indexesOfWithStartIndexSkipsEarlierMatches() {
        final BitSet expected = new BitSet();
        expected.set(2);
        assertEquals(expected, ArrayUtils.indexesOf(new int[] {1, 2, 1, 3}, 1, 1));
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf
    // ---------------------------------------------------------------

    @Test
    void indexOfFindsFirstMatchOrReportsNotFound() {
        assertEquals(1, ArrayUtils.indexOf(new int[] {5, 7, 7}, 7));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(new int[] {5, 7}, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 9));
        assertEquals(1, ArrayUtils.indexOf(new String[] {"a", "b", "b"}, "b"));
    }

    @Test
    void indexOfWithStartIndexHonoursBoundsRules() {
        final int[] array = {5, 7, 7};
        assertEquals(2, ArrayUtils.indexOf(array, 7, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 7, -5));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 7, 10));
    }

    @Test
    void indexOfWithToleranceFindsNearbyValue() {
        final double[] array = {1.0, 2.0, 3.0};
        assertEquals(1, ArrayUtils.indexOf(array, 2.05, 0.1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2.5, 0.1));
    }

    @Test
    void lastIndexOfFindsLastMatchOrReportsNotFound() {
        assertEquals(2, ArrayUtils.lastIndexOf(new int[] {5, 7, 7}, 7));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 7));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(new int[] {5, 7}, 9));
    }

    @Test
    void lastIndexOfWithStartIndexHonoursBoundsRules() {
        final int[] array = {5, 7, 7};
        assertEquals(1, ArrayUtils.lastIndexOf(array, 7, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 7, -1));
        assertEquals(2, ArrayUtils.lastIndexOf(array, 7, 100));
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    void insertAddsValuesAtGivenPositionAndHandlesNullArray() {
        assertArrayEquals(new int[] {1, 4, 5, 2, 3}, ArrayUtils.insert(1, new int[] {1, 2, 3}, 4, 5));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1, 2));
        final int[] original = {1, 2, 3};
        final int[] result = ArrayUtils.insert(1, original, (int[]) null);
        assertArrayEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    void insertThrowsWhenIndexOutOfRange() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, array, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(array.length + 1, array, 9);
            }
        });
    }

    // ---------------------------------------------------------------
    // isArrayIndexValid
    // ---------------------------------------------------------------

    @Test
    void isArrayIndexValidChecksBoundsAndNull() {
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    void isEmptyAndIsNotEmptyAreComplementary() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
    }

    // ---------------------------------------------------------------
    // isEquals (deprecated)
    // ---------------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    void isEqualsComparesContentDeeply() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {2, 1}));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType
    // ---------------------------------------------------------------

    @Test
    void isSameLengthTreatsNullAsEmpty() {
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertTrue(ArrayUtils.isSameLength((int[]) null, new int[0]));
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
    }

    @Test
    void isSameTypeComparesArrayComponentTypes() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertTrue(ArrayUtils.isSameType(new int[0][0], new int[0][0]));
    }

    @Test
    void isSameTypeThrowsWhenEitherArrayIsNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(new int[0], null);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSorted
    // ---------------------------------------------------------------

    @Test
    void isSortedChecksNaturalOrderingForPrimitives() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
    }

    @Test
    void isSortedChecksComparableOrdering() {
        assertTrue(ArrayUtils.isSorted(new Integer[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new Integer[] {3, 1, 2}));
    }

    @Test
    void isSortedWithComparatorUsesGivenOrdering() {
        final Comparator<Integer> descending = new Comparator<Integer>() {
            @Override
            public int compare(final Integer a, final Integer b) {
                return b.compareTo(a);
            }
        };
        assertTrue(ArrayUtils.isSorted(new Integer[] {3, 2, 1}, descending));
        assertFalse(ArrayUtils.isSorted(new Integer[] {1, 2, 3}, descending));
    }

    @Test
    void isSortedWithNullComparatorThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSorted(new Integer[] {1, 2}, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // newInstance / nullTo / nullToEmpty
    // ---------------------------------------------------------------

    @Test
    void newInstanceCreatesArrayOfGivenTypeAndLength() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertNull(array[0]);
    }

    @Test
    void newInstanceThrowsForNullComponentType() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.newInstance(null, 1);
            }
        });
    }

    @Test
    void nullToReturnsDefaultForNullOrEmptyInput() {
        final String[] defaultArray = {"x"};
        assertSame(defaultArray, ArrayUtils.nullTo((String[]) null, defaultArray));
        assertSame(defaultArray, ArrayUtils.nullTo(new String[0], defaultArray));
        final String[] nonEmpty = {"a"};
        assertSame(nonEmpty, ArrayUtils.nullTo(nonEmpty, defaultArray));
    }

    @Test
    void nullToEmptyReturnsEmptyArrayForNullPrimitiveInput() {
        assertArrayEquals(new int[0], ArrayUtils.nullToEmpty((int[]) null));
        final int[] nonEmpty = {1, 2};
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));
    }

    @Test
    void nullToEmptyWithClassReturnsEmptyArrayForNullInput() {
        final String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertEquals(0, result.length);
    }

    @Test
    void nullToEmptyWithClassThrowsForNullType() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.nullToEmpty((String[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // remove / removeAll / removeAllOccurrences / removeElement(s)
    // ---------------------------------------------------------------

    @Test
    void removeDeletesElementAtGivenIndex() {
        assertArrayEquals(new int[] {6, 3}, ArrayUtils.remove(new int[] {2, 6, 3}, 0));
        assertArrayEquals(new String[] {"a", "c"}, ArrayUtils.remove(new String[] {"a", "b", "c"}, 1));
    }

    @Test
    void removeThrowsWhenIndexOutOfRangeOrArrayNull() {
        final int[] array = {1, 2};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(array, 5);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    void removeAllDeletesMultiplePositions() {
        assertArrayEquals(new int[] {6}, ArrayUtils.removeAll(new int[] {2, 6, 3}, 0, 2));
    }

    @Test
    void removeAllThrowsWhenAnyIndexOutOfRange() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.removeAll(array, 0, 9);
            }
        });
    }

    @Test
    void removeAllOccurrencesDeletesEveryMatch() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1));
        assertNull(ArrayUtils.removeAllOccurrences((int[]) null, 1));
    }

    @Test
    void removeElementDeletesOnlyFirstMatchAndHandlesNullOrAbsent() {
        assertArrayEquals(new int[] {3, 1}, ArrayUtils.removeElement(new int[] {1, 3, 1}, 1));
        assertNull(ArrayUtils.removeElement((int[]) null, 1));
        assertArrayEquals(new int[] {1}, ArrayUtils.removeElement(new int[] {1}, 2));
    }

    @Test
    void removeElementsDeletesSpecifiedQuantities() {
        assertArrayEquals(new boolean[] {false}, ArrayUtils.removeElements(new boolean[] {true, false, true}, true, true));
        assertArrayEquals(new boolean[] {true}, ArrayUtils.removeElements(new boolean[] {true}, false, false));
        assertNull(ArrayUtils.removeElements((boolean[]) null, true));
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    void reverseFlipsEntireArray() {
        final int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    void reverseOnNullArrayIsNoOp() {
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void reverseRangeFlipsOnlyGivenRange() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    void reverseRangeClampsOutOfBoundsIndices() {
        final int[] array = {1, 2, 3};
        ArrayUtils.reverse(array, -5, 100);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    // ---------------------------------------------------------------
    // setAll
    // ---------------------------------------------------------------

    @Test
    void setAllWithIntFunctionPopulatesArrayAndReturnsSameInstance() {
        final String[] array = new String[3];
        final String[] result = ArrayUtils.setAll(array, new IntFunction<String>() {
            @Override
            public String apply(final int index) {
                return "v" + index;
            }
        });
        assertSame(array, result);
        assertArrayEquals(new String[] {"v0", "v1", "v2"}, array);
    }

    @Test
    void setAllWithSupplierPopulatesArrayAndReturnsSameInstance() {
        final String[] array = new String[2];
        final String[] result = ArrayUtils.setAll(array, new Supplier<String>() {
            @Override
            public String get() {
                return "fixed";
            }
        });
        assertSame(array, result);
        assertArrayEquals(new String[] {"fixed", "fixed"}, array);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    void shiftByZeroOrFullLengthLeavesArrayUnchanged() {
        final int[] array = {1, 2, 3, 4, 5};
        final int[] original = ArrayUtils.clone(array);
        ArrayUtils.shift(array, 0);
        assertArrayEquals(original, array);
        ArrayUtils.shift(array, array.length);
        assertArrayEquals(original, array);
    }

    @Test
    void shiftIsReversibleByComplementaryOffset() {
        final int[] array = {1, 2, 3, 4, 5};
        final int[] original = ArrayUtils.clone(array);
        ArrayUtils.shift(array, 2);
        assertFalse(java.util.Arrays.equals(original, array));
        ArrayUtils.shift(array, array.length - 2);
        assertArrayEquals(original, array);
    }

    @Test
    void shiftByModuloOffsetMatchesEquivalentSmallerOffset() {
        final int[] array1 = {1, 2, 3, 4, 5};
        final int[] array2 = ArrayUtils.clone(array1);
        ArrayUtils.shift(array1, 2);
        ArrayUtils.shift(array2, array2.length + 2);
        assertArrayEquals(array1, array2);
    }

    @Test
    void shiftOnNullOrEmptyArrayIsNoOp() {
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    void shiftRangeOnlyAffectsGivenRange() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1, 4, 1);
        assertEquals(1, array[0]);
        assertEquals(5, array[4]);
        final int[] middleSorted = {array[1], array[2], array[3]};
        java.util.Arrays.sort(middleSorted);
        assertArrayEquals(new int[] {2, 3, 4}, middleSorted);
    }

    // ---------------------------------------------------------------
    // shuffle
    // ---------------------------------------------------------------

    @Test
    void shuffleKeepsSameElementsAndLength() {
        final int[] array = {1, 2, 3, 4, 5};
        final int[] originalSorted = ArrayUtils.clone(array);
        java.util.Arrays.sort(originalSorted);
        ArrayUtils.shuffle(array, new Random(42));
        assertEquals(5, array.length);
        final int[] shuffledSorted = ArrayUtils.clone(array);
        java.util.Arrays.sort(shuffledSorted);
        assertArrayEquals(originalSorted, shuffledSorted);
    }

    @Test
    void shuffleOnNullArrayOrNullRandomIsNoOp() {
        ArrayUtils.shuffle((int[]) null, new Random(1));
        final int[] array = {1, 2, 3};
        ArrayUtils.shuffle(array, null);
        assertEquals(3, array.length);
    }

    // ---------------------------------------------------------------
    // startsWith
    // ---------------------------------------------------------------

    @Test
    void startsWithMatchesPrefixAndHandlesNulls() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertTrue(ArrayUtils.startsWith(null, null));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, null));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1}));
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    void subarrayExtractsRangeAndHandlesNull() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(new int[] {1, 2, 3, 4, 5}, 1, 3));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 2));
    }

    @Test
    void subarrayClampsOutOfRangeIndices() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(ArrayUtils.subarray(array, 0, 3), ArrayUtils.subarray(array, -2, 3));
        assertArrayEquals(ArrayUtils.subarray(array, 2, array.length), ArrayUtils.subarray(array, 2, 100));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    void swapExchangesTwoElementsAndClampsIndices() {
        assertArrayEquals(new int[] {3, 2, 1}, swapped(new int[] {1, 2, 3}, 0, 2));
        assertArrayEquals(new int[] {1, 2, 3}, swapped(new int[] {1, 2, 3}, 0, 0));
        assertArrayEquals(new int[] {2, 1, 3}, swapped(new int[] {1, 2, 3}, 1, 0));
        assertArrayEquals(new int[] {1, 2, 3}, swapped(new int[] {1, 2, 3}, 0, 5));
        assertArrayEquals(new int[] {2, 1, 3}, swapped(new int[] {1, 2, 3}, -1, 1));
    }

    private static int[] swapped(final int[] array, final int offset1, final int offset2) {
        ArrayUtils.swap(array, offset1, offset2);
        return array;
    }

    @Test
    void swapWithLengthExchangesSeriesOfElements() {
        final boolean[] array = {true, false, true, false};
        ArrayUtils.swap(array, 0, 3, 3);
        assertArrayEquals(new boolean[] {false, false, true, true}, array);
    }

    // ---------------------------------------------------------------
    // toArray
    // ---------------------------------------------------------------

    @Test
    void toArrayCreatesTypeSafeArrayFromVarargs() {
        final String[] result = ArrayUtils.toArray("1", "2");
        assertArrayEquals(new String[] {"1", "2"}, result);
    }

    @Test
    void toArrayWithNoArgumentsReturnsEmptyArray() {
        final Object[] result = ArrayUtils.toArray();
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    // ---------------------------------------------------------------
    // toMap
    // ---------------------------------------------------------------

    @Test
    void toMapBuildsMapFromArrayOfPairsAndMapEntries() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
        assertNull(ArrayUtils.toMap(null));

        final Map<Object, Object> fromEntries = ArrayUtils.toMap(
                new Object[] {new AbstractMap.SimpleEntry("k", "v")});
        assertEquals("v", fromEntries.get("k"));
    }

    @Test
    void toMapThrowsForInvalidElements() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {new Object[] {"onlyOneElement"}});
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {"notAnEntryOrArray"});
            }
        });
    }

    // ---------------------------------------------------------------
    // toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    void toObjectWrapsPrimitivesAndHandlesNull() {
        assertArrayEquals(new Boolean[] {Boolean.TRUE, Boolean.FALSE}, ArrayUtils.toObject(new boolean[] {true, false}));
        assertArrayEquals(new Integer[] {1, 2}, ArrayUtils.toObject(new int[] {1, 2}));
        assertNull(ArrayUtils.toObject((boolean[]) null));
    }

    @Test
    void toPrimitiveUnwrapsObjectsAndHandlesNull() {
        assertArrayEquals(new boolean[] {true, false}, ArrayUtils.toPrimitive(new Boolean[] {true, false}));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.toPrimitive(new Integer[] {1, 2}));
        assertNull(ArrayUtils.toPrimitive((Boolean[]) null));
    }

    @Test
    void toPrimitiveBooleanTreatsNullElementAsFalse() {
        assertArrayEquals(new boolean[] {true, false}, ArrayUtils.toPrimitive(new Boolean[] {true, null}));
    }

    @Test
    void toPrimitiveThrowsOnNullElementForNonBooleanWrappers() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Byte[] {1, null});
            }
        });
    }

    @Test
    void toPrimitiveWithDefaultSubstitutesNullElements() {
        assertArrayEquals(new byte[] {1, 9}, ArrayUtils.toPrimitive(new Byte[] {1, null}, (byte) 9));
    }

    @Test
    void toPrimitiveGenericConvertsWrapperArray() {
        final Object result = ArrayUtils.toPrimitive((Object) new Integer[] {1, 2, 3});
        assertArrayEquals(new int[] {1, 2, 3}, (int[]) result);
        assertNull(ArrayUtils.toPrimitive((Object) null));
        final String[] nonWrapperArray = {"a"};
        assertSame(nonWrapperArray, ArrayUtils.toPrimitive((Object) nonWrapperArray));
    }

    // ---------------------------------------------------------------
    // toString / toStringArray
    // ---------------------------------------------------------------

    @Test
    void toStringRendersArrayInJavaSourceStyle() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] {1, 2, 3}));
    }

    @Test
    void toStringWithFallbackUsesGivenStringForNull() {
        assertEquals("NULL", ArrayUtils.toString(null, "NULL"));
        assertEquals("{1}", ArrayUtils.toString(new int[] {1}, "NULL"));
    }

    @Test
    void toStringArrayConvertsElementsAndHandlesNull() {
        assertArrayEquals(new String[] {"1", "a", "true"}, ArrayUtils.toStringArray(new Object[] {1, "a", Boolean.TRUE}));
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    void toStringArrayWithFallbackSubstitutesNullElements() {
        assertArrayEquals(new String[] {"1", "NULL"}, ArrayUtils.toStringArray(new Object[] {1, null}, "NULL"));
    }
}
