package org.apache.commons.lang3.reflect;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Self-contained tests for {@link MethodUtils}, based on the documented contract in
 * api/org/apache/commons/lang3/reflect/MethodUtils.html.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Marker {
    }

    public interface Greeter {
        String greet();
    }

    public static class Base implements Greeter {
        @Marker
        public void templateMethod() {
        }

        @Override
        public String greet() {
            return "base";
        }
    }

    public static class Sub extends Base {
        @Override
        public void templateMethod() {
            // Intentionally not annotated here: used to test searchSupers in getAnnotation.
        }

        @Override
        public String greet() {
            return "sub";
        }

        @Marker
        public void subOnlyMethod() {
        }

        @Marker
        @SuppressWarnings("unused")
        private String privateAnnotatedMethod() {
            return "private-result";
        }

        public static int add(final int a, final int b) {
            return a + b;
        }

        public int instanceAdd(final int a, final int b) {
            return a + b;
        }

        public String echo(final String s) {
            return s;
        }

        public String echoObj(final Object o) {
            return "obj:" + o;
        }

        public String joinVarArgs(final String sep, final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    sb.append(sep);
                }
                sb.append(parts[i]);
            }
            return sb.toString();
        }

        public void ambiguous(final String s, final Object o) {
        }

        public void ambiguous(final Object o, final String s) {
        }
    }

    @Test
    public void testGetAccessibleMethodByClassAndMethod() throws Exception {
        final Method baseGreet = Base.class.getMethod("greet");
        final Method accessible = MethodUtils.getAccessibleMethod(Sub.class, baseGreet);
        assertNotNull(accessible);
        assertEquals("greet", accessible.getName());

        assertNull(MethodUtils.getAccessibleMethod((Class<?>) null, (Method) null));
    }

    @Test
    public void testGetAccessibleMethodByClassNameAndTypes() {
        final Method echo = MethodUtils.getAccessibleMethod(Sub.class, "echo", String.class);
        assertNotNull(echo);
        assertEquals("echo", echo.getName());

        assertNull(MethodUtils.getAccessibleMethod(Sub.class, "thisMethodDoesNotExist"));
    }

    @Test
    public void testGetAccessibleMethodByMethod() throws Exception {
        final Method echo = Sub.class.getMethod("echo", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(echo);
        assertNotNull(accessible);
        assertEquals("echo", accessible.getName());

        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAnnotation() throws Exception {
        final Method overriddenNotAnnotated = Sub.class.getDeclaredMethod("templateMethod");
        assertNull(MethodUtils.getAnnotation(overriddenNotAnnotated, Marker.class, false, false));

        final Marker foundViaSupers = MethodUtils.getAnnotation(overriddenNotAnnotated, Marker.class, true, false);
        assertNotNull(foundViaSupers);

        final Method directlyAnnotated = Sub.class.getDeclaredMethod("subOnlyMethod");
        assertNotNull(MethodUtils.getAnnotation(directlyAnnotated, Marker.class, false, false));

        try {
            MethodUtils.getAnnotation(null, Marker.class, false, false);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMatchingAccessibleMethod() {
        final Method matched = MethodUtils.getMatchingAccessibleMethod(Sub.class, "echoObj", String.class);
        assertNotNull(matched);
        assertEquals("echoObj", matched.getName());

        assertNull(MethodUtils.getMatchingAccessibleMethod(Sub.class, "thisMethodDoesNotExist"));
    }

    @Test
    public void testGetMatchingMethod() {
        final Method matched = MethodUtils.getMatchingMethod(Sub.class, "echo", String.class);
        assertNotNull(matched);
        assertEquals("echo", matched.getName());

        try {
            MethodUtils.getMatchingMethod(Sub.class, "ambiguous", String.class, String.class);
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }

        try {
            MethodUtils.getMatchingMethod(null, "echo", String.class);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMethodObject() {
        final Method method = MethodUtils.getMethodObject(Sub.class, "echo", String.class);
        assertNotNull(method);
        assertEquals("echo", method.getName());

        assertNull(MethodUtils.getMethodObject(Sub.class, "thisMethodDoesNotExist"));
    }

    @Test
    public void testGetMethodsWithAnnotationArray() {
        final Method[] classLevel = MethodUtils.getMethodsWithAnnotation(Sub.class, Marker.class);
        assertEquals(1, classLevel.length);
        assertEquals("subOnlyMethod", classLevel[0].getName());

        try {
            MethodUtils.getMethodsWithAnnotation(null, Marker.class);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMethodsWithAnnotationArrayFullOptions() {
        final Method[] withSupers = MethodUtils.getMethodsWithAnnotation(Sub.class, Marker.class, true, false);
        assertEquals(2, withSupers.length);

        final Method[] withPrivateAccess = MethodUtils.getMethodsWithAnnotation(Sub.class, Marker.class, false, true);
        assertEquals(2, withPrivateAccess.length);
    }

    @Test
    public void testGetMethodsListWithAnnotation() {
        final List<Method> classLevel = MethodUtils.getMethodsListWithAnnotation(Sub.class, Marker.class);
        assertEquals(1, classLevel.size());
        assertEquals("subOnlyMethod", classLevel.get(0).getName());

        final List<Method> withSupers = MethodUtils.getMethodsListWithAnnotation(Sub.class, Marker.class, true, false);
        assertEquals(2, withSupers.size());

        try {
            MethodUtils.getMethodsListWithAnnotation(Sub.class, null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetOverrideHierarchy() throws Exception {
        final Method templateMethod = Sub.class.getMethod("templateMethod");
        final Set<Method> excludeInterfaces = MethodUtils.getOverrideHierarchy(templateMethod, ClassUtils.Interfaces.EXCLUDE);
        assertEquals(2, excludeInterfaces.size());

        final Method greetMethod = Sub.class.getMethod("greet");
        final Set<Method> includeInterfaces = MethodUtils.getOverrideHierarchy(greetMethod, ClassUtils.Interfaces.INCLUDE);
        assertTrue(includeInterfaces.size() >= 3);
        boolean foundInterfaceMethod = false;
        for (final Method m : includeInterfaces) {
            if (m.getDeclaringClass() == Greeter.class) {
                foundInterfaceMethod = true;
            }
        }
        assertTrue(foundInterfaceMethod);

        try {
            MethodUtils.getOverrideHierarchy(null, ClassUtils.Interfaces.EXCLUDE);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeExactMethod(sub, "greet");
        assertEquals("sub", result);

        try {
            MethodUtils.invokeExactMethod(null, "greet");
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testInvokeExactMethodVarArgs() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeExactMethod(sub, "echo", "hi");
        assertEquals("hi", result);

        try {
            MethodUtils.invokeExactMethod(sub, "echo", Integer.valueOf(5));
            fail("Expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        }
    }

    @Test
    public void testInvokeExactMethodExplicitParameterTypes() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeExactMethod(sub, "instanceAdd",
                new Object[] {Integer.valueOf(1), Integer.valueOf(2)}, new Class<?>[] {int.class, int.class});
        assertEquals(Integer.valueOf(3), result);
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Sub.class, "add", Integer.valueOf(2), Integer.valueOf(3));
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void testInvokeExactStaticMethodExplicitParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Sub.class, "add",
                new Object[] {Integer.valueOf(4), Integer.valueOf(5)}, new Class<?>[] {int.class, int.class});
        assertEquals(Integer.valueOf(9), result);
    }

    @Test
    public void testInvokeMethodForceAccess() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeMethod(sub, true, "privateAnnotatedMethod");
        assertEquals("private-result", result);

        try {
            MethodUtils.invokeMethod(sub, false, "privateAnnotatedMethod");
            fail("Expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        }
    }

    @Test
    public void testInvokeMethodForceAccessWithArgs() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeMethod(sub, true, "echoObj", "x");
        assertEquals("obj:x", result);
    }

    @Test
    public void testInvokeMethodForceAccessExplicitParameterTypes() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeMethod(sub, true, "instanceAdd",
                new Object[] {Integer.valueOf(2), Integer.valueOf(3)}, new Class<?>[] {int.class, int.class});
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeMethod(sub, "greet");
        assertEquals("sub", result);
    }

    @Test
    public void testInvokeMethodCompatibleArgs() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeMethod(sub, "echoObj", "hello");
        assertEquals("obj:hello", result);

        final Object varArgsResult = MethodUtils.invokeMethod(sub, "joinVarArgs", "-", "a", "b", "c");
        assertEquals("a-b-c", varArgsResult);

        try {
            MethodUtils.invokeMethod(null, "greet");
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testInvokeMethodExplicitParameterTypes() throws Exception {
        final Sub sub = new Sub();
        final Object result = MethodUtils.invokeMethod(sub, "instanceAdd",
                new Object[] {Integer.valueOf(2), Integer.valueOf(3)}, new Class<?>[] {int.class, int.class});
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Sub.class, "add", Integer.valueOf(2), Integer.valueOf(3));
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void testInvokeStaticMethodExplicitParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Sub.class, "add",
                new Object[] {Integer.valueOf(6), Integer.valueOf(7)}, new Class<?>[] {int.class, int.class});
        assertEquals(Integer.valueOf(13), result);
    }
}
