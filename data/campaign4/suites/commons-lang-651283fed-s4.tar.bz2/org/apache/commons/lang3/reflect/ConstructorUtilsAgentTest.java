package org.apache.commons.lang3.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Self-contained tests for {@link ConstructorUtils}, based on the documented contract in
 * api/org/apache/commons/lang3/reflect/ConstructorUtils.html.
 */
public class ConstructorUtilsAgentTest {

    public static class Foo {
        public final String value;
        public final int number;

        public Foo() {
            this("default", 0);
        }

        public Foo(final String value) {
            this(value, 0);
        }

        public Foo(final String value, final int number) {
            this.value = value;
            this.number = number;
        }

        // Package-private: never reachable through the "accessible" constructor lookups.
        Foo(final double notAccessible) {
            this.value = "double";
            this.number = (int) notAccessible;
        }
    }

    public static class ObjectOnly {
        public final Object payload;

        public ObjectOnly(final Object payload) {
            this.payload = payload;
        }
    }

    public abstract static class AbstractFoo {
        public AbstractFoo() {
        }
    }

    public static class Throws {
        public Throws() {
            throw new IllegalStateException("boom");
        }
    }

    @Test
    public void testGetAccessibleConstructorByClassAndTypes() throws Exception {
        final Constructor<Foo> ctor = ConstructorUtils.getAccessibleConstructor(Foo.class, String.class, int.class);
        assertNotNull(ctor);
        assertEquals(2, ctor.getParameterTypes().length);

        // The matching constructor exists but is package-private, so it is not "accessible".
        assertNull(ConstructorUtils.getAccessibleConstructor(Foo.class, double.class));
        // No constructor with this exact signature exists at all.
        assertNull(ConstructorUtils.getAccessibleConstructor(ObjectOnly.class, String.class));
    }

    @Test
    public void testGetAccessibleConstructorNullClass() {
        try {
            ConstructorUtils.getAccessibleConstructor(null, String.class);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetAccessibleConstructorByPrototype() throws Exception {
        final Constructor<Foo> declared = Foo.class.getDeclaredConstructor(String.class);
        final Constructor<Foo> accessible = ConstructorUtils.getAccessibleConstructor(declared);
        assertNotNull(accessible);

        final Constructor<Foo> notAccessibleCtor = Foo.class.getDeclaredConstructor(double.class);
        assertNull(ConstructorUtils.getAccessibleConstructor(notAccessibleCtor));
    }

    @Test
    public void testGetAccessibleConstructorNullCtor() {
        try {
            ConstructorUtils.getAccessibleConstructor((Constructor<Foo>) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMatchingAccessibleConstructor() throws Exception {
        final Constructor<Foo> exact = ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, String.class, int.class);
        assertNotNull(exact);
        assertEquals(2, exact.getParameterTypes().length);

        // No exact (Object) constructor, but one is assignment-compatible with String.
        final Constructor<ObjectOnly> compatible = ConstructorUtils.getMatchingAccessibleConstructor(ObjectOnly.class, String.class);
        assertNotNull(compatible);
        assertEquals(Object.class, compatible.getParameterTypes()[0]);

        assertNull(ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, java.util.List.class));
    }

    @Test
    public void testInvokeConstructorInferringTypes() throws Exception {
        final Foo noArgs = ConstructorUtils.invokeConstructor(Foo.class);
        assertEquals("default", noArgs.value);
        assertEquals(0, noArgs.number);

        final Foo withString = ConstructorUtils.invokeConstructor(Foo.class, "hello");
        assertEquals("hello", withString.value);
        assertEquals(0, withString.number);

        final Foo withBoth = ConstructorUtils.invokeConstructor(Foo.class, "value", Integer.valueOf(5));
        assertEquals("value", withBoth.value);
        assertEquals(5, withBoth.number);

        final ObjectOnly compatible = ConstructorUtils.invokeConstructor(ObjectOnly.class, "hi");
        assertEquals("hi", compatible.payload);
    }

    @Test
    public void testInvokeConstructorNoMatch() {
        try {
            ConstructorUtils.invokeConstructor(Foo.class, "a", "b", "c");
            fail("Expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception other) {
            fail("Unexpected exception: " + other);
        }
    }

    @Test
    public void testInvokeConstructorAbstractClass() {
        try {
            ConstructorUtils.invokeConstructor(AbstractFoo.class);
            fail("Expected InstantiationException");
        } catch (final InstantiationException expected) {
            // expected
        } catch (final Exception other) {
            fail("Unexpected exception: " + other);
        }
    }

    @Test
    public void testInvokeConstructorPropagatesTargetException() {
        try {
            ConstructorUtils.invokeConstructor(Throws.class);
            fail("Expected InvocationTargetException");
        } catch (final InvocationTargetException expected) {
            assertEquals(IllegalStateException.class, expected.getTargetException().getClass());
            assertEquals("boom", expected.getTargetException().getMessage());
        } catch (final Exception other) {
            fail("Unexpected exception: " + other);
        }
    }

    @Test
    public void testInvokeConstructorWithExplicitParameterTypes() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, new Object[] {"x", Integer.valueOf(7)}, new Class<?>[] {String.class, int.class});
        assertEquals("x", foo.value);
        assertEquals(7, foo.number);
    }

    @Test
    public void testInvokeConstructorArgTypeMismatchThrowsIllegalArgumentException() {
        try {
            ConstructorUtils.invokeConstructor(Foo.class, new Object[] {"x", "not-an-int"}, new Class<?>[] {String.class, int.class});
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        } catch (final Exception other) {
            fail("Unexpected exception: " + other);
        }
    }

    @Test
    public void testInvokeConstructorNullArgsTreatedAsEmpty() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, (Object[]) null, (Class<?>[]) null);
        assertEquals("default", foo.value);
        assertEquals(0, foo.number);
    }

    @Test
    public void testInvokeExactConstructor() throws Exception {
        final Foo foo = ConstructorUtils.invokeExactConstructor(Foo.class, "hello");
        assertEquals("hello", foo.value);
        assertEquals(0, foo.number);
    }

    @Test
    public void testInvokeExactConstructorRequiresExactTypes() {
        try {
            // ObjectOnly only has an (Object) constructor; String is not an exact match for Object.
            ConstructorUtils.invokeExactConstructor(ObjectOnly.class, "hello");
            fail("Expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception other) {
            fail("Unexpected exception: " + other);
        }
    }

    @Test
    public void testInvokeExactConstructorWithExplicitParameterTypes() throws Exception {
        final Foo foo = ConstructorUtils.invokeExactConstructor(Foo.class, new Object[] {"y", Integer.valueOf(9)}, new Class<?>[] {String.class, int.class});
        assertEquals("y", foo.value);
        assertEquals(9, foo.number);

        try {
            ConstructorUtils.invokeExactConstructor(ObjectOnly.class, new Object[] {"z"}, new Class<?>[] {String.class});
            fail("Expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception other) {
            fail("Unexpected exception: " + other);
        }
    }
}
