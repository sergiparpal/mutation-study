package org.apache.commons.lang3.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for the package-private {@link MemberUtils} class, based on the documented
 * contract in api/org/apache/commons/lang3/reflect/MemberUtils.html.
 */
public class MemberUtilsAgentTest {

    public static class PublicFixture {

        public PublicFixture() {
        }

        public PublicFixture(final String value) {
        }

        public PublicFixture(final Object value) {
        }

        public static void publicStaticMethod() {
        }

        public void publicMethod(final String value) {
        }

        public void publicMethod(final Object value) {
        }

        @SuppressWarnings("unused")
        private void privateMethod() {
        }
    }

    @Test
    public void testIsPublic() throws Exception {
        final Method publicMethod = PublicFixture.class.getDeclaredMethod("publicStaticMethod");
        final Method privateMethod = PublicFixture.class.getDeclaredMethod("privateMethod");
        final Constructor<?> publicCtor = PublicFixture.class.getDeclaredConstructor();

        assertTrue(MemberUtils.isPublic(publicMethod));
        assertFalse(MemberUtils.isPublic(privateMethod));
        assertTrue(MemberUtils.isPublic(publicCtor));
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    public void testIsStatic() throws Exception {
        final Method staticMethod = PublicFixture.class.getDeclaredMethod("publicStaticMethod");
        final Method instanceMethod = PublicFixture.class.getDeclaredMethod("publicMethod", String.class);
        final Constructor<?> ctor = PublicFixture.class.getDeclaredConstructor();

        assertTrue(MemberUtils.isStatic(staticMethod));
        assertFalse(MemberUtils.isStatic(instanceMethod));
        assertFalse(MemberUtils.isStatic(ctor));
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    public void testIsAccessible() throws Exception {
        final Method publicMethod = PublicFixture.class.getDeclaredMethod("publicStaticMethod");
        final Method privateMethod = PublicFixture.class.getDeclaredMethod("privateMethod");

        assertTrue(MemberUtils.isAccessible(publicMethod));
        assertFalse(MemberUtils.isAccessible(privateMethod));
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    public void testIsPackage() {
        // Documented as true unless a public/protected/private modifier is present.
        assertTrue(MemberUtils.isPackage(0));
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    public void testIsMatchingMethod() throws Exception {
        final Method stringMethod = PublicFixture.class.getDeclaredMethod("publicMethod", String.class);

        assertTrue(MemberUtils.isMatchingMethod(stringMethod, new Class<?>[] {String.class}));
        assertFalse(MemberUtils.isMatchingMethod(stringMethod, new Class<?>[] {Integer.class}));
        assertFalse(MemberUtils.isMatchingMethod(stringMethod, new Class<?>[0]));
        assertFalse(MemberUtils.isMatchingMethod(stringMethod, new Class<?>[] {String.class, String.class}));
    }

    @Test
    public void testIsMatchingConstructor() throws Exception {
        final Constructor<?> stringCtor = PublicFixture.class.getDeclaredConstructor(String.class);

        assertTrue(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[] {String.class}));
        assertFalse(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[] {Integer.class}));
        assertFalse(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[0]));
    }

    @Test
    public void testCompareMethodFit() throws Exception {
        final Method stringMethod = PublicFixture.class.getDeclaredMethod("publicMethod", String.class);
        final Method objectMethod = PublicFixture.class.getDeclaredMethod("publicMethod", Object.class);
        final Class<?>[] actual = {String.class};

        // The exact-type match must be reported as a strictly better fit than the widened match.
        assertTrue(MemberUtils.compareMethodFit(stringMethod, objectMethod, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(objectMethod, stringMethod, actual) > 0);
        assertEquals(0, MemberUtils.compareMethodFit(stringMethod, stringMethod, actual));
    }

    @Test
    public void testCompareConstructorFit() throws Exception {
        final Constructor<?> stringCtor = PublicFixture.class.getDeclaredConstructor(String.class);
        final Constructor<?> objectCtor = PublicFixture.class.getDeclaredConstructor(Object.class);
        final Class<?>[] actual = {String.class};

        assertTrue(MemberUtils.compareConstructorFit(stringCtor, objectCtor, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(objectCtor, stringCtor, actual) > 0);
        assertEquals(0, MemberUtils.compareConstructorFit(stringCtor, stringCtor, actual));
    }

    @Test
    public void testSetAccessibleWorkaround() throws Exception {
        final Method publicMethod = PublicFixture.class.getDeclaredMethod("publicStaticMethod");

        final Method result = MemberUtils.setAccessibleWorkaround(publicMethod);
        assertSame(publicMethod, result);

        assertNull(MemberUtils.setAccessibleWorkaround((Method) null));
    }
}
