/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    @Test
    void testInitialStateBeforeAnyRead() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals(0, reader.getLineNumber());
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testSingleCharReadUpdatesStateAndReturnsEofAtEnd() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals('a', reader.read());
        assertEquals('a', reader.getLastChar());
        assertEquals(1, reader.getPosition());
        assertEquals('b', reader.read());
        assertEquals('b', reader.getLastChar());
        assertEquals(2, reader.getPosition());
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
        // Position is incremented even on an EOF read by the single-char read() method.
        assertEquals(3, reader.getPosition());
        assertEquals(EOF, reader.read());
        assertEquals(4, reader.getPosition());
    }

    @Test
    void testLineNumberTrackingAcrossCrLfAndUnterminatedLine() throws IOException {
        // "a\nb\r\nc" has three lines, the last one unterminated.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\nb\r\nc"));
        assertEquals(0, reader.getLineNumber());
        reader.read(); // 'a'
        assertEquals(1, reader.getLineNumber());
        reader.read(); // '\n'
        assertEquals(1, reader.getLineNumber());
        reader.read(); // 'b'
        assertEquals(2, reader.getLineNumber());
        reader.read(); // '\r'
        assertEquals(2, reader.getLineNumber());
        reader.read(); // '\n' following '\r', must not double count
        assertEquals(2, reader.getLineNumber());
        reader.read(); // 'c'
        assertEquals(3, reader.getLineNumber());
        assertEquals(EOF, reader.read());
        assertEquals(3, reader.getLineNumber());
    }

    @Test
    void testBulkReadZeroLengthReturnsZeroAndLeavesStateUntouched() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[5];
        assertEquals(0, reader.read(buf, 0, 0));
        assertEquals(0, reader.getPosition());
        assertEquals(UNDEFINED, reader.getLastChar());
    }

    @Test
    void testBulkReadFillsBufferAndUpdatesState() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcde"));
        final char[] buf = new char[5];
        final int len = reader.read(buf, 0, 5);
        assertEquals(5, len);
        assertEquals("abcde", new String(buf));
        assertEquals('e', reader.getLastChar());
        assertEquals(5, reader.getPosition());
    }

    @Test
    void testBulkReadAtOffsetOnlyWritesRequestedRange() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("xy"));
        final char[] buf = new char[] { '1', '2', '3', '4' };
        final int len = reader.read(buf, 1, 2);
        assertEquals(2, len);
        assertEquals('1', buf[0]);
        assertEquals('x', buf[1]);
        assertEquals('y', buf[2]);
        assertEquals('4', buf[3]);
        assertEquals('y', reader.getLastChar());
    }

    @Test
    void testBulkReadAtEofReturnsEofAndDecrementsPosition() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        final char[] buf = new char[5];
        final int len = reader.read(buf, 0, 5);
        assertEquals(EOF, len);
        assertEquals(EOF, reader.getLastChar());
        // The bulk read() method adds the EOF sentinel (-1) to position, an observable quirk of this implementation.
        assertEquals(-1, reader.getPosition());
    }

    @Test
    void testBulkReadLineNumberTrackingAcrossCrLf() throws IOException {
        // "a\r\nb\nc" -> line boundaries at the CRLF and at the lone LF.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\r\nb\nc"));
        final char[] buf = new char[6];
        final int len = reader.read(buf, 0, 6);
        assertEquals(6, len);
        assertEquals('c', reader.getLastChar());
        // Two EOLs were crossed (CRLF, then LF), and lastChar == 'c' is not a terminator so getLineNumber()
        // adds the pending-line allowance on top of the two completed lines.
        assertEquals(3, reader.getLineNumber());
    }

    @Test
    void testPeekArrayDoesNotConsumeCharacters() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"));
        final char[] peeked = new char[3];
        final int len = reader.peek(peeked);
        assertEquals(3, len);
        assertEquals("hel", new String(peeked));
        // Nothing was consumed: position is unaffected and the next real read starts from 'h'.
        assertEquals(0, reader.getPosition());
        assertEquals('h', reader.read());
        assertEquals('e', reader.read());
    }

    @Test
    void testPeekArrayLargerThanRemainingContent() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hi"));
        final char[] peeked = new char[10];
        final int len = reader.peek(peeked);
        assertEquals(2, len);
        assertEquals('h', peeked[0]);
        assertEquals('i', peeked[1]);
    }

    @Test
    void testPeekArrayZeroLengthReturnsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hi"));
        assertEquals(0, reader.peek(new char[0]));
    }

    @Test
    void testPeekArrayAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(EOF, reader.peek(new char[3]));
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        reader.read(); // 'a'
        reader.read(); // 'b'
        reader.mark(10);
        final long markedPosition = reader.getPosition();
        final long markedLineNumber = reader.getLineNumber();
        final int markedLastChar = reader.getLastChar();
        reader.read(); // 'c'
        reader.read(); // 'd'
        reader.reset();
        assertEquals(markedPosition, reader.getPosition());
        assertEquals(markedLineNumber, reader.getLineNumber());
        assertEquals(markedLastChar, reader.getLastChar());
        // Reading again after reset replays the same characters that followed the mark.
        assertEquals('c', reader.read());
        assertEquals('d', reader.read());
    }

    @Test
    void testReadLineDropsTerminatorsAndReturnsNullAtEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\r\nline2\nline3"));
        assertEquals("line1", reader.readLine());
        assertEquals("line2", reader.readLine());
        assertEquals("line3", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    void testReadLineOnEmptyReaderReturnsNull() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertNull(reader.readLine());
    }

    @Test
    void testCloseSetsLastCharToEofAndRejectsFurtherReads() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        reader.read();
        reader.close();
        assertEquals(EOF, reader.getLastChar());
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }

    @Test
    void testBytesReadIsZeroWithoutByteTracking() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        reader.read();
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testBytesReadTracksAsciiCharactersAsSingleBytes() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        reader.read();
        reader.read();
        reader.read();
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testBytesReadTracksMultiByteCharacter() throws IOException {
        // U+00F1 ('ñ') encodes as 2 bytes in UTF-8.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("añ"), StandardCharsets.UTF_8, true);
        reader.read(); // 'a' -> 1 byte
        assertEquals(1, reader.getBytesRead());
        reader.read(); // 'ñ' -> 2 bytes
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testBytesReadTracksSurrogatePairAsSingleFourByteCharacter() throws IOException {
        // U+1F600 (a surrogate pair) encodes as 4 bytes in UTF-8.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("😀"), StandardCharsets.UTF_8, true);
        reader.read(); // high surrogate alone contributes 0 bytes, pending the low surrogate
        assertEquals(0, reader.getBytesRead());
        reader.read(); // low surrogate completes the pair
        assertEquals(4, reader.getBytesRead());
    }

    @Test
    void testBulkReadBytesTrackingMatchesCharByCharReading() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[3];
        reader.read(buf, 0, 3);
        assertEquals(3, reader.getBytesRead());
    }
}
