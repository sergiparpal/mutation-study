/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    /** A minimal Readable that is not a Reader and not a CharBuffer. */
    private static final class PlainReadable implements Readable {
        private final CharBuffer source;

        PlainReadable(final String data) {
            source = CharBuffer.wrap(data.toCharArray());
        }

        @Override
        public int read(final CharBuffer cb) {
            if (!source.hasRemaining()) {
                return -1;
            }
            final int n = Math.min(cb.remaining(), source.remaining());
            final char[] tmp = new char[n];
            source.get(tmp, 0, n);
            cb.put(tmp, 0, n);
            return n;
        }
    }

    /** A Reader implementation usable with readFrom(Readable). */
    private static final class CountingReader extends Reader {
        private final String data;
        private int pos;

        CountingReader(final String data) {
            this.data = data;
        }

        @Override
        public void close() {
            // no-op
        }

        @Override
        public int read(final char[] cbuf, final int off, final int len) {
            if (pos >= data.length()) {
                return -1;
            }
            final int n = Math.min(len, data.length() - pos);
            data.getChars(pos, pos + n, cbuf, off);
            pos += n;
            return n;
        }
    }

    @Test
    public void testConstructors() {
        final StrBuilder defaultBuilder = new StrBuilder();
        assertEquals(32, defaultBuilder.capacity());
        assertEquals(0, defaultBuilder.length());
        assertEquals("", defaultBuilder.toString());

        final StrBuilder zeroCapacity = new StrBuilder(0);
        assertEquals(32, zeroCapacity.capacity());

        final StrBuilder negativeCapacity = new StrBuilder(-5);
        assertEquals(32, negativeCapacity.capacity());

        final StrBuilder withCapacity = new StrBuilder(10);
        assertEquals(10, withCapacity.capacity());

        final StrBuilder fromString = new StrBuilder("abc");
        assertEquals("abc", fromString.toString());
        assertEquals(3, fromString.length());
        assertEquals(3 + 32, fromString.capacity());

        final StrBuilder fromNullString = new StrBuilder((String) null);
        assertEquals("", fromNullString.toString());
        assertEquals(0, fromNullString.length());
    }

    @Test
    public void testAppendPrimitives() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(false).append('!').append(1).append(2L).append(1.5f).append(2.5d);
        assertEquals("truefalse!12" + String.valueOf(1.5f) + String.valueOf(2.5d), sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL").append((char[]) null);
        assertEquals("NULL", sb.toString());

        sb = new StrBuilder();
        sb.append(new char[0]);
        assertEquals(0, sb.length());
        sb.append(new char[] {'f', 'o', 'o'});
        assertEquals("foo", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeErrors() {
        final StrBuilder sb = new StrBuilder("bar");
        final char[] chars = {'b', 'a', 'r'};
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.append(chars, -1, 1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.append(chars, 4, 0);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.append(chars, 1, -1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.append(chars, 1, 3);
            }
        });
        // valid partial append
        final StrBuilder sb2 = new StrBuilder();
        sb2.append(chars, 1, 2);
        assertEquals("ar", sb2.toString());
    }

    @Test
    public void testAppendCharSequenceVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("N").append((CharSequence) null);
        assertEquals("N", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.append((CharSequence) new StringBuilder("abc"));
        sb2.append((CharSequence) new StringBuffer("def"));
        sb2.append((CharSequence) CharBuffer.wrap("ghi".toCharArray()));
        sb2.append((CharSequence) new StrBuilder("jkl"));
        assertEquals("abcdefghijkl", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.setNullText("N").append((CharSequence) null, 0, 1);
        assertEquals("N", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.append((CharSequence) "hello", 1, 3);
        assertEquals("ell", sb4.toString());
    }

    @Test
    public void testAppendObject() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL").append((Object) null);
        assertEquals("NULL", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.append((Object) Integer.valueOf(42));
        assertEquals("42", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.append((Object) "hi");
        assertEquals("hi", sb3.toString());
    }

    @Test
    public void testAppendStrBuilderAndRangeErrors() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL").append((StrBuilder) null);
        assertEquals("NULL", sb.toString());

        final StrBuilder sb1 = new StrBuilder("foo");
        sb1.append(new StrBuilder("bar"));
        assertEquals("foobar", sb1.toString());

        final StrBuilder sb2 = new StrBuilder("foo");
        final StrBuilder bar = new StrBuilder("bar");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb2.append(bar, -1, 1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb2.append(bar, 4, 0);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb2.append(bar, 1, -1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb2.append(bar, 1, 3);
            }
        });
        sb2.append(bar, 1, 2);
        assertEquals("fooar", sb2.toString());
    }

    @Test
    public void testAppendStringAndRangeErrors() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL").append((String) null);
        assertEquals("NULL", sb.toString());

        final StrBuilder sb1 = new StrBuilder("foo");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb1.append("bar", -1, 1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb1.append("bar", 4, 0);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb1.append("bar", 1, -1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb1.append("bar", 1, 3);
            }
        });
        sb1.append("bar", 1, 2);
        assertEquals("fooar", sb1.toString());
    }

    @Test
    public void testAppendFormatted() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 5);
        assertEquals("x-5", sb.toString());
    }

    @Test
    public void testAppendStringBufferAndStringBuilderVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL").append((StringBuffer) null);
        assertEquals("NULL", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.setNullText("NULL").append((StringBuilder) null);
        assertEquals("NULL", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("foo");
        final StringBuffer buf = new StringBuffer("bar");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb3.append(buf, -1, 1);
            }
        });
        sb3.append(buf, 1, 2);
        assertEquals("fooar", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("foo");
        final StringBuilder jdkBuilder = new StringBuilder("bar");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb4.append(jdkBuilder, 1, 3);
            }
        });
        sb4.append(jdkBuilder, 1, 2);
        assertEquals("fooar", sb4.toString());
    }

    @Test
    public void testAppendCharBufferVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL").append((CharBuffer) null);
        assertEquals("NULL", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.append(CharBuffer.wrap("abc".toCharArray()));
        assertEquals("abc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.setNullText("NULL").append((CharBuffer) null, 0, 1);
        assertEquals("NULL", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.append(CharBuffer.wrap("abcdef".toCharArray()), 1, 3);
        assertEquals("bcd", sb4.toString());
    }

    @Test
    public void testAppendAll() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) null);
        assertEquals(0, sb.length());
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll((Iterable<?>) list);
        assertEquals("abc", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendAll((java.util.Iterator<?>) null);
        assertEquals(0, sb2.length());
        sb2.appendAll(list.iterator());
        assertEquals("abc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendAll((Object[]) null);
        assertEquals(0, sb3.length());
        sb3.appendAll(new Object[] {"a", "b"});
        assertEquals("ab", sb3.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeft() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 3, '0');
        assertEquals("001", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadLeft("foobar", 3, '0');
        assertEquals("bar", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.setNullText("NULL").appendFixedWidthPadLeft((Object) null, 4, '-');
        assertEquals("NULL", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendFixedWidthPadLeft("x", 0, '-');
        assertEquals(0, sb4.length());
        sb4.appendFixedWidthPadLeft("x", -1, '-');
        assertEquals(0, sb4.length());
    }

    @Test
    public void testAppendFixedWidthPadRight() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(1, 3, '0');
        assertEquals("100", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadRight("foobar", 3, '0');
        assertEquals("foo", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.setNullText("NULL").appendFixedWidthPadRight((Object) null, 4, '-');
        assertEquals("NULL", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendFixedWidthPadRight("x", 0, '-');
        assertEquals(0, sb4.length());
    }

    @Test
    public void testAppendLnAndNewLine() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("|");
        sb.appendln("a");
        sb.appendln(1);
        sb.appendln(true);
        assertEquals("a|1|true|", sb.toString());
        assertEquals("|", sb.getNewLineText());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendNewLine();
        assertEquals(System.lineSeparator(), sb2.toString());
    }

    @Test
    public void testAppendNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNull();
        assertEquals(0, sb.length());
        assertEquals(null, sb.getNullText());

        sb.setNullText("NULL");
        sb.appendNull();
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendPadding() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
        sb.appendPadding(-1, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendSeparators() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals(0, sb.length());
        sb.append("a").appendSeparator(',').append("b");
        assertEquals("a,b", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendSeparator(',', ';');
        assertEquals(";", sb2.toString());
        sb2.appendSeparator(',', ';');
        assertEquals(";,", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendSeparator(',', 0);
        assertEquals(0, sb3.length());
        sb3.appendSeparator(',', 1);
        assertEquals(",", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendSeparator((String) null);
        assertEquals(0, sb4.length());
        sb4.append("a").appendSeparator(",").append("b");
        assertEquals("a,b", sb4.toString());

        final StrBuilder sb5 = new StrBuilder();
        sb5.appendSeparator(",", 0);
        assertEquals(0, sb5.length());
        sb5.appendSeparator(null, 1);
        assertEquals(0, sb5.length());
        sb5.appendSeparator(",", 1);
        assertEquals(",", sb5.toString());

        final StrBuilder sb6 = new StrBuilder();
        sb6.appendSeparator(" and", " where");
        assertEquals(" where", sb6.toString());
        sb6.appendSeparator(" and", " where");
        assertEquals(" where and", sb6.toString());
    }

    @Test
    public void testAppendToAppendable() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");

        final StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.toString());

        final StringBuilder jdkSb = new StringBuilder();
        sb.appendTo(jdkSb);
        assertEquals("hello", jdkSb.toString());

        final StringBuffer buf = new StringBuffer();
        sb.appendTo(buf);
        assertEquals("hello", buf.toString());

        final CharBuffer charBuffer = CharBuffer.allocate(10);
        sb.appendTo(charBuffer);
        charBuffer.flip();
        assertEquals("hello", charBuffer.toString());

        final StrBuilder genericTarget = new StrBuilder();
        sb.appendTo((Appendable) genericTarget);
        assertEquals("hello", genericTarget.toString());
    }

    @Test
    public void testAppendWithSeparators() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals(0, sb.length());
        sb.appendWithSeparators((Iterable<?>) Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendWithSeparators(Arrays.asList("a", "b").iterator(), null);
        assertEquals("ab", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendWithSeparators((Object[]) null, ",");
        assertEquals(0, sb3.length());
        sb3.appendWithSeparators(new Object[] {"a", "b", "c"}, "-");
        assertEquals("a-b-c", sb3.toString());
    }

    @Test
    public void testAsReader() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        assertEquals('a', (char) reader.read());
        reader.mark(0);
        final char[] buf = new char[3];
        final int n = reader.read(buf, 0, 3);
        assertEquals(3, n);
        assertArrayEquals(new char[] {'b', 'c', 'd'}, buf);
        reader.reset();
        assertEquals('b', (char) reader.read());
        assertTrue(reader.ready());
        final long skipped = reader.skip(100);
        assertTrue(skipped >= 0);
        assertFalse(reader.ready());
        assertEquals(-1, reader.read());

        final StrBuilder sb2 = new StrBuilder("xy");
        final Reader reader2 = sb2.asReader();
        final char[] dest = new char[5];
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                try {
                    reader2.read(dest, -1, 1);
                } catch (final IOException e) {
                    fail(e.getMessage());
                }
            }
        });
        assertEquals(0, reader2.read(dest, 0, 0));
    }

    @Test
    public void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        final String[] tokens = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokens);
        assertEquals("a b c", tokenizer.getContent());
    }

    @Test
    public void testAsWriter() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write('a');
        writer.write(new char[] {'b', 'c'});
        writer.write(new char[] {'x', 'd', 'e', 'y'}, 1, 2);
        writer.write("fg");
        writer.write("xhix", 1, 2);
        writer.flush();
        writer.close();
        assertEquals("abcdefghi", sb.toString());
    }

    @Test
    public void testBuild() {
        final StrBuilder sb = new StrBuilder("value");
        assertEquals("value", sb.build());
    }

    @Test
    public void testCapacityAndEnsureCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(2);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testCharAtBoundaries() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.charAt(-1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.charAt(3);
            }
        });
    }

    @Test
    public void testClear() {
        final StrBuilder sb = new StrBuilder("abc");
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testContains() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains('w'));
        assertFalse(sb.contains('z'));
        assertTrue(sb.contains("world"));
        assertFalse(sb.contains("planet"));
        assertTrue(sb.contains(StrMatcher.charMatcher('h')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testDeleteRangeAndCharAt() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abc");
        sb2.delete(1, 100);
        assertEquals("a", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abc");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb3.delete(-1, 2);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb3.delete(2, 1);
            }
        });

        final StrBuilder sb4 = new StrBuilder("abc");
        sb4.deleteCharAt(1);
        assertEquals("ac", sb4.toString());
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb4.deleteCharAt(-1);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb4.deleteCharAt(100);
            }
        });
    }

    @Test
    public void testDeleteAllAndFirst() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.deleteAll('a');
        assertEquals("bnn", sb.toString());

        final StrBuilder sb2 = new StrBuilder("one two one two");
        sb2.deleteAll((String) null);
        assertEquals("one two one two", sb2.toString());
        sb2.deleteAll("two");
        assertEquals("one  one ", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("a1b2c3");
        sb3.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("banana");
        sb4.deleteFirst('a');
        assertEquals("bnana", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("one two one two");
        sb5.deleteFirst((String) null);
        assertEquals("one two one two", sb5.toString());
        sb5.deleteFirst("two");
        assertEquals("one  one two", sb5.toString());

        final StrBuilder sb6 = new StrBuilder("a1b2c3");
        sb6.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb6.toString());
    }

    @Test
    public void testEndsWithStartsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith((String) null));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith("this is too long to fit"));

        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith((String) null));
        assertTrue(sb.startsWith(""));
    }

    @Test
    public void testEqualsAndHashCode() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("ABC");
        final StrBuilder sb4 = new StrBuilder("abcd");

        assertTrue(sb1.equals((Object) sb2));
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((StrBuilder) null));
        assertFalse(sb1.equals(sb4));
        assertFalse(sb1.equals(sb3));
        assertEquals(sb1.hashCode(), sb2.hashCode());

        assertTrue(sb1.equalsIgnoreCase(sb3));
        assertTrue(sb1.equalsIgnoreCase(sb1));
        assertFalse(sb1.equalsIgnoreCase(sb4));
    }

    @Test
    public void testGetChars() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] fullCopy = sb.getChars((char[]) null);
        assertArrayEquals("abcdef".toCharArray(), fullCopy);

        final char[] tooSmall = new char[2];
        final char[] result = sb.getChars(tooSmall);
        assertArrayEquals("abcdef".toCharArray(), result);

        final char[] bigEnough = new char[10];
        final char[] result2 = sb.getChars(bigEnough);
        assertSame(bigEnough, result2);

        final char[] dest = new char[3];
        sb.getChars(1, 3, dest, 0);
        assertArrayEquals(new char[] {'b', 'c', 0}, dest);

        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.getChars(-1, 2, new char[5], 0);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.getChars(2, 1, new char[5], 0);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.getChars(0, 100, new char[5], 0);
            }
        });
    }

    @Test
    public void testIndexOfAndLastIndexOf() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('z'));
        assertEquals(-1, sb.indexOf('a', 100));

        assertEquals(0, sb.indexOf("abc"));
        assertEquals(3, sb.indexOf("abc", 1));
        assertEquals(-1, sb.indexOf((String) null));

        assertEquals(0, sb.indexOf(StrMatcher.charMatcher('a')));
        assertEquals(-1, sb.indexOf((StrMatcher) null));

        assertEquals(3, sb.lastIndexOf('a'));
        assertEquals(0, sb.lastIndexOf('a', 2));
        assertEquals(-1, sb.lastIndexOf('z'));

        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(0, sb.lastIndexOf("abc", 2));
        assertEquals(-1, sb.lastIndexOf((String) null));

        assertEquals(3, sb.lastIndexOf(StrMatcher.charMatcher('a')));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testInsertVariants() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, false);
        assertEquals("afalsec", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'b', 'b'});
        assertEquals("abbc", sb.toString());

        sb = new StrBuilder("ac");
        sb.setNullText("NULL").insert(1, (char[]) null);
        assertEquals("aNULLc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'x', 'b', 'b', 'y'}, 1, 2);
        assertEquals("abbc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 1.5d);
        assertEquals("a1.5c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 1.5f);
        assertEquals("a1.5c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 42);
        assertEquals("a42c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 42L);
        assertEquals("a42c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, (Object) Integer.valueOf(9));
        assertEquals("a9c", sb.toString());

        sb = new StrBuilder("ac");
        sb.setNullText("NULL").insert(1, (Object) null);
        assertEquals("aNULLc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, "b");
        assertEquals("abc", sb.toString());

        sb = new StrBuilder("ac");
        sb.setNullText("NULL").insert(1, (String) null);
        assertEquals("aNULLc", sb.toString());

        final StrBuilder boundary = new StrBuilder("ac");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                boundary.insert(-1, "x");
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                boundary.insert(100, "x");
            }
        });
    }

    @Test
    public void testIsEmptyIsNotEmptyAndLengthSize() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        assertEquals(0, sb.length());
        assertEquals(0, sb.size());

        sb.append("x");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
        assertEquals(1, sb.length());
        assertEquals(1, sb.size());
    }

    @Test
    public void testLeftMidRightString() {
        final StrBuilder sb = new StrBuilder("0123456789");
        assertEquals("012", sb.leftString(3));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
        assertEquals("0123456789", sb.leftString(100));

        assertEquals("789", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
        assertEquals("0123456789", sb.rightString(100));

        assertEquals("345", sb.midString(3, 3));
        assertEquals("", sb.midString(3, -1));
        assertEquals("0123456789", sb.midString(-5, 100));
        assertEquals("", sb.midString(100, 3));
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        assertEquals(100, sb.capacity());
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new StringReader("hello world this is long content"));
        assertEquals(32, read);
        assertEquals("hello world this is long content", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.readFrom(new CountingReader("abc"));
        assertEquals("abc", sb2.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("xyz".toCharArray());
        final int read = sb.readFrom(cb);
        assertEquals(3, read);
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testReadFromPlainReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new PlainReadable("plain-data"));
        assertEquals(10, read);
        assertEquals("plain-data", sb.toString());
    }

    @Test
    public void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcdef");
        sb2.replace(1, 3, "Z");
        assertEquals("aZdef", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abc");
        sb3.replace(1, 100, "Z");
        assertEquals("aZ", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("abcdef");
        sb4.replace(1, 3, (String) null);
        assertEquals("adef", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("abc");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb5.replace(-1, 2, "x");
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb5.replace(2, 1, "x");
            }
        });
    }

    @Test
    public void testReplaceMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("123"), "#", 0, sb.length(), -1);
        assertEquals("a#b#c#", sb.toString());

        final StrBuilder sb2 = new StrBuilder("a1b2c3");
        sb2.replace(StrMatcher.charSetMatcher("123"), "#", 0, sb2.length(), 1);
        assertEquals("a#b2c3", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abc");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb3.replace(StrMatcher.charMatcher('a'), "x", -1, 2, -1);
            }
        });
    }

    @Test
    public void testReplaceAllAndFirst() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());

        final StrBuilder sb2 = new StrBuilder("one two one two");
        sb2.replaceAll((String) null, "x");
        assertEquals("one two one two", sb2.toString());
        sb2.replaceAll("two", "2");
        assertEquals("one 2 one 2", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("a1b2c3");
        sb3.replaceAll(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b#c#", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("banana");
        sb4.replaceFirst('a', 'o');
        assertEquals("bonana", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("one two one two");
        sb5.replaceFirst((String) null, "x");
        assertEquals("one two one two", sb5.toString());
        sb5.replaceFirst("two", "2");
        assertEquals("one 2 one two", sb5.toString());

        final StrBuilder sb6 = new StrBuilder("a1b2c3");
        sb6.replaceFirst(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b2c3", sb6.toString());
    }

    @Test
    public void testReverse() {
        final StrBuilder empty = new StrBuilder();
        empty.reverse();
        assertEquals("", empty.toString());

        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());

        final StrBuilder even = new StrBuilder("abcd");
        even.reverse();
        assertEquals("dcba", even.toString());

        // Supplementary code point: a high/low surrogate pair must stay a valid pair after reversal.
        final String supplementary = "a" + new String(Character.toChars(0x1F600)) + "b";
        final StrBuilder withSurrogates = new StrBuilder(supplementary);
        withSurrogates.reverse();
        assertEquals("b" + new String(Character.toChars(0x1F600)) + "a", withSurrogates.toString());
        assertEquals(supplementary.length(), withSurrogates.length());
        assertEquals(3, withSurrogates.toString().codePointCount(0, withSurrogates.length()));
    }

    @Test
    public void testSetCharAtBoundary() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.setCharAt(-1, 'x');
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.setCharAt(10, 'x');
            }
        });
    }

    @Test
    public void testSetLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());

        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));

        final StrBuilder sb2 = new StrBuilder("abc");
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb2.setLength(-1);
            }
        });
    }

    @Test
    public void testNewLineAndNullTextSetters() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(null, sb.getNewLineText());
        sb.setNewLineText("<br>");
        assertEquals("<br>", sb.getNewLineText());
        sb.setNewLineText(null);
        assertEquals(null, sb.getNewLineText());

        assertEquals(null, sb.getNullText());
        sb.setNullText("N/A");
        assertEquals("N/A", sb.getNullText());
        sb.setNullText("");
        assertEquals(null, sb.getNullText());
        sb.setNullText("x");
        sb.setNullText(null);
        assertEquals(null, sb.getNullText());
    }

    @Test
    public void testSubSequenceAndSubstring() {
        final StrBuilder sb = new StrBuilder("0123456789");
        assertEquals("234", sb.subSequence(2, 5));
        assertEquals("23456789", sb.substring(2));
        assertEquals("234", sb.substring(2, 5));
        assertEquals("23456789", sb.substring(2, 1000));

        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.subSequence(-1, 5);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.subSequence(2, 1000);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.subSequence(5, 2);
            }
        });
        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.substring(-1, 5);
            }
        });
    }

    @Test
    public void testToCharArray() {
        final StrBuilder empty = new StrBuilder();
        final char[] emptyArray = empty.toCharArray();
        assertEquals(0, emptyArray.length);

        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals("abcdef".toCharArray(), sb.toCharArray());
        assertArrayEquals(new char[] {'b', 'c'}, sb.toCharArray(1, 3));
        assertArrayEquals(new char[0], sb.toCharArray(2, 2));
        assertArrayEquals("cdef".toCharArray(), sb.toCharArray(2, 1000));

        assertThrowsIndexOutOfBounds(new Runnable() {
            @Override
            public void run() {
                sb.toCharArray(-1, 3);
            }
        });
    }

    @Test
    public void testToStringBufferAndBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
        final StringBuilder jdkBuilder = sb.toStringBuilder();
        assertEquals("abc", jdkBuilder.toString());

        // Returned values are independent copies.
        buf.append("X");
        jdkBuilder.append("Y");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrim() {
        final StrBuilder sb = new StrBuilder("  \t abc \n ");
        sb.trim();
        assertEquals("abc", sb.toString());

        final StrBuilder onlyWhitespace = new StrBuilder("   \t\n  ");
        onlyWhitespace.trim();
        assertEquals("", onlyWhitespace.toString());

        final StrBuilder noWhitespace = new StrBuilder("abc");
        noWhitespace.trim();
        assertEquals("abc", noWhitespace.toString());

        final StrBuilder empty = new StrBuilder();
        empty.trim();
        assertEquals("", empty.toString());
    }

    @Test
    public void testFluentChainingReturnsSameInstance() {
        final StrBuilder sb = new StrBuilder();
        assertSame(sb, sb.append("a"));
        assertSame(sb, sb.insert(0, "b"));
        assertSame(sb, sb.deleteCharAt(0));
        assertSame(sb, sb.setCharAt(0, 'c'));
        assertSame(sb, sb.setLength(1));
        assertSame(sb, sb.reverse());
        assertSame(sb, sb.trim());
    }

    /**
     * Asserts that running the given action throws either {@link StringIndexOutOfBoundsException}
     * or {@link IndexOutOfBoundsException}, matching the documented behavior of StrBuilder.
     */
    private static void assertThrowsIndexOutOfBounds(final Runnable action) {
        try {
            action.run();
        } catch (final IndexOutOfBoundsException expected) {
            return;
        }
        fail("Expected IndexOutOfBoundsException");
    }
}
