package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class DiffBuilderAgentTest {

    static class Point {
        final int x;
        final int y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof Point)) {
                return false;
            }
            Point p = (Point) o;
            return x == p.x && y == p.y;
        }

        @Override
        public int hashCode() {
            return x * 31 + y;
        }
    }

    private DiffBuilder<Point> newBuilder() {
        return DiffBuilder.<Point>builder()
                .setLeft(new Point(1, 2))
                .setRight(new Point(9, 9))
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .setTestObjectsEquals(false)
                .build();
    }

    // ---- TO_STRING_FORMAT constant ----

    @Test
    public void toStringFormatConstantMatchesDocumentedValue() {
        assertSame(String.class, DiffBuilder.TO_STRING_FORMAT.getClass());
        assertTrue("%s differs from %s".equals(DiffBuilder.TO_STRING_FORMAT));
    }

    // ---- static builder() factory ----

    @Test
    public void builderFactoryReturnsNonNullBuilder() {
        assertNotNull(DiffBuilder.builder());
    }

    @Test
    public void builderFactoryReturnsNewInstanceEachCall() {
        DiffBuilder.Builder<Point> b1 = DiffBuilder.builder();
        DiffBuilder.Builder<Point> b2 = DiffBuilder.builder();
        assertNotSame(b1, b2);
    }

    // ---- DiffBuilder.Builder fluent setters ----

    @Test
    public void builderSetLeftReturnsSameInstance() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setLeft(new Point(1, 2)));
    }

    @Test
    public void builderSetRightReturnsSameInstance() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setRight(new Point(1, 2)));
    }

    @Test
    public void builderSetStyleReturnsSameInstance() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setStyle(ToStringStyle.SHORT_PREFIX_STYLE));
    }

    @Test
    public void builderSetStyleAcceptsNull() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setStyle(null));
    }

    @Test
    public void builderSetTestObjectsEqualsReturnsSameInstance() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setTestObjectsEquals(false));
    }

    @Test
    public void builderSetToStringFormatReturnsSameInstance() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setToStringFormat("%s differs from %s"));
    }

    @Test
    public void builderSetToStringFormatAcceptsNull() {
        DiffBuilder.Builder<Point> builder = DiffBuilder.builder();
        assertSame(builder, builder.setToStringFormat(null));
    }

    @Test
    public void builderBuildProducesConfiguredDiffBuilder() {
        Point left = new Point(1, 2);
        Point right = new Point(3, 4);
        DiffBuilder<Point> db = DiffBuilder.<Point>builder()
                .setLeft(left)
                .setRight(right)
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .build();
        assertNotNull(db);
        assertSame(left, db.getLeft());
        assertSame(right, db.getRight());
    }

    @Test
    public void builderBuildWithNullLeftThrowsNPE() {
        final DiffBuilder.Builder<Point> builder = DiffBuilder.<Point>builder().setRight(new Point(1, 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.build();
            }
        });
    }

    @Test
    public void builderBuildWithNullRightThrowsNPE() {
        final DiffBuilder.Builder<Point> builder = DiffBuilder.<Point>builder().setLeft(new Point(1, 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.build();
            }
        });
    }

    // ---- Deprecated 3-arg constructor ----

    @Test
    public void threeArgConstructorStoresLeftAndRight() {
        Point left = new Point(1, 2);
        Point right = new Point(3, 4);
        DiffBuilder<Point> db = new DiffBuilder<Point>(left, right, ToStringStyle.SHORT_PREFIX_STYLE);
        assertSame(left, db.getLeft());
        assertSame(right, db.getRight());
    }

    @Test
    public void threeArgConstructorNullStyleUsesDefault() {
        Point left = new Point(1, 2);
        Point right = new Point(3, 4);
        DiffBuilder<Point> db = new DiffBuilder<Point>(left, right, null);
        assertNotNull(db.build());
    }

    @Test
    public void threeArgConstructorNullLeftThrowsNPE() {
        final Point right = new Point(3, 4);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new DiffBuilder<Point>(null, right, ToStringStyle.SHORT_PREFIX_STYLE);
            }
        });
    }

    @Test
    public void threeArgConstructorNullRightThrowsNPE() {
        final Point left = new Point(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new DiffBuilder<Point>(left, null, ToStringStyle.SHORT_PREFIX_STYLE);
            }
        });
    }

    @Test
    public void threeArgConstructorSkipsAppendWhenSameReference() {
        Point shared = new Point(1, 2);
        DiffBuilder<Point> db = new DiffBuilder<Point>(shared, shared, ToStringStyle.SHORT_PREFIX_STYLE);
        DiffBuilder<Point> result = db.append("flag", true, false);
        assertSame(db, result);
        assertFalse(result.build().toString().contains("flag"));
    }

    @Test
    public void threeArgConstructorSkipsAppendWhenEqualButNotSame() {
        Point left = new Point(1, 2);
        Point right = new Point(1, 2);
        DiffBuilder<Point> db = new DiffBuilder<Point>(left, right, ToStringStyle.SHORT_PREFIX_STYLE);
        db.append("flag", true, false);
        assertFalse(db.build().toString().contains("flag"));
    }

    // ---- Deprecated 4-arg constructor ----

    @Test
    public void fourArgConstructorNullLeftThrowsNPE() {
        final Point right = new Point(3, 4);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new DiffBuilder<Point>(null, right, ToStringStyle.SHORT_PREFIX_STYLE, true);
            }
        });
    }

    @Test
    public void fourArgConstructorNullRightThrowsNPE() {
        final Point left = new Point(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new DiffBuilder<Point>(left, null, ToStringStyle.SHORT_PREFIX_STYLE, true);
            }
        });
    }

    @Test
    public void fourArgConstructorTestObjectsEqualsTrueSkipsEqualButNotSame() {
        Point left = new Point(1, 2);
        Point right = new Point(1, 2);
        DiffBuilder<Point> db = new DiffBuilder<Point>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, true);
        db.append("flag", true, false);
        assertFalse(db.build().toString().contains("flag"));
    }

    @Test
    public void fourArgConstructorTestObjectsEqualsFalseEvaluatesEvenWhenSameReference() {
        Point shared = new Point(1, 2);
        DiffBuilder<Point> db = new DiffBuilder<Point>(shared, shared, ToStringStyle.SHORT_PREFIX_STYLE, false);
        db.append("flag", true, false);
        assertTrue(db.build().toString().contains("flag"));
    }

    @Test
    public void fourArgConstructorTestObjectsEqualsFalseEvaluatesEvenWhenEqual() {
        Point left = new Point(1, 2);
        Point right = new Point(1, 2);
        DiffBuilder<Point> db = new DiffBuilder<Point>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false);
        db.append("flag", true, false);
        assertTrue(db.build().toString().contains("flag"));
    }

    // ---- build() ----

    @Test
    public void buildReturnsNonNullDiffResult() {
        DiffBuilder<Point> db = newBuilder();
        DiffResult<Point> result = db.build();
        assertNotNull(result);
    }

    @Test
    public void buildWithNoAppendsProducesResultWithoutCanaryField() {
        DiffBuilder<Point> db = newBuilder();
        assertFalse(db.build().toString().contains("untouchedField"));
    }

    // ---- getLeft() / getRight() ----

    @Test
    public void getLeftAndGetRightReturnConfiguredObjects() {
        Point left = new Point(1, 2);
        Point right = new Point(3, 4);
        DiffBuilder<Point> db = new DiffBuilder<Point>(left, right, ToStringStyle.SHORT_PREFIX_STYLE);
        assertSame(left, db.getLeft());
        assertSame(right, db.getRight());
    }

    // ---- append(String, boolean, boolean) ----

    @Test
    public void appendBooleanRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("boolField", true, true));
        assertFalse(equalBuilder.build().toString().contains("boolField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("boolField", true, false));
        assertTrue(diffBuilder.build().toString().contains("boolField"));
    }

    @Test
    public void appendBooleanNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, true, false);
            }
        });
    }

    // ---- append(String, boolean[], boolean[]) ----

    @Test
    public void appendBooleanArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("boolArrField", new boolean[] {true, false}, new boolean[] {true, false}));
        assertFalse(equalBuilder.build().toString().contains("boolArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("boolArrField", new boolean[] {true, false}, new boolean[] {true, true}));
        assertTrue(diffBuilder.build().toString().contains("boolArrField"));
    }

    @Test
    public void appendBooleanArrayDetectsLengthMismatch() {
        DiffBuilder<Point> db = newBuilder();
        db.append("boolArrField", new boolean[] {true}, new boolean[] {true, false});
        assertTrue(db.build().toString().contains("boolArrField"));
    }

    @Test
    public void appendBooleanArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new boolean[] {true}, new boolean[] {false});
            }
        });
    }

    // ---- append(String, byte, byte) ----

    @Test
    public void appendByteRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("byteField", (byte) 1, (byte) 1));
        assertFalse(equalBuilder.build().toString().contains("byteField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("byteField", (byte) 1, (byte) 2));
        assertTrue(diffBuilder.build().toString().contains("byteField"));
    }

    @Test
    public void appendByteNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, (byte) 1, (byte) 2);
            }
        });
    }

    // ---- append(String, byte[], byte[]) ----

    @Test
    public void appendByteArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("byteArrField", new byte[] {1, 2}, new byte[] {1, 2}));
        assertFalse(equalBuilder.build().toString().contains("byteArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("byteArrField", new byte[] {1, 2}, new byte[] {1, 3}));
        assertTrue(diffBuilder.build().toString().contains("byteArrField"));
    }

    @Test
    public void appendByteArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new byte[] {1}, new byte[] {2});
            }
        });
    }

    // ---- append(String, char, char) ----

    @Test
    public void appendCharRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("charField", 'a', 'a'));
        assertFalse(equalBuilder.build().toString().contains("charField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("charField", 'a', 'b'));
        assertTrue(diffBuilder.build().toString().contains("charField"));
    }

    @Test
    public void appendCharNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, 'a', 'b');
            }
        });
    }

    // ---- append(String, char[], char[]) ----

    @Test
    public void appendCharArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("charArrField", new char[] {'a', 'b'}, new char[] {'a', 'b'}));
        assertFalse(equalBuilder.build().toString().contains("charArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("charArrField", new char[] {'a', 'b'}, new char[] {'a', 'c'}));
        assertTrue(diffBuilder.build().toString().contains("charArrField"));
    }

    @Test
    public void appendCharArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new char[] {'a'}, new char[] {'b'});
            }
        });
    }

    // ---- append(String, double, double) ----

    @Test
    public void appendDoubleRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("doubleField", 1.5d, 1.5d));
        assertFalse(equalBuilder.build().toString().contains("doubleField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("doubleField", 1.5d, 2.5d));
        assertTrue(diffBuilder.build().toString().contains("doubleField"));
    }

    @Test
    public void appendDoubleNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, 1.0d, 2.0d);
            }
        });
    }

    // ---- append(String, double[], double[]) ----

    @Test
    public void appendDoubleArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("doubleArrField", new double[] {1.0, 2.0}, new double[] {1.0, 2.0}));
        assertFalse(equalBuilder.build().toString().contains("doubleArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("doubleArrField", new double[] {1.0, 2.0}, new double[] {1.0, 3.0}));
        assertTrue(diffBuilder.build().toString().contains("doubleArrField"));
    }

    @Test
    public void appendDoubleArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new double[] {1.0}, new double[] {2.0});
            }
        });
    }

    // ---- append(String, float, float) ----

    @Test
    public void appendFloatRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("floatField", 1.5f, 1.5f));
        assertFalse(equalBuilder.build().toString().contains("floatField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("floatField", 1.5f, 2.5f));
        assertTrue(diffBuilder.build().toString().contains("floatField"));
    }

    @Test
    public void appendFloatNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, 1.0f, 2.0f);
            }
        });
    }

    // ---- append(String, float[], float[]) ----

    @Test
    public void appendFloatArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("floatArrField", new float[] {1.0f, 2.0f}, new float[] {1.0f, 2.0f}));
        assertFalse(equalBuilder.build().toString().contains("floatArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("floatArrField", new float[] {1.0f, 2.0f}, new float[] {1.0f, 3.0f}));
        assertTrue(diffBuilder.build().toString().contains("floatArrField"));
    }

    @Test
    public void appendFloatArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new float[] {1.0f}, new float[] {2.0f});
            }
        });
    }

    // ---- append(String, int, int) ----

    @Test
    public void appendIntRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("intField", 1, 1));
        assertFalse(equalBuilder.build().toString().contains("intField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("intField", 1, 2));
        assertTrue(diffBuilder.build().toString().contains("intField"));
    }

    @Test
    public void appendIntNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, 1, 2);
            }
        });
    }

    // ---- append(String, int[], int[]) ----

    @Test
    public void appendIntArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("intArrField", new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(equalBuilder.build().toString().contains("intArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("intArrField", new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(diffBuilder.build().toString().contains("intArrField"));
    }

    @Test
    public void appendIntArrayDetectsLengthMismatch() {
        DiffBuilder<Point> db = newBuilder();
        db.append("intArrField", new int[] {1, 2}, new int[] {1, 2, 3});
        assertTrue(db.build().toString().contains("intArrField"));
    }

    @Test
    public void appendIntArrayEmptyArraysAreEqual() {
        DiffBuilder<Point> db = newBuilder();
        db.append("intArrField", new int[0], new int[0]);
        assertFalse(db.build().toString().contains("intArrField"));
    }

    @Test
    public void appendIntArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new int[] {1}, new int[] {2});
            }
        });
    }

    // ---- append(String, long, long) ----

    @Test
    public void appendLongRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("longField", 1L, 1L));
        assertFalse(equalBuilder.build().toString().contains("longField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("longField", 1L, 2L));
        assertTrue(diffBuilder.build().toString().contains("longField"));
    }

    @Test
    public void appendLongNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, 1L, 2L);
            }
        });
    }

    // ---- append(String, long[], long[]) ----

    @Test
    public void appendLongArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("longArrField", new long[] {1L, 2L}, new long[] {1L, 2L}));
        assertFalse(equalBuilder.build().toString().contains("longArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("longArrField", new long[] {1L, 2L}, new long[] {1L, 3L}));
        assertTrue(diffBuilder.build().toString().contains("longArrField"));
    }

    @Test
    public void appendLongArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new long[] {1L}, new long[] {2L});
            }
        });
    }

    // ---- append(String, short, short) ----

    @Test
    public void appendShortRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("shortField", (short) 1, (short) 1));
        assertFalse(equalBuilder.build().toString().contains("shortField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("shortField", (short) 1, (short) 2));
        assertTrue(diffBuilder.build().toString().contains("shortField"));
    }

    @Test
    public void appendShortNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, (short) 1, (short) 2);
            }
        });
    }

    // ---- append(String, short[], short[]) ----

    @Test
    public void appendShortArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("shortArrField", new short[] {1, 2}, new short[] {1, 2}));
        assertFalse(equalBuilder.build().toString().contains("shortArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("shortArrField", new short[] {1, 2}, new short[] {1, 3}));
        assertTrue(diffBuilder.build().toString().contains("shortArrField"));
    }

    @Test
    public void appendShortArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new short[] {1}, new short[] {2});
            }
        });
    }

    // ---- append(String, Object, Object) ----

    @Test
    public void appendObjectRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("objectField", "a", "a"));
        assertFalse(equalBuilder.build().toString().contains("objectField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("objectField", "a", "b"));
        assertTrue(diffBuilder.build().toString().contains("objectField"));
    }

    @Test
    public void appendObjectNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, "a", "b");
            }
        });
    }

    // ---- append(String, Object[], Object[]) ----

    @Test
    public void appendObjectArrayRecordsDiffOnlyWhenValuesDiffer() {
        DiffBuilder<Point> equalBuilder = newBuilder();
        assertSame(equalBuilder, equalBuilder.append("objectArrField", new Object[] {"a", "b"}, new Object[] {"a", "b"}));
        assertFalse(equalBuilder.build().toString().contains("objectArrField"));

        DiffBuilder<Point> diffBuilder = newBuilder();
        assertSame(diffBuilder, diffBuilder.append("objectArrField", new Object[] {"a", "b"}, new Object[] {"a", "c"}));
        assertTrue(diffBuilder.build().toString().contains("objectArrField"));
    }

    @Test
    public void appendObjectArrayDetectsLengthMismatch() {
        DiffBuilder<Point> db = newBuilder();
        db.append("objectArrField", new Object[] {"a", "b"}, new Object[] {"a"});
        assertTrue(db.build().toString().contains("objectArrField"));
    }

    @Test
    public void appendObjectArrayNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> db = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                db.append(null, new Object[] {"a"}, new Object[] {"b"});
            }
        });
    }

    // ---- append(String, DiffResult) ----

    @Test
    public void appendDiffResultReturnsSameInstance() {
        DiffBuilder<Point> inner = DiffBuilder.<Point>builder()
                .setLeft(new Point(0, 0))
                .setRight(new Point(1, 1))
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .build();
        inner.append("innerValue", 1, 2);
        DiffResult<Point> innerResult = inner.build();

        DiffBuilder<Point> outer = newBuilder();
        DiffBuilder<Point> result = outer.append("nested", innerResult);
        assertSame(outer, result);
        assertNotNull(outer.build());
    }

    @Test
    public void appendDiffResultNullFieldNameThrowsNPE() {
        final DiffBuilder<Point> inner = DiffBuilder.<Point>builder()
                .setLeft(new Point(0, 0))
                .setRight(new Point(1, 1))
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .build();
        inner.append("innerValue", 1, 2);
        final DiffResult<Point> innerResult = inner.build();
        final DiffBuilder<Point> outer = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                outer.append(null, innerResult);
            }
        });
    }

    @Test
    public void appendDiffResultNullDiffResultThrowsNPE() {
        final DiffBuilder<Point> outer = newBuilder();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                outer.append("nested", null);
            }
        });
    }
}
