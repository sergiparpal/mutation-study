package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;

public class StopWatchAgentTest {

    private static final class CheckedTestException extends Exception {
        CheckedTestException(final String message) {
            super(message);
        }
    }

    // --- create() / createStarted() / constructors -------------------------

    @Test
    public void testCreate_InitialState() {
        final StopWatch watch = StopWatch.create();
        assertNotNull(watch);
        assertFalse(watch.isStarted());
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStopped());
    }

    @Test
    public void testCreateStarted_InitialState() {
        final StopWatch watch = StopWatch.createStarted();
        assertNotNull(watch);
        assertTrue(watch.isStarted());
        assertFalse(watch.isSuspended());
        assertFalse(watch.isStopped());
    }

    @Test
    public void testDefaultConstructor_NoMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    public void testMessageConstructor_GetMessageReturnsIt() {
        final StopWatch watch = new StopWatch("myLabel");
        assertEquals("myLabel", watch.getMessage());
    }

    // --- start()/stop() -----------------------------------------------------

    @Test
    public void testStart_SetsStartedState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    public void testStart_CalledTwiceThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    public void testStop_WithoutStartThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    public void testStop_AfterStart_SetsStoppedState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertTrue(watch.isStopped());
    }

    @Test
    public void testStop_CalledTwiceThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    // --- suspend()/resume() --------------------------------------------------

    @Test
    public void testSuspend_WithoutRunningThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    public void testSuspend_AfterStart_SetsSuspendedButStillStartedState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
    }

    @Test
    public void testSuspend_CalledTwiceThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    public void testResume_WithoutSuspendThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    public void testResume_AfterSuspend_ClearsSuspendedState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        watch.resume();
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStarted());
    }

    // --- split()/unsplit() ---------------------------------------------------

    @Test
    public void testSplit_WithoutRunningThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    public void testSplit_CalledTwiceThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    public void testUnsplit_WithoutSplitThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.unsplit();
            }
        });
    }

    @Test
    public void testUnsplit_AfterSplit_AllowsSplitAgain() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.unsplit();
        watch.split();
        assertTrue(watch.getSplitNanoTime() >= 0);
    }

    // --- split-related getters ------------------------------------------------

    @Test
    public void testGetSplitDuration_WithoutSplitThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getSplitDuration();
            }
        });
    }

    @Test
    public void testGetSplitNanoTime_WithoutSplitThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetSplitTime_WithoutSplitThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getSplitTime();
            }
        });
    }

    @Test
    public void testGetSplitDuration_AfterSplit_ConsistentWithSplitNanoTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final long splitNanos = watch.getSplitNanoTime();
        final Duration splitDuration = watch.getSplitDuration();
        assertNotNull(splitDuration);
        assertEquals(splitNanos, splitDuration.toNanos());
        // Reading again must return the same frozen value.
        assertEquals(splitNanos, watch.getSplitNanoTime());
    }

    // --- getSplits() -----------------------------------------------------------

    @Test
    public void testGetSplits_EmptyBeforeAnySplit() {
        final StopWatch watch = StopWatch.createStarted();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertNotNull(splits);
        assertTrue(splits.isEmpty());
    }

    @Test
    public void testGetSplits_AfterLabeledSplit_ContainsLabelAndDuration() {
        final StopWatch watch = StopWatch.createStarted();
        watch.split("first");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
    }

    // --- getStartInstant()/getStopInstant() and deprecated equivalents --------

    @Test
    public void testGetStartInstant_WithoutStartThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getStartInstant();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStartTime_WithoutStartThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getStartTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStartInstant_AfterStart_MatchesDeprecatedStartTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final Instant startInstant = watch.getStartInstant();
        assertNotNull(startInstant);
        assertEquals(startInstant.toEpochMilli(), watch.getStartTime());
    }

    @Test
    public void testGetStopInstant_WithoutStartThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getStopInstant();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStopTime_WithoutStartThrowsIllegalStateException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                watch.getStopTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStopInstant_AfterStop_MatchesDeprecatedStopTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final Instant stopInstant = watch.getStopInstant();
        assertNotNull(stopInstant);
        assertEquals(stopInstant.toEpochMilli(), watch.getStopTime());
    }

    // --- getTime()/getNanoTime()/getDuration() ---------------------------------

    @Test
    public void testGetTime_WithTimeUnit_RoundsDown() {
        final StopWatch watch = new StopWatch();
        watch.start();
        // Freshly started: elapsed time is far below an hour, so rounding down yields 0.
        assertEquals(0L, watch.getTime(TimeUnit.HOURS));
        watch.stop();
    }

    @Test
    public void testGetNanoTime_NonNegativeAndFrozenAfterStop() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final long first = watch.getNanoTime();
        final long second = watch.getNanoTime();
        assertTrue(first >= 0);
        assertEquals(first, second);
    }

    @Test
    public void testGetDuration_ConsistentWithNanoTimeAfterStop() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final Duration duration = watch.getDuration();
        assertNotNull(duration);
        assertEquals(watch.getNanoTime(), duration.toNanos());
        assertEquals(watch.getTime(), duration.toMillis());
    }

    // --- reset() -----------------------------------------------------------------

    @Test
    public void testReset_FromRunning_ReturnsToUnstartedState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.reset();
        assertFalse(watch.isStarted());
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStopped());
    }

    @Test
    public void testReset_AllowsStartingAgain() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.reset();
        // Would throw IllegalStateException if reset() had not cleared the running state.
        watch.start();
        assertTrue(watch.isStarted());
    }

    // --- toString()/toSplitString() -------------------------------------------

    @Test
    public void testToString_WithMessage_HasMessagePrefix() {
        final StopWatch watch = new StopWatch("prefix");
        watch.start();
        watch.stop();
        assertTrue(watch.toString().startsWith("prefix "));
    }

    @Test
    public void testToString_WithoutMessage_HasNoMessagePrefix() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertFalse(watch.toString().startsWith("prefix"));
        assertNotNull(watch.toString());
    }

    @Test
    public void testToSplitString_WithMessage_HasMessagePrefix() {
        final StopWatch watch = new StopWatch("splitPrefix");
        watch.start();
        watch.split();
        assertTrue(watch.toSplitString().startsWith("splitPrefix "));
    }

    // --- formatTime()/formatSplitTime() ----------------------------------------

    @Test
    public void testFormatTime_ReturnsNonNullString() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertNotNull(watch.formatTime());
    }

    @Test
    public void testFormatSplitTime_AfterSplit_ReturnsNonNullString() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertNotNull(watch.formatSplitTime());
    }

    // --- get()/run() delegation ---------------------------------------------------

    @Test
    public void testGet_ReturnsSupplierResult() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new Supplier<String>() {
            @Override
            public String get() {
                return "supplied-value";
            }
        });
        assertEquals("supplied-value", result);
    }

    @Test
    public void testGet_PropagatesRuntimeExceptionFromSupplier() {
        final StopWatch watch = new StopWatch();
        final RuntimeException thrown = new RuntimeException("boom");
        final RuntimeException caught = assertThrows(RuntimeException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        watch.get(new Supplier<String>() {
                            @Override
                            public String get() {
                                throw thrown;
                            }
                        });
                    }
                });
        assertSame(thrown, caught);
    }

    @Test
    public void testRun_ExecutesRunnable() {
        final StopWatch watch = new StopWatch();
        final boolean[] executed = { false };
        watch.run(new Runnable() {
            @Override
            public void run() {
                executed[0] = true;
            }
        });
        assertTrue(executed[0]);
    }

    @Test
    public void testRun_PropagatesRuntimeExceptionFromRunnable() {
        final StopWatch watch = new StopWatch();
        final RuntimeException thrown = new RuntimeException("boom-run");
        final RuntimeException caught = assertThrows(RuntimeException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        watch.run(new Runnable() {
                            @Override
                            public void run() {
                                throw thrown;
                            }
                        });
                    }
                });
        assertSame(thrown, caught);
    }

    // --- getT()/runT() delegation (checked-exception variants) -------------------

    @Test
    public void testGetT_ReturnsSupplierResult() throws Throwable {
        final StopWatch watch = new StopWatch();
        final String result = watch.getT(new FailableSupplier<String, CheckedTestException>() {
            @Override
            public String get() {
                return "failable-value";
            }
        });
        assertEquals("failable-value", result);
    }

    @Test
    public void testGetT_PropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        final CheckedTestException thrown = new CheckedTestException("checked-boom");
        final Throwable caught = assertThrows(CheckedTestException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        watch.getT(new FailableSupplier<String, CheckedTestException>() {
                            @Override
                            public String get() throws CheckedTestException {
                                throw thrown;
                            }
                        });
                    }
                });
        assertSame(thrown, caught);
    }

    @Test
    public void testRunT_ExecutesRunnable() throws Throwable {
        final StopWatch watch = new StopWatch();
        final boolean[] executed = { false };
        watch.runT(new FailableRunnable<CheckedTestException>() {
            @Override
            public void run() {
                executed[0] = true;
            }
        });
        assertTrue(executed[0]);
    }

    @Test
    public void testRunT_PropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        final CheckedTestException thrown = new CheckedTestException("checked-boom-run");
        final Throwable caught = assertThrows(CheckedTestException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        watch.runT(new FailableRunnable<CheckedTestException>() {
                            @Override
                            public void run() throws CheckedTestException {
                                throw thrown;
                            }
                        });
                    }
                });
        assertSame(thrown, caught);
    }

    // --- StopWatch.Split ------------------------------------------------------------

    @Test
    public void testSplit_ConstructorAndGetters() {
        final Duration duration = Duration.ofMillis(1234);
        final StopWatch.Split split = new StopWatch.Split("label", duration);
        assertEquals("label", split.getLabel());
        assertEquals(duration, split.getDuration());
    }

    @Test
    public void testSplit_ToStringIsNotNull() {
        final StopWatch.Split split = new StopWatch.Split("label", Duration.ofMillis(1));
        assertNotNull(split.toString());
    }
}
