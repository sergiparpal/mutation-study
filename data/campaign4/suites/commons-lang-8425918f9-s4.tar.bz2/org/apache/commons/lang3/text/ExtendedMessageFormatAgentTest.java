package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}, based solely on its
 * published javadoc contract.
 */
public class ExtendedMessageFormatAgentTest {

    /** Simple Format that upper-cases the String form of its argument. */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    /** FormatFactory that always returns an UpperCaseFormat, and records its invocation arguments. */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        private String lastName;
        private String lastArguments;
        private Locale lastLocale;

        public Format getFormat(String name, String arguments, Locale locale) {
            this.lastName = name;
            this.lastArguments = arguments;
            this.lastLocale = locale;
            return new UpperCaseFormat();
        }
    }

    // ---------------------------------------------------------------- ctors

    @Test
    public void testPatternOnlyConstructorAppliesPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}!");
        assertEquals("Hello World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testPatternOnlyConstructorRejectsBadPattern() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0,number,#");
            }
        });
    }

    @Test
    public void testPatternOnlyConstructorRejectsNullPattern() {
        assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                new ExtendedMessageFormat((String) null);
            }
        });
    }

    @Test
    public void testPatternLocaleConstructor() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Count: {0,number,integer}", Locale.US);
        assertEquals("Count: 1,234", emf.format(new Object[] {Integer.valueOf(1234)}));
    }

    @Test
    public void testPatternLocaleConstructorRejectsBadPattern() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0,bad", Locale.US);
            }
        });
    }

    @Test
    public void testPatternRegistryConstructorDefaultLocale() {
        Map registry = new HashMap();
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        registry.put("upper", factory);

        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    public void testPatternRegistryConstructorAllowsNullRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", (Map) null);
        assertEquals("Hi there", emf.format(new Object[] {"there"}));
    }

    @Test
    public void testPatternLocaleRegistryConstructor() {
        Map registry = new HashMap();
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        registry.put("upper", factory);

        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals("XYZ", emf.format(new Object[] {"xyz"}));
    }

    @Test
    public void testPatternLocaleRegistryConstructorAllowsNullRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("N={0,number,integer}", Locale.US, null);
        assertEquals("N=1,234", emf.format(new Object[] {Integer.valueOf(1234)}));
    }

    @Test
    public void testRegistryFormatNameAndStyleAreTrimmed() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        Map registry = new HashMap();
        registry.put("upper", factory);

        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0, upper , someStyle }", registry);
        emf.format(new Object[] {"abc"});

        assertEquals("upper", factory.lastName);
        assertEquals("someStyle", factory.lastArguments);
    }

    @Test
    public void testUnknownFormatNameNotInRegistryThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,totallyUnknownFormatType}");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                emf.format(new Object[] {"abc"});
            }
        });
    }

    // ------------------------------------------------------------ choice/std

    @Test
    public void testStandardChoiceFormatStillWorks() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#none|1#one|2#many}", Locale.US);
        assertEquals("none", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("many", emf.format(new Object[] {Integer.valueOf(2)}));
    }

    @Test
    public void testMultipleArguments() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} - {1}");
        assertEquals("a - b", emf.format(new Object[] {"a", "b"}));
    }

    // -------------------------------------------------------------- pattern

    @Test
    public void testApplyPatternChangesFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Initial {0}");
        emf.applyPattern("Changed {0}");
        assertEquals("Changed Z", emf.format(new Object[] {"Z"}));
    }

    @Test
    public void testApplyPatternRejectsBadPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Fine {0}");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                emf.applyPattern("{0,number,#");
            }
        });
    }

    @Test
    public void testToPatternRoundTripsFunctionally() {
        ExtendedMessageFormat original = new ExtendedMessageFormat("Hello {0}, you are {1}.", Locale.US);
        String pattern = original.toPattern();
        assertNotNull(pattern);

        ExtendedMessageFormat roundTripped = new ExtendedMessageFormat(pattern, Locale.US);
        Object[] args = {"Bob", "welcome"};
        assertEquals(original.format(args), roundTripped.format(args));
    }

    @Test
    public void testToPatternWithRegistryRoundTripsFunctionally() {
        Map registry = new HashMap();
        registry.put("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat original = new ExtendedMessageFormat("Say {0,upper}!", registry);
        String pattern = original.toPattern();

        ExtendedMessageFormat roundTripped = new ExtendedMessageFormat(pattern, registry);
        assertEquals(original.format(new Object[] {"hi"}), roundTripped.format(new Object[] {"hi"}));
        assertEquals("Say HI!", roundTripped.format(new Object[] {"hi"}));
    }

    // -------------------------------------------------------- equals/hash

    @Test
    public void testEqualsReflexive() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(emf.equals(emf));
    }

    @Test
    public void testEqualsSamePatternAndLocale() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0} world", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0} world", Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDifferentPattern() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0} world", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0} there", Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsDifferentLocale() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0} world", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0} world", Locale.GERMANY);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsAgainstNullAndOtherType() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0} world", Locale.US);
        assertFalse(a.equals(null));
        assertFalse(a.equals("{0} world"));
    }

    @Test
    public void testEqualsDifferentRegistryContent() {
        Map registryA = new HashMap();
        registryA.put("upper", new UpperCaseFormatFactory());
        Map registryB = new HashMap();
        registryB.put("other", new UpperCaseFormatFactory());

        ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", registryA);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", registryB);
        assertNotEquals(a, b);
    }

    // ------------------------------------------------------- unsupported ops

    @Test
    public void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                emf.setFormat(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    public void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                emf.setFormats(new Format[] {java.text.NumberFormat.getInstance(), java.text.NumberFormat.getInstance()});
            }
        });
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {java.text.NumberFormat.getInstance(), java.text.NumberFormat.getInstance()});
            }
        });
    }

    // ------------------------------------------------------------- state

    @Test
    public void testFormatIsUnaffectedByUnsupportedSetFormatAttempt() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        try {
            emf.setFormat(0, java.text.NumberFormat.getInstance());
        } catch (UnsupportedOperationException expected) {
            // ignored: verifying state below is unaffected by the attempted mutation
        }
        assertEquals("1,234", emf.format(new Object[] {Integer.valueOf(1234)}));
    }
}
