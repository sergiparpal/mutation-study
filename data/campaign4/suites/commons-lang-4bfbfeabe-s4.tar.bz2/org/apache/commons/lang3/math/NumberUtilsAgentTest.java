package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class NumberUtilsAgentTest {

    @Test
    public void testConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());

        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());

        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());

        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());

        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);

        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    @Test
    public void testCompare() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);

        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);

        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);

        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertEquals(new BigDecimal("-42"), NumberUtils.createBigDecimal("-42"));
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("abc");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    @Test
    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigInteger("abc");
            }
        });
    }

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    @Test
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberIntegral() {
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberOverflowsToLong() {
        String tooBigForInt = String.valueOf(((long) Integer.MAX_VALUE) + 1L);
        Number n = NumberUtils.createNumber(tooBigForInt);
        assertTrue(n instanceof Long);
        assertEquals(((long) Integer.MAX_VALUE) + 1L, n.longValue());
    }

    @Test
    public void testCreateNumberOverflowsToBigInteger() {
        Number n = NumberUtils.createNumber("99999999999999999999");
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger("99999999999999999999"), n);
    }

    @Test
    public void testCreateNumberTypeQualifiers() {
        assertTrue(NumberUtils.createNumber("3L") instanceof Long);
        assertTrue(NumberUtils.createNumber("3l") instanceof Long);
        assertTrue(NumberUtils.createNumber("3.14f") instanceof Float);
        assertTrue(NumberUtils.createNumber("3.14F") instanceof Float);
        assertTrue(NumberUtils.createNumber("3.14d") instanceof Double);
        assertTrue(NumberUtils.createNumber("3.14D") instanceof Double);
    }

    @Test
    public void testCreateNumberDecimalDefaultsToFloatThenWidens() {
        assertTrue(NumberUtils.createNumber("3.14") instanceof Float);
        Number veryPrecise = NumberUtils.createNumber("1E400");
        assertTrue(veryPrecise instanceof BigDecimal);
    }

    @Test
    public void testCreateNumberHexAndOctal() {
        Number hex = NumberUtils.createNumber("0x1A");
        assertTrue(hex instanceof Integer);
        assertEquals(26, hex.intValue());

        Number octal = NumberUtils.createNumber("010");
        assertTrue(octal instanceof Integer);
        assertEquals(8, octal.intValue());

        Number longHex = NumberUtils.createNumber("0x100000000");
        assertTrue(longHex instanceof Long);
        assertEquals(4294967296L, longHex.longValue());
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("abc");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber(" 1");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("1 ");
            }
        });
    }

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("123L"));
        assertTrue(NumberUtils.isCreatable("1.2e-5"));
        assertTrue(NumberUtils.isCreatable("0.09"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.34"));
        assertFalse(NumberUtils.isDigits("12a"));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberDeprecated() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("123"));
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertFalse(NumberUtils.isNumber("09"));
    }

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("+Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
        assertTrue(NumberUtils.isParsable("08"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("123L"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    @Test
    public void testMaxArrayByte() {
        assertEquals((byte) 5, NumberUtils.max(new byte[] {(byte) 1, (byte) 5, (byte) 3}));
        assertEquals((byte) 7, NumberUtils.max(new byte[] {(byte) 7}));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMinArrayByte() {
        assertEquals((byte) 1, NumberUtils.min(new byte[] {(byte) 1, (byte) 5, (byte) 3}));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxMinArrayShort() {
        assertEquals((short) 9, NumberUtils.max(new short[] {(short) 2, (short) 9, (short) 4}));
        assertEquals((short) 2, NumberUtils.min(new short[] {(short) 2, (short) 9, (short) 4}));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    public void testMaxMinArrayInt() {
        assertEquals(9, NumberUtils.max(new int[] {2, 9, 4}));
        assertEquals(2, NumberUtils.min(new int[] {2, 9, 4}));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMaxMinArrayLong() {
        assertEquals(9L, NumberUtils.max(new long[] {2L, 9L, 4L}));
        assertEquals(2L, NumberUtils.min(new long[] {2L, 9L, 4L}));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMaxMinArrayFloat() {
        assertEquals(9.5f, NumberUtils.max(new float[] {2.5f, 9.5f, 4.5f}), 0.0f);
        assertEquals(2.5f, NumberUtils.min(new float[] {2.5f, 9.5f, 4.5f}), 0.0f);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    public void testMaxMinArrayDouble() {
        assertEquals(9.5d, NumberUtils.max(new double[] {2.5d, 9.5d, 4.5d}), 0.0d);
        assertEquals(2.5d, NumberUtils.min(new double[] {2.5d, 9.5d, 4.5d}), 0.0d);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    public void testMaxMinThreeByte() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 3, (byte) 2));
    }

    @Test
    public void testMaxMinThreeShort() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 3, (short) 2));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 3, (short) 2));
    }

    @Test
    public void testMaxMinThreeInt() {
        assertEquals(3, NumberUtils.max(1, 3, 2));
        assertEquals(1, NumberUtils.min(1, 3, 2));
    }

    @Test
    public void testMaxMinThreeLong() {
        assertEquals(3L, NumberUtils.max(1L, 3L, 2L));
        assertEquals(1L, NumberUtils.min(1L, 3L, 2L));
    }

    @Test
    public void testMaxMinThreeFloat() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 3.0f, 2.0f), 0.0f);
        assertEquals(1.0f, NumberUtils.min(1.0f, 3.0f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        assertEquals(Float.POSITIVE_INFINITY, NumberUtils.max(1.0f, Float.POSITIVE_INFINITY, 2.0f), 0.0f);
    }

    @Test
    public void testMaxMinThreeDouble() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 3.0d, 2.0d), 0.0d);
        assertEquals(1.0d, NumberUtils.min(1.0d, 3.0d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        assertEquals(Double.POSITIVE_INFINITY, NumberUtils.max(1.0d, Double.POSITIVE_INFINITY, 2.0d), 0.0d);
    }

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("abc"));

        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 5, NumberUtils.toByte("abc", (byte) 5));
    }

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("abc"));

        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 5, NumberUtils.toShort("abc", (short) 5));
    }

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("abc"));

        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(5, NumberUtils.toInt("abc", 5));
    }

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("abc"));

        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(5L, NumberUtils.toLong("abc", 5L));
    }

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("abc"), 0.0f);

        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(5.5f, NumberUtils.toFloat("abc", 5.5f), 0.0f);
    }

    @Test
    public void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("abc"), 0.0d);

        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(5.5d, NumberUtils.toDouble("abc", 5.5d), 0.0d);
    }

    @Test
    public void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);

        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    public void testToScaledBigDecimalFromBigDecimal() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((BigDecimal) null)));

        BigDecimal scaled = NumberUtils.toScaledBigDecimal(BigDecimal.valueOf(1));
        assertEquals(2, scaled.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(scaled));

        BigDecimal rounded = NumberUtils.toScaledBigDecimal(new BigDecimal("2.355"), 2, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("2.36").compareTo(rounded));
        assertEquals(2, rounded.scale());
    }

    @Test
    public void testToScaledBigDecimalFromDouble() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Double) null)));

        BigDecimal scaled = NumberUtils.toScaledBigDecimal(Double.valueOf(1.0d));
        assertEquals(2, scaled.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(scaled));

        BigDecimal rounded = NumberUtils.toScaledBigDecimal(Double.valueOf(1.5d), 0, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("2").compareTo(rounded));
    }

    @Test
    public void testToScaledBigDecimalFromFloat() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Float) null)));

        BigDecimal scaled = NumberUtils.toScaledBigDecimal(Float.valueOf(1.0f));
        assertEquals(2, scaled.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(scaled));

        BigDecimal rounded = NumberUtils.toScaledBigDecimal(Float.valueOf(1.5f), 0, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("2").compareTo(rounded));
    }

    @Test
    public void testToScaledBigDecimalFromString() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((String) null)));

        BigDecimal scaled = NumberUtils.toScaledBigDecimal("1");
        assertEquals(2, scaled.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(scaled));

        BigDecimal rounded = NumberUtils.toScaledBigDecimal("2.355", 2, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("2.36").compareTo(rounded));
    }
}
