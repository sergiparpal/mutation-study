package org.apache.commons.lang3.reflect;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link MethodUtils} based solely on its published javadoc contract.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @interface Marker {
    }

    interface Greeter {
        String greet();
    }

    static class Base implements Greeter {
        @Override
        public String greet() {
            return "base";
        }

        @Marker
        public void annotated() {
        }

        public static String staticMethod(String s) {
            return "static:" + s;
        }

        public String overload(int i) {
            return "int:" + i;
        }

        public String overload(String s) {
            return "string:" + s;
        }

        public String exactMatch(Integer i) {
            return "Integer:" + i;
        }

        public String primitiveMatch(int i) {
            return "int-primitive:" + i;
        }

        public String noArgMethod() {
            return "noarg";
        }

        public void throwing() {
            throw new RuntimeException("boom");
        }
    }

    static class Sub extends Base {
        @Override
        public String greet() {
            return "sub";
        }
    }

    static class Hidden {
        public String pub() {
            return "pub";
        }

        private String priv() {
            return "priv";
        }
    }

    public interface PublicApi {
        String op();
    }

    static class HiddenImpl implements PublicApi {
        @Override
        public String op() {
            return "op";
        }
    }

    static class AnnotatedBase {
        @Marker
        public void baseAnnotated() {
        }

        public void baseMethod() {
        }
    }

    static class AnnotatedSub extends AnnotatedBase {
        @Marker
        public void subAnnotated() {
        }

        @Marker
        protected void subProtectedAnnotated() {
        }
    }

    static class OverrideBase {
        @Marker
        public void overridden() {
        }
    }

    static class OverrideSub extends OverrideBase {
        @Override
        public void overridden() {
        }
    }

    interface FooI {
    }

    interface BarI {
    }

    static class FooBar implements FooI, BarI {
    }

    static class Multi {
        public void ambiguous(FooI f) {
        }

        public void ambiguous(BarI b) {
        }

        public String single(String s) {
            return "single:" + s;
        }
    }

    private static boolean containsNamed(List<Method> methods, String name) {
        for (int i = 0; i < methods.size(); i++) {
            if (methods.get(i).getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    // ---- getAccessibleMethod(Class, Method) ----

    @Test
    public void testGetAccessibleMethodClassMethodFindsThroughInterface() throws Exception {
        Method declared = HiddenImpl.class.getMethod("op");
        Method accessible = MethodUtils.getAccessibleMethod(HiddenImpl.class, declared);
        assertNotNull(accessible);
        assertEquals("op", accessible.getName());
        assertEquals(PublicApi.class, accessible.getDeclaringClass());
        assertTrue(Modifier.isPublic(accessible.getDeclaringClass().getModifiers()));
    }

    @Test
    public void testGetAccessibleMethodClassMethodReturnsNullWhenNoAccessibleEquivalent() throws Exception {
        Method declared = Hidden.class.getMethod("pub");
        assertNull(MethodUtils.getAccessibleMethod(Hidden.class, declared));
    }

    @Test
    public void testGetAccessibleMethodClassMethodNullArgumentsReturnNull() throws Exception {
        Method declared = Base.class.getMethod("noArgMethod");
        assertNull(MethodUtils.getAccessibleMethod((Class<?>) null, declared));
        assertNull(MethodUtils.getAccessibleMethod(Base.class, (Method) null));
    }

    // ---- getAccessibleMethod(Method) ----

    @Test
    public void testGetAccessibleMethodSingleArgFindsPublicMethod() throws Exception {
        Method declared = Base.class.getMethod("noArgMethod");
        Method accessible = MethodUtils.getAccessibleMethod(declared);
        assertNotNull(accessible);
        assertEquals("noArgMethod", accessible.getName());
    }

    @Test
    public void testGetAccessibleMethodSingleArgReturnsNullWhenUnreachable() throws Exception {
        Method declared = Hidden.class.getMethod("pub");
        assertNull(MethodUtils.getAccessibleMethod(declared));
    }

    // ---- getAccessibleMethod(Class, String, Class...) ----

    @Test
    public void testGetAccessibleMethodByNameFindsMethod() {
        Method m = MethodUtils.getAccessibleMethod(Base.class, "noArgMethod");
        assertNotNull(m);
        assertEquals("noArgMethod", m.getName());
    }

    @Test
    public void testGetAccessibleMethodByNameReturnsNullWhenMissing() {
        assertNull(MethodUtils.getAccessibleMethod(Base.class, "doesNotExist"));
    }

    // ---- getAnnotation ----

    @Test
    public void testGetAnnotationDirectlyPresent() throws Exception {
        Method m = Base.class.getMethod("annotated");
        Marker marker = MethodUtils.getAnnotation(m, Marker.class, false, false);
        assertNotNull(marker);
    }

    @Test
    public void testGetAnnotationAbsentReturnsNull() throws Exception {
        Method m = Base.class.getMethod("noArgMethod");
        assertNull(MethodUtils.getAnnotation(m, Marker.class, true, true));
    }

    @Test
    public void testGetAnnotationSearchSupersFindsOverriddenAnnotation() throws Exception {
        Method overriding = OverrideSub.class.getMethod("overridden");
        assertNull(MethodUtils.getAnnotation(overriding, Marker.class, false, false));
        Annotation found = MethodUtils.getAnnotation(overriding, Marker.class, true, false);
        assertNotNull(found);
    }

    @Test
    public void testGetAnnotationNullArgumentsThrowNpe() throws Exception {
        final Method m = Base.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getAnnotation(null, Marker.class, false, false);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getAnnotation(m, null, false, false);
            }
        });
    }

    // ---- getMatchingAccessibleMethod ----

    @Test
    public void testGetMatchingAccessibleMethodResolvesPrimitiveWrapper() {
        Method m = MethodUtils.getMatchingAccessibleMethod(Base.class, "overload", Integer.class);
        assertNotNull(m);
        assertEquals(int.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodReturnsNullWhenNoMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Base.class, "overload", Thread.class));
    }

    // ---- getMatchingMethod ----

    @Test
    public void testGetMatchingMethodFindsUniqueMethod() {
        Method m = MethodUtils.getMatchingMethod(Multi.class, "single", String.class);
        assertNotNull(m);
        assertEquals("single", m.getName());
    }

    @Test
    public void testGetMatchingMethodThrowsOnAmbiguity() {
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(Multi.class, "ambiguous", FooBar.class);
            }
        });
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(null, "single", String.class);
            }
        });
    }

    // ---- getMethodObject ----

    @Test
    public void testGetMethodObjectFound() {
        Method m = MethodUtils.getMethodObject(Base.class, "noArgMethod");
        assertNotNull(m);
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Base.class, "doesNotExist"));
    }

    // ---- getMethodsListWithAnnotation(cls, annotationCls) ----

    @Test
    public void testGetMethodsListWithAnnotationTwoArg() {
        List<Method> found = MethodUtils.getMethodsListWithAnnotation(AnnotatedSub.class, Marker.class);
        assertTrue(containsNamed(found, "baseAnnotated"));
        assertTrue(containsNamed(found, "subAnnotated"));
        assertFalse(containsNamed(found, "subProtectedAnnotated"));
    }

    @Test
    public void testGetMethodsListWithAnnotationTwoArgEmptyWhenNoneAnnotated() {
        List<Method> found = MethodUtils.getMethodsListWithAnnotation(Base.class, Marker.class);
        assertFalse(containsNamed(found, "noArgMethod"));
    }

    @Test
    public void testGetMethodsListWithAnnotationTwoArgNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsListWithAnnotation(null, Marker.class);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsListWithAnnotation(AnnotatedSub.class, null);
            }
        });
    }

    // ---- getMethodsListWithAnnotation(cls, annotationCls, searchSupers, ignoreAccess) ----

    @Test
    public void testGetMethodsListWithAnnotationFourArgIgnoreAccess() {
        List<Method> found = MethodUtils.getMethodsListWithAnnotation(AnnotatedSub.class, Marker.class, false, true);
        assertTrue(containsNamed(found, "subProtectedAnnotated"));
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgSearchSupers() {
        List<Method> withoutSearch = MethodUtils.getMethodsListWithAnnotation(OverrideSub.class, Marker.class, false, false);
        assertFalse(containsNamed(withoutSearch, "overridden"));

        List<Method> withSearch = MethodUtils.getMethodsListWithAnnotation(OverrideSub.class, Marker.class, true, false);
        assertTrue(containsNamed(withSearch, "overridden"));
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsListWithAnnotation(null, Marker.class, true, true);
            }
        });
    }

    // ---- getMethodsWithAnnotation (array variants) ----

    @Test
    public void testGetMethodsWithAnnotationTwoArgMatchesListVersion() {
        List<Method> list = MethodUtils.getMethodsListWithAnnotation(AnnotatedSub.class, Marker.class);
        Method[] array = MethodUtils.getMethodsWithAnnotation(AnnotatedSub.class, Marker.class);
        assertEquals(list.size(), array.length);
    }

    @Test
    public void testGetMethodsWithAnnotationTwoArgNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsWithAnnotation(Base.class, null);
            }
        });
    }

    @Test
    public void testGetMethodsWithAnnotationFourArgMatchesListVersion() {
        List<Method> list = MethodUtils.getMethodsListWithAnnotation(AnnotatedSub.class, Marker.class, false, true);
        Method[] array = MethodUtils.getMethodsWithAnnotation(AnnotatedSub.class, Marker.class, false, true);
        assertEquals(list.size(), array.length);
        assertTrue(array.length >= 3);
    }

    // ---- getOverrideHierarchy ----

    @Test
    public void testGetOverrideHierarchyIncludeInterfaces() throws Exception {
        Method subGreet = Sub.class.getMethod("greet");
        Method baseGreet = Base.class.getDeclaredMethod("greet");
        Method interfaceGreet = Greeter.class.getMethod("greet");

        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(subGreet, Interfaces.INCLUDE);
        assertEquals(3, hierarchy.size());
        assertTrue(hierarchy.contains(baseGreet));
        assertTrue(hierarchy.contains(interfaceGreet));

        Iterator<Method> iterator = hierarchy.iterator();
        assertEquals(subGreet, iterator.next());
    }

    @Test
    public void testGetOverrideHierarchyExcludeInterfaces() throws Exception {
        Method subGreet = Sub.class.getMethod("greet");
        Method interfaceGreet = Greeter.class.getMethod("greet");

        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(subGreet, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        assertFalse(hierarchy.contains(interfaceGreet));
    }

    @Test
    public void testGetOverrideHierarchyNullBehavesLikeExclude() throws Exception {
        Method subGreet = Sub.class.getMethod("greet");
        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(subGreet, null);
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE);
            }
        });
    }

    // ---- invokeExactMethod ----

    @Test
    public void testInvokeExactMethodNoArg() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Base(), "noArgMethod");
        assertEquals("noarg", result);
    }

    @Test
    public void testInvokeExactMethodWithArgs() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Base(), "exactMatch", new Object[] {Integer.valueOf(5)});
        assertEquals("Integer:5", result);
    }

    @Test
    public void testInvokeExactMethodWithExplicitParamTypes() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Base(), "exactMatch",
                new Object[] {Integer.valueOf(9)}, new Class[] {Integer.class});
        assertEquals("Integer:9", result);
    }

    @Test
    public void testInvokeExactMethodNoSuchMethodWhenTypeMismatches() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new Base(), "primitiveMatch", new Object[] {Integer.valueOf(3)});
            }
        });
    }

    @Test
    public void testInvokeExactMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(null, "noArgMethod");
            }
        });
    }

    // ---- invokeExactStaticMethod ----

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Base.class, "staticMethod", new Object[] {"hi"});
        assertEquals("static:hi", result);
    }

    @Test
    public void testInvokeExactStaticMethodWithExplicitParamTypes() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Base.class, "staticMethod",
                new Object[] {"zz"}, new Class[] {String.class});
        assertEquals("static:zz", result);
    }

    @Test
    public void testInvokeExactStaticMethodNoSuchMethodWhenTypeMismatches() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(Base.class, "staticMethod", new Object[] {Integer.valueOf(1)});
            }
        });
    }

    // ---- invokeMethod ----

    @Test
    public void testInvokeMethodNoArgConvenience() throws Exception {
        Object result = MethodUtils.invokeMethod(new Base(), "noArgMethod");
        assertEquals("noarg", result);
    }

    @Test
    public void testInvokeMethodWithPrimitiveWrapping() throws Exception {
        Object result = MethodUtils.invokeMethod(new Base(), "primitiveMatch", new Object[] {Integer.valueOf(7)});
        assertEquals("int-primitive:7", result);
    }

    @Test
    public void testInvokeMethodFindsInterfaceDeclaredMethod() throws Exception {
        Object result = MethodUtils.invokeMethod(new HiddenImpl(), "op");
        assertEquals("op", result);
    }

    @Test
    public void testInvokeMethodForceAccessInvokesPrivateMethod() throws Exception {
        Object result = MethodUtils.invokeMethod(new Hidden(), true, "priv");
        assertEquals("priv", result);
    }

    @Test
    public void testInvokeMethodWithoutForceAccessFailsOnPrivateMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Hidden(), false, "priv");
            }
        });
    }

    @Test
    public void testInvokeMethodWithExplicitParamTypes() throws Exception {
        Object result = MethodUtils.invokeMethod(new Base(), "overload",
                new Object[] {"x"}, new Class[] {String.class});
        assertEquals("string:x", result);
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "noArgMethod");
            }
        });
    }

    @Test
    public void testInvokeMethodWrapsUnderlyingException() {
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Base(), "throwing");
            }
        });
        assertNotNull(thrown.getCause());
        assertEquals("boom", thrown.getCause().getMessage());
    }

    // ---- invokeStaticMethod ----

    @Test
    public void testInvokeStaticMethod() throws Exception {
        Object result = MethodUtils.invokeStaticMethod(Base.class, "staticMethod", new Object[] {"yo"});
        assertEquals("static:yo", result);
    }

    @Test
    public void testInvokeStaticMethodWithExplicitParamTypes() throws Exception {
        Object result = MethodUtils.invokeStaticMethod(Base.class, "staticMethod",
                new Object[] {"zz"}, new Class[] {String.class});
        assertEquals("static:zz", result);
    }

    @Test
    public void testInvokeStaticMethodNoSuchMethodWhenIncompatible() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Base.class, "staticMethod", new Object[] {Integer.valueOf(5)});
            }
        });
    }
}
