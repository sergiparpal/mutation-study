package org.apache.commons.lang3.reflect;

import org.apache.commons.lang3.ClassUtils;
import org.junit.jupiter.api.Test;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface MarkerAnnotation {
    }

    interface Greeter {
        String greet();
    }

    static class Animal {
        @MarkerAnnotation
        public void makeSound() {
        }

        public String identify() {
            return "Animal";
        }

        protected String protectedMethod() {
            return "protected";
        }

        private String privateMethod() {
            return "private";
        }

        public static String staticGreet(String name) {
            return "Hello, " + name;
        }

        public String overloaded(int i) {
            return "int:" + i;
        }

        public String overloaded(String s) {
            return "String:" + s;
        }

        public void throwingMethod() {
            throw new IllegalStateException("boom");
        }
    }

    static class Dog extends Animal implements Greeter {
        @Override
        public String identify() {
            return "Dog";
        }

        @Override
        public void makeSound() {
            // deliberately not annotated: used to test searchSupers on getAnnotation
        }

        @Override
        public String greet() {
            return "Woof";
        }
    }

    static class Cat extends Animal {
        @MarkerAnnotation
        private void purr() {
        }
    }

    static class Ambiguous {
        public void process(Number n) {
        }

        public void process(Object o) {
        }
    }

    // ---------- getAccessibleMethod(Class, Method) ----------

    @Test
    public void testGetAccessibleMethodClassMethodFindsPublicMethod() throws Exception {
        Method identify = Dog.class.getMethod("identify");
        Method accessible = MethodUtils.getAccessibleMethod(Dog.class, identify);
        assertNotNull(accessible);
        assertEquals("identify", accessible.getName());
    }

    @Test
    public void testGetAccessibleMethodClassMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(Dog.class, (Method) null));
    }

    // ---------- getAccessibleMethod(Class, String, Class...) ----------

    @Test
    public void testGetAccessibleMethodByNameFindsMethod() {
        Method method = MethodUtils.getAccessibleMethod(Dog.class, "identify");
        assertNotNull(method);
        assertEquals("identify", method.getName());
    }

    @Test
    public void testGetAccessibleMethodByNameUnknownReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(Dog.class, "noSuchMethodHere"));
    }

    // ---------- getAccessibleMethod(Method) ----------

    @Test
    public void testGetAccessibleMethodSingleArgFindsMethod() throws Exception {
        Method identify = Dog.class.getMethod("identify");
        Method accessible = MethodUtils.getAccessibleMethod(identify);
        assertNotNull(accessible);
        assertEquals("identify", accessible.getName());
    }

    @Test
    public void testGetAccessibleMethodSingleArgNullReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    // ---------- getAnnotation ----------

    @Test
    public void testGetAnnotationDirectlyPresent() throws Exception {
        Method method = Animal.class.getMethod("makeSound");
        MarkerAnnotation annotation = MethodUtils.getAnnotation(method, MarkerAnnotation.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationNotPresentWithoutSearchSupers() throws Exception {
        Method method = Dog.class.getMethod("makeSound");
        MarkerAnnotation annotation = MethodUtils.getAnnotation(method, MarkerAnnotation.class, false, false);
        assertNull(annotation);
    }

    @Test
    public void testGetAnnotationFoundViaSearchSupers() throws Exception {
        Method method = Dog.class.getMethod("makeSound");
        MarkerAnnotation annotation = MethodUtils.getAnnotation(method, MarkerAnnotation.class, true, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getAnnotation(null, MarkerAnnotation.class, false, false);
                    }
                });
    }

    @Test
    public void testGetAnnotationNullAnnotationClassThrowsNpe() throws Exception {
        final Method method = Animal.class.getMethod("makeSound");
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getAnnotation(method, null, false, false);
                    }
                });
    }

    // ---------- getMatchingAccessibleMethod ----------

    @Test
    public void testGetMatchingAccessibleMethodMatchesByWrapperType() {
        Method method = MethodUtils.getMatchingAccessibleMethod(Animal.class, "overloaded", Integer.class);
        assertNotNull(method);
        assertEquals(int.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodMatchesStringOverload() {
        Method method = MethodUtils.getMatchingAccessibleMethod(Animal.class, "overloaded", String.class);
        assertNotNull(method);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodNoArgsFindsNoArgMethod() {
        Method method = MethodUtils.getMatchingAccessibleMethod(Animal.class, "identify");
        assertNotNull(method);
        assertEquals(0, method.getParameterTypes().length);
    }

    @Test
    public void testGetMatchingAccessibleMethodUnknownReturnsNull() {
        Method method = MethodUtils.getMatchingAccessibleMethod(Animal.class, "doesNotExist");
        assertNull(method);
    }

    // ---------- getMatchingMethod ----------

    @Test
    public void testGetMatchingMethodFindsPrivateMethod() {
        Method method = MethodUtils.getMatchingMethod(Animal.class, "privateMethod");
        assertNotNull(method);
        assertEquals("privateMethod", method.getName());
    }

    @Test
    public void testGetMatchingMethodNullParameterTypesTreatedAsEmpty() {
        Method method = MethodUtils.getMatchingMethod(Animal.class, "identify", (Class<?>[]) null);
        assertNotNull(method);
        assertEquals(0, method.getParameterTypes().length);
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getMatchingMethod(null, "identify");
                    }
                });
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrowsIllegalStateException() {
        assertThrows(IllegalStateException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getMatchingMethod(Ambiguous.class, "process", Integer.class);
                    }
                });
    }

    // ---------- getMethodObject ----------

    @Test
    public void testGetMethodObjectFound() {
        Method method = MethodUtils.getMethodObject(Dog.class, "identify");
        assertNotNull(method);
        assertEquals("identify", method.getName());
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Dog.class, "doesNotExist"));
    }

    // ---------- getMethodsListWithAnnotation / getMethodsWithAnnotation (2-arg) ----------

    @Test
    public void testGetMethodsListWithAnnotationTwoArgFindsInheritedPublicMethod() {
        List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Cat.class, MarkerAnnotation.class);
        assertEquals(1, methods.size());
        assertEquals("makeSound", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsWithAnnotationTwoArgFindsInheritedPublicMethod() {
        Method[] methods = MethodUtils.getMethodsWithAnnotation(Cat.class, MarkerAnnotation.class);
        assertEquals(1, methods.length);
        assertEquals("makeSound", methods[0].getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationNullClassThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getMethodsListWithAnnotation(null, MarkerAnnotation.class);
                    }
                });
    }

    @Test
    public void testGetMethodsListWithAnnotationNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getMethodsListWithAnnotation(Cat.class, null);
                    }
                });
    }

    @Test
    public void testGetMethodsWithAnnotationNullClassThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getMethodsWithAnnotation(null, MarkerAnnotation.class);
                    }
                });
    }

    // ---------- getMethodsListWithAnnotation / getMethodsWithAnnotation (4-arg) ----------

    @Test
    public void testGetMethodsListWithAnnotationNoSupersIgnoreAccessFindsOwnPrivateOnly() {
        List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Cat.class, MarkerAnnotation.class, false, true);
        assertEquals(1, methods.size());
        assertEquals("purr", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationSearchSupersIgnoreAccessFindsBoth() {
        List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Cat.class, MarkerAnnotation.class, true, true);
        assertEquals(2, methods.size());
    }

    @Test
    public void testGetMethodsListWithAnnotationSearchSupersNoIgnoreAccessFindsOnlyPublic() {
        List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Cat.class, MarkerAnnotation.class, true, false);
        assertEquals(1, methods.size());
        assertEquals("makeSound", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsWithAnnotationNoSupersNoIgnoreAccessFindsNothing() {
        Method[] methods = MethodUtils.getMethodsWithAnnotation(Cat.class, MarkerAnnotation.class, false, false);
        assertEquals(0, methods.length);
    }

    @Test
    public void testGetMethodsListWithAnnotationFourArgNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getMethodsListWithAnnotation(Cat.class, null, true, true);
                    }
                });
    }

    // ---------- getOverrideHierarchy ----------

    @Test
    public void testGetOverrideHierarchyExcludeInterfaces() throws Exception {
        Method method = Dog.class.getMethod("identify");
        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, ClassUtils.Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        java.util.Iterator<Method> iterator = hierarchy.iterator();
        assertEquals(Dog.class, iterator.next().getDeclaringClass());
        assertEquals(Animal.class, iterator.next().getDeclaringClass());
    }

    @Test
    public void testGetOverrideHierarchyIncludeInterfaces() throws Exception {
        Method method = Dog.class.getMethod("greet");
        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, ClassUtils.Interfaces.INCLUDE);
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyExcludeInterfacesSkipsInterfaceOnlyMethod() throws Exception {
        Method method = Dog.class.getMethod("greet");
        Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, ClassUtils.Interfaces.EXCLUDE);
        assertEquals(1, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.getOverrideHierarchy(null, ClassUtils.Interfaces.EXCLUDE);
                    }
                });
    }

    // ---------- invokeExactMethod ----------

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Animal(), "identify");
        assertEquals("Animal", result);
    }

    @Test
    public void testInvokeExactMethodNoArgsUnknownThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeExactMethod(new Animal(), "doesNotExist");
                    }
                });
    }

    @Test
    public void testInvokeExactMethodWithArgs() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Animal(), "overloaded", "hello");
        assertEquals("String:hello", result);
    }

    @Test
    public void testInvokeExactMethodWithArgsNoExactPrimitiveMatchThrows() {
        assertThrows(NoSuchMethodException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeExactMethod(new Animal(), "overloaded", Integer.valueOf(5));
                    }
                });
    }

    @Test
    public void testInvokeExactMethodExplicitParameterTypes() throws Exception {
        Object result = MethodUtils.invokeExactMethod(new Animal(), "overloaded",
                new Object[] {"world"}, new Class<?>[] {String.class});
        assertEquals("String:world", result);
    }

    @Test
    public void testInvokeExactMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeExactMethod(null, "identify");
                    }
                });
    }

    @Test
    public void testInvokeExactMethodPropagatesInvocationTargetException() {
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeExactMethod(new Animal(), "throwingMethod");
                    }
                });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    // ---------- invokeExactStaticMethod ----------

    @Test
    public void testInvokeExactStaticMethodWithArgs() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Animal.class, "staticGreet", "World");
        assertEquals("Hello, World", result);
    }

    @Test
    public void testInvokeExactStaticMethodExplicitParameterTypes() throws Exception {
        Object result = MethodUtils.invokeExactStaticMethod(Animal.class, "staticGreet",
                new Object[] {"Bob"}, new Class<?>[] {String.class});
        assertEquals("Hello, Bob", result);
    }

    @Test
    public void testInvokeExactStaticMethodUnknownThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeExactStaticMethod(Animal.class, "doesNotExist");
                    }
                });
    }

    // ---------- invokeMethod (forceAccess) ----------

    @Test
    public void testInvokeMethodForceAccessTrueInvokesProtectedMethod() throws Exception {
        Object result = MethodUtils.invokeMethod(new Animal(), true, "protectedMethod");
        assertEquals("protected", result);
    }

    @Test
    public void testInvokeMethodForceAccessFalseCannotFindProtectedMethod() {
        assertThrows(NoSuchMethodException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeMethod(new Animal(), false, "protectedMethod");
                    }
                });
    }

    @Test
    public void testInvokeMethodForceAccessWithArgsMatchesByBoxing() throws Exception {
        Object result = MethodUtils.invokeMethod(new Animal(), true, "overloaded", Integer.valueOf(42));
        assertEquals("int:42", result);
    }

    @Test
    public void testInvokeMethodForceAccessExplicitParameterTypes() throws Exception {
        Object result = MethodUtils.invokeMethod(new Animal(), true, "overloaded",
                new Object[] {Integer.valueOf(7)}, new Class<?>[] {int.class});
        assertEquals("int:7", result);
    }

    // ---------- invokeMethod (no forceAccess) ----------

    @Test
    public void testInvokeMethodNoArgsUsesDynamicDispatch() throws Exception {
        Object result = MethodUtils.invokeMethod(new Dog(), "identify");
        assertEquals("Dog", result);
    }

    @Test
    public void testInvokeMethodWithArgsMatchesOverload() throws Exception {
        Object result = MethodUtils.invokeMethod(new Dog(), "overloaded", "hi");
        assertEquals("String:hi", result);
    }

    @Test
    public void testInvokeMethodExplicitParameterTypes() throws Exception {
        Object result = MethodUtils.invokeMethod(new Dog(), "overloaded",
                new Object[] {"explicit"}, new Class<?>[] {String.class});
        assertEquals("String:explicit", result);
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeMethod(null, "identify");
                    }
                });
    }

    @Test
    public void testInvokeMethodUnknownThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeMethod(new Dog(), "doesNotExist");
                    }
                });
    }

    // ---------- invokeStaticMethod ----------

    @Test
    public void testInvokeStaticMethodWithArgs() throws Exception {
        Object result = MethodUtils.invokeStaticMethod(Animal.class, "staticGreet", "Alice");
        assertEquals("Hello, Alice", result);
    }

    @Test
    public void testInvokeStaticMethodExplicitParameterTypes() throws Exception {
        Object result = MethodUtils.invokeStaticMethod(Animal.class, "staticGreet",
                new Object[] {"Carol"}, new Class<?>[] {String.class});
        assertEquals("Hello, Carol", result);
    }

    @Test
    public void testInvokeStaticMethodUnknownThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        MethodUtils.invokeStaticMethod(Animal.class, "doesNotExist");
                    }
                });
    }
}
