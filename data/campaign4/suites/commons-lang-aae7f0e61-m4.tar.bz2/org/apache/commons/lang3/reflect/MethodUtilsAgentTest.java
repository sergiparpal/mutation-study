/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface Marker {
    }

    public static class Calculator {
        public int add(final int a, final int b) {
            return a + b;
        }

        public static int staticAdd(final int a, final int b) {
            return a + b;
        }

        public String concatVarArgs(final String first, final String... rest) {
            final StringBuilder sb = new StringBuilder(first);
            for (final String s : rest) {
                sb.append(s);
            }
            return sb.toString();
        }

        public String echo(final String s) {
            return "echo:" + s;
        }

        @SuppressWarnings("unused")
        private String secret() {
            return "secret";
        }
    }

    public interface Greeter {
        @Marker
        String greet(String name);
    }

    public static class GreeterImpl implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hello, " + name;
        }

        @Marker
        public void unrelated() {
            // no-op
        }
    }

    public static class AmbiguousOverloads {
        public void foo(final Number n) {
            // no-op
        }

        public void foo(final Serializable s) {
            // no-op
        }
    }

    public static class Base {
        public String who() {
            return "Base";
        }
    }

    public static class Derived extends Base {
        @Override
        public String who() {
            return "Derived";
        }
    }

    @Test
    public void testGetAccessibleMethodNullMethod() {
        assertNull(MethodUtils.getAccessibleMethod(null, "noSuchMethod"));
    }

    @Test
    public void testGetAccessibleMethodPublicClass() throws NoSuchMethodException {
        final Method m = Calculator.class.getMethod("add", int.class, int.class);
        final Method accessible = MethodUtils.getAccessibleMethod(m);
        assertNotNull(accessible);
        assertEquals("add", accessible.getName());
    }

    @Test
    public void testGetAccessibleMethodWithNameAndParams() {
        final Method m = MethodUtils.getAccessibleMethod(Calculator.class, "echo", String.class);
        assertNotNull(m);
        assertEquals("echo", m.getName());
    }

    @Test
    public void testGetAccessibleMethodWithNameAndParamsNoSuchMethod() {
        assertNull(MethodUtils.getAccessibleMethod(Calculator.class, "doesNotExist", String.class));
    }

    @Test
    public void testGetAnnotationDirect() throws NoSuchMethodException {
        final Method m = GreeterImpl.class.getMethod("greet", String.class);
        final Marker marker = MethodUtils.getAnnotation(m, Marker.class, false, true);
        assertNull(marker, "annotation is on the interface method, not the impl method, without searchSupers");
        final Marker found = MethodUtils.getAnnotation(m, Marker.class, true, true);
        assertNotNull(found, "searchSupers should find the annotation on the interface method");
    }

    @Test
    public void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, Marker.class, true, true));
    }

    @Test
    public void testGetMatchingAccessibleMethodBoxing() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Calculator.class, "add", Integer.class, Integer.class);
        assertNotNull(m);
        assertEquals(int.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Calculator.class, "add", String.class, String.class));
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrows() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> MethodUtils.getMatchingMethod(AmbiguousOverloads.class, "foo", Integer.class));
        assertTrue(ex.getMessage().contains("multiple candidates"));
    }

    @Test
    public void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(Calculator.class, ""));
    }

    @Test
    public void testGetMatchingMethodExact() {
        final Method m = MethodUtils.getMatchingMethod(Calculator.class, "echo", String.class);
        assertNotNull(m);
        assertEquals("echo", m.getName());
    }

    @Test
    public void testGetMatchingMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(Calculator.class, "add", String.class, String.class));
    }

    @Test
    public void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "echo", String.class));
    }

    @Test
    public void testGetMethodObjectNoSuchMethodReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Calculator.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObjectNullArgumentsReturnNull() {
        assertNull(MethodUtils.getMethodObject(null, "echo", String.class));
        assertNull(MethodUtils.getMethodObject(Calculator.class, null));
    }

    @Test
    public void testGetMethodObjectValid() {
        final Method m = MethodUtils.getMethodObject(Calculator.class, "echo", String.class);
        assertNotNull(m);
        assertEquals("echo", m.getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationEmptyWhenNotPresent() {
        final List<Method> list = MethodUtils.getMethodsListWithAnnotation(Calculator.class, Marker.class);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotationFindsPublicMethod() {
        final List<Method> list = MethodUtils.getMethodsListWithAnnotation(GreeterImpl.class, Marker.class);
        assertEquals(1, list.size());
        assertEquals("unrelated", list.get(0).getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, Marker.class));
    }

    @Test
    public void testGetMethodsWithAnnotationArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(GreeterImpl.class, Marker.class);
        assertEquals(1, methods.length);
    }

    @Test
    public void testGetOverrideHierarchyIncludesBaseAndDerived() throws NoSuchMethodException {
        final Method derivedWho = Derived.class.getMethod("who");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(derivedWho, Interfaces.INCLUDE);
        assertEquals(2, hierarchy.size());
        assertTrue(hierarchy.contains(derivedWho));
    }

    @Test
    public void testGetOverrideHierarchyNullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE));
    }

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        final Calculator calc = new Calculator();
        final Method m = Calculator.class.getMethod("echo", String.class);
        final Object result = MethodUtils.invokeExactMethod(calc, "echo", new Object[] { "x" }, m.getParameterTypes());
        assertEquals("echo:x", result);
    }

    @Test
    public void testInvokeExactMethodWrongTypeThrowsNoSuchMethod() {
        final Calculator calc = new Calculator();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(calc, "echo", 42));
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Calculator.class, "staticAdd", new Object[] { 2, 3 },
                new Class<?>[] { int.class, int.class });
        assertEquals(5, result);
    }

    @Test
    public void testInvokeMethodForceAccessPrivate() throws Exception {
        final Calculator calc = new Calculator();
        final Object result = MethodUtils.invokeMethod(calc, true, "secret");
        assertEquals("secret", result);
    }

    @Test
    public void testInvokeMethodNoForceAccessPrivateThrows() {
        final Calculator calc = new Calculator();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(calc, false, "secret"));
    }

    @Test
    public void testInvokeMethodNullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "echo", "x"));
    }

    @Test
    public void testInvokeMethodNullObjectThrowsStaticVariant() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, false, "echo", "x"));
    }

    @Test
    public void testInvokeMethodUnknownMethodThrows() {
        final Calculator calc = new Calculator();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(calc, "doesNotExist", "x"));
    }

    @Test
    public void testInvokeMethodVarArgs() throws Exception {
        final Calculator calc = new Calculator();
        final Object result = MethodUtils.invokeMethod(calc, "concatVarArgs", "a", "b", "c");
        assertEquals("abc", result);
    }

    @Test
    public void testInvokeMethodWithAutoboxing() throws Exception {
        final Calculator calc = new Calculator();
        final Object result = MethodUtils.invokeMethod(calc, "add", Integer.valueOf(3), Integer.valueOf(4));
        assertEquals(7, result);
    }

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Calculator.class, "staticAdd", 10, 20);
        assertEquals(30, result);
    }

    @Test
    public void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(Calculator.class, "doesNotExist"));
    }

    @Test
    public void testThrowingMethodWrapsInInvocationTargetException() throws NoSuchMethodException {
        final Object instance = new Object() {
            @SuppressWarnings("unused")
            public void boom() {
                throw new IllegalStateException("kaboom");
            }
        };
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class, () -> MethodUtils.invokeMethod(instance, "boom"));
        assertTrue(ex.getCause() instanceof IllegalStateException);
        assertEquals("kaboom", ex.getCause().getMessage());
    }

    @Test
    public void testGetAccessibleMethodReturnsArrayAwareVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Calculator.class, "concatVarArgs", String.class, String.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    public void testArrayAssertionHelper() {
        assertArrayEquals(new Class<?>[] { int.class, int.class },
                MethodUtils.getMethodObject(Calculator.class, "add", int.class, int.class).getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleMethodVarArgsIncompatibleReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Calculator.class, "concatVarArgs", String.class, Integer.class));
    }
}
