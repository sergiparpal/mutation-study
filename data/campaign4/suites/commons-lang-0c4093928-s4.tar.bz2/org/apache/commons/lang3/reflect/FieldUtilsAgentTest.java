package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

public class FieldUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    private @interface Ann {
    }

    private static class GrandParent {
        public int gpPublic = 1;
        public static int gpStatic = 50;
    }

    private static class Parent extends GrandParent {
        protected int pProtected = 2;
        private int pPrivate = 3;
    }

    private static class Child extends Parent {
        public int cPublic = 4;
        private int cPrivate = 11;
        public static int cStatic = 5;
        private static int privateStatic = 55;
        public final int cFinal = 6;
        public static final int finalStatic = 99;
        private static final int privateStaticFinal = 7;
        @Ann
        public int annotated = 8;
        public int writableInstance = 10;
        public static int writableStatic = 20;
    }

    private static class ShadowBase {
        @SuppressWarnings("unused")
        private int shadow = 1;
    }

    private static class ShadowSub extends ShadowBase {
        @SuppressWarnings("unused")
        private int shadow = 2;
    }

    private static Set<String> names(Field[] fields) {
        Set<String> result = new HashSet<String>();
        for (Field f : fields) {
            result.add(f.getName());
        }
        return result;
    }

    // ------------------------------------------------------------------
    // constructor
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testConstructor() {
        assertNotNull(new FieldUtils());
    }

    // ------------------------------------------------------------------
    // getAllFields / getAllFieldsList
    // ------------------------------------------------------------------

    @Test
    public void testGetAllFields() {
        Field[] fields = FieldUtils.getAllFields(Child.class);
        Set<String> actual = names(fields);
        Set<String> expected = new HashSet<String>(Arrays.asList(
                "cPublic", "cPrivate", "cStatic", "privateStatic", "cFinal", "finalStatic",
                "privateStaticFinal", "annotated", "writableInstance", "writableStatic",
                "pProtected", "pPrivate", "gpPublic", "gpStatic"));
        assertEquals(expected.size(), fields.length);
        assertEquals(expected, actual);
    }

    @Test
    public void testGetAllFieldsEmptyForObjectLikeClass() {
        Field[] fields = FieldUtils.getAllFields(GrandParent.class);
        assertEquals(2, fields.length);
    }

    @Test
    public void testGetAllFieldsNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getAllFields(null);
            }
        });
    }

    @Test
    public void testGetAllFieldsList() {
        List<Field> fields = FieldUtils.getAllFieldsList(Child.class);
        Set<String> actual = new HashSet<String>();
        for (Field f : fields) {
            actual.add(f.getName());
        }
        assertEquals(14, fields.size());
        assertTrue(actual.contains("cPublic"));
        assertTrue(actual.contains("gpStatic"));
    }

    @Test
    public void testGetAllFieldsListNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getAllFieldsList(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // getDeclaredField
    // ------------------------------------------------------------------

    @Test
    public void testGetDeclaredFieldPublic() {
        Field field = FieldUtils.getDeclaredField(Child.class, "cPublic");
        assertNotNull(field);
        assertEquals("cPublic", field.getName());
        assertEquals(Child.class, field.getDeclaringClass());
    }

    @Test
    public void testGetDeclaredFieldDoesNotConsiderParents() {
        Field field = FieldUtils.getDeclaredField(Child.class, "gpPublic");
        assertNull(field);
    }

    @Test
    public void testGetDeclaredFieldPrivateWithoutForceAccess() {
        Field field = FieldUtils.getDeclaredField(Child.class, "cPrivate");
        assertNull(field);
    }

    @Test
    public void testGetDeclaredFieldPrivateWithForceAccess() {
        Field field = FieldUtils.getDeclaredField(Child.class, "cPrivate", true);
        assertNotNull(field);
        assertEquals("cPrivate", field.getName());
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetDeclaredFieldNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getDeclaredField(null, "x");
            }
        });
    }

    @Test
    public void testGetDeclaredFieldBlankName() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getDeclaredField(Child.class, " ");
            }
        });
    }

    @Test
    public void testGetDeclaredFieldNullName() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getDeclaredField(Child.class, null);
            }
        });
    }

    // ------------------------------------------------------------------
    // getField
    // ------------------------------------------------------------------

    @Test
    public void testGetFieldConsidersSuperclasses() {
        Field field = FieldUtils.getField(Child.class, "gpPublic");
        assertNotNull(field);
        assertEquals(GrandParent.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldProtectedWithoutForceAccess() {
        Field field = FieldUtils.getField(Child.class, "pProtected");
        assertNull(field);
    }

    @Test
    public void testGetFieldProtectedWithForceAccess() {
        Field field = FieldUtils.getField(Child.class, "pProtected", true);
        assertNotNull(field);
        assertEquals(Parent.class, field.getDeclaringClass());
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetFieldAmbiguousShadowedField() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getField(ShadowSub.class, "shadow", true);
            }
        });
    }

    @Test
    public void testGetFieldNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getField(null, "x");
            }
        });
    }

    @Test
    public void testGetFieldBlankName() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getField(Child.class, "");
            }
        });
    }

    // ------------------------------------------------------------------
    // getFieldsWithAnnotation / getFieldsListWithAnnotation
    // ------------------------------------------------------------------

    @Test
    public void testGetFieldsWithAnnotation() {
        Field[] fields = FieldUtils.getFieldsWithAnnotation(Child.class, Ann.class);
        assertEquals(1, fields.length);
        assertEquals("annotated", fields[0].getName());
    }

    @Test
    public void testGetFieldsWithAnnotationNoneFound() {
        Field[] fields = FieldUtils.getFieldsWithAnnotation(GrandParent.class, Ann.class);
        assertEquals(0, fields.length);
    }

    @Test
    public void testGetFieldsWithAnnotationNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getFieldsWithAnnotation(null, Ann.class);
            }
        });
    }

    @Test
    public void testGetFieldsWithAnnotationNullAnnotation() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getFieldsWithAnnotation(Child.class, null);
            }
        });
    }

    @Test
    public void testGetFieldsListWithAnnotation() {
        List<Field> fields = FieldUtils.getFieldsListWithAnnotation(Child.class, Ann.class);
        assertEquals(1, fields.size());
        assertEquals("annotated", fields.get(0).getName());
    }

    @Test
    public void testGetFieldsListWithAnnotationNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.getFieldsListWithAnnotation(null, Ann.class);
            }
        });
    }

    // ------------------------------------------------------------------
    // readDeclaredField
    // ------------------------------------------------------------------

    @Test
    public void testReadDeclaredField() throws IllegalAccessException {
        Child target = new Child();
        assertEquals(4, FieldUtils.readDeclaredField(target, "cPublic"));
    }

    @Test
    public void testReadDeclaredFieldNotPublic() {
        final Child target = new Child();
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredField(target, "cPrivate");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldNotDeclaredInTargetClass() {
        final Child target = new Child();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredField(target, "gpPublic");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldNullTarget() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredField(null, "x");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldBlankName() {
        final Child target = new Child();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredField(target, "");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldWithForceAccess() throws IllegalAccessException {
        Child target = new Child();
        assertEquals(11, FieldUtils.readDeclaredField(target, "cPrivate", true));
    }

    // ------------------------------------------------------------------
    // readDeclaredStaticField
    // ------------------------------------------------------------------

    @Test
    public void testReadDeclaredStaticField() throws IllegalAccessException {
        assertEquals(5, FieldUtils.readDeclaredStaticField(Child.class, "cStatic"));
    }

    @Test
    public void testReadDeclaredStaticFieldNotStatic() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredStaticField(Child.class, "cPublic");
            }
        });
    }

    @Test
    public void testReadDeclaredStaticFieldNotFound() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredStaticField(Child.class, "doesNotExist");
            }
        });
    }

    @Test
    public void testReadDeclaredStaticFieldNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredStaticField(null, "x");
            }
        });
    }

    @Test
    public void testReadDeclaredStaticFieldWithForceAccess() throws IllegalAccessException {
        assertEquals(7, FieldUtils.readDeclaredStaticField(Child.class, "privateStaticFinal", true));
    }

    @Test
    public void testReadDeclaredStaticFieldNotPublicWithoutForceAccess() {
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readDeclaredStaticField(Child.class, "privateStatic");
            }
        });
    }

    // ------------------------------------------------------------------
    // readField(Field, Object[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testReadFieldAccessiblePublic() throws Exception {
        Field field = Child.class.getField("cPublic");
        Child target = new Child();
        assertEquals(4, FieldUtils.readField(field, target));
    }

    @Test
    public void testReadFieldNotAccessible() throws Exception {
        final Field field = Child.class.getDeclaredField("cPrivate");
        final Child target = new Child();
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readField(field, target);
            }
        });
    }

    @Test
    public void testReadFieldNullField() {
        final Child target = new Child();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readField((Field) null, target);
            }
        });
    }

    @Test
    public void testReadFieldWithForceAccessMakesAccessible() throws Exception {
        Field field = Child.class.getDeclaredField("cPrivate");
        Child target = new Child();
        assertEquals(11, FieldUtils.readField(field, target, true));
        assertTrue(field.isAccessible());
    }

    @Test
    public void testReadFieldStaticAllowsNullTarget() throws Exception {
        Field field = Child.class.getField("cStatic");
        assertEquals(5, FieldUtils.readField(field, (Object) null));
    }

    // ------------------------------------------------------------------
    // readField(Object, String[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testReadFieldByNameConsidersSuperclasses() throws IllegalAccessException {
        Child target = new Child();
        assertEquals(1, FieldUtils.readField(target, "gpPublic"));
    }

    @Test
    public void testReadFieldByNameNotAccessible() {
        final Child target = new Child();
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readField(target, "pProtected");
            }
        });
    }

    @Test
    public void testReadFieldByNameWithForceAccess() throws IllegalAccessException {
        Child target = new Child();
        assertEquals(2, FieldUtils.readField(target, "pProtected", true));
    }

    @Test
    public void testReadFieldByNameNotFound() {
        final Child target = new Child();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readField(target, "doesNotExist");
            }
        });
    }

    @Test
    public void testReadFieldByNameNullTarget() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readField((Object) null, "x");
            }
        });
    }

    // ------------------------------------------------------------------
    // readStaticField(Class, String[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testReadStaticFieldByClassAndName() throws IllegalAccessException {
        assertEquals(5, FieldUtils.readStaticField(Child.class, "cStatic"));
    }

    @Test
    public void testReadStaticFieldByClassAndNameConsidersSuperclasses() throws IllegalAccessException {
        assertEquals(50, FieldUtils.readStaticField(Child.class, "gpStatic"));
    }

    @Test
    public void testReadStaticFieldByClassAndNameNotStatic() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readStaticField(Child.class, "cPublic");
            }
        });
    }

    @Test
    public void testReadStaticFieldByClassAndNameNotFound() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readStaticField(Child.class, "doesNotExist");
            }
        });
    }

    @Test
    public void testReadStaticFieldByClassAndNameWithForceAccess() throws IllegalAccessException {
        assertEquals(55, FieldUtils.readStaticField(Child.class, "privateStatic", true));
    }

    @Test
    public void testReadStaticFieldByClassAndNameNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readStaticField(null, "x");
            }
        });
    }

    // ------------------------------------------------------------------
    // readStaticField(Field[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testReadStaticFieldByField() throws Exception {
        Field field = Child.class.getField("cStatic");
        assertEquals(5, FieldUtils.readStaticField(field));
    }

    @Test
    public void testReadStaticFieldByFieldNotStatic() throws Exception {
        final Field field = Child.class.getField("cPublic");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readStaticField(field);
            }
        });
    }

    @Test
    public void testReadStaticFieldByFieldNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readStaticField(null);
            }
        });
    }

    @Test
    public void testReadStaticFieldByFieldNotAccessible() throws Exception {
        final Field field = Child.class.getDeclaredField("privateStatic");
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.readStaticField(field);
            }
        });
    }

    @Test
    public void testReadStaticFieldByFieldWithForceAccess() throws Exception {
        Field field = Child.class.getDeclaredField("privateStatic");
        assertEquals(55, FieldUtils.readStaticField(field, true));
    }

    // ------------------------------------------------------------------
    // removeFinalModifier
    // ------------------------------------------------------------------

    @Test
    public void testRemoveFinalModifier() throws Exception {
        Field field = Child.class.getDeclaredField("cFinal");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @Test
    public void testRemoveFinalModifierNullField() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.removeFinalModifier(null);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRemoveFinalModifierDeprecatedOverload() throws Exception {
        Field field = Child.class.getDeclaredField("finalStatic");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field, true);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRemoveFinalModifierDeprecatedOverloadNullField() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FieldUtils.removeFinalModifier(null, true);
            }
        });
    }

    // ------------------------------------------------------------------
    // setAccessible (package-private)
    // ------------------------------------------------------------------

    @Test
    public void testSetAccessibleForceTrueOnPrivateField() throws Exception {
        Field field = Child.class.getDeclaredField("cPrivate");
        assertFalse(field.isAccessible());
        Field result = FieldUtils.setAccessible(field, true);
        assertNotNull(result);
        assertEquals("cPrivate", result.getName());
        assertTrue(field.isAccessible());
    }

    @Test
    public void testSetAccessibleForceFalseOnPublicField() throws Exception {
        Field field = Child.class.getField("cPublic");
        Field result = FieldUtils.setAccessible(field, false);
        assertNotNull(result);
        assertEquals("cPublic", result.getName());
    }

    // ------------------------------------------------------------------
    // writeDeclaredField
    // ------------------------------------------------------------------

    @Test
    public void testWriteDeclaredField() throws IllegalAccessException {
        Child target = new Child();
        FieldUtils.writeDeclaredField(target, "writableInstance", 123);
        assertEquals(123, target.writableInstance);
    }

    @Test
    public void testWriteDeclaredFieldNotPublic() {
        final Child target = new Child();
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredField(target, "cPrivate", 1);
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldNotAssignable() {
        final Child target = new Child();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredField(target, "writableInstance", "notAnInt");
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldNullTarget() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredField(null, "x", 1);
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldWithForceAccess() throws IllegalAccessException {
        Child target = new Child();
        FieldUtils.writeDeclaredField(target, "cPrivate", 42, true);
        assertEquals(42, target.cPrivate);
    }

    // ------------------------------------------------------------------
    // writeDeclaredStaticField
    // ------------------------------------------------------------------

    @Test
    public void testWriteDeclaredStaticField() throws IllegalAccessException {
        FieldUtils.writeDeclaredStaticField(Child.class, "writableStatic", 321);
        assertEquals(321, Child.writableStatic);
    }

    @Test
    public void testWriteDeclaredStaticFieldNotStatic() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredStaticField(Child.class, "writableInstance", 1);
            }
        });
    }

    @Test
    public void testWriteDeclaredStaticFieldNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredStaticField(null, "x", 1);
            }
        });
    }

    @Test
    public void testWriteDeclaredStaticFieldNotPublic() {
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredStaticField(Child.class, "privateStatic", 1);
            }
        });
    }

    @Test
    public void testWriteDeclaredStaticFieldWithForceAccess() throws IllegalAccessException {
        FieldUtils.writeDeclaredStaticField(Child.class, "privateStatic", 777, true);
        assertEquals(777, Child.privateStatic);
    }

    // ------------------------------------------------------------------
    // writeField(Field, Object, Object[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testWriteFieldByFieldAccessible() throws Exception {
        Field field = Child.class.getField("writableInstance");
        Child target = new Child();
        FieldUtils.writeField(field, target, 55);
        assertEquals(55, target.writableInstance);
    }

    @Test
    public void testWriteFieldByFieldNotAssignable() throws Exception {
        final Field field = Child.class.getField("writableInstance");
        final Child target = new Child();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeField(field, target, "nope");
            }
        });
    }

    @Test
    public void testWriteFieldByFieldFinal() throws Exception {
        final Field field = Child.class.getField("cFinal");
        final Child target = new Child();
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeField(field, target, 999);
            }
        });
    }

    @Test
    public void testWriteFieldByFieldNullField() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeField(null, new Child(), 1);
            }
        });
    }

    @Test
    public void testWriteFieldByFieldWithForceAccess() throws Exception {
        Field field = Child.class.getDeclaredField("cPrivate");
        Child target = new Child();
        FieldUtils.writeField(field, target, 88, true);
        assertEquals(88, target.cPrivate);
    }

    @Test
    public void testWriteFieldByFieldStaticAllowsNullTarget() throws Exception {
        Field field = Child.class.getField("writableStatic");
        FieldUtils.writeField(field, (Object) null, 404);
        assertEquals(404, Child.writableStatic);
    }

    // ------------------------------------------------------------------
    // writeField(Object, String, Object[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testWriteFieldByNameConsidersSuperclasses() throws IllegalAccessException {
        Child target = new Child();
        FieldUtils.writeField(target, "gpPublic", 777);
        assertEquals(777, target.gpPublic);
    }

    @Test
    public void testWriteFieldByNameNotAccessible() {
        final Child target = new Child();
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeField(target, "pProtected", 1);
            }
        });
    }

    @Test
    public void testWriteFieldByNameWithForceAccess() throws IllegalAccessException {
        Child target = new Child();
        FieldUtils.writeField(target, "pProtected", 66, true);
        assertEquals(66, target.pProtected);
    }

    @Test
    public void testWriteFieldByNameNullTarget() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeField((Object) null, "x", 1);
            }
        });
    }

    @Test
    public void testWriteFieldByNameNotFound() {
        final Child target = new Child();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeField(target, "doesNotExist", 1);
            }
        });
    }

    // ------------------------------------------------------------------
    // writeStaticField(Class, String, Object[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testWriteStaticFieldByClassAndName() throws IllegalAccessException {
        FieldUtils.writeStaticField(Child.class, "writableStatic", 909);
        assertEquals(909, Child.writableStatic);
    }

    @Test
    public void testWriteStaticFieldByClassAndNameNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(null, "x", 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldByClassAndNameNotStatic() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(Child.class, "writableInstance", 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldByClassAndNameWithForceAccess() throws IllegalAccessException {
        FieldUtils.writeStaticField(Child.class, "privateStatic", 606, true);
        assertEquals(606, Child.privateStatic);
    }

    @Test
    public void testWriteStaticFieldByClassAndNameNotFoundWithForceAccess() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(Child.class, "doesNotExist", 1, true);
            }
        });
    }

    // ------------------------------------------------------------------
    // writeStaticField(Field, Object[, boolean])
    // ------------------------------------------------------------------

    @Test
    public void testWriteStaticFieldByField() throws Exception {
        Field field = Child.class.getField("writableStatic");
        FieldUtils.writeStaticField(field, 111);
        assertEquals(111, Child.writableStatic);
    }

    @Test
    public void testWriteStaticFieldByFieldNotStatic() throws Exception {
        final Field field = Child.class.getField("writableInstance");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(field, 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldByFieldNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(null, 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldByFieldFinal() throws Exception {
        final Field field = Child.class.getField("finalStatic");
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(field, 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldByFieldWithForceAccess() throws Exception {
        Field field = Child.class.getDeclaredField("privateStatic");
        FieldUtils.writeStaticField(field, 222, true);
        assertEquals(222, Child.privateStatic);
    }
}
