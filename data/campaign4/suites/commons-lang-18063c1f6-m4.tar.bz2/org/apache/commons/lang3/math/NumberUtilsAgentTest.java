/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testConstructor() {
        assertNotNull(new NumberUtils());
    }

    @Test
    void testCompare() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);

        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);

        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);

        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        try {
            NumberUtils.createBigDecimal("");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(10), NumberUtils.createBigInteger("10"));
        assertEquals(BigInteger.valueOf(-10), NumberUtils.createBigInteger("-10"));
        assertEquals(BigInteger.valueOf(10), NumberUtils.createBigInteger("+10"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        try {
            NumberUtils.createBigInteger("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigInteger("--1");
            fail("Expected NumberFormatException for double sign");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(1.5d, NumberUtils.createDouble("1.5").doubleValue(), 0.0d);
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(1.5f, NumberUtils.createFloat("1.5").floatValue(), 0.0f);
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(26, NumberUtils.createInteger("0x1A").intValue());
        assertEquals(8, NumberUtils.createInteger("010").intValue());
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(26L, NumberUtils.createLong("0x1A").longValue());
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("  ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberIntegral() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertEquals(Integer.valueOf(-12345), NumberUtils.createNumber("-12345"));
        assertTrue(NumberUtils.createNumber("12345") instanceof Integer);
        assertEquals(Long.valueOf(3147483647L), NumberUtils.createNumber("3147483647"));
        assertTrue(NumberUtils.createNumber("3147483647") instanceof Long);
        final String biggerThanLong = "123456789012345678901234567890";
        assertEquals(new BigInteger(biggerThanLong), NumberUtils.createNumber(biggerThanLong));
        assertTrue(NumberUtils.createNumber(biggerThanLong) instanceof BigInteger);
    }

    @Test
    void testCreateNumberTypeQualifiers() {
        assertEquals(Long.valueOf(1L), NumberUtils.createNumber("1L"));
        assertTrue(NumberUtils.createNumber("1L") instanceof Long);
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5F"));
        assertTrue(NumberUtils.createNumber("1.5F") instanceof Float);
        assertEquals(Double.valueOf(1.5d), NumberUtils.createNumber("1.5D"));
        assertTrue(NumberUtils.createNumber("1.5D") instanceof Double);
        try {
            NumberUtils.createNumber("1.5L");
            fail("Expected NumberFormatException for decimal with 'L' suffix");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberHex() {
        assertEquals(Integer.valueOf(26), NumberUtils.createNumber("0x1A"));
        assertTrue(NumberUtils.createNumber("0x1A") instanceof Integer);
        assertEquals(Long.valueOf(26L), NumberUtils.createNumber("0x1AL"));
        assertTrue(NumberUtils.createNumber("0x1AL") instanceof Long);
        // more than 8 hex digits => Long
        assertTrue(NumberUtils.createNumber("0x123456789") instanceof Long);
        // more than 16 hex digits => BigInteger
        assertTrue(NumberUtils.createNumber("0x12345678901234567") instanceof BigInteger);
    }

    @Test
    void testCreateNumberFloatingPoint() {
        final Number result = NumberUtils.createNumber("1.5");
        assertEquals(1.5d, result.doubleValue(), 0.0d);
        assertTrue(result instanceof Float || result instanceof Double);
        final Number bigDecimalResult = NumberUtils.createNumber("1.23456789012345678901234567890123456789");
        assertTrue(bigDecimalResult instanceof BigDecimal);
    }

    @Test
    void testCreateNumberInvalid() {
        try {
            NumberUtils.createNumber("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("1.2.3");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("--1");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertTrue(NumberUtils.isCreatable("1"));
        assertTrue(NumberUtils.isCreatable("1.5"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("not a number"));
        assertFalse(NumberUtils.isCreatable("--1"));
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    @Test
    void testIsNumberDeprecated() {
        assertEquals(NumberUtils.isCreatable("1"), NumberUtils.isNumber("1"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber(null));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("1"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("1.5e-5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("1.5L"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxByteThreeParam() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 2, (byte) 1));
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(42.0d, NumberUtils.max(1.0d, 42.0d, -5.0d), 0.0d);
        final double[] withNaN = { 1.0d, Double.NaN, 3.0d };
        assertTrue(Double.isNaN(NumberUtils.max(withNaN)));
        try {
            NumberUtils.max((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxDoubleThreeParam() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 2.0d, 3.0d), 0.0d);
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(42.0f, NumberUtils.max(1.0f, 42.0f, -5.0f), 0.0f);
        final float[] withNaN = { 1.0f, Float.NaN, 3.0f };
        assertTrue(Float.isNaN(NumberUtils.max(withNaN)));
        try {
            NumberUtils.max((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxFloatThreeParam() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f), 0.0f);
    }

    @Test
    void testMaxIntArray() {
        assertEquals(42, NumberUtils.max(1, 42, -5));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxIntThreeParam() {
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 1, 2));
        assertEquals(3, NumberUtils.max(1, 3, 2));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(42L, NumberUtils.max(1L, 42L, -5L));
        try {
            NumberUtils.max((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxLongThreeParam() {
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 42, NumberUtils.max((short) 1, (short) 42, (short) -5));
        try {
            NumberUtils.max((short[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxShortThreeParam() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) -5, NumberUtils.min((byte) 1, (byte) 42, (byte) -5));
        try {
            NumberUtils.min((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinByteThreeParam() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 2, (byte) 1));
        assertEquals((byte) 1, NumberUtils.min((byte) 2, (byte) 1, (byte) 3));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(-5.0d, NumberUtils.min(1.0d, 42.0d, -5.0d), 0.0d);
        final double[] withNaN = { 1.0d, Double.NaN, 3.0d };
        assertTrue(Double.isNaN(NumberUtils.min(withNaN)));
        try {
            NumberUtils.min((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinDoubleThreeParam() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 2.0d, 3.0d), 0.0d);
    }

    @Test
    void testMinFloatArray() {
        assertEquals(-5.0f, NumberUtils.min(1.0f, 42.0f, -5.0f), 0.0f);
        final float[] withNaN = { 1.0f, Float.NaN, 3.0f };
        assertTrue(Float.isNaN(NumberUtils.min(withNaN)));
        try {
            NumberUtils.min((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinFloatThreeParam() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f), 0.0f);
    }

    @Test
    void testMinIntArray() {
        assertEquals(-5, NumberUtils.min(1, 42, -5));
        try {
            NumberUtils.min((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinIntThreeParam() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
        assertEquals(1, NumberUtils.min(2, 1, 3));
    }

    @Test
    void testMinLongArray() {
        assertEquals(-5L, NumberUtils.min(1L, 42L, -5L));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinLongThreeParam() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) -5, NumberUtils.min((short) 1, (short) 42, (short) -5));
        try {
            NumberUtils.min((short[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinShortThreeParam() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(9.9d, NumberUtils.toDouble("not a double", 9.9d), 0.0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(9.9f, NumberUtils.toFloat("not a float", 9.9f), 0.0f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not an int", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a long", 9L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a short", (short) 9));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.230"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.23"), 3, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.HALF_UP));
        assertNotNull(NumberUtils.toScaledBigDecimal(Float.valueOf(1.23f)));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.230"), NumberUtils.toScaledBigDecimal("1.23", 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalNullRoundingModeDefaultsToHalfEven() {
        assertEquals(new BigDecimal("2.5"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 1, null));
    }
}
