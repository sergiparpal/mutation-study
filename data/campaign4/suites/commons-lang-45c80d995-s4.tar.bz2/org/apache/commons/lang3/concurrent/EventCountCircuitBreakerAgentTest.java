package org.apache.commons.lang3.concurrent;

import org.junit.jupiter.api.Test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link EventCountCircuitBreaker}, based on the documented contract.
 */
public class EventCountCircuitBreakerAgentTest {

    /**
     * Subclass that replaces the package-private {@code nanoTime()} hook with a fully
     * controllable clock so that interval based transitions can be tested deterministically.
     */
    private static final class FakeClockBreaker extends EventCountCircuitBreaker {

        private long time;

        FakeClockBreaker(final int threshold, final long checkInterval, final TimeUnit checkUnit) {
            super(threshold, checkInterval, checkUnit);
        }

        FakeClockBreaker(final int openingThreshold, final long checkInterval, final TimeUnit checkUnit,
                final int closingThreshold) {
            super(openingThreshold, checkInterval, checkUnit, closingThreshold);
        }

        @Override
        long nanoTime() {
            return time;
        }

        void setTime(final long newTime) {
            time = newTime;
        }
    }

    // ------------------------------------------------------------------
    // Constructors / getters
    // ------------------------------------------------------------------

    @Test
    public void testThreeArgConstructorUsesSameThresholdAndInterval() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 1, TimeUnit.SECONDS);

        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(10, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getClosingInterval());
    }

    @Test
    public void testFourArgConstructorUsesSameIntervalDifferentThresholds() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 1, TimeUnit.SECONDS, 5);

        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getClosingInterval());
    }

    @Test
    public void testSixArgConstructorUsesIndependentThresholdsAndIntervals() {
        final EventCountCircuitBreaker breaker =
                new EventCountCircuitBreaker(10, 500, TimeUnit.MILLISECONDS, 5, 2, TimeUnit.MINUTES);

        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(500), breaker.getOpeningInterval());
        assertEquals(TimeUnit.MINUTES.toNanos(2), breaker.getClosingInterval());
    }

    // ------------------------------------------------------------------
    // Initial state
    // ------------------------------------------------------------------

    @Test
    public void testNewlyCreatedBreakerIsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
    }

    // ------------------------------------------------------------------
    // checkState() / incrementAndCheckState() happy path
    // ------------------------------------------------------------------

    @Test
    public void testCheckStateWithoutEventsStaysClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        final boolean result = breaker.checkState();

        assertTrue(result);
        assertEquals(breaker.isClosed(), result);
        assertTrue(breaker.isClosed());
    }

    @Test
    public void testIncrementAndCheckStateReturnValueMatchesIsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(1000, 1, TimeUnit.HOURS);

        final boolean result = breaker.incrementAndCheckState();

        assertEquals(breaker.isClosed(), result);
        assertEquals(!breaker.isOpen(), result);
    }

    // ------------------------------------------------------------------
    // Negative increment is rejected
    // ------------------------------------------------------------------

    @Test
    public void testIncrementAndCheckStateRejectsNegativeIncrement() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                breaker.incrementAndCheckState(Integer.valueOf(-1));
            }
        });

        // Rejecting the increment must not have altered the observable state.
        assertTrue(breaker.isClosed());
    }

    @Test
    public void testIncrementAndCheckStateAcceptsZeroIncrement() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        final boolean result = breaker.incrementAndCheckState(Integer.valueOf(0));

        assertTrue(result);
        assertTrue(breaker.isClosed());
    }

    @Test
    public void testIncrementAndCheckStateAcceptsLargePositiveIncrementWithoutThrowing() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS, 1, 1, TimeUnit.HOURS);

        final boolean result = breaker.incrementAndCheckState(Integer.valueOf(Integer.MAX_VALUE));

        // No exception for a large, but legal, increment; the return value must always
        // be consistent with the resulting observable state.
        assertEquals(breaker.isClosed(), result);
        assertEquals(!breaker.isOpen(), result);
    }

    // ------------------------------------------------------------------
    // Manual open()/close() and idempotency
    // ------------------------------------------------------------------

    @Test
    public void testOpenChangesStateToOpen() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        breaker.open();

        assertTrue(breaker.isOpen());
        assertFalse(breaker.isClosed());
    }

    @Test
    public void testCloseChangesStateToClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        breaker.open();

        breaker.close();

        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
    }

    @Test
    public void testCloseOnAlreadyClosedBreakerHasNoEffect() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        breaker.close();

        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
    }

    @Test
    public void testOpenOnAlreadyOpenBreakerHasNoEffect() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        breaker.open();

        breaker.open();

        assertTrue(breaker.isOpen());
        assertFalse(breaker.isClosed());
    }

    // ------------------------------------------------------------------
    // Change listener notifications
    // ------------------------------------------------------------------

    private static final class RecordingListener implements PropertyChangeListener {
        private int notificationCount;
        private String lastPropertyName;

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            notificationCount++;
            lastPropertyName = evt.getPropertyName();
        }
    }

    @Test
    public void testAddChangeListenerIsNotifiedOnActualStateTransition() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);

        breaker.open();

        assertEquals(1, listener.notificationCount);
        assertEquals(EventCountCircuitBreaker.PROPERTY_NAME, listener.lastPropertyName);
    }

    @Test
    public void testListenerIsNotNotifiedWhenStateDoesNotActuallyChange() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        breaker.open();
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);

        // Breaker is already open: per the documented contract this call has no effect,
        // so no state transition occurs and the listener must not be notified.
        breaker.open();

        assertEquals(0, listener.notificationCount);
    }

    @Test
    public void testRemoveChangeListenerStopsNotifications() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);
        breaker.open();
        assertEquals(1, listener.notificationCount);

        breaker.removeChangeListener(listener);
        breaker.close();

        assertEquals(1, listener.notificationCount);
        assertTrue(breaker.isClosed());
    }

    // ------------------------------------------------------------------
    // nanoTime()
    // ------------------------------------------------------------------

    @Test
    public void testNanoTimeReflectsCurrentTime() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);

        final long before = System.nanoTime();
        final long reported = breaker.nanoTime();
        final long after = System.nanoTime();

        assertTrue(reported >= before);
        assertTrue(reported <= after);
    }

    // ------------------------------------------------------------------
    // Deterministic interval based transitions using a controllable clock
    // ------------------------------------------------------------------

    @Test
    public void testBreakerOpensAfterExceedingOpeningThresholdInInterval() {
        final FakeClockBreaker breaker = new FakeClockBreaker(2, 1000, TimeUnit.NANOSECONDS, 100);
        breaker.setTime(0L);

        // Events arriving well within the still-running first check interval must not
        // trigger any state change, however many of them are recorded.
        breaker.setTime(200L);
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.isClosed());

        // Advance well past the check interval: the accumulated event count (3 or 4,
        // depending on whether this call's own increment is counted against the elapsed
        // interval) is in both cases greater than the opening threshold of 2, so the
        // breaker must open.
        breaker.setTime(5000L);
        final boolean result = breaker.incrementAndCheckState();

        assertFalse(result);
        assertTrue(breaker.isOpen());
        assertFalse(breaker.isClosed());
    }

    @Test
    public void testBreakerClosesAfterGoingBelowClosingThresholdInInterval() {
        final FakeClockBreaker breaker = new FakeClockBreaker(2, 1000, TimeUnit.NANOSECONDS, 100);
        breaker.setTime(0L);
        breaker.setTime(5000L);
        breaker.incrementAndCheckState();
        breaker.incrementAndCheckState();
        breaker.incrementAndCheckState();
        breaker.setTime(10000L);
        breaker.incrementAndCheckState();
        assertTrue(breaker.isOpen());

        // While staying well inside the newly started check interval, the breaker must
        // remain open no matter how many checks are performed.
        breaker.setTime(10200L);
        assertFalse(breaker.checkState());
        assertFalse(breaker.checkState());
        assertTrue(breaker.isOpen());

        // Advance past the closing interval without recording further events: the event
        // count observed in that interval (0 or at most a handful) is far below the
        // closing threshold of 100, so the breaker must close again.
        breaker.setTime(20000L);
        final boolean result = breaker.checkState();

        assertTrue(result);
        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
    }
}
