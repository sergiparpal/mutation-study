package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.builder.Builder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link StrBuilder}, based solely on its published javadoc contract.
 */
public class StrBuilderAgentTest {

    // ---------------------------------------------------------------
    // Construction
    // ---------------------------------------------------------------

    @Test
    public void testDefaultConstructor() {
        StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertTrue(sb.isEmpty());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructorPositive() {
        StrBuilder sb = new StrBuilder(50);
        assertEquals(50, sb.capacity());
        assertEquals(0, sb.length());
    }

    @Test
    public void testCapacityConstructorNonPositiveConvertedTo32() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
    }

    @Test
    public void testStringConstructor() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.toString());
        assertEquals(5, sb.length());
        assertEquals(5 + 32, sb.capacity());
    }

    @Test
    public void testStringConstructorNullTreatedAsBlank() {
        StrBuilder sb = new StrBuilder((String) null);
        assertEquals("", sb.toString());
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
    }

    // ---------------------------------------------------------------
    // append - primitives
    // ---------------------------------------------------------------

    @Test
    public void testAppendPrimitives() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append(true).append(' ').append(false).append(' ')
                .append(1).append(' ').append(2L).append(' ').append(1.5f).append(' ').append(2.5d);
        assertSame(sb, result);
        assertEquals("true false 1 2 1.5 2.5", sb.toString());
    }

    @Test
    public void testAppendChar() {
        StrBuilder sb = new StrBuilder();
        assertSame(sb, sb.append('x'));
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayNullAppendsNothingByDefault() {
        StrBuilder sb = new StrBuilder("x");
        sb.append((char[]) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd', 'e'}, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendCharBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("abc".toCharArray()));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("abcde".toCharArray()), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendCharSequence() {
        StrBuilder sb = new StrBuilder();
        CharSequence seq = "abc";
        sb.append(seq);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        StrBuilder sb = new StrBuilder();
        CharSequence seq = "abcde";
        sb.append(seq, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendObjectNullAppendsNothingByDefault() {
        StrBuilder sb = new StrBuilder("x");
        sb.append((Object) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendObjectWithNullTextSet() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendString() {
        StrBuilder sb = new StrBuilder();
        sb.append("abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringNullAppendsNothingByDefault() {
        StrBuilder sb = new StrBuilder("x");
        sb.append((String) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendStringRange() {
        StrBuilder sb = new StrBuilder();
        sb.append("abcde", 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStringFormat() {
        StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 1);
        assertEquals("x-1", sb.toString());
    }

    @Test
    public void testAppendStringBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBufferRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abcde"), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStringBuilder() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBuilderRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abcde"), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("abcde"), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendReturnsThisForChaining() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append("a").append("b");
        assertSame(sb, result);
    }

    // ---------------------------------------------------------------
    // appendAll / appendWithSeparators
    // ---------------------------------------------------------------

    @Test
    public void testAppendAllIterable() {
        StrBuilder sb = new StrBuilder();
        List<String> list = Arrays.asList(new String[] {"a", "b", "c"});
        sb.appendAll(list);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterableNullHasNoEffect() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendAll((Iterable<?>) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        StrBuilder sb = new StrBuilder();
        List<String> list = Arrays.asList(new String[] {"a", "b", "c"});
        sb.appendAll(list.iterator());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIteratorNullHasNoEffect() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendAll((java.util.Iterator<?>) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllArrayNullHasNoEffect() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendAll((Object[]) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        StrBuilder sb = new StrBuilder();
        List<String> list = Arrays.asList(new String[] {"a", "b", "c"});
        sb.appendWithSeparators(list, ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparatorMeansNone() {
        StrBuilder sb = new StrBuilder();
        List<String> list = Arrays.asList(new String[] {"a", "b", "c"});
        sb.appendWithSeparators(list, null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        StrBuilder sb = new StrBuilder();
        List<String> list = Arrays.asList(new String[] {"a", "b", "c"});
        sb.appendWithSeparators(list.iterator(), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendFixedWidthPadLeft / appendFixedWidthPadRight
    // ---------------------------------------------------------------

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(12, 5, '0');
        assertEquals("00012", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncatesLeftSide() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(123456, 3, '0');
        assertEquals("456", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftWidthZeroOrNegativeHasNoEffect() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(12, 0, '0');
        assertEquals("", sb.toString());
        sb.appendFixedWidthPadLeft(12, -1, '0');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendFixedWidthPadLeft(null, 6, ' ');
        assertEquals("  NULL", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(12, 5, '0');
        assertEquals("12000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncatesRightSide() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(123456, 3, '0');
        assertEquals("123", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendFixedWidthPadRight(null, 6, ' ');
        assertEquals("NULL  ", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendln / appendNewLine / appendNull / appendPadding
    // ---------------------------------------------------------------

    @Test
    public void testAppendlnAppendsNewLineThenValue() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("|");
        sb.append("a");
        sb.appendln("b");
        assertEquals("a|b", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultUsesSystemLineSeparator() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineUsesCustomNewLineText() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        assertEquals("<br>", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("<br>", sb.toString());
    }

    @Test
    public void testAppendNullAppendsConfiguredNullText() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());

        sb.setNullText("N/A");
        sb.appendNull();
        assertEquals("N/A", sb.toString());
    }

    @Test
    public void testAppendPadding() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, 'x');
        assertEquals("xxx", sb.toString());
    }

    @Test
    public void testAppendPaddingNegativeMeansNoAppend() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(-1, 'x');
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendSeparator
    // ---------------------------------------------------------------

    @Test
    public void testAppendSeparatorCharOnNonEmptyBuilder() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator(',');
        assertEquals("a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharOnEmptyBuilderHasNoEffect() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharStandardOrDefaultIfEmpty() {
        StrBuilder empty = new StrBuilder();
        empty.appendSeparator(',', ';');
        assertEquals(";", empty.toString());

        StrBuilder nonEmpty = new StrBuilder("a");
        nonEmpty.appendSeparator(',', ';');
        assertEquals("a,", nonEmpty.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', 0);
        assertEquals("", sb.toString());
        sb.appendSeparator(',', 1);
        assertEquals(",", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringOnNonEmptyBuilder() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator(", ");
        assertEquals("a, ", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNullHasNoEffect() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(",", 0);
        assertEquals("", sb.toString());
        sb.appendSeparator(",", 1);
        assertEquals(",", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardOrDefaultIfEmpty() {
        StrBuilder empty = new StrBuilder();
        empty.appendSeparator(" and", " where");
        assertEquals(" where", empty.toString());

        StrBuilder nonEmpty = new StrBuilder("x = 1");
        nonEmpty.appendSeparator(" and", " where");
        assertEquals("x = 1 and", nonEmpty.toString());
    }

    // ---------------------------------------------------------------
    // appendTo / readFrom
    // ---------------------------------------------------------------

    @Test
    public void testAppendToAppendable() throws IOException {
        StrBuilder sb = new StrBuilder("abc");
        StringBuilder dest = new StringBuilder();
        sb.appendTo(dest);
        assertEquals("abc", dest.toString());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReadFromReadable() throws IOException {
        StrBuilder sb = new StrBuilder();
        Reader reader = new StringReader("abc");
        int count = sb.readFrom(reader);
        assertEquals(3, count);
        assertEquals("abc", sb.toString());
    }

    // ---------------------------------------------------------------
    // asReader / asWriter / asTokenizer
    // ---------------------------------------------------------------

    @Test
    public void testAsReaderReadsBuilderContent() throws IOException {
        StrBuilder sb = new StrBuilder("ab");
        Reader reader = sb.asReader();
        assertEquals('a', (char) reader.read());
        assertEquals('b', (char) reader.read());
        assertEquals(-1, reader.read());
    }

    @Test
    public void testAsWriterWritesIntoBuilder() throws IOException {
        StrBuilder sb = new StrBuilder();
        Writer writer = sb.asWriter();
        writer.write("abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAsTokenizerReturnsLinkedTokenizer() {
        StrBuilder sb = new StrBuilder("a b");
        StrTokenizer tokenizer = sb.asTokenizer();
        assertNotNull(tokenizer);
    }

    // ---------------------------------------------------------------
    // build / capacity / ensureCapacity / minimizeCapacity
    // ---------------------------------------------------------------

    @Test
    public void testBuildReturnsToString() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(sb.toString(), sb.build());
    }

    @Test
    public void testEnsureCapacityGrowsWhenNeeded() {
        StrBuilder sb = new StrBuilder(10);
        sb.ensureCapacity(50);
        assertTrue(sb.capacity() >= 50);
    }

    @Test
    public void testEnsureCapacityDoesNotShrink() {
        StrBuilder sb = new StrBuilder(50);
        sb.ensureCapacity(5);
        assertTrue(sb.capacity() >= 50);
    }

    @Test
    public void testMinimizeCapacity() {
        StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals(3, sb.length());
    }

    // ---------------------------------------------------------------
    // charAt / setCharAt / deleteCharAt
    // ---------------------------------------------------------------

    @Test
    public void testCharAtValidIndex() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    @Test
    public void testCharAtNegativeIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.charAt(-1);
            }
        });
    }

    @Test
    public void testCharAtTooLargeIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.charAt(3);
            }
        });
    }

    @Test
    public void testSetCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'Z');
        assertEquals("aZc", sb.toString());
    }

    @Test
    public void testSetCharAtInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.setCharAt(10, 'Z');
            }
        });
    }

    @Test
    public void testDeleteCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testDeleteCharAtInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.deleteCharAt(10);
            }
        });
    }

    // ---------------------------------------------------------------
    // clear / isEmpty / isNotEmpty / size / length
    // ---------------------------------------------------------------

    @Test
    public void testClearResetsSizeButKeepsCapacity() {
        StrBuilder sb = new StrBuilder();
        sb.append("abcdef");
        int capacityBefore = sb.capacity();
        StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
        assertEquals(capacityBefore, sb.capacity());
    }

    @Test
    public void testIsEmptyAndIsNotEmpty() {
        StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append("a");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testSizeEqualsLength() {
        StrBuilder sb = new StrBuilder("abcde");
        assertEquals(5, sb.size());
        assertEquals(sb.length(), sb.size());
    }

    // ---------------------------------------------------------------
    // contains
    // ---------------------------------------------------------------

    @Test
    public void testContainsChar() {
        StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cde"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsStrMatcherNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.contains((StrMatcher) null));
    }

    // ---------------------------------------------------------------
    // delete / deleteAll / deleteFirst
    // ---------------------------------------------------------------

    @Test
    public void testDeleteRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteRangeEndIndexTooLargeTreatedAsEndOfString() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(2, 1000);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testDeleteInvalidStartIndexThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.delete(-1, 2);
            }
        });
    }

    @Test
    public void testDeleteAllChar() {
        StrBuilder sb = new StrBuilder("ababab");
        sb.deleteAll('a');
        assertEquals("bbb", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        StrBuilder sb = new StrBuilder("a-b-c-d");
        sb.deleteAll("-");
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testDeleteAllStringNullCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteAllStrMatcherNullCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((StrMatcher) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstChar() {
        StrBuilder sb = new StrBuilder("ababab");
        sb.deleteFirst('a');
        assertEquals("babab", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        StrBuilder sb = new StrBuilder("ab-cd-ef");
        sb.deleteFirst("-");
        assertEquals("abcd-ef", sb.toString());
    }

    @Test
    public void testDeleteFirstStringNullCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteFirst((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstStrMatcherNullCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteFirst((StrMatcher) null);
        assertEquals("abc", sb.toString());
    }

    // ---------------------------------------------------------------
    // startsWith / endsWith
    // ---------------------------------------------------------------

    @Test
    public void testStartsWith() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("xyz"));
    }

    @Test
    public void testStartsWithNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.startsWith(null));
    }

    @Test
    public void testEndsWith() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("xyz"));
    }

    @Test
    public void testEndsWithNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.endsWith(null));
    }

    // ---------------------------------------------------------------
    // equals / equalsIgnoreCase / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsObjectWithSameContentDifferentInstance() {
        StrBuilder a = new StrBuilder("abc");
        StrBuilder b = new StrBuilder("abc");
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
    }

    @Test
    public void testEqualsObjectWithDifferentContent() {
        StrBuilder a = new StrBuilder("abc");
        StrBuilder b = new StrBuilder("abd");
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsObjectNullReturnsFalse() {
        StrBuilder a = new StrBuilder("abc");
        assertFalse(a.equals((Object) null));
    }

    @Test
    public void testEqualsObjectSameReferenceReturnsTrue() {
        StrBuilder a = new StrBuilder("abc");
        assertTrue(a.equals(a));
    }

    @Test
    public void testEqualsStrBuilderOverload() {
        StrBuilder a = new StrBuilder("abc");
        StrBuilder b = new StrBuilder("abc");
        assertTrue(a.equals(b));
        assertFalse(a.equals((StrBuilder) null));
    }

    @Test
    public void testEqualsIgnoreCase() {
        StrBuilder a = new StrBuilder("AbC");
        StrBuilder b = new StrBuilder("aBc");
        assertTrue(a.equalsIgnoreCase(b));
        assertFalse(a.equalsIgnoreCase(null));
    }

    @Test
    public void testHashCodeConsistentForEqualContent() {
        StrBuilder a = new StrBuilder("abc");
        StrBuilder b = new StrBuilder("abc");
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
        assertEquals(a.hashCode(), a.hashCode());
    }

    // ---------------------------------------------------------------
    // getBuffer / getChars
    // ---------------------------------------------------------------

    @Test
    public void testGetBufferLengthIsAtLeastSize() {
        StrBuilder sb = new StrBuilder("abc");
        char[] buffer = sb.getBuffer();
        assertNotNull(buffer);
        assertTrue(buffer.length >= sb.size());
    }

    @Test
    public void testGetCharsSingleArgNullDestinationCreatesArray() {
        StrBuilder sb = new StrBuilder("abc");
        char[] result = sb.getChars(null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testGetCharsSingleArgProvidedDestination() {
        StrBuilder sb = new StrBuilder("abc");
        char[] destination = new char[3];
        char[] result = sb.getChars(destination);
        assertSame(destination, result);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, destination);
    }

    @Test
    public void testGetCharsRangeCopiesIntoDestination() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] destination = new char[10];
        sb.getChars(1, 4, destination, 2);
        assertEquals('b', destination[2]);
        assertEquals('c', destination[3]);
        assertEquals('d', destination[4]);
    }

    @Test
    public void testGetCharsRangeNullDestinationThrowsNullPointerException() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                sb.getChars(0, 3, null, 0);
            }
        });
    }

    @Test
    public void testGetCharsRangeInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.getChars(-1, 3, new char[10], 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // getNewLineText / setNewLineText / getNullText / setNullText
    // ---------------------------------------------------------------

    @Test
    public void testGetSetNewLineText() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        StrBuilder result = sb.setNewLineText("\n");
        assertSame(sb, result);
        assertEquals("\n", sb.getNewLineText());
        sb.setNewLineText(null);
        assertNull(sb.getNewLineText());
    }

    @Test
    public void testGetSetNullText() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        StrBuilder result = sb.setNullText("NULL");
        assertSame(sb, result);
        assertEquals("NULL", sb.getNullText());
        sb.setNullText(null);
        assertNull(sb.getNullText());
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharFromStartIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf('b', 2));
    }

    @Test
    public void testIndexOfString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(-1, sb.indexOf("zz"));
    }

    @Test
    public void testIndexOfStringNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringFromStartIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf("bc", 2));
    }

    @Test
    public void testIndexOfStrMatcherNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf((StrMatcher) null));
        assertEquals(-1, sb.indexOf((StrMatcher) null, 0));
    }

    @Test
    public void testLastIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharFromStartIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.lastIndexOf('b', 3));
    }

    @Test
    public void testLastIndexOfString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(-1, sb.lastIndexOf("zz"));
    }

    @Test
    public void testLastIndexOfStringNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfStringFromStartIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.lastIndexOf("bc", 3));
    }

    @Test
    public void testLastIndexOfStrMatcherNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null, 2));
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    public void testInsertBoolean() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
    }

    @Test
    public void testInsertChar() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ac");
        sb.setNullText("X");
        sb.insert(1, (char[]) null);
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        StrBuilder sb = new StrBuilder("ae");
        sb.insert(1, new char[] {'w', 'b', 'c', 'd', 'z'}, 1, 3);
        assertEquals("abcde", sb.toString());
    }

    @Test
    public void testInsertDouble() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 1.5d);
        assertEquals("a1.5c", sb.toString());
    }

    @Test
    public void testInsertFloat() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 1.5f);
        assertEquals("a1.5c", sb.toString());
    }

    @Test
    public void testInsertInt() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 9);
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertLong() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 9L);
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ac");
        sb.setNullText("X");
        sb.insert(1, (Object) null);
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testInsertString() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, "b");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertStringNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ac");
        sb.setNullText("X");
        sb.insert(1, (String) null);
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testInsertInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.insert(10, "x");
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.insert(-1, "x");
            }
        });
    }

    // ---------------------------------------------------------------
    // leftString / rightString / midString
    // ---------------------------------------------------------------

    @Test
    public void testLeftString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
    }

    @Test
    public void testLeftStringLongerThanLengthReturnsWholeBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.leftString(100));
    }

    @Test
    public void testLeftStringNegativeReturnsEmptyString() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.leftString(-1));
    }

    @Test
    public void testRightString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
    }

    @Test
    public void testRightStringLongerThanLengthReturnsWholeBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.rightString(100));
    }

    @Test
    public void testRightStringNegativeReturnsEmptyString() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.rightString(-1));
    }

    @Test
    public void testMidStringNormal() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cd", sb.midString(2, 2));
    }

    @Test
    public void testMidStringNegativeIndexTreatedAsZero() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("ab", sb.midString(-5, 2));
    }

    @Test
    public void testMidStringIndexBeyondSizeReturnsEmptyString() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.midString(100, 2));
    }

    @Test
    public void testMidStringNegativeLengthReturnsEmptyString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.midString(1, -1));
    }

    @Test
    public void testMidStringInsufficientCharsReturnsAvailable() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("bc", sb.midString(1, 100));
    }

    // ---------------------------------------------------------------
    // replace / replaceAll / replaceFirst
    // ---------------------------------------------------------------

    @Test
    public void testReplaceRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    @Test
    public void testReplaceRangeNullReplaceStrDeletesRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testReplaceRangeEndTooLargeTreatedAsEndOfString() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(4, 1000, "Z");
        assertEquals("abcdZ", sb.toString());
    }

    @Test
    public void testReplaceAllChar() {
        StrBuilder sb = new StrBuilder("ababab");
        sb.replaceAll('a', 'X');
        assertEquals("XbXbXb", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        StrBuilder sb = new StrBuilder("a-b-c");
        sb.replaceAll("-", "+");
        assertEquals("a+b+c", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullSearchCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.replaceAll((String) null, "X");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullReplaceEquivalentToEmptyString() {
        StrBuilder sb = new StrBuilder("a-b-c");
        sb.replaceAll("-", null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        StrBuilder sb = new StrBuilder("ababab");
        sb.replaceFirst('a', 'X');
        assertEquals("Xbabab", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        StrBuilder sb = new StrBuilder("a-b-c");
        sb.replaceFirst("-", "+");
        assertEquals("a+b-c", sb.toString());
    }

    @Test
    public void testReplaceFirstStringNullSearchCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.replaceFirst((String) null, "X");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceAllStrMatcherNullCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.replaceAll((StrMatcher) null, "X");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceFirstStrMatcherNullCausesNoAction() {
        StrBuilder sb = new StrBuilder("abc");
        sb.replaceFirst((StrMatcher) null, "X");
        assertEquals("abc", sb.toString());
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    public void testReverse() {
        StrBuilder sb = new StrBuilder("abcd");
        sb.reverse();
        assertEquals("dcba", sb.toString());
    }

    @Test
    public void testReverseTwiceRestoresOriginal() {
        StrBuilder sb = new StrBuilder("abcd");
        sb.reverse();
        sb.reverse();
        assertEquals("abcd", sb.toString());
    }

    // ---------------------------------------------------------------
    // setLength
    // ---------------------------------------------------------------

    @Test
    public void testSetLengthTruncates() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
        assertEquals(3, sb.length());
    }

    @Test
    public void testSetLengthExtendsWithUnicodeZero() {
        StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('\u0000', sb.charAt(2));
        assertEquals('\u0000', sb.charAt(3));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.setLength(-1);
            }
        });
    }

    // ---------------------------------------------------------------
    // subSequence / substring / toCharArray
    // ---------------------------------------------------------------

    @Test
    public void testSubSequence() {
        StrBuilder sb = new StrBuilder("abcdef");
        CharSequence sub = sb.subSequence(1, 4);
        assertEquals("bcd", sub.toString());
    }

    @Test
    public void testSubstringFromStart() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    @Test
    public void testSubstringRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.substring(1, 4));
    }

    @Test
    public void testSubstringRangeEndTooLargeTreatedAsEndOfString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2, 1000));
    }

    @Test
    public void testSubstringInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.substring(-1);
            }
        });
    }

    @Test
    public void testToCharArray() {
        StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());
    }

    @Test
    public void testToCharArrayRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'b', 'c', 'd'}, sb.toCharArray(1, 4));
    }

    @Test
    public void testToCharArrayRangeEndTooLargeIsValid() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'c', 'd', 'e', 'f'}, sb.toCharArray(2, 1000));
    }

    @Test
    public void testToCharArrayRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                sb.toCharArray(-1, 3);
            }
        });
    }

    // ---------------------------------------------------------------
    // toString / toStringBuffer / toStringBuilder
    // ---------------------------------------------------------------

    @Test
    public void testToStringReturnsIndependentCopy() {
        StrBuilder sb = new StrBuilder("abc");
        String snapshot = sb.toString();
        sb.append("def");
        assertEquals("abc", snapshot);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuilder result = sb.toStringBuilder();
        assertEquals("abc", result.toString());
    }

    // ---------------------------------------------------------------
    // trim
    // ---------------------------------------------------------------

    @Test
    public void testTrimRemovesLeadingAndTrailingWhitespace() {
        StrBuilder sb = new StrBuilder("  \t abc \n ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimOnAllWhitespaceLeavesEmptyBuilder() {
        StrBuilder sb = new StrBuilder("   \t\n  ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // Interfaces implemented
    // ---------------------------------------------------------------

    @Test
    public void testImplementsDocumentedInterfaces() {
        StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb instanceof java.io.Serializable);
        assertTrue(sb instanceof Appendable);
        assertTrue(sb instanceof CharSequence);
        assertTrue(sb instanceof Builder);
    }

    @Test
    public void testCharSequenceContractMethods() {
        StrBuilder sb = new StrBuilder("abc");
        CharSequence cs = sb;
        assertEquals(3, cs.length());
        assertEquals('b', cs.charAt(1));
        assertEquals("abc", cs.toString());
    }

    // used to confirm imports resolve without warnings for unused List import
    @Test
    public void testAppendAllWithArrayListIterable() {
        StrBuilder sb = new StrBuilder();
        List<String> list = new ArrayList<String>();
        list.add("x");
        list.add("y");
        sb.appendAll((Iterable<?>) list);
        assertEquals("xy", sb.toString());
    }

    @Test
    public void testNotEqualsDifferentTypeSameContent() {
        StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.equals("abc"));
        assertNotSame("abc", sb.toString());
        assertEquals("abc", sb.toString());
    }
}
