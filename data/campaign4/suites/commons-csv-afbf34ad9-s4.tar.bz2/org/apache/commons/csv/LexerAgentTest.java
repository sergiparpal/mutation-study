package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

public class LexerAgentTest {

    private static Lexer newLexer(final CSVFormat format, final String input, final ExtendedBufferedReader[] readerOut) {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(input));
        if (readerOut != null) {
            readerOut[0] = reader;
        }
        return new Lexer(format, reader);
    }

    private static Lexer newLexer(final CSVFormat format, final String input) {
        return newLexer(format, input, null);
    }

    // ---------------------------------------------------------------
    // close() / isClosed()
    // ---------------------------------------------------------------

    @Test
    public void testIsClosedFalseBeforeClose() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b");
        assertFalse(lexer.isClosed());
    }

    @Test
    public void testCloseMarksLexerClosed() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b");
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b");
        lexer.close();
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    // ---------------------------------------------------------------
    // getBytesRead() / getCharacterPosition() / getCurrentLineNumber()
    // ---------------------------------------------------------------

    @Test
    public void testGetBytesReadStartsAtZero() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c\r\n");
        assertEquals(0L, lexer.getBytesRead());
    }

    @Test
    public void testGetBytesReadIncreasesAfterReadingTokens() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "aaaa,bbbb\r\n");
        lexer.nextToken(new Token());
        final long afterFirst = lexer.getBytesRead();
        assertTrue(afterFirst > 0, "Expected bytes read to increase after consuming input");
        lexer.nextToken(new Token());
        final long afterSecond = lexer.getBytesRead();
        assertTrue(afterSecond >= afterFirst, "Bytes read must not decrease");
    }

    @Test
    public void testGetCharacterPositionStartsAtZero() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c\r\n");
        assertEquals(0L, lexer.getCharacterPosition());
    }

    @Test
    public void testGetCurrentLineNumberStartsAtZero() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\r\nc,d\r\n");
        assertEquals(0L, lexer.getCurrentLineNumber());
    }

    @Test
    public void testGetCurrentLineNumberAdvancesAcrossRecords() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\r\nc,d\r\n");
        lexer.nextToken(new Token());
        lexer.nextToken(new Token());
        final long afterFirstRecord = lexer.getCurrentLineNumber();
        lexer.nextToken(new Token());
        lexer.nextToken(new Token());
        final long afterSecondRecord = lexer.getCurrentLineNumber();
        assertTrue(afterSecondRecord > afterFirstRecord, "Line number should advance once the next record is read");
    }

    // ---------------------------------------------------------------
    // getFirstEol()
    // ---------------------------------------------------------------

    @Test
    public void testGetFirstEolNullBeforeAnyLineEndingSeen() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        assertEquals(null, lexer.getFirstEol());
    }

    @Test
    public void testGetFirstEolCapturesCrLf() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\r\nc,d\r\n");
        Token token = new Token();
        while (token.type != Token.Type.EOF) {
            token = lexer.nextToken(new Token());
        }
        assertEquals("\r\n", lexer.getFirstEol());
    }

    // ---------------------------------------------------------------
    // isEndOfFile(int)
    // ---------------------------------------------------------------

    @Test
    public void testIsEndOfFileTrueForEofMarker() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(-1));
    }

    @Test
    public void testIsEndOfFileFalseForOrdinaryCharacter() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
    }

    // ---------------------------------------------------------------
    // isStartOfLine(int)
    // ---------------------------------------------------------------

    @Test
    public void testIsStartOfLineTrueForCrAndLf() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine('\r'));
        assertTrue(lexer.isStartOfLine('\n'));
    }

    @Test
    public void testIsStartOfLineFalseForOrdinaryCharacter() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isStartOfLine('a'));
    }

    @Test
    public void testIsStartOfLineTrueAtStartOfFile() {
        final ExtendedBufferedReader[] readerBox = new ExtendedBufferedReader[1];
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b", readerBox);
        // Before anything has been read, the reader reports its "no character read yet" sentinel.
        final int sentinel = readerBox[0].getLastChar();
        assertTrue(lexer.isStartOfLine(sentinel));
    }

    // ---------------------------------------------------------------
    // isQuoteChar(int)
    // ---------------------------------------------------------------

    @Test
    public void testIsQuoteCharTrueForConfiguredQuote() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isQuoteChar('"'));
    }

    @Test
    public void testIsQuoteCharFalseForOtherCharacter() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isQuoteChar('\''));
    }

    @Test
    public void testIsQuoteCharFalseWhenQuotingDisabled() {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setQuote((Character) null).get();
        final Lexer lexer = newLexer(format, "");
        assertFalse(lexer.isQuoteChar('"'));
    }

    // ---------------------------------------------------------------
    // isCommentStart(int)
    // ---------------------------------------------------------------

    @Test
    public void testIsCommentStartFalseWhenNoCommentMarkerConfigured() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    public void testIsCommentStartTrueForConfiguredMarker() {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setCommentMarker('#').get();
        final Lexer lexer = newLexer(format, "");
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    // ---------------------------------------------------------------
    // isEscape(int)
    // ---------------------------------------------------------------

    @Test
    public void testIsEscapeFalseWhenNoEscapeConfigured() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    public void testIsEscapeTrueForConfiguredEscapeCharacter() {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setEscape('\\').get();
        final Lexer lexer = newLexer(format, "");
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
    }

    // ---------------------------------------------------------------
    // isDelimiter(int) -- throws IOException
    // ---------------------------------------------------------------

    @Test
    public void testIsDelimiterTrueForSingleCharDelimiter() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isDelimiter(','));
    }

    @Test
    public void testIsDelimiterFalseForNonDelimiterFirstCharacter() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isDelimiter('a'));
    }

    @Test
    public void testIsDelimiterTrueForMultiCharDelimiterAndDoesNotConsumeOnPeek() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setDelimiter("[|]").get();
        final ExtendedBufferedReader[] readerBox = new ExtendedBufferedReader[1];
        final Lexer lexer = newLexer(format, "|]XY", readerBox);
        assertTrue(lexer.isDelimiter('['));
        // isDelimiter only peeks: the stream must remain unconsumed.
        final ExtendedBufferedReader reader = readerBox[0];
        assertEquals('|', reader.read());
        assertEquals(']', reader.read());
        assertEquals('X', reader.read());
        assertEquals('Y', reader.read());
    }

    @Test
    public void testIsDelimiterFalseForMultiCharDelimiterMismatch() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setDelimiter("[|]").get();
        final Lexer lexer = newLexer(format, "|X");
        assertFalse(lexer.isDelimiter('['));
    }

    // ---------------------------------------------------------------
    // isEscapeDelimiter() -- throws IOException
    // ---------------------------------------------------------------

    @Test
    public void testIsEscapeDelimiterTrueForDocumentedExample() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setDelimiter("[|]").setEscape('!').get();
        final Lexer lexer = newLexer(format, "![!|!]");
        assertTrue(lexer.isEscapeDelimiter());
    }

    @Test
    public void testIsEscapeDelimiterFalseForMismatch() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setDelimiter("[|]").setEscape('!').get();
        final Lexer lexer = newLexer(format, "!X");
        assertFalse(lexer.isEscapeDelimiter());
    }

    // ---------------------------------------------------------------
    // readEndOfLine(int) -- throws IOException
    // ---------------------------------------------------------------

    @Test
    public void testReadEndOfLineFalseForOrdinaryCharacter() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.readEndOfLine('a'));
    }

    @Test
    public void testReadEndOfLineTrueForLoneLf() throws IOException {
        final ExtendedBufferedReader[] readerBox = new ExtendedBufferedReader[1];
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "X", readerBox);
        assertTrue(lexer.readEndOfLine('\n'));
        // A lone LF does not consume any following character.
        assertEquals('X', readerBox[0].read());
    }

    @Test
    public void testReadEndOfLineTrueForLoneCr() throws IOException {
        final ExtendedBufferedReader[] readerBox = new ExtendedBufferedReader[1];
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "X", readerBox);
        assertTrue(lexer.readEndOfLine('\r'));
        // A CR not followed by LF does not consume the following character.
        assertEquals('X', readerBox[0].read());
    }

    @Test
    public void testReadEndOfLineGreedilyConsumesLfAfterCr() throws IOException {
        final ExtendedBufferedReader[] readerBox = new ExtendedBufferedReader[1];
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "\nX", readerBox);
        assertTrue(lexer.readEndOfLine('\r'));
        // The paired LF is silently swallowed, leaving only 'X'.
        assertEquals('X', readerBox[0].read());
    }

    // ---------------------------------------------------------------
    // readEscape() -- throws IOException, CSVException
    // ---------------------------------------------------------------

    @Test
    public void testReadEscapeThrowsIOExceptionAtEndOfStream() {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setEscape('\\').get();
        final Lexer lexer = newLexer(format, "");
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
    }

    @Test
    public void testReadEscapeReturnsLiteralQuoteCharacter() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setEscape('\\').get();
        final Lexer lexer = newLexer(format, "\"");
        assertEquals((int) '"', lexer.readEscape());
    }

    @Test
    public void testReadEscapeReturnsLiteralEscapeCharacter() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setEscape('\\').get();
        final Lexer lexer = newLexer(format, "\\");
        assertEquals((int) '\\', lexer.readEscape());
    }

    // ---------------------------------------------------------------
    // trimTrailingSpaces(StringBuilder)
    // ---------------------------------------------------------------

    @Test
    public void testTrimTrailingSpacesRemovesTrailingWhitespace() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("hello   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("hello", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesLeavesStringWithoutTrailingWhitespaceUnchanged() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("hello");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("hello", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesOnAllSpacesYieldsEmpty() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesOnEmptyBufferStaysEmpty() {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    // ---------------------------------------------------------------
    // nextToken(Token) -- the core tokenizer, throws IOException, CSVException
    // ---------------------------------------------------------------

    @Test
    public void testNextTokenOnEmptyInputReturnsEof() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    public void testNextTokenSimpleRecordProducesTokenThenEorecordThenEof() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c\r\n");

        final Token first = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, first.type);
        assertEquals("a", first.content.toString());

        final Token second = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, second.type);
        assertEquals("b", second.content.toString());

        final Token third = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, third.type);
        assertEquals("c", third.content.toString());

        final Token fourth = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, fourth.type);
    }

    @Test
    public void testNextTokenLastRecordWithoutTrailingNewlineStillEndsRecord() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b");

        final Token first = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, first.type);
        assertEquals("a", first.content.toString());

        final Token second = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, second.type);
        assertEquals("b", second.content.toString());

        final Token third = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, third.type);
    }

    @Test
    public void testNextTokenQuotedFieldPreservesDelimiterInsideQuotes() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "\"a,b\",c\r\n");

        final Token first = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, first.type);
        assertEquals("a,b", first.content.toString());

        final Token second = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, second.type);
        assertEquals("c", second.content.toString());
    }

    @Test
    public void testNextTokenCommentLineProducesCommentToken() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setCommentMarker('#').get();
        final Lexer lexer = newLexer(format, "#remark\r\na,b\r\n");

        final Token first = lexer.nextToken(new Token());
        assertEquals(Token.Type.COMMENT, first.type);
        assertEquals("remark", first.content.toString());

        final Token second = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, second.type);
        assertEquals("a", second.content.toString());

        final Token third = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, third.type);
        assertEquals("b", third.content.toString());
    }

    @Test
    public void testNextTokenIgnoresSurroundingSpacesWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = newLexer(format, " a , b \r\n");

        final Token first = lexer.nextToken(new Token());
        assertEquals("a", first.content.toString());

        final Token second = lexer.nextToken(new Token());
        assertEquals("b", second.content.toString());
    }

    @Test
    public void testNextTokenSkipsEmptyLinesWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setIgnoreEmptyLines(true).get();
        final Lexer lexer = newLexer(format, "\r\na,b\r\n");

        final Token first = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, first.type);
        assertEquals("a", first.content.toString());

        final Token second = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, second.type);
        assertEquals("b", second.content.toString());
    }

    @Test
    public void testNextTokenReusesSuppliedTokenInstance() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\r\n");
        final Token token = new Token();
        final Token returned = lexer.nextToken(token);
        assertEquals(token, returned);
    }
}
