/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.time.Duration;
import java.util.Collection;
import java.util.Iterator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link ThreadUtils}.
 */
class ThreadUtilsAgentTest {

    private volatile boolean fixtureThreadShouldRun;
    private Thread fixtureThread;
    private ThreadGroup fixtureThreadGroup;

    private Thread startNamedThread(final String name, final ThreadGroup group) {
        fixtureThreadShouldRun = true;
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                while (fixtureThreadShouldRun) {
                    try {
                        Thread.sleep(10);
                    } catch (final InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
            }
        };
        final Thread thread = group == null ? new Thread(runnable, name) : new Thread(group, runnable, name);
        thread.setDaemon(true);
        thread.start();
        // Give the thread a chance to actually start and register as active.
        while (thread.getState() == Thread.State.NEW) {
            try {
                Thread.sleep(1);
            } catch (final InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return thread;
    }

    @AfterEach
    public void tearDown() throws InterruptedException {
        fixtureThreadShouldRun = false;
        if (fixtureThread != null) {
            fixtureThread.join(2000);
            fixtureThread = null;
        }
        if (fixtureThreadGroup != null) {
            if (!fixtureThreadGroup.isDestroyed() && fixtureThreadGroup.activeCount() == 0) {
                fixtureThreadGroup.destroy();
            }
            fixtureThreadGroup = null;
        }
    }

    @Test
    void testGetSystemThreadGroupHasNoParent() {
        final ThreadGroup systemGroup = ThreadUtils.getSystemThreadGroup();
        assertNotNull(systemGroup);
        assertNull(systemGroup.getParent());
    }

    @Test
    void testGetAllThreadsContainsCurrentThread() {
        final Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertNotNull(threads);
        assertTrue(threads.contains(Thread.currentThread()));
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                threads.clear();
            }
        });
    }

    @Test
    void testGetAllThreadGroupsExcludesSystemGroup() {
        final Collection<ThreadGroup> groups = ThreadUtils.getAllThreadGroups();
        assertNotNull(groups);
        assertFalse(groups.contains(ThreadUtils.getSystemThreadGroup()));
    }

    @Test
    void testFindThreadByIdFindsNamedThread() {
        final String uniqueName = "ThreadUtilsAgentTest-findById-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, null);
        final Thread found = ThreadUtils.findThreadById(fixtureThread.getId());
        assertNotNull(found);
        assertSame(fixtureThread, found);
        assertEquals(uniqueName, found.getName());
    }

    @Test
    void testFindThreadByIdReturnsNullForUnusedId() {
        // Extremely unlikely to ever be assigned by the JVM in this run.
        final Thread found = ThreadUtils.findThreadById(Long.MAX_VALUE - 1);
        assertNull(found);
    }

    @Test
    void testFindThreadByIdThrowsOnZero() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(0);
            }
        });
    }

    @Test
    void testFindThreadByIdThrowsOnNegative() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(-1);
            }
        });
    }

    @Test
    void testFindThreadByIdAndGroupNameMatches() {
        final String uniqueGroupName = "ThreadUtilsAgentTest-group-" + System.nanoTime();
        fixtureThreadGroup = new ThreadGroup(uniqueGroupName);
        final String uniqueName = "ThreadUtilsAgentTest-byIdGroup-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, fixtureThreadGroup);
        final Thread found = ThreadUtils.findThreadById(fixtureThread.getId(), uniqueGroupName);
        assertNotNull(found);
        assertSame(fixtureThread, found);
    }

    @Test
    void testFindThreadByIdAndGroupNameMismatchReturnsNull() {
        final String uniqueGroupName = "ThreadUtilsAgentTest-group-" + System.nanoTime();
        fixtureThreadGroup = new ThreadGroup(uniqueGroupName);
        final String uniqueName = "ThreadUtilsAgentTest-byIdGroupMismatch-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, fixtureThreadGroup);
        final Thread found = ThreadUtils.findThreadById(fixtureThread.getId(), "some-other-group-name-" + System.nanoTime());
        assertNull(found);
    }

    @Test
    void testFindThreadByIdAndGroupNameThrowsOnNullGroupName() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(1, (String) null);
            }
        });
    }

    @Test
    void testFindThreadByIdAndThreadGroupMatches() {
        final ThreadGroup group = new ThreadGroup("ThreadUtilsAgentTest-group-" + System.nanoTime());
        fixtureThreadGroup = group;
        final String uniqueName = "ThreadUtilsAgentTest-byIdThreadGroup-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, group);
        final Thread found = ThreadUtils.findThreadById(fixtureThread.getId(), group);
        assertNotNull(found);
        assertSame(fixtureThread, found);
    }

    @Test
    void testFindThreadByIdAndThreadGroupMismatchReturnsNull() {
        final ThreadGroup group = new ThreadGroup("ThreadUtilsAgentTest-group-" + System.nanoTime());
        fixtureThreadGroup = group;
        final String uniqueName = "ThreadUtilsAgentTest-byIdThreadGroupMismatch-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, group);
        final ThreadGroup otherGroup = new ThreadGroup("ThreadUtilsAgentTest-other-group-" + System.nanoTime());
        try {
            final Thread found = ThreadUtils.findThreadById(fixtureThread.getId(), otherGroup);
            assertNull(found);
        } finally {
            if (otherGroup.activeCount() == 0) {
                otherGroup.destroy();
            }
        }
    }

    @Test
    void testFindThreadByIdAndThreadGroupThrowsOnNullGroup() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(1, (ThreadGroup) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameFindsUniqueThread() {
        final String uniqueName = "ThreadUtilsAgentTest-byName-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, null);
        final Collection<Thread> found = ThreadUtils.findThreadsByName(uniqueName);
        assertEquals(1, found.size());
        assertSame(fixtureThread, found.iterator().next());
    }

    @Test
    void testFindThreadsByNameNoMatchReturnsEmpty() {
        final Collection<Thread> found = ThreadUtils.findThreadsByName("ThreadUtilsAgentTest-nonexistent-" + System.nanoTime());
        assertNotNull(found);
        assertTrue(found.isEmpty());
    }

    @Test
    void testFindThreadsByNameThrowsOnNullName() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName((String) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameAndGroupNameMatches() {
        final String uniqueGroupName = "ThreadUtilsAgentTest-group-" + System.nanoTime();
        fixtureThreadGroup = new ThreadGroup(uniqueGroupName);
        final String uniqueName = "ThreadUtilsAgentTest-byNameGroup-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, fixtureThreadGroup);
        final Collection<Thread> found = ThreadUtils.findThreadsByName(uniqueName, uniqueGroupName);
        assertEquals(1, found.size());
        assertSame(fixtureThread, found.iterator().next());
    }

    @Test
    void testFindThreadsByNameAndGroupNameThrowsOnNullThreadName() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName(null, "someGroup");
            }
        });
    }

    @Test
    void testFindThreadsByNameAndGroupNameThrowsOnNullGroupName() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName("someThread", (String) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameAndThreadGroupMatches() {
        final ThreadGroup group = new ThreadGroup("ThreadUtilsAgentTest-group-" + System.nanoTime());
        fixtureThreadGroup = group;
        final String uniqueName = "ThreadUtilsAgentTest-byNameThreadGroup-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, group);
        final Collection<Thread> found = ThreadUtils.findThreadsByName(uniqueName, group);
        assertEquals(1, found.size());
        assertSame(fixtureThread, found.iterator().next());
    }

    @Test
    void testFindThreadsByNameAndThreadGroupNoMatchReturnsEmpty() {
        final ThreadGroup group = new ThreadGroup("ThreadUtilsAgentTest-group-" + System.nanoTime());
        fixtureThreadGroup = group;
        final Collection<Thread> found = ThreadUtils.findThreadsByName("ThreadUtilsAgentTest-nonexistent-" + System.nanoTime(), group);
        assertNotNull(found);
        assertTrue(found.isEmpty());
    }

    @Test
    void testFindThreadGroupsByNameMatches() {
        final String uniqueGroupName = "ThreadUtilsAgentTest-byGroupName-" + System.nanoTime();
        fixtureThreadGroup = new ThreadGroup(uniqueGroupName);
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName(uniqueGroupName);
        assertEquals(1, found.size());
        assertSame(fixtureThreadGroup, found.iterator().next());
    }

    @Test
    void testFindThreadGroupsByNameNoMatchReturnsEmpty() {
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName("ThreadUtilsAgentTest-nonexistent-group-" + System.nanoTime());
        assertNotNull(found);
        assertTrue(found.isEmpty());
    }

    @Test
    void testFindThreadGroupsByNameThrowsOnNullName() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroupsByName(null);
            }
        });
    }

    @Test
    void testFindThreadGroupsNonRecursiveExcludesGrandchild() {
        final ThreadGroup parent = new ThreadGroup("ThreadUtilsAgentTest-parent-" + System.nanoTime());
        fixtureThreadGroup = parent;
        final ThreadGroup child = new ThreadGroup(parent, "ThreadUtilsAgentTest-child-" + System.nanoTime());
        final ThreadGroup grandchild = new ThreadGroup(child, "ThreadUtilsAgentTest-grandchild-" + System.nanoTime());
        try {
            final Collection<ThreadGroup> recursiveResult = ThreadUtils.findThreadGroups(parent, true,
                    org.apache.commons.lang3.function.Predicates.<ThreadGroup>truePredicate());
            assertTrue(recursiveResult.contains(child));
            assertTrue(recursiveResult.contains(grandchild));

            final Collection<ThreadGroup> nonRecursiveResult = ThreadUtils.findThreadGroups(parent, false,
                    org.apache.commons.lang3.function.Predicates.<ThreadGroup>truePredicate());
            assertTrue(nonRecursiveResult.contains(child));
            assertFalse(nonRecursiveResult.contains(grandchild));
        } finally {
            if (grandchild.activeCount() == 0) {
                grandchild.destroy();
            }
            if (child.activeCount() == 0) {
                child.destroy();
            }
        }
    }

    @Test
    void testFindThreadGroupsThrowsOnNullGroup() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups(null, true, org.apache.commons.lang3.function.Predicates.<ThreadGroup>truePredicate());
            }
        });
    }

    @Test
    void testFindThreadGroupsThrowsOnNullPredicate() {
        final ThreadGroup group = ThreadUtils.getSystemThreadGroup();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups(group, true, (java.util.function.Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    void testFindThreadsThrowsOnNullGroup() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads(null, true, org.apache.commons.lang3.function.Predicates.<Thread>truePredicate());
            }
        });
    }

    @Test
    void testFindThreadsThrowsOnNullPredicate() {
        final ThreadGroup group = ThreadUtils.getSystemThreadGroup();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads(group, true, (java.util.function.Predicate<Thread>) null);
            }
        });
    }

    @Test
    void testFindThreadsNonRecursiveExcludesSubgroupThread() {
        final ThreadGroup parent = new ThreadGroup("ThreadUtilsAgentTest-threadParent-" + System.nanoTime());
        fixtureThreadGroup = parent;
        final ThreadGroup child = new ThreadGroup(parent, "ThreadUtilsAgentTest-threadChild-" + System.nanoTime());
        final String uniqueName = "ThreadUtilsAgentTest-nonRecursiveThread-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, child);
        try {
            final Collection<Thread> recursiveResult = ThreadUtils.findThreads(parent, true,
                    org.apache.commons.lang3.function.Predicates.<Thread>truePredicate());
            assertTrue(recursiveResult.contains(fixtureThread));

            final Collection<Thread> nonRecursiveResult = ThreadUtils.findThreads(parent, false,
                    org.apache.commons.lang3.function.Predicates.<Thread>truePredicate());
            assertFalse(nonRecursiveResult.contains(fixtureThread));
        } finally {
            fixtureThreadShouldRun = false;
            try {
                fixtureThread.join(2000);
            } catch (final InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            fixtureThread = null;
            if (child.activeCount() == 0) {
                child.destroy();
            }
        }
    }

    @Test
    void testNamePredicateThreadMatches() {
        final String uniqueName = "ThreadUtilsAgentTest-namePredicate-" + System.nanoTime();
        fixtureThread = startNamedThread(uniqueName, null);
        @SuppressWarnings("deprecation")
        final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(uniqueName);
        assertTrue(predicate.test(fixtureThread));
        assertFalse(predicate.test(Thread.currentThread()));
        assertFalse(predicate.test((Thread) null));
    }

    @Test
    void testNamePredicateThreadGroupMatches() {
        final String uniqueGroupName = "ThreadUtilsAgentTest-groupNamePredicate-" + System.nanoTime();
        fixtureThreadGroup = new ThreadGroup(uniqueGroupName);
        @SuppressWarnings("deprecation")
        final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(uniqueGroupName);
        assertTrue(predicate.test(fixtureThreadGroup));
        assertFalse(predicate.test((ThreadGroup) null));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testNamePredicateThrowsOnNullName() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ThreadUtils.NamePredicate(null);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testThreadIdPredicateMatches() {
        final long id = Thread.currentThread().getId();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(id);
        assertTrue(predicate.test(Thread.currentThread()));
        assertFalse(predicate.test((Thread) null));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testThreadIdPredicateThrowsOnZero() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ThreadUtils.ThreadIdPredicate(0);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testThreadIdPredicateThrowsOnNegative() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ThreadUtils.ThreadIdPredicate(-5);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testAlwaysTruePredicateReturnsTrueForEverything() {
        final ThreadUtils.ThreadPredicate threadPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        final ThreadUtils.ThreadGroupPredicate threadGroupPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(threadPredicate.test((Thread) null));
        assertTrue(threadPredicate.test(Thread.currentThread()));
        assertTrue(threadGroupPredicate.test((ThreadGroup) null));
        assertTrue(threadGroupPredicate.test(ThreadUtils.getSystemThreadGroup()));
    }

    @Test
    void testSleepSleepsForAtLeastRequestedDuration() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ofMillis(50));
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 40, "Elapsed time should be close to or greater than requested sleep: " + elapsedMillis);
    }

    @Test
    void testSleepZeroDurationReturnsImmediately() throws InterruptedException {
        ThreadUtils.sleep(Duration.ZERO);
        // No exception, completes normally.
        assertTrue(true);
    }

    @Test
    void testSleepThrowsOnInterrupt() {
        final Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ThreadUtils.sleep(Duration.ofSeconds(5));
                    fail("Expected InterruptedException");
                } catch (final InterruptedException expected) {
                    // expected
                }
            }
        });
        worker.start();
        try {
            Thread.sleep(50);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        worker.interrupt();
        try {
            worker.join(2000);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        assertFalse(worker.isAlive());
    }

    @Test
    void testSleepQuietlyDoesNotThrowOnInterrupt() throws InterruptedException {
        final boolean[] completedNormally = {false};
        final boolean[] interruptedFlagSeen = {false};
        final Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                ThreadUtils.sleepQuietly(Duration.ofSeconds(5));
                interruptedFlagSeen[0] = Thread.currentThread().isInterrupted();
                completedNormally[0] = true;
            }
        });
        worker.start();
        Thread.sleep(50);
        worker.interrupt();
        worker.join(2000);
        assertFalse(worker.isAlive());
        assertTrue(completedNormally[0]);
        assertTrue(interruptedFlagSeen[0]);
    }

    @Test
    void testJoinWaitsForThreadToFinish() throws InterruptedException {
        final boolean[] ran = {false};
        final Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(50);
                } catch (final InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                ran[0] = true;
            }
        });
        worker.start();
        ThreadUtils.join(worker, Duration.ofSeconds(5));
        assertFalse(worker.isAlive());
        assertTrue(ran[0]);
    }

    @Test
    void testJoinReturnsAfterTimeoutIfThreadStillRunning() throws InterruptedException {
        fixtureThreadShouldRun = true;
        final Thread worker = startNamedThread("ThreadUtilsAgentTest-joinTimeout-" + System.nanoTime(), null);
        fixtureThread = worker;
        final long start = System.nanoTime();
        ThreadUtils.join(worker, Duration.ofMillis(50));
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(worker.isAlive());
        assertTrue(elapsedMillis < 2000, "join with short timeout should not block long: " + elapsedMillis);
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedConstructorIsPublic() {
        final ThreadUtils instance = new ThreadUtils();
        assertNotNull(instance);
    }

    @Test
    void testFindThreadGroupsSinglePredicateOverloadThrowsOnNullPredicate() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups((java.util.function.Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    void testFindThreadsSinglePredicateOverloadThrowsOnNullPredicate() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads((java.util.function.Predicate<Thread>) null);
            }
        });
    }

    @Test
    void testFindThreadsReturnedCollectionIsUnmodifiable() {
        final Collection<Thread> threads = ThreadUtils.findThreads(org.apache.commons.lang3.function.Predicates.<Thread>truePredicate());
        final Iterator<Thread> iterator = threads.iterator();
        assertTrue(iterator.hasNext());
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                iterator.remove();
            }
        });
    }
}
