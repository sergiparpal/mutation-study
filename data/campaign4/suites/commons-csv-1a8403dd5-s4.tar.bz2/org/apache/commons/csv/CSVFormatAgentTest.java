package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat} based solely on the documented contract in api/.
 */
public class CSVFormatAgentTest {

    // ---------------------------------------------------------------
    // Predefined format: DEFAULT (the base all other predefined formats are described as "DEFAULT with: ...")
    // ---------------------------------------------------------------

    @Test
    public void testDefaultFormat() {
        CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        // Fields not mentioned in the DEFAULT bullet list take the Java default.
        assertNull(format.getEscapeCharacter());
        assertNull(format.getQuoteMode());
        assertNull(format.getNullString());
        assertNull(format.getCommentMarker());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getLenientEof());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingData());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
        assertTrue(format.isQuoteCharacterSet());
    }

    @Test
    public void testExcelFormat() {
        CSVFormat format = CSVFormat.EXCEL;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
        // Not overridden: inherited from DEFAULT.
        assertNull(format.getEscapeCharacter());
        assertNull(format.getQuoteMode());
        assertFalse(format.getTrim());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testRfc4180Format() {
        CSVFormat format = CSVFormat.RFC4180;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        // Not overridden: inherited from DEFAULT.
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getAllowMissingColumnNames());
    }

    @Test
    public void testTdfFormat() {
        CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
        // Not overridden: inherited from DEFAULT.
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testMySqlFormat() {
        CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        // Not overridden: inherited from DEFAULT.
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testOracleFormat() {
        CSVFormat format = CSVFormat.ORACLE;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\\N", format.getNullString());
        assertTrue(format.getTrim());
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    public void testPostgresqlCsvFormat() {
        CSVFormat format = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", format.getDelimiterString());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testPostgresqlTextFormat() {
        CSVFormat format = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testMongoDbCsvFormat() {
        CSVFormat format = CSVFormat.MONGODB_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
        // Not overridden: MongoDB CSV keeps DEFAULT's ignoreEmptyLines(true).
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    public void testMongoDbTsvFormat() {
        CSVFormat format = CSVFormat.MONGODB_TSV;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testInformixUnloadFormat() {
        CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        CSVFormat format = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        // Escaping is disabled for this variant: inherited from DEFAULT (no escape set).
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
    }

    // ---------------------------------------------------------------
    // newFormat(char)
    // ---------------------------------------------------------------

    @Test
    public void testNewFormatInitializesOnlyDelimiter() {
        CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // ---------------------------------------------------------------
    // valueOf(String)
    // ---------------------------------------------------------------

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    public void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.valueOf("NotARealPredefinedFormat");
            }
        });
    }

    // ---------------------------------------------------------------
    // builder() / copy() / Builder.create()
    // ---------------------------------------------------------------

    @Test
    public void testBuilderRoundTripsToEqualFormat() {
        CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertNotNull(builder);
        CSVFormat rebuilt = builder.get();
        assertEquals(CSVFormat.DEFAULT, rebuilt);
    }

    @Test
    public void testBuilderCreateMatchesDefault() {
        CSVFormat created = CSVFormat.Builder.create().get();
        assertEquals(CSVFormat.DEFAULT, created);
    }

    @Test
    public void testBuilderCreateFromFormatCopiesSettings() {
        CSVFormat.Builder builder = CSVFormat.Builder.create(CSVFormat.EXCEL);
        CSVFormat rebuilt = builder.get();
        assertEquals(CSVFormat.EXCEL, rebuilt);
    }

    @Test
    public void testCopyInstanceMethodProducesEqualFormat() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @Test
    public void testStaticCopyIsNullSafe() {
        assertNull(CSVFormat.copy(null));
        assertEquals(CSVFormat.EXCEL, CSVFormat.copy(CSVFormat.EXCEL));
    }

    @Test
    public void testDeprecatedBuildMatchesGet() {
        CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertEquals(builder.get(), builder.build());
    }

    // ---------------------------------------------------------------
    // Builder setters round trip through the resulting CSVFormat's getters.
    // ---------------------------------------------------------------

    @Test
    public void testSetDelimiterChar() {
        CSVFormat format = CSVFormat.newFormat(',').builder().setDelimiter(';').get();
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    public void testSetDelimiterString() {
        CSVFormat format = CSVFormat.newFormat(',').builder().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
        assertArrayEquals(new char[] {':', ':'}, format.getDelimiterCharArray());
    }

    @Test
    public void testSetQuoteCharAndDisableWithNull() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('\'').get();
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());

        CSVFormat disabled = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertNull(disabled.getQuoteCharacter());
        assertFalse(disabled.isQuoteCharacterSet());
    }

    @Test
    public void testSetEscapeCharAndDisableWithNull() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('!').get();
        assertEquals(Character.valueOf('!'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());

        CSVFormat disabled = CSVFormat.DEFAULT.builder().setEscape((Character) null).get();
        assertNull(disabled.getEscapeCharacter());
        assertFalse(disabled.isEscapeCharacterSet());
    }

    @Test
    public void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                builder.setEscape('\n');
            }
        });
    }

    @Test
    public void testSetCommentMarkerCharAndCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());

        CSVFormat other = CSVFormat.DEFAULT.builder().setCommentMarker(Character.valueOf('%')).get();
        assertEquals(Character.valueOf('%'), other.getCommentMarker());
    }

    @Test
    public void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                builder.setCommentMarker('\r');
            }
        });
    }

    @Test
    public void testSetNullString() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testSetQuoteMode() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).get();
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    public void testSetDuplicateHeaderMode() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testSetAllowMissingColumnNames() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).get();
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    public void testSetAllowDuplicateHeaderNamesRoundTrip() {
        CSVFormat allow = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(true).get();
        assertTrue(allow.getAllowDuplicateHeaderNames());
        CSVFormat disallow = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(false).get();
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    @Test
    public void testSetAutoFlush() {
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
        CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        assertTrue(format.getAutoFlush());
    }

    @Test
    public void testSetLenientEof() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        assertTrue(format.getLenientEof());
    }

    @Test
    public void testSetMaxRows() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    public void testSetSkipHeaderRecord() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setSkipHeaderRecord(true).get();
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    public void testSetTrailingData() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        assertTrue(format.getTrailingData());
    }

    @Test
    public void testSetTrailingDelimiter() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    public void testSetTrim() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertTrue(format.getTrim());
    }

    @Test
    public void testSetIgnoreHeaderCase() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(true).get();
        assertTrue(format.getIgnoreHeaderCase());
    }

    @Test
    public void testSetIgnoreSurroundingSpaces() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testSetIgnoreEmptyLines() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testSetRecordSeparatorCharAndString() {
        CSVFormat charSeparator = CSVFormat.DEFAULT.builder().setRecordSeparator('\n').get();
        assertEquals("\n", charSeparator.getRecordSeparator());

        CSVFormat stringSeparator = CSVFormat.DEFAULT.builder().setRecordSeparator("\r\n").get();
        assertEquals("\r\n", stringSeparator.getRecordSeparator());
    }

    // ---------------------------------------------------------------
    // Header / header comments: defensive copies.
    // ---------------------------------------------------------------

    @Test
    public void testGetHeaderIsNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testGetHeaderIsEmptyArrayWhenParsedAutomatically() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        String[] header = format.getHeader();
        assertNotNull(header);
        assertEquals(0, header.length);
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        String[] first = format.getHeader();
        assertArrayEquals(new String[] {"a", "b"}, first);
        first[0] = "mutated";
        String[] second = format.getHeader();
        assertArrayEquals(new String[] {"a", "b"}, second);
        assertNotSame(first, second);
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        String[] first = format.getHeaderComments();
        assertArrayEquals(new String[] {"c1", "c2"}, first);
        first[0] = "mutated";
        String[] second = format.getHeaderComments();
        assertArrayEquals(new String[] {"c1", "c2"}, second);
    }

    @Test
    public void testGetHeaderCommentsIsNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // ---------------------------------------------------------------
    // Deprecated getDelimiter() returns the first delimiter character.
    // ---------------------------------------------------------------

    @Test
    public void testDeprecatedGetDelimiterReturnsFirstChar() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
    }

    // ---------------------------------------------------------------
    // equals() / hashCode() / toString()
    // ---------------------------------------------------------------

    @Test
    public void testEqualsReflexiveAndBySettings() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        CSVFormat a = CSVFormat.newFormat(',').builder().setQuote('"').get();
        CSVFormat b = CSVFormat.newFormat(',').builder().setQuote('"').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDistinguishesDifferentSettings() {
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.EXCEL);
    }

    @Test
    public void testEqualsRejectsNullAndOtherTypes() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testToStringIsNonNullAndStable() {
        String first = CSVFormat.DEFAULT.toString();
        String second = CSVFormat.DEFAULT.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    @Test
    public void testFormatProducesDelimitedRecordString() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValuesContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    public void testFormatWithNoValuesIsEmpty() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    // ---------------------------------------------------------------
    // print(Object, Appendable, boolean)
    // ---------------------------------------------------------------

    @Test
    public void testPrintSingleValue() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("hello", sb, true);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testPrintTrimsValueWhenTrimIsEnabled() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        StringBuilder sb = new StringBuilder();
        format.print("  hello  ", sb, true);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testPrintDoesNotTrimByDefault() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("  hello  ", sb, true);
        assertEquals("  hello  ", sb.toString());
    }

    // ---------------------------------------------------------------
    // printRecord(Appendable, Object...) / println(Appendable)
    // ---------------------------------------------------------------

    @Test
    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "x", "y");
        assertEquals("x,y\r\n", sb.toString());
    }

    @Test
    public void testPrintlnOutputsRecordSeparatorOnly() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnOutputsTrailingDelimiterWhenSet() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals("," + "\r\n", sb.toString());
    }

    // ---------------------------------------------------------------
    // print(Appendable) -> CSVPrinter
    // ---------------------------------------------------------------

    @Test
    public void testPrintToAppendableReturnsWorkingPrinter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        try {
            assertNotNull(printer);
            printer.printRecord("a", "b");
        } finally {
            printer.close();
        }
        assertEquals("a,b\r\n", sb.toString());
    }

    // ---------------------------------------------------------------
    // print(File, Charset) / print(Path, Charset)
    // ---------------------------------------------------------------

    @Test
    public void testPrintToFileWithCharset() throws IOException {
        File file = File.createTempFile("csvformatagenttest", ".csv");
        file.deleteOnExit();
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
            try {
                printer.printRecord("v1", "v2");
            } finally {
                printer.close();
            }
            String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            assertEquals("v1,v2\r\n", content);
        } finally {
            file.delete();
        }
    }

    @Test
    public void testPrintToPathWithCharset() throws IOException {
        Path path = Files.createTempFile("csvformatagenttest", ".csv");
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(path, StandardCharsets.UTF_8);
            try {
                printer.printRecord("p1", "p2");
            } finally {
                printer.close();
            }
            String content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            assertEquals("p1,p2\r\n", content);
        } finally {
            Files.deleteIfExists(path);
        }
    }

    // ---------------------------------------------------------------
    // printer() -> prints to System.out
    // ---------------------------------------------------------------

    @Test
    public void testPrinterWritesToSystemOut() throws IOException {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setOut(new PrintStream(captured, true));
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.printer();
            try {
                printer.printRecord("sysout1", "sysout2");
            } finally {
                printer.close();
            }
        } finally {
            System.setOut(originalOut);
        }
        String content = captured.toString();
        assertTrue(content.contains("sysout1,sysout2"));
    }

    // ---------------------------------------------------------------
    // parse(Reader) -> CSVParser
    // ---------------------------------------------------------------

    @Test
    public void testParseReturnsRecordsWithExpectedValues() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\nd,e,f\r\n"));
        try {
            Iterator<CSVRecord> iterator = parser.iterator();
            assertTrue(iterator.hasNext());
            CSVRecord first = iterator.next();
            assertEquals("a", first.get(0));
            assertEquals("b", first.get(1));
            assertEquals("c", first.get(2));
            assertTrue(iterator.hasNext());
            CSVRecord second = iterator.next();
            assertEquals("d", second.get(0));
            assertEquals("e", second.get(1));
            assertEquals("f", second.get(2));
            assertFalse(iterator.hasNext());
        } finally {
            parser.close();
        }
    }

    // ---------------------------------------------------------------
    // Deprecated with* methods: representative coverage, including documented error cases.
    // ---------------------------------------------------------------

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withQuote('\r');
            }
        });
    }

    @Test
    public void testWithRecordSeparatorStringRejectsInvalidSeparator() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withRecordSeparator("not-a-separator");
            }
        });
    }

    @Test
    public void testWithHeaderSetsHeaderArray() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "email");
        assertArrayEquals(new String[] {"name", "email"}, format.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeaderSetsSkipHeaderRecord() {
        CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testWithNullStringSetsNullString() {
        CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @Test
    public void testWithTrailingDelimiterSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithIgnoreEmptyLinesSetsFlag() {
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @Test
    public void testWithAllowMissingColumnNamesSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithSystemRecordSeparatorUsesLineSeparator() {
        CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @Test
    public void testWithTrimSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    public void testWithSkipHeaderRecordSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithQuoteModeSetsMode() {
        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
        assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
    }

    @Test
    public void testWithIgnoreHeaderCaseSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withEscape('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                CSVFormat.DEFAULT.withEscape(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testWithAllowDuplicateHeaderNamesSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true).getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    @Test
    public void testWithAutoFlushSetsFlag() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.withAutoFlush(false).getAutoFlush());
    }

    @Test
    public void testWithHeaderCommentsSetsComments() {
        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("comment1", "comment2");
        assertArrayEquals(new String[] {"comment1", "comment2"}, format.getHeaderComments());
    }

    @Test
    public void testWithRecordSeparatorCharSetsSeparator() {
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    // ---------------------------------------------------------------
    // Package-private helper methods (this test lives in the same package).
    // ---------------------------------------------------------------

    @Test
    public void testIsBlankPackagePrivateHelper() {
        assertTrue(CSVFormat.isBlank(null));
        assertTrue(CSVFormat.isBlank(""));
        assertTrue(CSVFormat.isBlank("   "));
        assertFalse(CSVFormat.isBlank("a"));
        assertFalse(CSVFormat.isBlank(" a "));
    }

    @Test
    public void testToStringArrayPackagePrivateHelper() {
        String[] result = CSVFormat.toStringArray(new Object[] {"a", Integer.valueOf(1), Long.valueOf(2)});
        assertArrayEquals(new String[] {"a", "1", "2"}, result);
    }

    @Test
    public void testTrimCharSequencePackagePrivateHelper() {
        CharSequence trimmed = CSVFormat.trim((CharSequence) "  hi  ");
        assertEquals("hi", trimmed.toString());
    }

    @Test
    public void testTrimStringInstanceMethodRespectsGetTrimSetting() {
        CSVFormat trimEnabled = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertEquals("hi", trimEnabled.trim(" hi "));

        CSVFormat trimDisabled = CSVFormat.DEFAULT;
        assertEquals(" hi ", trimDisabled.trim(" hi "));
    }

    @Test
    public void testClonePackagePrivateHelperIsNullSafeAndCopies() {
        String[] nullArray = null;
        assertNull(CSVFormat.<String>clone(nullArray));

        String[] source = {"x", "y"};
        String[] cloned = CSVFormat.<String>clone(source);
        assertArrayEquals(source, cloned);
        assertNotSame(source, cloned);
    }

    @Test
    public void testCopyStaticPackagePrivateHelper() {
        assertNull(CSVFormat.copy((CSVFormat) null));
        CSVFormat copy = CSVFormat.copy(CSVFormat.EXCEL);
        assertEquals(CSVFormat.EXCEL, copy);
    }

    @Test
    public void testGetDelimiterCharArrayPackagePrivateHelper() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("ab").get();
        assertArrayEquals(new char[] {'a', 'b'}, format.getDelimiterCharArray());
    }

    @Test
    public void testGetEscapeCharPackagePrivateHelper() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        assertEquals('\\', CSVFormat.MYSQL.getEscapeChar());
    }

    @Test
    public void testUseMaxRowsPackagePrivateHelper() {
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        CSVFormat limited = CSVFormat.DEFAULT.builder().setMaxRows(3L).get();
        assertTrue(limited.useMaxRows());
    }

    @Test
    public void testUseRowPackagePrivateHelper() {
        CSVFormat noLimit = CSVFormat.DEFAULT;
        assertTrue(noLimit.useRow(0));
        assertTrue(noLimit.useRow(1000));

        CSVFormat limited = CSVFormat.DEFAULT.builder().setMaxRows(2L).get();
        assertTrue(limited.useRow(0));
        assertFalse(limited.useRow(50));
    }
}
