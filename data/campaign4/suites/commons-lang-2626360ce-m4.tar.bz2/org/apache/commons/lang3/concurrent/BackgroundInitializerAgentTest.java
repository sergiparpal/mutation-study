/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Self-contained test for {@link BackgroundInitializer}.
 */
class BackgroundInitializerAgentTest {

    /**
     * A concrete implementation of {@link BackgroundInitializer} used for testing. It records the
     * {@link ExecutorService} that was actually used to run the task, and allows controlling when
     * initialization is allowed to complete via a latch.
     */
    private static class TestInitializer extends BackgroundInitializer<Integer> {

        /** Number of times initialize() was called. */
        private int initializeCalls;

        /** The executor service that was active while initialize() ran. */
        private ExecutorService activeExecutorDuringInit;

        /** If set, blocks initialize() until it is counted down. */
        private CountDownLatch waitLatch;

        /** If set, thrown by initialize(). */
        private Exception exceptionToThrow;

        TestInitializer() {
            super();
        }

        TestInitializer(final ExecutorService exec) {
            super(exec);
        }

        @Override
        protected Integer initialize() throws Exception {
            initializeCalls++;
            activeExecutorDuringInit = getActiveExecutor();
            if (waitLatch != null) {
                waitLatch.await();
            }
            if (exceptionToThrow != null) {
                throw exceptionToThrow;
            }
            return Integer.valueOf(42);
        }

        @Override
        protected int getTaskCount() {
            return 1;
        }
    }

    /** Executors created during a test, torn down afterwards. */
    private ExecutorService createdExecutor;

    @AfterEach
    void tearDown() {
        if (createdExecutor != null) {
            createdExecutor.shutdownNow();
        }
    }

    @Test
    void testIsStartedFalseBeforeStart() {
        final TestInitializer init = new TestInitializer();
        assertFalse(init.isStarted(), "should not be started before start() is called");
    }

    @Test
    void testGetFutureBeforeStartThrows() {
        final TestInitializer init = new TestInitializer();
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.getFuture();
            }
        });
        assertNotNull(ex.getMessage());
    }

    @Test
    void testGetActiveExecutorNullBeforeStart() {
        final TestInitializer init = new TestInitializer();
        assertNull(init.getActiveExecutor(), "active executor should be null before start()");
    }

    @Test
    void testStartReturnsTrueOnceAndFalseAfterwards() throws ConcurrentException {
        final TestInitializer init = new TestInitializer();
        assertTrue(init.start(), "first call to start() should return true");
        assertTrue(init.isStarted());
        assertFalse(init.start(), "second call to start() should return false");
        assertFalse(init.start(), "third call to start() should also return false");
        assertEquals(Integer.valueOf(42), init.get());
        assertEquals(1, init.initializeCalls, "initialize() should only run once");
    }

    @Test
    void testGetBlocksUntilInitializationComplete() throws Exception {
        final TestInitializer init = new TestInitializer();
        init.waitLatch = new CountDownLatch(1);
        init.start();
        assertFalse(init.getFuture().isDone(), "future should not be done while waiting on latch");
        init.waitLatch.countDown();
        final Integer result = init.get();
        assertEquals(Integer.valueOf(42), result);
        assertTrue(init.getFuture().isDone());
    }

    @Test
    void testDefaultExecutorIsTemporaryAndShutdownAfterCompletion() throws ConcurrentException {
        final TestInitializer init = new TestInitializer();
        init.start();
        init.get();
        final ExecutorService active = init.getActiveExecutor();
        assertNotNull(active, "active executor should be set after start()");
        assertTrue(active.isShutdown(), "temporary executor should be shut down after task completion");
        assertNull(init.getExternalExecutor(), "no external executor was provided");
    }

    @Test
    void testExternalExecutorIsUsedAndNotShutdown() throws ConcurrentException {
        createdExecutor = Executors.newSingleThreadExecutor();
        final TestInitializer init = new TestInitializer(createdExecutor);
        assertSame(createdExecutor, init.getExternalExecutor());
        init.start();
        init.get();
        assertSame(createdExecutor, init.getActiveExecutor(), "external executor should be the active executor");
        assertFalse(createdExecutor.isShutdown(), "external executor must not be shut down by the initializer");
    }

    @Test
    void testSetExternalExecutorBeforeStart() {
        createdExecutor = Executors.newSingleThreadExecutor();
        final TestInitializer init = new TestInitializer();
        init.setExternalExecutor(createdExecutor);
        assertSame(createdExecutor, init.getExternalExecutor());
    }

    @Test
    void testSetExternalExecutorAfterStartThrows() {
        final TestInitializer init = new TestInitializer();
        init.start();
        final ExecutorService otherExec = Executors.newSingleThreadExecutor();
        try {
            final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    init.setExternalExecutor(otherExec);
                }
            });
            assertNotNull(ex.getMessage());
        } finally {
            otherExec.shutdownNow();
        }
    }

    @Test
    void testSetExternalExecutorNullAllowedBeforeStart() {
        final TestInitializer init = new TestInitializer();
        init.setExternalExecutor(null);
        assertNull(init.getExternalExecutor());
    }

    @Test
    void testIsInitializedFalseBeforeStart() {
        final TestInitializer init = new TestInitializer();
        assertFalse(init.isInitialized(), "isInitialized() must be false before start()");
    }

    @Test
    void testIsInitializedTrueAfterSuccessfulCompletion() throws ConcurrentException {
        final TestInitializer init = new TestInitializer();
        init.start();
        init.get();
        assertTrue(init.isInitialized(), "isInitialized() must be true after successful completion");
    }

    @Test
    void testIsInitializedFalseWhenNotYetDone() {
        final TestInitializer init = new TestInitializer();
        init.waitLatch = new CountDownLatch(1);
        init.start();
        assertFalse(init.isInitialized(), "isInitialized() must be false while task is still running");
        init.waitLatch.countDown();
    }

    @Test
    void testIsInitializedFalseAfterFailedInitialization() throws InterruptedException {
        final TestInitializer init = new TestInitializer();
        init.exceptionToThrow = new IOException("boom");
        init.start();
        // Wait for the background task to finish (it will fail).
        try {
            init.getFuture().get();
            fail("expected the future to report failure");
        } catch (final Exception expected) {
            // expected: ExecutionException wraps the IOException
        }
        assertFalse(init.isInitialized(), "isInitialized() must be false after failed initialization");
    }

    @Test
    void testGetWrapsCheckedExceptionInConcurrentException() {
        final TestInitializer init = new TestInitializer();
        final IOException cause = new IOException("checked failure");
        init.exceptionToThrow = cause;
        init.start();
        final ConcurrentException ex = assertThrows(ConcurrentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex.getCause(), "ConcurrentException should wrap the original checked exception");
    }

    @Test
    void testGetRethrowsRuntimeExceptionDirectly() {
        final TestInitializer init = new TestInitializer();
        final RuntimeException cause = new RuntimeException("runtime failure");
        init.exceptionToThrow = cause;
        init.start();
        final RuntimeException ex = assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex, "runtime exceptions from initialize() should be rethrown directly, unwrapped");
    }

    @Test
    void testFutureAvailableAfterStart() {
        final TestInitializer init = new TestInitializer();
        init.start();
        final Future<Integer> future = init.getFuture();
        assertNotNull(future);
        assertSame(future, init.getFuture(), "getFuture() should return the same Future instance on repeated calls");
    }

    @Test
    void testCloseDoesNothingBeforeStart() throws ConcurrentException {
        final TestInitializer init = new TestInitializer();
        // close() must be a no-op (not throw) when nothing has been initialized yet.
        init.close();
        assertFalse(init.isInitialized());
    }

    @Test
    void testBuilderCreatesWorkingInitializer() throws ConcurrentException {
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new org.apache.commons.lang3.function.FailableSupplier<String, ConcurrentException>() {
                    @Override
                    public String get() {
                        return "built-value";
                    }
                })
                .get();
        assertFalse(init.isStarted());
        assertTrue(init.start());
        assertEquals("built-value", init.get());
        assertTrue(init.isInitialized());
    }

    @Test
    void testBuilderWithExternalExecutor() throws ConcurrentException {
        createdExecutor = Executors.newSingleThreadExecutor();
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new org.apache.commons.lang3.function.FailableSupplier<String, ConcurrentException>() {
                    @Override
                    public String get() {
                        return "external";
                    }
                })
                .setExternalExecutor(createdExecutor)
                .get();
        assertSame(createdExecutor, init.getExternalExecutor());
        init.start();
        assertEquals("external", init.get());
        assertFalse(createdExecutor.isShutdown());
    }

    @Test
    void testBuilderCloserIsInvokedOnClose() throws ConcurrentException {
        final boolean[] closed = new boolean[1];
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new org.apache.commons.lang3.function.FailableSupplier<String, ConcurrentException>() {
                    @Override
                    public String get() {
                        return "value";
                    }
                })
                .setCloser(new org.apache.commons.lang3.function.FailableConsumer<String, ConcurrentException>() {
                    @Override
                    public void accept(final String value) {
                        closed[0] = true;
                    }
                })
                .get();
        init.start();
        init.get();
        assertFalse(closed[0], "closer must not run before close() is called");
        init.close();
        assertTrue(closed[0], "closer must run when close() is called after initialization");
    }

    @Test
    void testGetTaskCountDefaultIsOne() {
        final TestInitializer init = new TestInitializer();
        assertEquals(1, init.getTaskCount());
    }

    @Test
    void testCreatedTemporaryExecutorUsesTaskCount() throws ConcurrentException {
        final TestInitializer init = new TestInitializer() {
            @Override
            protected int getTaskCount() {
                return 3;
            }
        };
        init.start();
        init.get();
        assertNotNull(init.activeExecutorDuringInit, "initialize() should observe a non-null active executor");
    }

    @Test
    void testMultipleStartCallsShareSameFuture() {
        final TestInitializer init = new TestInitializer();
        init.start();
        final Future<Integer> firstFuture = init.getFuture();
        init.start();
        init.start();
        assertSame(firstFuture, init.getFuture(), "subsequent start() calls must not replace the Future");
    }

    @Test
    void testDifferentInstancesHaveIndependentState() throws ConcurrentException {
        final TestInitializer first = new TestInitializer();
        final TestInitializer second = new TestInitializer();
        first.start();
        assertTrue(first.isStarted());
        assertFalse(second.isStarted(), "starting one instance must not affect another instance");
        first.get();
        second.start();
        second.get();
        assertNotSame(first.getFuture(), second.getFuture());
    }
}
