package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;
import java.util.function.IntFunction;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------- fields

    @Test
    public void testEmptyArrayConstantsAreEmpty() {
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHAR_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CLASS_ARRAY.length);
    }

    @Test
    public void testIndexNotFoundConstant() {
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    @Test
    public void testSafeMaxArrayLengthIsPositive() {
        assertTrue(ArrayUtils.SAFE_MAX_ARRAY_LENGTH > 0);
    }

    @Test
    public void testDeprecatedConstructorInstantiates() {
        assertNotNull(new ArrayUtils());
    }

    // ------------------------------------------------------------------ add

    @Test
    public void testAddIntArray() {
        assertArrayEquals(new int[] {0}, ArrayUtils.add((int[]) null, 0));
        assertArrayEquals(new int[] {1, 0}, ArrayUtils.add(new int[] {1}, 0));
        assertArrayEquals(new int[] {1, 0, 1}, ArrayUtils.add(new int[] {1, 0}, 1));
    }

    @Test
    public void testAddGenericArrayNullAndNullElementThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.add((Object[]) null, (Object) null);
            }
        });
    }

    @Test
    public void testAddGenericArray() {
        assertArrayEquals(new String[] {"a"}, ArrayUtils.add((String[]) null, "a"));
        assertArrayEquals(new String[] {"a", null}, ArrayUtils.add(new String[] {"a"}, (String) null));
        assertArrayEquals(new String[] {"a", "b"}, ArrayUtils.add(new String[] {"a"}, "b"));
        assertArrayEquals(new String[] {"a", "b", "c"}, ArrayUtils.add(new String[] {"a", "b"}, "c"));
    }

    // --------------------------------------------------------------- addAll

    @Test
    public void testAddAllIntArrays() {
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
        assertArrayEquals(new int[0], ArrayUtils.addAll(new int[0], new int[0]));
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.addAll(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));
        assertArrayEquals(new int[] {3, 4}, ArrayUtils.addAll((int[]) null, new int[] {3, 4}));
    }

    @Test
    public void testAddAllGenericArrays() {
        assertArrayEquals(new String[] {null, null},
                ArrayUtils.addAll(new String[] {null}, new String[] {null}));
        assertArrayEquals(new String[] {"a", "b", "c", "1", "2", "3"},
                ArrayUtils.addAll(new String[] {"a", "b", "c"}, new String[] {"1", "2", "3"}));
    }

    @Test
    public void testAddAllGenericIncompatibleTypesThrows() {
        final Object[] strings = new String[] {"a"};
        final Object[] numbers = new Object[] {Integer.valueOf(1)};
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.addAll(strings, numbers);
            }
        });
    }

    // ---------------------------------------------------------------- clone

    @Test
    public void testCloneIntArray() {
        assertNull(ArrayUtils.clone((int[]) null));
        int[] original = {1, 2, 3};
        int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
    }

    @Test
    public void testCloneGenericArray() {
        assertNull(ArrayUtils.clone((Object[]) null));
        String[] original = {"a", "b"};
        String[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
    }

    // --------------------------------------------------------------- concat

    @Test
    public void testConcatIntArrays() {
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0], new int[0]));
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.concat(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new int[] {1, 2, 3, 4},
                ArrayUtils.concat(new int[] {1, 2}, null, new int[] {3, 4}));
    }

    // ------------------------------------------------------------- contains

    @Test
    public void testContainsInt() {
        assertFalse(ArrayUtils.contains((int[]) null, 1));
        assertTrue(ArrayUtils.contains(new int[] {1, 2, 3}, 2));
        assertFalse(ArrayUtils.contains(new int[] {1, 2, 3}, 4));
    }

    @Test
    public void testContainsObject() {
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
        assertTrue(ArrayUtils.contains(new Object[] {"a", "b", null}, null));
        assertTrue(ArrayUtils.contains(new Object[] {"a", "b"}, "a"));
        assertFalse(ArrayUtils.contains(new Object[] {"a", "b"}, "c"));
    }

    @Test
    public void testContainsDoubleTolerance() {
        double[] array = {1.0, 5.0, 9.0};
        assertTrue(ArrayUtils.contains(array, 5.05, 0.1));
        assertFalse(ArrayUtils.contains(array, 5.5, 0.1));
        assertFalse(ArrayUtils.contains((double[]) null, 5.0, 0.1));
    }

    @Test
    public void testContainsAnyInt() {
        int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.containsAny(array, 9, 3));
        assertFalse(ArrayUtils.containsAny(array, 9, 10));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
    }

    @Test
    public void testContainsAnyObject() {
        Object[] array = {"a", "b", "c"};
        assertTrue(ArrayUtils.containsAny(array, "x", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "a"));
    }

    // ------------------------------------------------------------------ get

    @Test
    public void testGetGeneric() {
        String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
        assertNull(ArrayUtils.get(array, -1));
    }

    @Test
    public void testGetGenericWithDefault() {
        String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0, "default"));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("default", ArrayUtils.get((String[]) null, 0, "default"));
    }

    @Test
    public void testGetComponentType() {
        assertSame(String.class, ArrayUtils.getComponentType(new String[0]));
        assertSame(Integer.class, ArrayUtils.getComponentType(new Integer[0]));
    }

    @Test
    public void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[3]));
        assertEquals(2, ArrayUtils.getDimensions(new int[2][2]));
    }

    @Test
    public void testGetLengthVariants() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] {null}));
        assertEquals(2, ArrayUtils.getLength(new boolean[] {true, false}));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(3, ArrayUtils.getLength(new String[] {"a", "b", "c"}));
    }

    @Test
    public void testGetLengthNonArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    // ------------------------------------------------------------- hashCode

    @Test
    public void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        int[] a = {1, 2, 3};
        int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    // ---------------------------------------------------------------- isXxx

    @Test
    public void testIsEmptyAndIsNotEmptyInt() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));
    }

    @Test
    public void testIsEmptyAndIsNotEmptyObject() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));

        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new Object[0]));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength((Object) null, (Object) null));
        assertTrue(ArrayUtils.isSameLength((Object) null, new int[0]));
        assertTrue(ArrayUtils.isSameLength((Object) new int[3], (Object) new String[] {"a", "b", "c"}));
        assertFalse(ArrayUtils.isSameLength(new int[3], new int[2]));
    }

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[5]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
    }

    @Test
    public void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    @Test
    public void testIsSortedInt() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
    }

    @Test
    public void testIsSortedWithComparator() {
        Comparator<Integer> naturalOrder = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1.compareTo(o2);
            }
        };
        assertTrue(ArrayUtils.isSorted(new Integer[] {1, 2, 3}, naturalOrder));
        assertFalse(ArrayUtils.isSorted(new Integer[] {3, 2, 1}, naturalOrder));
    }

    @Test
    public void testIsSortedComparatorNullThrows() {
        final Integer[] array = {1, 2, 3};
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.isSorted(array, null);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsEqualsDeprecated() {
        assertTrue(ArrayUtils.isEquals(null, null));
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
    }

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // -------------------------------------------------------------- indexOf

    @Test
    public void testIndexOfInt() {
        int[] array = {1, 2, 3, 2};
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
    }

    @Test
    public void testIndexOfIntWithStartIndex() {
        int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));
    }

    @Test
    public void testLastIndexOfInt() {
        int[] array = {1, 2, 3, 2};
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 2));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
    }

    @Test
    public void testLastIndexOfIntWithStartIndex() {
        int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 2, -1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2, 10));
    }

    @Test
    public void testIndexesOfInt() {
        int[] array = {1, 2, 3, 2};
        BitSet expected = new BitSet();
        expected.set(1);
        expected.set(3);
        assertEquals(expected, ArrayUtils.indexesOf(array, 2));
        assertTrue(ArrayUtils.indexesOf((int[]) null, 2).isEmpty());
        assertTrue(ArrayUtils.indexesOf(array, 9).isEmpty());
    }

    // --------------------------------------------------------------- insert

    @Test
    public void testInsertIntArray() {
        assertArrayEquals(new int[] {2, 1}, ArrayUtils.insert(0, new int[] {1}, 2));
        assertArrayEquals(new int[] {2, 6, 10}, ArrayUtils.insert(2, new int[] {2, 6}, 10));
        assertArrayEquals(new int[] {-4, 2, 6}, ArrayUtils.insert(0, new int[] {2, 6}, -4));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1, 2));
    }

    @Test
    public void testInsertIntArrayOutOfBoundsThrows() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.insert(-1, array, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.insert(4, array, 9);
            }
        });
    }

    @Test
    public void testInsertGenericArray() {
        String[] array = {"a", "b", "c"};
        assertArrayEquals(new String[] {"x", "a", "b", "c"}, ArrayUtils.insert(0, array, "x"));
        assertArrayEquals(new String[] {"a", "b", "c", "x"}, ArrayUtils.insert(3, array, "x"));
        assertNull(ArrayUtils.insert(0, (String[]) null, "x"));
    }

    // --------------------------------------------------------------- newInstance

    @Test
    public void testNewInstance() {
        String[] result = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, result.length);
        assertNull(result[0]);
    }

    @Test
    public void testNewInstanceNullComponentTypeThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.newInstance(null, 1);
            }
        });
    }

    // ----------------------------------------------------------- nullToEmpty

    @Test
    public void testNullToEmptyIntArray() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty(new int[0]));
        int[] nonEmpty = {1, 2};
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));
    }

    @Test
    public void testNullToEmptyObjectArray() {
        assertSame(ArrayUtils.EMPTY_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Object[]) null));
        Object[] nonEmpty = {"a"};
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));
    }

    @Test
    public void testNullToEmptyGenericWithClass() {
        String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertEquals(0, result.length);
        String[] nonEmpty = {"a"};
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty, String[].class));
    }

    // -------------------------------------------------------------- remove

    @Test
    public void testRemoveIntArray() {
        assertArrayEquals(new int[0], ArrayUtils.remove(new int[] {1}, 0));
        assertArrayEquals(new int[] {6}, ArrayUtils.remove(new int[] {2, 6}, 0));
        assertArrayEquals(new int[] {2}, ArrayUtils.remove(new int[] {2, 6}, 1));
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.remove(new int[] {2, 6, 3}, 1));
    }

    @Test
    public void testRemoveIntArrayNullOrOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
        final int[] array = {1, 2};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.remove(array, 2);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.remove(array, -1);
            }
        });
    }

    @Test
    public void testRemoveGenericArray() {
        assertArrayEquals(new String[0], ArrayUtils.remove(new String[] {"a"}, 0));
        assertArrayEquals(new String[] {"b"}, ArrayUtils.remove(new String[] {"a", "b"}, 0));
        assertArrayEquals(new String[] {"a"}, ArrayUtils.remove(new String[] {"a", "b"}, 1));
        assertArrayEquals(new String[] {"a", "c"}, ArrayUtils.remove(new String[] {"a", "b", "c"}, 1));
    }

    @Test
    public void testRemoveAllIntArray() {
        assertNull(ArrayUtils.removeAll((int[]) null, 0));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {1}, 0));
        assertArrayEquals(new int[] {6}, ArrayUtils.removeAll(new int[] {2, 6}, 0));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {2, 6}, 0, 1));
        assertArrayEquals(new int[] {2}, ArrayUtils.removeAll(new int[] {2, 6, 3}, 1, 2));
        assertArrayEquals(new int[] {6}, ArrayUtils.removeAll(new int[] {2, 6, 3}, 0, 2));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {2, 6, 3}, 0, 1, 2));
    }

    @Test
    public void testRemoveAllIntArrayOutOfBoundsThrows() {
        final int[] array = {1, 2};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.removeAll(array, 5);
            }
        });
    }

    @Test
    public void testRemoveAllOccurrencesInt() {
        assertNull(ArrayUtils.removeAllOccurrences((int[]) null, 1));
        assertArrayEquals(new int[] {3, 3}, ArrayUtils.removeAllOccurrences(new int[] {1, 3, 1, 3, 1}, 1));
        assertArrayEquals(new int[] {1, 3, 1}, ArrayUtils.removeAllOccurrences(new int[] {1, 3, 1}, 9));
    }

    @Test
    public void testRemoveElementInt() {
        assertNull(ArrayUtils.removeElement((int[]) null, 1));
        assertArrayEquals(new int[0], ArrayUtils.removeElement(new int[0], 1));
        assertArrayEquals(new int[] {1}, ArrayUtils.removeElement(new int[] {1}, 2));
        assertArrayEquals(new int[] {3}, ArrayUtils.removeElement(new int[] {1, 3}, 1));
    }

    @Test
    public void testRemoveElementGeneric() {
        assertNull(ArrayUtils.removeElement((String[]) null, "a"));
        assertArrayEquals(new String[0], ArrayUtils.removeElement(new String[0], "a"));
        assertArrayEquals(new String[] {"a"}, ArrayUtils.removeElement(new String[] {"a"}, "b"));
        assertArrayEquals(new String[] {"b"}, ArrayUtils.removeElement(new String[] {"a", "b"}, "a"));
    }

    @Test
    public void testRemoveElementsInt() {
        assertNull(ArrayUtils.removeElements((int[]) null, 1, 2));
        assertArrayEquals(new int[0], ArrayUtils.removeElements(new int[0], 1, 2));
        assertArrayEquals(new int[] {1}, ArrayUtils.removeElements(new int[] {1}, 2, 3));
        assertArrayEquals(new int[] {3}, ArrayUtils.removeElements(new int[] {1, 3}, 1, 2));
        assertArrayEquals(new int[] {3, 1}, ArrayUtils.removeElements(new int[] {1, 3, 1}, 1));
        assertArrayEquals(new int[] {3}, ArrayUtils.removeElements(new int[] {1, 3, 1}, 1, 1));
    }

    // -------------------------------------------------------------- reverse

    @Test
    public void testReverseIntArray() {
        int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testReverseIntArrayRange() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseIntArrayRangeNoChangeCases() {
        int[] overvalueStart = {1, 2, 3};
        ArrayUtils.reverse(overvalueStart, 5, 10);
        assertArrayEquals(new int[] {1, 2, 3}, overvalueStart);

        int[] endBeforeStart = {1, 2, 3};
        ArrayUtils.reverse(endBeforeStart, 2, 1);
        assertArrayEquals(new int[] {1, 2, 3}, endBeforeStart);
    }

    // ---------------------------------------------------------------- setAll

    @Test
    public void testSetAllWithIntFunction() {
        Integer[] array = new Integer[5];
        IntFunction<Integer> generator = new IntFunction<Integer>() {
            @Override
            public Integer apply(int value) {
                return value * 10;
            }
        };
        Integer[] result = ArrayUtils.setAll(array, generator);
        assertSame(array, result);
        assertArrayEquals(new Integer[] {0, 10, 20, 30, 40}, result);
    }

    @Test
    public void testSetAllWithSupplier() {
        String[] array = new String[3];
        Supplier<String> generator = new Supplier<String>() {
            @Override
            public String get() {
                return "x";
            }
        };
        String[] result = ArrayUtils.setAll(array, generator);
        assertSame(array, result);
        assertArrayEquals(new String[] {"x", "x", "x"}, result);
    }

    // ----------------------------------------------------------------- shift

    @Test
    public void testShiftIntArray() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] {4, 5, 1, 2, 3}, array);
    }

    @Test
    public void testShiftIntArrayRange() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1, 4, 1);
        assertArrayEquals(new int[] {1, 4, 2, 3, 5}, array);
    }

    // --------------------------------------------------------------- shuffle

    @Test
    public void testShuffleIntArrayPreservesElements() {
        int[] array = {1, 2, 3, 4, 5};
        int[] sortedOriginal = ArrayUtils.clone(array);
        Arrays.sort(sortedOriginal);

        ArrayUtils.shuffle(array, new Random(42));

        int[] sortedAfter = ArrayUtils.clone(array);
        Arrays.sort(sortedAfter);
        assertArrayEquals(sortedOriginal, sortedAfter);
    }

    @Test
    public void testShuffleWithNullRandomIsNoOp() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shuffle(array, null);
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, array);
    }

    // ------------------------------------------------------------ startsWith

    @Test
    public void testStartsWithByteArrays() {
        assertTrue(ArrayUtils.startsWith(null, null));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2}, null));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1}));
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, new byte[] {1, 2}));
    }

    // ------------------------------------------------------------- subarray

    @Test
    public void testSubarrayIntArray() {
        int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, ArrayUtils.subarray(array, -2, 10));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSubarrayGenericArray() {
        String[] array = {"a", "b", "c", "d"};
        assertArrayEquals(new String[] {"b", "c"}, ArrayUtils.subarray(array, 1, 3));
        assertNull(ArrayUtils.subarray((String[]) null, 0, 1));
    }

    // ----------------------------------------------------------------- swap

    @Test
    public void testSwapIntArray() {
        assertArrayEquals(new int[] {3, 2, 1}, swapCopy(new int[] {1, 2, 3}, 0, 2));
        assertArrayEquals(new int[] {1, 2, 3}, swapCopy(new int[] {1, 2, 3}, 0, 0));
        assertArrayEquals(new int[] {2, 1, 3}, swapCopy(new int[] {1, 2, 3}, 1, 0));
        assertArrayEquals(new int[] {1, 2, 3}, swapCopy(new int[] {1, 2, 3}, 0, 5));
        assertArrayEquals(new int[] {2, 1, 3}, swapCopy(new int[] {1, 2, 3}, -1, 1));
    }

    @Test
    public void testSwapIntArrayRange() {
        assertArrayEquals(new int[] {3, 2, 1, 4}, swapRangeCopy(new int[] {1, 2, 3, 4}, 0, 2, 1));
        assertArrayEquals(new int[] {1, 2, 3, 4}, swapRangeCopy(new int[] {1, 2, 3, 4}, 0, 0, 1));
        assertArrayEquals(new int[] {3, 4, 1, 2}, swapRangeCopy(new int[] {1, 2, 3, 4}, 2, 0, 2));
        assertArrayEquals(new int[] {4, 2, 3, 1}, swapRangeCopy(new int[] {1, 2, 3, 4}, 0, 3, 3));
    }

    private static int[] swapCopy(int[] array, int offset1, int offset2) {
        ArrayUtils.swap(array, offset1, offset2);
        return array;
    }

    private static int[] swapRangeCopy(int[] array, int offset1, int offset2, int len) {
        ArrayUtils.swap(array, offset1, offset2, len);
        return array;
    }

    // --------------------------------------------------------------- toArray

    @Test
    public void testToArrayVarargs() {
        String[] array = ArrayUtils.toArray("1", "2");
        assertArrayEquals(new String[] {"1", "2"}, array);
    }

    // ----------------------------------------------------------------- toMap

    @Test
    @SuppressWarnings("unchecked")
    public void testToMap() {
        assertNull(ArrayUtils.toMap(null));
        Map<Object, Object> map = ArrayUtils.toMap(
                new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
    }

    // -------------------------------------------------------------- toObject

    @Test
    public void testToObjectInt() {
        assertNull(ArrayUtils.toObject((int[]) null));
        assertArrayEquals(new Integer[] {1, 2, 3}, ArrayUtils.toObject(new int[] {1, 2, 3}));
    }

    @Test
    public void testToObjectBoolean() {
        assertNull(ArrayUtils.toObject((boolean[]) null));
        assertArrayEquals(new Boolean[] {Boolean.TRUE, Boolean.FALSE},
                ArrayUtils.toObject(new boolean[] {true, false}));
    }

    // ------------------------------------------------------------ toPrimitive

    @Test
    public void testToPrimitiveInteger() {
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.toPrimitive(new Integer[] {1, 2, 3}));
    }

    @Test
    public void testToPrimitiveIntegerNullElementThrows() {
        final Integer[] array = {1, null, 3};
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.toPrimitive(array);
            }
        });
    }

    @Test
    public void testToPrimitiveIntegerWithDefault() {
        assertNull(ArrayUtils.toPrimitive((Integer[]) null, 0));
        assertArrayEquals(new int[] {1, 9, 3}, ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, 9));
    }

    // --------------------------------------------------------------- toString

    @Test
    public void testToStringObject() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("{1,2}", ArrayUtils.toString(new int[] {1, 2}));
    }

    @Test
    public void testToStringObjectWithNullDefault() {
        assertEquals("NULL", ArrayUtils.toString(null, "NULL"));
        assertEquals("{1,2}", ArrayUtils.toString(new int[] {1, 2}, "NULL"));
    }

    @Test
    public void testToStringArrayObject() {
        assertNull(ArrayUtils.toStringArray(null));
        assertArrayEquals(new String[] {"1", "2"}, ArrayUtils.toStringArray(new Object[] {1, 2}));
    }

    @Test
    public void testToStringArrayObjectWithNullDefault() {
        assertNull(ArrayUtils.toStringArray(null, "NULL"));
        assertArrayEquals(new String[] {"1", "NULL", "3"},
                ArrayUtils.toStringArray(new Object[] {1, null, 3}, "NULL"));
    }
}
