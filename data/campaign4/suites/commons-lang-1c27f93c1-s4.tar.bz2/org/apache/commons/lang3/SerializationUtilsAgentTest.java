package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.OutputStream;
import java.io.Serializable;

import org.junit.jupiter.api.Test;

public class SerializationUtilsAgentTest {

    private static final String SERIALIZATION_EXCEPTION_NAME = "org.apache.commons.lang3.SerializationException";

    private static class Fixture implements Serializable {
        private static final long serialVersionUID = 1L;

        private final int number;
        private final String text;

        Fixture(int number, String text) {
            this.number = number;
            this.text = text;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Fixture)) {
                return false;
            }
            Fixture that = (Fixture) other;
            return this.number == that.number
                    && (this.text == null ? that.text == null : this.text.equals(that.text));
        }

        @Override
        public int hashCode() {
            return number * 31 + (text == null ? 0 : text.hashCode());
        }
    }

    private static class NotSerializableField implements Serializable {
        private static final long serialVersionUID = 1L;

        @SuppressWarnings("unused")
        private final Object payload = new Object();
    }

    private static class TrackingByteArrayOutputStream extends ByteArrayOutputStream {
        private boolean closed = false;

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }
    }

    private static class TrackingByteArrayInputStream extends ByteArrayInputStream {
        private boolean closed = false;

        TrackingByteArrayInputStream(byte[] buf) {
            super(buf);
        }

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testPublicConstructorCanBeInstantiated() {
        SerializationUtils instance = new SerializationUtils();
        assertNotNull(instance);
    }

    @Test
    public void testCloneDeepClonesSerializableObject() {
        Fixture original = new Fixture(42, "hello");
        Fixture cloned = SerializationUtils.clone(original);

        assertNotNull(cloned);
        assertNotSame(original, cloned);
        assertEquals(original, cloned);
    }

    @Test
    public void testCloneWithNullReturnsNull() {
        String result = SerializationUtils.<String>clone(null);
        assertNull(result);
    }

    @Test
    public void testCloneThrowsSerializationExceptionWhenObjectGraphNotSerializable() {
        NotSerializableField broken = new NotSerializableField();
        try {
            SerializationUtils.clone(broken);
            fail("Expected a serialization failure to be reported");
        } catch (RuntimeException e) {
            assertEquals(SERIALIZATION_EXCEPTION_NAME, e.getClass().getName());
        }
    }

    @Test
    public void testSerializeProducesBytesThatDeserializeToAnEqualObject() {
        Fixture original = new Fixture(7, "abc");

        byte[] bytes = SerializationUtils.serialize(original);

        assertNotNull(bytes);
        assertTrue(bytes.length > 0);

        Fixture restored = SerializationUtils.deserialize(bytes);
        assertNotSame(original, restored);
        assertEquals(original, restored);
    }

    @Test
    public void testSerializeNullObjectProducesBytesThatDeserializeToNull() {
        byte[] bytes = SerializationUtils.serialize((Serializable) null);

        assertNotNull(bytes);
        assertTrue(bytes.length > 0);

        Object restored = SerializationUtils.deserialize(bytes);
        assertNull(restored);
    }

    @Test
    public void testSerializeThrowsSerializationExceptionWhenObjectGraphNotSerializable() {
        NotSerializableField broken = new NotSerializableField();
        try {
            SerializationUtils.serialize(broken);
            fail("Expected a serialization failure to be reported");
        } catch (RuntimeException e) {
            assertEquals(SERIALIZATION_EXCEPTION_NAME, e.getClass().getName());
        }
    }

    @Test
    public void testSerializeToStreamWritesRecoverableDataAndClosesStream() {
        Fixture original = new Fixture(1, "x");
        TrackingByteArrayOutputStream out = new TrackingByteArrayOutputStream();

        SerializationUtils.serialize(original, out);

        assertTrue(out.closed);
        byte[] bytes = out.toByteArray();
        assertTrue(bytes.length > 0);

        Fixture restored = SerializationUtils.deserialize(bytes);
        assertEquals(original, restored);
    }

    @Test
    public void testSerializeToStreamAllowsNullObject() {
        TrackingByteArrayOutputStream out = new TrackingByteArrayOutputStream();

        SerializationUtils.serialize(null, out);

        assertTrue(out.closed);
        Object restored = SerializationUtils.deserialize(out.toByteArray());
        assertNull(restored);
    }

    @Test
    public void testSerializeToStreamThrowsNullPointerExceptionWhenStreamIsNull() {
        try {
            SerializationUtils.serialize(new Fixture(1, "x"), (OutputStream) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void testDeserializeByteArrayThrowsNullPointerExceptionWhenDataIsNull() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void testDeserializeByteArrayThrowsSerializationExceptionOnCorruptData() {
        byte[] garbage = new byte[] {1, 2, 3, 4, 5};
        try {
            SerializationUtils.deserialize(garbage);
            fail("Expected a serialization failure to be reported");
        } catch (RuntimeException e) {
            assertEquals(SERIALIZATION_EXCEPTION_NAME, e.getClass().getName());
        }
    }

    @Test
    public void testDeserializeInputStreamThrowsNullPointerExceptionWhenStreamIsNull() {
        try {
            SerializationUtils.deserialize((InputStream) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void testDeserializeInputStreamReadsObjectAndClosesStream() {
        Fixture original = new Fixture(5, "z");
        byte[] bytes = SerializationUtils.serialize(original);
        TrackingByteArrayInputStream in = new TrackingByteArrayInputStream(bytes);

        Fixture restored = SerializationUtils.deserialize(in);

        assertEquals(original, restored);
        assertTrue(in.closed);
    }

    @Test
    public void testDeserializeInputStreamThrowsSerializationExceptionOnCorruptData() {
        byte[] garbage = new byte[] {9, 9, 9, 9, 9};
        try {
            SerializationUtils.deserialize(new ByteArrayInputStream(garbage));
            fail("Expected a serialization failure to be reported");
        } catch (RuntimeException e) {
            assertEquals(SERIALIZATION_EXCEPTION_NAME, e.getClass().getName());
        }
    }

    @Test
    public void testRequireNonNullReturnsSameReferenceWhenNotNull() throws InvalidObjectException {
        String value = "value";
        String result = SerializationUtils.requireNonNull(value, "should not happen");
        assertSame(value, result);
    }

    @Test
    public void testRequireNonNullThrowsInvalidObjectExceptionWithMessageWhenNull() {
        try {
            SerializationUtils.requireNonNull(null, "custom message");
            fail("Expected InvalidObjectException");
        } catch (InvalidObjectException e) {
            assertEquals("custom message", e.getMessage());
        }
    }

    @Test
    public void testRoundtripReturnsEqualButDistinctObject() {
        Fixture original = new Fixture(9, "round");

        Fixture result = SerializationUtils.roundtrip(original);

        assertNotSame(original, result);
        assertEquals(original, result);
    }

    @Test
    public void testRoundtripOfNullReturnsNull() {
        Fixture result = SerializationUtils.<Fixture>roundtrip(null);
        assertNull(result);
    }

    @Test
    public void testRoundtripPreservesEqualityForSimpleSerializableValue() {
        Integer original = Integer.valueOf(123456);

        Integer result = SerializationUtils.roundtrip(original);

        assertEquals(original, result);
    }

    @Test
    public void testCloneAndRoundtripOfSameObjectAreBothEqualToOriginal() {
        Fixture original = new Fixture(3, "same");

        Fixture cloned = SerializationUtils.clone(original);
        Fixture roundtripped = SerializationUtils.roundtrip(original);

        assertEquals(original, cloned);
        assertEquals(original, roundtripped);
        assertFalse(cloned == roundtripped);
    }
}
