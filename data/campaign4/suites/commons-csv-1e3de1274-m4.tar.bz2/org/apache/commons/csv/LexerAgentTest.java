/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testGetFirstEolNullBeforeAnyEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        assertNull(lexer.getFirstEol());
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\n");
        assertTrue(lexer.readEndOfLine(Constants.LF));
        assertEquals("\n", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCr() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrLf() throws IOException {
        // The buffered reader must still contain the LF that follows the CR we pass in
        // so readEndOfLine can swallow it and recognize CRLF.
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\n");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r\n", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineNotEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertFalse(lexer.readEndOfLine('a'));
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testIsEndOfFile() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));
    }

    @Test
    void testIsStartOfLine() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    @Test
    void testIsQuoteCharAndIsEscapeDisabledByDefault() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        // CSVFormat.DEFAULT has no escape character configured.
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    void testIsEscapeEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "");
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('x'));
    }

    @Test
    void testIsCommentStartDisabledByDefault() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        // CSVFormat.DEFAULT has UNDEFINED comment marker, which never matches a real char.
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    void testIsCommentStartEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "");
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('%'));
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('x'));
    }

    @Test
    void testIsDelimiterMultiCharMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, ":rest");
        assertTrue(lexer.isDelimiter(':'));
    }

    @Test
    void testIsDelimiterMultiCharNoMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "xrest");
        assertFalse(lexer.isDelimiter(':'));
    }

    @Test
    void testIsDelimiterFirstCharMismatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "zz");
        assertFalse(lexer.isDelimiter('a'));
    }

    @Test
    void testGetBytesReadAndPositionAndLineNumber() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\nc,d");
        assertEquals(0, lexer.getCharacterPosition());
        final Token token = new Token();
        lexer.nextToken(token);
        assertTrue(lexer.getCharacterPosition() > 0);
        assertEquals(1, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getBytesRead());
    }

    @Test
    void testNextTokenEmptyInputReturnsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        assertEquals("", token.content.toString());
    }

    @Test
    void testNextTokenSimpleRecord() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b,c\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
    }

    @Test
    void testNextTokenFinalFieldWithoutTrailingNewlineIsEofWithData() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("b", token.content.toString());
    }

    @Test
    void testNextTokenQuotedField() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a,b\",c\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertTrue(token.isQuoted);
        assertEquals("a,b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertFalse(token.isQuoted);
        assertEquals("c", token.content.toString());
    }

    @Test
    void testNextTokenQuotedFieldWithEscapedQuote() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\"b\"\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a\"b", token.content.toString());
    }

    @Test
    void testNextTokenUnterminatedQuoteThrowsByDefault() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc");
        final Token token = new Token();
        final CSVException ex = assertThrows(CSVException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(ex.getMessage().contains("EOF reached before encapsulated token finished"));
    }

    @Test
    void testNextTokenUnterminatedQuoteLenientEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
    }

    @Test
    void testNextTokenInvalidCharAfterEncapsulatedTokenThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"b,c\n");
        final Token token = new Token();
        assertThrows(CSVException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
    }

    @Test
    void testNextTokenTrailingDataAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"a\"b,c\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("ab", token.content.toString());
    }

    @Test
    void testNextTokenIgnoreEmptyLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "\n\na,b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
    }

    @Test
    void testNextTokenEmptyLinesAtEndOfFileAreEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "a\n\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
    }

    @Test
    void testNextTokenEmptyLinesNotIgnored() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "\na,b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("", token.content.toString());
    }

    @Test
    void testNextTokenComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "# a comment\na,b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
    }

    @Test
    void testNextTokenCommentAtEndOfFileWithoutNewlineIsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "#comment");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("comment", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    void testNextTokenIgnoreSurroundingSpaces() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  , b \n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
    }

    @Test
    void testNextTokenEscapedCharacterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\,b,c\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        // The escaped comma is unescaped into the token's content rather than treated as a delimiter.
        assertEquals("a,b", token.content.toString());
    }

    @Test
    void testNextTokenEscapedDelimiterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final Lexer lexer = createLexer(format, "a!:!:b::c\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a::b", token.content.toString());
    }

    @Test
    void testIsEscapeDelimiterTrueConsumesInput() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!:!:rest"));
        final Lexer lexer = new Lexer(format, reader);
        // The leading escape char is consumed first, as happens in the normal nextToken flow
        // right before isEscapeDelimiter() is called to check what follows it.
        assertEquals('!', reader.read());
        assertTrue(lexer.isEscapeDelimiter());
        // The 3 remaining escape-delimiter characters are consumed, leaving only "rest".
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals("rest", token.content.toString());
    }

    @Test
    void testIsEscapeDelimiterFalseWhenFirstCharMismatches() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!xxxx"));
        final Lexer lexer = new Lexer(format, reader);
        assertEquals('!', reader.read());
        assertFalse(lexer.isEscapeDelimiter());
    }

    @Test
    void testReadEscapeNamedEscapes() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "rntbf");
        assertEquals(Constants.CR, lexer.readEscape());
        assertEquals(Constants.LF, lexer.readEscape());
        assertEquals(Constants.TAB, lexer.readEscape());
        assertEquals(Constants.BACKSPACE, lexer.readEscape());
        assertEquals(Constants.FF, lexer.readEscape());
    }

    @Test
    void testReadEscapePassThroughMetaChar() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "\"");
        assertEquals('"', lexer.readEscape());
    }

    @Test
    void testReadEscapeUnexpectedCharReturnsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "z");
        assertEquals(EOF, lexer.readEscape());
    }

    @Test
    void testReadEscapeAtEndOfFileThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertThrows(CSVException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
    }

    @Test
    void testTrimTrailingSpaces() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testTrimTrailingSpacesAllWhitespace() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals(0, sb.length());
    }

    @Test
    void testTrimTrailingSpacesNoTrailingWhitespace() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }
}
