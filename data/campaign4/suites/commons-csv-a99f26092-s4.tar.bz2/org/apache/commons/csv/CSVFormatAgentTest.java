package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link CSVFormat}, based solely on its published javadoc contract.
 */
public class CSVFormatAgentTest {

    private enum SampleHeader {
        NAME, EMAIL, PHONE
    }

    // ---------------------------------------------------------------------
    // Predefined format constants
    // ---------------------------------------------------------------------

    @Test
    public void testDefaultFormat() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
    }

    @Test
    public void testExcelFormat() {
        assertEquals(",", CSVFormat.EXCEL.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.EXCEL.getDuplicateHeaderMode());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    public void testInformixUnloadFormat() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD_CSV.getRecordSeparator());
    }

    @Test
    public void testMongoDbCsvFormat() {
        assertEquals(",", CSVFormat.MONGODB_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_CSV.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFormat() {
        assertEquals("\t", CSVFormat.MONGODB_TSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_TSV.getQuoteMode());
        assertFalse(CSVFormat.MONGODB_TSV.getSkipHeaderRecord());
    }

    @Test
    public void testMySqlFormat() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    public void testOracleFormat() {
        assertEquals(",", CSVFormat.ORACLE.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.ORACLE.getEscapeCharacter());
        assertFalse(CSVFormat.ORACLE.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), CSVFormat.ORACLE.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.ORACLE.getNullString());
        assertTrue(CSVFormat.ORACLE.getTrim());
        assertEquals(System.lineSeparator(), CSVFormat.ORACLE.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.ORACLE.getQuoteMode());
    }

    @Test
    public void testPostgresqlCsvFormat() {
        assertEquals(",", CSVFormat.POSTGRESQL_CSV.getDelimiterString());
        assertNull(CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertFalse(CSVFormat.POSTGRESQL_CSV.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), CSVFormat.POSTGRESQL_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_CSV.getRecordSeparator());
        assertEquals("", CSVFormat.POSTGRESQL_CSV.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_CSV.getQuoteMode());
    }

    @Test
    public void testPostgresqlTextFormat() {
        assertEquals("\t", CSVFormat.POSTGRESQL_TEXT.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.POSTGRESQL_TEXT.getEscapeCharacter());
        assertFalse(CSVFormat.POSTGRESQL_TEXT.getIgnoreEmptyLines());
        assertNull(CSVFormat.POSTGRESQL_TEXT.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_TEXT.getRecordSeparator());
        assertEquals("\\N", CSVFormat.POSTGRESQL_TEXT.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_TEXT.getQuoteMode());
    }

    @Test
    public void testRfc4180Format() {
        assertEquals(",", CSVFormat.RFC4180.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfFormat() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
        // Inherited from DEFAULT, not overridden by TDF.
        assertTrue(CSVFormat.TDF.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.TDF.getDuplicateHeaderMode());
        assertEquals(Character.valueOf('"'), CSVFormat.TDF.getQuoteCharacter());
    }

    @Test
    public void testPredefinedFormatsAreDistinct() {
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
        assertNotEquals(CSVFormat.MYSQL, CSVFormat.POSTGRESQL_TEXT);
    }

    // ---------------------------------------------------------------------
    // newFormat(char)
    // ---------------------------------------------------------------------

    @Test
    public void testNewFormatInitializesOnlyDelimiter() {
        CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getHeader());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getLenientEof());
        assertFalse(format.getTrailingData());
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // ---------------------------------------------------------------------
    // valueOf(String)
    // ---------------------------------------------------------------------

    @Test
    public void testValueOfKnownNames() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.valueOf("InformixUnload"));
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.valueOf("InformixUnloadCsv"));
        assertEquals(CSVFormat.MONGODB_CSV, CSVFormat.valueOf("MongoDBCsv"));
        assertEquals(CSVFormat.MONGODB_TSV, CSVFormat.valueOf("MongoDBTsv"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.ORACLE, CSVFormat.valueOf("Oracle"));
        assertEquals(CSVFormat.POSTGRESQL_CSV, CSVFormat.valueOf("PostgreSQLCsv"));
        assertEquals(CSVFormat.POSTGRESQL_TEXT, CSVFormat.valueOf("PostgreSQLText"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    public void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NoSuchPredefinedFormat");
            }
        });
    }

    // ---------------------------------------------------------------------
    // CSVFormat.Predefined
    // ---------------------------------------------------------------------

    @Test
    public void testPredefinedGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
    }

    @Test
    public void testPredefinedValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Predefined.valueOf("NoSuchEnumConstant");
            }
        });
    }

    // ---------------------------------------------------------------------
    // builder() / Builder.create() / get() / copy()
    // ---------------------------------------------------------------------

    @Test
    public void testBuilderFromInstanceKeepsSettings() {
        CSVFormat rebuilt = CSVFormat.DEFAULT.builder().get();
        assertEquals(CSVFormat.DEFAULT, rebuilt);
    }

    @Test
    public void testBuilderCreateDefaults() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();
        CSVFormat format = builder.get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testBuilderCreateFromFormat() {
        CSVFormat.Builder builder = CSVFormat.Builder.create(CSVFormat.MYSQL);
        assertEquals(CSVFormat.MYSQL, builder.get());
    }

    @Test
    public void testDeprecatedBuildMatchesGet() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertEquals(builder.get(), builder.build());
    }

    @Test
    public void testCopyInstanceMethod() {
        CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("x").get();
        CSVFormat copy = original.copy();
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    public void testStaticCopyIsNullSafe() {
        assertNull(CSVFormat.copy((CSVFormat) null));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.copy(CSVFormat.DEFAULT));
    }

    // ---------------------------------------------------------------------
    // clone(T...)
    // ---------------------------------------------------------------------

    @Test
    public void testCloneCopiesArray() {
        String[] source = { "a", "b" };
        String[] cloned = CSVFormat.<String>clone(source);
        assertArrayEquals(source, cloned);
        assertNotSame(source, cloned);
    }

    @Test
    public void testCloneIsNullSafe() {
        String[] cloned = CSVFormat.<String>clone((String[]) null);
        assertNull(cloned);
    }

    // ---------------------------------------------------------------------
    // equals / hashCode / toString
    // ---------------------------------------------------------------------

    @Test
    public void testEqualsAndHashCodeForEquivalentFormats() {
        CSVFormat other = CSVFormat.newFormat(',').builder()
                .setQuote('"')
                .setRecordSeparator("\r\n")
                .setIgnoreEmptyLines(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
                .get();
        assertEquals(CSVFormat.DEFAULT, other);
        assertEquals(CSVFormat.DEFAULT.hashCode(), other.hashCode());
    }

    @Test
    public void testEqualsReflexiveAndTypeSafe() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(CSVFormat.DEFAULT, null);
        assertNotEquals(CSVFormat.DEFAULT, "not a CSVFormat");
    }

    @Test
    public void testToStringIsNotNull() {
        assertNotNull(CSVFormat.DEFAULT.toString());
    }

    // ---------------------------------------------------------------------
    // Package-private helper getters
    // ---------------------------------------------------------------------

    @Test
    public void testGetDelimiterCharArray() {
        assertArrayEquals(new char[] { ',' }, CSVFormat.DEFAULT.getDelimiterCharArray());
        assertArrayEquals(new char[] { '\t' }, CSVFormat.TDF.getDelimiterCharArray());
    }

    @Test
    public void testGetEscapeChar() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        assertEquals('\\', CSVFormat.MYSQL.getEscapeChar());
    }

    // ---------------------------------------------------------------------
    // Comment marker
    // ---------------------------------------------------------------------

    @Test
    public void testCommentMarkerDefaultsToUnset() {
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
    }

    @Test
    public void testCommentMarkerRoundTrip() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    public void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker(Character.valueOf('\r'));
            }
        });
    }

    // ---------------------------------------------------------------------
    // Escape character
    // ---------------------------------------------------------------------

    @Test
    public void testEscapeCharacterDefaultsToUnset() {
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
    }

    @Test
    public void testEscapeCharacterRoundTrip() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    public void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setEscape('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setEscape(Character.valueOf('\r'));
            }
        });
    }

    // ---------------------------------------------------------------------
    // Quote character
    // ---------------------------------------------------------------------

    @Test
    public void testQuoteCharacterDefaultOnDefaultFormat() {
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
    }

    @Test
    public void testQuoteCharacterCanBeDisabled() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setQuote('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setQuote(Character.valueOf('\r'));
            }
        });
    }

    // ---------------------------------------------------------------------
    // Null string
    // ---------------------------------------------------------------------

    @Test
    public void testNullStringDefaultsToUnset() {
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
    }

    @Test
    public void testNullStringRoundTrip() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("N/A").get();
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    // ---------------------------------------------------------------------
    // Header / header comments (defensive copy semantics)
    // ---------------------------------------------------------------------

    @Test
    public void testHeaderDefaultsToNull() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testHeaderAutoDetectedIsEmptyArray() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertArrayEquals(new String[0], format.getHeader());
    }

    @Test
    public void testHeaderCanBeDisabledAfterBeingSet() {
        CSVFormat withHeader = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        CSVFormat withoutHeader = withHeader.builder().setHeader((String[]) null).get();
        assertArrayEquals(new String[] { "a", "b" }, withHeader.getHeader());
        assertNull(withoutHeader.getHeader());
    }

    @Test
    public void testHeaderGetterReturnsIndependentCopies() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b", "c").get();
        String[] first = format.getHeader();
        String[] second = format.getHeader();
        assertArrayEquals(new String[] { "a", "b", "c" }, first);
        assertNotSame(first, second);
    }

    @Test
    public void testHeaderSetterKeepsDefensiveCopy() {
        String[] source = { "a", "b" };
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(source).get();
        source[0] = "changed";
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    public void testHeaderFromEnumClass() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(SampleHeader.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    public void testHeaderCommentsDefaultsToNull() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    public void testHeaderCommentsGetterReturnsIndependentCopies() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        String[] first = format.getHeaderComments();
        String[] second = format.getHeaderComments();
        assertArrayEquals(new String[] { "c1", "c2" }, first);
        assertNotSame(first, second);
    }

    @Test
    public void testHeaderCommentsSetterKeepsDefensiveCopy() {
        Object[] source = { "x", "y" };
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(source).get();
        source[0] = "changed";
        assertArrayEquals(new String[] { "x", "y" }, format.getHeaderComments());
    }

    // ---------------------------------------------------------------------
    // Simple boolean / numeric settings
    // ---------------------------------------------------------------------

    @Test
    public void testAllowMissingColumnNames() {
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).get().getAllowMissingColumnNames());
    }

    @Test
    public void testAutoFlush() {
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
        assertTrue(CSVFormat.DEFAULT.builder().setAutoFlush(true).get().getAutoFlush());
    }

    @Test
    public void testIgnoreHeaderCase() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(true).get().getIgnoreHeaderCase());
    }

    @Test
    public void testIgnoreSurroundingSpaces() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testLenientEof() {
        assertFalse(CSVFormat.DEFAULT.getLenientEof());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    public void testMaxRowsDefaultsToZeroMeaningNoLimit() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        assertEquals(5L, CSVFormat.DEFAULT.builder().setMaxRows(5L).get().getMaxRows());
    }

    @Test
    public void testSkipHeaderRecord() {
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.builder().setSkipHeaderRecord(true).get().getSkipHeaderRecord());
    }

    @Test
    public void testTrailingData() {
        assertFalse(CSVFormat.DEFAULT.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
    }

    @Test
    public void testTrailingDelimiter() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get().getTrailingDelimiter());
    }

    @Test
    public void testTrim() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertTrue(CSVFormat.ORACLE.getTrim());
    }

    @Test
    public void testQuoteMode() {
        assertNull(CSVFormat.DEFAULT.getQuoteMode());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.ORACLE.getQuoteMode());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    public void testDeprecatedGetDelimiterMatchesFirstCharOfDelimiterString() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    public void testDeprecatedGetAllowDuplicateHeaderNamesReflectsDuplicateHeaderMode() {
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
    }

    // ---------------------------------------------------------------------
    // Deprecated with*(...) methods
    // ---------------------------------------------------------------------

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withQuote('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withQuote(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withEscape('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withEscape(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testWithNullString() {
        CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithHeaderStrings() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    public void testWithHeaderEnumClass() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader(SampleHeader.class);
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    public void testWithHeaderComments() {
        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("c1", "c2");
        assertArrayEquals(new String[] { "c1", "c2" }, format.getHeaderComments());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    public void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.withAutoFlush(false).getAutoFlush());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithAllowDuplicateHeaderNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    @Test
    public void testWithQuoteMode() {
        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testWithRecordSeparator() {
        assertEquals("|", CSVFormat.DEFAULT.withRecordSeparator('|').getRecordSeparator());
        assertEquals("||", CSVFormat.DEFAULT.withRecordSeparator("||").getRecordSeparator());
    }

    @Test
    public void testWithSystemRecordSeparator() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    // ---------------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------------

    @Test
    public void testFormatWithNoSpecialCharacters() {
        assertEquals("a,b,c", CSVFormat.RFC4180.format("a", "b", "c"));
    }

    @Test
    public void testFormatWithNoValues() {
        assertEquals("", CSVFormat.RFC4180.format());
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\"", CSVFormat.RFC4180.format("a,b"));
    }

    @Test
    public void testFormatDoublesEmbeddedQuoteCharacter() {
        assertEquals("\"a\"\"b\"", CSVFormat.RFC4180.format("a\"b"));
    }

    // ---------------------------------------------------------------------
    // print / println / printRecord / parse
    // ---------------------------------------------------------------------

    @Test
    public void testPrintToAppendableReturnsNonNullPrinter() throws IOException {
        StringWriter writer = new StringWriter();
        CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        assertNotNull(printer);
    }

    @Test
    public void testPrintRecordWritesDelimitedValuesFollowedBySeparator() throws IOException {
        StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b");
        assertEquals("a,b\r\n", writer.toString());
    }

    @Test
    public void testPrintlnWritesOnlyRecordSeparatorWhenNoTrailingDelimiter() throws IOException {
        StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    public void testPrintlnWritesTrailingDelimiterWhenSet() throws IOException {
        StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get().println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    public void testPrintValueJoinsSubsequentValuesWithDelimiter() throws IOException {
        StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("a", writer, true);
        CSVFormat.DEFAULT.print("b", writer, false);
        assertEquals("a,b", writer.toString());
    }

    @Test
    public void testPrintValueTrimsWhenTrimEnabled() throws IOException {
        StringWriter writer = new StringWriter();
        CSVFormat trimming = CSVFormat.DEFAULT.builder().setTrim(true).get();
        trimming.print("  a  ", writer, true);
        assertEquals("a", writer.toString());
    }

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b\r\n"));
        assertNotNull(parser);
    }
}
