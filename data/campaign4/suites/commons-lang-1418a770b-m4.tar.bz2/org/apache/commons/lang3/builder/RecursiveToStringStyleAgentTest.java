/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.mutable.MutableBoolean;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RecursiveToStringStyle}.
 */
class RecursiveToStringStyleAgentTest {

    static class Inner {
        String label = "inner-label";
    }

    static class Outer {
        Inner inner = new Inner();
        String name = "outer-name";
    }

    private String identityHashCodeHex(final Object object) {
        return Integer.toHexString(System.identityHashCode(object));
    }

    @Test
    void testAcceptAtomicBooleanReturnsFalse() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(AtomicBoolean.class));
    }

    @Test
    void testAcceptCustomClassReturnsTrue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertTrue(style.accept(Outer.class));
        assertTrue(style.accept(Inner.class));
    }

    @Test
    void testAcceptMutableBooleanReturnsFalse() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(MutableBoolean.class));
    }

    @Test
    void testAcceptNumberSubclassReturnsFalse() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(BigDecimal.class));
        assertFalse(style.accept(BigInteger.class));
    }

    @Test
    void testAcceptObjectClassReturnsTrue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertTrue(style.accept(Object.class));
    }

    @Test
    void testAcceptPrimitiveWrapperReturnsFalse() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(Integer.class));
        assertFalse(style.accept(Boolean.class));
        assertFalse(style.accept(Double.class));
        assertFalse(style.accept(Character.class));
    }

    @Test
    void testAcceptStringReturnsFalse() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(String.class));
    }

    @Test
    void testAppendDetailAtomicBooleanDelegatesToSuper() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "flag", new AtomicBoolean(true));
        assertEquals("true", buffer.toString());
    }

    @Test
    void testAppendDetailCollectionIsRecursivelyFormatted() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final List<Integer> coll = new ArrayList<Integer>();
        coll.add(1);
        coll.add(2);

        final StringBuffer actual = new StringBuffer();
        style.appendDetail(actual, "numbers", coll);

        final StringBuffer expected = new StringBuffer();
        style.appendClassName(expected, coll);
        style.appendIdentityHashCode(expected, coll);
        expected.append(style.getArrayStart());
        expected.append(1);
        expected.append(style.getArraySeparator());
        expected.append(2);
        expected.append(style.getArrayEnd());

        assertEquals(expected.toString(), actual.toString());
        assertTrue(actual.toString().contains(coll.getClass().getName()));
        assertTrue(actual.toString().contains("@" + identityHashCodeHex(coll)));
    }

    @Test
    void testAppendDetailCollectionOfEmptyCollection() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final List<Object> coll = new ArrayList<Object>();

        final StringBuffer actual = new StringBuffer();
        style.appendDetail(actual, "empty", coll);

        final String expectedPrefix = coll.getClass().getName() + "@" + identityHashCodeHex(coll);
        assertEquals(expectedPrefix + style.getArrayStart() + style.getArrayEnd(), actual.toString());
    }

    @Test
    void testAppendDetailCustomObjectIsRecursivelyFormatted() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final Inner inner = new Inner();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "inner", inner);

        final String result = buffer.toString();
        assertTrue(result.startsWith(inner.getClass().getName() + "@" + identityHashCodeHex(inner)));
        assertTrue(result.contains("label=inner-label"));
    }

    @Test
    void testAppendDetailIntegerValueDelegatesToSuper() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "age", Integer.valueOf(42));
        assertEquals("42", buffer.toString());
    }

    @Test
    void testAppendDetailMutableBooleanDelegatesToSuper() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "flag", new MutableBoolean(false));
        assertEquals("false", buffer.toString());
    }

    @Test
    void testAppendDetailNullValueDelegatesToSuper() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", (Object) null);
        assertEquals("null", buffer.toString());
    }

    @Test
    void testAppendDetailStringValueDelegatesToSuper() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "name", "hello");
        assertEquals("hello", buffer.toString());
    }

    @Test
    void testToStringBuilderFullyRecursesNestedObjectGraph() {
        final Outer outer = new Outer();
        final String result = new ReflectionToStringBuilder(outer, new RecursiveToStringStyle()).toString();

        assertTrue(result.startsWith(outer.getClass().getName() + "@" + identityHashCodeHex(outer)));
        assertTrue(result.contains("name=outer-name"));
        assertTrue(result.contains("inner=" + outer.inner.getClass().getName() + "@" + identityHashCodeHex(outer.inner)));
        assertTrue(result.contains("label=inner-label"));
    }

    @Test
    void testToStringBuilderOnNullObjectReturnsNullText() {
        final String result = ReflectionToStringBuilder.toString(null, new RecursiveToStringStyle());
        assertEquals("<null>", result);
    }
}
