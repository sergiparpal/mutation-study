package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}, based solely on its documented contract.
 */
public class ClassUtilsAgentTest {

    interface IfaceA {
        // marker interface
    }

    interface IfaceB extends IfaceA {
        // marker interface extending IfaceA
    }

    static class Base implements IfaceB {
        // fixture base class
    }

    static class Sub extends Base {
        // fixture subclass
    }

    private static class PrivateNested {
        // fixture private nested class
    }

    class NonStaticInner {
        // fixture non-static inner class
    }

    // ----- Fields -----

    @Test
    public void testFields() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    // ----- comparator() -----

    @Test
    public void testComparator() {
        Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        assertTrue(comparator.compare(String.class, Integer.class) > 0);
        assertTrue(comparator.compare(Integer.class, String.class) < 0);
        assertEquals(0, comparator.compare(String.class, String.class));

        List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        Collections.sort(list, comparator);
        List<Class<?>> expected = new ArrayList<Class<?>>();
        expected.add(Boolean.class);
        expected.add(Integer.class);
        expected.add(String.class);
        assertEquals(expected, list);
    }

    // ----- convertClassesToClassNames(List) -----

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));

        List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        classes.add(Integer.class);
        List<String> names = ClassUtils.convertClassesToClassNames(classes);
        List<String> expected = new ArrayList<String>();
        expected.add("java.lang.String");
        expected.add(null);
        expected.add("java.lang.Integer");
        assertEquals(expected, names);
    }

    @Test
    public void testConvertClassesToClassNamesClassCastException() {
        final List rawList = new ArrayList();
        rawList.add("not a class");
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.convertClassesToClassNames(rawList);
            }
        });
    }

    // ----- convertClassNamesToClasses(List) -----

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));

        List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add(null);
        names.add("not.a.real.ClassName");
        names.add("java.lang.Integer");
        List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        List<Class<?>> expected = new ArrayList<Class<?>>();
        expected.add(String.class);
        expected.add(null);
        expected.add(null);
        expected.add(Integer.class);
        assertEquals(expected, classes);
    }

    @Test
    public void testConvertClassNamesToClassesClassCastException() {
        final List rawList = new ArrayList();
        rawList.add(Integer.valueOf(1));
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.convertClassNamesToClasses(rawList);
            }
        });
    }

    // ----- getAbbreviatedName -----

    @Test
    public void testGetAbbreviatedNameFromString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("", ClassUtils.getAbbreviatedName("", 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 1));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameFromStringInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameFromClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 5));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameFromClassInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
    }

    // ----- getAllInterfaces / getAllSuperclasses -----

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));

        List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Sub.class);
        assertNotNull(interfaces);
        assertEquals(2, interfaces.size());
        assertTrue(interfaces.contains(IfaceB.class));
        assertTrue(interfaces.contains(IfaceA.class));
        assertTrue(interfaces.indexOf(IfaceB.class) < interfaces.indexOf(IfaceA.class));

        List<Class<?>> none = ClassUtils.getAllInterfaces(Object.class);
        assertNotNull(none);
        assertTrue(none.isEmpty());
    }

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));

        List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Sub.class);
        List<Class<?>> expected = new ArrayList<Class<?>>();
        expected.add(Base.class);
        expected.add(Object.class);
        assertEquals(expected, superclasses);

        List<Class<?>> none = ClassUtils.getAllSuperclasses(Object.class);
        assertNotNull(none);
        assertTrue(none.isEmpty());
    }

    // ----- getCanonicalName -----

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("MISSING", ClassUtils.getCanonicalName((Class<?>) null, "MISSING"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "MISSING"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc"));
        assertEquals("MISSING", ClassUtils.getCanonicalName((Object) null, "MISSING"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc", "MISSING"));
    }

    // ----- getClass -----

    @Test
    public void testGetClassByName() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
    }

    @Test
    public void testGetClassByNameWhitespaceNormalized() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass(" java.lang.String "));
    }

    @Test
    public void testGetClassByNameNullPointer() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassByNameNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("not.a.real.ClassName");
            }
        });
    }

    @Test
    public void testGetClassByNameAndInitialize() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", false));
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", true));
    }

    @Test
    public void testGetClassByClassLoaderAndName() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(int[].class, ClassUtils.getClass(loader, "[I"));
    }

    @Test
    public void testGetClassByClassLoaderNameAndInitialize() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", false));
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", true));
    }

    // ----- getComponentType -----

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(Integer.class, ClassUtils.getComponentType(Integer[].class));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // ----- getName -----

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("MISSING", ClassUtils.getName((Class<?>) null, "MISSING"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "MISSING"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.Integer", ClassUtils.getName(Integer.valueOf(1)));
        assertEquals("MISSING", ClassUtils.getName((Object) null, "MISSING"));
        assertEquals("java.lang.Integer", ClassUtils.getName(Integer.valueOf(1), "MISSING"));
    }

    // ----- getPackageCanonicalName -----

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObject() {
        assertEquals("MISSING", ClassUtils.getPackageCanonicalName((Object) null, "MISSING"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("abc", "MISSING"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
    }

    // ----- getPackageName -----

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("org.apache.commons.lang3", ClassUtils.getPackageName(Base.class));
    }

    @Test
    public void testGetPackageNameObject() {
        assertEquals("MISSING", ClassUtils.getPackageName((Object) null, "MISSING"));
        assertEquals("java.lang", ClassUtils.getPackageName("abc", "MISSING"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName("NoPackageClassName"));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
    }

    // ----- getPublicMethod -----

    @Test
    public void testGetPublicMethod() throws NoSuchMethodException {
        java.util.List<Object> unmodifiable = Collections.unmodifiableList(new ArrayList<Object>());
        Method method = ClassUtils.getPublicMethod(unmodifiable.getClass(), "isEmpty", new Class[0]);
        assertNotNull(method);
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
    }

    @Test
    public void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodAtAll", new Class[0]);
            }
        });
    }

    // ----- getShortCanonicalName -----

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName(ClassUtils.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
    }

    @Test
    public void testGetShortCanonicalNameObject() {
        assertEquals("MISSING", ClassUtils.getShortCanonicalName((Object) null, "MISSING"));
        assertEquals("String", ClassUtils.getShortCanonicalName("abc", "MISSING"));
    }

    @Test
    public void testGetShortCanonicalNameString() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[]"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[][]"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("int[]"));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("[[I"));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("int[][]"));
    }

    // ----- getShortClassName -----

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("ClassUtilsAgentTest.Base", ClassUtils.getShortClassName(Base.class));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("MISSING", ClassUtils.getShortClassName((Object) null, "MISSING"));
        assertEquals("String", ClassUtils.getShortClassName("abc", "MISSING"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    // ----- getSimpleName -----

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("MISSING", ClassUtils.getSimpleName((Class<?>) null, "MISSING"));
        assertEquals("String", ClassUtils.getSimpleName(String.class, "MISSING"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("Integer", ClassUtils.getSimpleName(Integer.valueOf(1)));
        assertEquals("MISSING", ClassUtils.getSimpleName((Object) null, "MISSING"));
        assertEquals("Integer", ClassUtils.getSimpleName(Integer.valueOf(1), "MISSING"));
    }

    // ----- hierarchy -----

    @Test
    public void testHierarchyExcludingInterfaces() {
        List<Class<?>> hierarchy = toList(ClassUtils.hierarchy(Sub.class));
        List<Class<?>> expected = new ArrayList<Class<?>>();
        expected.add(Sub.class);
        expected.add(Base.class);
        expected.add(Object.class);
        assertEquals(expected, hierarchy);
    }

    @Test
    public void testHierarchyExcludeInterfacesExplicit() {
        List<Class<?>> hierarchy = toList(ClassUtils.hierarchy(Base.class, ClassUtils.Interfaces.EXCLUDE));
        List<Class<?>> expected = new ArrayList<Class<?>>();
        expected.add(Base.class);
        expected.add(Object.class);
        assertEquals(expected, hierarchy);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        List<Class<?>> hierarchy = toList(ClassUtils.hierarchy(Base.class, ClassUtils.Interfaces.INCLUDE));
        assertEquals(Base.class, hierarchy.get(0));
        assertTrue(hierarchy.contains(IfaceA.class));
        assertTrue(hierarchy.contains(IfaceB.class));
        assertTrue(hierarchy.contains(Object.class));
    }

    private static List<Class<?>> toList(Iterable<Class<?>> iterable) {
        List<Class<?>> list = new ArrayList<Class<?>>();
        Iterator<Class<?>> it = iterable.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list;
    }

    // ----- isAssignable -----

    @Test
    public void testIsAssignableClassClass() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, String.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignableClassClassAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableClassArray() {
        Class<?>[] args = new Class<?>[] {String.class, Integer.class};
        Class<?>[] params = new Class<?>[] {Object.class, Number.class};
        assertTrue(ClassUtils.isAssignable(args, params));

        Class<?>[] mismatch = new Class<?>[] {String.class};
        assertFalse(ClassUtils.isAssignable(mismatch, params));
    }

    @Test
    public void testIsAssignableClassArrayAutoboxing() {
        Class<?>[] args = new Class<?>[] {int.class};
        Class<?>[] params = new Class<?>[] {Integer.class};
        assertTrue(ClassUtils.isAssignable(args, params, true));
        assertFalse(ClassUtils.isAssignable(args, params, false));
    }

    // ----- isInnerClass -----

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Base.class));
        assertTrue(ClassUtils.isInnerClass(PrivateNested.class));
        assertTrue(ClassUtils.isInnerClass(NonStaticInner.class));
    }

    // ----- isPrimitiveOrWrapper / isPrimitiveWrapper -----

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(boolean.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    // ----- isPublic -----

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateNested.class));
    }

    // ----- primitivesToWrappers / primitiveToWrapper -----

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.primitivesToWrappers());
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, Boolean.class},
                ClassUtils.primitivesToWrappers(int.class, String.class, boolean.class));
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Boolean.class, ClassUtils.primitiveToWrapper(boolean.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    // ----- toClass -----

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.toClass());
        assertArrayEquals(new Class<?>[] {String.class, null, Integer.class},
                ClassUtils.toClass("abc", null, Integer.valueOf(1)));
    }

    // ----- wrappersToPrimitives / wrapperToPrimitive -----

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.wrappersToPrimitives());
        assertArrayEquals(new Class<?>[] {int.class, null},
                ClassUtils.wrappersToPrimitives(Integer.class, String.class));
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }
}
