package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link FastDateParser}, based strictly on the documented contract
 * (javadoc) of the class, since no implementation source is available.
 */
public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date buildDate(TimeZone zone, int year, int month0, int day, int hour, int minute, int second) {
        Calendar cal = Calendar.getInstance(zone);
        cal.clear();
        cal.set(year, month0, day, hour, minute, second);
        return cal.getTime();
    }

    private static FastDateParser newParser(String pattern, TimeZone zone, Locale locale) {
        return new FastDateParser(pattern, zone, locale);
    }

    private static FastDateParser newParser(String pattern, TimeZone zone, Locale locale, Date centuryStart) {
        return new FastDateParser(pattern, zone, locale, centuryStart);
    }

    // ---- Constructors and simple getters ----------------------------------

    @Test
    public void testThreeArgConstructorStoresFields() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorStoresFields() {
        Date centuryStart = buildDate(UTC, 1980, Calendar.JANUARY, 1, 0, 0, 0);
        FastDateParser parser = newParser("yy-MM-dd", UTC, Locale.FRANCE, centuryStart);
        assertEquals("yy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.FRANCE, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorNullLocaleMapsToDefaultLocale() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, null, new Date(0));
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    // ---- getPatterns (package-private) -------------------------------------

    @Test
    public void testGetPatternsReturnsNonEmptyList() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        List<?> patterns = parser.getPatterns();
        assertNotNull(patterns);
        assertTrue(patterns.size() > 0);
    }

    // ---- parse(String) ------------------------------------------------------

    @Test
    public void testParseStringHappyPath() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("2023-01-15");
        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testParseStringOnlyNeedsLeadingPortionOfSource() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("2023-01-15 trailing garbage that is not parsed");
        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testParseStringThrowsParseExceptionOnUnparsableInput() {
        final FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                parser.parse("not-a-date-at-all");
            }
        });
    }

    @Test
    public void testParseStringHonorsTimeZone() throws ParseException {
        TimeZone plusFive = TimeZone.getTimeZone("GMT+05:00");
        FastDateParser utcParser = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser plusFiveParser = newParser("yyyy-MM-dd", plusFive, Locale.US);

        Date utcDate = utcParser.parse("2023-01-15");
        Date plusFiveDate = plusFiveParser.parse("2023-01-15");

        long fiveHoursInMillis = 5L * 60L * 60L * 1000L;
        assertEquals(fiveHoursInMillis, utcDate.getTime() - plusFiveDate.getTime());
    }

    @Test
    public void testParseStringLenientMinuteOverflow() throws ParseException {
        // The class javadoc documents that lenient mode treats a time of 90
        // minutes as 1 hour 30 minutes, matching java.util.Calendar's own
        // lenient field normalization.
        FastDateParser parser = newParser("yyyy-MM-dd HH:mm", UTC, Locale.US);
        Date actual = parser.parse("2023-01-15 01:90");

        Calendar expectedCal = Calendar.getInstance(UTC);
        expectedCal.clear();
        expectedCal.set(2023, Calendar.JANUARY, 15, 1, 90);
        assertEquals(expectedCal.getTime(), actual);
    }

    @Test
    public void testParseStringLenientMonthOverflow() throws ParseException {
        // Month 13 (1-based, i.e. Calendar.MONTH value 12) rolls over into
        // January of the following year under lenient Calendar semantics.
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("2023-13-01");

        Calendar expectedCal = Calendar.getInstance(UTC);
        expectedCal.clear();
        expectedCal.set(2023, 12, 1, 0, 0, 0);
        assertEquals(expectedCal.getTime(), actual);
    }

    @Test
    public void testParseStringHandlesQuotedLiteralText() throws ParseException {
        FastDateParser parser = newParser("'Date:' yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("Date: 2023-01-15");
        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testParseStringTwoDigitYearUsesCenturyStart() throws ParseException {
        Date centuryStart1980 = buildDate(UTC, 1980, Calendar.JANUARY, 1, 0, 0, 0);
        Date centuryStart1900 = buildDate(UTC, 1900, Calendar.JANUARY, 1, 0, 0, 0);

        FastDateParser parser1980 = newParser("yy-MM-dd", UTC, Locale.US, centuryStart1980);
        FastDateParser parser1900 = newParser("yy-MM-dd", UTC, Locale.US, centuryStart1900);

        Calendar cal1980 = Calendar.getInstance(UTC);
        cal1980.setTime(parser1980.parse("30-06-15"));
        assertEquals(2030, cal1980.get(Calendar.YEAR));

        Calendar cal1900 = Calendar.getInstance(UTC);
        cal1900.setTime(parser1900.parse("30-06-15"));
        assertEquals(1930, cal1900.get(Calendar.YEAR));
    }

    // ---- parse(String, ParsePosition) ---------------------------------------

    @Test
    public void testParseWithParsePositionSuccessUpdatesIndex() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date actual = parser.parse("2023-01-15", pos);

        assertNotNull(actual);
        assertEquals(10, pos.getIndex());
        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testParseWithParsePositionFailureReturnsNullAndSetsErrorIndex() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date actual = parser.parse("garbage", pos);

        assertNull(actual);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    public void testParseWithParsePositionEmptySourceFails() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date actual = parser.parse("", pos);

        assertNull(actual);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    // ---- parse(String, ParsePosition, Calendar) -----------------------------

    @Test
    public void testParseIntoCalendarSuccessReturnsTrueAndUpdatesCalendar() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Calendar calendar = Calendar.getInstance(UTC);
        calendar.clear();

        boolean result = parser.parse("2023-01-15", pos, calendar);

        assertTrue(result);
        assertEquals(10, pos.getIndex());
        assertEquals(2023, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseIntoCalendarFailureReturnsFalseAndSetsErrorIndex() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Calendar calendar = Calendar.getInstance(UTC);
        calendar.clear();

        boolean result = parser.parse("abcd-01-01", pos, calendar);

        assertFalse(result);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    public void testParseIntoNonLenientCalendarThrowsOnOutOfRangeField() {
        final FastDateParser parser = newParser("MM/dd/yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar calendar = Calendar.getInstance(UTC);
        calendar.clear();
        calendar.setLenient(false);

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                parser.parse("13/01/2023", pos, calendar);
            }
        });
    }

    // ---- parseObject(String) and parseObject(String, ParsePosition) --------

    @Test
    public void testParseObjectStringHappyPath() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        Object actual = parser.parseObject("2023-01-15");
        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
    }

    @Test
    public void testParseObjectStringThrowsParseExceptionOnUnparsableInput() {
        final FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                parser.parseObject("not-a-date-at-all");
            }
        });
    }

    @Test
    public void testParseObjectWithParsePositionSuccess() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Object actual = parser.parseObject("2023-01-15", pos);

        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
        assertEquals(10, pos.getIndex());
    }

    @Test
    public void testParseObjectWithParsePositionFailureReturnsNull() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Object actual = parser.parseObject("garbage", pos);

        assertNull(actual);
    }

    // ---- equals / hashCode ----------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(parser.equals(parser));
    }

    @Test
    public void testEqualsForEquivalentParsers() {
        FastDateParser parser1 = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = newParser("yyyy-MM-dd", UTC, Locale.US);

        assertTrue(parser1.equals(parser2));
        assertTrue(parser2.equals(parser1));
        assertEquals(parser1.hashCode(), parser2.hashCode());
    }

    @Test
    public void testEqualsForDifferentPattern() {
        FastDateParser parser1 = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = newParser("dd-MM-yyyy", UTC, Locale.US);
        assertFalse(parser1.equals(parser2));
    }

    @Test
    public void testEqualsForDifferentTimeZone() {
        FastDateParser parser1 = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = newParser("yyyy-MM-dd", TimeZone.getTimeZone("GMT+05:00"), Locale.US);
        assertFalse(parser1.equals(parser2));
    }

    @Test
    public void testEqualsForDifferentLocale() {
        FastDateParser parser1 = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = newParser("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertFalse(parser1.equals(parser2));
    }

    @Test
    public void testEqualsAgainstNullAndForeignType() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(parser.equals(null));
        assertFalse(parser.equals("yyyy-MM-dd"));
    }

    // ---- toString / toStringAll ------------------------------------------------

    @Test
    public void testToStringReturnsNonEmptyAndIsConsistent() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        String first = parser.toString();
        String second = parser.toString();

        assertNotNull(first);
        assertFalse(first.isEmpty());
        assertEquals(first, second);
    }

    @Test
    public void testToStringAllReturnsNonEmptyString() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        String all = parser.toStringAll();

        assertNotNull(all);
        assertFalse(all.isEmpty());
    }

    // ---- clear() (static cache) -------------------------------------------------

    @Test
    public void testClearDoesNotAffectSubsequentParsing() throws ParseException {
        FastDateParser.clear();

        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        Date actual = parser.parse("2023-01-15");
        Date expected = buildDate(UTC, 2023, Calendar.JANUARY, 15, 0, 0, 0);
        assertEquals(expected, actual);
    }

    // ---- Static field -----------------------------------------------------------

    @Test
    public void testJapaneseImperialLocaleFieldIsNotNull() {
        assertNotNull(FastDateParser.JAPANESE_IMPERIAL);
    }

    // ---- Interface / Serializable contract ---------------------------------------

    @Test
    public void testImplementsDateParserAndSerializable() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(parser instanceof org.apache.commons.lang3.time.DateParser);
        assertTrue(parser instanceof java.io.Serializable);
    }

    @Test
    public void testGetTimeZoneReturnsTimeZoneUsedToConstruct() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(UTC, parser.getTimeZone());
    }
}
