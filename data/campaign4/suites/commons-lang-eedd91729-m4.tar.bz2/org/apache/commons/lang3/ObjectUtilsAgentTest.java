/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ObjectUtils}.
 */
class ObjectUtilsAgentTest {

    /** Simple Cloneable fixture with a mutable field, for testing clone/cloneIfPossible. */
    static final class CloneableFixture implements Cloneable {
        int value;

        CloneableFixture(final int value) {
            this.value = value;
        }

        @Override
        public CloneableFixture clone() throws CloneNotSupportedException {
            return (CloneableFixture) super.clone();
        }
    }

    /** Cloneable fixture whose clone() always fails, for testing CloneFailedException. */
    static final class BrokenCloneableFixture implements Cloneable {
        @Override
        public BrokenCloneableFixture clone() {
            throw new UnsupportedOperationException("broken");
        }
    }

    /** Non-cloneable fixture, for testing clone()/cloneIfPossible() fallback behavior. */
    static final class NotCloneableFixture {
        // intentionally does not implement Cloneable
    }

    @Test
    void testAllNotNull() {
        assertTrue(ObjectUtils.allNotNull());
        assertTrue(ObjectUtils.allNotNull("a"));
        assertTrue(ObjectUtils.allNotNull("a", "b"));
        assertFalse(ObjectUtils.allNotNull((Object) null));
        assertFalse(ObjectUtils.allNotNull(null, null));
        assertFalse(ObjectUtils.allNotNull(null, "a"));
        assertFalse(ObjectUtils.allNotNull("a", null));
        assertFalse(ObjectUtils.allNotNull((Object[]) null));
    }

    @Test
    void testAllNull() {
        assertTrue(ObjectUtils.allNull());
        assertTrue(ObjectUtils.allNull((Object) null));
        assertTrue(ObjectUtils.allNull(null, null));
        assertTrue(ObjectUtils.allNull((Object[]) null));
        assertFalse(ObjectUtils.allNull("a"));
        assertFalse(ObjectUtils.allNull(null, "a"));
        assertFalse(ObjectUtils.allNull("a", null));
    }

    @Test
    void testAnyNotNull() {
        assertFalse(ObjectUtils.anyNotNull());
        assertFalse(ObjectUtils.anyNotNull((Object) null));
        assertFalse(ObjectUtils.anyNotNull(null, null));
        assertFalse(ObjectUtils.anyNotNull((Object[]) null));
        assertTrue(ObjectUtils.anyNotNull("a"));
        assertTrue(ObjectUtils.anyNotNull(null, "a"));
        assertTrue(ObjectUtils.anyNotNull("a", null));
    }

    @Test
    void testAnyNull() {
        assertFalse(ObjectUtils.anyNull());
        assertFalse(ObjectUtils.anyNull("a"));
        assertFalse(ObjectUtils.anyNull("a", "b"));
        assertTrue(ObjectUtils.anyNull((Object) null));
        assertTrue(ObjectUtils.anyNull(null, null));
        assertTrue(ObjectUtils.anyNull(null, "a"));
        assertTrue(ObjectUtils.anyNull((Object[]) null));
    }

    @Test
    void testCloneNull() {
        assertNull(ObjectUtils.clone((Object) null));
    }

    @Test
    void testCloneNotCloneable() {
        final NotCloneableFixture fixture = new NotCloneableFixture();
        assertNull(ObjectUtils.clone(fixture));
    }

    @Test
    void testCloneCloneableObject() {
        final CloneableFixture original = new CloneableFixture(42);
        final CloneableFixture cloned = ObjectUtils.clone(original);
        assertNotNull(cloned);
        assertNotSame(original, cloned);
        assertEquals(42, cloned.value);
    }

    @Test
    void testCloneArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ObjectUtils.clone(original);
        assertNotSame(original, cloned);
        assertArrayEquals(original, cloned);
    }

    @Test
    void testCloneObjectArray() {
        final String[] original = {"a", "b"};
        final String[] cloned = ObjectUtils.clone(original);
        assertNotSame(original, cloned);
        assertArrayEquals(original, cloned);
    }

    @Test
    void testCloneFailed() {
        final BrokenCloneableFixture fixture = new BrokenCloneableFixture();
        assertThrows(org.apache.commons.lang3.exception.CloneFailedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.clone(fixture);
            }
        });
    }

    @Test
    void testCloneIfPossibleNull() {
        assertNull(ObjectUtils.cloneIfPossible((Object) null));
    }

    @Test
    void testCloneIfPossibleNotCloneable() {
        final NotCloneableFixture fixture = new NotCloneableFixture();
        assertSame(fixture, ObjectUtils.cloneIfPossible(fixture));
    }

    @Test
    void testCloneIfPossibleCloneable() {
        final CloneableFixture original = new CloneableFixture(7);
        final CloneableFixture cloned = ObjectUtils.cloneIfPossible(original);
        assertNotSame(original, cloned);
        assertEquals(7, cloned.value);
    }

    @Test
    void testCompareTwoArg() {
        assertEquals(0, ObjectUtils.compare(null, null));
        assertEquals(-1, ObjectUtils.compare(null, "a"));
        assertEquals(1, ObjectUtils.compare("a", null));
        assertEquals(0, ObjectUtils.compare("a", "a"));
        assertTrue(ObjectUtils.compare("a", "b") < 0);
        assertTrue(ObjectUtils.compare("b", "a") > 0);
    }

    @Test
    void testCompareNullGreater() {
        assertEquals(0, ObjectUtils.compare(null, null, true));
        assertEquals(1, ObjectUtils.compare(null, "a", true));
        assertEquals(-1, ObjectUtils.compare("a", null, true));
        assertEquals(-1, ObjectUtils.compare(null, "a", false));
        assertEquals(1, ObjectUtils.compare("a", null, false));
    }

    @Test
    void testConstOverloads() {
        assertTrue(ObjectUtils.CONST(true));
        assertFalse(ObjectUtils.CONST(false));
        assertEquals((byte) 127, ObjectUtils.CONST((byte) 127));
        assertEquals('x', ObjectUtils.CONST('x'));
        assertEquals(1.5d, ObjectUtils.CONST(1.5d), 0d);
        assertEquals(1.5f, ObjectUtils.CONST(1.5f), 0f);
        assertEquals(123, ObjectUtils.CONST(123));
        assertEquals(123L, ObjectUtils.CONST(123L));
        assertEquals((short) 123, ObjectUtils.CONST((short) 123));
        assertEquals("abc", ObjectUtils.CONST("abc"));
        assertNull(ObjectUtils.CONST((String) null));
    }

    @Test
    void testConstByte() {
        assertEquals((byte) 127, ObjectUtils.CONST_BYTE(127));
        assertEquals((byte) -128, ObjectUtils.CONST_BYTE(-128));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(128);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(-129);
            }
        });
    }

    @Test
    void testConstShort() {
        assertEquals((short) 32767, ObjectUtils.CONST_SHORT(32767));
        assertEquals((short) -32768, ObjectUtils.CONST_SHORT(-32768));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(32768);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(-32769);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDefaultIfNull() {
        assertNull(ObjectUtils.defaultIfNull(null, null));
        assertEquals("", ObjectUtils.defaultIfNull(null, ""));
        assertEquals("zz", ObjectUtils.defaultIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.defaultIfNull("abc", "zz"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testEqualsDeprecated() {
        assertTrue(ObjectUtils.equals(null, null));
        assertFalse(ObjectUtils.equals(null, ""));
        assertFalse(ObjectUtils.equals("", null));
        assertTrue(ObjectUtils.equals("", ""));
        assertTrue(ObjectUtils.equals(Boolean.TRUE, Boolean.TRUE));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, Boolean.FALSE));
    }

    @Test
    void testFirstNonNull() {
        assertNull(ObjectUtils.firstNonNull());
        assertNull(ObjectUtils.firstNonNull(null, null));
        assertEquals("", ObjectUtils.firstNonNull(null, ""));
        assertEquals("zz", ObjectUtils.firstNonNull(null, "zz"));
        assertEquals("abc", ObjectUtils.firstNonNull("abc", "xyz"));
    }

    @Test
    void testGetClass() {
        assertNull(ObjectUtils.getClass(null));
        assertEquals(String.class, ObjectUtils.getClass("abc"));
        assertEquals(Integer.class, ObjectUtils.getClass(Integer.valueOf(1)));
    }

    @Test
    void testGetFirstNonNullSuppliers() {
        assertNull(ObjectUtils.getFirstNonNull());
        assertNull(ObjectUtils.getFirstNonNull(nullSupplier(), nullSupplier()));
        assertEquals("", ObjectUtils.getFirstNonNull(nullSupplier(), constSupplier("")));
        assertEquals("zz", ObjectUtils.getFirstNonNull(nullSupplier(), constSupplier("zz")));
        // once a non-null is found, later suppliers must not be invoked
        final boolean[] invoked = {false};
        final Supplier<String> shouldNotRun = new Supplier<String>() {
            @Override
            public String get() {
                invoked[0] = true;
                throw new IllegalStateException("should not be called");
            }
        };
        assertEquals("first", ObjectUtils.getFirstNonNull(constSupplier("first"), shouldNotRun));
        assertFalse(invoked[0]);
    }

    private static Supplier<String> nullSupplier() {
        return new Supplier<String>() {
            @Override
            public String get() {
                return null;
            }
        };
    }

    private static Supplier<String> constSupplier(final String value) {
        return new Supplier<String>() {
            @Override
            public String get() {
                return value;
            }
        };
    }

    @Test
    void testGetIfNullSupplier() {
        assertNull(ObjectUtils.getIfNull(null, (Supplier<String>) null));
        assertNull(ObjectUtils.getIfNull((String) null, nullSupplier()));
        assertEquals("", ObjectUtils.getIfNull((String) null, constSupplier("")));
        assertEquals("zz", ObjectUtils.getIfNull((String) null, constSupplier("zz")));
        assertEquals("abc", ObjectUtils.getIfNull("abc", constSupplier("zz")));
    }

    @Test
    void testGetIfNullValue() {
        assertNull(ObjectUtils.getIfNull(null, (String) null));
        assertEquals("", ObjectUtils.getIfNull(null, ""));
        assertEquals("zz", ObjectUtils.getIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.getIfNull("abc", "zz"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testHashCodeDeprecated() {
        assertEquals(0, ObjectUtils.hashCode(null));
        assertEquals("abc".hashCode(), ObjectUtils.hashCode("abc"));
    }

    @Test
    void testHashCodeHex() {
        assertEquals(Integer.toHexString(0), ObjectUtils.hashCodeHex(null));
        final Object obj = new Object();
        assertEquals(Integer.toHexString(obj.hashCode()), ObjectUtils.hashCodeHex(obj));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testHashCodeMultiDeprecated() {
        assertEquals(1, ObjectUtils.hashCodeMulti());
        assertEquals(1, ObjectUtils.hashCodeMulti((Object[]) null));
        final Object a = "a";
        final Object b = "b";
        assertEquals(31 + a.hashCode(), ObjectUtils.hashCodeMulti(a));
        assertEquals((31 + a.hashCode()) * 31 + b.hashCode(), ObjectUtils.hashCodeMulti(a, b));
    }

    @Test
    void testIdentityHashCodeHex() {
        final Object obj = new Object();
        assertEquals(Integer.toHexString(System.identityHashCode(obj)), ObjectUtils.identityHashCodeHex(obj));
        assertEquals(Integer.toHexString(System.identityHashCode(null)), ObjectUtils.identityHashCodeHex(null));
    }

    @Test
    void testIdentityToStringAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final String value = "abc";
        ObjectUtils.identityToString(sb, value);
        assertEquals(value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), sb.toString());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IOException {
                ObjectUtils.identityToString((Appendable) new StringBuilder(), null);
            }
        });
    }

    @Test
    void testIdentityToStringObject() {
        assertNull(ObjectUtils.identityToString(null));
        final String value = "abc";
        final String result = ObjectUtils.identityToString(value);
        assertEquals(value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), result);
    }

    @Test
    void testIdentityToStringStringBuffer() {
        final StringBuffer buffer = new StringBuffer();
        final String value = "abc";
        ObjectUtils.identityToString(buffer, value);
        assertEquals(value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), buffer.toString());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(new StringBuffer(), null);
            }
        });
    }

    @Test
    void testIdentityToStringStringBuilder() {
        final StringBuilder builder = new StringBuilder();
        final String value = "abc";
        ObjectUtils.identityToString(builder, value);
        assertEquals(value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), builder.toString());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(new StringBuilder(), null);
            }
        });
    }

    @Test
    void testIsArray() {
        assertFalse(ObjectUtils.isArray(null));
        assertFalse(ObjectUtils.isArray(""));
        assertFalse(ObjectUtils.isArray("ab"));
        assertTrue(ObjectUtils.isArray(new int[]{}));
        assertTrue(ObjectUtils.isArray(new int[]{1, 2, 3}));
        assertTrue(ObjectUtils.isArray(new String[]{"a"}));
        assertFalse(ObjectUtils.isArray(1234));
    }

    @Test
    void testIsEmpty() {
        assertTrue(ObjectUtils.isEmpty(null));
        assertTrue(ObjectUtils.isEmpty(""));
        assertFalse(ObjectUtils.isEmpty("ab"));
        assertTrue(ObjectUtils.isEmpty(new int[]{}));
        assertFalse(ObjectUtils.isEmpty(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isEmpty(1234));
        assertFalse(ObjectUtils.isEmpty(Optional.of("")));
        assertTrue(ObjectUtils.isEmpty(Optional.empty()));
        assertTrue(ObjectUtils.isEmpty(new ArrayList<String>()));
        final List<String> list = new ArrayList<String>();
        list.add("x");
        assertFalse(ObjectUtils.isEmpty(list));
        assertTrue(ObjectUtils.isEmpty(new HashMap<String, String>()));
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertFalse(ObjectUtils.isEmpty(map));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ObjectUtils.isNotEmpty(null));
        assertFalse(ObjectUtils.isNotEmpty(""));
        assertTrue(ObjectUtils.isNotEmpty("ab"));
        assertFalse(ObjectUtils.isNotEmpty(new int[]{}));
        assertTrue(ObjectUtils.isNotEmpty(new int[]{1, 2, 3}));
        assertTrue(ObjectUtils.isNotEmpty(1234));
        assertTrue(ObjectUtils.isNotEmpty(Optional.of("")));
        assertFalse(ObjectUtils.isNotEmpty(Optional.empty()));
    }

    @Test
    void testMax() {
        assertNull(ObjectUtils.max((String[]) null));
        assertNull(ObjectUtils.max((String) null, (String) null));
        assertEquals("b", ObjectUtils.max("a", "b"));
        assertEquals("b", ObjectUtils.max("b", "a"));
        assertEquals("b", ObjectUtils.max(null, "b"));
        assertEquals("b", ObjectUtils.max("b", null));
        assertEquals(Integer.valueOf(10), ObjectUtils.max(Integer.valueOf(1), Integer.valueOf(10), Integer.valueOf(5)));
    }

    @Test
    void testMin() {
        assertNull(ObjectUtils.min((String[]) null));
        assertNull(ObjectUtils.min((String) null, (String) null));
        assertEquals("a", ObjectUtils.min("a", "b"));
        assertEquals("a", ObjectUtils.min("b", "a"));
        assertEquals("b", ObjectUtils.min(null, "b"));
        assertEquals("b", ObjectUtils.min("b", null));
        assertEquals(Integer.valueOf(1), ObjectUtils.min(Integer.valueOf(1), Integer.valueOf(10), Integer.valueOf(5)));
    }

    @Test
    void testMedianVarargs() {
        assertEquals("b", ObjectUtils.median("c", "a", "b"));
        assertEquals(Integer.valueOf(2), ObjectUtils.median(Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3)));
        // even number of items -> lower of the two middle values
        assertEquals(Integer.valueOf(2), ObjectUtils.median(Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4)));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((String[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median(new String[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median("a", null, "b");
            }
        });
    }

    @Test
    void testMedianComparator() {
        final Comparator<String> byLength = new Comparator<String>() {
            @Override
            public int compare(final String a, final String b) {
                return Integer.compare(a.length(), b.length());
            }
        };
        assertEquals("bb", ObjectUtils.median(byLength, "a", "bb", "ccc"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((Comparator<String>) null, "a", "b");
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median(byLength, new String[0]);
            }
        });
    }

    @Test
    void testMode() {
        assertNull(ObjectUtils.mode());
        assertNull(ObjectUtils.mode((Object[]) null));
        assertNull(ObjectUtils.mode("a", "b"));
        assertEquals("a", ObjectUtils.mode("a", "b", "a"));
        assertEquals(Integer.valueOf(3), ObjectUtils.mode(Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(2)));
    }

    @Test
    void testNotEqual() {
        assertFalse(ObjectUtils.notEqual(null, null));
        assertTrue(ObjectUtils.notEqual(null, ""));
        assertTrue(ObjectUtils.notEqual("", null));
        assertFalse(ObjectUtils.notEqual("", ""));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, Boolean.FALSE));
        assertFalse(ObjectUtils.notEqual(Boolean.TRUE, Boolean.TRUE));
    }

    @Test
    void testRequireNonEmptyNoMessage() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty(null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("");
            }
        });
    }

    @Test
    void testRequireNonEmptyWithMessage() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc", "myMessage"));
        final NullPointerException npe = assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null, "myMessage");
            }
        });
        assertEquals("myMessage", npe.getMessage());
        final IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("", "myMessage");
            }
        });
        assertEquals("myMessage", iae.getMessage());
    }

    @Test
    void testToStringObject() {
        assertEquals("", ObjectUtils.toString(null));
        assertEquals("", ObjectUtils.toString(""));
        assertEquals("bat", ObjectUtils.toString("bat"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testToStringObjectNullStr() {
        assertNull(ObjectUtils.toString((Object) null, (String) null));
        assertEquals("null", ObjectUtils.toString(null, "null"));
        assertEquals("", ObjectUtils.toString("", "null"));
        assertEquals("bat", ObjectUtils.toString("bat", "null"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE, "null"));
    }

    @Test
    void testToStringSupplierObjSupplierStr() {
        assertEquals("expensive", ObjectUtils.toString((Supplier<Object>) null, constSupplier("expensive")));
        assertEquals("expensive", ObjectUtils.toString(nullObjectSupplier(), constSupplier("expensive")));
        assertEquals("", ObjectUtils.toString(constObjectSupplier(""), constSupplier("expensive")));
        assertEquals("bat", ObjectUtils.toString(constObjectSupplier("bat"), constSupplier("expensive")));
    }

    private static Supplier<Object> nullObjectSupplier() {
        return new Supplier<Object>() {
            @Override
            public Object get() {
                return null;
            }
        };
    }

    private static Supplier<Object> constObjectSupplier(final Object value) {
        return new Supplier<Object>() {
            @Override
            public Object get() {
                return value;
            }
        };
    }

    @Test
    void testToStringObjSupplierStr() {
        assertEquals("expensive", ObjectUtils.toString((String) null, constSupplier("expensive")));
        assertEquals("", ObjectUtils.toString("", constSupplier("expensive")));
        assertEquals("bat", ObjectUtils.toString("bat", constSupplier("expensive")));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE, constSupplier("expensive")));
    }

    @Test
    void testWaitNegativeDurationThrows() throws InterruptedException {
        final Object monitor = new Object();
        synchronized (monitor) {
            assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws InterruptedException {
                    ObjectUtils.wait(monitor, Duration.ofMillis(-1));
                }
            });
        }
    }

    @Test
    void testWaitWithoutMonitorThrowsIllegalMonitorState() {
        final Object monitor = new Object();
        assertThrows(IllegalMonitorStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws InterruptedException {
                ObjectUtils.wait(monitor, Duration.ofMillis(10));
            }
        });
    }

    @Test
    void testWaitTimesOutNormally() throws InterruptedException {
        final Object monitor = new Object();
        final long start = System.nanoTime();
        synchronized (monitor) {
            ObjectUtils.wait(monitor, Duration.ofMillis(20));
        }
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 0);
    }

    @Test
    void testWaitNullDurationTreatedAsZero() throws InterruptedException {
        final Object monitor = new Object();
        synchronized (monitor) {
            // null Duration is treated as Duration.ZERO, i.e. wait indefinitely until notified;
            // notify from another thread so the test does not hang.
            final Thread notifier = new Thread(new Runnable() {
                @Override
                public void run() {
                    synchronized (monitor) {
                        monitor.notifyAll();
                    }
                }
            });
            // Can't synchronize+wait+start notifier in the same synchronized block without deadlock risk,
            // so start the notifier before waiting; it will block on the monitor until we wait() releases it.
            notifier.start();
            ObjectUtils.wait(monitor, null);
            notifier.join();
        }
    }

    @Test
    void testNullSingleton() {
        assertNotNull(ObjectUtils.NULL);
        assertSame(ObjectUtils.NULL, ObjectUtils.NULL);
    }

    @Test
    void testNullSerializationReadResolve() throws IOException, ClassNotFoundException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(ObjectUtils.NULL);
        oos.close();
        final java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(baos.toByteArray()));
        final Object result = ois.readObject();
        ois.close();
        assertSame(ObjectUtils.NULL, result);
    }

    @Test
    @SuppressWarnings("deprecation")
    void testConstructorIsPublicAndUsable() {
        final ObjectUtils instance = new ObjectUtils();
        assertNotNull(instance);
    }

    @Test
    void testCompareConsistentWithArraysSort() {
        final String[] values = {"banana", null, "apple", null, "cherry"};
        Arrays.sort(values, new Comparator<String>() {
            @Override
            public int compare(final String a, final String b) {
                return ObjectUtils.compare(a, b);
            }
        });
        assertNull(values[0]);
        assertNull(values[1]);
        assertEquals("apple", values[2]);
        assertEquals("banana", values[3]);
        assertEquals("cherry", values[4]);
    }
}
