/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExceptionUtils}.
 */
class ExceptionUtilsAgentTest {

    /**
     * A legacy style exception exposing a non-standard "cause" accessor, used to exercise the
     * reflective {@code getCause} lookup.
     */
    private static final class LegacyException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable nested;

        LegacyException(final String message, final Throwable nested) {
            super(message);
            this.nested = nested;
        }

        public Throwable getNested() {
            return nested;
        }
    }

    private static Throwable buildCycle() {
        final Throwable a = new Throwable("a");
        final Throwable b = new Throwable("b", a);
        a.initCause(b);
        return a;
    }

    // -------------------- asRuntimeException / rethrow / wrapAndThrow / throwUnchecked --------------------

    @Test
    void testAsRuntimeExceptionRethrowsCheckedExceptionUnwrapped() {
        final IOException checked = new IOException("boom");
        final IOException thrown = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.<RuntimeException>asRuntimeException(checked);
            }
        });
        assertSame(checked, thrown);
    }

    @Test
    void testRethrowChecked() {
        final IOException checked = new IOException("boom");
        final IOException thrown = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.<Void>rethrow(checked);
            }
        });
        assertSame(checked, thrown);
    }

    @Test
    void testWrapAndThrowChecked() {
        final IOException checked = new IOException("boom");
        final UndeclaredThrowableException thrown = assertThrows(UndeclaredThrowableException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.<Object>wrapAndThrow(checked);
            }
        });
        assertSame(checked, thrown.getCause());
    }

    @Test
    void testWrapAndThrowRuntimeExceptionIsRethrownDirectly() {
        final RuntimeException runtime = new IllegalStateException("boom");
        final RuntimeException thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.<Object>wrapAndThrow(runtime);
            }
        });
        assertSame(runtime, thrown);
    }

    @Test
    void testThrowUncheckedReturnsCheckedExceptionUnchanged() {
        final IOException checked = new IOException("boom");
        final Throwable result = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, result);
    }

    @Test
    void testThrowUncheckedThrowsRuntimeException() {
        final RuntimeException runtime = new IllegalStateException("boom");
        final RuntimeException thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.throwUnchecked(runtime);
            }
        });
        assertSame(runtime, thrown);
    }

    @Test
    void testThrowUncheckedThrowsError() {
        final Error error = new OutOfMemoryError("boom");
        final Error thrown = assertThrows(Error.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.throwUnchecked(error);
            }
        });
        assertSame(error, thrown);
    }

    // -------------------- isChecked / isUnchecked --------------------

    @Test
    void testIsCheckedAndIsUnchecked() {
        assertFalse(ExceptionUtils.isChecked(null));
        assertFalse(ExceptionUtils.isUnchecked(null));

        final IOException checked = new IOException("x");
        assertTrue(ExceptionUtils.isChecked(checked));
        assertFalse(ExceptionUtils.isUnchecked(checked));

        final RuntimeException runtime = new RuntimeException("x");
        assertFalse(ExceptionUtils.isChecked(runtime));
        assertTrue(ExceptionUtils.isUnchecked(runtime));

        final Error error = new StackOverflowError("x");
        assertFalse(ExceptionUtils.isChecked(error));
        assertTrue(ExceptionUtils.isUnchecked(error));
    }

    // -------------------- getMessage / getRootCauseMessage --------------------

    @Test
    void testGetMessageNull() {
        assertEquals("", ExceptionUtils.getMessage(null));
    }

    @Test
    void testGetMessageWithMessage() {
        final Exception e = new IllegalArgumentException("bad value");
        assertEquals("IllegalArgumentException: bad value", ExceptionUtils.getMessage(e));
    }

    @Test
    void testGetMessageWithoutMessage() {
        final Exception e = new IllegalArgumentException();
        assertEquals("IllegalArgumentException: ", ExceptionUtils.getMessage(e));
    }

    @Test
    void testGetRootCauseMessageNoCause() {
        final Exception e = new IllegalArgumentException("top");
        assertEquals("IllegalArgumentException: top", ExceptionUtils.getRootCauseMessage(e));
    }

    @Test
    void testGetRootCauseMessageWithCause() {
        final Exception root = new IOException("root cause");
        final Exception wrapper = new RuntimeException("wrapper", root);
        assertEquals("IOException: root cause", ExceptionUtils.getRootCauseMessage(wrapper));
    }

    @Test
    void testGetRootCauseMessageNull() {
        assertEquals("", ExceptionUtils.getRootCauseMessage(null));
    }

    // -------------------- getRootCause / getThrowableList / getThrowables / getThrowableCount --------------------

    @Test
    void testGetRootCauseNull() {
        assertNull(ExceptionUtils.getRootCause(null));
    }

    @Test
    void testGetRootCauseNoCause() {
        final Exception e = new Exception("solo");
        assertSame(e, ExceptionUtils.getRootCause(e));
    }

    @Test
    void testGetRootCauseWithChain() {
        final Exception root = new IOException("root");
        final Exception middle = new RuntimeException("middle", root);
        final Exception top = new RuntimeException("top", middle);
        assertSame(root, ExceptionUtils.getRootCause(top));
    }

    @Test
    void testGetThrowableListNull() {
        final List<Throwable> list = ExceptionUtils.getThrowableList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testGetThrowableListChain() {
        final Exception root = new IOException("root");
        final Exception top = new RuntimeException("top", root);
        final List<Throwable> list = ExceptionUtils.getThrowableList(top);
        assertEquals(2, list.size());
        assertSame(top, list.get(0));
        assertSame(root, list.get(1));
    }

    @Test
    void testGetThrowableListHandlesCycle() {
        final Throwable a = buildCycle();
        final List<Throwable> list = ExceptionUtils.getThrowableList(a);
        assertEquals(2, list.size());
        assertEquals(2, ExceptionUtils.getThrowableCount(a));
    }

    @Test
    void testGetThrowableCountNull() {
        assertEquals(0, ExceptionUtils.getThrowableCount(null));
    }

    @Test
    void testGetThrowablesNull() {
        final Throwable[] throwables = ExceptionUtils.getThrowables(null);
        assertNotNull(throwables);
        assertEquals(0, throwables.length);
    }

    @Test
    void testGetThrowablesChain() {
        final Exception root = new IOException("root");
        final Exception top = new RuntimeException("top", root);
        final Throwable[] throwables = ExceptionUtils.getThrowables(top);
        assertEquals(2, throwables.length);
        assertSame(top, throwables[0]);
        assertSame(root, throwables[1]);
    }

    // -------------------- forEach / stream --------------------

    @Test
    void testStreamNull() {
        assertEquals(0L, ExceptionUtils.stream(null).count());
    }

    @Test
    void testStreamChain() {
        final Exception root = new IOException("root");
        final Exception top = new RuntimeException("top", root);
        final List<Throwable> collected = ExceptionUtils.stream(top).collect(java.util.stream.Collectors.<Throwable>toList());
        assertEquals(2, collected.size());
        assertSame(top, collected.get(0));
        assertSame(root, collected.get(1));
    }

    @Test
    void testForEachVisitsEveryThrowableInChain() {
        final Exception root = new IOException("root");
        final Exception top = new RuntimeException("top", root);
        final List<Throwable> visited = new ArrayList<Throwable>();
        ExceptionUtils.forEach(top, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                visited.add(t);
            }
        });
        assertEquals(2, visited.size());
        assertSame(top, visited.get(0));
        assertSame(root, visited.get(1));
    }

    @Test
    void testForEachNullThrowableVisitsNothing() {
        final List<Throwable> visited = new ArrayList<Throwable>();
        ExceptionUtils.forEach(null, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                visited.add(t);
            }
        });
        assertTrue(visited.isEmpty());
    }

    // -------------------- hasCause --------------------

    @Test
    void testHasCauseDirectInstance() {
        final IOException io = new IOException("x");
        assertTrue(ExceptionUtils.hasCause(io, IOException.class));
        assertFalse(ExceptionUtils.hasCause(io, IllegalStateException.class));
    }

    @Test
    void testHasCauseUndeclaredThrowableException() {
        final IOException io = new IOException("x");
        final UndeclaredThrowableException wrapped = new UndeclaredThrowableException(io);
        assertTrue(ExceptionUtils.hasCause(wrapped, IOException.class));
        assertFalse(ExceptionUtils.hasCause(wrapped, IllegalStateException.class));
    }

    @Test
    void testHasCauseNullChain() {
        assertFalse(ExceptionUtils.hasCause(null, IOException.class));
    }

    // -------------------- indexOfThrowable / indexOfType --------------------

    @Test
    void testIndexOfThrowableNullInputs() {
        assertEquals(-1, ExceptionUtils.indexOfThrowable(null, IOException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(new IOException("x"), null));
    }

    @Test
    void testIndexOfThrowableExactClassOnly() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertEquals(1, ExceptionUtils.indexOfThrowable(top, IOException.class));
        // FileNotFoundException is a subclass of IOException; indexOfThrowable requires an exact match.
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, java.io.FileNotFoundException.class));
    }

    @Test
    void testIndexOfTypeMatchesSubclasses() {
        final java.io.FileNotFoundException root = new java.io.FileNotFoundException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertEquals(1, ExceptionUtils.indexOfType(top, IOException.class));
    }

    @Test
    void testIndexOfThrowableFromIndexNegativeTreatedAsZero() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertEquals(1, ExceptionUtils.indexOfThrowable(top, IOException.class, -5));
    }

    @Test
    void testIndexOfThrowableFromIndexBeyondChainReturnsNotFound() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, IOException.class, 10));
    }

    @Test
    void testIndexOfTypeFromIndexSkipsEarlierMatch() {
        final IOException root = new IOException("root");
        final IOException top = new IOException("top", root);
        assertEquals(0, ExceptionUtils.indexOfType(top, IOException.class));
        assertEquals(1, ExceptionUtils.indexOfType(top, IOException.class, 1));
    }

    // -------------------- throwableOfThrowable / throwableOfType --------------------

    @Test
    void testThrowableOfThrowableNullInputs() {
        assertNull(ExceptionUtils.throwableOfThrowable(null, IOException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(new IOException("x"), null));
    }

    @Test
    void testThrowableOfThrowableExactMatch() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertSame(root, ExceptionUtils.throwableOfThrowable(top, IOException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(top, java.io.FileNotFoundException.class));
    }

    @Test
    void testThrowableOfTypeMatchesSubclass() {
        final java.io.FileNotFoundException root = new java.io.FileNotFoundException("root");
        final RuntimeException top = new RuntimeException("top", root);
        final IOException found = ExceptionUtils.throwableOfType(top, IOException.class);
        assertSame(root, found);
    }

    @Test
    void testThrowableOfTypeFromIndexBeyondChainReturnsNull() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertNull(ExceptionUtils.throwableOfType(top, IOException.class, 10));
    }

    @Test
    void testThrowableOfThrowableFromIndexNegativeTreatedAsZero() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertSame(root, ExceptionUtils.throwableOfThrowable(top, IOException.class, -3));
    }

    // -------------------- getCause / getDefaultCauseMethodNames (deprecated reflective API) --------------------

    @Test
    void testGetCauseNull() {
        assertNull(ExceptionUtils.getCause(null));
    }

    @Test
    void testGetCauseUsesThrowableGetCauseFirst() {
        final IOException root = new IOException("root");
        final RuntimeException top = new RuntimeException("top", root);
        assertSame(root, ExceptionUtils.getCause(top));
    }

    @Test
    void testGetCauseFallsBackToReflectiveMethodNames() {
        final IOException nested = new IOException("nested");
        final LegacyException legacy = new LegacyException("legacy", nested);
        assertNull(legacy.getCause());
        assertSame(nested, ExceptionUtils.getCause(legacy));
    }

    @Test
    void testGetCauseWithExplicitMethodNamesAndNullEntries() {
        final IOException nested = new IOException("nested");
        final LegacyException legacy = new LegacyException("legacy", nested);
        final String[] names = {null, "getNested"};
        assertSame(nested, ExceptionUtils.getCause(legacy, names));
    }

    @Test
    void testGetCauseWithExplicitMethodNamesNoMatchReturnsNull() {
        final LegacyException legacy = new LegacyException("legacy", new IOException("nested"));
        final String[] names = {"noSuchMethod"};
        assertNull(ExceptionUtils.getCause(legacy, names));
    }

    @Test
    void testGetDefaultCauseMethodNamesReturnsIndependentClone() {
        final String[] first = ExceptionUtils.getDefaultCauseMethodNames();
        assertTrue(first.length > 0);
        first[0] = "mutated";
        final String[] second = ExceptionUtils.getDefaultCauseMethodNames();
        assertFalse("mutated".equals(second[0]));
    }

    // -------------------- getStackTrace / getStackFrames / getRootCauseStackTrace(List) --------------------

    @Test
    void testGetStackTraceNull() {
        assertEquals("", ExceptionUtils.getStackTrace(null));
    }

    @Test
    void testGetStackTraceContainsExceptionToString() {
        final Exception e = new IllegalStateException("bad state");
        final String trace = ExceptionUtils.getStackTrace(e);
        assertTrue(trace.startsWith(e.toString()));
    }

    @Test
    void testGetStackFramesThrowableNull() {
        final String[] frames = ExceptionUtils.getStackFrames((Throwable) null);
        assertNotNull(frames);
        assertEquals(0, frames.length);
    }

    @Test
    void testGetStackFramesThrowableNonEmpty() {
        final Exception e = new IllegalStateException("bad state");
        final String[] frames = ExceptionUtils.getStackFrames(e);
        assertTrue(frames.length > 0);
    }

    @Test
    void testGetStackFramesStringSplitsOnLines() {
        final String text = "line1" + System.lineSeparator() + "line2" + System.lineSeparator() + "line3";
        final String[] frames = ExceptionUtils.getStackFrames(text);
        assertArrayEquals(new String[] {"line1", "line2", "line3"}, frames);
    }

    @Test
    void testGetRootCauseStackTraceNull() {
        final String[] frames = ExceptionUtils.getRootCauseStackTrace(null);
        assertNotNull(frames);
        assertEquals(0, frames.length);
    }

    @Test
    void testGetRootCauseStackTraceListNull() {
        final List<String> frames = ExceptionUtils.getRootCauseStackTraceList(null);
        assertNotNull(frames);
        assertTrue(frames.isEmpty());
    }

    @Test
    void testGetRootCauseStackTraceListOrderAndWrappedMarker() {
        final Exception root = new IOException("root cause");
        final Exception wrapper = new RuntimeException("wrapper", root);
        final List<String> frames = ExceptionUtils.getRootCauseStackTraceList(wrapper);
        assertFalse(frames.isEmpty());
        assertEquals(root.toString(), frames.get(0));
        boolean foundWrapperMarker = false;
        for (int i = 0; i < frames.size(); i++) {
            if (frames.get(i).equals(ExceptionUtils.WRAPPED_MARKER + wrapper.toString())) {
                foundWrapperMarker = true;
                break;
            }
        }
        assertTrue(foundWrapperMarker);
    }

    @Test
    void testGetRootCauseStackTraceNoCauseEqualsSingleEntry() {
        final Exception solo = new IllegalStateException("solo");
        final String[] frames = ExceptionUtils.getRootCauseStackTrace(solo);
        assertTrue(frames.length > 0);
        assertEquals(solo.toString(), frames[0]);
    }

    // -------------------- printRootCauseStackTrace --------------------

    @Test
    void testPrintRootCauseStackTraceNullThrowableDoesNothing() {
        // Must not throw even though System.err is the implicit target.
        ExceptionUtils.printRootCauseStackTrace(null);
    }

    @Test
    void testPrintRootCauseStackTraceNullThrowableWithStreamWritesNothing() throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(out, true, "UTF-8");
        ExceptionUtils.printRootCauseStackTrace(null, ps);
        ps.flush();
        assertEquals(0, out.size());
    }

    @Test
    void testPrintRootCauseStackTraceWritesToStream() throws IOException {
        final Exception e = new IllegalStateException("bad state");
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(out, true, "UTF-8");
        ExceptionUtils.printRootCauseStackTrace(e, ps);
        ps.flush();
        final String written = out.toString("UTF-8");
        assertTrue(written.contains(e.toString()));
    }

    @Test
    void testPrintRootCauseStackTraceNullStreamThrowsNpe() {
        final Exception e = new IllegalStateException("bad state");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(e, (PrintStream) null);
            }
        });
    }

    @Test
    void testPrintRootCauseStackTraceWritesToWriter() {
        final Exception e = new IllegalStateException("bad state");
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        ExceptionUtils.printRootCauseStackTrace(e, pw);
        pw.flush();
        assertTrue(sw.toString().contains(e.toString()));
    }

    @Test
    void testPrintRootCauseStackTraceNullWriterThrowsNpe() {
        final Exception e = new IllegalStateException("bad state");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(e, (PrintWriter) null);
            }
        });
    }

    @Test
    void testPrintRootCauseStackTraceNullThrowableWithWriterWritesNothing() {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        ExceptionUtils.printRootCauseStackTrace(null, pw);
        pw.flush();
        assertEquals("", sw.toString());
    }

    // -------------------- removeCommonFrames --------------------

    @Test
    void testRemoveCommonFramesNullCauseFramesThrowsNpe() {
        final List<String> wrapperFrames = new ArrayList<String>();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(null, wrapperFrames);
            }
        });
    }

    @Test
    void testRemoveCommonFramesNullWrapperFramesThrowsNpe() {
        final List<String> causeFrames = new ArrayList<String>();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(causeFrames, null);
            }
        });
    }

    @Test
    void testRemoveCommonFramesStripsTrailingCommonLines() {
        final List<String> causeFrames = new ArrayList<String>();
        causeFrames.add("line1");
        causeFrames.add("common1");
        causeFrames.add("common2");

        final List<String> wrapperFrames = new ArrayList<String>();
        wrapperFrames.add("lineA");
        wrapperFrames.add("common1");
        wrapperFrames.add("common2");

        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);

        assertEquals(1, causeFrames.size());
        assertEquals("line1", causeFrames.get(0));
        // The wrapper frames passed in are only read, never mutated.
        assertEquals(3, wrapperFrames.size());
    }

    @Test
    void testRemoveCommonFramesNoCommonSuffixLeavesCauseFramesUntouched() {
        final List<String> causeFrames = new ArrayList<String>();
        causeFrames.add("onlyInCause");

        final List<String> wrapperFrames = new ArrayList<String>();
        wrapperFrames.add("onlyInWrapper");

        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);

        assertEquals(1, causeFrames.size());
        assertEquals("onlyInCause", causeFrames.get(0));
    }
}
