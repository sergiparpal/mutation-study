package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // Fields
    // ---------------------------------------------------------------

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    // ---------------------------------------------------------------
    // compare (deprecated numeric comparisons)
    // ---------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertEquals(new BigDecimal("0"), NumberUtils.createBigDecimal("0"));
    }

    @Test
    public void testCreateBigDecimalInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("abc");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigInteger("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createDouble
    // ---------------------------------------------------------------

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createFloat
    // ---------------------------------------------------------------

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberNegativeInteger() {
        Number n = NumberUtils.createNumber("-123");
        assertTrue(n instanceof Integer);
        assertEquals(-123, n.intValue());
    }

    @Test
    public void testCreateNumberLongSuffix() {
        Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        Number n = NumberUtils.createNumber("1.5F");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        Number n = NumberUtils.createNumber("1.5D");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberHex() {
        Number n = NumberUtils.createNumber("0x1A");
        assertTrue(n instanceof Integer);
        assertEquals(26, n.intValue());
    }

    @Test
    public void testCreateNumberHexHash() {
        Number n = NumberUtils.createNumber("#1A");
        assertTrue(n instanceof Integer);
        assertEquals(26, n.intValue());
    }

    @Test
    public void testCreateNumberHexBeyondIntRange() {
        // 9 hex digits after the prefix: too large for an int, must become a Long.
        Number n = NumberUtils.createNumber("0x100000000");
        assertTrue(n instanceof Long);
        assertEquals(4294967296L, n.longValue());
    }

    @Test
    public void testCreateNumberOctal() {
        Number n = NumberUtils.createNumber("010");
        assertTrue(n instanceof Integer);
        assertEquals(8, n.intValue());
    }

    @Test
    public void testCreateNumberBigIntegerFallback() {
        String huge = "123456789012345678901234567890";
        Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    public void testCreateNumberDecimalValue() {
        Number n = NumberUtils.createNumber("1.5");
        assertEquals(1.5d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("--1");
            }
        });
    }

    @Test
    public void testCreateNumberDoesNotTrim() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber(" 1");
            }
        });
    }

    // ---------------------------------------------------------------
    // isCreatable
    // ---------------------------------------------------------------

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("123L"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("1.2e-5"));
        assertTrue(NumberUtils.isCreatable("0.1"));
        // Leading zero, non-hexadecimal: treated as octal; '9' is not a valid octal digit.
        assertFalse(NumberUtils.isCreatable("09"));
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits("12a45"));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    // ---------------------------------------------------------------
    // isNumber (deprecated, same contract as isCreatable)
    // ---------------------------------------------------------------

    @Test
    public void testIsNumber() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("123"));
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertFalse(NumberUtils.isNumber("09"));
    }

    // ---------------------------------------------------------------
    // isParsable
    // ---------------------------------------------------------------

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("+Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
        // Hex is creatable but not parsable by Integer/Long/Float/Double parse methods.
        assertFalse(NumberUtils.isParsable("0x1A"));
        // 'L' is not a recognized suffix for any of the four parse methods.
        assertFalse(NumberUtils.isParsable("123L"));
    }

    // ---------------------------------------------------------------
    // max / min - varargs array forms
    // ---------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 3, (byte) 5, (byte) 1));
        assertEquals((byte) 5, NumberUtils.max(new byte[] {3, 5, 1}));
    }

    @Test
    public void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 5, (byte) 1));
        assertEquals((byte) 1, NumberUtils.min(new byte[] {3, 5, 1}));
    }

    @Test
    public void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    public void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxShort() {
        assertEquals((short) 5, NumberUtils.max((short) 3, (short) 5, (short) 1));
        assertEquals((short) 5, NumberUtils.max(new short[] {3, 5, 1}));
    }

    @Test
    public void testMaxShortArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMinShort() {
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 5, (short) 1));
        assertEquals((short) 1, NumberUtils.min(new short[] {3, 5, 1}));
    }

    @Test
    public void testMinShortArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
    }

    @Test
    public void testMaxInt() {
        assertEquals(5, NumberUtils.max(3, 5, 1));
        assertEquals(5, NumberUtils.max(new int[] {3, 5, 1}));
        assertEquals(-1, NumberUtils.max(new int[] {-5, -1, -3}));
    }

    @Test
    public void testMaxIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
    }

    @Test
    public void testMaxIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMinInt() {
        assertEquals(1, NumberUtils.min(3, 5, 1));
        assertEquals(1, NumberUtils.min(new int[] {3, 5, 1}));
        assertEquals(-5, NumberUtils.min(new int[] {-5, -1, -3}));
    }

    @Test
    public void testMinIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLong() {
        assertEquals(5L, NumberUtils.max(3L, 5L, 1L));
        assertEquals(5L, NumberUtils.max(new long[] {3L, 5L, 1L}));
    }

    @Test
    public void testMaxLongArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
    }

    @Test
    public void testMinLong() {
        assertEquals(1L, NumberUtils.min(3L, 5L, 1L));
        assertEquals(1L, NumberUtils.min(new long[] {3L, 5L, 1L}));
    }

    @Test
    public void testMinLongArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMaxFloat() {
        assertEquals(5.5f, NumberUtils.max(3.3f, 5.5f, 1.1f), 0.0f);
        assertEquals(5.5f, NumberUtils.max(new float[] {3.3f, 5.5f, 1.1f}), 0.0f);
    }

    @Test
    public void testMaxFloatNaNPropagates() {
        float result = NumberUtils.max(1.0f, Float.NaN, 3.0f);
        assertTrue(Float.isNaN(result));
    }

    @Test
    public void testMaxFloatArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
    }

    @Test
    public void testMaxFloatArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMinFloat() {
        assertEquals(1.1f, NumberUtils.min(3.3f, 5.5f, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.min(new float[] {3.3f, 5.5f, 1.1f}), 0.0f);
    }

    @Test
    public void testMinFloatNaNPropagates() {
        float result = NumberUtils.min(1.0f, Float.NaN, 3.0f);
        assertTrue(Float.isNaN(result));
    }

    @Test
    public void testMaxDouble() {
        assertEquals(5.5d, NumberUtils.max(3.3d, 5.5d, 1.1d), 0.0d);
        assertEquals(5.5d, NumberUtils.max(new double[] {3.3d, 5.5d, 1.1d}), 0.0d);
    }

    @Test
    public void testMaxDoubleNaNPropagates() {
        double result = NumberUtils.max(1.0d, Double.NaN, 3.0d);
        assertTrue(Double.isNaN(result));
    }

    @Test
    public void testMaxDoubleArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
    }

    @Test
    public void testMaxDoubleArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMinDouble() {
        assertEquals(1.1d, NumberUtils.min(3.3d, 5.5d, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.min(new double[] {3.3d, 5.5d, 1.1d}), 0.0d);
    }

    @Test
    public void testMinDoubleNaNPropagates() {
        double result = NumberUtils.min(1.0d, Double.NaN, 3.0d);
        assertTrue(Double.isNaN(result));
    }

    @Test
    public void testMinDoubleArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // toByte
    // ---------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("not a number"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    // ---------------------------------------------------------------
    // toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("not a number"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---------------------------------------------------------------
    // toFloat
    // ---------------------------------------------------------------

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("not a number"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // ---------------------------------------------------------------
    // toInt
    // ---------------------------------------------------------------

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("not a number"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    // ---------------------------------------------------------------
    // toLong
    // ---------------------------------------------------------------

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("not a number"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    // ---------------------------------------------------------------
    // toShort
    // ---------------------------------------------------------------

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("not a number"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.345"));
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.34"), result);
    }

    @Test
    public void testToScaledBigDecimalBigDecimalCustomRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.345"), 2, RoundingMode.UP);
        assertEquals(new BigDecimal("2.35"), result);
    }

    @Test
    public void testToScaledBigDecimalBigDecimalCustomRoundingNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
    }

    @Test
    public void testToScaledBigDecimalDoubleDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.0d));
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.00"), result);
    }

    @Test
    public void testToScaledBigDecimalDoubleCustomRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.345d), 2, RoundingMode.UP);
        assertEquals(new BigDecimal("2.35"), result);
    }

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
    }

    @Test
    public void testToScaledBigDecimalFloatDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.0f));
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.00"), result);
    }

    @Test
    public void testToScaledBigDecimalFloatCustomRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.0f), 1, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.0"), result);
    }

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    public void testToScaledBigDecimalStringDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.345");
        assertEquals(2, result.scale());
        assertEquals(new BigDecimal("2.34"), result);
    }

    @Test
    public void testToScaledBigDecimalStringCustomRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.345", 2, RoundingMode.UP);
        assertEquals(new BigDecimal("2.35"), result);
    }

    @Test
    public void testToScaledBigDecimalStringCustomRoundingNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 4, RoundingMode.CEILING));
    }
}
