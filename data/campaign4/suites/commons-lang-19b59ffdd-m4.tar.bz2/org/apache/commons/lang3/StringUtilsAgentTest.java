/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    @Test
    public void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" ab "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("x"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank(" x "));
    }

    @Test
    public void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc  ", StringUtils.stripStart(" abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
    }

    @Test
    public void testEqualsAndCompare() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));

        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare(null, null));
    }

    @Test
    public void testIsNumericIsAlpha() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2"));
        assertFalse(StringUtils.isAlpha("ab c"));

        assertTrue(StringUtils.isAlphanumeric("ab12"));
        assertFalse(StringUtils.isAlphanumeric("ab 12"));
        assertFalse(StringUtils.isAlphanumeric(""));
    }

    @Test
    public void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("de", StringUtils.substring("abcde", -2));
        assertEquals("abcde", StringUtils.substring("abcde", -100));
        assertEquals("", StringUtils.substring("abcde", 100));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("", StringUtils.substring("abc", 4, 6));
        assertEquals("", StringUtils.substring("abc", 2, 2));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    public void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("", StringUtils.left("abc", 0));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    public void testLeftPadRightPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, "x"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
    }

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals(" a  ", StringUtils.center("a", 4));
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    public void testCapitalizeUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("", StringUtils.reverseDelimited("", '.'));
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    public void testRepeat() {
        assertNull(StringUtils.repeat((String) null, 2));
        assertEquals("", StringUtils.repeat("", 0));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));

        assertEquals("", StringUtils.repeat('x', 0));
        assertEquals("xxx", StringUtils.repeat('x', 3));

        assertNull(StringUtils.repeat(null, null, 2));
        assertEquals("xx", StringUtils.repeat("", "x", 3));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    public void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] {"a"}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
    }

    @Test
    public void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc def"));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] {"abc"}, StringUtils.split(" abc "));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[] {"a:b:c"}, StringUtils.split("a:b:c", '.'));

        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
    }

    @Test
    public void testContainsAndIndexOf() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(1, StringUtils.indexOf("abc", "b"));
        assertEquals(-1, StringUtils.indexOf("abc", "z"));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(1, StringUtils.lastIndexOf("abab", "b", 2));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
    }

    @Test
    public void testStartsWithEndsWith() {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith(null, null));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
    }

    @Test
    public void testReplaceRemove() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("", StringUtils.replace("", "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("aba", StringUtils.replace("aba", "a", null));
        assertEquals("b", StringUtils.replace("aba", "a", ""));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));

        assertNull(StringUtils.remove(null, "a"));
        assertEquals("", StringUtils.remove("", "a"));
        assertEquals("qunstown", StringUtils.remove("queenstown", "ee"));
        assertEquals("qunstown", StringUtils.remove("queenstown", "e"));
        assertEquals("abc", StringUtils.remove("abc", "x"));

        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("bc", StringUtils.removeStart("abc", "a"));
        assertEquals("abc", StringUtils.removeStart("abc", "x"));

        assertNull(StringUtils.removeEnd(null, "c"));
        assertEquals("ab", StringUtils.removeEnd("abc", "c"));
        assertEquals("abc", StringUtils.removeEnd("abc", "x"));
    }

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 0, 0));
        assertNull(StringUtils.truncate(null, 2, 4));
        assertEquals("", StringUtils.truncate("", 0, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("abcdefghijklmno", StringUtils.truncate("abcdefghijklmno", 0, Integer.MAX_VALUE));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghijklmno", -1, 10);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghij", 3, -1);
            }
        });
    }

    @Test
    public void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));

        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", "\""));

        assertEquals("/", StringUtils.wrapIfMissing("/", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("/a/b/c", '/'));
    }

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
    }

    @Test
    public void testOrdinalIndexOfAndCountMatches() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "ab", 1));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "ab", 2));

        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });

        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    @Test
    public void testDefaultStringAndDefaultIfEmpty() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));
    }

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("TMNXS", StringUtils.swapCase("tmnxs"));
        assertEquals("tmnxs", StringUtils.swapCase("TMNXS"));
        assertEquals("sTRING", StringUtils.swapCase("String"));
    }

    @Test
    public void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c "));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b   c  "));
    }

    @Test
    public void testSubstringBeforeAfter() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("c", StringUtils.substringAfter("abc", "b"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
    }

    @Test
    public void testGetDigitsAndStripAccents() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("1800555123", StringUtils.getDigits("1800 555 123"));

        assertNull(StringUtils.stripAccents(null));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    public void testIsAllBlankIsAnyEmpty() {
        assertTrue(StringUtils.isAllBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAllBlank(" ", null, ""));
        assertFalse(StringUtils.isAllBlank(" ", "x"));

        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertFalse(StringUtils.isAnyEmpty());
    }
}
