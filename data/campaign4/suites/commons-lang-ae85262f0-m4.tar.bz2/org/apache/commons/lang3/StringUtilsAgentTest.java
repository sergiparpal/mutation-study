/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    // capitalize / uncapitalize

    @Test
    public void testCapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));
    }

    @Test
    public void testUncapitalize() {
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    // center

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", 0));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7));
    }

    @Test
    public void testCenterEmptyOrNullPadStringTreatedAsSpace() {
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
    }

    // chomp / chop

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
        assertEquals("", StringUtils.chomp("\n"));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    // countMatches

    @Test
    public void testCountMatchesChar() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(4, StringUtils.countMatches("abababa", 'a'));
        assertEquals(0, StringUtils.countMatches("xyz", 'a'));
    }

    @Test
    public void testCountMatchesString() {
        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(2, StringUtils.countMatches("abcabc", "abc"));
    }

    // defaultString / defaultIfBlank / defaultIfEmpty

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));
    }

    @Test
    public void testDefaultIfBlank() {
        assertEquals("NULL", StringUtils.defaultIfBlank((String) null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NULL"));
        assertNull(StringUtils.defaultIfBlank("", null));
    }

    @Test
    public void testDefaultIfEmpty() {
        assertEquals("NULL", StringUtils.defaultIfEmpty((String) null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("  ", StringUtils.defaultIfEmpty("  ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
    }

    // deleteWhitespace

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("", StringUtils.deleteWhitespace("   \t\n "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b  c "));
    }

    // difference

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", ""));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("tx", StringUtils.difference("ab", "abtx"));
        assertEquals("yz", StringUtils.difference("abxyz", "abyz"));
    }

    // firstNonBlank / firstNonEmpty

    @Test
    public void testFirstNonBlank() {
        assertNull(StringUtils.<String>firstNonBlank());
        assertNull(StringUtils.firstNonBlank(null, null, ""));
        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));
    }

    @Test
    public void testFirstNonEmpty() {
        assertNull(StringUtils.<String>firstNonEmpty());
        assertNull(StringUtils.firstNonEmpty(null, ""));
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
    }

    // getLevenshteinDistance

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(7, StringUtils.getLevenshteinDistance("frog", "fog") + 6);
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting"));
    }

    @Test
    public void testGetLevenshteinDistanceNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
    }

    @Test
    public void testGetLevenshteinDistanceWithThreshold() {
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog", 5));
        assertEquals(-1, StringUtils.getLevenshteinDistance("frog", "cat", 1));
    }

    @Test
    public void testGetLevenshteinDistanceNegativeThresholdThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    // indexOfIgnoreCase / lastIndexOfIgnoreCase

    @Test
    public void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("a", null));
        assertEquals(0, StringUtils.indexOfIgnoreCase("", ""));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));
    }

    @Test
    public void testLastIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase(null, "a"));
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase("a", null));
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B"));
    }

    // join

    @Test
    public void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] {"a"}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    public void testJoinObjectArrayWithStringSeparator() {
        assertNull(StringUtils.join((Object[]) null, "-"));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
    }

    @Test
    public void testJoinIntArray() {
        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertNull(StringUtils.join((int[]) null, ','));
        assertEquals("", StringUtils.join(new int[0], ','));
    }

    @Test
    public void testJoinIterable() {
        java.util.List<String> list = new java.util.ArrayList<String>();
        list.add("a");
        list.add("b");
        assertEquals("a,b", StringUtils.join((Iterable<?>) list, ','));
        assertNull(StringUtils.join((Iterable<?>) null, ','));
    }

    @Test
    public void testJoinWithRange() {
        Object[] array = {"a", "b", "c", "d"};
        assertEquals("b,c", StringUtils.join(array, ',', 1, 3));
        assertEquals("", StringUtils.join(array, ',', 1, 1));
    }

    // leftPad / rightPad

    @Test
    public void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));
    }

    @Test
    public void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("   ", StringUtils.rightPad("", 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxy", StringUtils.rightPad("ab", 4, "xy"));
    }

    // normalizeSpace

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
        assertEquals("", StringUtils.normalizeSpace("   "));
    }

    // ordinalIndexOf

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));
    }

    // overlay

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
    }

    // remove

    @Test
    public void testRemoveChar() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("", StringUtils.remove("", 'a'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("abc", StringUtils.remove("abc", 'x'));
    }

    @Test
    public void testRemoveString() {
        assertNull(StringUtils.remove(null, "a"));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("abc", StringUtils.remove("abc", null));
        assertEquals("abc", StringUtils.remove("abc", ""));
    }

    // repeat

    @Test
    public void testRepeatChar() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("", StringUtils.repeat('e', -2));
        assertEquals("eee", StringUtils.repeat('e', 3));
    }

    @Test
    public void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat("", 3));
    }

    @Test
    public void testRepeatWithSeparator() {
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
        assertEquals("", StringUtils.repeat("a", "-", 0));
        assertEquals("a", StringUtils.repeat("a", "-", 1));
        assertNull(StringUtils.repeat(null, "-", 3));
    }

    // replace

    @Test
    public void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("any", StringUtils.replace("any", "a", null));
        assertEquals("any", StringUtils.replace("any", "", "b"));
        assertEquals("zzz", StringUtils.replace("aaa", "a", "z"));
    }

    @Test
    public void testReplaceWithMax() {
        assertEquals("zaa", StringUtils.replace("aaa", "a", "z", 1));
        assertEquals("zza", StringUtils.replace("aaa", "a", "z", 2));
        assertEquals("zzz", StringUtils.replace("aaa", "a", "z", -1));
        assertEquals("aaa", StringUtils.replace("aaa", "a", "z", 0));
    }

    // reverse

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    // rotate

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    // split

    @Test
    public void testSplitDefault() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split(" ab  cd ef  "));
    }

    @Test
    public void testSplitChar() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[0], StringUtils.split("", '.'));
    }

    @Test
    public void testSplitStringMax() {
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":", 0));
    }

    // swapCase

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("THE dog HAS CAT", StringUtils.swapCase("the DOG has cat"));
    }

    // truncate

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abcde", StringUtils.truncate("abcdefghij", 5));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghij", 10));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghij", 20));
        assertEquals("", StringUtils.truncate("abcdefghij", 0));
    }

    @Test
    public void testTruncateNegativeMaxWidthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });
    }

    @Test
    public void testTruncateWithOffset() {
        assertEquals("cdefghij", StringUtils.truncate("abcdefghij", 2, 8));
        assertEquals("cde", StringUtils.truncate("abcdefghij", 2, 3));
        assertNull(StringUtils.truncate(null, 2, 3));
    }

    @Test
    public void testTruncateNegativeOffsetThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.truncate("abc", -1, 3);
            }
        });
    }

    // unwrap / wrap

    @Test
    public void testWrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("", StringUtils.wrap("", '"'));
        assertEquals("\"ab\"", StringUtils.wrap("ab", '"'));
    }

    @Test
    public void testUnwrap() {
        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("ab", StringUtils.unwrap("\"ab\"", '"'));
        assertEquals("ab", StringUtils.unwrap("ab", '"'));
        assertEquals("\"", StringUtils.unwrap("\"", '"'));
    }

    // isEmpty / isBlank family - boundary sanity (also exercised elsewhere, kept minimal here)

    @Test
    public void testIsEmptyAndIsBlank() {
        assertEquals(true, StringUtils.isEmpty(null));
        assertEquals(true, StringUtils.isEmpty(""));
        assertEquals(false, StringUtils.isEmpty(" "));
        assertEquals(true, StringUtils.isBlank(null));
        assertEquals(true, StringUtils.isBlank(" \t\n"));
        assertEquals(false, StringUtils.isBlank(" a "));
    }

    @Test
    public void testAbbreviateBoundary() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc", StringUtils.abbreviate("abc", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
    }

    @Test
    public void testAbbreviateTooSmallWidthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testSameInstanceOnNoChange() {
        String s = "abc";
        assertSame(s, StringUtils.trim(s));
    }

}
