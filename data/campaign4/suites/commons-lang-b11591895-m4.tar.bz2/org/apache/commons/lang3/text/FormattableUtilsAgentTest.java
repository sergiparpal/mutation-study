/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Formattable;
import java.util.FormattableFlags;
import java.util.Formatter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FormattableUtils}.
 */
public class FormattableUtilsAgentTest {

    private static final class SimpleFormattable implements Formattable {
        private final String value;

        SimpleFormattable(final String value) {
            this.value = value;
        }

        @Override
        public void formatTo(final Formatter formatter, final int flags, final int width, final int precision) {
            FormattableUtils.append(value, formatter, flags, width, precision);
        }
    }

    @Test
    public void testAppendNoPaddingNoTruncation() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("hello", formatter, 0, -1, -1);
        assertSame(formatter, result);
        assertEquals("hello", formatter.toString());
    }

    @Test
    public void testAppendWidthPadsOnLeftByDefault() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, 0, 5, -1);
        assertEquals("   ab", formatter.toString());
    }

    @Test
    public void testAppendLeftJustifyPadsOnRight() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1);
        assertEquals("ab   ", formatter.toString());
    }

    @Test
    public void testAppendWidthSmallerThanLengthDoesNotPad() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 2, -1);
        assertEquals("hello", formatter.toString());
    }

    @Test
    public void testAppendPrecisionTruncatesHardWithoutEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 3);
        assertEquals("hel", formatter.toString());
    }

    @Test
    public void testAppendPrecisionEqualToLengthDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 5);
        assertEquals("hello", formatter.toString());
    }

    @Test
    public void testAppendPrecisionGreaterThanLengthDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 100);
        assertEquals("hello", formatter.toString());
    }

    @Test
    public void testAppendCustomPadChar() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, 0, 5, -1, '*');
        assertEquals("***ab", formatter.toString());
    }

    @Test
    public void testAppendWithEllipsisTruncation() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, -1, 5, ' ', "...");
        assertEquals("he...", formatter.toString());
    }

    @Test
    public void testAppendWithEmptyEllipsisActsAsHardTruncation() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, -1, 5, ' ', "");
        assertEquals("hello", formatter.toString());
    }

    @Test
    public void testAppendWithNullEllipsisActsAsHardTruncation() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, -1, 5, ' ', null);
        assertEquals("hello", formatter.toString());
    }

    @Test
    public void testAppendFourArgOverloadWithEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, -1, 5, "...");
        assertEquals("he...", formatter.toString());
    }

    @Test
    public void testAppendEllipsisLongerThanPrecisionThrows() {
        final Formatter formatter = new Formatter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FormattableUtils.append("hello world", formatter, 0, -1, 2, ' ', "...");
            }
        });
    }

    @Test
    public void testAppendEllipsisEqualToPrecisionIsAllowed() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, -1, 3, ' ', "...");
        assertEquals("...", formatter.toString());
    }

    @Test
    public void testAppendNegativePrecisionIgnoresEllipsisLengthCheck() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hi", formatter, 0, -1, -1, ' ', "this ellipsis is way too long");
        assertEquals("hi", formatter.toString());
    }

    @Test
    public void testAppendEmptySequence() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("", formatter, 0, -1, -1);
        assertEquals("", formatter.toString());
    }

    @Test
    public void testAppendEmptySequenceWithWidthPads() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("", formatter, 0, 4, -1);
        assertEquals("    ", formatter.toString());
    }

    @Test
    public void testAppendZeroPrecisionTruncatesToEmpty() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 0);
        assertEquals("", formatter.toString());
    }

    @Test
    public void testAppendReturnsSameFormatterInstance() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("x", formatter, 0, -1, -1, '-', null);
        assertSame(formatter, result);
    }

    @Test
    public void testToStringUsesFormattableFormatTo() {
        final Formattable formattable = new SimpleFormattable("value");
        final String result = FormattableUtils.toString(formattable);
        assertEquals("value", result);
    }

    @Test
    public void testToStringWithFormattableThatAppliesWidthViaFormat() {
        final Formattable formattable = new Formattable() {
            @Override
            public void formatTo(final Formatter formatter, final int flags, final int width, final int precision) {
                FormattableUtils.append("ab", formatter, flags, 5, precision);
            }
        };
        assertEquals("   ab", FormattableUtils.toString(formattable));
    }

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new FormattableUtils());
    }
}
