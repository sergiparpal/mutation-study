package org.apache.commons.cli;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link Options}, based solely on the documented
 * contract in the generated javadoc under api/.
 */
public class OptionsAgentTest {

    @Test
    public void testNewInstanceStartsEmpty() {
        Options options = new Options();
        assertTrue(options.getOptions().isEmpty());
        assertTrue(options.getRequiredOptions().isEmpty());
        assertTrue(options.getOptionGroups().isEmpty());
        assertTrue(options.helpOptions().isEmpty());
    }

    @Test
    public void testAddOptionShortOnly() {
        Options options = new Options();
        Options returned = options.addOption("a", "a short option");

        assertSame(options, returned);
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasShortOption("a"));
        assertFalse(options.hasLongOption("a"));
        assertNotNull(options.getOption("a"));
        assertSame(options.getOption("a"), options.getOption("-a"));
    }

    @Test
    public void testAddOptionShortOnlyWithHasArg() {
        Options options = new Options();
        Options returned = options.addOption("b", true, "requires an argument");

        assertSame(options, returned);
        assertTrue(options.hasOption("b"));
        assertEquals(1, options.getOptions().size());
    }

    @Test
    public void testAddOptionShortAndLong() {
        Options options = new Options();
        Options returned = options.addOption("c", "cee", false, "short and long");

        assertSame(options, returned);
        assertTrue(options.hasOption("c"));
        assertTrue(options.hasOption("cee"));
        assertTrue(options.hasShortOption("c"));
        assertFalse(options.hasShortOption("cee"));
        assertTrue(options.hasLongOption("cee"));
        assertFalse(options.hasLongOption("c"));
        assertSame(options.getOption("c"), options.getOption("cee"));
    }

    @Test
    public void testAddOptionInstance() {
        Options options = new Options();
        Option option = new Option("d", "dee", false, "an option instance");

        Options returned = options.addOption(option);

        assertSame(options, returned);
        assertSame(option, options.getOption("d"));
        assertSame(option, options.getOption("dee"));
    }

    @Test
    public void testAddRequiredOption() {
        Options options = new Options();
        assertEquals(0, options.getRequiredOptions().size());

        Options returned = options.addRequiredOption("r", "req", true, "a required option");

        assertSame(options, returned);
        assertEquals(1, options.getRequiredOptions().size());
        Option stored = options.getOption("r");
        assertNotNull(stored);
        assertTrue(stored.isRequired());
        assertTrue(options.hasOption("req"));
    }

    @Test
    public void testAddOptionGroup() {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        Option first = new Option("e", "first in group");
        Option second = new Option("f", "second in group");
        group.addOption(first);
        group.addOption(second);

        Options returned = options.addOptionGroup(group);

        assertSame(options, returned);
        assertTrue(options.hasOption("e"));
        assertTrue(options.hasOption("f"));
        assertSame(group, options.getOptionGroup(first));
        assertSame(group, options.getOptionGroup(second));
        assertTrue(options.getOptionGroups().contains(group));
    }

    @Test
    public void testAddOptionGroupClearsRequiredFlag() {
        Options options = new Options();
        Option grouped = new Option("g", "grouped", false, "should become optional");
        grouped.setRequired(true);
        OptionGroup group = new OptionGroup();
        group.addOption(grouped);

        options.addOptionGroup(group);

        assertFalse(grouped.isRequired());
    }

    @Test
    public void testGetOptionGroupNullWhenNotInGroup() {
        Options options = new Options();
        Option standalone = new Option("s", "standalone", false, "not in any group");
        options.addOption(standalone);

        assertNull(options.getOptionGroup(standalone));
    }

    @Test
    public void testAddOptions() {
        Options base = new Options();
        base.addOption("a", "alpha", false, "base option");
        Options extra = new Options();
        extra.addOption("b", "beta", false, "extra option");

        Options returned = base.addOptions(extra);

        assertSame(base, returned);
        assertTrue(base.hasOption("a"));
        assertTrue(base.hasOption("b"));
        assertEquals(2, base.getOptions().size());
    }

    @Test
    public void testAddOptionsDuplicateThrowsException() {
        final Options base = new Options();
        base.addOption("a", "alpha", false, "first");
        final Options dup = new Options();
        dup.addOption("a", "alphaAgain", false, "duplicate short name");

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                base.addOptions(dup);
            }
        });
    }

    @Test
    public void testGetMatchingOptions() {
        Options options = new Options();
        options.addOption("f", "foo", false, "foo option");
        options.addOption("b", "foobar", false, "foobar option");
        options.addOption("z", "bar", false, "bar option");
        options.addOption("n", false, "short only, no long name");

        List<String> matches = options.getMatchingOptions("foo");

        assertEquals(2, matches.size());
        assertTrue(matches.containsAll(Arrays.asList("foo", "foobar")));
        assertFalse(matches.contains("bar"));

        assertEquals(1, options.getMatchingOptions("foob").size());
        assertTrue(options.getMatchingOptions("qux").isEmpty());
    }

    @Test
    public void testGetMatchingOptionsNullAndEmpty() {
        Options options = new Options();
        options.addOption("f", "foo", false, "foo option");

        assertTrue(options.getMatchingOptions(null).isEmpty());
        assertTrue(options.getMatchingOptions("").isEmpty());
    }

    @Test
    public void testGetOptionUnknown() {
        Options options = new Options();

        assertNull(options.getOption("zzz"));
        assertFalse(options.hasOption("zzz"));
        assertFalse(options.hasShortOption("zzz"));
        assertFalse(options.hasLongOption("zzz"));
    }

    @Test
    public void testGetOptionHyphenHandling() {
        Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        Option expected = options.getOption("a");

        assertNotNull(expected);
        assertSame(expected, options.getOption("-a"));
        assertSame(expected, options.getOption("--a"));
        assertSame(expected, options.getOption("--alpha"));
        assertSame(expected, options.getOption("-alpha"));
        // Only up to 2 leading hyphens are stripped, so a 3rd hyphen remains
        // part of the name and no longer matches.
        assertNull(options.getOption("---a"));
    }

    @Test
    public void testGetOptionsIsReadOnly() {
        Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        final Collection<Option> all = options.getOptions();

        assertEquals(1, all.size());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                all.clear();
            }
        });
    }

    @Test
    public void testGetRequiredOptionsIsReadOnly() {
        Options options = new Options();
        options.addRequiredOption("r", "req", true, "required option");
        final List<?> required = options.getRequiredOptions();

        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                required.add(null);
            }
        });
    }

    @Test
    public void testHelpOptionsEmptyInitially() {
        Options options = new Options();

        List<Option> help = options.helpOptions();

        assertNotNull(help);
        assertTrue(help.isEmpty());
    }

    @Test
    public void testToString() {
        Options options = new Options();
        String empty = options.toString();
        assertNotNull(empty);

        options.addOption("a", "alpha", false, "desc");
        String withOption = options.toString();
        assertNotNull(withOption);
        assertFalse(withOption.isEmpty());
    }
}
