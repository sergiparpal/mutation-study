/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
public class RandomStringUtilsAgentTest {

    @Test
    public void testRandomZeroCountReturnsEmptyString() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    public void testRandomNegativeCountThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
        assertTrue(e.getMessage().contains("-1"));
    }

    @Test
    public void testRandomLength() {
        final String s = RandomStringUtils.random(50);
        assertEquals(50, s.length());
    }

    @Test
    public void testRandomAlphabeticOnlyLetters() {
        final String s = RandomStringUtils.randomAlphabetic(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)), "Expected letter but got: " + s.charAt(i));
        }
    }

    @Test
    public void testRandomAlphabeticRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10, "length=" + s.length());
        }
    }

    @Test
    public void testRandomAlphanumericOnlyLettersAndDigits() {
        final String s = RandomStringUtils.randomAlphanumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetter(c) || Character.isDigit(c), "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomNumericOnlyDigits() {
        final String s = RandomStringUtils.randomNumeric(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)), "Expected digit but got: " + s.charAt(i));
        }
    }

    @Test
    public void testRandomAsciiRange() {
        final String s = RandomStringUtils.randomAscii(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char out of ASCII printable range: " + (int) c);
        }
    }

    @Test
    public void testRandomGraphRange() {
        final String s = RandomStringUtils.randomGraph(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c < 126, "Char out of graph range: " + (int) c);
            assertFalse(c == ' ', "Space should not be included");
        }
    }

    @Test
    public void testRandomPrintRange() {
        final String s = RandomStringUtils.randomPrint(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c < 126, "Char out of print range: " + (int) c);
        }
    }

    @Test
    public void testRandomWithCharsArray() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(50, chars);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomWithNullCharsArrayUsesAllChars() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.random(10, nullChars);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomWithEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, new char[0]);
            }
        });
    }

    @Test
    public void testRandomWithStringChars() {
        final String s = RandomStringUtils.random(30, "ab");
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @Test
    public void testRandomWithNullStringCharsUsesAllChars() {
        final String s = RandomStringUtils.random(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomLettersAndNumbersFlags() {
        final String s = RandomStringUtils.random(100, true, true);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetterOrDigit(c), "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomStartEndLettersNumbers() {
        final Random fixed = new Random(42);
        final String s = RandomStringUtils.random(20, 'a', 'f' + 1, true, false, null, fixed);
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 'a' && c <= 'f', "Char out of range: " + c);
        }
    }

    @Test
    public void testRandomEndNotGreaterThanStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 10, false, false);
            }
        });
    }

    @Test
    public void testRandomNegativeStartOrEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false);
            }
        });
    }

    @Test
    public void testRandomNoLettersInRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, '0', '9' + 1, true, false);
            }
        });
    }

    @Test
    public void testRandomNoDigitsInRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, 20, false, true);
            }
        });
    }

    @Test
    public void testRandomDeterministicWithFixedRandomSource() {
        final Random r1 = new Random(123);
        final Random r2 = new Random(123);
        final String s1 = RandomStringUtils.random(25, 0, 0, true, true, null, r1);
        final String s2 = RandomStringUtils.random(25, 0, 0, true, true, null, r2);
        assertEquals(s1, s2);
    }

    @Test
    public void testSecureInsecureSecureStrongAreSingletonsAndDistinct() {
        final RandomStringUtils secure1 = RandomStringUtils.secure();
        final RandomStringUtils secure2 = RandomStringUtils.secure();
        final RandomStringUtils insecure1 = RandomStringUtils.insecure();
        final RandomStringUtils secureStrong = RandomStringUtils.secureStrong();
        assertSame(secure1, secure2);
        assertNotSame(secure1, insecure1);
        assertNotSame(secure1, secureStrong);
        assertNotNull(insecure1);
        assertNotNull(secureStrong);
    }

    @Test
    public void testInstanceNextMethods() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals(15, rsu.next(15).length());
        assertEquals(0, rsu.next(0).length());
        assertEquals(10, rsu.nextAlphabetic(10).length());
        assertEquals(10, rsu.nextAlphanumeric(10).length());
        assertEquals(10, rsu.nextNumeric(10).length());
        assertEquals(10, rsu.nextAscii(10).length());
        assertEquals(10, rsu.nextGraph(10).length());
        assertEquals(10, rsu.nextPrint(10).length());
    }

    @Test
    public void testInstanceNextRangeMethods() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        for (int i = 0; i < 10; i++) {
            assertTrue(inRange(rsu.nextAlphabetic(3, 8).length(), 3, 8));
            assertTrue(inRange(rsu.nextAlphanumeric(3, 8).length(), 3, 8));
            assertTrue(inRange(rsu.nextNumeric(3, 8).length(), 3, 8));
            assertTrue(inRange(rsu.nextAscii(3, 8).length(), 3, 8));
            assertTrue(inRange(rsu.nextGraph(3, 8).length(), 3, 8));
            assertTrue(inRange(rsu.nextPrint(3, 8).length(), 3, 8));
        }
    }

    private static boolean inRange(final int value, final int minInclusive, final int maxExclusive) {
        return value >= minInclusive && value < maxExclusive;
    }

    @Test
    public void testNextNegativeCountThrows() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                rsu.next(-5);
            }
        });
    }

    @Test
    public void testNextWithCharArrayVarargs() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final String s = rsu.next(20, 'x', 'y');
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y', "Unexpected char: " + c);
        }
    }

    @Test
    public void testNextWithStringChars() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final String s = rsu.next(20, "pq");
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'p' || c == 'q', "Unexpected char: " + c);
        }
    }

    @Test
    public void testDeprecatedNoArgConstructorStillUsable() {
        @SuppressWarnings("deprecation")
        final RandomStringUtils rsu = new RandomStringUtils();
        assertNotNull(rsu);
        assertEquals(5, rsu.next(5).length());
    }

    @Test
    public void testToStringContainsClassName() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final String str = rsu.toString();
        assertTrue(str.contains("RandomStringUtils"), "toString did not contain class name: " + str);
    }

    @Test
    public void testRandomWithAllCodePointsWhenNoLettersOrDigits() {
        final String s = RandomStringUtils.random(10, 0, 0, false, false);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomMaxCodePointClampedWhenEndTooLarge() {
        final Random fixed = new Random(7);
        final String s = RandomStringUtils.random(5, 0, Character.MAX_CODE_POINT + 100, false, false, null, fixed);
        assertEquals(5, s.codePointCount(0, s.length()));
    }
}
