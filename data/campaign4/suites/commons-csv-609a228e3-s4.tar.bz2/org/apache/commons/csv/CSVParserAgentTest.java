package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Self-contained tests for {@link CSVParser} based on its documented contract.
 */
public class CSVParserAgentTest {

    /** A Reader whose every read fails, used to force IOException during parsing. */
    private static final class FailingReader extends Reader {
        @Override
        public int read(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("Simulated read failure");
        }

        @Override
        public void close() throws IOException {
            // Nothing to close.
        }
    }

    @TempDir
    Path tempDir;

    // ---- String ----------------------------------------------------------

    @Test
    public void testParseStringBasicRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n3,4\n", CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(3, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("b", records.get(0).get(1));
        assertEquals("3", records.get(1).get(0));
        assertEquals("4", records.get(1).get(1));
        parser.close();
    }

    @Test
    public void testParseStringNullThrowsNullPointerException() {
        assertThrowsNpe(new ThrowingRunnable() {
            @Override
            public void run() throws Exception {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- Reader ------------------------------------------------------------

    @Test
    public void testParseReaderBasicRecords() throws IOException {
        Reader reader = new java.io.StringReader("x,y\n1,2\n");
        CSVParser parser = CSVParser.parse(reader, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("x", records.get(0).get(0));
        parser.close();
    }

    @Test
    public void testParseReaderNullThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    // ---- File ----------------------------------------------------------

    @Test
    public void testParseFileBasicRecords() throws IOException {
        File file = tempDir.resolve("parseFile.csv").toFile();
        writeFile(file, "a,b\n1,2\n");
        CSVParser parser = CSVParser.parse(file, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(1).get(0));
        parser.close();
    }

    @Test
    public void testParseFileNullThrowsNullPointerException() {
        assertThrowsNpe(new ThrowingRunnable() {
            @Override
            public void run() throws Exception {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- Path ------------------------------------------------------------

    @Test
    public void testParsePathBasicRecords() throws IOException {
        Path path = tempDir.resolve("parsePath.csv");
        Files.write(path, "p,q\n9,8\n".getBytes(StandardCharsets.UTF_8));
        CSVParser parser = CSVParser.parse(path, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("9", records.get(1).get(0));
        parser.close();
    }

    @Test
    public void testParsePathNullThrowsNullPointerException() {
        assertThrowsNpe(new ThrowingRunnable() {
            @Override
            public void run() throws Exception {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- URL ------------------------------------------------------------

    @Test
    public void testParseUrlBasicRecords() throws IOException {
        File file = tempDir.resolve("parseUrl.csv").toFile();
        writeFile(file, "u,v\n5,6\n");
        URL url = file.toURI().toURL();
        CSVParser parser = CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("5", records.get(1).get(0));
        parser.close();
    }

    @Test
    public void testParseUrlNullThrowsNullPointerException() {
        assertThrowsNpe(new ThrowingRunnable() {
            @Override
            public void run() throws Exception {
                CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- InputStream ------------------------------------------------------

    @Test
    public void testParseInputStreamBasicRecords() throws IOException {
        InputStream in = new ByteArrayInputStream("i,j\n7,8\n".getBytes(StandardCharsets.UTF_8));
        CSVParser parser = CSVParser.parse(in, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("7", records.get(1).get(0));
        parser.close();
    }

    // ---- Deprecated constructors ------------------------------------------

    @Test
    public void testDeprecatedConstructorBasic() throws IOException {
        Reader reader = new java.io.StringReader("c,d\n1,2\n");
        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testDeprecatedConstructorNullReaderThrowsIllegalArgumentException() {
        try {
            new CSVParser((Reader) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testDeprecatedConstructorNullFormatThrowsIllegalArgumentException() {
        Reader reader = new java.io.StringReader("a,b\n");
        try {
            new CSVParser(reader, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testDeprecatedConstructorWithRecordNumberOffset() throws IOException {
        Reader reader = new java.io.StringReader("1,2\n3,4\n");
        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT, 0L, 5L);
        CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals(5L, parser.getRecordNumber());
        CSVRecord record2 = parser.nextRecord();
        assertNotNull(record2);
        assertEquals(6L, parser.getRecordNumber());
        parser.close();
    }

    // ---- builder() ---------------------------------------------------------

    @Test
    public void testBuilderReturnsUsableInstance() {
        CSVParser.Builder builder = CSVParser.builder();
        assertNotNull(builder);
    }

    @Test
    public void testBuilderGetProducesWorkingParser() throws IOException {
        Reader reader = new java.io.StringReader("a,b\n1,2\n");
        CSVParser parser = CSVParser.builder().setReader(reader).setFormat(CSVFormat.DEFAULT).get();
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(1).get(0));
        parser.close();
    }

    @Test
    public void testBuilderSetRecordNumberAffectsFirstRecordNumber() throws IOException {
        Reader reader = new java.io.StringReader("1,2\n3,4\n");
        CSVParser parser = CSVParser.builder().setReader(reader).setFormat(CSVFormat.DEFAULT).setRecordNumber(10L).get();
        CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals(10L, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testBuilderOffsetAndTrackBytesSettersDoNotBreakParsing() throws IOException {
        Reader reader = new java.io.StringReader("1,2\n3,4\n");
        CSVParser parser = CSVParser.builder()
                .setReader(reader)
                .setFormat(CSVFormat.DEFAULT)
                .setCharacterOffset(0L)
                .setByteOffset(-1L)
                .setTrackBytes(false)
                .get();
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
    }

    // ---- getRecordNumber / getCurrentLineNumber ----------------------------

    @Test
    public void testGetRecordNumberProgressesFromZero() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        assertEquals(0L, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(1L, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(2L, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testGetCurrentLineNumberProgresses() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        assertEquals(0L, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(1L, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(2L, parser.getCurrentLineNumber());
        parser.close();
    }

    // ---- getFirstEndOfLine -------------------------------------------------

    @Test
    public void testGetFirstEndOfLine() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        parser.getRecords();
        assertEquals("\n", parser.getFirstEndOfLine());
        parser.close();
    }

    // ---- header map / header names -----------------------------------------

    @Test
    public void testGetHeaderMapContainsColumnIndices() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).build();
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(2, headerMap.size());
        assertEquals(Integer.valueOf(0), headerMap.get("a"));
        assertEquals(Integer.valueOf(1), headerMap.get("b"));
        parser.close();
    }

    @Test
    public void testGetHeaderMapReturnsIndependentCopy() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).build();
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        Map<String, Integer> first = parser.getHeaderMap();
        first.remove("a");
        Map<String, Integer> second = parser.getHeaderMap();
        assertTrue(second.containsKey("a"));
        assertEquals(2, second.size());
        parser.close();
    }

    @Test
    public void testGetHeaderMapRawMatchesHeaderMap() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).build();
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        Map<String, Integer> headerMap = parser.getHeaderMap();
        Map<String, Integer> raw = parser.getHeaderMapRaw();
        assertEquals(headerMap, raw);
        parser.close();
    }

    @Test
    public void testGetHeaderNamesOrderAndReadOnly() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("first", "second").setSkipHeaderRecord(true).build();
        CSVParser parser = CSVParser.parse("first,second\n1,2\n", format);
        List<String> names = parser.getHeaderNames();
        assertEquals(Arrays.asList("first", "second"), names);
        try {
            names.add("third");
            fail("Expected header names list to be read-only");
        } catch (UnsupportedOperationException expected) {
            // documented as read-only
        }
        parser.close();
    }

    // ---- header / trailer comments -----------------------------------------

    @Test
    public void testHasHeaderCommentFalseByDefault() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        assertFalse(parser.hasHeaderComment());
        assertNull(parser.getHeaderComment());
        parser.close();
    }

    @Test
    public void testHeaderCommentDetectedBeforeExplicitHeader() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader("name", "age")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("# header comment\nname,age\nJohn,30\n", format);
        assertTrue(parser.hasHeaderComment());
        assertEquals("header comment", parser.getHeaderComment());
        List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("John", records.get(0).get("name"));
        parser.close();
    }

    @Test
    public void testHasTrailerCommentFalseByDefault() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", format);
        parser.getRecords();
        assertFalse(parser.hasTrailerComment());
        assertNull(parser.getTrailerComment());
        parser.close();
    }

    @Test
    public void testTrailerCommentDetectedAfterLastRecord() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        CSVParser parser = CSVParser.parse("1,2\n3,4\n# trailer comment\n", format);
        parser.getRecords();
        assertTrue(parser.hasTrailerComment());
        assertEquals("trailer comment", parser.getTrailerComment());
        parser.close();
    }

    // ---- isClosed / close --------------------------------------------------

    @Test
    public void testIsClosedReflectsCloseCall() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ---- iterator() ---------------------------------------------------------

    @Test
    public void testIteratorTraversesAllRecords() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        Iterator<CSVRecord> iterator = parser.iterator();
        assertTrue(iterator.hasNext());
        CSVRecord first = iterator.next();
        assertEquals("1", first.get(0));
        assertTrue(iterator.hasNext());
        CSVRecord second = iterator.next();
        assertEquals("3", second.get(0));
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException at end of iteration");
        } catch (NoSuchElementException expected) {
            // documented
        }
        parser.close();
    }

    @Test
    public void testIteratorOnClosedParserYieldsNoRecords() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        parser.close();
        Iterator<CSVRecord> iterator = parser.iterator();
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException on closed parser");
        } catch (NoSuchElementException expected) {
            // documented
        }
    }

    @Test
    public void testIteratorRethrowsIOExceptionAsIllegalStateException() throws IOException {
        CSVParser parser = CSVParser.parse(new FailingReader(), CSVFormat.DEFAULT);
        Iterator<CSVRecord> iterator = parser.iterator();
        try {
            iterator.hasNext();
            fail("Expected IllegalStateException wrapping the IOException");
        } catch (IllegalStateException expected) {
            // documented
        }
    }

    // ---- getRecords() ---------------------------------------------------------

    @Test
    public void testGetRecordsOnEmptyInputIsEmptyNotNull() throws IOException {
        CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertNotNull(records);
        assertTrue(records.isEmpty());
        parser.close();
    }

    @Test
    public void testGetRecordsStartsAtCurrentParsePosition() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n3,4\n5,6\n", CSVFormat.DEFAULT);
        CSVRecord consumedFirst = parser.nextRecord();
        assertNotNull(consumedFirst);
        List<CSVRecord> remaining = parser.getRecords();
        assertEquals(2, remaining.size());
        assertEquals("3", remaining.get(0).get(0));
        assertEquals("5", remaining.get(1).get(0));
        parser.close();
    }

    @Test
    public void testGetRecordsThrowsUncheckedIOExceptionOnReadFailure() throws IOException {
        CSVParser parser = CSVParser.parse(new FailingReader(), CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected UncheckedIOException");
        } catch (UncheckedIOException expected) {
            // documented
        }
    }

    // ---- nextRecord() (package-private) -------------------------------------

    @Test
    public void testNextRecordReturnsNullAtEndOfStream() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        CSVRecord end = parser.nextRecord();
        assertNull(end);
        parser.close();
    }

    // ---- stream() ---------------------------------------------------------

    @Test
    public void testStreamProducesAllRecords() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        List<CSVRecord> streamed = parser.stream().collect(java.util.stream.Collectors.toList());
        assertEquals(2, streamed.size());
        assertEquals("1", streamed.get(0).get(0));
        assertEquals("3", streamed.get(1).get(0));
        parser.close();
    }

    // ---- helpers ------------------------------------------------------------

    private static void writeFile(File file, String content) throws IOException {
        FileOutputStream out = new FileOutputStream(file);
        try {
            out.write(content.getBytes(StandardCharsets.UTF_8));
        } finally {
            out.close();
        }
    }

    private interface ThrowingRunnable {
        void run() throws Exception;
    }

    private static void assertThrowsNpe(ThrowingRunnable runnable) {
        try {
            runnable.run();
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        } catch (Exception e) {
            fail("Unexpected exception: " + e);
        }
    }
}
