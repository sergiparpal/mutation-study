package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedBufferedReader}, based solely on the documented contract.
 */
class ExtendedBufferedReaderAgentTest {

    private static ExtendedBufferedReader newReader(final String content) {
        return new ExtendedBufferedReader(new StringReader(content));
    }

    // ---- getPosition() ----

    @Test
    void getPositionIsZeroBeforeAnyRead() {
        final ExtendedBufferedReader reader = newReader("abc");
        assertEquals(0L, reader.getPosition());
    }

    @Test
    void getPositionAdvancesByOneOnSingleCharRead() throws IOException {
        final ExtendedBufferedReader reader = newReader("abc");
        reader.read();
        assertEquals(1L, reader.getPosition());
        reader.read();
        assertEquals(2L, reader.getPosition());
    }

    @Test
    void getPositionAdvancesByCountReadIntoArray() throws IOException {
        final ExtendedBufferedReader reader = newReader("abcde");
        final char[] buf = new char[3];
        final int n = reader.read(buf, 0, 3);
        assertEquals(3, n);
        assertEquals(3L, reader.getPosition());
    }

    // ---- getLastChar() ----

    @Test
    void getLastCharIsNegativeBeforeAnyRead() {
        final ExtendedBufferedReader reader = newReader("abc");
        assertTrue(reader.getLastChar() < 0, "Undefined last-char sentinel must fall outside the valid 0-65535 range");
    }

    @Test
    void getLastCharReflectsLastCharacterRead() throws IOException {
        final ExtendedBufferedReader reader = newReader("AB");
        final int first = reader.read();
        assertEquals('A', first);
        assertEquals('A', reader.getLastChar());
        final int second = reader.read();
        assertEquals('B', second);
        assertEquals('B', reader.getLastChar());
    }

    @Test
    void getLastCharReflectsLastCharacterReadIntoArray() throws IOException {
        final ExtendedBufferedReader reader = newReader("XYZ");
        final char[] buf = new char[3];
        reader.read(buf, 0, 3);
        assertEquals('Z', reader.getLastChar());
    }

    @Test
    void getLastCharMatchesEofMarkerAfterStreamExhausted() throws IOException {
        final ExtendedBufferedReader reader = newReader("A");
        reader.read();
        final int eof = reader.read();
        assertEquals(-1, eof);
        assertEquals(eof, reader.getLastChar());
    }

    // ---- read() ----

    @Test
    void readReturnsCharactersInOrderThenEof() throws IOException {
        final ExtendedBufferedReader reader = newReader("ab");
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals(-1, reader.read());
        assertEquals(-1, reader.read());
    }

    @Test
    void readOnEmptyStreamReturnsEofImmediately() throws IOException {
        final ExtendedBufferedReader reader = newReader("");
        assertEquals(-1, reader.read());
    }

    // ---- read(char[], int, int) ----

    @Test
    void readArrayFillsBufferFromOffset() throws IOException {
        final ExtendedBufferedReader reader = newReader("abcd");
        final char[] buf = new char[6];
        buf[0] = 'Z';
        final int n = reader.read(buf, 1, 4);
        assertEquals(4, n);
        assertEquals('Z', buf[0]);
        assertEquals('a', buf[1]);
        assertEquals('b', buf[2]);
        assertEquals('c', buf[3]);
        assertEquals('d', buf[4]);
    }

    @Test
    void readArrayWithZeroLengthReturnsZero() throws IOException {
        final ExtendedBufferedReader reader = newReader("abcd");
        final char[] buf = new char[4];
        final int n = reader.read(buf, 0, 0);
        assertEquals(0, n);
        assertEquals(0L, reader.getPosition());
    }

    @Test
    void readArrayAtEofReturnsMinusOne() throws IOException {
        final ExtendedBufferedReader reader = newReader("a");
        final char[] buf = new char[4];
        assertEquals(1, reader.read(buf, 0, 4));
        assertEquals(-1, reader.read(buf, 0, 4));
    }

    @Test
    void readArrayRejectsNegativeOffset() {
        final ExtendedBufferedReader reader = newReader("abcd");
        final char[] buf = new char[4];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, -1, 2);
            }
        });
    }

    @Test
    void readArrayRejectsLengthExceedingBuffer() {
        final ExtendedBufferedReader reader = newReader("abcd");
        final char[] buf = new char[4];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, 2, 10);
            }
        });
    }

    // ---- readLine() ----

    @Test
    void readLineReturnsLinesWithoutTerminatorsThenNull() throws IOException {
        final ExtendedBufferedReader reader = newReader("line1\nline2\r\nline3");
        assertEquals("line1", reader.readLine());
        assertEquals("line2", reader.readLine());
        assertEquals("line3", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    void readLineOnEmptyStreamReturnsNull() throws IOException {
        final ExtendedBufferedReader reader = newReader("");
        assertNull(reader.readLine());
    }

    @Test
    void readLineIncrementsLineNumber() throws IOException {
        final ExtendedBufferedReader reader = newReader("one\ntwo\nthree");
        assertEquals(0L, reader.getLineNumber());
        reader.readLine();
        assertEquals(1L, reader.getLineNumber());
        reader.readLine();
        assertEquals(2L, reader.getLineNumber());
    }

    @Test
    void readLineAdvancesPosition() throws IOException {
        final ExtendedBufferedReader reader = newReader("abc\ndef");
        reader.readLine();
        assertEquals(4L, reader.getPosition());
    }

    @Test
    void readLineSetsLastCharToEofMarkerAtEndOfStream() throws IOException {
        final ExtendedBufferedReader reader = newReader("onlyline");
        reader.readLine();
        assertNull(reader.readLine());
        assertEquals(-1, reader.getLastChar());
    }

    // ---- mark() / reset() ----

    @Test
    void markAndResetAllowReReadingSameCharacters() throws IOException {
        final ExtendedBufferedReader reader = newReader("abcdef");
        reader.read();
        reader.mark(10);
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        reader.reset();
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
    }

    @Test
    void resetWithoutPriorMarkThrowsIOException() {
        final ExtendedBufferedReader reader = newReader("abcdef");
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.reset();
            }
        });
    }

    // ---- close() ----

    @Test
    void readAfterCloseThrowsIOException() throws IOException {
        final ExtendedBufferedReader reader = newReader("abc");
        reader.close();
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }

    @Test
    void closingTwiceHasNoAdditionalEffect() throws IOException {
        final ExtendedBufferedReader reader = newReader("abc");
        reader.close();
        reader.close();
    }

    // ---- getBytesRead() ----

    @Test
    void getBytesReadIsZeroWithoutByteTracking() throws IOException {
        final ExtendedBufferedReader reader = newReader("hello");
        final char[] buf = new char[5];
        reader.read(buf, 0, 5);
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    void getBytesReadTracksEncodedBytesWhenEnabledWithCharset() throws IOException {
        final Reader source = new StringReader("hello");
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(source, StandardCharsets.UTF_8, true);
        assertEquals(0L, reader.getBytesRead());
        final char[] buf = new char[5];
        final int n = reader.read(buf, 0, 5);
        assertEquals(5, n);
        // Each ASCII character encodes to exactly one byte in UTF-8.
        assertEquals(5L, reader.getBytesRead());
    }

    @Test
    void getBytesReadStaysZeroWhenTrackingEnabledButCharsetIsNull() throws IOException {
        final Reader source = new StringReader("hello");
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(source, null, true);
        final char[] buf = new char[5];
        reader.read(buf, 0, 5);
        assertFalse(reader.getBytesRead() > 0);
    }
}
