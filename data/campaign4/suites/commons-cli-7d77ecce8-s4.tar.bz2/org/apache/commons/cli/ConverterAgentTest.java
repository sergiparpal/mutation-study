package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link Converter}, based solely on the documented contract.
 */
public class ConverterAgentTest {

    // ------------------------------------------------------------------
    // Functional interface contract: custom implementations
    // ------------------------------------------------------------------

    @Test
    public void testCustomImplementationReturnsConvertedValue() throws Exception {
        Converter<Integer, Exception> lengthConverter = new Converter<Integer, Exception>() {
            @Override
            public Integer apply(String string) throws Exception {
                return string.length();
            }
        };

        Integer result = lengthConverter.apply("hello");

        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void testCustomImplementationPropagatesDeclaredException() {
        Converter<Integer, ParseException> throwing = new Converter<Integer, ParseException>() {
            @Override
            public Integer apply(String string) throws ParseException {
                throw new ParseException("boom", 0);
            }
        };

        ParseException thrown = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                throwing.apply("anything");
            }
        });
        assertEquals("boom", thrown.getMessage());
    }

    // ------------------------------------------------------------------
    // DEFAULT: "The default converter does nothing."
    // ------------------------------------------------------------------

    @Test
    public void testDefaultFieldIsNotNull() {
        assertNotNull(Converter.DEFAULT);
    }

    @Test
    public void testDefaultDoesNothingReturnsInputUnchanged() throws Exception {
        Converter<?, RuntimeException> converter = Converter.DEFAULT;

        Object result = converter.apply("unchanged-value");

        assertEquals("unchanged-value", result);
    }

    @Test
    public void testDefaultWithNullReturnsNull() throws Exception {
        Converter<?, RuntimeException> converter = Converter.DEFAULT;

        Object result = converter.apply(null);

        assertNull(result);
    }

    // ------------------------------------------------------------------
    // CLASS: "Converts a String to a Class. Calls Class.forName(String)."
    // ------------------------------------------------------------------

    @Test
    public void testClassConverterResolvesKnownClass() throws Exception {
        Class<?> result = Converter.CLASS.apply("java.lang.String");

        assertEquals(String.class, result);
    }

    @Test
    public void testClassConverterThrowsOnUnknownClass() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.Class.Anywhere");
            }
        });
    }

    // ------------------------------------------------------------------
    // FILE: "Converts a String to a File. Calls File(String)."
    // ------------------------------------------------------------------

    @Test
    public void testFileConverterCreatesExpectedFile() throws Exception {
        File result = Converter.FILE.apply("test.txt");

        assertEquals(new File("test.txt"), result);
    }

    @Test
    public void testFileConverterThrowsNullPointerExceptionOnNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // PATH: "Converts a String to a Path. Calls Paths.get(String, String...)."
    // ------------------------------------------------------------------

    @Test
    public void testPathConverterCreatesExpectedPath() throws Exception {
        Path result = Converter.PATH.apply("a/b/c");

        assertEquals(Paths.get("a/b/c"), result);
    }

    @Test
    public void testPathConverterThrowsOnInvalidPath() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("a\u0000b");
            }
        });
    }

    // ------------------------------------------------------------------
    // NUMBER: "Converts a String to a Number. Converts to a Double if a
    // decimal point ('.') is in the string or a Long otherwise."
    // ------------------------------------------------------------------

    @Test
    public void testNumberConverterReturnsLongWithoutDecimalPoint() throws Exception {
        Number result = Converter.NUMBER.apply("42");

        assertTrue(result instanceof Long);
        assertEquals(42L, result.longValue());
    }

    @Test
    public void testNumberConverterReturnsDoubleWithDecimalPoint() throws Exception {
        Number result = Converter.NUMBER.apply("3.14");

        assertTrue(result instanceof Double);
        assertEquals(3.14d, result.doubleValue(), 0.0001d);
    }

    @Test
    public void testNumberConverterThrowsOnInvalidNumber() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    // ------------------------------------------------------------------
    // OBJECT: "Converts a class name to an instance of the class. Uses the
    // Class converter to find the class and then call the default
    // constructor."
    // ------------------------------------------------------------------

    @Test
    public void testObjectConverterInstantiatesClassWithDefaultConstructor() throws Exception {
        Object result = Converter.OBJECT.apply("java.lang.Object");

        assertNotNull(result);
        assertEquals(Object.class, result.getClass());
    }

    @Test
    public void testObjectConverterThrowsOnUnknownClass() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.Class.Anywhere");
            }
        });
    }

    @Test
    public void testObjectConverterThrowsWhenNoDefaultConstructor() {
        // java.lang.Integer has no public no-arg constructor.
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("java.lang.Integer");
            }
        });
    }

    // ------------------------------------------------------------------
    // URL: "Converts a String to a URL. Calls URL(String)."
    // ------------------------------------------------------------------

    @Test
    public void testUrlConverterCreatesExpectedUrl() throws Exception {
        URL result = Converter.URL.apply("http://example.com");

        assertEquals(new URL("http://example.com"), result);
    }

    @Test
    public void testUrlConverterThrowsOnMalformedUrl() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    // ------------------------------------------------------------------
    // DATE: "Converts a String to a Date using the format string Form
    // 'EEE MMM dd HH:mm:ss zzz yyyy'."
    // ------------------------------------------------------------------

    @Test
    public void testDateConverterParsesExpectedFormat() throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
        Date expected = format.parse("Wed Jul 04 12:08:56 GMT 2018");
        String input = format.format(expected);

        Date result = Converter.DATE.apply(input);

        assertEquals(expected.getTime(), result.getTime());
    }

    @Test
    public void testDateConverterThrowsOnInvalidFormat() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date at all");
            }
        });
    }

    // ------------------------------------------------------------------
    // Sanity: every documented static field is present and distinct.
    // ------------------------------------------------------------------

    @Test
    public void testAllDocumentedStaticFieldsArePresentAndNonNull() {
        assertNotNull(Converter.DEFAULT);
        assertNotNull(Converter.CLASS);
        assertNotNull(Converter.DATE);
        assertNotNull(Converter.FILE);
        assertNotNull(Converter.NUMBER);
        assertNotNull(Converter.OBJECT);
        assertNotNull(Converter.PATH);
        assertNotNull(Converter.URL);
    }
}
