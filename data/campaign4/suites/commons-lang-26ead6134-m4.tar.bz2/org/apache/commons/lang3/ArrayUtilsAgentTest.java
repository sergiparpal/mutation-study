/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));

        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.getLength("not an array"));
    }

    @Test
    void testGet() {
        final String[] array = { "a", "b", "c" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertEquals("c", ArrayUtils.get(array, 2));
        assertNull(ArrayUtils.get(array, 3));
        assertNull(ArrayUtils.get(array, -1));
        assertNull(ArrayUtils.get((String[]) null, 0));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("a", ArrayUtils.get(array, 0, "default"));
    }

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((Object[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new Object[] { "a" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] { "a" }, -1));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] { "a" }, 1));
    }

    @Test
    void testContainsAndContainsAny() {
        final int[] intArray = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(intArray, 2));
        assertFalse(ArrayUtils.contains(intArray, 4));
        assertFalse(ArrayUtils.contains((int[]) null, 2));

        final Object[] objArray = { "a", "b", null };
        assertTrue(ArrayUtils.contains(objArray, "a"));
        assertTrue(ArrayUtils.contains(objArray, null));
        assertFalse(ArrayUtils.contains(objArray, "z"));

        assertTrue(ArrayUtils.containsAny(intArray, 9, 3));
        assertFalse(ArrayUtils.containsAny(intArray, 9, 10));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        final int[] array = { 1, 2, 3, 2, 1 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));

        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 3, 2, 1 };
        final BitSet bits = ArrayUtils.indexesOf(array, 2);
        assertEquals(2, bits.cardinality());
        assertTrue(bits.get(1));
        assertTrue(bits.get(3));

        final BitSet none = ArrayUtils.indexesOf(array, 42);
        assertTrue(none.isEmpty());

        final BitSet nullInput = ArrayUtils.indexesOf((int[]) null, 1);
        assertTrue(nullInput.isEmpty());
    }

    @Test
    void testAdd() {
        final int[] result = ArrayUtils.add(new int[] { 1, 2 }, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);

        final int[] fromNull = ArrayUtils.add((int[]) null, 1);
        assertArrayEquals(new int[] { 1 }, fromNull);

        final String[] inserted = ArrayUtils.add(new String[] { "a", "c" }, 1, "b");
        assertArrayEquals(new String[] { "a", "b", "c" }, inserted);

        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(new String[] { "a" }, 5, "b"));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(new String[] { "a" }, -1, "b"));
    }

    @Test
    void testAddAll() {
        final int[] combined = ArrayUtils.addAll(new int[] { 1, 2 }, 3, 4);
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, combined);
        assertArrayEquals(new int[] { 3, 4 }, ArrayUtils.addAll((int[]) null, 3, 4));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll(new int[] { 1, 2 }, (int[]) null));

        final String[] strCombined = ArrayUtils.addAll(new String[] { "a" }, "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, strCombined);
    }

    @Test
    void testAddFirst() {
        final int[] result = ArrayUtils.addFirst(new int[] { 2, 3 }, 1);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        assertArrayEquals(new int[] { 1 }, ArrayUtils.addFirst((int[]) null, 1));
    }

    @Test
    void testInsert() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 9, 2, 3 }, ArrayUtils.insert(1, array, 9));
        assertArrayEquals(new int[] { 1, 2, 3 }, array, "original array must be unmodified");
        assertNull(ArrayUtils.insert(0, (int[]) null, 9));

        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(-1, array, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(4, array, 9));

        final String[] strArray = { "a", "b" };
        assertArrayEquals(new String[] { "a", "b" }, ArrayUtils.insert(1, strArray));
    }

    @Test
    void testRemove() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 3 }, ArrayUtils.remove(array, 1));
        assertArrayEquals(new int[] { 1, 2, 3 }, array, "original array must be unmodified");

        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(array, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(array, 3));

        final String[] strArray = { "a", "b", "c" };
        assertArrayEquals(new String[] { "a", "c" }, ArrayUtils.remove(strArray, 1));
    }

    @Test
    void testRemoveAll() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 1, 3, 5 }, ArrayUtils.removeAll(array, 1, 3));
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, ArrayUtils.removeAll(array));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.removeAll(array, 10));
    }

    @Test
    void testRemoveElement() {
        final int[] array = { 1, 2, 3, 2 };
        assertArrayEquals(new int[] { 1, 3, 2 }, ArrayUtils.removeElement(array, 2));
        assertArrayEquals(new int[] { 1, 2, 3, 2 }, ArrayUtils.removeElement(array, 9), "no match leaves a copy");

        final String[] strArray = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b", "a" }, ArrayUtils.removeElement(strArray, "a"));
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] array = { 1, 2, 3, 2, 1 };
        assertArrayEquals(new int[] { 1, 3, 1 }, ArrayUtils.removeAllOccurrences(array, 2));
        assertArrayEquals(new int[] { 2, 3, 2 }, ArrayUtils.removeAllOccurrences(array, 1));
    }

    @Test
    void testReverse() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] partial = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(partial, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, partial);

        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testShift() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] { 5, 1, 2, 3, 4 }, array);

        final int[] noop = { 1, 2, 3 };
        ArrayUtils.shift(noop, 0);
        assertArrayEquals(new int[] { 1, 2, 3 }, noop);

        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] outOfBounds = { 1, 2, 3 };
        ArrayUtils.swap(outOfBounds, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, outOfBounds, "no-op for an out-of-range offset");

        final int[] negative = { 1, 2, 3 };
        ArrayUtils.swap(negative, -1, 1);
        assertArrayEquals(new int[] { 2, 1, 3 }, negative, "negative index is promoted to 0");

        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testSubarray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1), "end before start yields empty");
        assertArrayEquals(array, ArrayUtils.subarray(array, -2, 10), "out-of-range bounds are clamped");
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    void testIsSameLengthAndIsSameType() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));

        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(null, new int[0]));
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[0]));
    }

    @Test
    void testCloneAndConcat() {
        final int[] array = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertFalse(array == cloned, "clone must return a different array instance");
        assertNull(ArrayUtils.clone((int[]) null));

        final int[] concatenated = ArrayUtils.concat(new int[] { 1, 2 }, new int[] { 3 }, new int[] { 4, 5 });
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, concatenated);
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0][]));
    }

    @Test
    void testHashCodeAndIsEquals() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        assertEquals(ArrayUtils.hashCode(new int[] { 1, 2, 3 }), ArrayUtils.hashCode(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.hashCode(new int[] { 1, 2, 3 }) == ArrayUtils.hashCode(new int[] { 1, 2, 4 }));

        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertTrue(ArrayUtils.startsWith((byte[]) null, (byte[]) null));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, null));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, new byte[] { 1, 2 }), "expected longer than data");
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2 }, new byte[] { 1, 2 }), "equal arrays");
    }

    @Test
    void testToObjectAndToPrimitive() {
        final Integer[] boxed = ArrayUtils.toObject(new int[] { 1, 2, 3 });
        assertArrayEquals(new Integer[] { 1, 2, 3 }, boxed);
        assertNull(ArrayUtils.toObject((int[]) null));

        final int[] primitive = ArrayUtils.toPrimitive(new Integer[] { 1, 2, 3 });
        assertArrayEquals(new int[] { 1, 2, 3 }, primitive);
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
        assertThrows(NullPointerException.class, () -> ArrayUtils.toPrimitive(new Integer[] { 1, null }));

        final int[] withDefault = ArrayUtils.toPrimitive(new Integer[] { 1, null }, -1);
        assertArrayEquals(new int[] { 1, -1 }, withDefault);
    }

    @Test
    void testToStringAndToStringArray() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] { 1, 2, 3 }));

        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", 1, null });
        assertArrayEquals(new String[] { "a", "1", "null" }, result);
        assertNull(ArrayUtils.toStringArray(null));

        final String[] withDefault = ArrayUtils.toStringArray(new Object[] { "a", null }, "N/A");
        assertArrayEquals(new String[] { "a", "N/A" }, withDefault);
    }

    @Test
    void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] { { "k1", "v1" }, { "k2", "v2" } });
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));
        assertNull(ArrayUtils.toMap(null));

        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] { "not an entry" }));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] { new String[] { "onlyKey" } }));
    }

    @Test
    void testNullToEmpty() {
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        assertArrayEquals(new int[] { 1 }, ArrayUtils.nullToEmpty(new int[] { 1 }));
        assertArrayEquals(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        assertSame(ArrayUtils.EMPTY_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Object[]) null));
    }

    @Test
    void testGetComponentTypeAndNewInstance() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertNull(ArrayUtils.getComponentType(null));

        final String[] created = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, created.length);
        assertEquals(String.class, created.getClass().getComponentType());
    }

    @Test
    void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[0]));
        assertEquals(2, ArrayUtils.getDimensions(new int[0][0]));
    }
}
