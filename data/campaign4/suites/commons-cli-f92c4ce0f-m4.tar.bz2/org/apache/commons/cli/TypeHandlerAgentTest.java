/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link TypeHandler}.
 */
public class TypeHandlerAgentTest {

    // A class without a default (no-arg) constructor, used to exercise error paths.
    public static class NoDefaultConstructor {

        public NoDefaultConstructor(final int i) {
        }
    }

    @Test
    void testCreateClassValid() throws Exception {
        final Class<?> clazz = TypeHandler.createClass(this.getClass().getName());
        assertEquals(this.getClass(), clazz);
    }

    @Test
    void testCreateClassInvalid() {
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createClass("org.apache.commons.cli.NoSuchClassXYZ");
            }
        });
        assertNotNull(e.getCause());
        assertTrue(e.getCause() instanceof ClassNotFoundException);
    }

    @Test
    void testCreateDateValid() throws Exception {
        final Date expected = new Date(1023400137000L);
        final DateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        final String formatted = dateFormat.format(expected);
        final Date actual = TypeHandler.createDate(formatted);
        assertEquals(expected, actual);
    }

    @Test
    void testCreateDateInvalid() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createDate("not-a-date");
            }
        });
        assertNotNull(e.getCause());
        assertTrue(e.getCause() instanceof ParseException);
    }

    @Test
    void testCreateDefaultMap() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        assertEquals(17, map.size());
        assertSame(Converter.CLASS, map.get(Class.class));
        assertSame(Converter.DATE, map.get(Date.class));
        assertSame(Converter.FILE, map.get(File.class));
        assertSame(Converter.NUMBER, map.get(Number.class));
        assertSame(Converter.URL, map.get(URL.class));
        assertSame(Converter.OBJECT, map.get(Object.class));
        assertTrue(map.containsKey(Path.class));
        assertTrue(map.containsKey(FileInputStream.class));
        assertTrue(map.containsKey(Long.class));
        assertTrue(map.containsKey(Integer.class));
        assertTrue(map.containsKey(Short.class));
        assertTrue(map.containsKey(Byte.class));
        assertTrue(map.containsKey(Character.class));
        assertTrue(map.containsKey(Double.class));
        assertTrue(map.containsKey(Float.class));
        assertTrue(map.containsKey(BigInteger.class));
        assertTrue(map.containsKey(BigDecimal.class));
        // The returned map is modifiable and independent across calls.
        map.remove(Class.class);
        assertEquals(16, map.size());
        final Map<Class<?>, Converter<?, ? extends Throwable>> map2 = TypeHandler.createDefaultMap();
        assertEquals(17, map2.size());
    }

    @Test
    void testCreateFileValid() {
        final File file = TypeHandler.createFile("some-file-name.txt");
        assertNotNull(file);
        assertEquals("some-file-name.txt", file.getName());
    }

    @Test
    void testCreateFileNullThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createFile(null);
            }
        });
    }

    @Test
    void testCreateFilesAlwaysThrowsUnsupported() {
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createFiles("whatever");
            }
        });
    }

    @Test
    void testCreateNumberLong() throws Exception {
        final Number n = TypeHandler.createNumber("123");
        assertEquals(Long.valueOf(123), n);
    }

    @Test
    void testCreateNumberDouble() throws Exception {
        final Number n = TypeHandler.createNumber("12.3");
        assertEquals(Double.valueOf(12.3), n);
    }

    @Test
    void testCreateNumberInvalid() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createNumber("not-a-number");
            }
        });
    }

    @Test
    void testCreateObjectValid() throws Exception {
        final Object o = TypeHandler.createObject(Object.class.getName());
        assertNotNull(o);
        assertEquals(Object.class, o.getClass());
    }

    @Test
    void testCreateObjectNoDefaultConstructor() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createObject(NoDefaultConstructor.class.getName());
            }
        });
    }

    @Test
    void testCreateObjectClassNotFound() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createObject("no.such.ClassXYZ");
            }
        });
    }

    @Test
    void testCreateUrlValid() throws Exception {
        final URL url = TypeHandler.createURL("https://apache.org");
        assertEquals(new URL("https://apache.org"), url);
    }

    @Test
    void testCreateUrlInvalid() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createURL("not a url");
            }
        });
    }

    @Test
    void testCreateValueWithClassForUnregisteredTypeUsesDefaultConverter() throws Exception {
        // String is not registered, so the DEFAULT (identity) converter is used.
        final String s = TypeHandler.createValue("hello", String.class);
        assertEquals("hello", s);
    }

    @Test
    void testCreateValueDeprecatedObjectOverloadValid() throws Exception {
        final Object value = TypeHandler.createValue("123", (Object) Long.class);
        assertEquals(Long.valueOf(123), value);
    }

    @Test
    void testCreateValueDeprecatedObjectOverloadNotAClassThrowsClassCast() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createValue("123", "not a class");
            }
        });
    }

    @Test
    void testOpenFileValid() throws Exception {
        final URL url = this.getClass().getClassLoader().getResource("org/apache/commons/cli/existing-readable.file");
        assertNotNull(url);
        final String fileName = url.toString().substring("file:".length());
        final FileInputStream fis = TypeHandler.openFile(fileName);
        try {
            assertNotNull(fis);
            assertTrue(fis.available() >= 0);
        } finally {
            fis.close();
        }
    }

    @Test
    void testOpenFileMissingThrows() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.openFile("/no/such/path/definitely-missing-" + System.nanoTime());
            }
        });
    }

    @Test
    void testGetDefaultIsSingleton() {
        final TypeHandler first = TypeHandler.getDefault();
        final TypeHandler second = TypeHandler.getDefault();
        assertNotNull(first);
        assertSame(first, second);
    }

    @Test
    void testDefaultConstructorUsesDefaultMapBehavior() throws Exception {
        final TypeHandler handler = new TypeHandler();
        assertNotSame(TypeHandler.getDefault(), handler);
        assertSame(Converter.NUMBER, handler.getConverter(Number.class));
        final Number n = handler.getConverter(Number.class).apply("42");
        assertEquals(Long.valueOf(42), n);
    }

    @Test
    void testConstructorWithNullMapThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new TypeHandler(null);
            }
        });
    }

    @Test
    void testConstructorWithCustomMap() throws Exception {
        final Map<Class<?>, Converter<?, ? extends Throwable>> customMap = new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        final Converter<Integer, RuntimeException> doubler = new Converter<Integer, RuntimeException>() {
            @Override
            public Integer apply(final String string) {
                return Integer.parseInt(string) * 2;
            }
        };
        customMap.put(Integer.class, doubler);
        final TypeHandler handler = new TypeHandler(customMap);
        final Converter<Integer, ?> converter = handler.getConverter(Integer.class);
        assertSame(doubler, converter);
        assertEquals(Integer.valueOf(20), converter.apply("10"));
    }

    @Test
    void testGetConverterReturnsDefaultForUnregisteredClass() {
        final TypeHandler handler = new TypeHandler(new HashMap<Class<?>, Converter<?, ? extends Throwable>>());
        final Converter<String, ?> converter = handler.getConverter(String.class);
        assertSame(Converter.DEFAULT, converter);
    }

    @Test
    void testGetConverterReturnsRegisteredForKnownClass() {
        final TypeHandler handler = TypeHandler.getDefault();
        assertSame(Converter.FILE, handler.getConverter(File.class));
        assertFalse(handler.getConverter(File.class) == Converter.DEFAULT);
    }
}
