package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FractionAgentTest {

    // ---- Constants ----

    @Test
    public void testConstantZero() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
    }

    @Test
    public void testConstantOne() {
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
    }

    @Test
    public void testConstantOneHalf() {
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
    }

    @Test
    public void testConstantOneThird() {
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
    }

    @Test
    public void testConstantTwoThirds() {
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
    }

    @Test
    public void testConstantOneQuarter() {
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
    }

    @Test
    public void testConstantTwoQuarters() {
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantThreeQuarters() {
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantOneFifth() {
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
    }

    @Test
    public void testConstantTwoFifths() {
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantThreeFifths() {
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantFourFifths() {
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ---- getFraction(double) ----

    @Test
    public void testGetFractionDoubleHalf() {
        Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleWhole() {
        Fraction f = Fraction.getFraction(2.0d);
        assertEquals(2, f.intValue());
        assertEquals(2.0d, f.doubleValue(), 0.0d);
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1.0e20d);
            }
        });
    }

    // ---- getFraction(int, int) ----

    @Test
    public void testGetFractionIntIntBasic() {
        Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        Fraction f = Fraction.getFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntDoubleNegativeCancels() {
        Fraction f = Fraction.getFraction(-1, -2);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMinValueNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // ---- getFraction(int, int, int) ----

    @Test
    public void testGetFractionWholeNumeratorDenominatorBasic() {
        Fraction f = Fraction.getFraction(1, 1, 2);
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorNegativeWhole() {
        Fraction f = Fraction.getFraction(-1, 1, 2);
        assertEquals(-3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, -2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 1);
            }
        });
    }

    // ---- getFraction(String) ----

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringDouble() {
        Fraction f = Fraction.getFraction("1.5");
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixed() {
        Fraction f = Fraction.getFraction("1 1/2");
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringSimpleFraction() {
        Fraction f = Fraction.getFraction("3/4");
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrowsWithCause() {
        NumberFormatException ex = assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1/0");
            }
        });
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionStringOutOfIntRangeThrowsWithCause() {
        NumberFormatException ex = assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("9999999999.5");
            }
        });
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionStringMixedNumberOverflowThrowsWithCause() {
        NumberFormatException ex = assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("2147483647 1/2");
            }
        });
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionStringInvalidFormatThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("not a fraction");
            }
        });
    }

    // ---- getReducedFraction(int, int) ----

    @Test
    public void testGetReducedFractionBasic() {
        Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionNegativeSignOnNumerator() {
        Fraction f = Fraction.getReducedFraction(4, -8);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ---- abs() ----

    @Test
    public void testAbsOnPositiveReturnsSameInstance() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.abs());
    }

    @Test
    public void testAbsOnNegativeNotReduced() {
        Fraction f = Fraction.getFraction(-2, 4).abs();
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ---- add(Fraction) ----

    @Test
    public void testAddReducesResult() {
        Fraction f = Fraction.ONE_HALF.add(Fraction.ONE_HALF);
        assertEquals(1, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testAddDifferentDenominators() {
        Fraction f = Fraction.ONE_HALF.add(Fraction.ONE_THIRD);
        assertEquals(5, f.getNumerator());
        assertEquals(6, f.getDenominator());
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.add(Fraction.ONE);
            }
        });
    }

    // ---- compareTo(Fraction) ----

    @Test
    public void testCompareToEqualValueDifferentForm() {
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.TWO_QUARTERS));
    }

    @Test
    public void testCompareToLess() {
        assertTrue(Fraction.ONE_THIRD.compareTo(Fraction.ONE_HALF) < 0);
    }

    @Test
    public void testCompareToGreater() {
        assertTrue(Fraction.ONE_HALF.compareTo(Fraction.ONE_THIRD) > 0);
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.compareTo(null);
            }
        });
    }

    @Test
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void testCompareToWrongTypeThrowsClassCastException() {
        final Comparable raw = Fraction.ONE_HALF;
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                raw.compareTo("not a fraction");
            }
        });
    }

    // ---- divideBy(Fraction) ----

    @Test
    public void testDivideByBasic() {
        Fraction f = Fraction.ONE_HALF.divideBy(Fraction.ONE_QUARTER);
        assertEquals(2, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.divideBy(null);
            }
        });
    }

    @Test
    public void testDivideByOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.divideBy(Fraction.ONE_HALF);
            }
        });
    }

    // ---- doubleValue/floatValue/intValue/longValue ----

    @Test
    public void testDoubleValue() {
        assertEquals(1.75d, Fraction.getFraction(7, 4).doubleValue(), 0.0d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(1.75f, Fraction.getFraction(7, 4).floatValue(), 0.0f);
    }

    @Test
    public void testIntValueTruncatesTowardZeroPositive() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
    }

    @Test
    public void testIntValueTruncatesTowardZeroNegative() {
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
    }

    // ---- equals(Object) ----

    @Test
    public void testEqualsSameValueSameForm() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
    }

    @Test
    public void testEqualsDifferentFormNotEqual() {
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(Fraction.ONE_HALF.equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        assertFalse(Fraction.ONE_HALF.equals("1/2"));
    }

    // ---- getDenominator()/getNumerator() ----

    @Test
    public void testGetNumeratorAndDenominatorImproperFraction() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ---- getProperNumerator()/getProperWhole() ----

    @Test
    public void testGetProperNumeratorAndWholePositive() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAndWholeZero() {
        assertEquals(0, Fraction.ZERO.getProperWhole());
        assertEquals(0, Fraction.ZERO.getProperNumerator());
    }

    // ---- hashCode() ----

    @Test
    public void testHashCodeConsistentWithEquals() {
        Fraction a = Fraction.getFraction(3, 4);
        Fraction b = Fraction.getFraction(3, 4);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    // ---- invert() ----

    @Test
    public void testInvertBasicNotReduced() {
        Fraction f = Fraction.getFraction(2, 4).invert();
        assertEquals(4, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    // ---- multiplyBy(Fraction) ----

    @Test
    public void testMultiplyByReducesResult() {
        Fraction f = Fraction.ONE_HALF.multiplyBy(Fraction.TWO_THIRDS);
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.multiplyBy(Fraction.getFraction(2, 1));
            }
        });
    }

    // ---- negate() ----

    @Test
    public void testNegateBasicNotReduced() {
        Fraction f = Fraction.getFraction(2, 4).negate();
        assertEquals(-2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testNegateOfNegativeGivesPositive() {
        Fraction f = Fraction.getFraction(-1, 2).negate();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    // ---- pow(int) ----

    @Test
    public void testPowZeroGivesOneEvenForZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
        assertSame(Fraction.ONE, Fraction.ONE_HALF.pow(0));
    }

    @Test
    public void testPowOneGivesThis() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.pow(1));
    }

    @Test
    public void testPowGreaterThanOneIsReduced() {
        Fraction f = Fraction.getFraction(2, 4).pow(2);
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testPowOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                big.pow(2);
            }
        });
    }

    // ---- reduce() ----

    @Test
    public void testReduceSimplifies() {
        Fraction f = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        Fraction f = Fraction.getFraction(3, 5);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceZero() {
        Fraction f = Fraction.ZERO.reduce();
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    // ---- subtract(Fraction) ----

    @Test
    public void testSubtractReducesResult() {
        Fraction f = Fraction.TWO_THIRDS.subtract(Fraction.ONE_THIRD);
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.subtract(null);
            }
        });
    }

    @Test
    public void testSubtractOverflowThrows() {
        final Fraction small = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                small.subtract(Fraction.ONE);
            }
        });
    }

    // ---- toProperString() ----

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringZeroNumeratorOmitsFraction() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperStringZeroWholeOmitsWhole() {
        assertEquals("1/2", Fraction.ONE_HALF.toProperString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    // ---- toString() ----

    @Test
    public void testToStringAlwaysNumeratorOverDenominator() {
        assertEquals("7/4", Fraction.getFraction(7, 4).toString());
    }

    @Test
    public void testToStringNegative() {
        assertEquals("-7/4", Fraction.getFraction(-7, 4).toString());
    }

    @Test
    public void testToStringZero() {
        assertEquals("0/1", Fraction.ZERO.toString());
    }

    // ---- misc: Number subclass / Comparable ----

    @Test
    public void testIsNumberAndComparable() {
        Object f = Fraction.ONE_HALF;
        assertTrue(f instanceof Number);
        assertTrue(f instanceof Comparable);
        assertNotNull(f.toString());
    }
}
