/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Iterator;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum AgentHeader {
        Col1, Col2, Col3
    }

    @Test
    void testNewFormatBasicDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testMySqlFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertNull(format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testValueOfPredefined() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("DoesNotExist");
            }
        });
    }

    @Test
    void testBuilderCreateDefaults() {
        final Builder builder = Builder.create();
        final CSVFormat format = builder.get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    void testBuilderCreateFromFormatCopiesValues() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter('|').setNullString("NULL").get();
        final Builder builder = Builder.create(source);
        final CSVFormat copy = builder.get();
        assertEquals(source, copy);
        assertNotSame(source, copy);
    }

    @Test
    void testBuildVsGetReturnDistinctInstances() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat a = builder.build();
        final CSVFormat b = builder.get();
        assertEquals(a, b);
        assertNotSame(a, b);
    }

    @Test
    void testBuilderReturnsNewIndependentInstance() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", changed.getDelimiterString());
        assertNotEquals(original, changed);
    }

    @Test
    void testSetDelimiterCharLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(Constants.CR).get();
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(Constants.LF).get();
            }
        });
    }

    @Test
    void testSetDelimiterEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("").get();
            }
        });
    }

    @Test
    void testSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker(Constants.LF).get();
            }
        });
    }

    @Test
    void testSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape(Constants.CR).get();
            }
        });
    }

    @Test
    void testSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote(Constants.LF).get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setQuote('!').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setEscape('!').get();
            }
        });
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setCommentMarker('!').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderNamesThrowsByDefaultModeAllowAllAllowsThem() {
        final CSVFormat allowAll = CSVFormat.DEFAULT.builder().setHeader("A", "B", "A").get();
        assertArrayEquals(new String[] { "A", "B", "A" }, allowAll.getHeader());
    }

    @Test
    void testValidateDuplicateHeaderNamesThrowsWhenDisallowed() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("A", "B", "A").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
            }
        });
    }

    @Test
    void testValidateDuplicateEmptyHeaderNamesAllowedWhenModeAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] { "A", "", "" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateNonEmptyHeaderNamesDisallowedWhenModeAllowEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
            }
        });
    }

    @Test
    void testSetDuplicateHeaderModeNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(null);
            }
        });
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    void testSetHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(AgentHeader.class).get();
        assertArrayEquals(new String[] { "Col1", "Col2", "Col3" }, format.getHeader());
    }

    @Test
    void testSetHeaderEnumNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = new StubResultSetMetaData(new String[] { "ID", "NAME" });
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(metaData).get();
        assertArrayEquals(new String[] { "ID", "NAME" }, format.getHeader());
    }

    @Test
    void testSetHeaderResultSet() throws SQLException {
        final ResultSetMetaData metaData = new StubResultSetMetaData(new String[] { "ID", "NAME" });
        final ResultSet resultSet = new StubResultSet(metaData);
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(resultSet).get();
        assertArrayEquals(new String[] { "ID", "NAME" }, format.getHeader());
    }

    @Test
    void testGetHeaderCommentsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("Line1", "Line2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        assertEquals("Line1", format.getHeaderComments()[0]);
    }

    @Test
    void testSetHeaderCommentsObjectsConvertsToString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(new Object[] { Integer.valueOf(1), null, "x" }).get();
        assertArrayEquals(new String[] { "1", null, "x" }, format.getHeaderComments());
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat c = CSVFormat.DEFAULT.builder().setDelimiter('|').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
        assertEquals(a, a);
    }

    @Test
    void testGetDelimiterDeprecatedReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals('|', format.getDelimiter());
        assertEquals("||", format.getDelimiterString());
    }

    @Test
    void testMaxRowsDefaultIsZeroAndUnlimited() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        assertTrue(CSVFormat.DEFAULT.useRow(1000000L));
    }

    @Test
    void testMaxRowsPositiveLimitsRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2L).get();
        assertEquals(2L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1L));
        assertTrue(format.useRow(2L));
        assertFalse(format.useRow(3L));
    }

    @Test
    void testMaxRowsNegativeMeansUnlimited() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(-5L).get();
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(999L));
    }

    @Test
    void testFormatValues() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("a,b,c", format.format("a", "b", "c"));
    }

    @Test
    void testFormatValuesWithQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("a,\"b,c\",d", format.format("a", "b,c", "d"));
    }

    @Test
    void testPrintValueWritesDelimiterBetweenValues() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("first", writer, true);
        CSVFormat.DEFAULT.print("second", writer, false);
        assertEquals("first,second", writer.toString());
    }

    @Test
    void testPrintNullUsesEmptyStringWhenNoNullStringSet() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullUsesNullStringWhenSet() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintlnWritesRecordSeparatorOnly() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintRecordAppendsSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testParseReturnsParserThatYieldsRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n"));
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            final CSVRecord record = it.next();
            assertEquals(3, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    void testPrintCreatesPrinterThatWrites() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        try {
            printer.printRecord("x", "y");
        } finally {
            printer.close();
        }
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testToStringContainsDelimiterAndSkipHeaderRecord() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringIncludesOptionalAttributesWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setCommentMarker('#').setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final String str = format.toString();
        assertTrue(str.contains("Escape=<\\>"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
        assertTrue(str.contains("QuoteMode=<ALL>"));
    }

    @Test
    void testPredefinedEnumGetFormat() {
        for (final CSVFormat.Predefined predefined : CSVFormat.Predefined.values()) {
            assertNotNull(predefined.getFormat());
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedWithDelimiterCreatesNewInstance() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
        assertNotSame(CSVFormat.DEFAULT, format);
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedWithHeaderAndSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true);
        assertArrayEquals(new String[] { "A", "B" }, format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedAllowDuplicateHeaderNames() {
        final CSVFormat allow = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true);
        assertTrue(allow.getAllowDuplicateHeaderNames());
        final CSVFormat disallow = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    /**
     * Minimal stub for header extraction tests; throws on anything beyond what CSVFormat.Builder uses.
     */
    private static final class StubResultSetMetaData implements ResultSetMetaData {
        private final String[] labels;

        StubResultSetMetaData(final String[] labels) {
            this.labels = labels;
        }

        @Override
        public int getColumnCount() {
            return labels.length;
        }

        @Override
        public String getColumnLabel(final int column) {
            return labels[column - 1];
        }

        @Override
        public <T> T unwrap(final Class<T> iface) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) {
            return false;
        }

        @Override
        public boolean isAutoIncrement(final int column) {
            return false;
        }

        @Override
        public boolean isCaseSensitive(final int column) {
            return false;
        }

        @Override
        public boolean isSearchable(final int column) {
            return false;
        }

        @Override
        public boolean isCurrency(final int column) {
            return false;
        }

        @Override
        public int isNullable(final int column) {
            return 0;
        }

        @Override
        public boolean isSigned(final int column) {
            return false;
        }

        @Override
        public int getColumnDisplaySize(final int column) {
            return 0;
        }

        @Override
        public String getColumnName(final int column) {
            return labels[column - 1];
        }

        @Override
        public String getSchemaName(final int column) {
            return "";
        }

        @Override
        public int getPrecision(final int column) {
            return 0;
        }

        @Override
        public int getScale(final int column) {
            return 0;
        }

        @Override
        public String getTableName(final int column) {
            return "";
        }

        @Override
        public String getCatalogName(final int column) {
            return "";
        }

        @Override
        public int getColumnType(final int column) {
            return 0;
        }

        @Override
        public String getColumnTypeName(final int column) {
            return "";
        }

        @Override
        public boolean isReadOnly(final int column) {
            return false;
        }

        @Override
        public boolean isWritable(final int column) {
            return false;
        }

        @Override
        public boolean isDefinitelyWritable(final int column) {
            return false;
        }

        @Override
        public String getColumnClassName(final int column) {
            return Object.class.getName();
        }
    }

    /**
     * Minimal stub exposing only getMetaData(), as used by CSVFormat.Builder.setHeader(ResultSet).
     */
    private static final class StubResultSet implements ResultSet {
        private final ResultSetMetaData metaData;

        StubResultSet(final ResultSetMetaData metaData) {
            this.metaData = metaData;
        }

        @Override
        public ResultSetMetaData getMetaData() {
            return metaData;
        }

        @Override
        public <T> T unwrap(final Class<T> iface) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) {
            return false;
        }

        @Override
        public boolean next() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void close() {
            // no-op
        }

        @Override
        public boolean wasNull() {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getString(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean getBoolean(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public byte getByte(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public short getShort(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getInt(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public long getLong(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public float getFloat(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public double getDouble(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final int columnIndex, final int scale) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public byte[] getBytes(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Date getDate(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Time getTime(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Timestamp getTimestamp(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.InputStream getAsciiStream(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.InputStream getUnicodeStream(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.InputStream getBinaryStream(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.Reader getCharacterStream(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.Reader getCharacterStream(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getString(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean getBoolean(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public byte getByte(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public short getShort(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getInt(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public long getLong(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public float getFloat(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public double getDouble(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final String columnLabel, final int scale) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public byte[] getBytes(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Date getDate(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Time getTime(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Timestamp getTimestamp(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.InputStream getAsciiStream(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.InputStream getUnicodeStream(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.InputStream getBinaryStream(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getCursorName() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int findColumn(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object getObject(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object getObject(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.SQLWarning getWarnings() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clearWarnings() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isBeforeFirst() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isAfterLast() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isFirst() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isLast() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void beforeFirst() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void afterLast() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean first() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean last() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean absolute(final int row) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean relative(final int rows) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean previous() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setFetchDirection(final int direction) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getFetchDirection() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setFetchSize(final int rows) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getFetchSize() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getType() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getConcurrency() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean rowUpdated() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean rowInserted() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean rowDeleted() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNull(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBoolean(final int columnIndex, final boolean x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateByte(final int columnIndex, final byte x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateShort(final int columnIndex, final short x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateInt(final int columnIndex, final int x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateLong(final int columnIndex, final long x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateFloat(final int columnIndex, final float x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateDouble(final int columnIndex, final double x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBigDecimal(final int columnIndex, final java.math.BigDecimal x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateString(final int columnIndex, final String x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBytes(final int columnIndex, final byte[] x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateDate(final int columnIndex, final java.sql.Date x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateTime(final int columnIndex, final java.sql.Time x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateTimestamp(final int columnIndex, final java.sql.Timestamp x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateAsciiStream(final int columnIndex, final java.io.InputStream x, final int length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBinaryStream(final int columnIndex, final java.io.InputStream x, final int length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateCharacterStream(final int columnIndex, final java.io.Reader x, final int length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateObject(final int columnIndex, final Object x, final int scaleOrLength) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateObject(final int columnIndex, final Object x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNull(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBoolean(final String columnLabel, final boolean x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateByte(final String columnLabel, final byte x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateShort(final String columnLabel, final short x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateInt(final String columnLabel, final int x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateLong(final String columnLabel, final long x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateFloat(final String columnLabel, final float x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateDouble(final String columnLabel, final double x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBigDecimal(final String columnLabel, final java.math.BigDecimal x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateString(final String columnLabel, final String x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBytes(final String columnLabel, final byte[] x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateDate(final String columnLabel, final java.sql.Date x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateTime(final String columnLabel, final java.sql.Time x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateTimestamp(final String columnLabel, final java.sql.Timestamp x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateAsciiStream(final String columnLabel, final java.io.InputStream x, final int length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBinaryStream(final String columnLabel, final java.io.InputStream x, final int length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateCharacterStream(final String columnLabel, final java.io.Reader reader, final int length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateObject(final String columnLabel, final Object x, final int scaleOrLength) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateObject(final String columnLabel, final Object x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void insertRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void deleteRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void refreshRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void cancelRowUpdates() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void moveToInsertRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void moveToCurrentRow() {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Statement getStatement() {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object getObject(final int columnIndex, final java.util.Map<String, Class<?>> map) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Ref getRef(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Blob getBlob(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Clob getClob(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Array getArray(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object getObject(final String columnLabel, final java.util.Map<String, Class<?>> map) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Ref getRef(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Blob getBlob(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Clob getClob(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Array getArray(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Date getDate(final int columnIndex, final java.util.Calendar cal) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Date getDate(final String columnLabel, final java.util.Calendar cal) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Time getTime(final int columnIndex, final java.util.Calendar cal) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Time getTime(final String columnLabel, final java.util.Calendar cal) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Timestamp getTimestamp(final int columnIndex, final java.util.Calendar cal) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.Timestamp getTimestamp(final String columnLabel, final java.util.Calendar cal) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.net.URL getURL(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.net.URL getURL(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateRef(final int columnIndex, final java.sql.Ref x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateRef(final String columnLabel, final java.sql.Ref x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBlob(final int columnIndex, final java.sql.Blob x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBlob(final String columnLabel, final java.sql.Blob x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateClob(final int columnIndex, final java.sql.Clob x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateClob(final String columnLabel, final java.sql.Clob x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateArray(final int columnIndex, final java.sql.Array x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateArray(final String columnLabel, final java.sql.Array x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.RowId getRowId(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.RowId getRowId(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateRowId(final int columnIndex, final java.sql.RowId x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateRowId(final String columnLabel, final java.sql.RowId x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getHoldability() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isClosed() {
            return false;
        }

        @Override
        public void updateNString(final int columnIndex, final String nString) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNString(final String columnLabel, final String nString) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNClob(final int columnIndex, final java.sql.NClob nClob) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNClob(final String columnLabel, final java.sql.NClob nClob) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.NClob getNClob(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.NClob getNClob(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.SQLXML getSQLXML(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.sql.SQLXML getSQLXML(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateSQLXML(final int columnIndex, final java.sql.SQLXML xmlObject) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateSQLXML(final String columnLabel, final java.sql.SQLXML xmlObject) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getNString(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getNString(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.Reader getNCharacterStream(final int columnIndex) {
            throw new UnsupportedOperationException();
        }

        @Override
        public java.io.Reader getNCharacterStream(final String columnLabel) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNCharacterStream(final int columnIndex, final java.io.Reader x, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNCharacterStream(final String columnLabel, final java.io.Reader reader, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateAsciiStream(final int columnIndex, final java.io.InputStream x, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBinaryStream(final int columnIndex, final java.io.InputStream x, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateCharacterStream(final int columnIndex, final java.io.Reader x, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateAsciiStream(final String columnLabel, final java.io.InputStream x, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBinaryStream(final String columnLabel, final java.io.InputStream x, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateCharacterStream(final String columnLabel, final java.io.Reader reader, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBlob(final int columnIndex, final java.io.InputStream inputStream, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBlob(final String columnLabel, final java.io.InputStream inputStream, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateClob(final int columnIndex, final java.io.Reader reader, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateClob(final String columnLabel, final java.io.Reader reader, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNClob(final int columnIndex, final java.io.Reader reader, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNClob(final String columnLabel, final java.io.Reader reader, final long length) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNCharacterStream(final int columnIndex, final java.io.Reader x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNCharacterStream(final String columnLabel, final java.io.Reader reader) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateAsciiStream(final int columnIndex, final java.io.InputStream x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBinaryStream(final int columnIndex, final java.io.InputStream x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateCharacterStream(final int columnIndex, final java.io.Reader x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateAsciiStream(final String columnLabel, final java.io.InputStream x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBinaryStream(final String columnLabel, final java.io.InputStream x) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateCharacterStream(final String columnLabel, final java.io.Reader reader) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBlob(final int columnIndex, final java.io.InputStream inputStream) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateBlob(final String columnLabel, final java.io.InputStream inputStream) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateClob(final int columnIndex, final java.io.Reader reader) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateClob(final String columnLabel, final java.io.Reader reader) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNClob(final int columnIndex, final java.io.Reader reader) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateNClob(final String columnLabel, final java.io.Reader reader) {
            throw new UnsupportedOperationException();
        }

        @Override
        public <T> T getObject(final int columnIndex, final Class<T> type) {
            throw new UnsupportedOperationException();
        }

        @Override
        public <T> T getObject(final String columnLabel, final Class<T> type) {
            throw new UnsupportedOperationException();
        }
    }
}
