package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class DurationUtilsAgentTest {

    private static final class LongBox {
        long value;
    }

    private static final class IntBox {
        int value;
    }

    private static final class InstantBox {
        Instant value;
    }

    // --- accept(FailableBiConsumer, Duration) ---

    @Test
    public void testAcceptSplitsPositiveDurationWithNonNegativeNanos() {
        final Duration duration = Duration.ofNanos(1500000L);
        final LongBox millis = new LongBox();
        final IntBox nanos = new IntBox();
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millisParam, final Integer nanosParam) {
                millis.value = millisParam.longValue();
                nanos.value = nanosParam.intValue();
            }
        }, duration);
        assertEquals(1L, millis.value);
        assertEquals(500000, nanos.value);
        assertTrue(nanos.value >= 0 && nanos.value <= 999999);
    }

    @Test
    public void testAcceptSplitsNegativeDurationWithNonNegativeNanos() {
        final Duration duration = Duration.ofNanos(-1500000L);
        final LongBox millis = new LongBox();
        final IntBox nanos = new IntBox();
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millisParam, final Integer nanosParam) {
                millis.value = millisParam.longValue();
                nanos.value = nanosParam.intValue();
            }
        }, duration);
        assertEquals(-2L, millis.value);
        assertEquals(500000, nanos.value);
        assertTrue(nanos.value >= 0 && nanos.value <= 999999);
    }

    @Test
    public void testAcceptPropagatesCheckedException() {
        final Duration duration = Duration.ofMillis(10);
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.accept(new FailableBiConsumer<Long, Integer, IOException>() {
                    @Override
                    public void accept(final Long millisParam, final Integer nanosParam) throws IOException {
                        throw new IOException("boom");
                    }
                }, duration);
            }
        });
    }

    // --- get(String, TemporalUnit, long) ---

    @Test
    public void testGetUsesSystemPropertyWhenPresent() {
        final String key = "DurationUtilsAgentTest.get.present";
        System.setProperty(key, "7");
        try {
            final Duration result = DurationUtils.get(key, ChronoUnit.SECONDS, 99L);
            assertEquals(Duration.ofSeconds(7), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    public void testGetUsesDefaultWhenPropertyAbsent() {
        final String key = "DurationUtilsAgentTest.get.absent";
        System.clearProperty(key);
        final Duration result = DurationUtils.get(key, ChronoUnit.MINUTES, 2L);
        assertEquals(Duration.ofMinutes(2), result);
    }

    // --- getMillis(String, long) ---

    @Test
    public void testGetMillisUsesSystemPropertyWhenPresent() {
        final String key = "DurationUtilsAgentTest.getMillis.present";
        System.setProperty(key, "250");
        try {
            final Duration result = DurationUtils.getMillis(key, 1L);
            assertEquals(Duration.ofMillis(250), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    public void testGetMillisUsesDefaultWhenPropertyAbsent() {
        final String key = "DurationUtilsAgentTest.getMillis.absent";
        System.clearProperty(key);
        final Duration result = DurationUtils.getMillis(key, 123L);
        assertEquals(Duration.ofMillis(123), result);
    }

    // --- getSeconds(String, long) ---

    @Test
    public void testGetSecondsUsesSystemPropertyWhenPresent() {
        final String key = "DurationUtilsAgentTest.getSeconds.present";
        System.setProperty(key, "9");
        try {
            final Duration result = DurationUtils.getSeconds(key, 1L);
            assertEquals(Duration.ofSeconds(9), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    public void testGetSecondsUsesDefaultWhenPropertyAbsent() {
        final String key = "DurationUtilsAgentTest.getSeconds.absent";
        System.clearProperty(key);
        final Duration result = DurationUtils.getSeconds(key, 42L);
        assertEquals(Duration.ofSeconds(42), result);
    }

    // --- getNanosOfMilli(Duration) / getNanosOfMiili(Duration) ---

    @Test
    public void testGetNanosOfMilliIsWithinDocumentedRange() {
        final int nanos = DurationUtils.getNanosOfMilli(Duration.ofNanos(1500000L));
        assertEquals(500000, nanos);
        assertTrue(nanos >= 0 && nanos <= 999999);
    }

    @Test
    public void testGetNanosOfMilliOnExactMillisecondIsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofMillis(5)));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testDeprecatedGetNanosOfMiiliMatchesGetNanosOfMilli() {
        final Duration duration = Duration.ofNanos(2500000L);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    // --- isPositive(Duration) ---

    @Test
    public void testIsPositiveTrueForPositiveDuration() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
    }

    @Test
    public void testIsPositiveFalseForZeroDuration() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    public void testIsPositiveFalseForNegativeDuration() {
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    // --- of(FailableConsumer<Instant, E>) ---

    @Test
    public void testOfConsumerReturnsNonNegativeDurationAndSuppliesInstant() {
        final InstantBox received = new InstantBox();
        final Duration result = DurationUtils.of(new FailableConsumer<Instant, RuntimeException>() {
            @Override
            public void accept(final Instant instant) {
                received.value = instant;
            }
        });
        assertNotNull(received.value);
        assertNotNull(result);
        assertFalse(result.isNegative());
    }

    @Test
    public void testOfConsumerPropagatesCheckedException() {
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, IOException>() {
                    @Override
                    public void accept(final Instant instant) throws IOException {
                        throw new IOException("boom");
                    }
                });
            }
        });
    }

    // --- of(FailableRunnable<E>) ---

    @Test
    public void testOfRunnableReturnsNonNegativeDurationAndRuns() {
        final IntBox calls = new IntBox();
        final Duration result = DurationUtils.of(new FailableRunnable<RuntimeException>() {
            @Override
            public void run() {
                calls.value++;
            }
        });
        assertEquals(1, calls.value);
        assertNotNull(result);
        assertFalse(result.isNegative());
    }

    @Test
    public void testOfRunnablePropagatesCheckedException() {
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<IOException>() {
                    @Override
                    public void run() throws IOException {
                        throw new IOException("boom");
                    }
                });
            }
        });
    }

    // --- since(Temporal) ---

    @Test
    public void testSinceWithPastInstantIsPositiveAndApproximatelyCorrect() {
        final Temporal start = Instant.now().minusSeconds(5);
        final Duration result = DurationUtils.since(start);
        assertTrue(DurationUtils.isPositive(result));
        assertTrue(result.toMillis() >= 4000, "expected at least ~5s, got " + result);
        assertTrue(result.toMillis() < 60000, "expected well under a minute, got " + result);
    }

    @Test
    public void testSinceWithFutureInstantIsNegative() {
        final Temporal start = Instant.now().plusSeconds(1000);
        final Duration result = DurationUtils.since(start);
        assertTrue(result.isNegative());
        assertFalse(DurationUtils.isPositive(result));
    }

    // --- toChronoUnit(TimeUnit) [package-private] ---

    @Test
    public void testToChronoUnitMapsAllKnownTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    // --- toDuration(long, TimeUnit) ---

    @Test
    public void testToDurationFromPositiveSeconds() {
        assertEquals(Duration.ofSeconds(5), DurationUtils.toDuration(5L, TimeUnit.SECONDS));
    }

    @Test
    public void testToDurationFromNegativeMillis() {
        assertEquals(Duration.ofMillis(-100), DurationUtils.toDuration(-100L, TimeUnit.MILLISECONDS));
    }

    // --- toMillisInt(Duration) ---

    @Test
    public void testToMillisIntNormalValue() {
        assertEquals(100, DurationUtils.toMillisInt(Duration.ofMillis(100)));
    }

    @Test
    public void testToMillisIntClampsAboveIntegerMax() {
        final Duration duration = Duration.ofMillis((long) Integer.MAX_VALUE + 1L);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    public void testToMillisIntClampsBelowIntegerMin() {
        final Duration duration = Duration.ofMillis((long) Integer.MIN_VALUE - 1L);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(duration));
    }

    // --- toMillisLong(Duration) ---

    @Test
    public void testToMillisLongNormalValue() {
        assertEquals(5000L, DurationUtils.toMillisLong(Duration.ofSeconds(5)));
    }

    @Test
    public void testToMillisLongClampsAboveLongMaxWithoutThrowing() {
        final Duration duration = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    public void testToMillisLongClampsBelowLongMinWithoutThrowing() {
        final Duration duration = Duration.ofSeconds(Long.MIN_VALUE);
        assertEquals(Long.MIN_VALUE, DurationUtils.toMillisLong(duration));
    }

    // --- zeroIfNull(Duration) ---

    @Test
    public void testZeroIfNullWithNullReturnsZero() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    public void testZeroIfNullWithNonNullReturnsSameValue() {
        final Duration duration = Duration.ofSeconds(3);
        assertSame(duration, DurationUtils.zeroIfNull(duration));
    }
}
