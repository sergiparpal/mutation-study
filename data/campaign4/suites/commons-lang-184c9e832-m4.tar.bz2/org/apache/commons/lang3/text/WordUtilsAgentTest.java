/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class WordUtilsAgentTest {

    @Test
    public void testCapitalize_null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    public void testCapitalize_withDelimiters_null() {
        assertNull(WordUtils.capitalize(null, ' '));
    }

    @Test
    public void testCapitalize_withDelimiters_emptyArray() {
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalize(str, new char[0]));
    }

    @Test
    public void testCapitalize_withDelimiters_nullDelimiters() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalize_withDelimiters_custom() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", '.'));
    }

    @Test
    public void testCapitalizeFully_null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    @Test
    public void testCapitalizeFully_withDelimiters_null() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
    }

    @Test
    public void testCapitalizeFully_withDelimiters_nullDelimiters() {
        assertEquals("I Am.fine", WordUtils.capitalizeFully("i aM.fine", (char[]) null));
    }

    @Test
    public void testCapitalizeFully_withDelimiters_emptyArray() {
        final String str = "i aM.fine";
        assertSame(str, WordUtils.capitalizeFully(str, new char[0]));
    }

    @Test
    public void testCapitalizeFully_withDelimiters_custom() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", '.'));
    }

    @Test
    public void testContainsAllWords_nullWord() {
        assertFalseResult(WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_emptyWord() {
        assertFalseResult(WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_nullWords() {
        assertFalseResult(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_emptyWordsArray() {
        assertFalseResult(WordUtils.containsAllWords("abc def"));
    }

    @Test
    public void testContainsAllWords_blankElement() {
        assertFalseResult(WordUtils.containsAllWords("abc def", "abc", " "));
    }

    @Test
    public void testContainsAllWords_partialMatchNotWordBoundary() {
        assertFalseResult(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_allPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    public void testContainsAllWords_oneMissing() {
        assertFalseResult(WordUtils.containsAllWords("abc def", "abc", "xyz"));
    }

    private void assertFalseResult(final boolean result) {
        assertTrue(!result);
    }

    @Test
    public void testInitials_null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_withPeriod() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    @Test
    public void testInitials_withDelimiters_null() {
        assertNull(WordUtils.initials(null, '.'));
    }

    @Test
    public void testInitials_withDelimiters_emptyArray() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    @Test
    public void testInitials_withDelimiters_nullDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitials_withDelimiters_custom() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testSwapCase_null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testSwapCase_nonLetterCharacters() {
        assertEquals("1 2 3", WordUtils.swapCase("1 2 3"));
    }

    @Test
    public void testUncapitalize_null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    @Test
    public void testUncapitalize_withDelimiters_null() {
        assertNull(WordUtils.uncapitalize(null, '.'));
    }

    @Test
    public void testUncapitalize_withDelimiters_nullDelimiters() {
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    public void testUncapitalize_withDelimiters_emptyArray() {
        final String str = "I AM.FINE";
        assertSame(str, WordUtils.uncapitalize(str, new char[0]));
    }

    @Test
    public void testUncapitalize_withDelimiters_custom() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", '.'));
    }

    @Test
    public void testWrap_null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap_empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_wrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("abc", 0);
        assertEquals("abc", result);
    }

    @Test
    public void testWrap_wrapLengthNegativeTreatedAsOne() {
        final String result = WordUtils.wrap("abc", -10);
        assertEquals("abc", result);
    }

    @Test
    public void testWrap_customNewLineString() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    public void testWrap_wrapLongWordsTrue() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    public void testWrap_wrapLongWordsFalse() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    public void testWrap_customWrapOn() {
        final String input = "flammable/inflammable";
        final String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    public void testWrap_blankWrapOnUsesSpace() {
        final String input = "one two three four five";
        final String expected = "one two" + System.lineSeparator() + "three four" + System.lineSeparator() + "five";
        assertEquals(expected, WordUtils.wrap(input, 10, null, false, ""));
    }

    @Test
    public void testConstructorIsPublic() {
        assertTrue(new WordUtils() != null);
    }
}
