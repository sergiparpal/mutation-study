/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StrBuilder}.
 */
@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    @Test
    public void testConstructorDefault() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testConstructorNegativeCapacity() {
        final StrBuilder sb = new StrBuilder(-5);
        assertEquals(32, sb.capacity());
    }

    @Test
    public void testConstructorZeroCapacity() {
        final StrBuilder sb = new StrBuilder(0);
        assertEquals(32, sb.capacity());
    }

    @Test
    public void testConstructorPositiveCapacity() {
        final StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
    }

    @Test
    public void testConstructorNullString() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testConstructorString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(5, sb.length());
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true);
        assertEquals("true", sb.toString());
        sb.clear();
        sb.append(false);
        assertEquals("false", sb.toString());
    }

    @Test
    public void testAppendChar() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append('A');
        assertSame(sb, result);
        assertEquals("A", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder("x");
        sb.append(new char[0]);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStart() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, 3, 1));
    }

    @Test
    public void testAppendCharArrayRangeInvalidLength() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, 0, 3));
    }

    @Test
    public void testAppendCharBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello"));
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendCharBufferNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharBuffer) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello"), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendCharSequence() {
        final StrBuilder sb = new StrBuilder();
        final CharSequence cs = "world";
        sb.append(cs);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendCharSequenceNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharSequenceOtherStrBuilder() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("abc");
        sb.append((CharSequence) other);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "hello", 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendDouble() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5d);
        assertEquals(String.valueOf(1.5d), sb.toString());
    }

    @Test
    public void testAppendFloat() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5f);
        assertEquals(String.valueOf(1.5f), sb.toString());
    }

    @Test
    public void testAppendInt() {
        final StrBuilder sb = new StrBuilder();
        sb.append(42);
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendLong() {
        final StrBuilder sb = new StrBuilder();
        sb.append(123456789012L);
        assertEquals("123456789012", sb.toString());
    }

    @Test
    public void testAppendObject() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) Integer.valueOf(7));
        assertEquals("7", sb.toString());
    }

    @Test
    public void testAppendObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        final StrBuilder sb = new StrBuilder("a");
        final StrBuilder other = new StrBuilder("bc");
        sb.append(other);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStrBuilderNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.append((StrBuilder) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRange() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("hello");
        sb.append(other, 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, 0, 10));
    }

    @Test
    public void testAppendString() {
        final StrBuilder sb = new StrBuilder();
        sb.append("hello");
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendStringNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append("hello", 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendStringRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("hello", -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("hello", 0, 10));
    }

    @Test
    public void testAppendFormatted() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 5);
        assertEquals("x-5", sb.toString());
    }

    @Test
    public void testAppendStringBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hi"));
        assertEquals("hi", sb.toString());
    }

    @Test
    public void testAppendStringBufferNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((StringBuffer) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello"), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendStringBuilder() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("hi"));
        assertEquals("hi", sb.toString());
    }

    @Test
    public void testAppendStringBuilderNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((StringBuilder) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringBuilderRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("hello"), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = new ArrayList<>();
        list.add("a");
        list.add("b");
        sb.appendAll((Iterable<?>) list);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendAllIterableNull() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendAll((Iterable<?>) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll(list.iterator());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIteratorNull() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendAll((java.util.Iterator<?>) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllArrayNull() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendAll((Object[]) null);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(5, 4, '0');
        assertEquals("0005", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncates() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(123456, 3, '0');
        assertEquals("456", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftZeroWidth() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendFixedWidthPadLeft(5, 0, '0');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendFixedWidthPadLeft((Object) null, 6, ' ');
        assertEquals("  NULL", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(5, 4, '0');
        assertEquals("5000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncates() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(123456, 3, '0');
        assertEquals("123", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightZeroWidth() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendFixedWidthPadRight(5, -1, '0');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendlnVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln(1);
        sb.appendln("x");
        sb.appendln(true);
        assertEquals("1\nx\ntrue\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineCustom() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        sb.appendNewLine();
        assertEquals("<br>", sb.toString());
        assertEquals("<br>", sb.getNewLineText());
    }

    @Test
    public void testAppendNullNoText() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendNullWithText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendNull();
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testSetNullTextEmptyBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    @Test
    public void testAppendPadding() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendPadding(3, '-');
        assertEquals("x---", sb.toString());
    }

    @Test
    public void testAppendPaddingNegative() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendPadding(-1, '-');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(',');
        sb.append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharDefaultIfEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.append("a");
        sb.appendSeparator(',', ';');
        assertEquals(";a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator("-", i);
            sb.append(i);
        }
        assertEquals("0-1-2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        assertEquals(" where", sb.toString());
        sb.append("a=1");
        sb.appendSeparator(" and", " where");
        assertEquals(" wherea=1 and", sb.toString());
    }

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder target = new StringBuilder();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendToStringBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuffer target = new StringBuffer();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringWriterSpy writer = new StringWriterSpy();
        sb.appendTo(writer);
        assertEquals("hello", writer.getContent());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendWithSeparators((Iterable<?>) list, ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b");
        sb.appendWithSeparators((Iterable<?>) list, null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNull() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendWithSeparators(list.iterator(), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArrayEmpty() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendWithSeparators(new Object[0], ",");
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAsReaderReadsContent() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
    }

    @Test
    public void testAsReaderMarkAndReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        reader.read();
        reader.mark(10);
        reader.read();
        reader.read();
        reader.reset();
        assertEquals('b', reader.read());
    }

    @Test
    public void testAsReaderBulkRead() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final char[] buf = new char[4];
        final int n = reader.read(buf, 0, 4);
        assertEquals(4, n);
        assertEquals("abcd", new String(buf));
    }

    @Test
    public void testAsReaderBulkReadInvalidArgs() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(new char[2], -1, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(new char[2], 0, 3));
    }

    @Test
    public void testAsReaderSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final long skipped = reader.skip(3);
        assertEquals(3, skipped);
        assertEquals('d', reader.read());
    }

    @Test
    public void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        assertEquals(Arrays.asList("a", "b", "c"), tokenizer.getTokenList());
    }

    @Test
    public void testAsWriter() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("hi");
        writer.write('!');
        writer.write(new char[] {'a', 'b'});
        writer.write(new char[] {'c', 'd', 'e'}, 1, 2);
        writer.write("xyz", 1, 2);
        assertEquals("hi!abdeyz", sb.toString());
    }

    @Test
    public void testBuild() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.build());
    }

    @Test
    public void testCapacity() {
        final StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
        sb.append("12345678901234567890");
        assertTrue(sb.capacity() >= 21);
    }

    @Test
    public void testCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    @Test
    public void testCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(3));
    }

    @Test
    public void testClear() {
        final StrBuilder sb = new StrBuilder("abc");
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cde"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertTrue(sb.contains(StrMatcher.charMatcher('1')));
        assertFalse(sb.contains(StrMatcher.charMatcher('z')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testDeleteRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteRangeEndTooLarge() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(2, 100);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testDeleteRangeInvalidStart() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(-1, 2));
    }

    @Test
    public void testDeleteRangeStartGreaterThanEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(4, 2));
    }

    @Test
    public void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("abcabcabc");
        sb.deleteAll('a');
        assertEquals("bcbcbc", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteAll("ab");
        assertEquals("", sb.toString());
    }

    @Test
    public void testDeleteAllStringNull() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testDeleteCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(3));
    }

    @Test
    public void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst("abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2");
        sb.deleteFirst(StrMatcher.charSetMatcher("12"));
        assertEquals("ab2", sb.toString());
    }

    @Test
    public void testEndsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith("this is way too long to match"));
    }

    @Test
    public void testEnsureCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testEnsureCapacityNoGrowthWhenSufficient() {
        final StrBuilder sb = new StrBuilder(50);
        sb.ensureCapacity(10);
        assertEquals(50, sb.capacity());
    }

    @Test
    public void testEqualsObject() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals((Object) sb3));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((Object) null));
    }

    @Test
    public void testEqualsStrBuilder() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb1));
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals((StrBuilder) null));
        final StrBuilder sb3 = new StrBuilder("ab");
        assertFalse(sb1.equals(sb3));
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder sb1 = new StrBuilder("ABC");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertTrue(sb1.equalsIgnoreCase(sb1));
        final StrBuilder sb3 = new StrBuilder("abd");
        assertFalse(sb1.equalsIgnoreCase(sb3));
    }

    @Test
    public void testGetCharsSingleArg() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testGetCharsSingleArgReuseBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] dest = new char[10];
        final char[] result = sb.getChars(dest);
        assertSame(dest, result);
        assertEquals('a', dest[0]);
    }

    @Test
    public void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[6];
        sb.getChars(1, 4, dest, 0);
        assertEquals('b', dest[0]);
        assertEquals('c', dest[1]);
        assertEquals('d', dest[2]);
    }

    @Test
    public void testGetCharsRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] dest = new char[5];
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 2, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 10, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(2, 1, dest, 0));
    }

    @Test
    public void testHashCodeConsistency() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(-1, sb.indexOf('b', 100));
        assertEquals(0, sb.indexOf('a', -5));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(-1, sb.indexOf("xyz"));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf("bc", 2));
    }

    @Test
    public void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertEquals(3, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testIndexOfMatcherStart() {
        final StrBuilder sb = new StrBuilder("1a2b3c");
        assertEquals(3, sb.indexOf(StrMatcher.charSetMatcher("abc"), 2));
        assertEquals(-1, sb.indexOf(StrMatcher.charMatcher('a'), 100));
    }

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, true);
        assertEquals("atrueb", sb.toString());
        sb.clear();
        sb.append("ab").insert(1, false);
        assertEquals("afalseb", sb.toString());
    }

    @Test
    public void testInsertBooleanInvalidIndex() {
        final StrBuilder sb = new StrBuilder("ab");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, true));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(5, true));
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNull() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (char[]) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("ae");
        sb.insert(1, new char[] {'w', 'b', 'c', 'x'}, 1, 2);
        assertEquals("abce", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder("ab");
        final char[] chars = new char[] {'x', 'y'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, 0, 3));
    }

    @Test
    public void testInsertDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 1.5d);
        sb.insert(0, 2L);
        sb.insert(0, 3);
        sb.insert(0, 4.5f);
        assertEquals("4.532" + 1.5d, sb.toString());
    }

    @Test
    public void testInsertObject() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (Object) Integer.valueOf(9));
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertObjectNull() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (Object) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testInsertString() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, "bc");
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertStringNull() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (String) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testInsertStringInvalidIndex() {
        final StrBuilder sb = new StrBuilder("ab");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, "x"));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(3, "x"));
    }

    @Test
    public void testIsEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        sb.append("x");
        assertFalse(sb.isEmpty());
    }

    @Test
    public void testIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertFalse(sb.isNotEmpty());
        sb.append("x");
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.lastIndexOf('b', 3));
        assertEquals(-1, sb.lastIndexOf('a', -1));
        assertEquals(4, sb.lastIndexOf('b', 100));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfStringStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.lastIndexOf("abc", 2));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("1a2b3c");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("abc")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testLastIndexOfMatcherStart() {
        final StrBuilder sb = new StrBuilder("1a2b3c");
        assertEquals(1, sb.lastIndexOf(StrMatcher.charSetMatcher("abc"), 2));
        assertEquals(-1, sb.lastIndexOf(StrMatcher.charMatcher('a'), -1));
    }

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(-1));
        assertEquals("abcdef", sb.leftString(100));
    }

    @Test
    public void testLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(6, sb.length());
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.midString(1, 3));
        assertEquals("", sb.midString(1, -1));
        assertEquals("abc", sb.midString(-5, 3));
        assertEquals("", sb.midString(100, 3));
        assertEquals("cdef", sb.midString(2, 100));
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new java.io.StringReader("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(CharBuffer.wrap("world"));
        assertEquals(5, read);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testReadFromGenericReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new MinimalReadable("xyz"));
        assertEquals(3, read);
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XY");
        assertEquals("aXYdef", sb.toString());
    }

    @Test
    public void testReplaceRangeShorter() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 5, "X");
        assertEquals("aXf", sb.toString());
    }

    @Test
    public void testReplaceRangeNullDeletes() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testReplaceRangeEndTooLarge() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(4, 100, "Z");
        assertEquals("abcdZ", sb.toString());
    }

    @Test
    public void testReplaceMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("123"), "#", 0, sb.length(), -1);
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceMatcherLimitedCount() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("123"), "#", 0, sb.length(), 1);
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReplaceAllCharToChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());
    }

    @Test
    public void testReplaceAllCharNoOpWhenSame() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'a');
        assertEquals("banana", sb.toString());
    }

    @Test
    public void testReplaceAllStringToString() {
        final StrBuilder sb = new StrBuilder("one two one two");
        sb.replaceAll("one", "ONE");
        assertEquals("ONE two ONE two", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullSearch() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.replaceAll((String) null, "x");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullReplace() {
        final StrBuilder sb = new StrBuilder("aXbXc");
        sb.replaceAll("X", null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceFirstCharToChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());
    }

    @Test
    public void testReplaceFirstStringToString() {
        final StrBuilder sb = new StrBuilder("one two one");
        sb.replaceFirst("one", "ONE");
        assertEquals("ONE two one", sb.toString());
    }

    @Test
    public void testReplaceFirstStringNullSearch() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.replaceFirst((String) null, "x");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReverse() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.reverse();
        assertEquals("fedcba", sb.toString());
    }

    @Test
    public void testReverseEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    @Test
    public void testReverseSingleChar() {
        final StrBuilder sb = new StrBuilder("a");
        sb.reverse();
        assertEquals("a", sb.toString());
    }

    @Test
    public void testReverseSurrogatePair() {
        final String supplementary = new String(Character.toChars(0x1F600));
        final StrBuilder sb = new StrBuilder("a" + supplementary + "b");
        sb.reverse();
        assertEquals("b" + supplementary + "a", sb.toString());
        final StringBuilder jdk = new StringBuilder("a" + supplementary + "b").reverse();
        assertEquals(jdk.toString(), sb.toString());
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(-1));
        assertEquals("abcdef", sb.rightString(100));
    }

    @Test
    public void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testSetCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'X'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(3, 'X'));
    }

    @Test
    public void testSetLengthShrink() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testSetLengthGrow() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));
    }

    @Test
    public void testSetLengthNegativeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    public void testSetLengthSameNoChange() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testSize() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(6, sb.size());
        assertEquals(sb.length(), sb.size());
    }

    @Test
    public void testStartsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith("this is way too long to match"));
    }

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.subSequence(1, 4));
    }

    @Test
    public void testSubSequenceInvalid() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 3));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(4, 2));
    }

    @Test
    public void testSubstringFromStart() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    @Test
    public void testSubstringRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.substring(1, 4));
    }

    @Test
    public void testSubstringRangeEndTooLarge() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2, 100));
    }

    @Test
    public void testSubstringInvalidStart() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(-1, 3));
    }

    @Test
    public void testToCharArray() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());
    }

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertArrayEquals(new char[0], sb.toCharArray());
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'b', 'c', 'd'}, sb.toCharArray(1, 4));
    }

    @Test
    public void testToCharArrayRangeEmpty() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[0], sb.toCharArray(2, 2));
    }

    @Test
    public void testToStringIndependentCopy() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilderMethod() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder other = sb.toStringBuilder();
        assertEquals("abc", other.toString());
    }

    @Test
    public void testTrim() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimNoWhitespace() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimAllWhitespace() {
        final StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testChainedCalls() {
        final StrBuilder sb = new StrBuilder();
        sb.append("a").append('b').append(1).append(true);
        assertEquals("ab1true", sb.toString());
    }

    /**
     * Minimal {@link Readable} implementation that is not a {@link Reader} or {@link CharBuffer},
     * used to exercise the generic branch of {@link StrBuilder#readFrom(Readable)}.
     */
    private static final class MinimalReadable implements Readable {
        private final char[] data;
        private int pos;

        MinimalReadable(final String s) {
            data = s.toCharArray();
        }

        @Override
        public int read(final CharBuffer cb) {
            if (pos >= data.length) {
                return -1;
            }
            final int n = Math.min(cb.remaining(), data.length - pos);
            cb.put(data, pos, n);
            pos += n;
            return n;
        }
    }

    /** Minimal Writer that records written content, used to test appendTo(Writer). */
    private static final class StringWriterSpy extends Writer {
        private final StringBuilder content = new StringBuilder();

        @Override
        public void write(final char[] cbuf, final int off, final int len) {
            content.append(cbuf, off, len);
        }

        @Override
        public void flush() {
            // no-op
        }

        @Override
        public void close() {
            // no-op
        }

        String getContent() {
            return content.toString();
        }
    }
}
