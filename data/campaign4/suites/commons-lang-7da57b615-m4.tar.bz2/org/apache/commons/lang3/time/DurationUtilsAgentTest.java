/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    private static final String PROP_KEY = "org.apache.commons.lang3.time.DurationUtilsAgentTest.prop";

    @AfterEach
    public void clearProperty() {
        System.clearProperty(PROP_KEY);
    }

    @Test
    public void testAcceptNormal() {
        final Duration d = Duration.ofSeconds(1).plusNanos(123456789);
        final long[] capturedMillis = new long[1];
        final int[] capturedNanos = new int[1];
        final boolean[] called = new boolean[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                capturedMillis[0] = millis.longValue();
                capturedNanos[0] = nanos.intValue();
                called[0] = true;
            }
        }, d);
        assertTrue(called[0]);
        assertEquals(d.toMillis(), capturedMillis[0]);
        assertEquals(DurationUtils.getNanosOfMilli(d), capturedNanos[0]);
    }

    @Test
    public void testAcceptNegativeDuration() {
        final Duration d = Duration.ofSeconds(-2).plusNanos(123000000);
        final long[] capturedMillis = new long[1];
        final int[] capturedNanos = new int[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                capturedMillis[0] = millis.longValue();
                capturedNanos[0] = nanos.intValue();
            }
        }, d);
        assertTrue(capturedNanos[0] >= 0);
        assertEquals(d.minusNanos(capturedNanos[0]).toMillis(), capturedMillis[0]);
    }

    @Test
    public void testAcceptNullConsumer() {
        // Must not throw, and nothing to assert on besides no exception.
        DurationUtils.accept(null, Duration.ofSeconds(1));
    }

    @Test
    public void testAcceptNullDuration() {
        final boolean[] called = new boolean[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                called[0] = true;
            }
        }, null);
        assertFalse(called[0]);
    }

    @Test
    public void testAcceptPropagatesException() {
        final Duration d = Duration.ofSeconds(1);
        assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.accept(new FailableBiConsumer<Long, Integer, java.io.IOException>() {
                    @Override
                    public void accept(final Long millis, final Integer nanos) throws java.io.IOException {
                        throw new java.io.IOException("boom");
                    }
                }, d);
            }
        });
    }

    @Test
    public void testGetWithPropertySet() {
        System.setProperty(PROP_KEY, "42");
        final Duration result = DurationUtils.get(PROP_KEY, ChronoUnit.SECONDS, 7);
        assertEquals(Duration.ofSeconds(42), result);
    }

    @Test
    public void testGetWithPropertyUnset() {
        final Duration result = DurationUtils.get(PROP_KEY, ChronoUnit.SECONDS, 7);
        assertEquals(Duration.ofSeconds(7), result);
    }

    @Test
    public void testGetWithEmptyKey() {
        final Duration result = DurationUtils.get("", ChronoUnit.MINUTES, 5);
        assertEquals(Duration.ofMinutes(5), result);
    }

    @Test
    public void testGetWithNullKey() {
        final Duration result = DurationUtils.get(null, ChronoUnit.MINUTES, 5);
        assertEquals(Duration.ofMinutes(5), result);
    }

    @Test
    public void testGetMillis() {
        System.setProperty(PROP_KEY, "250");
        assertEquals(Duration.ofMillis(250), DurationUtils.getMillis(PROP_KEY, 0));
        System.clearProperty(PROP_KEY);
        assertEquals(Duration.ofMillis(99), DurationUtils.getMillis(PROP_KEY, 99));
    }

    @Test
    public void testGetSeconds() {
        System.setProperty(PROP_KEY, "9");
        assertEquals(Duration.ofSeconds(9), DurationUtils.getSeconds(PROP_KEY, 0));
        System.clearProperty(PROP_KEY);
        assertEquals(Duration.ofSeconds(3), DurationUtils.getSeconds(PROP_KEY, 3));
    }

    @Test
    public void testGetNanosOfMilliZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ZERO));
    }

    @Test
    public void testGetNanosOfMilliNull() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    public void testGetNanosOfMilliBoundaryUnder1Ms() {
        final Duration d = Duration.ofNanos(999999);
        assertEquals(999999, DurationUtils.getNanosOfMilli(d));
    }

    @Test
    public void testGetNanosOfMilliExactly1Ms() {
        final Duration d = Duration.ofNanos(1000000);
        assertEquals(0, DurationUtils.getNanosOfMilli(d));
    }

    @Test
    public void testGetNanosOfMilliMultiMs() {
        final Duration d = Duration.ofNanos(5000123);
        assertEquals(123, DurationUtils.getNanosOfMilli(d));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetNanosOfMiiliDeprecatedMatchesNonDeprecated() {
        final Duration d = Duration.ofNanos(7000456);
        assertEquals(DurationUtils.getNanosOfMilli(d), DurationUtils.getNanosOfMiili(d));
    }

    @Test
    public void testIsPositiveTrue() {
        assertTrue(DurationUtils.isPositive(Duration.ofSeconds(1)));
    }

    @Test
    public void testIsPositiveZero() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    public void testIsPositiveNegative() {
        assertFalse(DurationUtils.isPositive(Duration.ofSeconds(-1)));
    }

    @Test
    public void testOfConsumerReturnsNonNegativeDuration() throws Throwable {
        final boolean[] invoked = new boolean[1];
        final Duration result = DurationUtils.of(new FailableConsumer<Instant, RuntimeException>() {
            @Override
            public void accept(final Instant start) {
                invoked[0] = true;
                assertNotNull(start);
            }
        });
        assertTrue(invoked[0]);
        assertFalse(result.isNegative());
    }

    @Test
    public void testOfConsumerPropagatesException() {
        assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, java.io.IOException>() {
                    @Override
                    public void accept(final Instant start) throws java.io.IOException {
                        throw new java.io.IOException("fail");
                    }
                });
            }
        });
    }

    @Test
    public void testOfRunnableReturnsNonNegativeDuration() throws Throwable {
        final boolean[] invoked = new boolean[1];
        final Duration result = DurationUtils.of(new FailableRunnable<RuntimeException>() {
            @Override
            public void run() {
                invoked[0] = true;
            }
        });
        assertTrue(invoked[0]);
        assertFalse(result.isNegative());
    }

    @Test
    public void testOfRunnablePropagatesException() {
        assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<java.io.IOException>() {
                    @Override
                    public void run() throws java.io.IOException {
                        throw new java.io.IOException("fail");
                    }
                });
            }
        });
    }

    @Test
    public void testSincePastInstantIsPositive() {
        final Instant past = Instant.now().minusSeconds(5);
        final Duration result = DurationUtils.since(past);
        assertTrue(DurationUtils.isPositive(result));
        assertTrue(result.getSeconds() >= 5);
    }

    @Test
    public void testToChronoUnitMapping() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    public void testToChronoUnitNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    @Test
    public void testToDuration() {
        assertEquals(Duration.ofSeconds(30), DurationUtils.toDuration(30, TimeUnit.SECONDS));
        assertEquals(Duration.ofMillis(-10), DurationUtils.toDuration(-10, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ZERO, DurationUtils.toDuration(0, TimeUnit.DAYS));
    }

    @Test
    public void testToMillisIntNormal() {
        assertEquals(1000, DurationUtils.toMillisInt(Duration.ofSeconds(1)));
        assertEquals(0, DurationUtils.toMillisInt(Duration.ZERO));
        assertEquals(-1000, DurationUtils.toMillisInt(Duration.ofSeconds(-1)));
    }

    @Test
    public void testToMillisIntOverflowClampsToMax() {
        final Duration d = Duration.ofSeconds(3000000);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(d));
    }

    @Test
    public void testToMillisIntUnderflowClampsToMin() {
        final Duration d = Duration.ofSeconds(-3000000);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(d));
    }

    @Test
    public void testToMillisIntNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    public void testToMillisLongNormal() {
        assertEquals(1000L, DurationUtils.toMillisLong(Duration.ofSeconds(1)));
        assertEquals(0L, DurationUtils.toMillisLong(Duration.ZERO));
        assertEquals(-1000L, DurationUtils.toMillisLong(Duration.ofSeconds(-1)));
    }

    @Test
    public void testToMillisLongOverflowClampsToMax() {
        final Duration d = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, DurationUtils.toMillisLong(d));
    }

    @Test
    public void testToMillisLongUnderflowClampsToMin() {
        final Duration d = Duration.ofSeconds(Long.MIN_VALUE);
        assertEquals(Long.MIN_VALUE, DurationUtils.toMillisLong(d));
    }

    @Test
    public void testToMillisLongNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisLong(null);
            }
        });
    }

    @Test
    public void testZeroIfNullWithNull() {
        assertSame(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    public void testZeroIfNullWithValue() {
        final Duration d = Duration.ofSeconds(5);
        assertSame(d, DurationUtils.zeroIfNull(d));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testDefaultConstructor() {
        assertNotNull(new DurationUtils());
    }
}
