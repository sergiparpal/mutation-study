/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static FastDateParser newParser(final String pattern) {
        return new FastDateParser(pattern, GMT, Locale.US);
    }

    @Test
    void testBasicDateParse() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final Date date = parser.parse("2024-03-05");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAccessors() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(GMT, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    void testTimeZoneReturnedIsClone() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final TimeZone tz1 = parser.getTimeZone();
        assertEquals(GMT, tz1);
        tz1.setID("Bogus/NotReal");
        // mutating a returned clone must not affect the parser's own time zone
        assertEquals(GMT, parser.getTimeZone());
    }

    @Test
    void testTwoDigitYearParse() throws ParseException {
        final FastDateParser parser = newParser("MM/dd/yy");
        final Date date = parser.parse("01/11/12");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2012, cal.get(Calendar.YEAR));
    }

    @Test
    void testCenturyStartParameter() throws ParseException {
        final Calendar centuryStartCal = new GregorianCalendar(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryStartCal.getTime());
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);

        cal.setTime(parser.parse("49"));
        assertEquals(2049, cal.get(Calendar.YEAR));

        cal.setTime(parser.parse("50"));
        assertEquals(1950, cal.get(Calendar.YEAR));

        cal.setTime(parser.parse("99"));
        assertEquals(1999, cal.get(Calendar.YEAR));
    }

    @Test
    void testParseThrowsOnUnparseableString() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParseException ex = assertThrows(ParseException.class, () -> parser.parse("not-a-date"));
        assertEquals(0, ex.getErrorOffset());
        assertTrue(ex.getMessage().contains("not-a-date"));
    }

    @Test
    void testParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("xxxx-MM-dd", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParsePositionPartialConsumption() {
        final FastDateParser parser = newParser("MM/dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("3/23/1961", pos);
        assertNotNull(date);
        // the unbounded month and day fields each stop at the first non-digit, consuming "3/23"
        assertEquals(4, pos.getIndex());
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseEmptyStringFails() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testParsePositionStartBeyondLengthFails() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(100);
        final Date date = parser.parse("2024-03-05", pos);
        assertNull(date);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseStartAtExactLengthFails() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(10);
        final Date date = parser.parse("2024-03-05", pos);
        // index == length is a valid start position but no strategy can match zero characters of a
        // non-empty pattern, so the first strategy's own failure sets the error index.
        assertNull(date);
        assertEquals(10, pos.getErrorIndex());
    }

    @Test
    void testParseCalendarOverload() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2024-03-05", pos, cal);
        assertTrue(ok);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final Object date = parser.parseObject("2024-03-05");
        assertTrue(date instanceof Date);
        assertEquals(parser.parse("2024-03-05"), date);
    }

    @Test
    void testParseObjectWithPositionDelegatesToParse() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Object date = parser.parseObject("2024-03-05", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testIntegerOverflowInNumericFieldIsParseFailureNotException() {
        final FastDateParser parser = newParser("yyyy");
        final ParsePosition pos = new ParsePosition(0);
        // 10 digits, one past Integer.MAX_VALUE, overflows during Integer.parseInt
        final Date date = parser.parse("2147483648", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testLargeYearBelowOverflowParsesSuccessfully() throws ParseException {
        final FastDateParser parser = newParser("yyyy");
        // large but still comfortably within the range Calendar can convert to millis
        final Date date = parser.parse("99999999");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(99999999, cal.get(Calendar.YEAR));
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> newParser("yyyy'MM"));
        assertEquals("Unterminated quote", ex.getMessage());
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> newParser("yyyy-QQ"));
        assertTrue(ex.getMessage().contains("Q"));
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> new FastDateParser(null, GMT, Locale.US));
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> new FastDateParser("yyyy-MM-dd", null, Locale.US));
    }

    @Test
    void testNullLocaleFallsBackToSystemDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, null);
        assertNotNull(parser.getLocale());
    }

    @Test
    void testQuotedLiteralTextIsCopiedVerbatim() throws ParseException {
        final FastDateParser parser = newParser("yyyy'T'MM");
        final Date date = parser.parse("2024T03");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));

        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("2024X03", pos));
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testEscapedQuoteLiteral() throws ParseException {
        final FastDateParser parser = newParser("yyyy''MM");
        final Date date = parser.parse("2024'03");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    @Test
    void testEquals() {
        final FastDateParser p1 = newParser("yyyy-MM-dd");
        final FastDateParser p2 = newParser("yyyy-MM-dd");
        final FastDateParser p3 = newParser("yyyy/MM/dd");
        final FastDateParser p4 = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertNotEquals(p1, p4);
        assertNotEquals(p1, "yyyy-MM-dd");
        assertNotEquals(p1, null);
        assertEquals(p1, p1);
    }

    @Test
    void testToString() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final String str = parser.toString();
        assertTrue(str.startsWith("FastDateParser["));
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("GMT"));
    }

    @Test
    void testToStringAll() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final String str = parser.toStringAll();
        assertTrue(str.contains("pattern=yyyy-MM-dd"));
        assertTrue(str.contains("timeZone="));
        assertTrue(str.contains("locale="));
    }

    @Test
    void testGetPatternsTokenizesFormat() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertEquals(5, parser.getPatterns().size());
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, deserialized);
        assertEquals(parser.getPattern(), deserialized.getPattern());
        assertEquals(parser.getTimeZone(), deserialized.getTimeZone());
        assertNotNull(deserialized.getPatterns());
        assertEquals(parser.parse("2024-03-05"), deserialized.parse("2024-03-05"));
    }

    @Test
    void testTextFieldMonthAndDayOfWeekNames() throws ParseException {
        final FastDateParser parser = newParser("EEEE, MMMM d, yyyy");
        final Date date = parser.parse("Tuesday, March 5, 2024");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTextFieldIsCaseInsensitive() throws ParseException {
        final FastDateParser parser = newParser("MMMM d, yyyy");
        final Date lower = parser.parse("march 5, 2024");
        final Date upper = parser.parse("MARCH 5, 2024");
        assertEquals(lower, upper);
    }

    @Test
    void testInvalidTextFieldValueIsParseFailure() {
        final FastDateParser parser = newParser("MMMM d, yyyy");
        final ParsePosition pos = new ParsePosition(0);
        // "March" matches as a prefix of the month name alternation; the failure surfaces at the
        // literal " " that follows, once "imus" does not match it
        final Date date = parser.parse("Marchimus 5, 2024", pos);
        assertNull(date);
        assertEquals(5, pos.getErrorIndex());
    }

    @Test
    void testWrongDayOfWeekNameFails() {
        final FastDateParser parser = new FastDateParser("EEEE, MM/dd/yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("Thorsday, 03/23/1961", pos));
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testHourInDayBoundaries() throws ParseException {
        final FastDateParser parser = newParser("HH");
        assertEquals(0, hourOf(parser.parse("00")));
        assertEquals(23, hourOf(parser.parse("23")));
    }

    private static int hourOf(final Date date) {
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        return cal.get(Calendar.HOUR_OF_DAY);
    }

    @Test
    void testRfc822TimeZoneOffset() throws ParseException {
        final FastDateParser parser = newParser("mm:ss Z");
        final Date plusOne = parser.parse("00:00 +0100");
        final Date utc = parser.parse("00:00 +0000");
        // "+0100" is one hour ahead of UTC, so the same wall-clock minute:second is an earlier instant
        assertEquals(3600000L, utc.getTime() - plusOne.getTime());
    }

    @Test
    void testIso8601TimeZoneSingleLetter() throws ParseException {
        final FastDateParser parser = newParser("mm:ss X");
        final Date date = parser.parse("00:00 +01");
        assertNotNull(date);
    }

    @Test
    void testIso8601TimeZoneInvalidWidthThrows() {
        assertThrows(IllegalArgumentException.class, () -> newParser("mm:ss XXXX"));
    }

    @Test
    void testWeekYearPattern() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-ww-u", GMT, Locale.US);
        final Date actual = parser.parse("2024-01-1");

        final Calendar expectedCal = Calendar.getInstance(GMT, Locale.US);
        expectedCal.clear();
        expectedCal.setWeekDate(2024, 1, Calendar.MONDAY);

        assertEquals(expectedCal.getTime(), actual);
    }

    @Test
    void testJapaneseImperialLocaleAddsEraNoteOnParseFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, new Locale("ja", "JP", "JP"));
        final ParseException ex = assertThrows(ParseException.class, () -> parser.parse("not-a-date"));
        assertTrue(ex.getMessage().contains("1868-01-01"));
    }

    @Test
    void testWhitespaceSkippedForUnboundedNumericField() throws ParseException {
        final FastDateParser parser = newParser("M/d/y");
        final Date date = parser.parse(" 3/ 23/ 1961");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(1961, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }
}
