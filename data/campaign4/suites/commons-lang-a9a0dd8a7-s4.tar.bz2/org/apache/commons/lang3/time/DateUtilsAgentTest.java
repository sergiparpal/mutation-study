package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class DateUtilsAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static TimeZone originalDefault;

    @BeforeAll
    public static void setUpDefaultTimeZone() {
        originalDefault = TimeZone.getDefault();
        TimeZone.setDefault(UTC);
    }

    @AfterAll
    public static void restoreDefaultTimeZone() {
        TimeZone.setDefault(originalDefault);
    }

    private static Calendar newCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = new GregorianCalendar(UTC);
        cal.clear();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date newDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    private static void expectNpe(Executable executable) {
        assertThrows(NullPointerException.class, executable);
    }

    // ---------------------------------------------------------------
    // Fields / constructor
    // ---------------------------------------------------------------

    @Test
    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(DateUtils.MILLIS_PER_SECOND * 60L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(DateUtils.MILLIS_PER_MINUTE * 60L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(DateUtils.MILLIS_PER_HOUR * 24L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    public void testRangeStyleConstantsAreDistinct() {
        int[] values = new int[] {
                DateUtils.RANGE_WEEK_SUNDAY, DateUtils.RANGE_WEEK_MONDAY,
                DateUtils.RANGE_WEEK_RELATIVE, DateUtils.RANGE_WEEK_CENTER,
                DateUtils.RANGE_MONTH_SUNDAY, DateUtils.RANGE_MONTH_MONDAY
        };
        for (int i = 0; i < values.length; i++) {
            for (int j = i + 1; j < values.length; j++) {
                assertNotEquals(values[i], values[j]);
            }
        }
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testPublicConstructor() {
        DateUtils instance = new DateUtils();
        assertNotNull(instance);
    }

    // ---------------------------------------------------------------
    // addXxx
    // ---------------------------------------------------------------

    @Test
    public void testAddDays() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date original = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date plus = DateUtils.addDays(date, 5);
        Calendar expectedPlus = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expectedPlus.add(Calendar.DAY_OF_MONTH, 5);
        assertEquals(expectedPlus.getTime(), plus);
        assertEquals(original, date);

        Date minus = DateUtils.addDays(date, -30);
        Calendar expectedMinus = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expectedMinus.add(Calendar.DAY_OF_MONTH, -30);
        assertEquals(expectedMinus.getTime(), minus);
        assertEquals(original, date);
    }

    @Test
    public void testAddHours() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addHours(date, 15);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.HOUR_OF_DAY, 15);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddMinutes() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addMinutes(date, -50);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.MINUTE, -50);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddSeconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addSeconds(date, 90);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.SECOND, 90);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddMilliseconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addMilliseconds(date, 900);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.MILLISECOND, 900);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddWeeks() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addWeeks(date, 2);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.WEEK_OF_YEAR, 2);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddMonths() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addMonths(date, 11);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.MONTH, 11);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddYears() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.addYears(date, -3);
        Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.YEAR, -3);
        assertEquals(expected.getTime(), result);
    }

    @Test
    public void testAddMethodsNullDateThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addDays(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addHours(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addMinutes(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addSeconds(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addMilliseconds(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addWeeks(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addMonths(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.addYears(null, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // ceiling / round / truncate
    // ---------------------------------------------------------------

    @Test
    public void testCeilingDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date hourCeil = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), hourCeil);

        Date monthCeil = DateUtils.ceiling(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), monthCeil);
    }

    @Test
    public void testCeilingCalendar() {
        Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result.getTime());
    }

    @Test
    public void testCeilingObject() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date fromDate = DateUtils.ceiling((Object) date, Calendar.HOUR_OF_DAY);
        Date fromCal = DateUtils.ceiling((Object) cal, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), fromDate);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), fromCal);

        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.ceiling((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testCeilingNullThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testCeilingHugeYearThrowsArithmeticException() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.ceiling(cal, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testRoundDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date hourRound = DateUtils.round(date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), hourRound);

        Date monthRound = DateUtils.round(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), monthRound);
    }

    @Test
    public void testRoundCalendar() {
        Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.round(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result.getTime());
    }

    @Test
    public void testRoundObject() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.round((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result);

        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.round((Object) "nope", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testRoundNullThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testRoundHugeYearThrowsArithmeticException() {
        final Date date = newDate(300000000, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.round(date, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testTruncateDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date hourTrunc = DateUtils.truncate(date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), hourTrunc);

        Date monthTrunc = DateUtils.truncate(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), monthTrunc);
    }

    @Test
    public void testTruncateCalendar() {
        Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), result.getTime());
    }

    @Test
    public void testTruncateObject() {
        Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.truncate((Object) cal, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), result);

        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncate((Object) Integer.valueOf(5), Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testTruncateNullThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testTruncateHugeYearThrowsArithmeticException() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncate((Object) cal, Calendar.MONTH);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFragmentInXxx
    // ---------------------------------------------------------------

    @Test
    public void testGetFragmentInDays() {
        Calendar jan28 = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        Calendar feb28 = newCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);

        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
        assertEquals(0L, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));

        assertEquals(28L, DateUtils.getFragmentInDays(jan28.getTime(), Calendar.MONTH));
        assertEquals(59L, DateUtils.getFragmentInDays(feb28.getTime(), Calendar.YEAR));
        assertEquals(0L, DateUtils.getFragmentInDays(jan28.getTime(), Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInHours() {
        Calendar jan1 = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Calendar jan6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Calendar jan16 = newCalendar(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);

        assertEquals(7L, DateUtils.getFragmentInHours(jan1, Calendar.DAY_OF_YEAR));
        assertEquals(7L, DateUtils.getFragmentInHours(jan6, Calendar.DAY_OF_YEAR));
        assertEquals(7L, DateUtils.getFragmentInHours(jan1, Calendar.MONTH));
        assertEquals(127L, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInHours(jan16, Calendar.MILLISECOND));

        assertEquals(127L, DateUtils.getFragmentInHours(jan6.getTime(), Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInHours(jan16.getTime(), Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInMinutes() {
        Calendar jan1 = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Calendar jan6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Calendar jan16 = newCalendar(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);

        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan6, Calendar.HOUR_OF_DAY));
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1, Calendar.MONTH));
        assertEquals(435L, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInMinutes(jan16, Calendar.MILLISECOND));

        assertEquals(435L, DateUtils.getFragmentInMinutes(jan6.getTime(), Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInMinutes(jan16.getTime(), Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInSeconds() {
        Calendar jan1 = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Calendar jan6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Calendar jan16 = newCalendar(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);

        assertEquals(10L, DateUtils.getFragmentInSeconds(jan1, Calendar.MINUTE));
        assertEquals(10L, DateUtils.getFragmentInSeconds(jan6, Calendar.MINUTE));
        assertEquals(26110L, DateUtils.getFragmentInSeconds(jan6, Calendar.DAY_OF_YEAR));
        assertEquals(0L, DateUtils.getFragmentInSeconds(jan16, Calendar.MILLISECOND));

        assertEquals(26110L, DateUtils.getFragmentInSeconds(jan6.getTime(), Calendar.DAY_OF_YEAR));
        assertEquals(0L, DateUtils.getFragmentInSeconds(jan16.getTime(), Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInMilliseconds() {
        Calendar jan1 = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Calendar jan6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Calendar jan16 = newCalendar(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);

        assertEquals(538L, DateUtils.getFragmentInMilliseconds(jan1, Calendar.SECOND));
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(jan6, Calendar.SECOND));
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MINUTE));
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(jan16, Calendar.MILLISECOND));

        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(jan6.getTime(), Calendar.MINUTE));
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(jan16.getTime(), Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentNullThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.MONTH);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays((Date) null, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testGetFragmentUnsupportedFragment() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        final Date date = cal.getTime();

        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays(cal, Calendar.DAY_OF_WEEK);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays(date, Calendar.DAY_OF_WEEK);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSameDay / isSameInstant / isSameLocalTime
    // ---------------------------------------------------------------

    @Test
    public void testIsSameDay() {
        Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar cal3 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);

        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertFalse(DateUtils.isSameDay(cal1, cal3));

        assertTrue(DateUtils.isSameDay(cal1.getTime(), cal2.getTime()));
        assertFalse(DateUtils.isSameDay(cal1.getTime(), cal3.getTime()));
    }

    @Test
    public void testIsSameInstant() {
        Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 1);

        assertTrue(DateUtils.isSameInstant(cal1, cal2));
        assertFalse(DateUtils.isSameInstant(cal1, cal3));

        assertTrue(DateUtils.isSameInstant(cal1.getTime(), cal2.getTime()));
        assertFalse(DateUtils.isSameInstant(cal1.getTime(), cal3.getTime()));
    }

    @Test
    public void testIsSameLocalTime() {
        Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar cal2 = new GregorianCalendar(TimeZone.getTimeZone("America/New_York"));
        cal2.clear();
        cal2.set(2002, Calendar.MARCH, 28, 13, 45, 0);
        cal2.set(Calendar.MILLISECOND, 0);

        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));
        assertFalse(DateUtils.isSameInstant(cal1, cal2));

        Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 14, 45, 0, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal3));
    }

    @Test
    public void testIsSameXxxNullThrowsNpe() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date date = cal.getTime();

        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.isSameDay((Calendar) null, cal);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.isSameDay((Date) null, date);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.isSameInstant((Calendar) null, cal);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.isSameInstant((Date) null, date);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.isSameLocalTime((Calendar) null, cal);
            }
        });
    }

    // ---------------------------------------------------------------
    // iterator
    // ---------------------------------------------------------------

    @Test
    public void testIteratorRangeMonthSunday() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);

        assertTrue(it.hasNext());
        Calendar first = it.next();
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }

        assertEquals(35, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testIteratorRangeMonthSundayFromDate() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(35, count);
    }

    @Test
    public void testIteratorRangeMonthSundayFromObject() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<?> it = DateUtils.iterator((Object) focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            Calendar c = (Calendar) it.next();
            assertNotNull(c);
            count++;
        }
        assertEquals(35, count);
    }

    @Test
    public void testIteratorWeekRangesHaveSevenDays() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);

        assertEquals(7, countIterated(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY)));
        assertEquals(7, countIterated(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY)));
        assertEquals(7, countIterated(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE)));
        assertEquals(7, countIterated(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER)));
    }

    private static int countIterated(Iterator<Calendar> it) {
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        return count;
    }

    @Test
    public void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final int invalid = DateUtils.RANGE_WEEK_SUNDAY + DateUtils.RANGE_WEEK_MONDAY
                + DateUtils.RANGE_WEEK_RELATIVE + DateUtils.RANGE_WEEK_CENTER
                + DateUtils.RANGE_MONTH_SUNDAY + DateUtils.RANGE_MONTH_MONDAY + 1;
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.iterator(focus, invalid);
            }
        });
    }

    @Test
    public void testIteratorNullThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    public void testIteratorObjectWrongTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    // ---------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ---------------------------------------------------------------

    @Test
    public void testParseDate() throws ParseException {
        Date parsed = DateUtils.parseDate("2002-03-28", new String[] { "yyyy-MM-dd" });
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), parsed);
    }

    @Test
    public void testParseDateTriesPatternsInTurn() throws ParseException {
        Date parsed = DateUtils.parseDate("2002-03-28",
                new String[] { "dd/MM/yyyy", "yyyy-MM-dd" });
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), parsed);
    }

    @Test
    public void testParseDateRequiresWholeStringConsumed() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDate("2002-03-28-extra", new String[] { "yyyy-MM-dd" });
            }
        });
    }

    @Test
    public void testParseDateNoMatchingPatternThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDate("not-a-date", new String[] { "yyyy-MM-dd" });
            }
        });
    }

    @Test
    public void testParseDateIsLenient() throws ParseException {
        Date parsed = DateUtils.parseDate("2001-02-30", new String[] { "yyyy-MM-dd" });
        assertEquals(newDate(2001, Calendar.MARCH, 2, 0, 0, 0, 0), parsed);
    }

    @Test
    public void testParseDateWithLocale() throws ParseException {
        Date withNullLocale = DateUtils.parseDate("2002-03-28", (Locale) null, new String[] { "yyyy-MM-dd" });
        Date withExplicitLocale = DateUtils.parseDate("2002-03-28", Locale.US, new String[] { "yyyy-MM-dd" });
        assertEquals(withNullLocale, withExplicitLocale);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), withExplicitLocale);
    }

    @Test
    public void testParseDateNullArgumentsThrowNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDate((String) null, new String[] { "yyyy-MM-dd" });
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDate("2002-03-28", (String[]) null);
            }
        });
    }

    @Test
    public void testParseDateStrictlyRejectsOverflow() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2001-02-30", new String[] { "yyyy-MM-dd" });
            }
        });
    }

    @Test
    public void testParseDateStrictlyAcceptsValidDate() throws ParseException {
        Date parsed = DateUtils.parseDateStrictly("2002-03-28", new String[] { "yyyy-MM-dd" });
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), parsed);
    }

    @Test
    public void testParseDateStrictlyWithLocale() throws ParseException {
        Date parsed = DateUtils.parseDateStrictly("2002-03-28", (Locale) null, new String[] { "yyyy-MM-dd" });
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), parsed);
    }

    @Test
    public void testParseDateStrictlyNullArgumentsThrowNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly((String) null, new String[] { "yyyy-MM-dd" });
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2002-03-28", (String[]) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // setXxx
    // ---------------------------------------------------------------

    @Test
    public void testSetDays() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setDays(date, 31);
        assertEquals(31, DateUtils.toCalendar(result).get(Calendar.DAY_OF_MONTH));

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setDays(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setDays(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 32);
            }
        });
    }

    @Test
    public void testSetHours() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setHours(date, 23);
        assertEquals(23, DateUtils.toCalendar(result).get(Calendar.HOUR_OF_DAY));

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setHours(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setHours(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 24);
            }
        });
    }

    @Test
    public void testSetMinutes() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setMinutes(date, 59);
        assertEquals(59, DateUtils.toCalendar(result).get(Calendar.MINUTE));

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMinutes(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 60);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMinutes(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), -1);
            }
        });
    }

    @Test
    public void testSetSeconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setSeconds(date, 59);
        assertEquals(59, DateUtils.toCalendar(result).get(Calendar.SECOND));

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setSeconds(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 60);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setSeconds(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), -1);
            }
        });
    }

    @Test
    public void testSetMilliseconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setMilliseconds(date, 999);
        assertEquals(999, DateUtils.toCalendar(result).get(Calendar.MILLISECOND));

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMilliseconds(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 1000);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMilliseconds(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), -1);
            }
        });
    }

    @Test
    public void testSetMonths() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setMonths(date, 11);
        assertEquals(Calendar.DECEMBER, DateUtils.toCalendar(result).get(Calendar.MONTH));

        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMonths(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), 12);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMonths(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), -1);
            }
        });
    }

    @Test
    public void testSetYears() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.setYears(date, 1999);
        assertEquals(1999, DateUtils.toCalendar(result).get(Calendar.YEAR));
    }

    @Test
    public void testSetMethodsNullThrowsNpe() {
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setDays(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setHours(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMinutes(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setSeconds(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMilliseconds(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setMonths(null, 1);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.setYears(null, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // toCalendar
    // ---------------------------------------------------------------

    @Test
    public void testToCalendar() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    public void testToCalendarWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date, cal.getTime());
        assertEquals(tz, cal.getTimeZone());
    }

    @Test
    public void testToCalendarNullThrowsNpe() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.toCalendar(null);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.toCalendar(date, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // toLocalDateTime / toOffsetDateTime / toZonedDateTime
    // ---------------------------------------------------------------

    @Test
    public void testToLocalDateTime() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        LocalDateTime result = DateUtils.toLocalDateTime(date);
        LocalDateTime expected = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        assertEquals(expected, result);
    }

    @Test
    public void testToLocalDateTimeWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        LocalDateTime result = DateUtils.toLocalDateTime(date, tz);
        LocalDateTime expected = LocalDateTime.ofInstant(date.toInstant(), tz.toZoneId());
        assertEquals(expected, result);
    }

    @Test
    public void testToLocalDateTimeNullTimeZoneMapsToDefault() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        LocalDateTime withNullTz = DateUtils.toLocalDateTime(date, null);
        LocalDateTime defaultResult = DateUtils.toLocalDateTime(date);
        assertEquals(defaultResult, withNullTz);
    }

    @Test
    public void testToOffsetDateTime() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        OffsetDateTime result = DateUtils.toOffsetDateTime(date);
        OffsetDateTime expected = OffsetDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        assertEquals(expected, result);
    }

    @Test
    public void testToOffsetDateTimeWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        OffsetDateTime result = DateUtils.toOffsetDateTime(date, tz);
        OffsetDateTime expected = OffsetDateTime.ofInstant(date.toInstant(), tz.toZoneId());
        assertEquals(expected, result);
    }

    @Test
    public void testToOffsetDateTimeNullTimeZoneMapsToDefault() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        OffsetDateTime withNullTz = DateUtils.toOffsetDateTime(date, null);
        OffsetDateTime defaultResult = DateUtils.toOffsetDateTime(date);
        assertEquals(defaultResult, withNullTz);
    }

    @Test
    public void testToZonedDateTime() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        ZonedDateTime result = DateUtils.toZonedDateTime(date);
        ZonedDateTime expected = ZonedDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        assertEquals(expected, result);
    }

    @Test
    public void testToZonedDateTimeWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        ZonedDateTime result = DateUtils.toZonedDateTime(date, tz);
        ZonedDateTime expected = ZonedDateTime.ofInstant(date.toInstant(), tz.toZoneId());
        assertEquals(expected, result);
    }

    @Test
    public void testToZonedDateTimeNullTimeZoneMapsToDefault() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        ZonedDateTime withNullTz = DateUtils.toZonedDateTime(date, null);
        ZonedDateTime defaultResult = DateUtils.toZonedDateTime(date);
        assertEquals(defaultResult, withNullTz);
    }

    // ---------------------------------------------------------------
    // truncatedCompareTo / truncatedEquals
    // ---------------------------------------------------------------

    @Test
    public void testTruncatedCompareToAndEqualsDates() {
        Date date1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date date2 = newDate(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        Date date3 = newDate(2002, Calendar.MARCH, 29, 0, 0, 0, 0);

        assertEquals(0, DateUtils.truncatedCompareTo(date1, date2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(date1, date2, Calendar.DATE));

        assertTrue(DateUtils.truncatedCompareTo(date1, date2, Calendar.MINUTE) > 0);
        assertFalse(DateUtils.truncatedEquals(date1, date2, Calendar.MINUTE));

        assertTrue(DateUtils.truncatedCompareTo(date1, date3, Calendar.DATE) < 0);
        assertFalse(DateUtils.truncatedEquals(date1, date3, Calendar.DATE));
    }

    @Test
    public void testTruncatedCompareToAndEqualsCalendars() {
        Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 9, 0, 0, 0);

        assertEquals(0, DateUtils.truncatedCompareTo(cal1, cal2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(cal1, cal2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(cal1, cal2, Calendar.HOUR_OF_DAY) > 0);
        assertFalse(DateUtils.truncatedEquals(cal1, cal2, Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncatedCompareToAndEqualsNullThrowsNpe() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncatedCompareTo((Date) null, date, Calendar.DATE);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncatedCompareTo((Calendar) null, cal, Calendar.DATE);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncatedEquals((Date) null, date, Calendar.DATE);
            }
        });
        expectNpe(new Executable() {
            public void execute() throws Throwable {
                DateUtils.truncatedEquals((Calendar) null, cal, Calendar.DATE);
            }
        });
    }
}
