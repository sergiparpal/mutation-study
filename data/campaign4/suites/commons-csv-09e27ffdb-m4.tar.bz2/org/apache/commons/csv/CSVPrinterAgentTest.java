/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

class CSVPrinterAgentTest {

    /** Appendable that is also Closeable and Flushable, tracking state for assertions. */
    private static final class TrackingWriter extends StringWriter implements Closeable, Flushable {
        private boolean closed;
        private int flushCount;

        @Override
        public void close() throws IOException {
            closed = true;
        }

        @Override
        public void flush() {
            flushCount++;
        }
    }

    /** Appendable that always fails, to exercise IOException propagation. */
    private static final class FailingAppendable implements Appendable {
        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }
    }

    private Connection openConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest" + System.nanoTime());
    }

    private ResultSet buildResultSet(final Connection connection) throws SQLException {
        final Statement statement = connection.createStatement();
        statement.execute("CREATE TABLE T (ID INT, NAME VARCHAR(20))");
        statement.execute("INSERT INTO T VALUES (1, 'John')");
        statement.execute("INSERT INTO T VALUES (2, 'Jane')");
        return statement.executeQuery("SELECT ID, NAME FROM T ORDER BY ID");
    }

    @Test
    void constructorNullAppendableThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void constructorNullFormatThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringWriter(), null);
            }
        });
    }

    @Test
    void constructorPrintsHeaderWhenNotSkipped() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        assertEquals("A,B\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void constructorSkipsHeaderWhenRequested() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").setSkipHeaderRecord(true).get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        assertEquals("", writer.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void constructorPrintsHeaderComments() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("line1", "line2").get();
        new CSVPrinter(writer, format);
        assertEquals("# line1\r\n# line2\r\n", writer.toString());
    }

    @Test
    void getOutReturnsUnderlyingAppendable() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertSame(writer, printer.getOut());
    }

    @Test
    void getRecordCountStartsAtZero() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void printQuotesValueContainingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", writer.toString());
    }

    @Test
    void printNullValuePrintsEmpty() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("", writer.toString());
    }

    @Test
    void printSecondValueOnLineIsPrecededByDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", writer.toString());
    }

    @Test
    void printPropagatesIOException() {
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVPrinter printer = new CSVPrinter(new FailingAppendable(), CSVFormat.DEFAULT);
                printer.print("x");
            }
        });
    }

    @Test
    void printlnWritesRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        assertEquals("a\r\n", writer.toString());
        printer.print("b");
        assertEquals("a\r\nb", writer.toString());
    }

    @Test
    void printCommentDoesNothingWhenMarkerNotSet() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", writer.toString());
    }

    @Test
    void printCommentDoesNothingWhenNull() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment(null);
        assertEquals("", writer.toString());
    }

    @Test
    void printCommentWithMarkerSet() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", writer.toString());
    }

    @Test
    void printCommentHandlesEmbeddedLineBreaks() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment("line1\nline2\r\nline3\rline4");
        assertEquals("# line1\r\n# line2\r\n# line3\r\n# line4\r\n", writer.toString());
    }

    @Test
    void printRecordObjectsAddsSeparatorAndIncrementsCount() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordEmptyArrayStillEndsRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordIterable() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordStream() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final Stream<String> stream = Arrays.asList("p", "q").stream();
        printer.printRecord(stream);
        assertEquals("p,q\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordsVarargsFlattensNestedArrays() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "A", "B" }, (Object) new String[] { "1", "2" });
        assertEquals("A,B\r\n1,2\r\n", writer.toString());
    }

    @Test
    void printRecordsIterableOfSimpleObjectsPrintsOneRecordPerElement() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        printer.printRecords(values);
        assertEquals("a\r\nb\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordsStream() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data.stream());
        assertEquals("A,B\r\n1,2\r\n", writer.toString());
    }

    @Test
    void printRecordsResultSet() throws IOException, SQLException {
        final Connection connection = openConnection();
        try {
            final ResultSet resultSet = buildResultSet(connection);
            final StringWriter writer = new StringWriter();
            final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
            printer.printRecords(resultSet);
            assertEquals("1,John\r\n2,Jane\r\n", writer.toString());
            assertEquals(2, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void printRecordsResultSetRespectsMaxRows() throws IOException, SQLException {
        final Connection connection = openConnection();
        try {
            final ResultSet resultSet = buildResultSet(connection);
            final StringWriter writer = new StringWriter();
            final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
            final CSVPrinter printer = new CSVPrinter(writer, format);
            printer.printRecords(resultSet);
            assertEquals("1,John\r\n", writer.toString());
            assertEquals(1, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void printRecordsResultSetWithHeaderTrue() throws IOException, SQLException {
        final Connection connection = openConnection();
        try {
            final ResultSet resultSet = buildResultSet(connection);
            final StringWriter writer = new StringWriter();
            final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
            printer.printRecords(resultSet, true);
            assertEquals("ID,NAME\r\n1,John\r\n2,Jane\r\n", writer.toString());
        } finally {
            connection.close();
        }
    }

    @Test
    void printRecordsResultSetWithHeaderFalseOmitsHeader() throws IOException, SQLException {
        final Connection connection = openConnection();
        try {
            final ResultSet resultSet = buildResultSet(connection);
            final StringWriter writer = new StringWriter();
            final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
            printer.printRecords(resultSet, false);
            assertEquals("1,John\r\n2,Jane\r\n", writer.toString());
        } finally {
            connection.close();
        }
    }

    @Test
    void printHeadersWritesColumnNames() throws IOException, SQLException {
        final Connection connection = openConnection();
        try {
            final ResultSet resultSet = buildResultSet(connection);
            final StringWriter writer = new StringWriter();
            final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
            printer.printHeaders(resultSet);
            assertEquals("ID,NAME\r\n", writer.toString());
            assertEquals(0, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void flushDelegatesToFlushableAppendable() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertEquals(0, writer.flushCount);
        printer.flush();
        assertEquals(1, writer.flushCount);
    }

    @Test
    void closeWithoutFlushDoesNotFlushByDefault() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close();
        assertTrue(writer.closed);
        assertEquals(0, writer.flushCount);
    }

    @Test
    void closeWithFlushTrueFlushesBeforeClosing() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close(true);
        assertTrue(writer.closed);
        assertEquals(1, writer.flushCount);
    }

    @Test
    void closeHonorsAutoFlushFormatSetting() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.close(false);
        assertTrue(writer.closed);
        assertEquals(1, writer.flushCount);
    }

    @Test
    void closeOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("x");
        printer.close();
        assertEquals("x", sb.toString());
    }

    @Test
    void multipleRecordsIncrementRecordCount() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord("a");
        printer.printRecord("b");
        printer.printRecord("c");
        assertEquals(3, printer.getRecordCount());
        assertEquals("a\r\nb\r\nc\r\n", writer.toString());
    }

    @Test
    void newRecordStateAfterConstructionIsTrueSoFirstPrintHasNoLeadingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("first");
        assertFalse(writer.toString().startsWith(","));
        assertEquals("first", writer.toString());
    }

    @Test
    void printCommentAfterPrintStartsOnNewLine() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.print("value");
        printer.printComment("note");
        assertEquals("value\r\n# note\r\n", writer.toString());
    }

    @Test
    void getRecordCountNotIncrementedByComments() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment("a");
        printer.printComment("b");
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void printRecordWithNullElementInArray() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord("a", null, "c");
        assertEquals("a,,c\r\n", writer.toString());
    }

    @Test
    void formatPassedToConstructorIsCopiedNotSharedMutation() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setHeader("A");
        final CSVFormat format = builder.get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        assertNotNull(printer.getOut());
        assertEquals("A\r\n", writer.toString());
    }
}
