package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Converter}, based solely on its documented contract.
 */
public class ConverterAgentTest {

    // ---------------------------------------------------------------
    // Functional interface shape
    // ---------------------------------------------------------------

    @Test
    public void testIsInterface() {
        assertTrue(Converter.class.isInterface());
    }

    @Test
    public void testIsAnnotatedFunctionalInterface() {
        assertTrue(Converter.class.isAnnotationPresent(FunctionalInterface.class));
    }

    @Test
    public void testHasExactlyOneAbstractMethodNamedApply() {
        Method[] methods = Converter.class.getMethods();
        int abstractCount = 0;
        String abstractName = null;
        for (int i = 0; i < methods.length; i++) {
            if (Modifier.isAbstract(methods[i].getModifiers())) {
                abstractCount++;
                abstractName = methods[i].getName();
            }
        }
        assertEquals(1, abstractCount);
        assertEquals("apply", abstractName);
    }

    // ---------------------------------------------------------------
    // Custom implementations (anonymous classes), verifying the general contract
    // ---------------------------------------------------------------

    @Test
    public void testCustomImplementationAppliesConversion() throws Exception {
        Converter<Integer, NumberFormatException> lengthConverter = new Converter<Integer, NumberFormatException>() {
            @Override
            public Integer apply(String string) {
                return string.length();
            }
        };
        Integer result = lengthConverter.apply("hello");
        assertEquals(5, result.intValue());
    }

    @Test
    public void testCustomImplementationPropagatesDeclaredCheckedException() {
        Converter<String, IOException> failingConverter = new Converter<String, IOException>() {
            @Override
            public String apply(String string) throws IOException {
                throw new IOException("boom: " + string);
            }
        };
        IOException thrown = assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                failingConverter.apply("input");
            }
        });
        assertEquals("boom: input", thrown.getMessage());
    }

    @Test
    public void testCustomImplementationReceivesExactArgument() throws Exception {
        final String[] captured = new String[1];
        Converter<Void, RuntimeException> capturingConverter = new Converter<Void, RuntimeException>() {
            @Override
            public Void apply(String string) {
                captured[0] = string;
                return null;
            }
        };
        Void result = capturingConverter.apply("exact-argument");
        assertEquals("exact-argument", captured[0]);
        assertEquals(null, result);
    }

    // ---------------------------------------------------------------
    // DEFAULT
    // ---------------------------------------------------------------

    @SuppressWarnings("unchecked")
    @Test
    public void testDefaultConverterDoesNothing() {
        Converter<Object, RuntimeException> defaultConverter = (Converter<Object, RuntimeException>) Converter.DEFAULT;
        Object result = defaultConverter.apply("unchanged-value");
        assertEquals("unchanged-value", result);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDefaultConverterFieldIsStableReference() {
        Converter<Object, RuntimeException> first = (Converter<Object, RuntimeException>) Converter.DEFAULT;
        Converter<Object, RuntimeException> second = (Converter<Object, RuntimeException>) Converter.DEFAULT;
        assertSame(first, second);
    }

    // ---------------------------------------------------------------
    // CLASS
    // ---------------------------------------------------------------

    @Test
    public void testClassConverterResolvesKnownClass() throws ClassNotFoundException {
        Class<?> result = Converter.CLASS.apply("java.lang.String");
        assertSame(String.class, result);
    }

    @Test
    public void testClassConverterThrowsForUnknownClass() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.package.NoSuchClassAtAll");
            }
        });
    }

    // ---------------------------------------------------------------
    // FILE
    // ---------------------------------------------------------------

    @Test
    public void testFileConverterCreatesFileWithGivenPath() throws NullPointerException {
        File result = Converter.FILE.apply("some-file.txt");
        assertEquals(new File("some-file.txt"), result);
    }

    @Test
    public void testFileConverterThrowsNullPointerExceptionForNullInput() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // PATH
    // ---------------------------------------------------------------

    @Test
    public void testPathConverterResolvesGivenPath() throws InvalidPathException {
        Path result = Converter.PATH.apply("some/relative/path");
        assertEquals(Paths.get("some/relative/path"), result);
    }

    @Test
    public void testPathConverterThrowsForInvalidPath() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("bad\u0000path");
            }
        });
    }

    // ---------------------------------------------------------------
    // NUMBER
    // ---------------------------------------------------------------

    @Test
    public void testNumberConverterParsesIntegerAsLong() throws NumberFormatException {
        Number result = Converter.NUMBER.apply("123");
        assertTrue(result instanceof Long);
        assertEquals(123L, result.longValue());
    }

    @Test
    public void testNumberConverterParsesDecimalAsDouble() throws NumberFormatException {
        Number result = Converter.NUMBER.apply("123.45");
        assertTrue(result instanceof Double);
        assertEquals(123.45d, result.doubleValue(), 0.0001d);
    }

    @Test
    public void testNumberConverterThrowsForNonNumericString() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    // ---------------------------------------------------------------
    // OBJECT
    // ---------------------------------------------------------------

    @Test
    public void testObjectConverterInstantiatesClassByName() throws ReflectiveOperationException {
        Object result = Converter.OBJECT.apply("java.util.ArrayList");
        assertTrue(result instanceof ArrayList);
        assertEquals(0, ((ArrayList<?>) result).size());
    }

    @Test
    public void testObjectConverterThrowsForUnknownClassName() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.package.NoSuchClassAtAll");
            }
        });
    }

    // ---------------------------------------------------------------
    // URL
    // ---------------------------------------------------------------

    @Test
    public void testUrlConverterParsesValidUrl() throws MalformedURLException {
        URL result = Converter.URL.apply("https://example.com/path");
        assertEquals("example.com", result.getHost());
        assertEquals("https", result.getProtocol());
        assertEquals("/path", result.getPath());
    }

    @Test
    public void testUrlConverterThrowsForMalformedUrl() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url with no protocol");
            }
        });
    }

    // ---------------------------------------------------------------
    // DATE
    // ---------------------------------------------------------------

    @Test
    public void testDateConverterParsesDocumentedFormat() throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        Calendar calendar = Calendar.getInstance();
        calendar.set(2020, Calendar.JANUARY, 15, 10, 30, 45);
        calendar.set(Calendar.MILLISECOND, 0);
        Date expected = calendar.getTime();
        String formatted = format.format(expected);

        Date result = Converter.DATE.apply(formatted);

        assertEquals(expected, result);
    }

    @Test
    public void testDateConverterThrowsForUnparsableString() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("this is not a date");
            }
        });
    }

    // ---------------------------------------------------------------
    // Sanity: static converter fields are distinct instances
    // ---------------------------------------------------------------

    @Test
    public void testStaticConvertersAreAllNonNullAndDistinct() {
        Object[] converters = new Object[] {
            Converter.DEFAULT, Converter.CLASS, Converter.FILE, Converter.PATH,
            Converter.NUMBER, Converter.OBJECT, Converter.URL, Converter.DATE
        };
        for (int i = 0; i < converters.length; i++) {
            assertNotNull(converters[i]);
            for (int j = i + 1; j < converters.length; j++) {
                assertFalse(converters[i] == converters[j]);
            }
        }
    }
}
