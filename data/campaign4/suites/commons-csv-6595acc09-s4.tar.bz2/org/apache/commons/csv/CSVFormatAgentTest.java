package org.apache.commons.csv;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CSVFormatAgentTest {

    private enum SampleHeader {
        Name, Email, Phone
    }

    // ---- Predefined static constants ----

    @Test
    public void testDefaultFormat() {
        CSVFormat f = CSVFormat.DEFAULT;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertTrue(f.isQuoteCharacterSet());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
        assertFalse(f.isEscapeCharacterSet());
        assertFalse(f.isCommentMarkerSet());
        assertFalse(f.isNullStringSet());
        assertNull(f.getHeader());
        assertNull(f.getHeaderComments());
        assertFalse(f.getSkipHeaderRecord());
        assertFalse(f.getTrailingDelimiter());
        assertFalse(f.getTrim());
        assertFalse(f.getAutoFlush());
        assertFalse(f.getIgnoreHeaderCase());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getAllowMissingColumnNames());
        assertFalse(f.getLenientEof());
        assertFalse(f.getTrailingData());
        assertEquals(0L, f.getMaxRows());
        assertNull(f.getQuoteMode());
    }

    @Test
    public void testExcelFormat() {
        CSVFormat f = CSVFormat.EXCEL;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
        assertFalse(f.getIgnoreEmptyLines());
        assertTrue(f.getAllowMissingColumnNames());
        assertTrue(f.getTrailingData());
        assertTrue(f.getLenientEof());
    }

    @Test
    public void testRfc4180Format() {
        CSVFormat f = CSVFormat.RFC4180;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
    }

    @Test
    public void testInformixUnloadFormat() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", f.getDelimiterString());
        assertTrue(f.isEscapeCharacterSet());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", f.getDelimiterString());
        assertFalse(f.isEscapeCharacterSet());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
    }

    @Test
    public void testMongoDbCsvFormat() {
        CSVFormat f = CSVFormat.MONGODB_CSV;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFormat() {
        CSVFormat f = CSVFormat.MONGODB_TSV;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
        assertFalse(f.getSkipHeaderRecord());
    }

    @Test
    public void testMysqlFormat() {
        CSVFormat f = CSVFormat.MYSQL;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.isQuoteCharacterSet());
        assertNull(f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertTrue(f.isNullStringSet());
        assertEquals("\\N", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testOracleFormat() {
        CSVFormat f = CSVFormat.ORACLE;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertTrue(f.isNullStringSet());
        assertEquals("\\N", f.getNullString());
        assertTrue(f.getTrim());
        assertEquals(System.lineSeparator(), f.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testPostgresqlCsvFormat() {
        CSVFormat f = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", f.getDelimiterString());
        assertFalse(f.isEscapeCharacterSet());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertTrue(f.isNullStringSet());
        assertEquals("", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testPostgresqlTextFormat() {
        CSVFormat f = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.isQuoteCharacterSet());
        assertEquals("\n", f.getRecordSeparator());
        assertTrue(f.isNullStringSet());
        assertEquals("\\N", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testTdfFormat() {
        CSVFormat f = CSVFormat.TDF;
        assertEquals("\t", f.getDelimiterString());
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    // ---- newFormat ----

    @Test
    public void testNewFormatInitialState() {
        CSVFormat f = CSVFormat.newFormat(';');
        assertEquals(";", f.getDelimiterString());
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
        assertNull(f.getCommentMarker());
        assertFalse(f.isCommentMarkerSet());
        assertNull(f.getEscapeCharacter());
        assertFalse(f.isEscapeCharacterSet());
        assertNull(f.getHeader());
        assertNull(f.getHeaderComments());
        assertNull(f.getRecordSeparator());
        assertNull(f.getNullString());
        assertFalse(f.isNullStringSet());
        assertNull(f.getQuoteMode());
        assertNull(f.getDuplicateHeaderMode());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.getSkipHeaderRecord());
        assertFalse(f.getAllowMissingColumnNames());
        assertFalse(f.getTrailingDelimiter());
        assertFalse(f.getTrim());
        assertFalse(f.getAutoFlush());
        assertFalse(f.getIgnoreHeaderCase());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getLenientEof());
        assertFalse(f.getTrailingData());
        assertEquals(0L, f.getMaxRows());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // ---- valueOf ----

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        CSVFormat defaultFormat = CSVFormat.valueOf("Default");
        assertEquals(",", defaultFormat.getDelimiterString());
        assertTrue(defaultFormat.getIgnoreEmptyLines());

        CSVFormat tdfFormat = CSVFormat.valueOf("TDF");
        assertEquals("\t", tdfFormat.getDelimiterString());
    }

    @Test
    public void testValueOfRejectsUnknownName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.valueOf("NotAFormat");
            }
        });
    }

    @Test
    public void testValueOfRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.valueOf(null);
            }
        });
    }

    // ---- Predefined enum ----

    @Test
    public void testPredefinedValuesCount() {
        assertEquals(12, CSVFormat.Predefined.values().length);
    }

    @Test
    public void testPredefinedGetFormatMatchesConstants() {
        assertEquals(CSVFormat.DEFAULT.getDelimiterString(), CSVFormat.Predefined.Default.getFormat().getDelimiterString());
        assertEquals(CSVFormat.EXCEL.getLenientEof(), CSVFormat.Predefined.Excel.getFormat().getLenientEof());
        assertEquals(CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter(), CSVFormat.Predefined.InformixUnload.getFormat().getEscapeCharacter());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV.isEscapeCharacterSet(), CSVFormat.Predefined.InformixUnloadCsv.getFormat().isEscapeCharacterSet());
        assertEquals(CSVFormat.MONGODB_CSV.getQuoteMode(), CSVFormat.Predefined.MongoDBCsv.getFormat().getQuoteMode());
        assertEquals(CSVFormat.MONGODB_TSV.getDelimiterString(), CSVFormat.Predefined.MongoDBTsv.getFormat().getDelimiterString());
        assertEquals(CSVFormat.MYSQL.getNullString(), CSVFormat.Predefined.MySQL.getFormat().getNullString());
        assertEquals(CSVFormat.ORACLE.getTrim(), CSVFormat.Predefined.Oracle.getFormat().getTrim());
        assertEquals(CSVFormat.POSTGRESQL_CSV.getNullString(), CSVFormat.Predefined.PostgreSQLCsv.getFormat().getNullString());
        assertEquals(CSVFormat.POSTGRESQL_TEXT.getNullString(), CSVFormat.Predefined.PostgreSQLText.getFormat().getNullString());
        assertEquals(CSVFormat.RFC4180.getIgnoreEmptyLines(), CSVFormat.Predefined.RFC4180.getFormat().getIgnoreEmptyLines());
        assertEquals(CSVFormat.TDF.getIgnoreSurroundingSpaces(), CSVFormat.Predefined.TDF.getFormat().getIgnoreSurroundingSpaces());
    }

    @Test
    public void testPredefinedValueOf() {
        assertSame(CSVFormat.Predefined.Default, CSVFormat.Predefined.valueOf("Default"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.Predefined.valueOf("Bogus");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.Predefined.valueOf(null);
            }
        });
    }

    // ---- Builder ----

    @Test
    public void testBuilderFluentReturnsThis() {
        CSVFormat.Builder b = CSVFormat.DEFAULT.builder();
        assertSame(b, b.setDelimiter(';'));
        assertSame(b, b.setQuote('\''));
        assertSame(b, b.setHeader("a", "b"));
    }

    @Test
    public void testBuilderCreateDefaults() {
        CSVFormat f = CSVFormat.Builder.create().get();
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testBuilderCreateFromFormat() {
        CSVFormat f = CSVFormat.Builder.create(CSVFormat.MYSQL).get();
        assertEquals(CSVFormat.MYSQL.getDelimiterString(), f.getDelimiterString());
        assertEquals(CSVFormat.MYSQL.getEscapeCharacter(), f.getEscapeCharacter());
        assertEquals(CSVFormat.MYSQL.getNullString(), f.getNullString());
    }

    @Test
    public void testBuilderGetAndBuildEquivalent() {
        CSVFormat.Builder b = CSVFormat.DEFAULT.builder().setDelimiter(';');
        CSVFormat f1 = b.get();
        CSVFormat f2 = b.build();
        assertNotSame(f1, f2);
        assertEquals(f1.getDelimiterString(), f2.getDelimiterString());
    }

    @Test
    public void testBuilderImplementsSupplier() {
        Supplier<CSVFormat> supplier = CSVFormat.DEFAULT.builder();
        CSVFormat f = supplier.get();
        assertNotNull(f);
        assertEquals(",", f.getDelimiterString());
    }

    @Test
    public void testBuilderCreatesNewInstanceEachCall() {
        assertNotSame(CSVFormat.DEFAULT.builder(), CSVFormat.DEFAULT.builder());
    }

    @Test
    public void testBuilderSetDelimiterChar() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(";", f.getDelimiterString());
    }

    @Test
    public void testBuilderSetDelimiterStringMultiChar() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("||", f.getDelimiterString());
    }

    @Test
    public void testBuilderSetCommentMarker() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(f.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), f.getCommentMarker());

        CSVFormat f2 = f.builder().setCommentMarker((Character) null).get();
        assertFalse(f2.isCommentMarkerSet());
        assertNull(f2.getCommentMarker());
    }

    @Test
    public void testBuilderSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setCommentMarker(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testBuilderSetEscape() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertTrue(f.isEscapeCharacterSet());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());

        CSVFormat f2 = f.builder().setEscape((Character) null).get();
        assertFalse(f2.isEscapeCharacterSet());
        assertNull(f2.getEscapeCharacter());
    }

    @Test
    public void testBuilderSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setEscape('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setEscape(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testBuilderSetQuote() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setQuote('\'').get();
        assertTrue(f.isQuoteCharacterSet());
        assertEquals(Character.valueOf('\''), f.getQuoteCharacter());

        CSVFormat f2 = f.builder().setQuote((Character) null).get();
        assertFalse(f2.isQuoteCharacterSet());
        assertNull(f2.getQuoteCharacter());
    }

    @Test
    public void testBuilderSetQuoteMode() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL_NON_NULL).get();
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testBuilderSetDuplicateHeaderMode() {
        CSVFormat f = CSVFormat.newFormat(',').builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testBuilderSetNullString() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(f.isNullStringSet());
        assertEquals("NULL", f.getNullString());

        CSVFormat f2 = f.builder().setNullString(null).get();
        assertFalse(f2.isNullStringSet());
        assertNull(f2.getNullString());
    }

    @Test
    public void testBuilderSetRecordSeparatorCharAndString() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setRecordSeparator('\n').get();
        assertEquals("\n", f.getRecordSeparator());

        CSVFormat f2 = CSVFormat.DEFAULT.builder().setRecordSeparator("\r\n").get();
        assertEquals("\r\n", f2.getRecordSeparator());
    }

    @Test
    public void testBuilderSetSkipHeaderRecord() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setSkipHeaderRecord(true).get();
        assertTrue(f.getSkipHeaderRecord());
    }

    @Test
    public void testBuilderSetTrailingDelimiter() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        assertTrue(f.getTrailingDelimiter());
    }

    @Test
    public void testBuilderSetTrim() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertTrue(f.getTrim());
    }

    @Test
    public void testBuilderSetAutoFlush() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        assertTrue(f.getAutoFlush());
    }

    @Test
    public void testBuilderSetIgnoreHeaderCase() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(true).get();
        assertTrue(f.getIgnoreHeaderCase());
    }

    @Test
    public void testBuilderSetIgnoreSurroundingSpaces() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testBuilderSetIgnoreEmptyLines() {
        CSVFormat f = CSVFormat.RFC4180.builder().setIgnoreEmptyLines(true).get();
        assertTrue(f.getIgnoreEmptyLines());
    }

    @Test
    public void testBuilderSetAllowMissingColumnNames() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).get();
        assertTrue(f.getAllowMissingColumnNames());
    }

    @Test
    public void testBuilderSetLenientEof() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        assertTrue(f.getLenientEof());
    }

    @Test
    public void testBuilderSetTrailingData() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        assertTrue(f.getTrailingData());
    }

    @Test
    public void testBuilderSetMaxRows() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertEquals(5L, f.getMaxRows());

        CSVFormat f2 = CSVFormat.DEFAULT.builder().setMaxRows(-100).get();
        assertEquals(-100L, f2.getMaxRows());

        CSVFormat f3 = CSVFormat.DEFAULT.builder().setMaxRows(0).get();
        assertEquals(0L, f3.getMaxRows());
    }

    @Test
    public void testBuilderSetHeaderVarargsDefensiveCopy() {
        String[] headers = {"a", "b"};
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader(headers).get();
        headers[0] = "zzz";
        assertArrayEquals(new String[] {"a", "b"}, f.getHeader());

        String[] got = f.getHeader();
        got[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, f.getHeader());
    }

    @Test
    public void testBuilderSetHeaderNoArgsIsEmptyArray() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(f.getHeader());
        assertEquals(0, f.getHeader().length);
    }

    @Test
    public void testBuilderSetHeaderNullDisables() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader((String[]) null).get();
        assertNull(f.getHeader());
    }

    @Test
    public void testBuilderSetHeaderFromEnum() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader(SampleHeader.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, f.getHeader());
    }

    @Test
    public void testBuilderSetHeaderCommentsObjectOverloadDefensiveCopy() {
        Object[] comments = {"line1", Integer.valueOf(42)};
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeaderComments(comments).get();
        assertArrayEquals(new String[] {"line1", "42"}, f.getHeaderComments());

        comments[0] = "mutated";
        assertArrayEquals(new String[] {"line1", "42"}, f.getHeaderComments());
    }

    @Test
    public void testBuilderSetHeaderCommentsStringOverload() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeaderComments("a", "b").get();
        assertArrayEquals(new String[] {"a", "b"}, f.getHeaderComments());
    }

    // ---- equals / hashCode / toString ----

    @Test
    public void testEqualsReflexiveAndTypeSafety() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
    }

    @Test
    public void testHashCodeConsistent() {
        int h1 = CSVFormat.DEFAULT.hashCode();
        int h2 = CSVFormat.DEFAULT.hashCode();
        assertEquals(h1, h2);
    }

    @Test
    public void testToStringNotNullAndConsistent() {
        String s = CSVFormat.DEFAULT.toString();
        assertNotNull(s);
        assertEquals(s, CSVFormat.DEFAULT.toString());
    }

    // ---- copy / clone (package-private) ----

    @Test
    public void testCopyInstanceMethod() {
        CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("N/A").get();
        CSVFormat copy = original.copy();
        assertNotSame(original, copy);
        assertEquals(original.getDelimiterString(), copy.getDelimiterString());
        assertEquals(original.getNullString(), copy.getNullString());
    }

    @Test
    public void testStaticCopyNullSafe() {
        assertNull(CSVFormat.copy(null));
        CSVFormat copy = CSVFormat.copy(CSVFormat.MYSQL);
        assertNotNull(copy);
        assertEquals(CSVFormat.MYSQL.getDelimiterString(), copy.getDelimiterString());
    }

    @Test
    public void testCloneNullSafeArray() {
        assertNull(CSVFormat.clone((String[]) null));
        String[] src = {"a", "b"};
        String[] cloned = CSVFormat.clone(src);
        assertNotSame(src, cloned);
        assertArrayEquals(src, cloned);
    }

    @Test
    public void testGetDelimiterCharArray() {
        assertArrayEquals(new char[] {','}, CSVFormat.DEFAULT.getDelimiterCharArray());
    }

    @Test
    public void testGetEscapeCharDefaultsToZero() {
        assertEquals(0, CSVFormat.newFormat(';').getEscapeChar());
    }

    @Test
    public void testGetEscapeCharWhenSet() {
        CSVFormat f = CSVFormat.newFormat(',').builder().setEscape('\\').get();
        assertEquals('\\', f.getEscapeChar());
    }

    // ---- Immutability of shared static constants ----

    @Test
    public void testPredefinedConstantIsNotMutatedByWithMethods() {
        CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    public void testPredefinedConstantIsNotMutatedByBuilder() {
        CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    // ---- Deprecated "with" methods ----

    @Test
    public void testDeprecatedGetDelimiter() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        CSVFormat f = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals('|', f.getDelimiter());
    }

    @Test
    public void testWithDelimiter() {
        CSVFormat f = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", f.getDelimiterString());
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithEscape() {
        CSVFormat f = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        CSVFormat f2 = CSVFormat.DEFAULT.withEscape((Character) null);
        assertNull(f2.getEscapeCharacter());
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withEscape('\n');
            }
        });
    }

    @Test
    public void testWithCommentMarker() {
        CSVFormat f = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), f.getCommentMarker());
        CSVFormat f2 = CSVFormat.DEFAULT.withCommentMarker((Character) null);
        assertNull(f2.getCommentMarker());
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withCommentMarker('\n');
            }
        });
    }

    @Test
    public void testWithQuote() {
        CSVFormat f = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), f.getQuoteCharacter());
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withQuote('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withQuote(Character.valueOf('\n'));
            }
        });
    }

    @Test
    public void testWithQuoteMode() {
        CSVFormat f = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testWithNullString() {
        CSVFormat f = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", f.getNullString());
        assertTrue(f.isNullStringSet());
    }

    @Test
    public void testWithRecordSeparatorCharAndString() {
        CSVFormat f = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", f.getRecordSeparator());
        CSVFormat f2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", f2.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorStringRejectsInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withRecordSeparator("xyz");
            }
        });
    }

    @Test
    public void testWithSkipHeaderRecord() {
        CSVFormat f = CSVFormat.DEFAULT.withSkipHeaderRecord();
        assertTrue(f.getSkipHeaderRecord());
        CSVFormat f2 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
        assertFalse(f2.getSkipHeaderRecord());
    }

    @Test
    public void testWithSystemRecordSeparator() {
        CSVFormat f = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), f.getRecordSeparator());
    }

    @Test
    public void testWithTrailingDelimiter() {
        CSVFormat f = CSVFormat.DEFAULT.withTrailingDelimiter();
        assertTrue(f.getTrailingDelimiter());
        CSVFormat f2 = CSVFormat.DEFAULT.withTrailingDelimiter(false);
        assertFalse(f2.getTrailingDelimiter());
    }

    @Test
    public void testWithTrim() {
        CSVFormat f = CSVFormat.DEFAULT.withTrim();
        assertTrue(f.getTrim());
        CSVFormat f2 = CSVFormat.DEFAULT.withTrim(false);
        assertFalse(f2.getTrim());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        CSVFormat f = CSVFormat.RFC4180.withIgnoreEmptyLines();
        assertTrue(f.getIgnoreEmptyLines());
        CSVFormat f2 = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
        assertFalse(f2.getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        CSVFormat f = CSVFormat.DEFAULT.withIgnoreHeaderCase();
        assertTrue(f.getIgnoreHeaderCase());
        CSVFormat f2 = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
        assertFalse(f2.getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        CSVFormat f = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces();
        assertTrue(f.getIgnoreSurroundingSpaces());
        CSVFormat f2 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
        assertFalse(f2.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        CSVFormat f = CSVFormat.DEFAULT.withAllowMissingColumnNames();
        assertTrue(f.getAllowMissingColumnNames());
        CSVFormat f2 = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
        assertFalse(f2.getAllowMissingColumnNames());
    }

    @Test
    public void testWithAutoFlush() {
        CSVFormat f = CSVFormat.DEFAULT.withAutoFlush(true);
        assertTrue(f.getAutoFlush());
    }

    @Test
    public void testWithHeaderVarargs() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader("a", "b", "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, f.getHeader());
    }

    @Test
    public void testWithHeaderEnum() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader(SampleHeader.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, f.getHeader());
    }

    @Test
    public void testWithHeaderComments() {
        CSVFormat f = CSVFormat.DEFAULT.withHeaderComments("Generated", Integer.valueOf(7));
        assertArrayEquals(new String[] {"Generated", "7"}, f.getHeaderComments());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        CSVFormat f = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(f.getHeader());
        assertEquals(0, f.getHeader().length);
        assertTrue(f.getSkipHeaderRecord());
    }

    @Test
    public void testWithAllowDuplicateHeaderNames() {
        CSVFormat f = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames();
        assertTrue(f.getAllowDuplicateHeaderNames());
        CSVFormat f2 = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(f2.getAllowDuplicateHeaderNames());
    }

    // ---- format / print / println / printRecord ----

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    public void testPrintlnOutputsRecordSeparatorOnly() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnOutputsTrailingDelimiterWhenSet() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        f.println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testPrintValueTrimsAndHandlesNewRecordFlag() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrim(true).get();
        f.print("first", sb, true);
        f.print(" second ", sb, false);
        assertEquals("first,second", sb.toString());
    }

    @Test
    public void testPrintToAppendableReturnsNonNullPrinter() throws IOException {
        CSVPrinter printer = CSVFormat.DEFAULT.print(new StringWriter());
        assertNotNull(printer);
    }

    @Test
    public void testPrinterReturnsNonNull() throws IOException {
        CSVPrinter printer = CSVFormat.DEFAULT.printer();
        assertNotNull(printer);
    }

    @Test
    public void testPrintToFileReturnsNonNullPrinter() throws IOException {
        File tempFile = File.createTempFile("csvformat-agent-test", ".csv");
        tempFile.deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(tempFile, java.nio.charset.StandardCharsets.UTF_8);
        assertNotNull(printer);
    }

    @Test
    public void testPrintToPathReturnsNonNullPrinter() throws IOException {
        File tempFile = File.createTempFile("csvformat-agent-test", ".csv");
        tempFile.deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(tempFile.toPath(), java.nio.charset.StandardCharsets.UTF_8);
        assertNotNull(printer);
    }

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n"));
        assertNotNull(parser);
    }
}
