package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    // ---------------------------------------------------------------
    // Constructor (public, deprecated, but part of the API contract)
    // ---------------------------------------------------------------

    @Test
    public void testConstructorIsUsable() {
        assertNotNull(new NumberUtils());
    }

    // ---------------------------------------------------------------
    // compare(...)
    // ---------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("10.25"), NumberUtils.createBigDecimal("10.25"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("abc");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createDouble
    // ---------------------------------------------------------------

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createFloat
    // ---------------------------------------------------------------

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongSuffix() {
        Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        Number n = NumberUtils.createNumber("1.2f");
        assertTrue(n instanceof Float);
        assertEquals(1.2f, n.floatValue(), 0.0001f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        Number n = NumberUtils.createNumber("1.2d");
        assertTrue(n instanceof Double);
        assertEquals(1.2d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberHex() {
        Number n = NumberUtils.createNumber("0x1A");
        assertEquals(26, n.intValue());
        Number neg = NumberUtils.createNumber("-0x1A");
        assertEquals(-26, neg.intValue());
    }

    @Test
    public void testCreateNumberLeadingZeroOctal() {
        Number n = NumberUtils.createNumber("010");
        assertEquals(8, n.intValue());
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("abc");
            }
        });
    }

    @Test
    public void testCreateNumberDoesNotTrim() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber(" 123");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("123 ");
            }
        });
    }

    // ---------------------------------------------------------------
    // isCreatable / isNumber (deprecated)
    // ---------------------------------------------------------------

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertTrue(NumberUtils.isCreatable("9"));
        assertTrue(NumberUtils.isCreatable("0.1"));
        assertTrue(NumberUtils.isCreatable("0x1F"));
        assertTrue(NumberUtils.isCreatable("123L"));
    }

    @Test
    public void testIsNumberDeprecated() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertFalse(NumberUtils.isNumber("09"));
        assertTrue(NumberUtils.isNumber("9"));
        assertTrue(NumberUtils.isNumber("0x1F"));
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("abc"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertTrue(NumberUtils.isDigits("12345"));
    }

    // ---------------------------------------------------------------
    // isParsable
    // ---------------------------------------------------------------

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("abc"));
        assertTrue(NumberUtils.isParsable("1"));
        assertTrue(NumberUtils.isParsable("1.1"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("+Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
    }

    // ---------------------------------------------------------------
    // max(array) / max(a,b,c) - byte
    // ---------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 7, NumberUtils.max(new byte[] {7}));
        assertEquals((byte) 9, NumberUtils.max(new byte[] {1, 9, 4}));
    }

    @Test
    public void testMaxByteArrayNullAndEmpty() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(9, NumberUtils.max(new int[] {1, 9, 4}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(9L, NumberUtils.max(new long[] {1L, 9L, 4L}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertEquals((short) 9, NumberUtils.max(new short[] {1, 9, 4}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMaxFloat() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0f);
        assertEquals(9.0f, NumberUtils.max(new float[] {1.0f, 9.0f, 4.0f}), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
        assertEquals(Float.POSITIVE_INFINITY, NumberUtils.max(1.0f, Float.POSITIVE_INFINITY, 3.0f), 0.0f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMaxDouble() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d), 0.0d);
        assertEquals(9.0d, NumberUtils.max(new double[] {1.0d, 9.0d, 4.0d}), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
        assertEquals(Double.POSITIVE_INFINITY, NumberUtils.max(1.0d, Double.POSITIVE_INFINITY, 3.0d), 0.0d);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // min(array) / min(a,b,c)
    // ---------------------------------------------------------------

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min(new byte[] {4, 1, 9}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(1, NumberUtils.min(new int[] {4, 1, 9}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertEquals(1L, NumberUtils.min(new long[] {4L, 1L, 9L}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertEquals((short) 1, NumberUtils.min(new short[] {4, 1, 9}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    public void testMinFloat() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0f);
        assertEquals(1.0f, NumberUtils.min(new float[] {4.0f, 1.0f, 9.0f}), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
        assertEquals(Float.NEGATIVE_INFINITY, NumberUtils.min(1.0f, Float.NEGATIVE_INFINITY, 3.0f), 0.0f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    public void testMinDouble() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 5.0d, 3.0d), 0.0d);
        assertEquals(1.0d, NumberUtils.min(new double[] {4.0d, 1.0d, 9.0d}), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
        assertEquals(Double.NEGATIVE_INFINITY, NumberUtils.min(1.0d, Double.NEGATIVE_INFINITY, 3.0d), 0.0d);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // toByte
    // ---------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("abc"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("abc", (byte) 9));
    }

    // ---------------------------------------------------------------
    // toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("abc"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---------------------------------------------------------------
    // toFloat
    // ---------------------------------------------------------------

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("abc"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // ---------------------------------------------------------------
    // toInt
    // ---------------------------------------------------------------

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("abc"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
    }

    // ---------------------------------------------------------------
    // toLong
    // ---------------------------------------------------------------

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("abc"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    // ---------------------------------------------------------------
    // toShort
    // ---------------------------------------------------------------

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("abc"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal(BigDecimal.valueOf(2.5d)));
        assertEquals(new BigDecimal("2.00"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.005")));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 0, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("2"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 0, RoundingMode.DOWN));
    }

    @Test
    public void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d)));
    }

    @Test
    public void testToScaledBigDecimalDoubleWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d), 0, RoundingMode.HALF_UP));
    }

    @Test
    public void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f)));
    }

    @Test
    public void testToScaledBigDecimalFloatWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f), 0, RoundingMode.HALF_UP));
    }

    @Test
    public void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal("2.5"));
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal("2.5", 0, RoundingMode.HALF_UP));
    }
}
