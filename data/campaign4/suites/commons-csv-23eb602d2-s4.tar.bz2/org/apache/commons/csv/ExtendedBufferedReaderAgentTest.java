package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link ExtendedBufferedReader} based on its documented contract.
 */
public class ExtendedBufferedReaderAgentTest {

    @Test
    public void testInitialStateBeforeAnyRead() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0L, reader.getPosition());
        assertEquals(0L, reader.getLineNumber());
        assertEquals(0L, reader.getBytesRead());
        final int lastChar = reader.getLastChar();
        // Constants.UNDEFINED must not look like a character actually read (0..65535).
        assertTrue(lastChar < 0 || lastChar > 65535);
        reader.close();
    }

    @Test
    public void testReadSingleCharUpdatesStateAndReturnsCharValue() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("AB"));

        final int c1 = reader.read();
        assertEquals((int) 'A', c1);
        assertEquals((int) 'A', reader.getLastChar());
        assertEquals(1L, reader.getPosition());

        final int c2 = reader.read();
        assertEquals((int) 'B', c2);
        assertEquals((int) 'B', reader.getLastChar());
        assertEquals(2L, reader.getPosition());

        final int c3 = reader.read();
        assertEquals(-1, c3);
        assertEquals(-1, reader.getLastChar());
        assertEquals(2L, reader.getPosition());

        reader.close();
    }

    @Test
    public void testReadCharArrayFillsBufferAndTracksPosition() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("Hello"));
        final char[] buf = new char[5];

        final int n = reader.read(buf, 0, 5);
        assertEquals(5, n);
        assertArrayEquals("Hello".toCharArray(), buf);
        assertEquals(5L, reader.getPosition());
        assertEquals((int) 'o', reader.getLastChar());

        final int eof = reader.read(buf, 0, 5);
        assertEquals(-1, eof);

        reader.close();
    }

    @Test
    public void testReadCharArrayWithOffsetReadsAvailableCharsThenEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("XY"));
        final char[] buf = new char[5];
        buf[0] = 'Z';
        buf[1] = 'Z';

        final int n = reader.read(buf, 2, 3);
        assertEquals(2, n);
        assertEquals('X', buf[2]);
        assertEquals('Y', buf[3]);
        assertEquals(2L, reader.getPosition());
        assertEquals((int) 'Y', reader.getLastChar());

        final int eof = reader.read(buf, 0, 1);
        assertEquals(-1, eof);

        reader.close();
    }

    @Test
    public void testReadCharArrayZeroLengthReturnsZeroAndReadsNothing() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("X"));
        final char[] buf = new char[3];

        final int n = reader.read(buf, 0, 0);
        assertEquals(0, n);
        assertEquals(0L, reader.getPosition());

        reader.close();
    }

    @Test
    public void testReadCharArrayNegativeOffsetThrowsIndexOutOfBounds() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        final char[] buf = new char[4];

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, -1, 2);
            }
        });

        reader.close();
    }

    @Test
    public void testReadCharArrayNegativeLengthThrowsIndexOutOfBounds() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        final char[] buf = new char[4];

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, 0, -1);
            }
        });

        reader.close();
    }

    @Test
    public void testReadCharArrayLengthBeyondBufferThrowsIndexOutOfBounds() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        final char[] buf = new char[4];

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, 2, 3);
            }
        });

        reader.close();
    }

    @Test
    public void testReadLineDropsTerminatorAndTracksLineNumberAndPosition() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2\nline3"));

        assertEquals(0L, reader.getLineNumber());

        final String l1 = reader.readLine();
        assertEquals("line1", l1);
        assertEquals(1L, reader.getLineNumber());
        assertEquals((int) '\n', reader.getLastChar());
        assertEquals(6L, reader.getPosition());

        final String l2 = reader.readLine();
        assertEquals("line2", l2);
        assertEquals(2L, reader.getLineNumber());
        assertEquals(12L, reader.getPosition());

        final String l3 = reader.readLine();
        assertEquals("line3", l3);
        assertEquals(-1, reader.getLastChar());

        final String l4 = reader.readLine();
        assertNull(l4);

        reader.close();
    }

    @Test
    public void testReadLineWithCrLfTerminatorEndsOnLastEolChar() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("foo\r\nbar"));

        final String l1 = reader.readLine();
        assertEquals("foo", l1);
        assertEquals((int) '\n', reader.getLastChar());
        assertEquals(5L, reader.getPosition());

        final String l2 = reader.readLine();
        assertEquals("bar", l2);
        assertEquals(-1, reader.getLastChar());

        reader.close();
    }

    @Test
    public void testReadLineOnEmptyStreamReturnsNull() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertNull(reader.readLine());
        reader.close();
    }

    @Test
    public void testGetBytesReadDefaultConstructorStaysZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        assertEquals(0L, reader.getBytesRead());

        while (reader.read() != -1) {
            // consume the whole stream
        }

        assertEquals(0L, reader.getBytesRead());
        reader.close();
    }

    @Test
    public void testGetBytesReadWithTrackingEnabledAndCharsetCountsAsciiBytes() throws IOException {
        final ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);

        assertEquals(0L, reader.getBytesRead());

        reader.read();
        reader.read();
        reader.read();

        assertEquals(3L, reader.getBytesRead());
        reader.close();
    }

    @Test
    public void testGetBytesReadTrackingEnabledButNullCharsetStaysZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), null, true);

        while (reader.read() != -1) {
            // consume the whole stream
        }

        assertEquals(0L, reader.getBytesRead());
        reader.close();
    }

    @Test
    public void testGetBytesReadTrackingDisabledWithCharsetStaysZero() throws IOException {
        final ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);

        while (reader.read() != -1) {
            // consume the whole stream
        }

        assertEquals(0L, reader.getBytesRead());
        reader.close();
    }

    @Test
    public void testMarkAndResetRestoresStreamPosition() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));

        final int first = reader.read();
        assertEquals((int) 'a', first);

        reader.mark(10);

        final int second = reader.read();
        assertEquals((int) 'b', second);
        final int third = reader.read();
        assertEquals((int) 'c', third);

        reader.reset();

        final int afterReset = reader.read();
        assertEquals((int) 'b', afterReset);

        reader.close();
    }

    @Test
    public void testResetWithoutPriorMarkThrowsIOException() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));

        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.reset();
            }
        });

        reader.close();
    }

    @Test
    public void testCloseThenReadThrowsIOException() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        reader.close();

        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }
}
