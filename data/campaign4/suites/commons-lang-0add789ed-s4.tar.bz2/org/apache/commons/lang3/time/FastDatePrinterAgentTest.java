package org.apache.commons.lang3.time;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for FastDatePrinter, based solely on its documented
 * public/package/protected contract (api/org/apache/commons/lang3/time/FastDatePrinter.html).
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar utcCalendar(int year, int month, int day,
                                         int hour, int minute, int second, int millis) {
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(year, month - 1, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static FastDatePrinter printer(String pattern, TimeZone tz, Locale locale) {
        return new FastDatePrinter(pattern, tz, locale);
    }

    // ---- construction -----------------------------------------------------

    @Test
    public void testConstructorNullPatternThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                new FastDatePrinter(null, UTC, Locale.US);
            }
        });
    }

    @Test
    public void testConstructorNullTimeZoneThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                new FastDatePrinter("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    public void testConstructorNullLocaleThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                new FastDatePrinter("yyyy", UTC, null);
            }
        });
    }

    @Test
    public void testConstructorInvalidPatternThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new FastDatePrinter("'unterminated", UTC, Locale.US);
            }
        });
    }

    // ---- simple getters -----------------------------------------------------

    @Test
    public void testGetPattern() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", p.getPattern());
    }

    @Test
    public void testGetTimeZone() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(UTC, p.getTimeZone());
    }

    @Test
    public void testGetLocale() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertEquals(Locale.FRANCE, p.getLocale());
    }

    // ---- format(Date) / format(Calendar) / format(long) --------------------

    @Test
    public void testFormatDate() {
        FastDatePrinter p = printer("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        Date date = utcCalendar(2023, 6, 15, 13, 45, 30, 123).getTime();
        assertEquals("2023-06-15T13:45:30", p.format(date));
    }

    @Test
    public void testFormatCalendar() {
        FastDatePrinter p = printer("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, 6, 15, 13, 45, 30, 123);
        assertEquals("2023-06-15T13:45:30", p.format(cal));
    }

    @Test
    public void testFormatLong() {
        FastDatePrinter p = printer("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        long millis = utcCalendar(2023, 6, 15, 13, 45, 30, 123).getTimeInMillis();
        assertEquals("2023-06-15T13:45:30", p.format(millis));
    }

    @Test
    public void testFormatMilliseconds() {
        FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss.SSS", UTC, Locale.US);
        Date date = utcCalendar(2023, 6, 15, 13, 45, 30, 123).getTime();
        assertEquals("2023-06-15 13:45:30.123", p.format(date));
    }

    // ---- format(..., StringBuffer) appends and returns same reference ------

    @Test
    public void testFormatDateIntoStringBuffer() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        StringBuffer buf = new StringBuffer("PRE:");
        StringBuffer result = p.format(date, buf);
        assertSame(buf, result);
        assertEquals("PRE:2023-06-15", buf.toString());
    }

    @Test
    public void testFormatCalendarIntoStringBuffer() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, 6, 15, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer("PRE:");
        StringBuffer result = p.format(cal, buf);
        assertSame(buf, result);
        assertEquals("PRE:2023-06-15", buf.toString());
    }

    @Test
    public void testFormatLongIntoStringBuffer() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        long millis = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTimeInMillis();
        StringBuffer buf = new StringBuffer("PRE:");
        StringBuffer result = p.format(millis, buf);
        assertSame(buf, result);
        assertEquals("PRE:2023-06-15", buf.toString());
    }

    // ---- format(..., B extends Appendable) ----------------------------------

    @Test
    public void testFormatDateIntoAppendable() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        StringBuilder sb = new StringBuilder("PRE:");
        StringBuilder result = p.format(date, sb);
        assertSame(sb, result);
        assertEquals("PRE:2023-06-15", result.toString());
    }

    @Test
    public void testFormatCalendarIntoAppendable() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, 6, 15, 0, 0, 0, 0);
        StringBuilder sb = new StringBuilder("PRE:");
        StringBuilder result = p.format(cal, sb);
        assertSame(sb, result);
        assertEquals("PRE:2023-06-15", result.toString());
    }

    @Test
    public void testFormatLongIntoAppendable() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        long millis = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTimeInMillis();
        StringBuilder sb = new StringBuilder("PRE:");
        StringBuilder result = p.format(millis, sb);
        assertSame(sb, result);
        assertEquals("PRE:2023-06-15", result.toString());
    }

    // ---- pattern semantics documented in the class javadoc -------------------

    @Test
    public void testYearPatternTruncationVsJava7YBehavior() {
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        assertEquals("2023", printer("yyyy", UTC, Locale.US).format(date));
        assertEquals("23", printer("yy", UTC, Locale.US).format(date));
        // "Starting with Java 1.7 a pattern of 'Y' or 'YYY' will be formatted as '2003'"
        assertEquals("2023", printer("YYY", UTC, Locale.US).format(date));
    }

    @Test
    public void testRfc822TimeZonePattern() {
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        assertEquals("+0000", printer("Z", UTC, Locale.US).format(date));
    }

    @Test
    public void testIso8601ExtendedTimeZonePattern() {
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        assertEquals("+00:00", printer("ZZ", UTC, Locale.US).format(date));
    }

    @Test
    public void testIso8601XTimeZonePattern() {
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        assertEquals("Z", printer("X", UTC, Locale.US).format(date));
    }

    @Test
    public void testLocaleDependentTextFields() {
        Date date = utcCalendar(2023, 6, 15, 13, 45, 0, 0).getTime();
        assertEquals("Thursday, June 15, 2023",
                printer("EEEE, MMMM d, yyyy", UTC, Locale.US).format(date));
        assertEquals("AD", printer("G", UTC, Locale.US).format(date));
        assertEquals("PM", printer("a", UTC, Locale.US).format(date));
    }

    @Test
    public void testQuotedLiteralText() {
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        assertEquals("Year:2023", printer("'Year:'yyyy", UTC, Locale.US).format(date));
        // SimpleDateFormat-compatible: two consecutive single quotes mean a literal quote.
        assertEquals("2023'", printer("yyyy''", UTC, Locale.US).format(date));
    }

    @Test
    public void testPatternWithOnlyLiteralTextIgnoresDate() {
        FastDatePrinter p = printer("'Hello'", UTC, Locale.US);
        Date d1 = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        Date d2 = utcCalendar(1999, 1, 1, 0, 0, 0, 0).getTime();
        assertEquals("Hello", p.format(d1));
        assertEquals("Hello", p.format(d2));
    }

    // ---- getMaxLengthEstimate -------------------------------------------------

    @Test
    public void testGetMaxLengthEstimateIsPositiveUpperBound() {
        FastDatePrinter p = printer("yyyy-MM-dd'T'HH:mm:ss.SSSZ", UTC, Locale.US);
        int estimate = p.getMaxLengthEstimate();
        assertTrue(estimate > 0);
        Date date = utcCalendar(2023, 6, 15, 13, 45, 30, 123).getTime();
        String formatted = p.format(date);
        assertTrue(formatted.length() <= estimate,
                "formatted length " + formatted.length() + " should be <= estimate " + estimate);
    }

    // ---- equals / hashCode / toString -----------------------------------------

    @Test
    public void testEqualsReflexive() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(p, p);
    }

    @Test
    public void testEqualsSameConfigurationAreEqualWithMatchingHashCode() {
        FastDatePrinter p1 = printer("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        FastDatePrinter p2 = printer("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    public void testEqualsDifferentPattern() {
        FastDatePrinter p1 = printer("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = printer("yyyy/MM/dd", UTC, Locale.US);
        assertNotEquals(p1, p2);
    }

    @Test
    public void testEqualsDifferentTimeZone() {
        FastDatePrinter p1 = printer("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = printer("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        assertNotEquals(p1, p2);
    }

    @Test
    public void testEqualsDifferentLocale() {
        FastDatePrinter p1 = printer("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = printer("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertNotEquals(p1, p2);
    }

    @Test
    public void testEqualsNullAndDifferentType() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(p.equals(null));
        assertFalse(p.equals("yyyy-MM-dd"));
    }

    @Test
    public void testToStringIsNonEmptyDebugString() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        String s = p.toString();
        assertNotNull(s);
        assertFalse(s.isEmpty());
    }

    // ---- package-private / protected members, reachable from same package ----

    @Test
    public void testFormatObjectDispatchesToDateCalendarAndLong() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, 6, 15, 0, 0, 0, 0);
        Date date = cal.getTime();
        long millis = cal.getTimeInMillis();

        assertEquals(p.format(date), p.format((Object) date));
        assertEquals(p.format(cal), p.format((Object) cal));
        assertEquals(p.format(millis), p.format((Object) Long.valueOf(millis)));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testDeprecatedFormatObjectStringBufferFieldPosition() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Date date = utcCalendar(2023, 6, 15, 0, 0, 0, 0).getTime();
        StringBuffer buf = new StringBuffer("X:");
        FieldPosition pos = new FieldPosition(0);
        StringBuffer result = p.format((Object) date, buf, pos);
        assertSame(buf, result);
        assertEquals("X:2023-06-15", buf.toString());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testDeprecatedApplyRulesAppliesToSuppliedBuffer() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, 6, 15, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer("PRE:");
        StringBuffer result = p.applyRules(cal, buf);
        assertSame(buf, result);
        assertEquals("PRE:2023-06-15", buf.toString());
    }

    @Test
    public void testParsePatternReturnsNonEmptyRuleList() {
        FastDatePrinter p = printer("yyyy-MM-dd", UTC, Locale.US);
        List<?> rules = p.parsePattern();
        assertNotNull(rules);
        assertFalse(rules.isEmpty());
    }

    @Test
    public void testParseTokenGroupsRepeatedPatternLetters() {
        FastDatePrinter p = printer("yyyy", UTC, Locale.US);
        int[] indexRef = new int[] {0};
        String token = p.parseToken("yyyyMMdd", indexRef);
        assertEquals("yyyy", token);
    }

    @Test
    public void testParseTokenSingleNonLetterCharacter() {
        FastDatePrinter p = printer("yyyy", UTC, Locale.US);
        int[] indexRef = new int[] {0};
        String token = p.parseToken("-MM", indexRef);
        assertEquals("-", token);
    }

    @Test
    public void testSelectNumberRuleReturnsNewRuleEachCall() {
        FastDatePrinter p = printer("yyyy", UTC, Locale.US);
        Object rule1 = p.selectNumberRule(Calendar.YEAR, 4);
        Object rule2 = p.selectNumberRule(Calendar.YEAR, 4);
        assertNotNull(rule1);
        assertNotNull(rule2);
        assertNotSame(rule1, rule2);
    }

    @Test
    public void testGetTimeZoneDisplayStyleVariesOutput() {
        TimeZone ny = TimeZone.getTimeZone("America/New_York");
        String longName = FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.LONG, Locale.US);
        String shortName = FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.SHORT, Locale.US);
        assertNotNull(longName);
        assertFalse(longName.isEmpty());
        assertNotNull(shortName);
        assertFalse(shortName.isEmpty());
        assertNotEquals(longName, shortName);
    }

    @Test
    public void testClearDoesNotChangeTimeZoneDisplayResult() {
        TimeZone ny = TimeZone.getTimeZone("America/New_York");
        String before = FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.LONG, Locale.US);
        FastDatePrinter.clear();
        String after = FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.LONG, Locale.US);
        assertEquals(before, after);
    }

    // ---- field constants ------------------------------------------------------

    @Test
    public void testStyleFieldConstantsAreDistinct() {
        assertNotEquals(FastDatePrinter.FULL, FastDatePrinter.LONG);
        assertNotEquals(FastDatePrinter.LONG, FastDatePrinter.MEDIUM);
        assertNotEquals(FastDatePrinter.MEDIUM, FastDatePrinter.SHORT);
    }
}
