/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar toCalendar(final Date date) {
        final Calendar calendar = new GregorianCalendar(GMT, Locale.US);
        calendar.setTime(date);
        return calendar;
    }

    @Test
    void testAdjustYearBelowStartYearRollsIntoNextCentury() throws ParseException {
        final Date centuryStart = new GregorianCalendar(1960, Calendar.JANUARY, 1, 0, 0, 0).getTime();
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryStart);
        final Date date = parser.parse("30");
        assertEquals(2030, toCalendar(date).get(Calendar.YEAR));
    }

    @Test
    void testAdjustYearAtOrAboveStartYearStaysInCentury() throws ParseException {
        final Date centuryStart = new GregorianCalendar(1960, Calendar.JANUARY, 1, 0, 0, 0).getTime();
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryStart);
        final Date date = parser.parse("70");
        assertEquals(1970, toCalendar(date).get(Calendar.YEAR));
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructorNullLocaleUsesDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testConstructorRejectsUnsupportedPatternLetter() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd'Q'q", GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsUnterminatedQuote() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd'", GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsTooManyXTokens() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-ddXXXX", GMT, Locale.US);
            }
        });
    }

    @Test
    void testGettersReturnConstructorValues() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(GMT, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final TimeZone mutable = TimeZone.getTimeZone("GMT");
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", mutable, Locale.US);
        final TimeZone returned = parser.getTimeZone();
        returned.setRawOffset(123456);
        assertEquals(0, parser.getTimeZone().getRawOffset());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser differentPattern = new FastDateParser("MM/dd/yyyy", GMT, Locale.US);
        final FastDateParser differentLocale = new FastDateParser("yyyy-MM-dd", GMT, Locale.FRANCE);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, differentPattern);
        assertNotEquals(p1, differentLocale);
        assertNotEquals(p1, null);
        assertNotEquals(p1, "not a parser");
    }

    @Test
    void testToStringAndToStringAllContainPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertTrue(parser.toString().contains("yyyy-MM-dd"));
        assertTrue(parser.toStringAll().contains("yyyy-MM-dd"));
    }

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2017-06-15");
        final Calendar calendar = toCalendar(date);
        assertEquals(2017, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException thrown = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertEquals(0, thrown.getErrorOffset());
    }

    @Test
    void testParseWithParsePositionReturnsNullAndSetsErrorIndexOnMismatch() {
        final FastDateParser parser = new FastDateParser("MM-dd-yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("03/23/1961", pos);
        assertNull(date);
        assertEquals(2, pos.getErrorIndex());
        assertEquals(2, pos.getIndex());
    }

    @Test
    void testParseWithParsePositionBeyondSourceLengthReturnsNull() {
        final FastDateParser parser = new FastDateParser("MM/dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        assertNull(parser.parse("03/23", pos));
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParsePartialInputLeavesIndexAtConsumedPosition() {
        final FastDateParser parser = new FastDateParser("MM/dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("03/23/1961", pos);
        assertNotNull(date);
        assertEquals(5, pos.getIndex());
    }

    @Test
    void testParseWithCalendarOverloadUpdatesSuppliedCalendar() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Calendar calendar = new GregorianCalendar(GMT, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("2020-01-02", pos, calendar);
        assertTrue(success);
        assertEquals(2020, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, calendar.get(Calendar.MONTH));
        assertEquals(2, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithCalendarOverloadReturnsFalseOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Calendar calendar = new GregorianCalendar(GMT, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("garbage", pos, calendar);
        assertFalse(success);
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object parsed = parser.parseObject("2017-06-15");
        assertTrue(parsed instanceof Date);
        assertEquals(2017, toCalendar((Date) parsed).get(Calendar.YEAR));
    }

    @Test
    void testParseObjectWithParsePositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object parsed = parser.parseObject("bad-input", pos);
        assertNull(parsed);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testParseTwoDigitHourBoundaries() throws ParseException {
        final FastDateParser hour24Parser = new FastDateParser("kk:mm", GMT, Locale.US);
        final Calendar midnightAs24 = toCalendar(hour24Parser.parse("24:00"));
        assertEquals(0, midnightAs24.get(Calendar.HOUR_OF_DAY));

        final FastDateParser hour12Parser = new FastDateParser("hh:mm", GMT, Locale.US);
        final Calendar noonAs12 = toCalendar(hour12Parser.parse("12:00"));
        assertEquals(0, noonAs12.get(Calendar.HOUR));
    }

    @Test
    void testParseLiteralQuotedText() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy'-T-'MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2017-T-06-15");
        final Calendar calendar = toCalendar(date);
        assertEquals(2017, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseLiteralQuotedTextMismatchFails() {
        final FastDateParser parser = new FastDateParser("yyyy'-T-'MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("2017-X-06-15", pos));
        assertEquals(5, pos.getErrorIndex());
    }

    @Test
    void testParseDayOfWeekTextStrategy() throws ParseException {
        final FastDateParser parser = new FastDateParser("EEEE, MM/dd/yyyy", GMT, Locale.US);
        final Date date = parser.parse("Thursday, 06/15/2017");
        final Calendar calendar = toCalendar(date);
        assertEquals(Calendar.THURSDAY, calendar.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testParseDayOfWeekTextStrategyInvalidNameFails() {
        final FastDateParser parser = new FastDateParser("EEEE, MM/dd/yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("Blursday, 06/15/2017", pos));
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testParseOverflowingNumericFieldFails() {
        final FastDateParser parser = new FastDateParser("yyyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        // 19 digits overflows int, must be reported as a parse failure, not an uncaught NumberFormatException
        assertNull(parser.parse("9999999999999999999", pos));
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testJapaneseImperialLocaleParseFailureMessageMentionsEpoch() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, new Locale("ja", "JP", "JP"));
        final ParseException thrown = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("abcd-01-01");
            }
        });
        assertTrue(thrown.getMessage().contains("1868-01-01"));
    }

    @Test
    void testWeekYearPatternResolvesThroughWeekDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", GMT, Locale.US);
        final Date date = parser.parse("2017-W03-2");
        final Calendar calendar = new GregorianCalendar(GMT, Locale.US);
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.setMinimalDaysInFirstWeek(4);
        calendar.setTime(date);
        assertEquals(2017, calendar.getWeekYear());
        assertEquals(3, calendar.get(Calendar.WEEK_OF_YEAR));
        assertEquals(Calendar.TUESDAY, calendar.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, deserialized);
        final Date date = deserialized.parse("2021-12-25");
        final Calendar calendar = toCalendar(date);
        assertEquals(2021, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, calendar.get(Calendar.MONTH));
        assertEquals(25, calendar.get(Calendar.DAY_OF_MONTH));
    }
}
