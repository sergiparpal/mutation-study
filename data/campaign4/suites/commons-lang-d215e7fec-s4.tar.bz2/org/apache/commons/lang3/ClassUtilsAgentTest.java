package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ClassUtilsAgentTest {

    interface FixtureInterfaceA {
    }

    interface FixtureInterfaceB extends FixtureInterfaceA {
    }

    static class FixtureBase implements FixtureInterfaceB {
    }

    static class FixtureMiddle extends FixtureBase {
    }

    static class FixtureChild extends FixtureMiddle {
    }

    private static class FixturePrivate {
    }

    private static List<Class<?>> drain(Iterable<Class<?>> iterable) {
        List<Class<?>> result = new ArrayList<Class<?>>();
        Iterator<Class<?>> iterator = iterable.iterator();
        while (iterator.hasNext()) {
            result.add(iterator.next());
        }
        return result;
    }

    @Test
    public void testFieldConstants() {
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
    }

    @Test
    public void testDeprecatedPublicConstructor() {
        ClassUtils instance = new ClassUtils();
        assertNotNull(instance);
        assertTrue(instance instanceof ClassUtils);
    }

    @Test
    public void testComparator() {
        Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Boolean.class);
        list.add(Integer.class);
        Collections.sort(list, comparator);
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    @Test
    public void testConvertClassesToClassNamesNullInput() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNamesEmpty() {
        List<Class<?>> classes = new ArrayList<Class<?>>();
        List<String> result = ClassUtils.convertClassesToClassNames(classes);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testConvertClassesToClassNamesWithNullElement() {
        List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        List<String> result = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, result.size());
        assertEquals("java.lang.String", result.get(0));
        assertNull(result.get(1));
    }

    @Test
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void testConvertClassesToClassNamesClassCastException() {
        List raw = new ArrayList();
        raw.add("notAClass");
        final List<Class<?>> badList = raw;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.convertClassesToClassNames(badList);
            }
        });
    }

    @Test
    public void testConvertClassNamesToClassesNullInput() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClassesWithNullAndUnknown() {
        List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add(null);
        names.add("does.not.exist.Unknown");
        List<Class<?>> result = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, result.size());
        assertEquals(String.class, result.get(0));
        assertNull(result.get(1));
        assertNull(result.get(2));
    }

    @Test
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void testConvertClassNamesToClassesClassCastException() {
        List raw = new ArrayList();
        raw.add(Integer.valueOf(1));
        final List<String> badList = raw;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.convertClassNamesToClasses(badList);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameClassInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, -1);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameClassConsistentWithStringVariant() {
        String fromClass = ClassUtils.getAbbreviatedName(String.class, 5);
        String fromName = ClassUtils.getAbbreviatedName(String.class.getName(), 5);
        assertEquals(fromName, fromClass);
        assertEquals("j.l.String", fromClass);
    }

    @Test
    public void testGetAbbreviatedNameStringNullInput() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameStringExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameStringInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", -5);
            }
        });
    }

    @Test
    public void testGetAllInterfacesNullInput() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfacesOrder() {
        List<Class<?>> interfaces = ClassUtils.getAllInterfaces(FixtureMiddle.class);
        assertEquals(Arrays.asList(FixtureInterfaceB.class, FixtureInterfaceA.class), interfaces);
    }

    @Test
    public void testGetAllSuperclassesNullInput() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclassesOrder() {
        List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(FixtureChild.class);
        assertEquals(Arrays.asList(FixtureMiddle.class, FixtureBase.class, Object.class), superclasses);
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    public void testGetCanonicalNameClassWithDefault() {
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "N/A"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    @Test
    public void testGetCanonicalNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello", "N/A"));
    }

    @Test
    public void testGetClassWithClassLoader() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", true));
    }

    @Test
    public void testGetClassArraySyntax() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String[].class, ClassUtils.getClass(loader, "java.lang.String[]"));
        assertEquals(String[].class, ClassUtils.getClass(loader, "[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassInnerClassSyntax() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass(loader, "java.util.Map.Entry"));
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass(loader, "java.util.Map$Entry"));
    }

    @Test
    public void testGetClassWhitespaceNormalization() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, " java.lang.String "));
    }

    @Test
    public void testGetClassNullNameThrowsNullPointerException() {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassUnknownThrowsClassNotFoundException() {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertThrows(ClassNotFoundException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, "does.not.exist.Unknown");
            }
        });
    }

    @Test
    public void testGetClassCurrentContextClassLoaderVariant() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", false));
    }

    @Test
    public void testGetClassStrictNormal() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClassStrict(loader, "java.lang.String", true));
        assertEquals(String.class, ClassUtils.getClassStrict("java.lang.String"));
    }

    @Test
    public void testGetClassStrictDoesNotNormalizeWhitespace() {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertThrows(ClassNotFoundException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClassStrict(loader, " java.lang.String ", true);
            }
        });
        assertThrows(ClassNotFoundException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClassStrict(" java.lang.String ");
            }
        });
    }

    @Test
    @SuppressWarnings("rawtypes")
    public void testGetComponentType() {
        Class arrayType = String[].class;
        Class componentType = ClassUtils.getComponentType(arrayType);
        assertEquals(String.class, componentType);

        Class nonArrayType = String.class;
        assertNull(ClassUtils.getComponentType(nonArrayType));

        Class nullType = null;
        assertNull(ClassUtils.getComponentType(nullType));
    }

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameClassWithDefault() {
        assertEquals("N/A", ClassUtils.getName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "N/A"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
    }

    @Test
    public void testGetNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName("hello", "N/A"));
    }

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hello", "N/A"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
    }

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageName("hello", "N/A"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
    }

    @Test
    public void testGetPrimitiveClass() {
        assertEquals(byte.class, ClassUtils.getPrimitiveClass("byte"));
        assertEquals(int.class, ClassUtils.getPrimitiveClass("int"));
        assertEquals(boolean.class, ClassUtils.getPrimitiveClass("boolean"));
        assertEquals(double.class, ClassUtils.getPrimitiveClass("double"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        Set<Object> set = Collections.unmodifiableSet(new HashSet<Object>());
        Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty", new Class[0]);
        assertNotNull(method);
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        Object result = method.invoke(set, new Object[0]);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    public void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExist", new Class[0]);
            }
        });
    }

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
    }

    @Test
    public void testGetShortCanonicalNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getShortCanonicalName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hello", "N/A"));
    }

    @Test
    public void testGetShortCanonicalNameStringExamples() {
        String mapEntryName = java.util.Map.Entry.class.getName();
        String mapEntryCanonical = java.util.Map.Entry.class.getCanonicalName();
        String intArrayCanonical = int[].class.getCanonicalName();
        String intArrayName = int[].class.getName();

        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("Map.Entry", ClassUtils.getShortCanonicalName(mapEntryName));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(mapEntryCanonical));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[]"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[][]"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(intArrayCanonical));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(intArrayName));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("[[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("int[]"));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("int[][]"));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(java.util.Map.Entry.class));
    }

    @Test
    public void testGetShortClassNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getShortClassName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "N/A"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(java.util.Map.Entry.class.getName()));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameClassWithDefault() {
        assertEquals("N/A", ClassUtils.getSimpleName((Class<?>) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName(String.class, "N/A"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
    }

    @Test
    public void testGetSimpleNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getSimpleName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName("hello", "N/A"));
    }

    @Test
    public void testHierarchyExcludingInterfaces() {
        List<Class<?>> list = drain(ClassUtils.hierarchy(FixtureChild.class));
        assertEquals(Arrays.asList(FixtureChild.class, FixtureMiddle.class, FixtureBase.class, Object.class), list);

        List<Class<?>> listExplicitExclude =
                drain(ClassUtils.hierarchy(FixtureChild.class, ClassUtils.Interfaces.EXCLUDE));
        assertEquals(list, listExplicitExclude);
    }

    @Test
    public void testHierarchyIncludingInterfaces() {
        List<Class<?>> list = drain(ClassUtils.hierarchy(FixtureChild.class, ClassUtils.Interfaces.INCLUDE));
        assertTrue(list.contains(FixtureChild.class));
        assertTrue(list.contains(FixtureMiddle.class));
        assertTrue(list.contains(FixtureBase.class));
        assertTrue(list.contains(Object.class));
        assertTrue(list.contains(FixtureInterfaceA.class));
        assertTrue(list.contains(FixtureInterfaceB.class));
    }

    @Test
    public void testIsAssignableBasic() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertFalse(ClassUtils.isAssignable(Object.class, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
        assertTrue(ClassUtils.isAssignable(int.class, long.class, false));
    }

    @Test
    public void testIsAssignableArray() {
        Class<?>[] from = new Class<?>[]{Integer.class, int.class};
        Class<?>[] to = new Class<?>[]{Number.class, Integer.class};
        assertTrue(ClassUtils.isAssignable(from, to));
        assertTrue(ClassUtils.isAssignable(from, Number.class, Integer.class));
    }

    @Test
    public void testIsAssignableArrayAutoboxing() {
        Class<?>[] from = new Class<?>[]{int.class};
        Class<?>[] to = new Class<?>[]{Integer.class};
        assertTrue(ClassUtils.isAssignable(from, to, true));
        assertFalse(ClassUtils.isAssignable(from, to, false));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(ClassUtilsAgentTest.class));
        assertTrue(ClassUtils.isInnerClass(FixtureBase.class));
        assertTrue(ClassUtils.isInnerClass(FixturePrivate.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(boolean.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(FixturePrivate.class));
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers(new Class<?>[0]).length);

        Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, boolean.class, String.class);
        assertEquals(3, result.length);
        assertEquals(Integer.class, result[0]);
        assertEquals(Boolean.class, result[1]);
        assertEquals(String.class, result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass(new Object[0]).length);

        Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertEquals(3, result.length);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives(new Class<?>[0]).length);

        Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, Boolean.class, String.class);
        assertEquals(3, result.length);
        assertEquals(int.class, result[0]);
        assertEquals(boolean.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }
}
