/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    public interface AgentPublicIface {
        void doStuff();
    }

    static class AgentPackagePrivateImpl implements AgentPublicIface {
        @Override
        public void doStuff() {
            // empty
        }
    }

    interface AgentIfaceTop {
        // empty
    }

    interface AgentIfaceMid extends AgentIfaceTop {
        // empty
    }

    static class AgentGrandParent {
        // empty
    }

    static class AgentParent extends AgentGrandParent {
        // empty
    }

    static class AgentChild extends AgentParent implements AgentIfaceMid {
        // empty
    }

    static class AgentNested {
        // empty
    }

    private static <T> List<T> toList(final Iterable<T> iterable) {
        final List<T> result = new ArrayList<T>();
        final Iterator<T> it = iterable.iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        return result;
    }

    @Test
    void testComparator() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(Integer.class);
        classes.add(Boolean.class);
        java.util.Collections.sort(classes, ClassUtils.comparator());
        assertEquals(Boolean.class, classes.get(0));
        assertEquals(Integer.class, classes.get(1));
        assertEquals(String.class, classes.get(2));
    }

    @Test
    void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(input);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> input = new ArrayList<String>();
        input.add("java.lang.String");
        input.add("this.is.not.a.Class");
        input.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(input);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
    }

    @Test
    void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertTrue(interfaces.contains(AgentIfaceMid.class));
        assertTrue(interfaces.contains(AgentIfaceTop.class));
        assertEquals(2, interfaces.size());
    }

    @Test
    void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> supers = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentParent.class, AgentGrandParent.class, Object.class), supers);
    }

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
    }

    @Test
    void testGetClassPrimitivesAndArrays() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
        assertEquals(boolean.class, ClassUtils.getClass("boolean"));
        final Class<?> arrCls1 = ClassUtils.getClass("java.util.Map.Entry[]");
        assertTrue(arrCls1.isArray());
        assertEquals(Map.Entry.class, arrCls1.getComponentType());
        final Class<?> arrCls2 = ClassUtils.getClass("[Ljava.util.Map$Entry;");
        assertTrue(arrCls2.isArray());
        assertEquals(Map.Entry.class, arrCls2.getComponentType());
    }

    @Test
    void testGetClassNullAndNotFound() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("com.example.DoesNotExistReallyAgent123");
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensions() {
        final StringBuilder sb = new StringBuilder("java.lang.String");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    void testGetClassNameTooLong() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        final Class<String[]> arrCls = String[].class;
        assertEquals(String.class, ClassUtils.getComponentType(arrCls));
    }

    @Test
    void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("N/A", ClassUtils.getName((Class<?>) null, "N/A"));
    }

    @Test
    void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
        assertEquals("N/A", ClassUtils.getName((Object) null, "N/A"));
    }

    @Test
    void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("", ClassUtils.getPackageCanonicalName("[I"));
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
    }

    @Test
    void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
    }

    @Test
    void testGetPublicMethod() throws NoSuchMethodException {
        final Method method = ClassUtils.getPublicMethod(AgentPackagePrivateImpl.class, "doStuff");
        assertEquals(AgentPublicIface.class, method.getDeclaringClass());
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(AgentPackagePrivateImpl.class, "thisMethodDoesNotExist");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "doStuff");
            }
        });
    }

    @Test
    void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("N/A", ClassUtils.getShortCanonicalName((Object) null, "N/A"));
    }

    @Test
    void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
        assertEquals("int[][]", ClassUtils.getShortClassName(int[][].class));
        assertEquals("N/A", ClassUtils.getShortClassName((Object) null, "N/A"));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    @Test
    void testGetSimpleName() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("N/A", ClassUtils.getSimpleName((Class<?>) null, "N/A"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
        assertEquals("N/A", ClassUtils.getSimpleName((Object) null, "N/A"));
    }

    @Test
    void testHierarchyExcludeInterfaces() {
        final List<Class<?>> expected = Arrays.<Class<?>>asList(AgentChild.class, AgentParent.class, AgentGrandParent.class, Object.class);
        final List<Class<?>> actual = toList(ClassUtils.hierarchy(AgentChild.class));
        assertEquals(expected, actual);
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final List<Class<?>> expected = Arrays.<Class<?>>asList(AgentChild.class, AgentIfaceMid.class, AgentIfaceTop.class, AgentParent.class,
            AgentGrandParent.class, Object.class);
        final List<Class<?>> actual = toList(ClassUtils.hierarchy(AgentChild.class, Interfaces.INCLUDE));
        assertEquals(expected, actual);
    }

    @Test
    void testIsAssignable() {
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Long.TYPE));
        assertFalse(ClassUtils.isAssignable(Long.TYPE, Integer.TYPE));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, Integer.TYPE));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Integer.class));
        assertFalse(ClassUtils.isAssignable(Integer.TYPE, Integer.class, false));
        assertFalse(ClassUtils.isAssignable(Boolean.TYPE, Integer.TYPE));
    }

    @Test
    void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {Integer.TYPE}, new Class<?>[] {Long.TYPE}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {Integer.TYPE}, new Class<?>[] {Long.TYPE, String.class}));
    }

    @Test
    void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(AgentNested.class));
    }

    @Test
    void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.TYPE));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(Integer.TYPE));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentPackagePrivateImpl.class));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.primitivesToWrappers(empty));
        final Class<?>[] result = ClassUtils.primitivesToWrappers(Integer.TYPE, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(Integer.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        final Class<?>[] empty = ClassUtils.toClass(new Object[0]);
        assertEquals(0, empty.length);
        final Class<?>[] result = ClassUtils.toClass("hello", null, Integer.valueOf(1));
        assertEquals(String.class, result[0]);
        assertNull(result[1]);
        assertEquals(Integer.class, result[2]);
    }

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.wrappersToPrimitives(empty));
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(Integer.TYPE, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(Integer.TYPE, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    void testConstructor() {
        assertNotNull(new ClassUtils());
    }
}
