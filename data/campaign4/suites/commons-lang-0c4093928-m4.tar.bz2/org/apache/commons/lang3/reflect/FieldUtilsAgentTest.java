/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link FieldUtils}.
 */
public class FieldUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    private @interface Marker {
    }

    private interface IfaceA {
        int AMBIGUOUS = 1;
    }

    private interface IfaceB {
        int AMBIGUOUS = 2;
    }

    private interface IfaceC {
        int SOLO = 42;
    }

    private static class AmbiguousFixture implements IfaceA, IfaceB {
    }

    private static class SoloInterfaceFixture implements IfaceC {
    }

    private static class ParentFixture {
        public static int staticPublicField = 10;
        private static int staticPrivateField = 20;
        public static final int STATIC_FINAL_FIELD = 30;

        public int publicField = 1;
        protected int protectedField = 2;
        int packageField = 3;
        private int privateField = 4;
        @Marker
        public int annotatedField = 5;
        public boolean notFinalInstanceField = true;
    }

    private static class ChildFixture extends ParentFixture {
        public int childPublicField = 100;
    }

    // --- getAllFields / getAllFieldsList ---

    @Test
    public void testGetAllFieldsNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getAllFields(null);
            }
        });
    }

    @Test
    public void testGetAllFieldsIncludesInherited() {
        final Field[] fields = FieldUtils.getAllFields(ChildFixture.class);
        assertTrue(containsFieldNamed(fields, "childPublicField"));
        assertTrue(containsFieldNamed(fields, "publicField"));
        assertTrue(containsFieldNamed(fields, "privateField"));
        assertEquals(FieldUtils.getAllFieldsList(ChildFixture.class).size(), fields.length);
    }

    @Test
    public void testGetAllFieldsListNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getAllFieldsList(null);
            }
        });
    }

    private static boolean containsFieldNamed(final Field[] fields, final String name) {
        for (final Field f : fields) {
            if (f.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    // --- getDeclaredField ---

    @Test
    public void testGetDeclaredFieldNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getDeclaredField(null, "publicField");
            }
        });
    }

    @Test
    public void testGetDeclaredFieldBlankName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getDeclaredField(ParentFixture.class, "   ");
            }
        });
    }

    @Test
    public void testGetDeclaredFieldUnknownName() {
        assertNull(FieldUtils.getDeclaredField(ParentFixture.class, "doesNotExist"));
    }

    @Test
    public void testGetDeclaredFieldOnlyConsidersOwnClass() {
        assertNull(FieldUtils.getDeclaredField(ChildFixture.class, "publicField"));
        assertNotNull(FieldUtils.getDeclaredField(ChildFixture.class, "childPublicField"));
    }

    @Test
    public void testGetDeclaredFieldPrivateWithoutForceAccess() {
        assertNull(FieldUtils.getDeclaredField(ParentFixture.class, "privateField", false));
    }

    @Test
    public void testGetDeclaredFieldPrivateWithForceAccess() {
        final Field field = FieldUtils.getDeclaredField(ParentFixture.class, "privateField", true);
        assertNotNull(field);
        assertEquals("privateField", field.getName());
        assertTrue(field.isAccessible());
    }

    // --- getField ---

    @Test
    public void testGetFieldNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getField(null, "publicField");
            }
        });
    }

    @Test
    public void testGetFieldBlankName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getField(ParentFixture.class, "");
            }
        });
    }

    @Test
    public void testGetFieldPublicInSuperclass() {
        final Field field = FieldUtils.getField(ChildFixture.class, "publicField");
        assertNotNull(field);
        assertEquals(ParentFixture.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldPrivateInSuperclassWithoutForceAccess() {
        assertNull(FieldUtils.getField(ChildFixture.class, "privateField", false));
    }

    @Test
    public void testGetFieldPrivateInSuperclassWithForceAccess() {
        final Field field = FieldUtils.getField(ChildFixture.class, "privateField", true);
        assertNotNull(field);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetFieldFromInterface() {
        final Field field = FieldUtils.getField(SoloInterfaceFixture.class, "SOLO");
        assertNotNull(field);
        assertEquals(IfaceC.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldAmbiguousInterfaceThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getField(AmbiguousFixture.class, "AMBIGUOUS");
            }
        });
    }

    // --- getFieldsListWithAnnotation / getFieldsWithAnnotation ---

    @Test
    public void testGetFieldsWithAnnotationNullAnnotation() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getFieldsWithAnnotation(ParentFixture.class, null);
            }
        });
    }

    @Test
    public void testGetFieldsWithAnnotationNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.getFieldsWithAnnotation(null, Marker.class);
            }
        });
    }

    @Test
    public void testGetFieldsWithAnnotationFindsMatch() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(ParentFixture.class, Marker.class);
        assertEquals(1, fields.length);
        assertEquals("annotatedField", fields[0].getName());
        final List<Field> list = FieldUtils.getFieldsListWithAnnotation(ParentFixture.class, Marker.class);
        assertEquals(1, list.size());
    }

    @Test
    public void testGetFieldsWithAnnotationNoMatch() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(ParentFixture.class, Deprecated.class);
        assertEquals(0, fields.length);
    }

    // --- readDeclaredField ---

    @Test
    public void testReadDeclaredFieldNullTarget() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readDeclaredField(null, "publicField");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldOnlyOwnClass() {
        final ChildFixture child = new ChildFixture();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readDeclaredField(child, "publicField");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldSuccess() throws IllegalAccessException {
        final ChildFixture child = new ChildFixture();
        assertEquals(100, FieldUtils.readDeclaredField(child, "childPublicField"));
    }

    @Test
    public void testReadDeclaredFieldPrivateWithoutForceAccess() {
        final ParentFixture parent = new ParentFixture();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readDeclaredField(parent, "privateField", false);
            }
        });
    }

    @Test
    public void testReadDeclaredFieldPrivateWithForceAccess() throws IllegalAccessException {
        final ParentFixture parent = new ParentFixture();
        assertEquals(4, FieldUtils.readDeclaredField(parent, "privateField", true));
    }

    // --- readDeclaredStaticField ---

    @Test
    public void testReadDeclaredStaticFieldPublic() throws IllegalAccessException {
        assertEquals(10, FieldUtils.readDeclaredStaticField(ParentFixture.class, "staticPublicField"));
    }

    @Test
    public void testReadDeclaredStaticFieldPrivateWithoutForceAccess() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readDeclaredStaticField(ParentFixture.class, "staticPrivateField", false);
            }
        });
    }

    @Test
    public void testReadDeclaredStaticFieldPrivateWithForceAccess() throws IllegalAccessException {
        assertEquals(20, FieldUtils.readDeclaredStaticField(ParentFixture.class, "staticPrivateField", true));
    }

    // --- readField(Field, Object[, boolean]) ---

    @Test
    public void testReadFieldNullField() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readField((Field) null, new ParentFixture());
            }
        });
    }

    @Test
    public void testReadFieldInaccessibleWithoutForceAccess() throws NoSuchFieldException {
        final Field rawField = ParentFixture.class.getDeclaredField("privateField");
        assertFalse(rawField.isAccessible());
        final ParentFixture parent = new ParentFixture();
        assertThrows(IllegalAccessException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readField(rawField, parent, false);
            }
        });
    }

    @Test
    public void testReadFieldWithForceAccess() throws NoSuchFieldException, IllegalAccessException {
        final Field rawField = ParentFixture.class.getDeclaredField("privateField");
        final ParentFixture parent = new ParentFixture();
        assertEquals(4, FieldUtils.readField(rawField, parent, true));
    }

    // --- readField(Object, String[, boolean]) ---

    @Test
    public void testReadFieldByNameNullTarget() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readField((Object) null, "publicField");
            }
        });
    }

    @Test
    public void testReadFieldByNamePublicInherited() throws IllegalAccessException {
        final ChildFixture child = new ChildFixture();
        assertEquals(1, FieldUtils.readField(child, "publicField"));
    }

    @Test
    public void testReadFieldByNamePrivateWithoutForceAccess() {
        final ParentFixture parent = new ParentFixture();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readField(parent, "privateField");
            }
        });
    }

    @Test
    public void testReadFieldByNamePrivateWithForceAccess() throws IllegalAccessException {
        final ParentFixture parent = new ParentFixture();
        assertEquals(4, FieldUtils.readField(parent, "privateField", true));
    }

    // --- readStaticField ---

    @Test
    public void testReadStaticFieldByNamePublic() throws IllegalAccessException {
        assertEquals(10, FieldUtils.readStaticField(ParentFixture.class, "staticPublicField"));
    }

    @Test
    public void testReadStaticFieldByNamePrivateWithoutForceAccess() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readStaticField(ParentFixture.class, "staticPrivateField", false);
            }
        });
    }

    @Test
    public void testReadStaticFieldFieldOverloadNotStatic() throws NoSuchFieldException {
        final Field instanceField = ParentFixture.class.getDeclaredField("publicField");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readStaticField(instanceField);
            }
        });
    }

    @Test
    public void testReadStaticFieldFieldOverloadNullField() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readStaticField((Field) null);
            }
        });
    }

    @Test
    public void testReadStaticFieldFieldOverloadSuccess() throws NoSuchFieldException, IllegalAccessException {
        final Field staticField = ParentFixture.class.getDeclaredField("staticPublicField");
        assertEquals(10, FieldUtils.readStaticField(staticField));
    }

    // --- removeFinalModifier ---

    @Test
    public void testRemoveFinalModifierNullField() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                FieldUtils.removeFinalModifier(null);
            }
        });
    }

    @Test
    public void testRemoveFinalModifierOnFinalField() throws NoSuchFieldException {
        final Field field = ParentFixture.class.getDeclaredField("STATIC_FINAL_FIELD");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @Test
    public void testRemoveFinalModifierOnNonFinalFieldIsNoOp() throws NoSuchFieldException {
        final Field field = ParentFixture.class.getDeclaredField("notFinalInstanceField");
        FieldUtils.removeFinalModifier(field, true);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    // --- writeDeclaredField ---

    @Test
    public void testWriteDeclaredFieldNullTarget() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeDeclaredField(null, "publicField", 1);
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldOnlyOwnClass() {
        final ChildFixture child = new ChildFixture();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeDeclaredField(child, "publicField", 999);
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldSuccess() throws IllegalAccessException {
        final ChildFixture child = new ChildFixture();
        FieldUtils.writeDeclaredField(child, "childPublicField", 999);
        assertEquals(999, child.childPublicField);
    }

    @Test
    public void testWriteDeclaredFieldPrivateWithForceAccess() throws IllegalAccessException {
        final ParentFixture parent = new ParentFixture();
        FieldUtils.writeDeclaredField(parent, "privateField", 999, true);
        assertEquals(999, FieldUtils.readDeclaredField(parent, "privateField", true));
    }

    // --- writeDeclaredStaticField ---

    @Test
    public void testWriteDeclaredStaticFieldPublic() throws IllegalAccessException {
        try {
            FieldUtils.writeDeclaredStaticField(ParentFixture.class, "staticPublicField", 999);
            assertEquals(999, ParentFixture.staticPublicField);
        } finally {
            ParentFixture.staticPublicField = 10;
        }
    }

    @Test
    public void testWriteDeclaredStaticFieldUnknownField() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeDeclaredStaticField(ParentFixture.class, "doesNotExist", 1);
            }
        });
    }

    // --- writeField(Field, Object, Object[, boolean]) ---

    @Test
    public void testWriteFieldNullField() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeField(null, new ParentFixture(), 1);
            }
        });
    }

    @Test
    public void testWriteFieldNotAssignableValue() throws NoSuchFieldException {
        final Field field = ParentFixture.class.getDeclaredField("publicField");
        final ParentFixture parent = new ParentFixture();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeField(field, parent, "not an int", true);
            }
        });
    }

    @Test
    public void testWriteFieldSuccess() throws NoSuchFieldException, IllegalAccessException {
        final Field field = ParentFixture.class.getDeclaredField("publicField");
        final ParentFixture parent = new ParentFixture();
        FieldUtils.writeField(field, parent, 777);
        assertEquals(777, parent.publicField);
    }

    // --- writeField(Object, String, Object[, boolean]) ---

    @Test
    public void testWriteFieldByNamePrivateWithoutForceAccess() {
        final ParentFixture parent = new ParentFixture();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeField(parent, "privateField", 999);
            }
        });
    }

    @Test
    public void testWriteFieldByNameInheritedPublic() throws IllegalAccessException {
        final ChildFixture child = new ChildFixture();
        FieldUtils.writeField(child, "publicField", 555);
        assertEquals(555, child.publicField);
    }

    // --- writeStaticField ---

    @Test
    public void testWriteStaticFieldFinalWithoutForceAccessFails() {
        assertThrows(IllegalAccessException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeStaticField(ParentFixture.class, "STATIC_FINAL_FIELD", 999);
            }
        });
    }

    @Test
    public void testWriteStaticFieldByNameSuccess() throws IllegalAccessException {
        try {
            FieldUtils.writeStaticField(ParentFixture.class, "staticPublicField", 42);
            assertEquals(42, ParentFixture.staticPublicField);
        } finally {
            ParentFixture.staticPublicField = 10;
        }
    }

    @Test
    public void testWriteStaticFieldFieldOverloadNotStatic() throws NoSuchFieldException {
        final Field instanceField = ParentFixture.class.getDeclaredField("publicField");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeStaticField(instanceField, 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldFieldOverloadNullField() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeStaticField((Field) null, 1);
            }
        });
    }

    @Test
    public void testWriteStaticFieldFieldOverloadSuccess() throws NoSuchFieldException, IllegalAccessException {
        try {
            final Field staticField = ParentFixture.class.getDeclaredField("staticPublicField");
            FieldUtils.writeStaticField(staticField, 321);
            assertEquals(321, ParentFixture.staticPublicField);
        } finally {
            ParentFixture.staticPublicField = 10;
        }
    }

}
