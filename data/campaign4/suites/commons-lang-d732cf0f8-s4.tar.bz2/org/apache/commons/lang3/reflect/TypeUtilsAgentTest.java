package org.apache.commons.lang3.reflect;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TypeUtilsAgentTest {

    private interface GenericInterface<T> {
        // marker generic interface used as a fixture
    }

    private static class StringClass implements GenericInterface<String> {
        // non-generic implementor fixture
    }

    private static class Box<T> {
        // simple generic holder fixture
    }

    private static class StringBox extends Box<String> {
        // concrete subtype fixture for getTypeArguments(Type, Class)
    }

    private static class GenericBox<E> extends Box<E> {
        // generic subtype fixture for determineTypeArguments
    }

    private static class NoBound<T> {
        // fixture with an implicitly Object-bounded type variable
    }

    private static class Bounded<T extends Number & Comparable<T>> {
        // fixture with a multiply-bounded type variable
    }

    private static List<? extends Number> extendsField;
    private static List<? super String> superField;
    private static List<?> plainWildcardField;

    private static WildcardType extractWildcard(String fieldName) throws Exception {
        ParameterizedType fieldType = (ParameterizedType) TypeUtilsAgentTest.class.getDeclaredField(fieldName).getGenericType();
        return (WildcardType) fieldType.getActualTypeArguments()[0];
    }

    private static void assertNpe(Executable executable) {
        assertThrows(NullPointerException.class, executable);
    }

    @Test
    public void testDeprecatedConstructor() {
        TypeUtils instance = new TypeUtils();
        assertNotNull(instance);
    }

    @Test
    public void testWildcardAllField() {
        assertNotNull(TypeUtils.WILDCARD_ALL);
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.WILDCARD_ALL.getUpperBounds());
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);
    }

    @Test
    public void testContainsTypeVariables() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));

        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(boxVar));

        ParameterizedType withVariable = TypeUtils.parameterize(Box.class, boxVar);
        assertTrue(TypeUtils.containsTypeVariables(withVariable));

        ParameterizedType withoutVariable = TypeUtils.parameterize(Box.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(withoutVariable));
    }

    @Test
    public void testEquals() {
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));

        ParameterizedType a = TypeUtils.parameterize(Box.class, String.class);
        ParameterizedType b = TypeUtils.parameterize(Box.class, String.class);
        assertNotSame(a, b);
        assertTrue(TypeUtils.equals(a, b));
    }

    @Test
    public void testGenericArrayType() {
        GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertNotNull(gat);
        assertEquals(String.class, gat.getGenericComponentType());
        assertTrue(TypeUtils.isArrayType(gat));
        assertEquals(String.class, TypeUtils.getArrayComponentType(gat));
    }

    @Test
    public void testGetArrayComponentType() {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
    }

    @Test
    public void testGetImplicitBounds() {
        TypeVariable<?> unbounded = NoBound.class.getTypeParameters()[0];
        Type[] bounds = TypeUtils.getImplicitBounds(unbounded);
        assertEquals(1, bounds.length);
        assertEquals(Object.class, bounds[0]);

        TypeVariable<?> bounded = Bounded.class.getTypeParameters()[0];
        Type[] boundedBounds = TypeUtils.getImplicitBounds(bounded);
        assertEquals(2, boundedBounds.length);
        assertEquals(Number.class, boundedBounds[0]);

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    public void testGetImplicitLowerBounds() throws Exception {
        WildcardType extendsWildcard = extractWildcard("extendsField");
        Type[] lowerBounds = TypeUtils.getImplicitLowerBounds(extendsWildcard);
        assertEquals(1, lowerBounds.length);
        assertNull(lowerBounds[0]);

        WildcardType superWildcard = extractWildcard("superField");
        Type[] lowerBounds2 = TypeUtils.getImplicitLowerBounds(superWildcard);
        assertEquals(1, lowerBounds2.length);
        assertEquals(String.class, lowerBounds2[0]);

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    @Test
    public void testGetImplicitUpperBounds() throws Exception {
        WildcardType extendsWildcard = extractWildcard("extendsField");
        Type[] upperBounds = TypeUtils.getImplicitUpperBounds(extendsWildcard);
        assertEquals(1, upperBounds.length);
        assertEquals(Number.class, upperBounds[0]);

        WildcardType plainWildcard = extractWildcard("plainWildcardField");
        Type[] upperBounds2 = TypeUtils.getImplicitUpperBounds(plainWildcard);
        assertEquals(1, upperBounds2.length);
        assertEquals(Object.class, upperBounds2[0]);

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    @Test
    public void testGetRawType() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));

        ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(Box.class, TypeUtils.getRawType(boxOfString, null));

        assertEquals(String[].class, TypeUtils.getRawType(TypeUtils.genericArrayType(String.class), null));

        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        assertEquals(String.class, TypeUtils.getRawType(boxVar, boxOfString));
    }

    @Test
    public void testGetTypeArgumentsParameterizedType() {
        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);

        Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(boxOfString);
        assertEquals(1, args.size());
        assertEquals(String.class, args.get(boxVar));
    }

    @Test
    public void testGetTypeArgumentsTypeClass() {
        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];

        Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringBox.class, Box.class);
        assertNotNull(args);
        assertEquals(String.class, args.get(boxVar));

        assertNull(TypeUtils.getTypeArguments(String.class, List.class));

        Map<TypeVariable<?>, Type> emptyArgs = TypeUtils.getTypeArguments(String.class, Serializable.class);
        assertNotNull(emptyArgs);
        assertTrue(emptyArgs.isEmpty());
    }

    @Test
    public void testDetermineTypeArguments() {
        TypeVariable<?> eVar = GenericBox.class.getTypeParameters()[0];
        ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);

        Map<TypeVariable<?>, Type> determined = TypeUtils.determineTypeArguments(GenericBox.class, boxOfString);
        assertEquals(String.class, determined.get(eVar));

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.determineTypeArguments(null, TypeUtils.parameterize(Box.class, String.class));
            }
        });
        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.determineTypeArguments(GenericBox.class, null);
            }
        });
    }

    @Test
    public void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    public void testIsAssignable() {
        assertTrue(TypeUtils.isAssignable(String.class, Object.class));
        assertFalse(TypeUtils.isAssignable(Object.class, String.class));
        assertTrue(TypeUtils.isAssignable(ArrayList.class, List.class));

        ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        ParameterizedType arrayListOfString = TypeUtils.parameterize(ArrayList.class, String.class);

        assertTrue(TypeUtils.isAssignable(arrayListOfString, listOfString));
        assertFalse(TypeUtils.isAssignable(arrayListOfString, listOfInteger));
    }

    @Test
    public void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(1), String.class));

        List<String> sample = new ArrayList<String>();
        sample.add("x");
        ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isInstance(sample, listOfString));
    }

    @Test
    public void testNormalizeUpperBounds() {
        Type[] redundant = new Type[] { Collection.class, List.class };
        Type[] normalized = TypeUtils.normalizeUpperBounds(redundant);
        assertEquals(1, normalized.length);
        assertEquals(List.class, normalized[0]);

        Type[] unrelated = new Type[] { Number.class, Comparable.class };
        Type[] normalized2 = TypeUtils.normalizeUpperBounds(unrelated);
        assertEquals(2, normalized2.length);

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    @Test
    public void testParameterizeVarargsAndMap() {
        ParameterizedType pt = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(Box.class, pt.getRawType());
        assertArrayEquals(new Type[] { String.class }, pt.getActualTypeArguments());
        assertNull(pt.getOwnerType());

        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        Map<TypeVariable<?>, Type> varMap = new HashMap<TypeVariable<?>, Type>();
        varMap.put(boxVar, Integer.class);
        ParameterizedType ptFromMap = TypeUtils.parameterize(Box.class, varMap);
        assertEquals(Box.class, ptFromMap.getRawType());
        assertArrayEquals(new Type[] { Integer.class }, ptFromMap.getActualTypeArguments());

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.parameterize(null, String.class);
            }
        });
        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.parameterize(Box.class, (Map<TypeVariable<?>, Type>) null);
            }
        });
    }

    @Test
    public void testParameterizeWithOwner() {
        ParameterizedType ptOwner = TypeUtils.parameterizeWithOwner(String.class, Box.class, String.class);
        assertEquals(String.class, ptOwner.getOwnerType());
        assertEquals(Box.class, ptOwner.getRawType());
        assertArrayEquals(new Type[] { String.class }, ptOwner.getActualTypeArguments());

        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        Map<TypeVariable<?>, Type> varMap = new HashMap<TypeVariable<?>, Type>();
        varMap.put(boxVar, Integer.class);
        ParameterizedType ptOwnerFromMap = TypeUtils.parameterizeWithOwner(String.class, Box.class, varMap);
        assertEquals(String.class, ptOwnerFromMap.getOwnerType());
        assertArrayEquals(new Type[] { Integer.class }, ptOwnerFromMap.getActualTypeArguments());

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.parameterizeWithOwner(String.class, null, String.class);
            }
        });
    }

    @Test
    public void testToString() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));

        ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        String formatted = TypeUtils.toString(boxOfString);
        assertTrue(formatted.contains("String"));
        assertTrue(formatted.contains("<"));
        assertTrue(formatted.contains(">"));

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    public void testToLongString() {
        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        String longString = TypeUtils.toLongString(boxVar);
        assertTrue(longString.contains(boxVar.getName()));

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    @Test
    public void testTypesSatisfyVariables() {
        TypeVariable<?> unbounded = NoBound.class.getTypeParameters()[0];
        Map<TypeVariable<?>, Type> satisfying = new HashMap<TypeVariable<?>, Type>();
        satisfying.put(unbounded, String.class);
        assertTrue(TypeUtils.typesSatisfyVariables(satisfying));

        TypeVariable<?> bounded = Bounded.class.getTypeParameters()[0];
        Map<TypeVariable<?>, Type> violating = new HashMap<TypeVariable<?>, Type>();
        violating.put(bounded, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(violating));

        assertNpe(new Executable() {
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    @Test
    public void testUnrollVariables() {
        TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
        Map<TypeVariable<?>, Type> args = new HashMap<TypeVariable<?>, Type>();
        args.put(boxVar, String.class);

        assertEquals(String.class, TypeUtils.unrollVariables(args, boxVar));

        ParameterizedType boxOfVar = TypeUtils.parameterize(Box.class, boxVar);
        Type unrolled = TypeUtils.unrollVariables(args, boxOfVar);
        assertTrue(TypeUtils.equals(unrolled, TypeUtils.parameterize(Box.class, String.class)));

        assertNull(TypeUtils.unrollVariables(args, null));

        TypeVariable<?> unrelatedVar = NoBound.class.getTypeParameters()[0];
        assertNull(TypeUtils.unrollVariables(new HashMap<TypeVariable<?>, Type>(), unrelatedVar));
    }

    @Test
    public void testWildcardTypeBuilder() {
        TypeUtils.WildcardTypeBuilder builder = TypeUtils.wildcardType();
        assertNotNull(builder);

        TypeUtils.WildcardTypeBuilder sameBuilder = builder.withUpperBounds(Number.class);
        assertSame(builder, sameBuilder);

        WildcardType built = builder.build();
        assertArrayEquals(new Type[] { Number.class }, built.getUpperBounds());

        TypeUtils.WildcardTypeBuilder builder2 = TypeUtils.wildcardType().withLowerBounds(String.class);
        WildcardType built2 = builder2.build();
        assertArrayEquals(new Type[] { String.class }, built2.getLowerBounds());
    }

    @Test
    public void testWrap() {
        Typed<String> typed = TypeUtils.wrap(String.class);
        assertNotNull(typed);
        assertEquals(String.class, typed.getType());

        ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        Typed<?> typedParameterized = TypeUtils.wrap((Type) boxOfString);
        assertNotNull(typedParameterized);
        assertTrue(TypeUtils.equals(boxOfString, typedParameterized.getType()));
    }

    @Test
    public void testGenericInterfaceFixtureIsAssignable() {
        assertTrue(TypeUtils.isAssignable(StringClass.class, GenericInterface.class));
    }
}
