package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class NumberUtilsAgentTest {

    // ---- Field constants ----

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    // ---- compare ----

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 5) < 0);
        assertTrue(NumberUtils.compare((byte) 5, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 5) < 0);
        assertTrue(NumberUtils.compare(5, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 5L) < 0);
        assertTrue(NumberUtils.compare(5L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 5) < 0);
        assertTrue(NumberUtils.compare((short) 5, (short) 1) > 0);
    }

    // ---- createBigDecimal ----

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("123.45"), NumberUtils.createBigDecimal("123.45"));
    }

    @Test
    public void testCreateBigDecimalInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("abc");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    // ---- createBigInteger ----

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigInteger("abc");
            }
        });
    }

    // ---- createDouble ----

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // ---- createFloat ----

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---- createInteger ----

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(16), NumberUtils.createInteger("0x10"));
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // ---- createLong ----

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(Long.valueOf(16L), NumberUtils.createLong("0x10"));
    }

    @Test
    public void testCreateLongOctal() {
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
    }

    @Test
    public void testCreateLongInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---- createNumber ----

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberInteger() {
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongSuffix() {
        Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        Number n = NumberUtils.createNumber("3.14f");
        assertTrue(n instanceof Float);
        assertEquals(3.14f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        Number n = NumberUtils.createNumber("3.14d");
        assertTrue(n instanceof Double);
        assertEquals(3.14d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberHex() {
        Number n = NumberUtils.createNumber("0x10");
        assertEquals(16, n.intValue());
    }

    @Test
    public void testCreateNumberHexBeyondEightDigitsIsLong() {
        Number n = NumberUtils.createNumber("0x100000000");
        assertTrue(n instanceof Long);
        assertEquals(4294967296L, n.longValue());
    }

    @Test
    public void testCreateNumberOctal() {
        Number n = NumberUtils.createNumber("011");
        assertEquals(9L, n.longValue());
    }

    @Test
    public void testCreateNumberLeadingOrTrailingSpaceThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber(" 123");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("123 ");
            }
        });
    }

    @Test
    public void testCreateNumberInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("abc");
            }
        });
    }

    @Test
    public void testCreateNumberEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
    }

    @Test
    public void testIsCreatableImpliesCreateNumberSucceeds() {
        String[] creatable = {"123", "0x1A", "123L", "0.09", "3.14d"};
        for (int i = 0; i < creatable.length; i++) {
            String s = creatable[i];
            assertTrue(NumberUtils.isCreatable(s), "expected isCreatable to be true for " + s);
            // Must not throw.
            NumberUtils.createNumber(s);
        }
    }

    // ---- isCreatable ----

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertFalse(NumberUtils.isCreatable("09"));
        assertTrue(NumberUtils.isCreatable("0.09"));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("123L"));
        assertTrue(NumberUtils.isCreatable("3.14d"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    // ---- isDigits ----

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("123a"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12.3"));
    }

    // ---- isNumber (deprecated) ----

    @Test
    @SuppressWarnings("deprecation")
    public void testIsNumberDeprecated() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertFalse(NumberUtils.isNumber("09"));
        assertTrue(NumberUtils.isNumber("0.09"));
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
    }

    // ---- isParsable ----

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("123.45"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertFalse(NumberUtils.isParsable("abc"));
        // Not parsable by Integer/Long/Float/Double.parse*, even though isCreatable accepts them.
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("123L"));
        assertFalse(NumberUtils.isParsable(" 123"));
    }

    // ---- max/min error conditions across all primitive array overloads ----

    @Test
    public void testMaxArrayNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
    }

    @Test
    public void testMaxArrayEmptyThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMinArrayNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
    }

    @Test
    public void testMinArrayEmptyThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    // ---- max: happy path ----

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 10, NumberUtils.max(new byte[] {2, -5, 10, 3}));
    }

    @Test
    public void testMaxByteThreeArgs() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(2.5d, NumberUtils.max(new double[] {1.5d, 2.5d, -3.5d}), 0.0d);
    }

    @Test
    public void testMaxDoubleThreeArgsNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    public void testMaxDoubleThreeArgsInfinity() {
        assertEquals(Double.POSITIVE_INFINITY, NumberUtils.max(1.0d, Double.POSITIVE_INFINITY, 2.0d), 0.0d);
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(2.5f, NumberUtils.max(new float[] {1.5f, 2.5f, -3.5f}), 0.0f);
    }

    @Test
    public void testMaxFloatThreeArgsNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(7, NumberUtils.max(new int[] {3, -1, 7, 2}));
    }

    @Test
    public void testMaxIntThreeArgs() {
        assertEquals(9, NumberUtils.max(1, 9, 4));
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(7L, NumberUtils.max(new long[] {3L, -1L, 7L, 2L}));
    }

    @Test
    public void testMaxLongThreeArgs() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 4L));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 7, NumberUtils.max(new short[] {3, -1, 7}));
    }

    @Test
    public void testMaxShortThreeArgs() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 4));
    }

    // ---- min: happy path ----

    @Test
    public void testMinByteArray() {
        assertEquals((byte) -5, NumberUtils.min(new byte[] {2, -5, 10, 3}));
    }

    @Test
    public void testMinByteThreeArgs() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(-3.5d, NumberUtils.min(new double[] {1.5d, 2.5d, -3.5d}), 0.0d);
    }

    @Test
    public void testMinDoubleThreeArgsNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    public void testMinDoubleThreeArgsInfinity() {
        assertEquals(Double.NEGATIVE_INFINITY, NumberUtils.min(1.0d, Double.NEGATIVE_INFINITY, 2.0d), 0.0d);
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(-3.5f, NumberUtils.min(new float[] {1.5f, 2.5f, -3.5f}), 0.0f);
    }

    @Test
    public void testMinFloatThreeArgsNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMinIntArray() {
        assertEquals(-1, NumberUtils.min(new int[] {3, -1, 7, 2}));
    }

    @Test
    public void testMinIntThreeArgs() {
        assertEquals(1, NumberUtils.min(1, 9, 4));
    }

    @Test
    public void testMinLongArray() {
        assertEquals(-1L, NumberUtils.min(new long[] {3L, -1L, 7L, 2L}));
    }

    @Test
    public void testMinLongThreeArgs() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 4L));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) -1, NumberUtils.min(new short[] {3, -1, 7}));
    }

    @Test
    public void testMinShortThreeArgs() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 4));
    }

    // ---- toByte ----

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("abc"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 5, NumberUtils.toByte("abc", (byte) 5));
    }

    // ---- toDouble ----

    @Test
    public void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("abc"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(2.2d, NumberUtils.toDouble("abc", 2.2d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---- toFloat ----

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("abc"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(2.2f, NumberUtils.toFloat("abc", 2.2f), 0.0f);
    }

    // ---- toInt ----

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("abc"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(5, NumberUtils.toInt("abc", 5));
    }

    // ---- toLong ----

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("abc"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(5L, NumberUtils.toLong("abc", 5L));
    }

    // ---- toShort ----

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("abc"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 5, NumberUtils.toShort("abc", (short) 5));
    }

    // ---- toScaledBigDecimal: BigDecimal ----

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((BigDecimal) null)));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.0"));
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("2.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRoundingNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(
                NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP)));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.005"), 2, RoundingMode.HALF_UP);
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("2.01").compareTo(result));
    }

    // ---- toScaledBigDecimal: Double ----

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Double) null)));
    }

    @Test
    public void testToScaledBigDecimalDoubleDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.0d));
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("2.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalDoubleWithScaleAndRoundingNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(
                NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP)));
    }

    @Test
    public void testToScaledBigDecimalDoubleWithScaleAndRounding() {
        assertEquals(0, BigDecimal.valueOf(3).compareTo(
                NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d), 0, RoundingMode.HALF_UP)));
        assertEquals(0, BigDecimal.valueOf(2).compareTo(
                NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d), 0, RoundingMode.HALF_DOWN)));
    }

    // ---- toScaledBigDecimal: Float ----

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Float) null)));
    }

    @Test
    public void testToScaledBigDecimalFloatDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.0f));
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("2.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalFloatWithScaleAndRoundingNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(
                NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP)));
    }

    @Test
    public void testToScaledBigDecimalFloatWithScaleAndRounding() {
        assertEquals(0, BigDecimal.valueOf(3).compareTo(
                NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f), 0, RoundingMode.HALF_UP)));
        assertEquals(0, BigDecimal.valueOf(2).compareTo(
                NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f), 0, RoundingMode.HALF_DOWN)));
    }

    // ---- toScaledBigDecimal: String ----

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((String) null)));
    }

    @Test
    public void testToScaledBigDecimalStringDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.0");
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("2.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRoundingNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(
                NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP)));
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.005", 2, RoundingMode.HALF_UP);
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("2.01").compareTo(result));
    }
}
