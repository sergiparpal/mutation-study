/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;

class ConverterAgentTest {

    private static final class UppercaseConverter implements Converter<String, RuntimeException> {
        @Override
        public String apply(final String string) {
            return string.toUpperCase();
        }
    }

    private static final class FailingConverter implements Converter<String, IllegalStateException> {
        @Override
        public String apply(final String string) throws IllegalStateException {
            throw new IllegalStateException("boom: " + string);
        }
    }

    @Test
    void testDefaultConverterReturnsInputUnchanged() {
        final Object result = Converter.DEFAULT.apply("hello");
        assertEquals("hello", result);
    }

    @Test
    void testDefaultConverterWithEmptyString() {
        final Object result = Converter.DEFAULT.apply("");
        assertEquals("", result);
    }

    @Test
    void testClassConverterHappyPath() throws Exception {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertSame(String.class, clazz);
    }

    @Test
    void testClassConverterThrowsOnUnknownClass() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.Class");
            }
        });
    }

    @Test
    void testFileConverterCreatesFileWithGivenPath() {
        final File file = Converter.FILE.apply("some/path/name.txt");
        assertEquals("some/path/name.txt".replace('/', File.separatorChar), file.getPath());
    }

    @Test
    void testPathConverterHappyPath() {
        final Path path = Converter.PATH.apply("a/b/c");
        assertEquals("a", path.getName(0).toString());
    }

    @Test
    void testPathConverterThrowsOnInvalidPath() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("bad\u0000path");
            }
        });
    }

    @Test
    void testNumberConverterReturnsLongWithoutDecimalPoint() {
        final Number number = Converter.NUMBER.apply("42");
        assertTrue(number instanceof Long);
        assertEquals(42L, number.longValue());
    }

    @Test
    void testNumberConverterReturnsDoubleWithDecimalPoint() {
        final Number number = Converter.NUMBER.apply("3.14");
        assertTrue(number instanceof Double);
        assertEquals(3.14, number.doubleValue(), 0.0001);
    }

    @Test
    void testNumberConverterThrowsOnNonNumeric() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testObjectConverterInstantiatesClass() throws Exception {
        final Object obj = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(obj);
        assertTrue(obj instanceof Object);
    }

    @Test
    void testObjectConverterThrowsOnUnknownClass() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.Class");
            }
        });
    }

    @Test
    void testUrlConverterHappyPath() throws Exception {
        final URL url = Converter.URL.apply("https://example.com");
        assertEquals("https://example.com", url.toString());
    }

    @Test
    void testUrlConverterThrowsOnMalformedUrl() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    void testDateConverterHappyPath() throws Exception {
        final Date date = new Date(0);
        final Date parsed = Converter.DATE.apply(date.toString());
        assertEquals(date.toString(), parsed.toString());
    }

    @Test
    void testDateConverterThrowsOnInvalidFormat() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date");
            }
        });
    }

    @Test
    void testCustomConverterImplementationHappyPath() {
        final Converter<String, RuntimeException> converter = new UppercaseConverter();
        assertEquals("ABC", converter.apply("abc"));
    }

    @Test
    void testCustomConverterImplementationPropagatesException() {
        final Converter<String, IllegalStateException> converter = new FailingConverter();
        final IllegalStateException thrown = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                converter.apply("x");
            }
        });
        assertEquals("boom: x", thrown.getMessage());
    }

    @Test
    void testLambdaBasedConverter() throws Exception {
        final Converter<Integer, NumberFormatException> parser = new Converter<Integer, NumberFormatException>() {
            @Override
            public Integer apply(final String string) throws NumberFormatException {
                return Integer.valueOf(string);
            }
        };
        assertEquals(Integer.valueOf(7), parser.apply("7"));
    }

    @Test
    void testDefaultConverterIsNotSameInstanceAsOtherConstants() {
        assertFalse(Converter.DEFAULT.equals(Converter.CLASS));
    }
}
