/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.junit.jupiter.api.Test;

class ConverterAgentTest {

    /** Public no-arg constructor so Converter.OBJECT can instantiate it via reflection. */
    public static class Instantiable {
        public Instantiable() {
        }
    }

    /** Private constructor so Converter.OBJECT fails to find an accessible constructor. */
    public static final class NotInstantiable {
        private NotInstantiable() {
        }
    }

    @Test
    void testClassConverter() throws Exception {
        final Class<?> result = Converter.CLASS.apply(Instantiable.class.getName());
        assertEquals(Instantiable.class, result);
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.ClassName");
            }
        });
    }

    @Test
    void testDateConverterFormatsEnglishLocale() throws Exception {
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        final Date date = new Date(1023400137000L);
        final String formatted = format.format(date);
        final Date result = Converter.DATE.apply(formatted);
        assertEquals(formatted, format.format(result));
    }

    @Test
    void testDateConverterRejectsGarbage() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date at all");
            }
        });
    }

    @Test
    void testDateConverterRejectsTrailingText() throws Exception {
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        final String formatted = format.format(new Date(1023400137000L));
        final String withGarbage = formatted + " extra-garbage";
        final ParseException thrown = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply(withGarbage);
            }
        });
        assertTrue(thrown.getMessage().contains("Unparseable date"));
    }

    @Test
    void testDateConverterRejectsOutOfRangeDay() {
        // Lenient parsing is disabled, so "Feb 30" must not silently roll over into March.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Sat Feb 30 10:00:00 GMT 2002");
            }
        });
    }

    @Test
    void testDefaultConverterIsIdentity() throws Exception {
        assertEquals("hello", Converter.DEFAULT.apply("hello"));
        assertEquals("", Converter.DEFAULT.apply(""));
        assertNull(Converter.DEFAULT.apply(null));
    }

    @Test
    void testFileConverter() throws Exception {
        final File result = Converter.FILE.apply("some-file.txt");
        assertEquals(new File("some-file.txt"), result);
    }

    @Test
    void testFileConverterNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testNumberConverterInteger() throws Exception {
        final Number result = Converter.NUMBER.apply("15");
        assertEquals(Long.valueOf(15), result);
        assertTrue(result instanceof Long);
    }

    @Test
    void testNumberConverterDecimal() throws Exception {
        final Number result = Converter.NUMBER.apply("1.5");
        assertEquals(Double.valueOf(1.5), result);
        assertTrue(result instanceof Double);
    }

    @Test
    void testNumberConverterInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testObjectConverter() throws Exception {
        final Object result = Converter.OBJECT.apply(Instantiable.class.getName());
        assertTrue(result instanceof Instantiable);
    }

    @Test
    void testObjectConverterUnknownClassThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.ClassName");
            }
        });
    }

    @Test
    void testObjectConverterNoAccessibleConstructorThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply(NotInstantiable.class.getName());
            }
        });
    }

    @Test
    void testPathConverter() throws Exception {
        final Path result = Converter.PATH.apply("foo/bar");
        assertEquals(Paths.get("foo/bar"), result);
    }

    @Test
    void testPathConverterInvalidThrows() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("foo\u0000bar");
            }
        });
    }

    @Test
    void testUrlConverter() throws Exception {
        final String urlString = "https://commons.apache.org";
        final URL result = Converter.URL.apply(urlString);
        assertEquals(new URL(urlString), result);
    }

    @Test
    void testUrlConverterInvalidThrows() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not-a-url");
            }
        });
    }

    @Test
    void testCustomConverterImplementation() throws Exception {
        final Converter<Integer, NumberFormatException> lengthConverter = new Converter<Integer, NumberFormatException>() {
            @Override
            public Integer apply(final String string) throws NumberFormatException {
                if (string == null) {
                    throw new NumberFormatException("null");
                }
                return Integer.valueOf(string.length());
            }
        };
        final Integer result = lengthConverter.apply("abcde");
        assertNotNull(result);
        assertEquals(Integer.valueOf(5), result);
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lengthConverter.apply(null);
            }
        });
    }
}
