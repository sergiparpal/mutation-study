package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}, built solely from the
 * documented contract of the class (api/org/apache/commons/lang3/time/FastDateParser.html).
 *
 * The constructors of FastDateParser are package-private ("protected"), so this
 * test class lives in the same package in order to instantiate it directly,
 * exactly as the javadoc describes.
 */
public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static FastDateParser newParser(String pattern) {
        return new FastDateParser(pattern, UTC, Locale.US);
    }

    private static FastDateParser newParser(String pattern, TimeZone tz, Locale locale) {
        return new FastDateParser(pattern, tz, locale);
    }

    private static FastDateParser newParser(String pattern, TimeZone tz, Locale locale, Date centuryStart) {
        return new FastDateParser(pattern, tz, locale, centuryStart);
    }

    // -------------------- constructor / accessor contract --------------------

    @Test
    public void testGetPatternReturnsConstructorPattern() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", parser.getPattern());
    }

    @Test
    public void testGetTimeZoneReturnsConstructorTimeZone() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        assertEquals(UTC, parser.getTimeZone());
    }

    @Test
    public void testGetLocaleReturnsConstructorLocale() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertEquals(Locale.FRANCE, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorNullLocaleDefaultsToSystemDefault() {
        FastDateParser parser = newParser("yyyy-MM-dd", UTC, null, new Date(0L));
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    public void testThreeArgConstructorNullPatternThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                newParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    public void testThreeArgConstructorNullTimeZoneThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                newParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    public void testThreeArgConstructorNullLocaleThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                newParser("yyyy-MM-dd", UTC, null);
            }
        });
    }

    // -------------------- parse(String) --------------------

    @Test
    public void testParseStringHappyPath() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");
        Date parsed = parser.parse("2024-03-05");
        Calendar cal = new GregorianCalendar(UTC);
        cal.setTime(parsed);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Exception {
                parser.parse("not-a-date");
            }
        });
    }

    @Test
    public void testParseStringThrowsParseExceptionOnEmptyInput() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Exception {
                parser.parse("");
            }
        });
    }

    // -------------------- parse(String, ParsePosition) --------------------

    @Test
    public void testParseStringParsePositionFullyConsumedSetsIndexToEnd() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        String source = "2024-03-05";
        ParsePosition pos = new ParsePosition(0);
        Date parsed = parser.parse(source, pos);
        assertNotNull(parsed);
        assertEquals(source.length(), pos.getIndex());
    }

    @Test
    public void testParseStringParsePositionPartialConsumptionLeavesRemainder() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        String source = "2024-03-05 trailing text";
        ParsePosition pos = new ParsePosition(0);
        Date parsed = parser.parse(source, pos);
        assertNotNull(parsed);
        assertEquals(10, pos.getIndex());
        assertTrue(pos.getIndex() < source.length());
    }

    @Test
    public void testParseStringParsePositionFailureReturnsNullAndDoesNotAdvanceIndex() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        Date parsed = parser.parse("abcd-ef-gh", pos);
        assertNull(parsed);
        assertEquals(0, pos.getIndex());
    }

    // -------------------- parse(String, ParsePosition, Calendar) --------------------

    @Test
    public void testParseWithCalendarHappyPathReturnsTrueAndUpdatesCalendarAndPosition() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        String source = "2024-03-05";
        ParsePosition pos = new ParsePosition(0);
        Calendar calendar = new GregorianCalendar(UTC);
        calendar.clear();
        boolean result = parser.parse(source, pos, calendar);
        assertTrue(result);
        assertEquals(source.length(), pos.getIndex());
        assertEquals(2024, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, calendar.get(Calendar.MONTH));
        assertEquals(5, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseWithCalendarFailureReturnsFalseAndSetsErrorIndex() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        Calendar calendar = new GregorianCalendar(UTC);
        boolean result = parser.parse("not-a-date", pos, calendar);
        assertFalse(result);
        assertNotEquals(-1, pos.getErrorIndex());
        assertEquals(0, pos.getIndex());
    }

    @Test
    public void testParseWithCalendarNotNeedingFullConsumption() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        String source = "2024-03-05 remainder";
        ParsePosition pos = new ParsePosition(0);
        Calendar calendar = new GregorianCalendar(UTC);
        boolean result = parser.parse(source, pos, calendar);
        assertTrue(result);
        assertTrue(pos.getIndex() < source.length());
    }

    // -------------------- parseObject(String) / parseObject(String, ParsePosition) --------------------

    @Test
    public void testParseObjectStringHappyPath() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");
        Object parsed = parser.parseObject("2024-03-05");
        assertTrue(parsed instanceof Date);
        Calendar cal = new GregorianCalendar(UTC);
        cal.setTime((Date) parsed);
        assertEquals(2024, cal.get(Calendar.YEAR));
    }

    @Test
    public void testParseObjectStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Exception {
                parser.parseObject("garbage");
            }
        });
    }

    @Test
    public void testParseObjectStringParsePositionHappyPath() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        Object parsed = parser.parseObject("2024-03-05", pos);
        assertNotNull(parsed);
        assertTrue(parsed instanceof Date);
        assertEquals(10, pos.getIndex());
    }

    // -------------------- equals / hashCode --------------------

    @Test
    public void testEqualsTrueForSameConfiguration() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
    }

    @Test
    public void testHashCodeConsistentWithEqualInstances() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsFalseForDifferentPattern() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = newParser("dd-MM-yyyy", UTC, Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForDifferentTimeZone() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = newParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForDifferentLocale() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser b = newParser("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForNonFastDateParserObject() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(a.equals("yyyy-MM-dd"));
    }

    @Test
    public void testEqualsFalseForNull() {
        FastDateParser a = newParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(a.equals(null));
    }

    // -------------------- toString / toStringAll --------------------

    @Test
    public void testToStringIsNotNull() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        assertNotNull(parser.toString());
    }

    @Test
    public void testToStringAllIsNotNull() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        assertNotNull(parser.toStringAll());
    }

    // -------------------- package-private helpers: clear() / getPatterns() --------------------

    @Test
    public void testClearDoesNotBreakSubsequentParsing() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");
        FastDateParser.clear();
        Date parsed = parser.parse("2024-03-05");
        assertNotNull(parsed);
        assertEquals("yyyy-MM-dd", parser.getPattern());
    }

    @Test
    public void testGetPatternsReturnsNonEmptyListForNonEmptyPattern() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        List<?> patterns = parser.getPatterns();
        assertNotNull(patterns);
        assertFalse(patterns.isEmpty());
    }

    // -------------------- centuryStart (4-arg constructor) --------------------

    @Test
    public void testCenturyStartControlsTwoDigitYearInterpretation() throws ParseException {
        Calendar centuryCal = new GregorianCalendar(UTC);
        centuryCal.clear();
        centuryCal.set(1950, Calendar.JANUARY, 1);
        Date centuryStart = centuryCal.getTime();

        FastDateParser parser = newParser("yy-MM-dd", UTC, Locale.US, centuryStart);

        Date lateInCentury = parser.parse("60-01-01");
        Calendar lateCal = new GregorianCalendar(UTC);
        lateCal.setTime(lateInCentury);
        assertEquals(1960, lateCal.get(Calendar.YEAR));

        Date earlyInNextCentury = parser.parse("10-01-01");
        Calendar earlyCal = new GregorianCalendar(UTC);
        earlyCal.setTime(earlyInNextCentury);
        assertEquals(2010, earlyCal.get(Calendar.YEAR));
    }

    // -------------------- boundary: literal-only / escaped pattern --------------------

    @Test
    public void testLiteralPatternParsesFixedText() throws ParseException {
        FastDateParser parser = newParser("'literal'");
        ParsePosition pos = new ParsePosition(0);
        Date parsed = parser.parse("literal", pos);
        assertNotNull(parsed);
        assertEquals("literal".length(), pos.getIndex());
    }
}
