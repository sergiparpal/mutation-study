/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    @Test
    void testAvailableLocaleListNotEmptyAndUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    @Test
    void testAvailableLocaleSetContainsKnownLocale() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertTrue(set.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                set.add(new Locale("xx", "XX"));
            }
        });
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "XX", "yy")));
    }

    @Test
    void testCountriesByLanguageNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguageIsCached() {
        final List<Locale> list1 = LocaleUtils.countriesByLanguage("en");
        final List<Locale> list2 = LocaleUtils.countriesByLanguage("en");
        assertSame(list1, list2);
        for (final Locale locale : list1) {
            assertEquals("en", locale.getLanguage());
        }
    }

    @Test
    void testLanguagesByCountryNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryIsCached() {
        final List<Locale> list1 = LocaleUtils.languagesByCountry("FR");
        final List<Locale> list2 = LocaleUtils.languagesByCountry("FR");
        assertSame(list1, list2);
        for (final Locale locale : list1) {
            assertEquals("FR", locale.getCountry());
        }
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("en")));
    }

    @Test
    void testLocaleLookupListSingleArg() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    void testLocaleLookupListSingleArgNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListTwoArgsWithDefault() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"), Locale.ENGLISH);
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(Locale.ENGLISH, list.get(3));
    }

    @Test
    void testLocaleLookupListDoesNotDuplicateDefault() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("en"), new Locale("en"));
        assertEquals(1, list.size());
        assertEquals(new Locale("en"), list.get(0));
    }

    @Test
    void testLocaleLookupListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.US);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.FRANCE);
            }
        });
    }

    @Test
    void testToLocaleFromLocale() {
        assertSame(Locale.US, LocaleUtils.toLocale(Locale.US));
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        final Locale locale = LocaleUtils.toLocale("en");
        assertEquals("en", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageCountryUnderscore() {
        final Locale locale = LocaleUtils.toLocale("en_GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageCountryDash() {
        final Locale locale = LocaleUtils.toLocale("en-GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageNumericArea() {
        final Locale locale = LocaleUtils.toLocale("en_001");
        assertEquals("en", locale.getLanguage());
        assertEquals("001", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageCountryVariant() {
        final Locale locale = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    void testToLocaleStringCountryOnlyIso() {
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    void testToLocaleStringTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("U");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_U");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreLowercaseThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreCountryOnly() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringLeadingUnderscoreWithVariantMissingSeparatorThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBX");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreMismatchedSeparatorThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GB-xxx");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreWithVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_xxx");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    void testToLocaleStringInvalidLanguageUppercaseThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("EN");
            }
        });
    }

    @Test
    void testToLocaleStringInvalidFormatThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_G");
            }
        });
    }

    @Test
    void testToLocaleStringThreeLetterLanguageCode() {
        final Locale locale = LocaleUtils.toLocale("enb");
        assertEquals("enb", locale.getLanguage());
    }

    @Test
    void testToLocaleStringSpecialCaseThaiVariant() {
        final Locale locale = LocaleUtils.toLocale("th_TH_TH_#u-nu-thai");
        assertEquals("th", locale.getLanguage());
        assertEquals("TH", locale.getCountry());
    }

    @Test
    void testToLocaleStringSpecialCaseJapaneseVariant() {
        final Locale locale = LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese");
        assertEquals("ja", locale.getLanguage());
        assertEquals("JP", locale.getCountry());
    }
}
