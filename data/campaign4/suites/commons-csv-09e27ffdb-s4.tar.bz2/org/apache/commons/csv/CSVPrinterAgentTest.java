package org.apache.commons.csv;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link CSVPrinter}, based solely on its documented contract.
 */
public class CSVPrinterAgentTest {

    /** An Appendable that always fails, used to verify documented IOException propagation. */
    private static final class ThrowingAppendable implements Appendable {
        public Appendable append(CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        public Appendable append(CharSequence csq, int start, int end) throws IOException {
            throw new IOException("boom");
        }

        public Appendable append(char c) throws IOException {
            throw new IOException("boom");
        }
    }

    /** An Appendable/Flushable/Closeable that records whether flush()/close() were delegated to it. */
    private static final class TrackingAppendable implements Appendable, Flushable, Closeable {
        private final StringBuilder sb = new StringBuilder();
        private boolean flushCalled;
        private boolean closeCalled;

        public Appendable append(CharSequence csq) {
            sb.append(csq);
            return this;
        }

        public Appendable append(CharSequence csq, int start, int end) {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(char c) {
            sb.append(c);
            return this;
        }

        public void flush() {
            flushCalled = true;
        }

        public void close() {
            closeCalled = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    private static Object defaultForReturnType(final Class<?> type) {
        if (!type.isPrimitive()) {
            return null;
        }
        if (type == boolean.class) {
            return Boolean.FALSE;
        }
        if (type == byte.class) {
            return Byte.valueOf((byte) 0);
        }
        if (type == short.class) {
            return Short.valueOf((short) 0);
        }
        if (type == int.class) {
            return Integer.valueOf(0);
        }
        if (type == long.class) {
            return Long.valueOf(0L);
        }
        if (type == float.class) {
            return Float.valueOf(0f);
        }
        if (type == double.class) {
            return Double.valueOf(0d);
        }
        if (type == char.class) {
            return Character.valueOf('\u0000');
        }
        return null;
    }

    /** InvocationHandler backing a fake java.sql.ResultSetMetaData with a fixed column count. */
    private static final class FakeMetaDataHandler implements InvocationHandler {
        private final int columnCount;

        FakeMetaDataHandler(final int columnCount) {
            this.columnCount = columnCount;
        }

        public Object invoke(final Object proxyObj, final Method method, final Object[] args) throws Throwable {
            final String name = method.getName();
            if ("equals".equals(name) && args != null && args.length == 1) {
                return Boolean.valueOf(proxyObj == args[0]);
            }
            if ("hashCode".equals(name)) {
                return Integer.valueOf(System.identityHashCode(proxyObj));
            }
            if ("toString".equals(name)) {
                return "FakeResultSetMetaData";
            }
            if ("getColumnCount".equals(name)) {
                return Integer.valueOf(columnCount);
            }
            if (("getColumnLabel".equals(name) || "getColumnName".equals(name)) && args != null && args.length == 1
                    && args[0] instanceof Integer) {
                return "COL" + ((Integer) args[0]).intValue();
            }
            return defaultForReturnType(method.getReturnType());
        }
    }

    /** InvocationHandler backing a fake java.sql.ResultSet with a fixed row/column count. */
    private static final class FakeResultSetHandler implements InvocationHandler {
        private final int rowCount;
        private final Object metaDataProxy;
        private final boolean throwOnAccess;
        private int currentRow;

        FakeResultSetHandler(final int rowCount, final Object metaDataProxy, final boolean throwOnAccess) {
            this.rowCount = rowCount;
            this.metaDataProxy = metaDataProxy;
            this.throwOnAccess = throwOnAccess;
        }

        public Object invoke(final Object proxyObj, final Method method, final Object[] args) throws Throwable {
            final String name = method.getName();
            if ("equals".equals(name) && args != null && args.length == 1) {
                return Boolean.valueOf(proxyObj == args[0]);
            }
            if ("hashCode".equals(name)) {
                return Integer.valueOf(System.identityHashCode(proxyObj));
            }
            if ("toString".equals(name)) {
                return "FakeResultSet";
            }
            if (throwOnAccess) {
                throw new SQLException("simulated database access error");
            }
            if ("next".equals(name)) {
                currentRow++;
                return Boolean.valueOf(currentRow <= rowCount);
            }
            if ("getMetaData".equals(name)) {
                return metaDataProxy;
            }
            if ("close".equals(name)) {
                return null;
            }
            if ("getObject".equals(name) && args != null && args.length == 1 && args[0] instanceof Integer) {
                return "R" + currentRow + "C" + ((Integer) args[0]).intValue();
            }
            return defaultForReturnType(method.getReturnType());
        }
    }

    private static ResultSetMetaData newFakeMetaData(final int columnCount) {
        return (ResultSetMetaData) Proxy.newProxyInstance(CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSetMetaData.class }, new FakeMetaDataHandler(columnCount));
    }

    private static ResultSet newFakeResultSet(final int rowCount, final int columnCount, final boolean throwOnAccess) {
        final ResultSetMetaData metaData = newFakeMetaData(columnCount);
        return (ResultSet) Proxy.newProxyInstance(CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSet.class }, new FakeResultSetHandler(rowCount, metaData, throwOnAccess));
    }

    // -------------------- constructor --------------------

    @Test
    public void testConstructorNullAppendableThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testConstructorNullFormatThrowsNullPointerException() {
        final StringWriter sw = new StringWriter();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVPrinter(sw, null);
            }
        });
    }

    @Test
    public void testConstructorGetOutReturnsSameAppendableAndStartsWithZeroRecords() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testConstructorWritesHeaderImmediatelyWithoutCountingIt() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setHeader("H1", "H2").build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        final String sep = format.getRecordSeparator();
        assertEquals("H1,H2" + sep, sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.printRecord("v1", "v2");
        assertEquals("H1,H2" + sep + "v1,v2" + sep, sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testConstructorPropagatesIOExceptionWhenHeaderCannotBePrinted() {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setHeader("H1", "H2").build();
        final ThrowingAppendable ta = new ThrowingAppendable();
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVPrinter(ta, format);
            }
        });
    }

    // -------------------- print --------------------

    @Test
    public void testPrintUsesStringValueOfForNull() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        printer.flush();
        assertEquals(String.valueOf((Object) null), sw.toString());
    }

    @Test
    public void testPrintUsesStringValueOfForNonString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(Integer.valueOf(42));
        printer.flush();
        assertEquals("42", sw.toString());
    }

    @Test
    public void testPrintDoesNotByItselfIncrementRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testPrintPropagatesIOException() throws IOException {
        final ThrowingAppendable ta = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                printer.print("x");
            }
        });
    }

    @Test
    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        printer.flush();
        assertEquals("\"a,b\"", sw.toString());
    }

    // -------------------- println --------------------

    @Test
    public void testPrintlnWritesRecordSeparatorAndCompletesARecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        assertEquals("a" + CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testPrintlnPropagatesIOException() throws IOException {
        final ThrowingAppendable ta = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                printer.println();
            }
        });
    }

    // -------------------- printRecord --------------------

    @Test
    public void testPrintRecordVarargsIncrementsRecordCountAndAddsSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c" + sep, sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.printRecord("d", "e");
        assertEquals("a,b,c" + sep + "d,e" + sep, sw.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordWithNoValuesStillWritesOneRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordWithEmptyObjectArrayStillWritesOneRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecord(Arrays.asList("x", "y"));
        assertEquals("x,y" + sep, sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecord(Stream.of("x", "y", "z"));
        assertEquals("x,y,z" + sep, sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordPropagatesIOException() throws IOException {
        final ThrowingAppendable ta = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printRecord("a", "b");
            }
        });
    }

    // -------------------- printRecords --------------------

    @Test
    public void testPrintRecordsWithSimpleObjectsWritesASingleRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecords("a", "b", "c");
        assertEquals("a,b,c" + sep, sw.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsVarargsWithNestedArraysWritesOneRecordPerNestedArray() throws IOException {
        final String[][] data = new String[3][];
        data[0] = new String[] { "A", "B", "C" };
        data[1] = new String[] { "1", "2", "3" };
        data[2] = new String[] { "A1", "B2", "C3" };
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecords(data);
        assertEquals("A,B,C" + sep + "1,2,3" + sep + "A1,B2,C3" + sep, sw.toString());
        assertEquals(3L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsIterableWithNestedArraysWritesOneRecordPerNestedArray() throws IOException {
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B", "C" });
        data.add(new String[] { "1", "2", "3" });
        data.add(new String[] { "A1", "B2", "C3" });
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecords(data);
        assertEquals("A,B,C" + sep + "1,2,3" + sep + "A1,B2,C3" + sep, sw.toString());
        assertEquals(3L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsStreamWithNestedArraysWritesOneRecordPerNestedArray() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String sep = CSVFormat.DEFAULT.getRecordSeparator();
        printer.printRecords(Stream.of(new String[] { "A", "B", "C" }, new String[] { "1", "2", "3" },
                new String[] { "A1", "B2", "C3" }));
        assertEquals("A,B,C" + sep + "1,2,3" + sep + "A1,B2,C3" + sep, sw.toString());
        assertEquals(3L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsVarargsWithNoValuesWritesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords();
        assertEquals("", sw.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsIterableWithNoValuesWritesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", sw.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    // -------------------- printComment --------------------

    @Test
    public void testPrintCommentDoesNothingWhenCommentsDisabled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("hello");
        printer.flush();
        assertEquals("", sw.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentWritesMarkerAndSpaceWhenEnabled() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setCommentMarker('#').build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        assertEquals("# hello" + format.getRecordSeparator(), sw.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentSplitsMultiLineCommentsOntoSeparateMarkedLines() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setCommentMarker('#').build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        final String sep = format.getRecordSeparator();
        printer.printComment("line1\nline2");
        final String content = sw.toString();
        assertTrue(content.startsWith("# line1"));
        final int idx = content.indexOf("# line2");
        assertTrue(idx > 0);
        assertEquals(sep, content.substring("# line1".length(), idx));
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentPropagatesIOExceptionWhenEnabled() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT).setCommentMarker('#').build();
        final ThrowingAppendable ta = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, format);
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printComment("hello");
            }
        });
    }

    // -------------------- printHeaders --------------------

    @Test
    public void testPrintHeadersWritesColumnLabelsAndDoesNotCountAsARecord() throws IOException, SQLException {
        final ResultSet rs = newFakeResultSet(0, 2, false);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printHeaders(rs);
        final String content = sw.toString();
        assertTrue(content.contains("COL1"));
        assertTrue(content.contains("COL2"));
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void testPrintHeadersPropagatesSqlException() throws IOException {
        final ResultSet rs = newFakeResultSet(0, 2, true);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertThrows(SQLException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printHeaders(rs);
            }
        });
    }

    // -------------------- printRecords(ResultSet...) --------------------

    @Test
    public void testPrintRecordsResultSetCountsOnlyDataRows() throws IOException, SQLException {
        final ResultSet rs = newFakeResultSet(3, 2, false);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(rs);
        assertEquals(3L, printer.getRecordCount());
        assertFalse(sw.toString().isEmpty());
    }

    @Test
    public void testPrintRecordsResultSetPropagatesSqlException() throws IOException {
        final ResultSet rs = newFakeResultSet(1, 1, true);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertThrows(SQLException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printRecords(rs);
            }
        });
    }

    @Test
    public void testPrintRecordsResultSetWithHeaderTrueWritesHeaderButDoesNotCountIt() throws IOException, SQLException {
        final ResultSet rs = newFakeResultSet(2, 2, false);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(rs, true);
        assertTrue(sw.toString().contains("COL1"));
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsResultSetWithHeaderFalseOmitsHeader() throws IOException, SQLException {
        final ResultSet rs = newFakeResultSet(2, 2, false);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(rs, false);
        assertFalse(sw.toString().contains("COL1"));
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsResultSetWithHeaderFlagPropagatesSqlException() throws IOException {
        final ResultSet rs = newFakeResultSet(1, 1, true);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertThrows(SQLException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printRecords(rs, true);
            }
        });
    }

    // -------------------- flush / close --------------------

    @Test
    public void testFlushDelegatesToUnderlyingFlushable() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        printer.print("x");
        assertFalse(ta.flushCalled);
        printer.flush();
        assertTrue(ta.flushCalled);
    }

    @Test
    public void testCloseDelegatesToUnderlyingCloseable() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        printer.print("x");
        printer.close();
        assertTrue(ta.closeCalled);
    }

    @Test
    public void testCloseWithFlushTrueFlushesBeforeClosing() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        printer.print("x");
        printer.close(true);
        assertTrue(ta.flushCalled);
        assertTrue(ta.closeCalled);
    }

    @Test
    public void testCloseWithFlushFalseDoesNotFlush() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        printer.print("x");
        printer.close(false);
        assertFalse(ta.flushCalled);
        assertTrue(ta.closeCalled);
    }

    @Test
    public void testFlushPropagatesIOException() throws IOException {
        final ThrowingAppendable ta = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                printer.flush();
            }
        });
    }

    @Test
    public void testRecordCountIsUnaffectedByClosingThePrinter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.close();
        assertEquals(1L, printer.getRecordCount());
    }
}
