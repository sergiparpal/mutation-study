package org.apache.commons.lang3;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ClassUtilsAgentTest {

    interface Able {
    }

    interface Baker extends Able {
    }

    static class GrandParent implements Able {
    }

    static class Parent extends GrandParent implements Baker {
    }

    static class Child extends Parent {
    }

    public static class PublicNested {
    }

    private static class PrivateNested {
    }

    // ---- fields ----

    @Test
    public void testFields() {
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
    }

    // ---- deprecated constructor ----

    @SuppressWarnings("deprecation")
    @Test
    public void testConstructor() {
        assertNotNull(new ClassUtils());
    }

    // ---- comparator() ----

    @Test
    public void testComparator() {
        Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        assertEquals(0, comparator.compare(String.class, String.class));
        int expectedSign = String.class.getName().compareTo(Integer.class.getName());
        int actualSign = comparator.compare(String.class, Integer.class);
        assertEquals(sign(expectedSign), sign(actualSign));
    }

    private static int sign(int n) {
        if (n < 0) {
            return -1;
        }
        if (n > 0) {
            return 1;
        }
        return 0;
    }

    // ---- convertClassesToClassNames ----

    @Test
    public void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNamesNormal() {
        List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        classes.add(Integer.class);
        List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(3, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
        assertEquals("java.lang.Integer", names.get(2));
    }

    @Test
    public void testConvertClassesToClassNamesBadEntry() {
        final List rawList = new ArrayList();
        rawList.add("not a class");
        final List<Class<?>> badList = rawList;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.convertClassesToClassNames(badList);
            }
        });
    }

    // ---- convertClassNamesToClasses ----

    @Test
    public void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClassesNormal() {
        List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add(null);
        names.add("does.not.Exist");
        List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testConvertClassNamesToClassesBadEntry() {
        final List rawList = new ArrayList();
        rawList.add(Integer.valueOf(1));
        final List<String> badList = rawList;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.convertClassNamesToClasses(badList);
            }
        });
    }

    // ---- getAbbreviatedName(Class, int) ----

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameClassInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, -1);
            }
        });
    }

    // ---- getAbbreviatedName(String, int) ----

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameStringEmpty() {
        assertEquals("", ClassUtils.getAbbreviatedName("", 1));
    }

    @Test
    public void testGetAbbreviatedNameStringExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameStringInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", -5);
            }
        });
    }

    // ---- getAllInterfaces ----

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfaces() {
        List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Child.class);
        assertEquals(2, interfaces.size());
        assertEquals(Baker.class, interfaces.get(0));
        assertEquals(Able.class, interfaces.get(1));
    }

    // ---- getAllSuperclasses ----

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclasses() {
        List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Child.class);
        assertEquals(3, superclasses.size());
        assertEquals(Parent.class, superclasses.get(0));
        assertEquals(GrandParent.class, superclasses.get(1));
        assertEquals(Object.class, superclasses.get(2));
    }

    // ---- getCanonicalName ----

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    public void testGetCanonicalNameClassWithDefault() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "NULL"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    @Test
    public void testGetCanonicalNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello", "NULL"));
    }

    // ---- getClass ----

    @Test
    public void testGetClassByNameInitialized() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    public void testGetClassByNameWhitespaceNormalized() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang. String"));
    }

    @Test
    public void testGetClassByNameWithInitializeFlag() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", false));
    }

    @Test
    public void testGetClassWithClassLoader() throws ClassNotFoundException {
        ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", false));
    }

    @Test
    public void testGetClassArraySyntax() throws ClassNotFoundException {
        Class<?> cls = ClassUtils.getClass("java.util.Map.Entry[]");
        assertTrue(cls.isArray());
        assertEquals(java.util.Map.Entry.class, cls.getComponentType());

        Class<?> cls2 = ClassUtils.getClass("java.util.Map$Entry[]");
        assertTrue(cls2.isArray());
        assertEquals(java.util.Map.Entry.class, cls2.getComponentType());

        Class<?> cls3 = ClassUtils.getClass("[Ljava.util.Map.Entry;");
        assertTrue(cls3.isArray());
        assertEquals(java.util.Map.Entry.class, cls3.getComponentType());
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass("does.not.Exist");
            }
        });
    }

    @Test
    public void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassTooManyArrayDimensions() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append('I');
        final String tooManyDimensions = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass(tooManyDimensions);
            }
        });
    }

    @Test
    public void testGetClassNameTooLong() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        final String tooLongName = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass(tooLongName);
            }
        });
    }

    // ---- getComponentType ----

    @Test
    public void testGetComponentType() {
        assertEquals(Integer.class, ClassUtils.getComponentType(Integer[].class));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
        assertNull(ClassUtils.getComponentType((Class) null));
    }

    // ---- getName ----

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameClassWithDefault() {
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "NULL"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
    }

    @Test
    public void testGetNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName("hello", "NULL"));
    }

    // ---- getPackageCanonicalName ----

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hello", "NULL"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageCanonicalName("Unpackaged"));
    }

    // ---- getPackageName ----

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageName("hello", "NULL"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName("Unpackaged"));
    }

    // ---- getPrimitiveClass (package-private) ----

    @Test
    public void testGetPrimitiveClass() {
        assertEquals(int.class, ClassUtils.getPrimitiveClass("int"));
        assertEquals(boolean.class, ClassUtils.getPrimitiveClass("boolean"));
        assertEquals(byte.class, ClassUtils.getPrimitiveClass("byte"));
    }

    // ---- getPublicMethod ----

    @Test
    public void testGetPublicMethod() throws Exception {
        Set<Object> hidden = new HashSet<Object>();
        Set<Object> set = Collections.unmodifiableSet(hidden);
        Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty", new Class[0]);
        assertNotNull(method);
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        Object result = method.invoke(set, new Object[0]);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    public void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodAtAll");
            }
        });
    }

    // ---- getShortCanonicalName ----

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
    }

    @Test
    public void testGetShortCanonicalNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hello", "NULL"));
    }

    @Test
    public void testGetShortCanonicalNameStringExamples() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("Map.Entry", ClassUtils.getShortCanonicalName(java.util.Map.Entry.class.getName()));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(java.util.Map.Entry.class.getCanonicalName()));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[]"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[][]"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class.getCanonicalName()));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class.getName()));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("[[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("int[]"));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("int[][]"));
    }

    // ---- getShortClassName ----

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(java.util.Map.Entry.class));
    }

    @Test
    public void testGetShortClassNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "NULL"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    // ---- getSimpleName ----

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("Entry", ClassUtils.getSimpleName(java.util.Map.Entry.class));
    }

    @Test
    public void testGetSimpleNameClassWithDefault() {
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName(String.class, "NULL"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("Integer", ClassUtils.getSimpleName(Integer.valueOf(1)));
    }

    @Test
    public void testGetSimpleNameObjectWithDefault() {
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
        assertEquals("Integer", ClassUtils.getSimpleName(Integer.valueOf(1), "NULL"));
    }

    // ---- hierarchy ----

    @Test
    public void testHierarchyExcludeInterfaces() {
        Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Child.class);
        List<Class<?>> list = toList(hierarchy);
        assertEquals(4, list.size());
        assertEquals(Child.class, list.get(0));
        assertEquals(Parent.class, list.get(1));
        assertEquals(GrandParent.class, list.get(2));
        assertEquals(Object.class, list.get(3));
    }

    @Test
    public void testHierarchyExplicitExclude() {
        Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Child.class, ClassUtils.Interfaces.EXCLUDE);
        List<Class<?>> list = toList(hierarchy);
        assertEquals(4, list.size());
        assertFalse(list.contains(Able.class));
        assertFalse(list.contains(Baker.class));
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Child.class, ClassUtils.Interfaces.INCLUDE);
        List<Class<?>> list = toList(hierarchy);
        assertTrue(list.contains(Able.class));
        assertTrue(list.contains(Baker.class));
        assertEquals(Child.class, list.get(0));
        assertEquals(Object.class, list.get(list.size() - 1));

        List<Class<?>> classesOnly = new ArrayList<Class<?>>();
        Iterator<Class<?>> it = list.iterator();
        while (it.hasNext()) {
            Class<?> c = it.next();
            if (!c.isInterface()) {
                classesOnly.add(c);
            }
        }
        assertEquals(4, classesOnly.size());
        assertEquals(Child.class, classesOnly.get(0));
        assertEquals(Parent.class, classesOnly.get(1));
        assertEquals(GrandParent.class, classesOnly.get(2));
        assertEquals(Object.class, classesOnly.get(3));
    }

    private static List<Class<?>> toList(Iterable<Class<?>> iterable) {
        List<Class<?>> list = new ArrayList<Class<?>>();
        Iterator<Class<?>> it = iterable.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list;
    }

    // ---- isAssignable ----

    @Test
    public void testIsAssignableTwoArg() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, Integer.class));
    }

    @Test
    public void testIsAssignableTwoArgWithAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
    }

    @Test
    public void testIsAssignableArray() {
        Class<?>[] from = new Class<?>[] { int.class, String.class };
        Class<?>[] to = new Class<?>[] { long.class, Object.class };
        assertTrue(ClassUtils.isAssignable(from, to));

        Class<?>[] mismatchedLength = new Class<?>[] { int.class };
        assertFalse(ClassUtils.isAssignable(from, mismatchedLength));
    }

    @Test
    public void testIsAssignableArrayWithAutoboxing() {
        Class<?>[] from = new Class<?>[] { Integer.class };
        Class<?>[] to = new Class<?>[] { int.class };
        assertTrue(ClassUtils.isAssignable(from, to, true));
        assertFalse(ClassUtils.isAssignable(from, to, false));
    }

    // ---- isInnerClass ----

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(PublicNested.class));
        assertTrue(ClassUtils.isInnerClass(PrivateNested.class));
        assertTrue(ClassUtils.isInnerClass(java.util.Map.Entry.class));
    }

    // ---- isPrimitiveOrWrapper / isPrimitiveWrapper ----

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(boolean.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    // ---- isPublic ----

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertTrue(ClassUtils.isPublic(PublicNested.class));
        assertFalse(ClassUtils.isPublic(PrivateNested.class));
    }

    // ---- primitivesToWrappers / primitiveToWrapper ----

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.primitivesToWrappers());
        Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, boolean.class);
        assertArrayEquals(new Class<?>[] { Integer.class, String.class, Boolean.class }, result);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Boolean.class, ClassUtils.primitiveToWrapper(boolean.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    // ---- toClass ----

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        assertArrayEquals(new Class<?>[0], ClassUtils.toClass());
    }

    @Test
    public void testToClassMixed() {
        Object[] array = new Object[] { "hello", Integer.valueOf(1), null };
        Class<?>[] result = ClassUtils.toClass(array);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, result);
    }

    // ---- wrappersToPrimitives / wrapperToPrimitive ----

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.wrappersToPrimitives());
        Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, Boolean.class);
        assertArrayEquals(new Class<?>[] { int.class, null, boolean.class }, result);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertEquals(boolean.class, ClassUtils.wrapperToPrimitive(Boolean.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    // ---- ClassUtils.Interfaces enum ----

    @Test
    public void testInterfacesEnumValues() {
        ClassUtils.Interfaces[] values = ClassUtils.Interfaces.values();
        assertEquals(2, values.length);
        assertSame(ClassUtils.Interfaces.INCLUDE, values[0]);
        assertSame(ClassUtils.Interfaces.EXCLUDE, values[1]);
    }

    @Test
    public void testInterfacesEnumValueOf() {
        assertSame(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertSame(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    @Test
    public void testInterfacesEnumValueOfUnknown() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.Interfaces.valueOf("NOT_A_CONSTANT");
            }
        });
    }

    @Test
    public void testInterfacesEnumValueOfNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.Interfaces.valueOf(null);
            }
        });
    }
}
