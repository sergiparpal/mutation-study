/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 */
class DurationFormatUtilsAgentTest {

    private static final long MILLIS_PER_SECOND = 1000L;
    private static final long MILLIS_PER_MINUTE = 60L * MILLIS_PER_SECOND;
    private static final long MILLIS_PER_HOUR = 60L * MILLIS_PER_MINUTE;
    private static final long MILLIS_PER_DAY = 24L * MILLIS_PER_HOUR;

    private static long utcMillis(final int year, final int month, final int day, final int hour, final int minute, final int second) {
        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal.getTimeInMillis();
    }

    // -- formatDuration --

    @Test
    void testFormatDurationZero() {
        assertEquals("0d0h0m0s", DurationFormatUtils.formatDuration(0L, "d'd'H'h'm'm's's'"));
    }

    @Test
    void testFormatDurationPadded() {
        final long millis = DurationFormatUtilsAgentTest.MILLIS_PER_HOUR + 2 * DurationFormatUtilsAgentTest.MILLIS_PER_MINUTE + 3 * DurationFormatUtilsAgentTest.MILLIS_PER_SECOND;
        assertEquals("01:02:03.000", DurationFormatUtils.formatDuration(millis, "HH:mm:ss.SSS"));
    }

    @Test
    void testFormatDurationUnpadded() {
        final long millis = DurationFormatUtilsAgentTest.MILLIS_PER_HOUR + 2 * DurationFormatUtilsAgentTest.MILLIS_PER_MINUTE + 3 * DurationFormatUtilsAgentTest.MILLIS_PER_SECOND;
        assertEquals("1:2:3", DurationFormatUtils.formatDuration(millis, "H:m:s", false));
    }

    @Test
    void testFormatDurationUnpaddedMillisecondsAfterSecondsAreStillPaddedToThree() {
        // the S token is always rendered with at least 3 digits when it directly follows an s token
        assertEquals("3.007", DurationFormatUtils.formatDuration(3007L, "s.S", false));
    }

    @Test
    void testFormatDurationNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "H:m:s");
            }
        });
    }

    @Test
    void testFormatDurationMaxValueDoesNotThrow() {
        assertNotNull(DurationFormatUtils.formatDuration(Long.MAX_VALUE, "d'd'H'h'm'm's's'"));
    }

    // -- formatDurationHMS --

    @Test
    void testFormatDurationHMSZero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
    }

    @Test
    void testFormatDurationHMSNonZero() {
        final long millis = DurationFormatUtilsAgentTest.MILLIS_PER_HOUR + 9 * DurationFormatUtilsAgentTest.MILLIS_PER_MINUTE + 5 * DurationFormatUtilsAgentTest.MILLIS_PER_SECOND + 7;
        assertEquals("01:09:05.007", DurationFormatUtils.formatDurationHMS(millis));
    }

    @Test
    void testFormatDurationHMSNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDurationHMS(-1L);
            }
        });
    }

    // -- formatDurationISO --

    @Test
    void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    @Test
    void testFormatDurationISONonZero() {
        final long millis = DurationFormatUtilsAgentTest.MILLIS_PER_DAY + DurationFormatUtilsAgentTest.MILLIS_PER_HOUR + 500;
        assertEquals("P0Y0M1DT1H0M0.500S", DurationFormatUtils.formatDurationISO(millis));
    }

    // -- formatDurationWords --

    @Test
    void testFormatDurationWordsZeroSuppressed() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0L, true, true));
    }

    @Test
    void testFormatDurationWordsZeroNotSuppressed() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0L, false, false));
    }

    @Test
    void testFormatDurationWordsSingularDay() {
        assertEquals("1 day 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(DurationFormatUtilsAgentTest.MILLIS_PER_DAY, true, false));
    }

    @Test
    void testFormatDurationWordsSuppressTrailingSingularMinute() {
        assertEquals("0 days 0 hours 1 minute",
                DurationFormatUtils.formatDurationWords(DurationFormatUtilsAgentTest.MILLIS_PER_MINUTE, false, true));
    }

    @Test
    void testFormatDurationWordsNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDurationWords(-1L, true, true);
            }
        });
    }

    // -- formatPeriod --

    @Test
    void testFormatPeriodStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(2000L, 1000L, "H:m:s");
            }
        });
    }

    @Test
    void testFormatPeriodStartEqualsEnd() {
        final long millis = utcMillis(2023, Calendar.JANUARY, 15, 10, 0, 0);
        assertEquals("0 0 0", DurationFormatUtils.formatPeriod(millis, millis, "y M d", true, TimeZone.getTimeZone("UTC")));
    }

    @Test
    void testFormatPeriodMonthsAndDays() {
        // January 15th to March 10th resolves to 1 month (January's 31 days) plus 26 remaining days.
        final long start = utcMillis(2023, Calendar.JANUARY, 15, 0, 0, 0);
        final long end = utcMillis(2023, Calendar.MARCH, 10, 0, 0, 0);
        assertEquals("1M26D", DurationFormatUtils.formatPeriod(start, end, "M'M'd'D'", true, TimeZone.getTimeZone("UTC")));
    }

    @Test
    void testFormatPeriodNoMonthToken() {
        // Without an M token, months get rolled forward into days.
        final long start = utcMillis(2023, Calendar.JANUARY, 1, 0, 0, 0);
        final long end = utcMillis(2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("1", DurationFormatUtils.formatPeriod(start, end, "d", true, TimeZone.getTimeZone("UTC")));
    }

    // -- formatPeriodISO --

    @Test
    void testFormatPeriodISOSameInstant() {
        final long millis = utcMillis(2023, Calendar.JUNE, 1, 0, 0, 0);
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(millis, millis));
    }

    @Test
    void testFormatPeriodISOStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriodISO(2000L, 1000L);
            }
        });
    }

    // -- optional token patterns (see class javadoc table) --

    @Test
    void testOptionalBlockWithDaysOnly() {
        assertEquals("1d0s", DurationFormatUtils.formatDuration(DurationFormatUtilsAgentTest.MILLIS_PER_DAY, "d'd'[H'h'm'm']s's'", true));
    }

    @Test
    void testOptionalBlockWithHoursOnly() {
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(DurationFormatUtilsAgentTest.MILLIS_PER_HOUR, "d'd'[H'h'm'm']s's'", true));
    }

    @Test
    void testOptionalBlockWithMinutesOnly() {
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(DurationFormatUtilsAgentTest.MILLIS_PER_MINUTE, "d'd'[H'h'm'm']s's'", true));
    }

    @Test
    void testOptionalBlockAllZero() {
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0L, "d'd'[H'h'm'm']s's'", true));
    }

    @Test
    void testOptionalBracketedTokensProduceEmptyStringForZero() {
        assertEquals("", DurationFormatUtils.formatDuration(0L, "[dHms]", true));
    }

    @Test
    void testOptionalBracketedTokensNonZero() {
        assertEquals("1", DurationFormatUtils.formatDuration(DurationFormatUtilsAgentTest.MILLIS_PER_DAY, "[dHms]", true));
    }

    // -- lexx() token parsing and error handling --

    @Test
    void testLexxNestedOptionalThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[H[m]]");
            }
        });
        assertTrue(e.getMessage().contains("Nested optional block"));
    }

    @Test
    void testLexxUnmatchedOptionalOpenThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[H");
            }
        });
        assertTrue(e.getMessage().contains("Unmatched optional"));
    }

    @Test
    void testLexxUnopenedOptionalCloseThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("H]");
            }
        });
        assertTrue(e.getMessage().contains("Attempting to close unopened optional block"));
    }

    @Test
    void testLexxUnmatchedQuoteThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("'abc");
            }
        });
        assertTrue(e.getMessage().contains("Unmatched quote"));
    }

    @Test
    void testLexxEscapedQuoteInsideLiteral() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("'it''s'");
        assertEquals(1, tokens.length);
        assertEquals("it's", tokens[0].toString());
    }

    @Test
    void testLexxStandaloneDoubleQuoteOutsideLiteral() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("''");
        assertEquals(1, tokens.length);
        assertEquals("'", tokens[0].toString());
    }

    @Test
    void testLexxRepeatedTokenCharactersAreCollapsed() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("HHHH");
        assertEquals(1, tokens.length);
        assertEquals(4, tokens[0].getCount());
        assertEquals("HHHH", tokens[0].toString());
    }

    @Test
    void testLexxEmptyFormatProducesNoTokens() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("");
        assertEquals(0, tokens.length);
    }

    // -- Token inner class --

    @Test
    void testTokenEqualsAndHashCode() {
        final DurationFormatUtils.Token[] a = DurationFormatUtils.lexx("HH");
        final DurationFormatUtils.Token[] b = DurationFormatUtils.lexx("HH");
        assertEquals(a[0], b[0]);
        assertEquals(a[0].hashCode(), b[0].hashCode());
    }

    @Test
    void testTokenNotEqualsDifferentCount() {
        final DurationFormatUtils.Token[] a = DurationFormatUtils.lexx("H");
        final DurationFormatUtils.Token[] b = DurationFormatUtils.lexx("HH");
        assertNotEquals(a[0], b[0]);
    }

    @Test
    void testTokenNotEqualsNonToken() {
        final DurationFormatUtils.Token[] a = DurationFormatUtils.lexx("H");
        assertNotEquals(a[0], "H");
    }

    @Test
    void testTokenContainsTokenWithValue() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("HH:mm");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.s));
    }

    @Test
    void testTokenGetValueAndCount() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyy");
        assertEquals(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(3, tokens[0].getCount());
    }

    // -- format() internal method --

    @Test
    void testFormatDirectInvocation() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("y'y'M'M'd'd'");
        final String result = DurationFormatUtils.format(tokens, 1, 2, 3, 0, 0, 0, 0, true);
        assertEquals("1y2M3d", result);
    }

    // -- deprecated public constructor --

    @Test
    @SuppressWarnings("deprecation")
    void testPublicConstructor() {
        assertNotNull(new DurationFormatUtils());
    }
}
