package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class TypeUtilsAgentTest {

    static class GenericFixture<T> {
        public List<T> listOfT;
        public List<String> listOfString;
        public T[] arrayOfT;
    }

    static class Unbounded<T> {
        public T value;
    }

    static class SingleBound<T extends Number> {
        public T value;
    }

    interface Container<T> {
        // marker generic interface used as a supertype fixture
    }

    static class SimpleContainer<T> implements Container<T> {
        // concrete generic implementation used to exercise type argument resolution
    }

    static class Box<T> {
        public T value;
        public List<T> listValue;
    }

    static class OuterGeneric<T> {
        class InnerGeneric<S> {
            // non-static inner class to exercise owner types
        }
    }

    private static Field field(final Class<?> cls, final String name) {
        try {
            return cls.getField(name);
        } catch (final NoSuchFieldException e) {
            throw new AssertionError(e);
        }
    }

    // ---- containsTypeVariables ----

    @Test
    public void testContainsTypeVariablesSimpleClass() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
    }

    @Test
    public void testContainsTypeVariablesTypeVariable() {
        final TypeVariable<?> tv = GenericFixture.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(tv));
    }

    @Test
    public void testContainsTypeVariablesParameterizedWithVariable() {
        final Type t = field(GenericFixture.class, "listOfT").getGenericType();
        assertTrue(TypeUtils.containsTypeVariables(t));
    }

    @Test
    public void testContainsTypeVariablesParameterizedWithConcreteArgument() {
        final Type t = field(GenericFixture.class, "listOfString").getGenericType();
        assertFalse(TypeUtils.containsTypeVariables(t));
    }

    @Test
    public void testContainsTypeVariablesGenericArray() {
        final Type t = field(GenericFixture.class, "arrayOfT").getGenericType();
        assertTrue(TypeUtils.containsTypeVariables(t));
    }

    // ---- determineTypeArguments ----

    @Test
    public void testDetermineTypeArguments() {
        final ParameterizedType superType = TypeUtils.parameterize(Container.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(SimpleContainer.class, superType);
        final TypeVariable<?> tv = SimpleContainer.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(tv));
    }

    @Test
    public void testDetermineTypeArgumentsNullClass() {
        final ParameterizedType superType = TypeUtils.parameterize(Container.class, String.class);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, superType);
            }
        });
    }

    @Test
    public void testDetermineTypeArgumentsNullSuperType() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(SimpleContainer.class, null);
            }
        });
    }

    // ---- equals ----

    @Test
    public void testEqualsSameClass() {
        assertTrue(TypeUtils.equals(String.class, String.class));
    }

    @Test
    public void testEqualsDifferentClass() {
        assertFalse(TypeUtils.equals(String.class, Integer.class));
    }

    @Test
    public void testEqualsBothNull() {
        assertTrue(TypeUtils.equals(null, null));
    }

    @Test
    public void testEqualsOneNull() {
        assertFalse(TypeUtils.equals(String.class, null));
        assertFalse(TypeUtils.equals(null, String.class));
    }

    @Test
    public void testEqualsStructurallyEqualParameterizedTypes() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, String.class);
        assertNotSame(a, b);
        assertTrue(TypeUtils.equals(a, b));
    }

    @Test
    public void testEqualsDifferentParameterizedTypes() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.equals(a, b));
    }

    // ---- genericArrayType ----

    @Test
    public void testGenericArrayType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
    }

    @Test
    public void testGenericArrayTypeOfArray() {
        final GenericArrayType inner = TypeUtils.genericArrayType(String.class);
        final GenericArrayType outer = TypeUtils.genericArrayType(inner);
        assertSame(inner, outer.getGenericComponentType());
    }

    // ---- getArrayComponentType ----

    @Test
    public void testGetArrayComponentTypeClassArray() {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
    }

    @Test
    public void testGetArrayComponentTypePrimitiveArray() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
    }

    @Test
    public void testGetArrayComponentTypeNonArray() {
        assertNull(TypeUtils.getArrayComponentType(String.class));
    }

    @Test
    public void testGetArrayComponentTypeGenericArray() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(gat));
    }

    // ---- getImplicitBounds ----

    @Test
    public void testGetImplicitBoundsUnbounded() {
        final TypeVariable<?> tv = Unbounded.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(tv);
        assertArrayEquals(new Type[] {Object.class}, bounds);
    }

    @Test
    public void testGetImplicitBoundsSingleBound() {
        final TypeVariable<?> tv = SingleBound.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(tv);
        assertArrayEquals(new Type[] {Number.class}, bounds);
    }

    @Test
    public void testGetImplicitBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    // ---- getImplicitLowerBounds ----

    @Test
    public void testGetImplicitLowerBoundsNoExplicitBound() {
        final WildcardType wt = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final Type[] lower = TypeUtils.getImplicitLowerBounds(wt);
        assertArrayEquals(new Type[] {null}, lower);
    }

    @Test
    public void testGetImplicitLowerBoundsExplicitBound() {
        final WildcardType wt = TypeUtils.wildcardType().withLowerBounds(Number.class).build();
        final Type[] lower = TypeUtils.getImplicitLowerBounds(wt);
        assertArrayEquals(new Type[] {Number.class}, lower);
    }

    @Test
    public void testGetImplicitLowerBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    // ---- getImplicitUpperBounds ----

    @Test
    public void testGetImplicitUpperBoundsNoExplicitBound() {
        final WildcardType wt = TypeUtils.wildcardType().build();
        final Type[] upper = TypeUtils.getImplicitUpperBounds(wt);
        assertArrayEquals(new Type[] {Object.class}, upper);
    }

    @Test
    public void testGetImplicitUpperBoundsExplicitBound() {
        final WildcardType wt = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final Type[] upper = TypeUtils.getImplicitUpperBounds(wt);
        assertArrayEquals(new Type[] {Number.class}, upper);
    }

    @Test
    public void testGetImplicitUpperBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    // ---- getRawType ----

    @Test
    public void testGetRawTypeClass() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    public void testGetRawTypeParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(pt, null));
    }

    @Test
    public void testGetRawTypeTypeVariableResolvedByAssigningType() {
        final Type fieldType = field(Box.class, "value").getGenericType();
        final Type assigningType = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(fieldType, assigningType));
    }

    @Test
    public void testGetRawTypeTypeVariableUnresolved() {
        final Type fieldType = field(Box.class, "value").getGenericType();
        assertNull(TypeUtils.getRawType(fieldType, null));
    }

    @Test
    public void testGetRawTypeGenericArrayType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String[].class, TypeUtils.getRawType(gat, null));
    }

    // ---- getTypeArguments(ParameterizedType) ----

    @Test
    public void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(pt);
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertEquals(1, result.size());
        assertEquals(String.class, result.get(e));
    }

    @Test
    public void testGetTypeArgumentsParameterizedTypeMultipleVariables() {
        final TypeVariable<?> k = Map.class.getTypeParameters()[0];
        final TypeVariable<?> v = Map.class.getTypeParameters()[1];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(k, String.class);
        map.put(v, Integer.class);
        final ParameterizedType pt = TypeUtils.parameterize(Map.class, map);
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(pt);
        assertEquals(String.class, result.get(k));
        assertEquals(Integer.class, result.get(v));
    }

    // ---- getTypeArguments(Type, Class) ----

    @Test
    public void testGetTypeArgumentsSubtype() {
        final ParameterizedType arrayListOfString = TypeUtils.parameterize(ArrayList.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(arrayListOfString, List.class);
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(e));
    }

    @Test
    public void testGetTypeArgumentsNotAssignableReturnsNull() {
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(String.class, List.class);
        assertNull(result);
    }

    @Test
    public void testGetTypeArgumentsNoTypeParametersReturnsEmptyMap() {
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(String.class, CharSequence.class);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ---- isArrayType ----

    @Test
    public void testIsArrayTypeClassArray() {
        assertTrue(TypeUtils.isArrayType(String[].class));
    }

    @Test
    public void testIsArrayTypeNonArray() {
        assertFalse(TypeUtils.isArrayType(String.class));
    }

    @Test
    public void testIsArrayTypeGenericArray() {
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    public void testIsArrayTypeParameterizedType() {
        assertFalse(TypeUtils.isArrayType(TypeUtils.parameterize(List.class, String.class)));
    }

    // ---- isAssignable ----

    @Test
    public void testIsAssignableSubclassToSuperclass() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
    }

    @Test
    public void testIsAssignableSuperclassToSubclass() {
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
    }

    @Test
    public void testIsAssignableRawClassToInterface() {
        assertTrue(TypeUtils.isAssignable(ArrayList.class, List.class));
    }

    @Test
    public void testIsAssignableMatchingParameterizedTypes() {
        final ParameterizedType from = TypeUtils.parameterize(ArrayList.class, String.class);
        final ParameterizedType to = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isAssignable(from, to));
    }

    @Test
    public void testIsAssignableMismatchedParameterizedTypes() {
        final ParameterizedType from = TypeUtils.parameterize(ArrayList.class, String.class);
        final ParameterizedType to = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.isAssignable(from, to));
    }

    // ---- isInstance ----

    @Test
    public void testIsInstanceTrue() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
    }

    @Test
    public void testIsInstanceFalse() {
        assertFalse(TypeUtils.isInstance(Integer.valueOf(5), String.class));
    }

    @Test
    public void testIsInstanceNullValue() {
        assertFalse(TypeUtils.isInstance(null, String.class));
    }

    // ---- normalizeUpperBounds ----

    @Test
    public void testNormalizeUpperBoundsStripsRedundantSupertype() {
        final Type[] bounds = new Type[] {Collection.class, List.class};
        final Type[] result = TypeUtils.normalizeUpperBounds(bounds);
        assertArrayEquals(new Type[] {List.class}, result);
    }

    @Test
    public void testNormalizeUpperBoundsNoRedundancy() {
        final Type[] bounds = new Type[] {Number.class};
        final Type[] result = TypeUtils.normalizeUpperBounds(bounds);
        assertArrayEquals(new Type[] {Number.class}, result);
    }

    @Test
    public void testNormalizeUpperBoundsEmptyArray() {
        final Type[] result = TypeUtils.normalizeUpperBounds(new Type[0]);
        assertEquals(0, result.length);
    }

    @Test
    public void testNormalizeUpperBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    // ---- parameterize(Class, Type...) ----

    @Test
    public void testParameterizeVarargs() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertArrayEquals(new Type[] {String.class}, pt.getActualTypeArguments());
        assertNull(pt.getOwnerType());
    }

    @Test
    public void testParameterizeVarargsNullRawClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(null, String.class);
            }
        });
    }

    // ---- parameterize(Class, Map) ----

    @Test
    public void testParameterizeWithMap() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(e, String.class);
        final ParameterizedType pt = TypeUtils.parameterize(List.class, map);
        assertArrayEquals(new Type[] {String.class}, pt.getActualTypeArguments());
    }

    @Test
    public void testParameterizeWithNullMap() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Map<TypeVariable<?>, Type>) null);
            }
        });
    }

    // ---- parameterizeWithOwner(Type, Class, Type...) ----

    @Test
    public void testParameterizeWithOwnerVarargsNoOwner() {
        final ParameterizedType pt = TypeUtils.parameterizeWithOwner(null, List.class, String.class);
        assertNull(pt.getOwnerType());
        assertEquals(List.class, pt.getRawType());
        assertArrayEquals(new Type[] {String.class}, pt.getActualTypeArguments());
    }

    @Test
    public void testParameterizeWithOwnerVarargsWithOwner() {
        final ParameterizedType ownerType = TypeUtils.parameterize(OuterGeneric.class, String.class);
        final ParameterizedType innerType = TypeUtils.parameterizeWithOwner(ownerType, OuterGeneric.InnerGeneric.class, Integer.class);
        assertTrue(TypeUtils.equals(ownerType, innerType.getOwnerType()));
        assertEquals(OuterGeneric.InnerGeneric.class, innerType.getRawType());
        assertArrayEquals(new Type[] {Integer.class}, innerType.getActualTypeArguments());
    }

    @Test
    public void testParameterizeWithOwnerVarargsNullRawClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(null, null, String.class);
            }
        });
    }

    // ---- parameterizeWithOwner(Type, Class, Map) ----

    @Test
    public void testParameterizeWithOwnerMap() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(e, String.class);
        final ParameterizedType pt = TypeUtils.parameterizeWithOwner(null, List.class, map);
        assertNull(pt.getOwnerType());
        assertArrayEquals(new Type[] {String.class}, pt.getActualTypeArguments());
    }

    // ---- toLongString ----

    @Test
    public void testToLongString() {
        final TypeVariable<?> tv = SingleBound.class.getTypeParameters()[0];
        final String result = TypeUtils.toLongString(tv);
        assertNotNull(result);
        assertTrue(result.contains(tv.getName()));
        assertTrue(result.contains("SingleBound"));
    }

    @Test
    public void testToLongStringNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    // ---- toString ----

    @Test
    public void testToStringClass() {
        final String result = TypeUtils.toString(String.class);
        assertNotNull(result);
        assertTrue(result.contains("String"));
    }

    @Test
    public void testToStringParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final String result = TypeUtils.toString(pt);
        assertTrue(result.contains("List"));
        assertTrue(result.contains("String"));
    }

    @Test
    public void testToStringNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(null);
            }
        });
    }

    // ---- typesSatisfyVariables ----

    @Test
    public void testTypesSatisfyVariablesTrue() {
        final TypeVariable<?> tv = SingleBound.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesFalse() {
        final TypeVariable<?> tv = SingleBound.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    // ---- unrollVariables ----

    @Test
    public void testUnrollVariablesResolvesTypeVariable() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, String.class);
        final Type fieldType = field(Box.class, "value").getGenericType();
        final Type result = TypeUtils.unrollVariables(map, fieldType);
        assertEquals(String.class, result);
    }

    @Test
    public void testUnrollVariablesResolvesParameterizedType() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, String.class);
        final Type fieldType = field(Box.class, "listValue").getGenericType();
        final Type result = TypeUtils.unrollVariables(map, fieldType);
        final ParameterizedType expected = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.equals(expected, result));
    }

    @Test
    public void testUnrollVariablesNoVariablesUnchanged() {
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        final Type result = TypeUtils.unrollVariables(map, String.class);
        assertEquals(String.class, result);
    }

    // ---- wildcardType / WildcardTypeBuilder ----

    @Test
    public void testWildcardTypeDefaultMatchesWildcardAll() {
        final WildcardType wt = TypeUtils.wildcardType().build();
        assertTrue(TypeUtils.equals(wt, TypeUtils.WILDCARD_ALL));
    }

    @Test
    public void testWildcardTypeWithUpperBounds() {
        final WildcardType wt = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertArrayEquals(new Type[] {Number.class}, wt.getUpperBounds());
    }

    @Test
    public void testWildcardTypeWithLowerBounds() {
        final WildcardType wt = TypeUtils.wildcardType().withLowerBounds(Number.class).build();
        assertArrayEquals(new Type[] {Number.class}, wt.getLowerBounds());
    }

    @Test
    public void testWildcardTypeBuilderReturnsSameInstance() {
        final TypeUtils.WildcardTypeBuilder builder = TypeUtils.wildcardType();
        assertSame(builder, builder.withUpperBounds(Number.class));
        assertSame(builder, builder.withLowerBounds(Number.class));
    }

    // ---- wrap ----

    @Test
    public void testWrapClass() {
        final Object wrapped = TypeUtils.wrap(String.class);
        assertNotNull(wrapped);
        assertTrue(wrapped instanceof Typed);
    }

    @Test
    public void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Object wrapped = TypeUtils.wrap((Type) pt);
        assertNotNull(wrapped);
        assertTrue(wrapped instanceof Typed);
    }
}
