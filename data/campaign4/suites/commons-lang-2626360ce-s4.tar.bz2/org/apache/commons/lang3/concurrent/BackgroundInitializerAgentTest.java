package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link BackgroundInitializer} based solely on its documented contract.
 */
public class BackgroundInitializerAgentTest {

    /** A background initializer that simply returns a fixed result. */
    private static class ResultInitializer extends BackgroundInitializer<Object> {
        private final Object result;

        ResultInitializer(final Object result) {
            super();
            this.result = result;
        }

        ResultInitializer(final Object result, final ExecutorService exec) {
            super(exec);
            this.result = result;
        }

        @Override
        protected Object initialize() throws Exception {
            return result;
        }
    }

    /** A background initializer whose {@code getTaskCount()} is overridden. */
    private static class CountingTaskCountInitializer extends BackgroundInitializer<Object> {
        private final int taskCount;

        CountingTaskCountInitializer(final int taskCount) {
            this.taskCount = taskCount;
        }

        @Override
        protected int getTaskCount() {
            return taskCount;
        }

        @Override
        protected Object initialize() throws Exception {
            return "counting-value";
        }
    }

    /** A background initializer that blocks until explicitly released, for synchronization checks. */
    private static class LatchInitializer extends BackgroundInitializer<Object> {
        final CountDownLatch startLatch = new CountDownLatch(1);
        final CountDownLatch releaseLatch = new CountDownLatch(1);

        @Override
        protected Object initialize() throws Exception {
            startLatch.countDown();
            releaseLatch.await();
            return "latched-result";
        }
    }

    /** A background initializer that fails with a given checked exception. */
    private static class CheckedExceptionInitializer extends BackgroundInitializer<Object> {
        private final Exception exceptionToThrow;

        CheckedExceptionInitializer(final Exception exceptionToThrow) {
            this.exceptionToThrow = exceptionToThrow;
        }

        @Override
        protected Object initialize() throws Exception {
            throw exceptionToThrow;
        }
    }

    /** A background initializer that fails with a given runtime exception. */
    private static class RuntimeExceptionInitializer extends BackgroundInitializer<Object> {
        private final RuntimeException exceptionToThrow;

        RuntimeExceptionInitializer(final RuntimeException exceptionToThrow) {
            this.exceptionToThrow = exceptionToThrow;
        }

        @Override
        protected Object initialize() throws Exception {
            throw exceptionToThrow;
        }
    }

    private ExecutorService externalExecutor;

    @AfterEach
    public void tearDown() {
        if (externalExecutor != null) {
            externalExecutor.shutdownNow();
            externalExecutor = null;
        }
    }

    @Test
    public void testInitialStateBeforeStart() {
        final ResultInitializer initializer = new ResultInitializer("value");
        assertFalse(initializer.isStarted());
        assertFalse(initializer.isInitialized());
        assertNull(initializer.getActiveExecutor());
        assertNull(initializer.getExternalExecutor());
    }

    @Test
    public void testGetBeforeStartThrowsIllegalStateException() {
        final ResultInitializer initializer = new ResultInitializer("value");
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                initializer.get();
            }
        });
    }

    @Test
    public void testGetFutureBeforeStartThrowsIllegalStateException() {
        final ResultInitializer initializer = new ResultInitializer("value");
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                initializer.getFuture();
            }
        });
    }

    @Test
    public void testStartReturnsTrueOnlyOnce() throws ConcurrentException {
        final ResultInitializer initializer = new ResultInitializer("value");
        assertTrue(initializer.start());
        assertTrue(initializer.isStarted());
        assertFalse(initializer.start());
        assertFalse(initializer.start());
        assertEquals("value", initializer.get());
    }

    @Test
    public void testGetReturnsResultAndMarksInitialized() throws ConcurrentException {
        final ResultInitializer initializer = new ResultInitializer("hello");
        initializer.start();
        final Object result = initializer.get();
        assertEquals("hello", result);
        assertTrue(initializer.isInitialized());
    }

    @Test
    public void testGetFutureAfterStart() throws Exception {
        final ResultInitializer initializer = new ResultInitializer("future-value");
        initializer.start();
        final Future<Object> future = initializer.getFuture();
        assertNotNull(future);
        assertEquals("future-value", future.get());
        assertTrue(future.isDone());
        assertEquals("future-value", initializer.get());
    }

    @Test
    public void testBackgroundProcessingRunsAsynchronously() throws Exception {
        final LatchInitializer initializer = new LatchInitializer();
        assertTrue(initializer.start());
        assertTrue(initializer.startLatch.await(5, TimeUnit.SECONDS));
        assertFalse(initializer.isInitialized());
        initializer.releaseLatch.countDown();
        final Object result = initializer.get();
        assertEquals("latched-result", result);
        assertTrue(initializer.isInitialized());
    }

    @Test
    public void testGetWrapsCheckedExceptionInConcurrentException() {
        final Exception cause = new Exception("checked failure");
        final CheckedExceptionInitializer initializer = new CheckedExceptionInitializer(cause);
        initializer.start();
        final ConcurrentException thrown = assertThrows(ConcurrentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                initializer.get();
            }
        });
        assertSame(cause, thrown.getCause());
        assertFalse(initializer.isInitialized());
    }

    @Test
    public void testGetRethrowsRuntimeExceptionDirectly() {
        final RuntimeException cause = new RuntimeException("runtime failure");
        final RuntimeExceptionInitializer initializer = new RuntimeExceptionInitializer(cause);
        initializer.start();
        final RuntimeException thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                initializer.get();
            }
        });
        assertSame(cause, thrown);
        assertFalse(initializer.isInitialized());
    }

    @Test
    public void testSetExternalExecutorBeforeStartIsUsedAsActiveExecutor() throws ConcurrentException {
        externalExecutor = Executors.newFixedThreadPool(2);
        final ResultInitializer initializer = new ResultInitializer("value");
        initializer.setExternalExecutor(externalExecutor);
        assertSame(externalExecutor, initializer.getExternalExecutor());
        assertNull(initializer.getActiveExecutor());
        initializer.start();
        assertSame(externalExecutor, initializer.getActiveExecutor());
        assertEquals("value", initializer.get());
        assertFalse(externalExecutor.isShutdown());
    }

    @Test
    public void testExternalExecutorPassedToConstructor() throws ConcurrentException {
        externalExecutor = Executors.newSingleThreadExecutor();
        final ResultInitializer initializer = new ResultInitializer("ctor-value", externalExecutor);
        assertSame(externalExecutor, initializer.getExternalExecutor());
        initializer.start();
        assertSame(externalExecutor, initializer.getActiveExecutor());
        assertEquals("ctor-value", initializer.get());
        assertFalse(externalExecutor.isShutdown());
    }

    @Test
    public void testNullExecutorPassedToConstructorCreatesTemporaryExecutor() throws ConcurrentException {
        final ResultInitializer initializer = new ResultInitializer("value", null);
        assertNull(initializer.getExternalExecutor());
        initializer.start();
        assertNotNull(initializer.getActiveExecutor());
        assertEquals("value", initializer.get());
    }

    @Test
    public void testSetExternalExecutorWithNullIsPermitted() throws ConcurrentException {
        final ResultInitializer initializer = new ResultInitializer("value");
        initializer.setExternalExecutor(null);
        assertNull(initializer.getExternalExecutor());
        initializer.start();
        assertNotNull(initializer.getActiveExecutor());
        assertEquals("value", initializer.get());
    }

    @Test
    public void testSetExternalExecutorAfterStartThrowsIllegalStateException() throws ConcurrentException {
        final ResultInitializer initializer = new ResultInitializer("value");
        initializer.start();
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            assertThrows(IllegalStateException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    initializer.setExternalExecutor(exec);
                }
            });
        } finally {
            initializer.get();
            exec.shutdownNow();
        }
    }

    @Test
    public void testTemporaryExecutorIsDestroyedAfterCompletion() throws ConcurrentException {
        final ResultInitializer initializer = new ResultInitializer("value");
        initializer.start();
        final ExecutorService active = initializer.getActiveExecutor();
        assertNotNull(active);
        initializer.get();
        assertTrue(active.isShutdown());
    }

    @Test
    public void testGetTaskCountDefaultIsOne() {
        final ResultInitializer initializer = new ResultInitializer("value");
        assertEquals(1, initializer.getTaskCount());
    }

    @Test
    public void testGetTaskCountCanBeOverridden() {
        final CountingTaskCountInitializer initializer = new CountingTaskCountInitializer(5);
        assertEquals(5, initializer.getTaskCount());
    }

    @Test
    public void testGetTypedExceptionReturnsNonNullRelatedException() {
        final ResultInitializer initializer = new ResultInitializer("value");
        final Exception input = new Exception("boom");
        final Exception typed = initializer.getTypedException(input);
        assertNotNull(typed);
        assertTrue(typed == input || typed.getCause() == input);
    }

    @Test
    public void testBuilderReturnsNonNullBuilder() {
        final BackgroundInitializer.Builder<BackgroundInitializer<Object>, Object> builder =
                BackgroundInitializer.<Object>builder();
        assertNotNull(builder);
    }

    @Test
    public void testBuilderSetExternalExecutorReturnsSameBuilderInstance() {
        final BackgroundInitializer.Builder<BackgroundInitializer<Object>, Object> builder =
                BackgroundInitializer.<Object>builder();
        final BackgroundInitializer.Builder<BackgroundInitializer<Object>, Object> same =
                builder.setExternalExecutor(null);
        assertSame(builder, same);
    }

    @Test
    public void testTwoIndependentInitializersDoNotShareState() throws ConcurrentException {
        final ResultInitializer first = new ResultInitializer("first");
        final ResultInitializer second = new ResultInitializer("second");
        first.start();
        second.start();
        assertEquals("first", first.get());
        assertEquals("second", second.get());
        assertNotSame(first.getFuture(), second.getFuture());
    }
}
