package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVParser} based solely on its documented contract.
 */
public class CSVParserAgentTest {

    private static File createTempCsvFile(String content) throws IOException {
        File file = File.createTempFile("csvparser-agent-test", ".csv");
        file.deleteOnExit();
        FileWriter writer = new FileWriter(file);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    // ---- static factory: parse(String, CSVFormat) ----

    @Test
    public void parseString_basicContent_returnsExpectedRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void parseString_nullString_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void parseString_nullFormat_usesDefaultFormat() throws IOException {
        CSVParser parser = CSVParser.parse("x,y\n1,2\n", null);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("y", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- static factory: parse(Reader, CSVFormat) ----

    @Test
    public void parseReader_nullReader_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void parseReader_basicContent_returnsExpectedRecords() throws IOException {
        CSVParser parser = CSVParser.parse(new StringReader("1,2\n3,4\n"), CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("4", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- deprecated constructors ----

    @Test
    public void deprecatedConstructor_nullReader_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void deprecatedConstructor_nullFormat_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser(new StringReader("a,b"), null);
            }
        });
    }

    @Test
    public void deprecatedConstructorWithOffsets_customRecordNumber_isAssignedToFirstRecord() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT, 0L, 5L);
        try {
            assertEquals(4, parser.getRecordNumber());
            Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(5, parser.getRecordNumber());
            it.next();
            assertEquals(6, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- static factory: parse(File, Charset, CSVFormat) ----

    @Test
    public void parseFile_nullFile_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void parseFile_nullFormat_usesDefaultFormat() throws IOException {
        File file = createTempCsvFile("p,q\n7,8\n");
        CSVParser parser = CSVParser.parse(file, StandardCharsets.UTF_8, null);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("7", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    // ---- static factory: parse(Path, Charset, CSVFormat) ----

    @Test
    public void parsePath_nullPath_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void parsePath_validArgs_parsesCorrectly() throws IOException {
        File file = createTempCsvFile("m,n\n9,10\n");
        CSVParser parser = CSVParser.parse(file.toPath(), StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("10", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- static factory: parse(URL, Charset, CSVFormat) ----

    @Test
    public void parseURL_nullURL_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void parseURL_validArgs_parsesCorrectly() throws IOException {
        File file = createTempCsvFile("u,v\n11,12\n");
        URL url = file.toURI().toURL();
        CSVParser parser = CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("11", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    // ---- static factory: parse(InputStream, Charset, CSVFormat) ----

    @Test
    public void parseInputStream_validArgs_parsesCorrectly() throws IOException {
        File file = createTempCsvFile("i,j\n13,14\n");
        InputStream in = new FileInputStream(file);
        CSVParser parser = CSVParser.parse(in, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("14", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- builder() ----

    @Test
    public void builder_get_buildsParserThatParsesCorrectly() throws IOException {
        CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("k,l\n15,16\n"))
                .setFormat(CSVFormat.DEFAULT)
                .get();
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("16", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void builder_setFormatNull_resetsToDefaultFormat() throws IOException {
        CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("o,p\n17,18\n"))
                .setFormat(null)
                .get();
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("17", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void builder_setRecordNumber_isAssignedToFirstRecord() throws IOException {
        CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a,b\nc,d\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(100L)
                .get();
        try {
            Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(100, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- getRecords() ----

    @Test
    public void getRecords_secondCall_returnsEmptyListBecauseStreamAlreadyConsumed() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> first = parser.getRecords();
            assertEquals(2, first.size());
            List<CSVRecord> second = parser.getRecords();
            assertNotNull(second);
            assertTrue(second.isEmpty());
        } finally {
            parser.close();
        }
    }

    // ---- iterator() ----

    @Test
    public void iterator_afterAllRecordsConsumed_hasNextFalseAndNextThrows() throws IOException {
        CSVParser parser = CSVParser.parse("a\n1\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            it.next();
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            final Iterator<CSVRecord> exhausted = it;
            assertThrows(NoSuchElementException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    exhausted.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void iterator_afterClose_hasNextFalseAndNextThrows() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    // ---- close() / isClosed() ----

    @Test
    public void isClosed_falseBeforeClose_trueAfterClose() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ---- getCurrentLineNumber() / getRecordNumber() ----

    @Test
    public void getCurrentLineNumberAndRecordNumber_incrementAsRecordsAreRead() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            Iterator<CSVRecord> it = parser.iterator();

            it.next();
            long lineAfterFirst = parser.getCurrentLineNumber();
            assertEquals(1, parser.getRecordNumber());
            assertEquals(1, lineAfterFirst);

            it.next();
            long lineAfterSecond = parser.getCurrentLineNumber();
            assertEquals(2, parser.getRecordNumber());
            assertTrue(lineAfterSecond >= lineAfterFirst);
        } finally {
            parser.close();
        }
    }

    // ---- getHeaderMap() / getHeaderNames() / getHeaderMapRaw() ----

    @Test
    public void getHeaderMapAndNames_withExplicitHeader_reflectColumnOrder() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("Name", "Age")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("Name,Age\nAlice,30\n", format);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("Name"));
            assertEquals(Integer.valueOf(1), headerMap.get("Age"));

            List<String> headerNames = parser.getHeaderNames();
            assertEquals(2, headerNames.size());
            assertEquals("Name", headerNames.get(0));
            assertEquals("Age", headerNames.get(1));

            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("Alice", records.get(0).get("Name"));
            assertEquals("30", records.get(0).get("Age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void getHeaderMap_returnsCopy_mutationDoesNotAffectFutureCopies() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("Name", "Age")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("Name,Age\nAlice,30\n", format);
        try {
            Map<String, Integer> firstCopy = parser.getHeaderMap();
            firstCopy.put("Injected", 42);

            Map<String, Integer> secondCopy = parser.getHeaderMap();
            assertFalse(secondCopy.containsKey("Injected"));
            assertEquals(Integer.valueOf(0), secondCopy.get("Name"));
            assertEquals(Integer.valueOf(1), secondCopy.get("Age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void getHeaderMapRaw_returnsLiveUnderlyingMap() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("Name", "Age")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("Name,Age\nAlice,30\n", format);
        try {
            Map<String, Integer> raw = parser.getHeaderMapRaw();
            raw.put("Injected", 42);

            Map<String, Integer> rawAgain = parser.getHeaderMapRaw();
            assertEquals(Integer.valueOf(42), rawAgain.get("Injected"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void getHeaderNames_isReadOnly() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("Name", "Age")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("Name,Age\nAlice,30\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertThrows(UnsupportedOperationException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    headerNames.add("Extra");
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void getHeaderMapAndNames_withoutHeaderFormat_areEmpty() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            assertTrue(headerMap.isEmpty());

            List<String> headerNames = parser.getHeaderNames();
            assertNotNull(headerNames);
            assertTrue(headerNames.isEmpty());
        } finally {
            parser.close();
        }
    }

    // ---- header / trailer comments ----

    @Test
    public void hasHeaderComment_noCommentMarkerConfigured_falseAndNull() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void headerComment_precedingExplicitSkippedHeader_isDetected() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("A", "B")
                .setSkipHeaderRecord(true)
                .setCommentMarker('#')
                .build();
        CSVParser parser = CSVParser.parse("# a header comment\nx,y\n1,2\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasHeaderComment());
            assertNotNull(parser.getHeaderComment());
            assertTrue(parser.getHeaderComment().contains("a header comment"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void hasTrailerComment_falseAndNull_whenNoTrailingComment() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        try {
            parser.getRecords();
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void trailerComment_afterFullConsumption_isDetected() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        CSVParser parser = CSVParser.parse("a,b\n1,2\n#a trailer comment\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasTrailerComment());
            assertNotNull(parser.getTrailerComment());
            assertTrue(parser.getTrailerComment().contains("a trailer comment"));
        } finally {
            parser.close();
        }
    }

    // ---- stream() ----

    @Test
    public void stream_returnsSequentialStreamOverAllRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            Stream<CSVRecord> stream = parser.stream();
            assertNotNull(stream);
            assertEquals(2, stream.count());
        } finally {
            parser.close();
        }
    }

    // ---- getFirstEndOfLine() ----

    @Test
    public void getFirstEndOfLine_returnsFirstEncounteredLineSeparator() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\r\n1,2\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    // ---- nextRecord() (package-private) ----

    @Test
    public void nextRecord_returnsRecordsThenNullAtEndOfStream() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            CSVRecord first = parser.nextRecord();
            assertNotNull(first);
            assertEquals("a", first.get(0));

            CSVRecord second = parser.nextRecord();
            assertNotNull(second);
            assertEquals("1", second.get(0));

            CSVRecord third = parser.nextRecord();
            assertNull(third);
        } finally {
            parser.close();
        }
    }

    // ---- misc: Files helper sanity for Path-based parsing content ----

    @Test
    public void parsePath_contentReadBackMatchesWrittenBytes() throws IOException {
        File file = createTempCsvFile("z,w\n5,6\n");
        byte[] bytesOnDisk = Files.readAllBytes(file.toPath());
        assertTrue(bytesOnDisk.length > 0);

        CSVParser parser = CSVParser.parse(file.toPath(), StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("6", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- Map fixture sanity used indirectly (no external test-helper dependency) ----

    @Test
    public void getHeaderMap_withDuplicateLogicNotApplicable_stillEqualsExpectedMap() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("Name", "Age")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("Name,Age\nAlice,30\n", format);
        try {
            Map<String, Integer> expected = new HashMap<String, Integer>();
            expected.put("Name", 0);
            expected.put("Age", 1);
            assertEquals(expected, parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }
}
