/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    @Test
    void testAcceptCallsConsumerWithMillisAndNanoRemainder() {
        final Duration duration = Duration.ofSeconds(1).plusNanos(1_500_001);
        final long[] capturedMillis = new long[1];
        final int[] capturedNanos = new int[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                capturedMillis[0] = millis;
                capturedNanos[0] = nanos;
            }
        }, duration);
        assertEquals(duration.toMillis(), capturedMillis[0]);
        assertEquals(500001, capturedNanos[0]);
    }

    @Test
    void testAcceptNullConsumerIsNoOp() {
        // Should not throw even though the consumer is null.
        DurationUtils.accept(null, Duration.ofSeconds(1));
    }

    @Test
    void testAcceptNullDurationIsNoOp() {
        final boolean[] called = new boolean[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                called[0] = true;
            }
        }, null);
        assertFalse(called[0]);
    }

    @Test
    void testGetUsesDefaultWhenKeyMissing() {
        final Duration duration = DurationUtils.get("org.apache.commons.lang3.time.DurationUtilsAgentTest.missing",
                ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(42), duration);
    }

    @Test
    void testGetWithEmptyKeyUsesDefault() {
        final Duration duration = DurationUtils.get("", ChronoUnit.MILLIS, 7L);
        assertEquals(Duration.ofMillis(7), duration);
    }

    @Test
    void testGetMillisUsesDefaultWhenKeyMissing() {
        final Duration duration = DurationUtils.getMillis("org.apache.commons.lang3.time.DurationUtilsAgentTest.missingMillis", 123L);
        assertEquals(Duration.ofMillis(123), duration);
    }

    @Test
    void testGetSecondsUsesDefaultWhenKeyMissing() {
        final Duration duration = DurationUtils.getSeconds("org.apache.commons.lang3.time.DurationUtilsAgentTest.missingSeconds", 9L);
        assertEquals(Duration.ofSeconds(9), duration);
    }

    @Test
    void testGetNanosOfMilliZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofSeconds(1)));
    }

    @Test
    void testGetNanosOfMilliNonZero() {
        assertEquals(999999, DurationUtils.getNanosOfMilli(Duration.ofNanos(1999999)));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testGetNanosOfMiiliDelegatesToGetNanosOfMilli() {
        final Duration duration = Duration.ofNanos(2500000);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testGetNanosOfMilliOnNullReturnsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testIsPositiveTrue() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
    }

    @Test
    void testIsPositiveFalseForZero() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    void testIsPositiveFalseForNegative() {
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    @Test
    void testOfRunnableMeasuresElapsedNonNegativeDuration() throws Throwable {
        final Duration duration = DurationUtils.of(new FailableRunnable<Throwable>() {
            @Override
            public void run() {
                // Intentionally empty; we only verify the Duration is well-formed.
            }
        });
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfConsumerReceivesStartInstant() throws Throwable {
        final Instant[] capturedStart = new Instant[1];
        final Duration duration = DurationUtils.of(new FailableConsumer<Instant, Throwable>() {
            @Override
            public void accept(final Instant start) {
                capturedStart[0] = start;
            }
        });
        assertNotNull(capturedStart[0]);
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfRunnablePropagatesException() {
        final IllegalStateException expected = new IllegalStateException("boom");
        final IllegalStateException thrown = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<IllegalStateException>() {
                    @Override
                    public void run() {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, thrown);
    }

    @Test
    void testSinceReturnsNonNegativeDurationForPastInstant() {
        final Instant past = Instant.now().minusSeconds(1);
        final Duration duration = DurationUtils.since(past);
        assertFalse(duration.isNegative());
        assertTrue(duration.toMillis() >= 1000);
    }

    @Test
    void testToDurationSeconds() {
        assertEquals(Duration.ofSeconds(5), DurationUtils.toDuration(5, TimeUnit.SECONDS));
    }

    @Test
    void testToDurationMilliseconds() {
        assertEquals(Duration.ofMillis(250), DurationUtils.toDuration(250, TimeUnit.MILLISECONDS));
    }

    @Test
    void testToDurationNegativeAmount() {
        assertEquals(Duration.ofSeconds(-3), DurationUtils.toDuration(-3, TimeUnit.SECONDS));
    }

    @Test
    void testToMillisIntNormalValue() {
        assertEquals(1000, DurationUtils.toMillisInt(Duration.ofSeconds(1)));
    }

    @Test
    void testToMillisIntClampsToIntegerMaxValue() {
        final Duration huge = Duration.ofDays(365 * 1000);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntClampsToIntegerMinValue() {
        final Duration huge = Duration.ofDays(365 * 1000).negated();
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testZeroIfNullReturnsZeroForNull() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNullReturnsSameInstanceWhenNonNull() {
        final Duration duration = Duration.ofSeconds(3);
        assertSame(duration, DurationUtils.zeroIfNull(duration));
    }

    @Test
    void testToChronoUnitMapsAllTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnitNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDefaultConstructor() {
        assertNotNull(new DurationUtils());
    }
}
