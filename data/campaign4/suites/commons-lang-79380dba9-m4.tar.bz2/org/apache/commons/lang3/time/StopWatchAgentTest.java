/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link StopWatch}.
 */
class StopWatchAgentTest {

    @Test
    void testCreateReturnsUnstartedStopWatch() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testCreateStartedReturnsStartedStopWatch() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    void testMessageConstructorStoresMessage() {
        final StopWatch watch = new StopWatch("my-message");
        assertEquals("my-message", watch.getMessage());
    }

    @Test
    void testGetNanoTimeIsZeroBeforeStart() {
        final StopWatch watch = new StopWatch();
        assertEquals(0L, watch.getNanoTime());
        assertEquals(0L, watch.getTime());
        assertEquals(Duration.ZERO, watch.getDuration());
    }

    @Test
    void testStartThenStopProducesNonNegativeElapsedTime() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertTrue(watch.isStarted());
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getNanoTime() >= 0);
        assertTrue(watch.getTime() >= 0);
        assertFalse(watch.getDuration().isNegative());
    }

    @Test
    void testStartTwiceWithoutResetThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
        assertNotNull(e.getMessage());
    }

    @Test
    void testStartAfterStopWithoutResetThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStartAfterResetSucceeds() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.stop();
        watch.reset();
        assertTrue(watch.isStopped());
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    void testStopWithoutStartThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testStopTwiceThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testSuspendWithoutStartThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testSuspendTwiceThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testSuspendThenResumeKeepsRunning() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        watch.resume();
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStarted());
        watch.stop();
        assertTrue(watch.getNanoTime() >= 0);
    }

    @Test
    void testResumeWithoutSuspendThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    void testSplitBeforeStartThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testSplitTwiceAddsTwoSplits() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split();
        watch.split();
        assertEquals(2, watch.getSplits().size());
    }

    @Test
    void testSplitRecordsSplitAndAllowsGetSplitDuration() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split();
        assertFalse(watch.getSplitDuration().isNegative());
        assertTrue(watch.getSplitNanoTime() >= 0);
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
    }

    @Test
    void testSplitWithLabelStoresLabel() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split("first-split");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first-split", splits.get(0).getLabel());
        assertSame(splits.get(0).getDuration(), splits.get(0).getRight());
        assertEquals("first-split", splits.get(0).getLeft());
    }

    @Test
    void testGetSplitsReturnsUnmodifiableList() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testGetSplitDurationWithoutSplitThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitDuration();
            }
        });
    }

    @Test
    void testUnsplitWithoutSplitThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.unsplit();
            }
        });
    }

    @Test
    void testUnsplitRemovesLastSplitAndAllowsContinuedTiming() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split();
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitDuration();
            }
        });
        // Timing should continue uninterrupted from the original start point.
        watch.stop();
        assertTrue(watch.getNanoTime() >= 0);
    }

    @Test
    void testResetClearsSplitsAndState() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split();
        watch.reset();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitDuration();
            }
        });
    }

    @Test
    void testGetStartInstantBeforeStartThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStartInstant();
            }
        });
    }

    @Test
    void testGetStartInstantAfterStartIsNotNull() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertNotNull(watch.getStartInstant());
    }

    @Test
    void testGetStopInstantBeforeStartThrowsIllegalStateException() {
        final StopWatch watch = StopWatch.create();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStopInstant();
            }
        });
    }

    @Test
    void testGetStopInstantBeforeStopIsNull() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertNull(watch.getStopInstant());
    }

    @Test
    void testGetStopInstantAfterStopIsNotNull() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.stop();
        assertNotNull(watch.getStopInstant());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedGetStartTimeMatchesStartInstant() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedGetStopTimeIsZeroBeforeStop() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        assertEquals(0L, watch.getStopTime());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedGetSplitTimeMatchesSplitNanoTimeInMillis() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.split();
        assertEquals(watch.getSplitNanoTime() / 1000000L, watch.getSplitTime());
    }

    @Test
    void testGetTimeTimeUnitConversion() {
        final StopWatch watch = StopWatch.create();
        watch.start();
        watch.suspend();
        // getTime(TimeUnit.HOURS) rounds down; elapsed time is far below one hour.
        assertEquals(0L, watch.getTime(TimeUnit.HOURS));
        assertTrue(watch.getTime(TimeUnit.NANOSECONDS) >= 0);
    }

    @Test
    void testFormatTimeAndToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final String formatted = watch.formatTime();
        assertEquals(12, formatted.length());
        assertEquals(formatted, watch.toString());
    }

    @Test
    void testToStringWithMessagePrefixesMessage() {
        final StopWatch watch = new StopWatch("Baking cookies");
        watch.start();
        watch.suspend();
        assertTrue(watch.toString().startsWith("Baking cookies "));
    }

    @Test
    void testFormatSplitTimeAndToSplitStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String formatted = watch.formatSplitTime();
        assertEquals(12, formatted.length());
        assertEquals(formatted, watch.toSplitString());
    }

    @Test
    void testToSplitStringWithMessagePrefixesMessage() {
        final StopWatch watch = new StopWatch("Split message");
        watch.start();
        watch.split();
        assertTrue(watch.toSplitString().startsWith("Split message "));
    }

    @Test
    void testGetSupplierReturnsResultAndSuspendsAfterwards() {
        final StopWatch watch = StopWatch.create();
        final String result = watch.get(new Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetSupplierSuspendsEvenWhenSupplierThrows() {
        final StopWatch watch = StopWatch.create();
        final RuntimeException expected = new RuntimeException("boom");
        final RuntimeException thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() {
                watch.get(new Supplier<String>() {
                    @Override
                    public String get() {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, thrown);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunRunnableStartsAndSuspends() {
        final StopWatch watch = StopWatch.create();
        final boolean[] ran = new boolean[1];
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTCanPropagateCheckedException() {
        final StopWatch watch = StopWatch.create();
        final Exception expected = new Exception("checked-failure");
        final Throwable thrown = assertThrows(Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getT(new FailableSupplier<String, Exception>() {
                    @Override
                    public String get() throws Exception {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, thrown);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTCanPropagateCheckedException() {
        final StopWatch watch = StopWatch.create();
        final Exception expected = new Exception("checked-failure");
        final Throwable thrown = assertThrows(Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, thrown);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetAndRunResumeAfterSuspendWithoutResettingElapsedTime() {
        final StopWatch watch = StopWatch.create();
        watch.run(new Runnable() {
            @Override
            public void run() {
                // first measured section
            }
        });
        final long afterFirst = watch.getNanoTime();
        watch.run(new Runnable() {
            @Override
            public void run() {
                // second measured section, resumes from suspended state
            }
        });
        assertTrue(watch.getNanoTime() >= afterFirst);
    }

    @Test
    void testSplitClassAccessors() {
        final Duration duration = Duration.ofSeconds(5);
        final StopWatch.Split split = new StopWatch.Split("label", duration);
        assertEquals("label", split.getLabel());
        assertEquals(duration, split.getDuration());
        assertEquals("label", split.getKey());
        assertEquals(duration, split.getValue());
        assertTrue(split.toString().contains("label"));
        assertTrue(split.toString().contains(duration.toString()));
    }
}
