/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils} covering methods not exercised
 * by the existing StringUtils*Test classes.
 */
class StringUtilsAgentTest {

    @Test
    void testCapitalizeAndUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
        assertEquals("a", StringUtils.reverse("a"));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testRepeatCharAndString() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("", StringUtils.repeat('e', -1));
        assertEquals("eee", StringUtils.repeat('e', 3));

        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("", 5));
    }

    @Test
    void testRepeatWithSeparator() {
        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("", StringUtils.repeat("ab", "-", 0));
        assertEquals("ab", StringUtils.repeat("ab", "-", 1));
        assertEquals("ab-ab-ab", StringUtils.repeat("ab", "-", 3));
    }

    @Test
    void testLeftPadRightPadCenter() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxy", StringUtils.rightPad("ab", 4, "xy"));

        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", 2));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("", "a"));
        assertEquals(0, StringUtils.countMatches("abba", null));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
        assertEquals(3, StringUtils.countMatches("eee", "e"));

        assertEquals(0, StringUtils.countMatches((CharSequence) null, 'a'));
        assertEquals(2, StringUtils.countMatches("hello", 'l'));
    }

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));

        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));
    }

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeetee", StringUtils.remove("queetee", 'u'));
        assertEquals("abc", StringUtils.remove("abc", 'z'));

        assertNull(StringUtils.remove(null, "an"));
        assertEquals("", StringUtils.remove("", "an"));
        assertEquals("queued", StringUtils.remove("queued", null));
        assertEquals("queued", StringUtils.remove("queued", ""));
        assertEquals("usets", StringUtils.remove("useotoso", "o"));
        assertEquals("abc", StringUtils.remove("abc", "x"));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("any", StringUtils.replace("any", "a", null));
        assertEquals("any", StringUtils.replace("any", "", "b"));
        assertEquals("", StringUtils.replace("", "a", "b"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z", -1));
        assertEquals("zba", StringUtils.replace("aba", "a", "z", 1));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z", 2));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z", 3));
        assertEquals("aba", StringUtils.replace("aba", "a", "z", 0));
    }

    @Test
    void testSplitWhitespaceAndChar() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.split("ab cd  ef"));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.split(" ab  cd ef "));

        assertNull(StringUtils.split(null, '.'));
        assertArrayEquals(new String[0], StringUtils.split("", '.'));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a..b.c", '.'));
    }

    @Test
    void testSplitWithMax() {
        assertNull(StringUtils.split(null, ".", 2));
        assertArrayEquals(new String[] { "a", "b.c" }, StringUtils.split("a.b.c", ".", 2));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", ".", 0));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", ".", -1));
    }

    @Test
    void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] { "a" }, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] { "a", "b", "c" }, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] { "a", null, "c" }, ','));

        assertNull(StringUtils.join((Object[]) null, "-"));
        assertEquals("a-b-c", StringUtils.join(new Object[] { "a", "b", "c" }, "-"));
        assertEquals("abc", StringUtils.join(new Object[] { "a", "b", "c" }, (String) null));
    }

    @Test
    void testJoinWithRange() {
        final Object[] array = { "a", "b", "c", "d" };
        assertEquals("b,c", StringUtils.join(array, ',', 1, 3));
        assertEquals("", StringUtils.join(array, ',', 2, 2));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 5));
        assertEquals("", StringUtils.truncate("", 5));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertEquals("", StringUtils.truncate("abcdefg", 0));

        assertEquals("cdefg", StringUtils.truncate("abcdefg", 2, 10));
        assertEquals("cd", StringUtils.truncate("abcdefg", 2, 2));
    }

    @Test
    void testTruncateInvalidArgs() {
        try {
            StringUtils.truncate("abc", -1);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            StringUtils.truncate("abc", -1, 5);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            StringUtils.truncate("abc", 0, -1);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testWrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("", StringUtils.wrap("", '"'));
        assertEquals("\"ab\"", StringUtils.wrap("ab", '"'));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", '"'));

        assertNull(StringUtils.wrap(null, "xyz"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xyzabxyz", StringUtils.wrap("ab", "xyz"));
    }

    @Test
    void testAppendAndPrependIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abc", StringUtils.appendIfMissing("abc", ""));

        assertNull(StringUtils.prependIfMissing(null, "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
    }

    @Test
    void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("", StringUtils.deleteWhitespace("   \t\n "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b  c "));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
        assertEquals("", StringUtils.chomp("\n"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("ty", StringUtils.difference("abcde", "abcty"));
        assertEquals("", StringUtils.difference("abcde", "abc"));
        assertEquals("y", StringUtils.difference("abc", "abcy"));
    }

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix("", "abc"));
        assertEquals("", StringUtils.getCommonPrefix("abc", null));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd", "abz"));
        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abc"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(3, StringUtils.getLevenshteinDistance("abc", ""));
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting"));
    }

    @Test
    void testGetLevenshteinDistanceNullArgs() {
        try {
            StringUtils.getLevenshteinDistance(null, "abc");
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            StringUtils.getLevenshteinDistance("abc", null);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
        assertEquals("a b c", StringUtils.normalizeSpace("a\tb\nc"));
    }

    @Test
    void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        // start greater than end swaps the bounds
        assertEquals(StringUtils.overlay("abcdef", "zzzz", 4, 2), StringUtils.overlay("abcdef", "zzzz", 2, 4));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    @Test
    void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    void testContainsAnyContainsOnlyContainsNone() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertTrue(StringUtils.containsAny("abc", 'a', 'z'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'z'));

        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertFalse(StringUtils.containsOnly("ab", (char[]) null));
        assertTrue(StringUtils.containsOnly("", 'a', 'b'));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcab", 'a', 'b'));

        assertTrue(StringUtils.containsNone(null, 'a'));
        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a', 'y'));
    }

    @Test
    void testIndexOfAnyOrdinalIndexOf() {
        assertEquals(-1, StringUtils.indexOfAny(null, 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", (char[]) null));
        assertEquals(0, StringUtils.indexOfAny("abc", 'a', 'z'));
        assertEquals(-1, StringUtils.indexOfAny("abc", 'x', 'z'));

        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));
    }

    @Test
    void testAbbreviateMiddleAndLength() {
        assertNull(StringUtils.abbreviateMiddle(null, "...", 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
        assertEquals("abcdef", StringUtils.abbreviateMiddle("abcdef", ".", 10));
    }

    @Test
    void testLengthAndIsEmptyIdentity() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));

        final String same = "same-ref";
        assertSame(same, StringUtils.defaultString(same));
    }
}
