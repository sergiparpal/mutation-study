/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link SerializationUtils}.
 */
class SerializationUtilsAgentTest {

    /** Simple serializable fixture with an equals/hashCode so clone/roundtrip can be checked by value. */
    static class Fixture implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int value;
        private final String name;

        Fixture(final int value, final String name) {
            this.value = value;
            this.name = name;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof Fixture)) {
                return false;
            }
            final Fixture other = (Fixture) obj;
            return value == other.value && (name == null ? other.name == null : name.equals(other.name));
        }

        @Override
        public int hashCode() {
            return value;
        }
    }

    /** Implements Serializable but holds a non-serializable field, so writing it fails. */
    static class NotReallySerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final Object notSerializable = new Object();
    }

    /** An OutputStream whose write methods always fail, to force an IOException during serialize(). */
    static class FailingOutputStream extends OutputStream {
        @Override
        public void write(final int b) throws IOException {
            throw new IOException("boom");
        }
    }

    // --- clone ---

    @Test
    void testCloneNullReturnsNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    void testCloneReturnsEqualButDistinctInstance() {
        final Fixture original = new Fixture(42, "hello");
        final Fixture cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    void testCloneOfString() {
        final String original = "abc";
        final String cloned = SerializationUtils.clone(original);
        assertEquals("abc", cloned);
    }

    @Test
    void testCloneThrowsSerializationExceptionForUnwritableGraph() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.clone(new NotReallySerializable());
            }
        });
    }

    // --- serialize(Serializable) ---

    @Test
    void testSerializeNullObject() {
        final byte[] bytes = SerializationUtils.serialize(null);
        assertNotNull(bytes);
        assertTrue(bytes.length > 0);
        assertNull(SerializationUtils.deserialize(bytes));
    }

    @Test
    void testSerializeThenDeserializeRoundTrip() {
        final Fixture original = new Fixture(7, "x");
        final byte[] bytes = SerializationUtils.serialize(original);
        final Fixture result = SerializationUtils.deserialize(bytes);
        assertEquals(original, result);
    }

    @Test
    void testSerializeWrapsIOExceptionAsSerializationException() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize("abc", new FailingOutputStream());
            }
        });
    }

    @Test
    void testSerializeNullOutputStreamThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize("abc", null);
            }
        });
    }

    // --- deserialize(byte[]) ---

    @Test
    void testDeserializeNullByteArrayThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((byte[]) null);
            }
        });
    }

    @Test
    void testDeserializeEmptyByteArrayThrowsSerializationException() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(new byte[0]);
            }
        });
    }

    @Test
    void testDeserializeCorruptDataThrowsSerializationException() {
        final byte[] bytes = SerializationUtils.serialize("abc");
        // Flip a byte so the stream header is invalid.
        bytes[0] = (byte) 0x00;
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(bytes);
            }
        });
    }

    // --- deserialize(InputStream) ---

    @Test
    void testDeserializeNullInputStreamThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((java.io.InputStream) null);
            }
        });
    }

    @Test
    void testDeserializeFromInputStream() {
        final List<String> original = new ArrayList<String>();
        original.add("a");
        original.add("b");
        final byte[] bytes = SerializationUtils.serialize((Serializable) original);
        final List<?> result = SerializationUtils.deserialize(new java.io.ByteArrayInputStream(bytes));
        assertEquals(original, result);
    }

    // --- roundtrip ---

    @Test
    void testRoundtripReturnsEqualDistinctInstance() {
        final Fixture original = new Fixture(99, "roundtrip");
        final Fixture result = SerializationUtils.roundtrip(original);
        assertEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    void testRoundtripOfNull() {
        assertNull(SerializationUtils.roundtrip(null));
    }

    // --- requireNonNull ---

    @Test
    void testRequireNonNullReturnsSameInstanceWhenNotNull() throws InvalidObjectException {
        final String value = "present";
        final String result = SerializationUtils.requireNonNull(value, "must not be null");
        assertSame(value, result);
    }

    @Test
    void testRequireNonNullThrowsInvalidObjectExceptionWithMessageWhenNull() {
        final InvalidObjectException ex = assertThrows(InvalidObjectException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws InvalidObjectException {
                SerializationUtils.requireNonNull(null, "field is required");
            }
        });
        assertEquals("field is required", ex.getMessage());
    }

    // --- byte array round trip sanity (serialize produces deserializable bytes) ---

    @Test
    void testSerializeByteArrayIsConsistentAcrossCalls() {
        final Fixture original = new Fixture(1, "same");
        final byte[] first = SerializationUtils.serialize(original);
        final byte[] second = SerializationUtils.serialize(original);
        assertArrayEquals(first, second);
    }
}
