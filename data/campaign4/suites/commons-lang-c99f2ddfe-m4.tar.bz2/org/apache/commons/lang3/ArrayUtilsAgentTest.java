/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testIsEmptyIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));

        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(2, ArrayUtils.getLength(new int[][] {{1}, {2}}));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.getLength("not an array"));
    }

    @Test
    void testCloneNull() {
        assertNull(ArrayUtils.clone((Object[]) null));
        assertNull(ArrayUtils.clone((int[]) null));
    }

    @Test
    void testCloneObjectArray() {
        final String[] original = {"a", "b"};
        final String[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
    }

    @Test
    void testCloneIntArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
        cloned[0] = 99;
        assertEquals(1, original[0]);
    }

    @Test
    void testIndexOfIntArray() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 42));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 100));
    }

    @Test
    void testLastIndexOfIntArray() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 42));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 2, -1));
    }

    @Test
    void testContains() {
        final int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 42));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final Object[] objArray = {"a", null, "c"};
        assertTrue(ArrayUtils.contains(objArray, (Object) null));
        assertTrue(ArrayUtils.contains(objArray, "c"));
        assertFalse(ArrayUtils.contains(objArray, "z"));
    }

    @Test
    void testContainsAny() {
        final Object[] array = {"a", "b", "c"};
        assertTrue(ArrayUtils.containsAny(array, "x", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
    }

    @Test
    void testIndexesOf() {
        final int[] array = {1, 2, 1, 3, 1};
        final BitSet indexes = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, indexes.cardinality());
        assertTrue(indexes.get(0));
        assertTrue(indexes.get(2));
        assertTrue(indexes.get(4));
        assertFalse(indexes.get(1));

        final BitSet none = ArrayUtils.indexesOf(array, 42);
        assertTrue(none.isEmpty());
    }

    @Test
    void testSubarray() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 2));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        // negative start index is clamped to 0
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.subarray(array, -2, 2));
        // end index beyond length is clamped to length
        assertArrayEquals(new int[] {4, 5}, ArrayUtils.subarray(array, 3, 100));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    void testReverse() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {5, 4, 3, 2, 1}, array);

        final int[] partial = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(partial, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, partial);

        // null array is a no-op, must not throw
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testSwap() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.swap(array, 0, 4);
        assertArrayEquals(new int[] {5, 2, 3, 4, 1}, array);

        final int[] same = {1, 2, 3};
        ArrayUtils.swap(same, 1, 1);
        assertArrayEquals(new int[] {1, 2, 3}, same);

        // negative offsets are promoted to 0 rather than throwing
        final int[] negativeOffset = {1, 2, 3};
        ArrayUtils.swap(negativeOffset, -1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, negativeOffset);

        // overflow offsets are a no-op rather than throwing
        final int[] outOfRange = {1, 2, 3};
        ArrayUtils.swap(outOfRange, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, outOfRange);

        // null array is a no-op
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] {5, 1, 2, 3, 4}, array);

        final int[] array2 = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array2, -1);
        assertArrayEquals(new int[] {2, 3, 4, 5, 1}, array2);

        // null array is a no-op
        ArrayUtils.shift((int[]) null, 1);

        // offset of 0 on an empty array is a no-op
        final int[] empty = {};
        ArrayUtils.shift(empty, 0);
        assertEquals(0, empty.length);
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 1, 2}));
    }

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, (int[]) null));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(null, new int[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(new int[0], null));
    }

    @Test
    void testAddObjectElement() {
        final String[] base = {"a", "b"};
        final String[] added = ArrayUtils.add(base, "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, added);
        assertEquals(2, base.length);

        final String[] fromNull = ArrayUtils.add((String[]) null, "x");
        assertArrayEquals(new String[] {"x"}, fromNull);

        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.add((Object[]) null, null));
    }

    @Test
    void testAddPrimitiveInt() {
        final int[] base = {1, 2};
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.add(base, 3));
        assertArrayEquals(new int[] {1}, ArrayUtils.add((int[]) null, 1));
    }

    @Test
    void testAddWithIndex() {
        final int[] base = {1, 2, 3};
        assertArrayEquals(new int[] {1, 99, 2, 3}, ArrayUtils.add(base, 1, 99));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(base, -1, 99));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(base, 4, 99));
    }

    @Test
    void testAddAllObjectArrays() {
        final String[] a1 = {"a", "b"};
        final String[] a2 = {"c"};
        assertArrayEquals(new String[] {"a", "b", "c"}, ArrayUtils.addAll(a1, a2));
        assertArrayEquals(a1, ArrayUtils.addAll(a1, (String[]) null));
        assertArrayEquals(a2, ArrayUtils.addAll((String[]) null, a2));
    }

    @Test
    void testAddFirst() {
        final String[] base = {"b", "c"};
        assertArrayEquals(new String[] {"a", "b", "c"}, ArrayUtils.addFirst(base, "a"));
        assertArrayEquals(new String[] {"x"}, ArrayUtils.addFirst((String[]) null, "x"));
    }

    @Test
    void testRemoveIndex() {
        final String[] base = {"a", "b", "c"};
        assertArrayEquals(new String[] {"a", "c"}, ArrayUtils.remove(base, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(base, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(base, 3));
    }

    @Test
    void testRemoveElement() {
        final String[] base = {"a", "b", "c", "b"};
        assertArrayEquals(new String[] {"a", "c", "b"}, ArrayUtils.removeElement(base, "b"));
        // element not present returns a copy unchanged
        assertArrayEquals(base, ArrayUtils.removeElement(base, "z"));
    }

    @Test
    void testRemoveAllOccurrences() {
        final String[] base = {"a", "b", "a", "c", "a"};
        assertArrayEquals(new String[] {"b", "c"}, ArrayUtils.removeAllOccurrences(base, "a"));
    }

    @Test
    void testRemoveElements() {
        final String[] base = {"a", "b", "a", "c"};
        assertArrayEquals(new String[] {"b", "c"}, ArrayUtils.removeElements(base, "a", "a"));
    }

    @Test
    void testInsert() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 99, 2, 3}, ArrayUtils.insert(1, array, 99));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(-1, array, 99));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(4, array, 99));
    }

    @Test
    void testToStringAndToStringArray() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
        assertNotNull(ArrayUtils.toString(new Object[] {"a", "b"}));
        assertTrue(ArrayUtils.toString(new Object[] {"a", "b"}).contains("a"));
    }

    @Test
    void testToObjectIntArray() {
        final int[] primitives = {1, 2, 3};
        final Integer[] objects = ArrayUtils.toObject(primitives);
        assertArrayEquals(new Integer[] {1, 2, 3}, objects);
        assertNull(ArrayUtils.toObject((int[]) null));
        assertEquals(0, ArrayUtils.toObject(new int[0]).length);
    }

    @Test
    void testToPrimitiveIntArray() {
        final Integer[] objects = {1, 2, 3};
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.toPrimitive(objects));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));

        final Integer[] withNull = {1, null, 3};
        assertThrows(NullPointerException.class, () -> ArrayUtils.toPrimitive(withNull));
        assertArrayEquals(new int[] {1, -1, 3}, ArrayUtils.toPrimitive(withNull, -1));
    }

    @Test
    void testNullToEmpty() {
        assertSame(ArrayUtils.EMPTY_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Object[]) null));
        final Object[] nonEmpty = {"a"};
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));

        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[0]));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, new byte[] {1, 2}));
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array1 = {1, 2, 3};
        final int[] array2 = {1, 2, 3};
        final int[] array3 = {3, 2, 1};
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertTrue(ArrayUtils.hashCode(array1) != ArrayUtils.hashCode(array3));
    }

    @Test
    void testIsArrayIndexValid() {
        final String[] array = {"a", "b"};
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
    }

    @Test
    void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[0]));
        assertEquals(2, ArrayUtils.getDimensions(new int[0][0]));
    }

    @Test
    void testConcat() {
        final int[] result = ArrayUtils.concat(new int[] {1}, new int[] {2, 3}, new int[0]);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }
}
