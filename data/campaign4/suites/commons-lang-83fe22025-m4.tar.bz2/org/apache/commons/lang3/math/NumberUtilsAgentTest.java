/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
public class NumberUtilsAgentTest {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------

    @Test
    public void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    // ----------------------------------------------------------------
    // compare(...)
    // ----------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ----------------------------------------------------------------
    // createBigDecimal
    // ----------------------------------------------------------------

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
    }

    @Test
    public void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    public void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("abc");
            }
        });
    }

    // ----------------------------------------------------------------
    // createBigInteger
    // ----------------------------------------------------------------

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("-FF", 16), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ----------------------------------------------------------------
    // createDouble / createFloat / createInteger / createLong
    // ----------------------------------------------------------------

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createFloat("abc");
            }
        });
    }

    @Test
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ----------------------------------------------------------------
    // createNumber
    // ----------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("");
            }
        });
    }

    @Test
    public void testCreateNumberLeadingSpaceThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber(" 1");
            }
        });
    }

    @Test
    public void testCreateNumberInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongWhenTooBigForInt() {
        final Number n = NumberUtils.createNumber("12345678901");
        assertTrue(n instanceof Long);
        assertEquals(12345678901L, n.longValue());
    }

    @Test
    public void testCreateNumberBigIntegerWhenTooBigForLong() {
        final String huge = "123456789012345678901234567890";
        final Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    public void testCreateNumberDecimalDouble() {
        final Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float || n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberBadTypeQualifierThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("1x");
            }
        });
    }

    @Test
    public void testCreateNumberDoubleExponentThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("1e2e3");
            }
        });
    }

    // ----------------------------------------------------------------
    // isCreatable / isNumber (deprecated)
    // ----------------------------------------------------------------

    @Test
    public void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertFalse(NumberUtils.isCreatable("--1"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber(null));
    }

    // ----------------------------------------------------------------
    // isDigits
    // ----------------------------------------------------------------

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // ----------------------------------------------------------------
    // isParsable
    // ----------------------------------------------------------------

    @Test
    public void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
        assertFalse(NumberUtils.isParsable("0xFF"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ----------------------------------------------------------------
    // max/min - varargs
    // ----------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 7, NumberUtils.max(new byte[] {7}));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0d);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((double[]) null);
            }
        });
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0f);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((float[]) null);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((int[]) null);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((long[]) null);
            }
        });
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((short[]) null);
            }
        });
    }

    // ----------------------------------------------------------------
    // max/min - three params
    // ----------------------------------------------------------------

    @Test
    public void testMaxMinThreeParamByte() {
        assertEquals((byte) 9, NumberUtils.max((byte) 9, (byte) 2, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 9, (byte) 2, (byte) 5));
    }

    @Test
    public void testMaxMinThreeParamDouble() {
        assertEquals(9.0d, NumberUtils.max(9.0d, 2.0d, 5.0d), 0.0d);
        assertEquals(2.0d, NumberUtils.min(9.0d, 2.0d, 5.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(Double.NaN, 2.0d, 5.0d)));
    }

    @Test
    public void testMaxMinThreeParamFloat() {
        assertEquals(9.0f, NumberUtils.max(9.0f, 2.0f, 5.0f), 0.0f);
        assertEquals(2.0f, NumberUtils.min(9.0f, 2.0f, 5.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(Float.NaN, 2.0f, 5.0f)));
    }

    @Test
    public void testMaxMinThreeParamInt() {
        assertEquals(9, NumberUtils.max(9, 2, 5));
        assertEquals(2, NumberUtils.min(9, 2, 5));
    }

    @Test
    public void testMaxMinThreeParamLong() {
        assertEquals(9L, NumberUtils.max(9L, 2L, 5L));
        assertEquals(2L, NumberUtils.min(9L, 2L, 5L));
    }

    @Test
    public void testMaxMinThreeParamShort() {
        assertEquals((short) 9, NumberUtils.max((short) 9, (short) 2, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 2, (short) 5));
    }

    // ----------------------------------------------------------------
    // toByte / toDouble / toFloat / toInt / toLong / toShort
    // ----------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("abc", (byte) 9));
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(9.9d, NumberUtils.toDouble("abc", 9.9d), 0.0d);
    }

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(9.9f, NumberUtils.toFloat("abc", 9.9f), 0.0f);
    }

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("abc", 9));
    }

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("abc", 9L));
    }

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("abc", (short) 9));
    }

    // ----------------------------------------------------------------
    // toScaledBigDecimal
    // ----------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.23"), 1, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 1, RoundingMode.DOWN));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.25"), 1, null));
    }

    @Test
    public void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.23d), 1, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 1, RoundingMode.DOWN));
    }

    @Test
    public void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.20"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.2f)));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.23f), 1, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 1, RoundingMode.DOWN));
    }

    @Test
    public void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal("1.23", 1, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 1, RoundingMode.DOWN));
    }

    // ----------------------------------------------------------------
    // deprecated public constructor
    // ----------------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructor() {
        assertNotNull(new NumberUtils());
    }
}
