package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link WordUtils}, based solely on the documented contract in the
 * generated javadoc under api/.
 */
public class WordUtilsAgentTest {

    private static final String SEP = System.lineSeparator();

    // ---- capitalize(String) ----

    @Test
    public void testCapitalize_null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    // ---- capitalize(String, char...) ----

    @Test
    public void testCapitalizeDelims_nullStr() {
        assertNull(WordUtils.capitalize(null, '.', ' '));
    }

    @Test
    public void testCapitalizeDelims_emptyStr() {
        assertEquals("", WordUtils.capitalize("", '.'));
    }

    @Test
    public void testCapitalizeDelims_emptyArrayUnchanged() {
        assertEquals("hello world", WordUtils.capitalize("hello world", new char[0]));
    }

    @Test
    public void testCapitalizeDelims_nullDelimitersMeansWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalizeDelims_customDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    // ---- capitalizeFully(String) ----

    @Test
    public void testCapitalizeFully_null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // ---- capitalizeFully(String, char...) ----

    @Test
    public void testCapitalizeFullyDelims_nullStr() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
    }

    @Test
    public void testCapitalizeFullyDelims_emptyStr() {
        assertEquals("", WordUtils.capitalizeFully("", '.'));
    }

    @Test
    public void testCapitalizeFullyDelims_emptyArrayUnchanged() {
        assertEquals("Hello World", WordUtils.capitalizeFully("Hello World", new char[0]));
    }

    @Test
    public void testCapitalizeFullyDelims_customDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    // ---- containsAllWords(CharSequence, CharSequence...) ----

    @Test
    public void testContainsAllWords_nullWord() {
        assertFalse(WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_emptyWord() {
        assertFalse(WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_nullWords() {
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_emptyWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", new CharSequence[0]));
    }

    @Test
    public void testContainsAllWords_substringsDoNotCount() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_allWordsPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    // ---- initials(String) ----

    @Test
    public void testInitials_null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_dotNotADelimiter() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    // ---- initials(String, char...) ----

    @Test
    public void testInitialsDelims_nullStr() {
        assertNull(WordUtils.initials(null, ' '));
    }

    @Test
    public void testInitialsDelims_emptyStr() {
        assertEquals("", WordUtils.initials("", ' '));
    }

    @Test
    public void testInitialsDelims_nullDelimitersMeansWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
        assertEquals("BJ", WordUtils.initials("Ben J.Lee", (char[]) null));
    }

    @Test
    public void testInitialsDelims_customDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testInitialsDelims_emptyArrayYieldsEmptyString() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    // ---- swapCase(String) ----

    @Test
    public void testSwapCase_null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    // ---- uncapitalize(String) ----

    @Test
    public void testUncapitalize_null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // ---- uncapitalize(String, char...) ----

    @Test
    public void testUncapitalizeDelims_nullStr() {
        assertNull(WordUtils.uncapitalize(null, '.'));
    }

    @Test
    public void testUncapitalizeDelims_emptyStr() {
        assertEquals("", WordUtils.uncapitalize("", '.'));
    }

    @Test
    public void testUncapitalizeDelims_emptyArrayUnchanged() {
        assertEquals("I AM.FINE", WordUtils.uncapitalize("I AM.FINE", new char[0]));
    }

    @Test
    public void testUncapitalizeDelims_customDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    // ---- wrap(String, int) ----

    @Test
    public void testWrap_null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap_empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap_basicExample() {
        String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        String expected = "Here is one line of" + SEP + "text that is going" + SEP
                + "to be wrapped after" + SEP + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_longWordNotWrappedByDefault() {
        String input = "Click here to jump to the commons website - https://commons.apache.org";
        String expected = "Click here to jump" + SEP + "to the commons" + SEP
                + "website -" + SEP + "https://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_wrapLengthLessThanOneTreatedAsOne() {
        String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        assertEquals(WordUtils.wrap(input, 1), WordUtils.wrap(input, 0));
        assertEquals(WordUtils.wrap(input, 1), WordUtils.wrap(input, -5));
    }

    // ---- wrap(String, int, String, boolean) ----

    @Test
    public void testWrap4_null() {
        assertNull(WordUtils.wrap(null, 20, "\n", true));
    }

    @Test
    public void testWrap4_empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", false));
    }

    @Test
    public void testWrap4_customNewLineString() {
        String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", true));
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    public void testWrap4_nullNewLineStringUsesSystemSeparator() {
        String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        String expected = "Here is one line of" + SEP + "text that is going" + SEP
                + "to be wrapped after" + SEP + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, null, true));
    }

    @Test
    public void testWrap4_longWordNotWrapped() {
        String input = "Click here to jump to the commons website - https://commons.apache.org";
        String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    public void testWrap4_longWordWrapped() {
        String input = "Click here to jump to the commons website - https://commons.apache.org";
        String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    // ---- wrap(String, int, String, boolean, String) ----

    @Test
    public void testWrap5_null() {
        assertNull(WordUtils.wrap(null, 20, "\n", true, " "));
    }

    @Test
    public void testWrap5_empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", false, " "));
    }

    @Test
    public void testWrap5_spaceWrapOnMatchesFourArgVersion() {
        String input = "Click here to jump to the commons website - https://commons.apache.org";
        String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, " "));
    }

    @Test
    public void testWrap5_blankWrapOnTreatedAsSpace() {
        String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        String expectedWithSpace = WordUtils.wrap(input, 20, "\n", true, " ");
        assertEquals(expectedWithSpace, WordUtils.wrap(input, 20, "\n", true, ""));
    }

    @Test
    public void testWrap5_customWrapOnCharacter() {
        String input = "flammable/inflammable";
        String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }
}
