/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * Simple {@link FormatFactory} that builds upper-casing formats keyed by name/style.
     */
    private static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new UpperFormat(arguments);
        }
    }

    /**
     * Minimal {@link Format} implementation that upper-cases the string representation
     * of the object being formatted, and optionally prefixes the result with its
     * construction arguments (to verify the arguments were passed through correctly).
     */
    private static final class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String arguments;

        UpperFormat(final String arguments) {
            this.arguments = arguments;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            if (arguments != null) {
                toAppendTo.append('[').append(arguments).append(']');
            }
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UpperFormat)) {
                return false;
            }
            final UpperFormat other = (UpperFormat) obj;
            return arguments == null ? other.arguments == null : arguments.equals(other.arguments);
        }

        @Override
        public int hashCode() {
            return arguments == null ? 0 : arguments.hashCode();
        }
    }

    private Map<String, FormatFactory> newRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testDefaultLocaleConstructor() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}");
        assertEquals("Hello {0}", emf.toPattern());
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("Hello World", emf.format(new Object[] {"World"}));
    }

    @Test
    void testLocaleConstructor() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Value {0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
        assertEquals("Value 1", emf.format(new Object[] {"1"}));
    }

    @Test
    void testNullRegistryFallsBackToMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US, null);
        assertEquals("{0,number,integer}", emf.toPattern());
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
    }

    @Test
    void testCustomFormatRegistryAppliedAndRoundTrippedInPattern() {
        final Map<String, FormatFactory> registry = newRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", registry);
        assertEquals("Name: {0,upper}", emf.toPattern());
        assertEquals("Name: ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testCustomFormatWithStyleArgumentsPassedThrough() {
        final Map<String, FormatFactory> registry = newRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,xyz}", Locale.US, registry);
        assertEquals("{0,upper,xyz}", emf.toPattern());
        assertEquals("[xyz]ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testUnknownFormatNameFallsThroughToStandardFormat() {
        final Map<String, FormatFactory> registry = newRegistry();
        // "number" is not registered, so standard MessageFormat number handling applies.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US, registry);
        assertEquals("{0,number,integer}", emf.toPattern());
        assertEquals("7", emf.format(new Object[] {Integer.valueOf(7)}));
    }

    @Test
    void testMultipleArgumentsMixedCustomAndStandardFormats() {
        final Map<String, FormatFactory> registry = newRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} has {1,number,integer} items", Locale.US, registry);
        assertEquals("CART has 3 items", emf.format(new Object[] {"cart", Integer.valueOf(3)}));
    }

    @Test
    void testQuotedTextIsPreservedLiterally() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' is literal, {0} is not");
        assertEquals("{0} is literal, World is not", emf.format(new Object[] {"World"}));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        final Map<String, FormatFactory> registry = newRegistry();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("missing end quote: '{0}", registry);
            }
        });
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        final Map<String, FormatFactory> registry = newRegistry();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", registry);
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        final Map<String, FormatFactory> registry = newRegistry();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0a}", registry);
            }
        });
    }

    @Test
    void testEmptyPatternProducesEmptyOutput() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final Map<String, FormatFactory> registry = newRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsReturnsFalseForDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}");
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0} ");
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testEqualsReturnsFalseForNonExtendedMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals("{0}"));
    }

    @Test
    void testEqualsReturnsFalseForNull() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsIsReflexive() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    void testNestedFormatElementInChoiceIsHandled() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#no files|1#one file|1<{0,number,integer} files}");
        assertEquals("no files", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one file", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("3 files", emf.format(new Object[] {Integer.valueOf(3)}));
    }

    @Test
    void testWhitespaceAroundArgumentIndexAndFormatName() {
        final Map<String, FormatFactory> registry = newRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 , upper}", Locale.US, registry);
        assertEquals("XY", emf.format(new Object[] {"xy"}));
    }
}
