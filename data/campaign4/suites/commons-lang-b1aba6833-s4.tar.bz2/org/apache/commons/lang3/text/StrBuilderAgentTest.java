package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    // A simple Appendable that always fails, to verify IOException propagation.
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(CharSequence csq, int start, int end) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(char c) throws IOException {
            throw new IOException("boom");
        }
    }

    // A simple Readable that always fails, to verify IOException propagation.
    private static final class ThrowingReadable implements Readable {
        @Override
        public int read(CharBuffer cb) throws IOException {
            throw new IOException("boom");
        }
    }

    // ---------------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------------

    @Test
    public void testDefaultConstructor() {
        StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructor() {
        StrBuilder sb = new StrBuilder(50);
        assertEquals(50, sb.capacity());
        assertEquals(0, sb.length());
    }

    @Test
    public void testCapacityConstructorZeroOrLessConvertedTo32() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
    }

    @Test
    public void testStringConstructor() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.toString());
        assertEquals(5, sb.length());
        assertEquals(37, sb.capacity());
    }

    @Test
    public void testStringConstructorNullTreatedAsBlank() {
        StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // append - primitives
    // ---------------------------------------------------------------

    @Test
    public void testAppendBoolean() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append(true);
        assertSame(sb, result);
        assertEquals("true", sb.toString());
        sb.append(false);
        assertEquals("truefalse", sb.toString());
    }

    @Test
    public void testAppendChar() {
        StrBuilder sb = new StrBuilder();
        assertSame(sb, sb.append('x'));
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayNullCallsAppendNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());
        sb.setNullText("NULL");
        sb.append((char[]) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        StrBuilder sb = new StrBuilder();
        char[] chars = "abcdef".toCharArray();
        sb.append(chars, 2, 3);
        assertEquals("cde", sb.toString());
    }

    @Test
    public void testAppendDouble() {
        StrBuilder sb = new StrBuilder();
        sb.append(1.5d);
        assertEquals(String.valueOf(1.5d), sb.toString());
    }

    @Test
    public void testAppendFloat() {
        StrBuilder sb = new StrBuilder();
        sb.append(1.5f);
        assertEquals(String.valueOf(1.5f), sb.toString());
    }

    @Test
    public void testAppendInt() {
        StrBuilder sb = new StrBuilder();
        sb.append(42);
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendLong() {
        StrBuilder sb = new StrBuilder();
        sb.append(42L);
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendObject() {
        StrBuilder sb = new StrBuilder();
        sb.append(Integer.valueOf(7));
        assertEquals("7", sb.toString());
    }

    @Test
    public void testAppendObjectNullCallsAppendNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // append - CharSequence / String / StringBuffer / StringBuilder / StrBuilder / CharBuffer
    // ---------------------------------------------------------------

    @Test
    public void testAppendCharSequence() {
        StrBuilder sb = new StrBuilder();
        CharSequence cs = "hello";
        assertSame(sb, sb.append(cs));
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendCharSequenceNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        StrBuilder sb = new StrBuilder();
        CharSequence cs = "Hello world";
        sb.append(cs, 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendString() {
        StrBuilder sb = new StrBuilder();
        sb.append("abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringRange() {
        StrBuilder sb = new StrBuilder();
        sb.append("Hello world", 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendStringFormat() {
        StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "a", 1);
        assertEquals("a-1", sb.toString());
    }

    @Test
    public void testAppendStringBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBufferNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((StringBuffer) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringBufferRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("Hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendStringBuilder() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBuilderNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((StringBuilder) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringBuilderRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("Hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStrBuilderNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((StrBuilder) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("Hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendCharBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharBufferNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((CharBuffer) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("Hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendAll
    // ---------------------------------------------------------------

    @Test
    public void testAppendAllIterable() {
        StrBuilder sb = new StrBuilder();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        sb.appendAll((Iterable<?>) list);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterableNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        StrBuilder sb = new StrBuilder();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        sb.appendAll(list.iterator());
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendAllIteratorNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterator<?>) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllArrayNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendAll((Object[]) null);
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendFixedWidthPadLeft / Right
    // ---------------------------------------------------------------

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 5, '0');
        assertEquals("00001", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftIntLargerThanWidthLosesLeftSide() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(123456, 3, '0');
        assertEquals("456", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftIntZeroOrNegativeWidthNoEffect() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 0, '0');
        assertEquals("", sb.toString());
        sb.appendFixedWidthPadLeft(1, -5, '0');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftObject() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("ab", 5, '*');
        assertEquals("***ab", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("null");
        sb.appendFixedWidthPadLeft(null, 6, ' ');
        assertEquals("  null", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(1, 5, '0');
        assertEquals("10000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightIntLargerThanWidthLosesRightSide() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(123456, 3, '0');
        assertEquals("123", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightObject() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("ab", 5, '*');
        assertEquals("ab***", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("null");
        sb.appendFixedWidthPadRight(null, 6, ' ');
        assertEquals("null  ", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendln / appendNewLine / appendNull / appendPadding
    // ---------------------------------------------------------------

    @Test
    public void testAppendlnString() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln("abc");
        assertEquals("abc\n", sb.toString());
    }

    @Test
    public void testAppendlnInt() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln(5);
        assertEquals("5\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultIsSystemLineSeparator() {
        StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineCustom() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        sb.appendNewLine();
        assertEquals("<br>", sb.toString());
        assertEquals("<br>", sb.getNewLineText());
    }

    @Test
    public void testSetNewLineTextNullResetsToSystemDefault() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        sb.setNewLineText(null);
        assertNull(sb.getNewLineText());
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNullDefaultNoText() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendNullCustomText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.appendNull();
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendPadding() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendPaddingNegativeMeansNoAppend() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(-1, '*');
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendSeparator
    // ---------------------------------------------------------------

    @Test
    public void testAppendSeparatorCharOnEmptyBuilderNoEffect() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharOnNonEmptyBuilder() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator(',');
        assertEquals("a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharCharDefaultIfEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharCharStandardWhenNotEmpty() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator(',', ';');
        assertEquals("a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringOnEmptyBuilderNoEffect() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNullNoEffect() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringOnNonEmptyBuilder() {
        StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator(",");
        assertEquals("a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(",", i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStringDefaultIfEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        assertEquals(" where", sb.toString());
        sb.appendSeparator(" and", " where");
        assertEquals(" where and", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendWithSeparators
    // ---------------------------------------------------------------

    @Test
    public void testAppendWithSeparatorsIterable() {
        StrBuilder sb = new StrBuilder();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        sb.appendWithSeparators((Iterable<?>) list, ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullIterableNoEffect() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparatorMeansNone() {
        StrBuilder sb = new StrBuilder();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        sb.appendWithSeparators((Iterable<?>) list, null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        StrBuilder sb = new StrBuilder();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        sb.appendWithSeparators(list.iterator(), ",");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    // ---------------------------------------------------------------
    // appendTo / readFrom
    // ---------------------------------------------------------------

    @Test
    public void testAppendToAppendable() throws IOException {
        StrBuilder sb = new StrBuilder("hello");
        StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.toString());
    }

    @Test
    public void testAppendToPropagatesIOException() {
        StrBuilder sb = new StrBuilder("hello");
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.appendTo(new ThrowingAppendable());
            }
        });
    }

    @Test
    public void testReadFromReadable() throws IOException {
        StrBuilder sb = new StrBuilder();
        int read = sb.readFrom(new StringReader("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromPropagatesIOException() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.readFrom(new ThrowingReadable());
            }
        });
    }

    // ---------------------------------------------------------------
    // asReader / asTokenizer / asWriter
    // ---------------------------------------------------------------

    @Test
    public void testAsReaderReadsContents() throws IOException {
        StrBuilder sb = new StrBuilder("abc");
        Reader reader = sb.asReader();
        int c1 = reader.read();
        int c2 = reader.read();
        int c3 = reader.read();
        int c4 = reader.read();
        assertEquals('a', c1);
        assertEquals('b', c2);
        assertEquals('c', c3);
        assertEquals(-1, c4);
    }

    @Test
    public void testAsReaderSupportsMarkAndReset() throws IOException {
        StrBuilder sb = new StrBuilder("abcdef");
        Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        reader.read();
        reader.mark(10);
        reader.read();
        reader.read();
        reader.reset();
        int next = reader.read();
        assertEquals('b', next);
    }

    @Test
    public void testAsTokenizerDefaultTokenization() {
        StrBuilder sb = new StrBuilder();
        sb.append("a b ");
        StrTokenizer tokenizer = sb.asTokenizer();
        String[] tokens = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b"}, tokens);
    }

    @Test
    public void testAsWriterWritesIntoBuilder() throws IOException {
        StrBuilder sb = new StrBuilder();
        Writer writer = sb.asWriter();
        writer.write("hello");
        assertEquals("hello", sb.toString());
        writer.close();
        // close is documented as ignored, so the builder is still usable.
        writer.write(" world");
        assertEquals("hello world", sb.toString());
    }

    // ---------------------------------------------------------------
    // build / capacity / ensureCapacity / minimizeCapacity
    // ---------------------------------------------------------------

    @Test
    public void testBuildMatchesToString() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals(sb.toString(), sb.build());
    }

    @Test
    public void testCapacityGrowsWhenNeeded() {
        StrBuilder sb = new StrBuilder(2);
        assertEquals(2, sb.capacity());
        sb.append("a much longer string than the initial capacity");
        assertTrue(sb.capacity() >= sb.length());
    }

    @Test
    public void testEnsureCapacity() {
        StrBuilder sb = new StrBuilder(5);
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testEnsureCapacitySmallerThanCurrentNoReduction() {
        StrBuilder sb = new StrBuilder(100);
        sb.ensureCapacity(5);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testMinimizeCapacity() {
        StrBuilder sb = new StrBuilder(100);
        sb.append("hello");
        sb.minimizeCapacity();
        assertEquals(sb.length(), sb.capacity());
    }

    // ---------------------------------------------------------------
    // charAt / setCharAt / deleteCharAt
    // ---------------------------------------------------------------

    @Test
    public void testCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    @Test
    public void testCharAtInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.charAt(-1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.charAt(3);
            }
        });
    }

    @Test
    public void testSetCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        StrBuilder result = sb.setCharAt(1, 'X');
        assertSame(sb, result);
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testSetCharAtInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.setCharAt(-1, 'X');
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.setCharAt(3, 'X');
            }
        });
    }

    @Test
    public void testDeleteCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testDeleteCharAtInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.deleteCharAt(10);
            }
        });
    }

    // ---------------------------------------------------------------
    // clear / isEmpty / isNotEmpty / length / size
    // ---------------------------------------------------------------

    @Test
    public void testClear() {
        StrBuilder sb = new StrBuilder("abc");
        int capacityBefore = sb.capacity();
        StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
        assertEquals(capacityBefore, sb.capacity());
    }

    @Test
    public void testIsEmptyAndIsNotEmpty() {
        StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append("x");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLengthAndSizeAreEquivalent() {
        StrBuilder sb = new StrBuilder("abcde");
        assertEquals(5, sb.length());
        assertEquals(sb.length(), sb.size());
    }

    // ---------------------------------------------------------------
    // contains / startsWith / endsWith
    // ---------------------------------------------------------------

    @Test
    public void testContainsChar() {
        StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cd"));
        assertFalse(sb.contains("zz"));
    }

    @Test
    public void testStartsWith() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("bcd"));
    }

    @Test
    public void testStartsWithNullIsFalse() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertFalse(sb.startsWith(null));
    }

    @Test
    public void testEndsWith() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("abc"));
    }

    @Test
    public void testEndsWithNullIsFalse() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertFalse(sb.endsWith(null));
    }

    // ---------------------------------------------------------------
    // delete / deleteAll / deleteFirst
    // ---------------------------------------------------------------

    @Test
    public void testDelete() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteEndIndexTooLargeTreatedAsEndOfString() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(2, 1000);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testDeleteInvalidStartIndexThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.delete(-1, 2);
            }
        });
    }

    @Test
    public void testDeleteAllChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll("bc");
        assertEquals("aa", sb.toString());
    }

    @Test
    public void testDeleteAllStringNullNoAction() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll((String) null);
        assertEquals("abcabc", sb.toString());
    }

    @Test
    public void testDeleteFirstChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst("bc");
        assertEquals("aabc", sb.toString());
    }

    @Test
    public void testDeleteFirstStringNullNoAction() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst((String) null);
        assertEquals("abcabc", sb.toString());
    }

    // ---------------------------------------------------------------
    // equals / equalsIgnoreCase / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsObjectSameContent() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb2));
        assertTrue(sb2.equals(sb1));
    }

    @Test
    public void testEqualsObjectDifferentContent() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abd");
        assertFalse(sb1.equals(sb2));
    }

    @Test
    public void testEqualsObjectNullIsFalse() {
        StrBuilder sb1 = new StrBuilder("abc");
        assertFalse(sb1.equals(null));
    }

    @Test
    public void testEqualsObjectDifferentTypeIsFalse() {
        StrBuilder sb1 = new StrBuilder("abc");
        assertFalse(sb1.equals("abc"));
    }

    @Test
    public void testEqualsStrBuilderOverload() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals((StrBuilder) null));
    }

    @Test
    public void testEqualsIgnoreCase() {
        StrBuilder sb1 = new StrBuilder("ABC");
        StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertFalse(sb1.equalsIgnoreCase(new StrBuilder("abd")));
        assertFalse(sb1.equalsIgnoreCase(null));
    }

    @Test
    public void testHashCodeConsistentForEqualBuilders() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    // ---------------------------------------------------------------
    // getChars
    // ---------------------------------------------------------------

    @Test
    public void testGetCharsNullDestinationCreatesArray() {
        StrBuilder sb = new StrBuilder("hello");
        char[] result = sb.getChars((char[]) null);
        assertEquals(5, result.length);
        assertEquals("hello", new String(result));
    }

    @Test
    public void testGetCharsTooSmallDestinationCreatesNewArray() {
        StrBuilder sb = new StrBuilder("hello");
        char[] small = new char[2];
        char[] result = sb.getChars(small);
        assertNotSame(small, result);
        assertEquals("hello", new String(result));
    }

    @Test
    public void testGetCharsBigEnoughDestinationReused() {
        StrBuilder sb = new StrBuilder("hello");
        char[] big = new char[10];
        char[] result = sb.getChars(big);
        assertSame(big, result);
        assertEquals('h', result[0]);
        assertEquals('o', result[4]);
    }

    @Test
    public void testGetCharsRange() {
        StrBuilder sb = new StrBuilder("hello world");
        char[] destination = new char[5];
        sb.getChars(6, 11, destination, 0);
        assertEquals("world", new String(destination));
    }

    @Test
    public void testGetCharsRangeNullDestinationThrowsNPE() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.getChars(0, 3, null, 0);
            }
        });
    }

    @Test
    public void testGetCharsRangeInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        final char[] destination = new char[5];
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.getChars(-1, 3, destination, 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharWithStartIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf('b', 2));
    }

    @Test
    public void testIndexOfCharStartIndexTooSmallRoundsToZero() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(sb.indexOf('a'), sb.indexOf('a', -100));
    }

    @Test
    public void testIndexOfCharStartIndexTooLargeReturnsNotFound() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(-1, sb.indexOf('a', 1000));
    }

    @Test
    public void testIndexOfString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(-1, sb.indexOf("zz"));
    }

    @Test
    public void testIndexOfStringNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringWithStartIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf("bc", 2));
    }

    @Test
    public void testLastIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharStartIndexTooLargeIncludesWholeString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(sb.lastIndexOf('a'), sb.lastIndexOf('a', 1000));
    }

    @Test
    public void testLastIndexOfCharStartIndexNegativeDoesNotThrow() {
        StrBuilder sb = new StrBuilder("abcabc");
        int result = sb.lastIndexOf('a', -100);
        assertTrue(result == -1 || (result >= 0 && result < sb.length()));
    }

    @Test
    public void testLastIndexOfString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(-1, sb.lastIndexOf("zz"));
    }

    @Test
    public void testLastIndexOfStringNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    public void testInsertBoolean() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
    }

    @Test
    public void testInsertChar() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (char[]) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        StrBuilder sb = new StrBuilder("af");
        sb.insert(1, "abcde".toCharArray(), 1, 3);
        assertEquals("abcdf", sb.toString());
    }

    @Test
    public void testInsertDouble() {
        StrBuilder sb = new StrBuilder();
        sb.insert(0, 1.5d);
        assertEquals(String.valueOf(1.5d), sb.toString());
    }

    @Test
    public void testInsertFloat() {
        StrBuilder sb = new StrBuilder();
        sb.insert(0, 1.5f);
        assertEquals(String.valueOf(1.5f), sb.toString());
    }

    @Test
    public void testInsertInt() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 9);
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertLong() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 9L);
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertObject() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, Integer.valueOf(9));
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (Object) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertString() {
        StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, "bc");
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertStringNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (String) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.insert(-1, "x");
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.insert(100, "x");
            }
        });
    }

    // ---------------------------------------------------------------
    // leftString / rightString / midString
    // ---------------------------------------------------------------

    @Test
    public void testLeftString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
    }

    @Test
    public void testLeftStringNegativeReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.leftString(-1));
    }

    @Test
    public void testLeftStringLongerThanAvailableReturnsWhole() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.leftString(100));
    }

    @Test
    public void testRightString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
    }

    @Test
    public void testRightStringNegativeReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.rightString(-1));
    }

    @Test
    public void testRightStringLongerThanAvailableReturnsWhole() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.rightString(100));
    }

    @Test
    public void testMidString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cd", sb.midString(2, 2));
    }

    @Test
    public void testMidStringNegativeIndexTreatedAsZero() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("ab", sb.midString(-5, 2));
    }

    @Test
    public void testMidStringIndexGreaterThanSizeTreatedAsSize() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.midString(100, 2));
    }

    @Test
    public void testMidStringNegativeLengthReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.midString(1, -1));
    }

    @Test
    public void testMidStringInsufficientCharsReturnsAsMuchAsPossible() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("ef", sb.midString(4, 100));
    }

    // ---------------------------------------------------------------
    // replace / replaceAll / replaceFirst
    // ---------------------------------------------------------------

    @Test
    public void testReplaceRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    @Test
    public void testReplaceRangeNullDeletesRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testReplaceRangeEndIndexTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(4, 1000, "X");
        assertEquals("abcdX", sb.toString());
    }

    @Test
    public void testReplaceRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.replace(-1, 3, "X");
            }
        });
    }

    @Test
    public void testReplaceAllChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll('a', 'X');
        assertEquals("XbcXbc", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll("bc", "X");
        assertEquals("aXaX", sb.toString());
    }

    @Test
    public void testReplaceAllStringSearchNullNoAction() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll((String) null, "X");
        assertEquals("abcabc", sb.toString());
    }

    @Test
    public void testReplaceAllStringReplaceNullEquivalentToEmpty() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll("bc", null);
        assertEquals("aa", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceFirst('a', 'X');
        assertEquals("Xbcabc", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceFirst("bc", "X");
        assertEquals("aXabc", sb.toString());
    }

    @Test
    public void testReplaceFirstStringSearchNullNoAction() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceFirst((String) null, "X");
        assertEquals("abcabc", sb.toString());
    }

    // ---------------------------------------------------------------
    // reverse / trim
    // ---------------------------------------------------------------

    @Test
    public void testReverse() {
        StrBuilder sb = new StrBuilder("abc");
        sb.reverse();
        assertEquals("cba", sb.toString());
    }

    @Test
    public void testReverseEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrim() {
        StrBuilder sb = new StrBuilder(" \t hello \n ");
        sb.trim();
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testTrimAllWhitespaceBecomesEmpty() {
        StrBuilder sb = new StrBuilder("   \t\n  ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    // ---------------------------------------------------------------
    // setLength
    // ---------------------------------------------------------------

    @Test
    public void testSetLengthShrinks() {
        StrBuilder sb = new StrBuilder("hello");
        sb.setLength(3);
        assertEquals("hel", sb.toString());
        assertEquals(3, sb.length());
    }

    @Test
    public void testSetLengthGrowsWithUnicodeZeroFiller() {
        StrBuilder sb = new StrBuilder("he");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('h', sb.charAt(0));
        assertEquals('e', sb.charAt(1));
        assertEquals('\u0000', sb.charAt(2));
        assertEquals('\u0000', sb.charAt(3));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.setLength(-1);
            }
        });
    }

    // ---------------------------------------------------------------
    // subSequence / substring / toCharArray
    // ---------------------------------------------------------------

    @Test
    public void testSubSequence() {
        StrBuilder sb = new StrBuilder("abcdef");
        CharSequence sub = sb.subSequence(1, 4);
        assertEquals("bcd", sub.toString());
    }

    @Test
    public void testSubSequenceInvalidRangeThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.subSequence(-1, 3);
            }
        });
    }

    @Test
    public void testSubstringFromStart() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    @Test
    public void testSubstringFromStartInvalidThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.substring(100);
            }
        });
    }

    @Test
    public void testSubstringRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.substring(1, 4));
    }

    @Test
    public void testSubstringRangeEndIndexTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.substring(3, 1000));
    }

    @Test
    public void testSubstringRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.substring(-1, 3);
            }
        });
    }

    @Test
    public void testToCharArray() {
        StrBuilder sb = new StrBuilder("abc");
        char[] result = sb.toCharArray();
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testToCharArrayEmptyBuilder() {
        StrBuilder sb = new StrBuilder();
        char[] result = sb.toCharArray();
        assertEquals(0, result.length);
    }

    @Test
    public void testToCharArrayRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] result = sb.toCharArray(1, 4);
        assertArrayEquals(new char[] {'b', 'c', 'd'}, result);
    }

    @Test
    public void testToCharArrayRangeEndIndexTooLargeIsValid() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] result = sb.toCharArray(3, 1000);
        assertArrayEquals(new char[] {'d', 'e', 'f'}, result);
    }

    @Test
    public void testToCharArrayRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.toCharArray(-1, 3);
            }
        });
    }

    // ---------------------------------------------------------------
    // toString / toStringBuffer / toStringBuilder - independence
    // ---------------------------------------------------------------

    @Test
    public void testToStringIndependentOfBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        String str = sb.toString();
        sb.append("def");
        assertEquals("abc", str);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuffer buffer = sb.toStringBuffer();
        assertEquals("abc", buffer.toString());
        sb.append("def");
        assertEquals("abc", buffer.toString());
    }

    @Test
    public void testToStringBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuilder builder = sb.toStringBuilder();
        assertEquals("abc", builder.toString());
        sb.append("def");
        assertEquals("abc", builder.toString());
    }

    // ---------------------------------------------------------------
    // CharSequence / Appendable interface contract
    // ---------------------------------------------------------------

    @Test
    public void testImplementsCharSequenceAndAppendable() {
        StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb instanceof CharSequence);
        assertTrue(sb instanceof Appendable);
        assertTrue(sb instanceof java.io.Serializable);
    }

    @Test
    public void testAppendableAppendCharReturnsAppendable() throws IOException {
        Appendable appendable = new StrBuilder();
        Appendable result = appendable.append('x');
        assertEquals("x", result.toString());
    }

    // ---------------------------------------------------------------
    // Package-private members accessible from same package
    // ---------------------------------------------------------------

    @Test
    public void testGetBufferReflectsContent() {
        StrBuilder sb = new StrBuilder("abc");
        char[] buffer = sb.getBuffer();
        assertNotNull(buffer);
        assertTrue(buffer.length >= sb.size());
        assertEquals('a', buffer[0]);
        assertEquals('b', buffer[1]);
        assertEquals('c', buffer[2]);
    }

    @Test
    public void testValidateIndexValidDoesNotThrow() {
        StrBuilder sb = new StrBuilder("abc");
        sb.validateIndex(0);
        sb.validateIndex(3);
    }

    @Test
    public void testValidateIndexInvalidThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.validateIndex(-1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.validateIndex(4);
            }
        });
    }

    @Test
    public void testValidateRangeEndIndexTooLargeClamped() {
        StrBuilder sb = new StrBuilder("abcde");
        int result = sb.validateRange(1, 1000);
        assertEquals(5, result);
    }

    @Test
    public void testValidateRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abcde");
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sb.validateRange(-1, 3);
            }
        });
    }
}
