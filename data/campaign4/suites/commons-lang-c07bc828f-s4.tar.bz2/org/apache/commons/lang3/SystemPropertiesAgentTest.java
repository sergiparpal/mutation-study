package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Tests for {@link SystemProperties} based solely on its documented contract.
 */
public class SystemPropertiesAgentTest {

    /** Fixture class used to exercise the "SimpleClassName.Key" lookup methods. */
    static class Probe {
        // Intentionally empty: only its simple name "Probe" is used.
    }

    /** Collects system properties set up by a test so they can be removed again. */
    private final java.util.List<String> propertiesToClear = new java.util.ArrayList<String>();

    @AfterEach
    public void tearDown() {
        for (String key : propertiesToClear) {
            System.clearProperty(key);
        }
        propertiesToClear.clear();
    }

    private void setProp(String key, String value) {
        System.setProperty(key, value);
        propertiesToClear.add(key);
    }

    private void clearProp(String key) {
        System.clearProperty(key);
        propertiesToClear.add(key);
    }

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------

    @Test
    public void testPublicConstructorIsUsable() {
        SystemProperties instance = new SystemProperties();
        assertNotNull(instance);
    }

    // ---------------------------------------------------------------
    // Field constants: value must match the documented System property name.
    // ---------------------------------------------------------------

    @Test
    public void testConstantValues() {
        assertEquals("file.encoding", SystemProperties.FILE_ENCODING);
        assertEquals("file.separator", SystemProperties.FILE_SEPARATOR);
        assertEquals("java.class.path", SystemProperties.JAVA_CLASS_PATH);
        assertEquals("java.class.version", SystemProperties.JAVA_CLASS_VERSION);
        assertEquals("java.home", SystemProperties.JAVA_HOME);
        assertEquals("java.specification.version", SystemProperties.JAVA_SPECIFICATION_VERSION);
        assertEquals("java.vendor", SystemProperties.JAVA_VENDOR);
        assertEquals("java.version", SystemProperties.JAVA_VERSION);
        assertEquals("line.separator", SystemProperties.LINE_SEPARATOR);
        assertEquals("os.arch", SystemProperties.OS_ARCH);
        assertEquals("os.name", SystemProperties.OS_NAME);
        assertEquals("os.version", SystemProperties.OS_VERSION);
        assertEquals("path.separator", SystemProperties.PATH_SEPARATOR);
        assertEquals("user.dir", SystemProperties.USER_DIR);
        assertEquals("user.home", SystemProperties.USER_HOME);
        assertEquals("user.name", SystemProperties.USER_NAME);
    }

    // ---------------------------------------------------------------
    // No-arg getters: documented to mirror System.getProperty(<fixed key>).
    // ---------------------------------------------------------------

    @Test
    public void testNoArgGettersMirrorSystemProperties() {
        assertEquals(System.getProperty(SystemProperties.FILE_ENCODING), SystemProperties.getFileEncoding());
        assertEquals(System.getProperty(SystemProperties.FILE_SEPARATOR), SystemProperties.getFileSeparator());
        assertEquals(System.getProperty(SystemProperties.JAVA_CLASS_PATH), SystemProperties.getJavaClassPath());
        assertEquals(System.getProperty(SystemProperties.JAVA_CLASS_VERSION), SystemProperties.getJavaClassVersion());
        assertEquals(System.getProperty(SystemProperties.JAVA_HOME), SystemProperties.getJavaHome());
        assertEquals(System.getProperty(SystemProperties.JAVA_VENDOR), SystemProperties.getJavaVendor());
        assertEquals(System.getProperty(SystemProperties.JAVA_VERSION), SystemProperties.getJavaVersion());
        assertEquals(System.getProperty(SystemProperties.LINE_SEPARATOR), SystemProperties.getLineSeparator());
        assertEquals(System.getProperty(SystemProperties.OS_ARCH), SystemProperties.getOsArch());
        assertEquals(System.getProperty(SystemProperties.OS_NAME), SystemProperties.getOsName());
        assertEquals(System.getProperty(SystemProperties.OS_VERSION), SystemProperties.getOsVersion());
        assertEquals(System.getProperty(SystemProperties.PATH_SEPARATOR), SystemProperties.getPathSeparator());
        assertEquals(System.getProperty(SystemProperties.USER_DIR), SystemProperties.getUserDir());
        assertEquals(System.getProperty(SystemProperties.USER_HOME), SystemProperties.getUserHome());
        assertEquals(System.getProperty(SystemProperties.USER_NAME), SystemProperties.getUserName());
        assertEquals(System.getProperty(SystemProperties.JAVA_SPECIFICATION_VERSION), SystemProperties.getJavaSpecificationVersion());
    }

    @Test
    public void testDeprecatedNoArgGetterStillMirrorsSystemProperty() {
        // AWT_TOOLKIT / getAwtToolkit() are deprecated without replacement but remain callable.
        assertEquals(System.getProperty(SystemProperties.AWT_TOOLKIT), SystemProperties.getAwtToolkit());
    }

    @Test
    public void testNoArgGetterReflectsLiveChangeToSystemProperty() {
        String key = SystemProperties.FILE_ENCODING;
        String original = System.getProperty(key);
        try {
            setProp(key, "AGENT-TEST-ENCODING");
            assertEquals("AGENT-TEST-ENCODING", SystemProperties.getFileEncoding());
        } finally {
            if (original == null) {
                System.clearProperty(key);
            } else {
                System.setProperty(key, original);
            }
        }
    }

    // ---------------------------------------------------------------
    // getProperty(String)
    // ---------------------------------------------------------------

    @Test
    public void testGetPropertySinglePresent() {
        String key = "SystemPropertiesAgentTest.single.present";
        setProp(key, "value1");
        assertEquals("value1", SystemProperties.getProperty(key));
    }

    @Test
    public void testGetPropertySingleAbsentReturnsNull() {
        String key = "SystemPropertiesAgentTest.single.absent";
        clearProp(key);
        assertNull(SystemProperties.getProperty(key));
    }

    @Test
    public void testGetPropertySingleEmptyKeyReturnsNull() {
        assertNull(SystemProperties.getProperty(""));
    }

    // ---------------------------------------------------------------
    // getProperty(String, String) [package-private]
    // ---------------------------------------------------------------

    @Test
    public void testGetPropertyWithStringDefaultAbsentReturnsDefault() {
        String key = "SystemPropertiesAgentTest.strDefault.absent";
        clearProp(key);
        assertEquals("fallback", SystemProperties.getProperty(key, "fallback"));
    }

    @Test
    public void testGetPropertyWithStringDefaultPresentReturnsActual() {
        String key = "SystemPropertiesAgentTest.strDefault.present";
        setProp(key, "actual");
        assertEquals("actual", SystemProperties.getProperty(key, "fallback"));
    }

    // ---------------------------------------------------------------
    // getProperty(String, Supplier<String>) [package-private]
    // ---------------------------------------------------------------

    @Test
    public void testGetPropertyWithSupplierDefaultAbsentReturnsSupplied() {
        String key = "SystemPropertiesAgentTest.supplierDefault.absent";
        clearProp(key);
        Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                return "supplied";
            }
        };
        assertEquals("supplied", SystemProperties.getProperty(key, supplier));
    }

    @Test
    public void testGetPropertyWithSupplierDefaultPresentReturnsActual() {
        String key = "SystemPropertiesAgentTest.supplierDefault.present";
        setProp(key, "actual");
        Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                throw new AssertionError("Supplier must not be invoked when the property is present");
            }
        };
        assertEquals("actual", SystemProperties.getProperty(key, supplier));
    }

    // ---------------------------------------------------------------
    // getBoolean(String, BooleanSupplier)
    // ---------------------------------------------------------------

    @Test
    public void testGetBooleanByKeyPresentTrue() {
        String key = "SystemPropertiesAgentTest.bool.present.true";
        setProp(key, "true");
        BooleanSupplier supplier = new BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return false;
            }
        };
        assertTrue(SystemProperties.getBoolean(key, supplier));
    }

    @Test
    public void testGetBooleanByKeyPresentFalse() {
        String key = "SystemPropertiesAgentTest.bool.present.false";
        setProp(key, "false");
        BooleanSupplier supplier = new BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return true;
            }
        };
        assertFalse(SystemProperties.getBoolean(key, supplier));
    }

    @Test
    public void testGetBooleanByKeyAbsentReturnsDefault() {
        String key = "SystemPropertiesAgentTest.bool.absent";
        clearProp(key);
        BooleanSupplier supplier = new BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return true;
            }
        };
        assertTrue(SystemProperties.getBoolean(key, supplier));
    }

    @Test
    public void testGetBooleanByClassAndKeyUsesSimpleClassNamePrefix() {
        String key = "Probe.flag";
        setProp(key, "true");
        BooleanSupplier supplier = new BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return false;
            }
        };
        assertTrue(SystemProperties.getBoolean(Probe.class, "flag", supplier));
    }

    @Test
    public void testGetBooleanByClassAndKeyAbsentReturnsDefault() {
        String key = "Probe.missingFlag";
        clearProp(key);
        BooleanSupplier supplier = new BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return true;
            }
        };
        assertTrue(SystemProperties.getBoolean(Probe.class, "missingFlag", supplier));
    }

    // ---------------------------------------------------------------
    // getInt(String, IntSupplier) / getInt(Class, String, IntSupplier)
    // ---------------------------------------------------------------

    @Test
    public void testGetIntByKeyPresent() {
        String key = "SystemPropertiesAgentTest.int.present";
        setProp(key, "42");
        IntSupplier supplier = new IntSupplier() {
            @Override
            public int getAsInt() {
                return -1;
            }
        };
        assertEquals(42, SystemProperties.getInt(key, supplier));
    }

    @Test
    public void testGetIntByKeyAbsentReturnsDefault() {
        String key = "SystemPropertiesAgentTest.int.absent";
        clearProp(key);
        IntSupplier supplier = new IntSupplier() {
            @Override
            public int getAsInt() {
                return 7;
            }
        };
        assertEquals(7, SystemProperties.getInt(key, supplier));
    }

    @Test
    public void testGetIntByClassAndKeyUsesSimpleClassNamePrefix() {
        String key = "Probe.intValue";
        setProp(key, "99");
        IntSupplier supplier = new IntSupplier() {
            @Override
            public int getAsInt() {
                return -1;
            }
        };
        assertEquals(99, SystemProperties.getInt(Probe.class, "intValue", supplier));
    }

    @Test
    public void testGetIntByClassAndKeyAbsentReturnsDefault() {
        String key = "Probe.missingIntValue";
        clearProp(key);
        IntSupplier supplier = new IntSupplier() {
            @Override
            public int getAsInt() {
                return 123;
            }
        };
        assertEquals(123, SystemProperties.getInt(Probe.class, "missingIntValue", supplier));
    }

    // ---------------------------------------------------------------
    // getLong(String, LongSupplier) / getLong(Class, String, LongSupplier)
    // ---------------------------------------------------------------

    @Test
    public void testGetLongByKeyPresent() {
        String key = "SystemPropertiesAgentTest.long.present";
        setProp(key, "4200000000");
        LongSupplier supplier = new LongSupplier() {
            @Override
            public long getAsLong() {
                return -1L;
            }
        };
        assertEquals(4200000000L, SystemProperties.getLong(key, supplier));
    }

    @Test
    public void testGetLongByKeyAbsentReturnsDefault() {
        String key = "SystemPropertiesAgentTest.long.absent";
        clearProp(key);
        LongSupplier supplier = new LongSupplier() {
            @Override
            public long getAsLong() {
                return 777L;
            }
        };
        assertEquals(777L, SystemProperties.getLong(key, supplier));
    }

    @Test
    public void testGetLongByClassAndKeyUsesSimpleClassNamePrefix() {
        String key = "Probe.longValue";
        setProp(key, "123456789");
        LongSupplier supplier = new LongSupplier() {
            @Override
            public long getAsLong() {
                return -1L;
            }
        };
        assertEquals(123456789L, SystemProperties.getLong(Probe.class, "longValue", supplier));
    }

    @Test
    public void testGetLongByClassAndKeyAbsentReturnsDefault() {
        String key = "Probe.missingLongValue";
        clearProp(key);
        LongSupplier supplier = new LongSupplier() {
            @Override
            public long getAsLong() {
                return 555L;
            }
        };
        assertEquals(555L, SystemProperties.getLong(Probe.class, "missingLongValue", supplier));
    }

    // ---------------------------------------------------------------
    // getPath(String, Supplier<Path>)
    // ---------------------------------------------------------------

    @Test
    public void testGetPathPresent() {
        String key = "SystemPropertiesAgentTest.path.present";
        setProp(key, "a/b/c");
        Supplier<Path> supplier = new Supplier<Path>() {
            @Override
            public Path get() {
                throw new AssertionError("Supplier must not be invoked when the property is present");
            }
        };
        assertEquals(Paths.get("a/b/c"), SystemProperties.getPath(key, supplier));
    }

    @Test
    public void testGetPathAbsentReturnsDefault() {
        String key = "SystemPropertiesAgentTest.path.absent";
        clearProp(key);
        final Path fallback = Paths.get("fallback", "dir");
        Supplier<Path> supplier = new Supplier<Path>() {
            @Override
            public Path get() {
                return fallback;
            }
        };
        assertEquals(fallback, SystemProperties.getPath(key, supplier));
    }

    // ---------------------------------------------------------------
    // getUserName(String) / getJavaSpecificationVersion(String) / getLineSeparator(Supplier)
    // ---------------------------------------------------------------

    @Test
    public void testGetUserNameWithDefaultWhenPropertyPresentReturnsActual() {
        String actual = System.getProperty(SystemProperties.USER_NAME);
        assertEquals(actual, SystemProperties.getUserName("some-default"));
    }

    @Test
    public void testGetUserNameWithDefaultWhenPropertyAbsentReturnsDefault() {
        String key = SystemProperties.USER_NAME;
        String original = System.getProperty(key);
        try {
            System.clearProperty(key);
            assertEquals("some-default", SystemProperties.getUserName("some-default"));
        } finally {
            if (original != null) {
                System.setProperty(key, original);
            }
        }
    }

    @Test
    public void testGetJavaSpecificationVersionWithDefaultWhenPresentReturnsActual() {
        String actual = System.getProperty(SystemProperties.JAVA_SPECIFICATION_VERSION);
        assertEquals(actual, SystemProperties.getJavaSpecificationVersion("default-spec"));
    }

    @Test
    public void testGetJavaSpecificationVersionWithDefaultWhenAbsentReturnsDefault() {
        String key = SystemProperties.JAVA_SPECIFICATION_VERSION;
        String original = System.getProperty(key);
        try {
            System.clearProperty(key);
            assertEquals("default-spec", SystemProperties.getJavaSpecificationVersion("default-spec"));
        } finally {
            if (original != null) {
                System.setProperty(key, original);
            }
        }
    }

    @Test
    public void testGetLineSeparatorWithSupplierWhenPresentReturnsActual() {
        String actual = System.getProperty(SystemProperties.LINE_SEPARATOR);
        Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                throw new AssertionError("Supplier must not be invoked when the property is present");
            }
        };
        assertEquals(actual, SystemProperties.getLineSeparator(supplier));
    }

    @Test
    public void testGetLineSeparatorWithSupplierWhenAbsentReturnsSupplied() {
        String key = SystemProperties.LINE_SEPARATOR;
        String original = System.getProperty(key);
        try {
            System.clearProperty(key);
            Supplier<String> supplier = new Supplier<String>() {
                @Override
                public String get() {
                    return "<<EOL>>";
                }
            };
            assertEquals("<<EOL>>", SystemProperties.getLineSeparator(supplier));
        } finally {
            if (original != null) {
                System.setProperty(key, original);
            }
        }
    }
}
