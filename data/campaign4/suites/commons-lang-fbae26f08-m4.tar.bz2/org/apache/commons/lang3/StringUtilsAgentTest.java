/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsNotEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));
    }

    @Test
    void testIsBlankIsNotBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertTrue(StringUtils.isBlank("\t\n\r"));
        assertFalse(StringUtils.isBlank(" a "));
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("a"));
    }

    @Test
    void testIsAnyAllNoneEmpty() {
        assertFalse(StringUtils.isAnyEmpty((CharSequence[]) null));
        assertFalse(StringUtils.isAnyEmpty());
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));

        assertTrue(StringUtils.isAllEmpty((CharSequence[]) null));
        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "a"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        assertTrue(StringUtils.isNoneEmpty());
    }

    @Test
    void testIsAnyAllNoneBlank() {
        assertFalse(StringUtils.isAnyBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));

        assertTrue(StringUtils.isAllBlank(" ", null, ""));
        assertFalse(StringUtils.isAllBlank(" ", "a"));

        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));
    }

    @Test
    void testTrimAndTrimToNullEmpty() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull(""));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));
    }

    @Test
    void testTrimAsciiControl() {
        assertNull(StringUtils.trimAsciiControl(null));
        assertEquals("", StringUtils.trimAsciiControl(""));
        assertEquals("foo", StringUtils.trimAsciiControl("foo"));
        assertEquals("foo", StringUtils.trimAsciiControl("\t\r\nfoo\t\r\n"));
        assertEquals(" foo ", StringUtils.trimAsciiControl(" foo "));
        assertEquals("", StringUtils.trimAsciiControl("\u0001\u0002"));
    }

    @Test
    void testStripVariants() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcyy", "xy"));
        assertNull(StringUtils.strip(null, "xy"));

        assertNull(StringUtils.stripToNull("   "));
        assertNull(StringUtils.stripToNull(null));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));

        assertNull(StringUtils.stripStart(null, "x"));
        assertEquals("abcxx", StringUtils.stripStart("xxabcxx", "x"));
        assertNull(StringUtils.stripEnd(null, "x"));
        assertEquals("xxabc", StringUtils.stripEnd("xxabcxx", "x"));

        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.stripAll(" a ", " b "));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.stripAll(new String[] {"xax", "xbx"}, "x"));
    }

    @Test
    void testEqualsAndCompare() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, ""));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abd"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", null));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz"));
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "XYZ", "ABC"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", "XYZ"));

        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare(null, "a", true) > 0);
        assertEquals(0, StringUtils.compare("a", "a"));

        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
        assertTrue(StringUtils.compareIgnoreCase(null, "a", true) > 0);
    }

    @Test
    void testIndexOfBoundaries() {
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOf(null, "a"));
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOf("abc", (CharSequence) null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("abc", "bc"));
        assertEquals(1, StringUtils.indexOf("abc", 'b'));
        assertEquals(-1, StringUtils.indexOf("abc", 'z'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 2));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(2, StringUtils.lastIndexOf("abcabc", "c"));
        assertEquals(5, StringUtils.lastIndexOf("abcabc", 'c'));
        assertEquals(2, StringUtils.lastIndexOf("abcabc", 'c', 3));

        assertEquals(1, StringUtils.indexOfIgnoreCase("abc", "B"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "B"));
        assertEquals(4, StringUtils.lastIndexOfIgnoreCase("ABCabc", "C"));

        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a', 'b'));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[] {"ab", "cd"}));

        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", 'y', 'x'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));

        assertEquals(3, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));

        assertEquals(0, StringUtils.indexOfDifference("abc", "abd"));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(0, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference("abc"));
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertTrue(StringUtils.contains("abc", "b"));
        assertTrue(StringUtils.contains("abc", 'b'));
        assertFalse(StringUtils.contains("abc", 'z'));

        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "ab", "no"));
        assertTrue(StringUtils.containsAnyIgnoreCase("ZZABYY", "ab"));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "B"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));
        assertTrue(StringUtils.containsNone(null, "xy"));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly((CharSequence) null, 'a'));

        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("a c"));
    }

    @Test
    void testSubstringFamily() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("bc", StringUtils.substring("abc", 1));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("", StringUtils.substring("abc", 10));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 1));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("abc", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));
        assertEquals("ab", StringUtils.substringBefore("abc", 'c'));

        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "x"));
        assertNull(StringUtils.substringAfter(null, "x"));
        assertEquals("c", StringUtils.substringAfter("abc", 'b'));

        assertEquals("a", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("abc", StringUtils.substringBeforeLast("abc", "x"));

        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "x"));
        assertEquals("", StringUtils.substringAfterLast("abc", 'c'));

        assertEquals("bar", StringUtils.substringBetween("<foo>bar</foo>".substring(5, 8), "", ""));
        assertEquals("bar", StringUtils.substringBetween("tagbartag", "tag"));
        assertEquals("bar", StringUtils.substringBetween("yabcz", "ab", "cz"));
        assertNull(StringUtils.substringBetween(null, "a"));

        assertArrayEquals(new String[] {"bar", "baz"}, StringUtils.substringsBetween("[bar][baz]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertNull(StringUtils.substringsBetween("[bar]", "[", null));
    }

    @Test
    void testSplitFamily() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd  ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", ".,"));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.split("a.b.c", ".", 2));

        assertArrayEquals(new String[] {"a", "", "b", "c", ""}, StringUtils.splitPreserveAllTokens("a..b.c.", '.'));
        assertArrayEquals(new String[0], StringUtils.splitPreserveAllTokens(""));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.splitByWholeSeparator("a..b.c", ".."));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.splitByWholeSeparator("a..b.c", "..", 2));
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("a....b.c", ".."));

        assertArrayEquals(new String[] {"ab", "de", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
    }

    @Test
    void testSplitByCharacterTypeCamelCaseExact() {
        assertArrayEquals(new String[] {"ab", "Cde"}, StringUtils.splitByCharacterTypeCamelCase("abCde"));
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
    }

    @Test
    void testJoinFamily() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
        assertEquals("b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ',', 1, 3));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("true,false", StringUtils.join(new boolean[] {true, false}, ','));
        assertEquals("a,b", StringUtils.join(new char[] {'a', 'b'}, ','));
        assertEquals("1,2", StringUtils.join(new long[] {1L, 2L}, ','));

        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c").iterator(), ','));
        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c"), ','));
        assertNull(StringUtils.join((Iterable<?>) null, ','));

        assertEquals("a-b", StringUtils.joinWith("-", "a", "b"));
        assertEquals("a--b", StringUtils.joinWith("-", "a", null, "b"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith("-", (Object[]) null);
            }
        });
    }

    @Test
    void testReplaceFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
        assertEquals("xbxbc", StringUtils.replace("ababc", "a", "x"));
        assertEquals("xbabc", StringUtils.replace("ababc", "a", "x", 1));
        assertEquals("abc", StringUtils.replace("abc", "a", "x", 0));

        assertEquals("xbc", StringUtils.replaceOnce("abc", "a", "x"));
        assertEquals("xBc", StringUtils.replaceOnceIgnoreCase("aBc", "a", "x"));
        assertEquals("xbxbc", StringUtils.replaceIgnoreCase("AbAbc", "a", "x"));
        assertEquals("xbAbc", StringUtils.replaceIgnoreCase("AbAbc", "a", "x", 1));

        assertEquals("bc", StringUtils.remove("abc", "a"));
        assertEquals("bc", StringUtils.remove("abc", 'a'));
        assertNull(StringUtils.remove(null, "a"));
        assertEquals("bc", StringUtils.removeIgnoreCase("Abc", "a"));

        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", ""));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("bc", StringUtils.removeStart("abc", 'a'));
        assertEquals("Xabc", StringUtils.removeStartIgnoreCase("Xabc", "y"));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("abc", StringUtils.removeEnd("abc", "x"));
        assertEquals("ab", StringUtils.removeEndIgnoreCase("abC", "c"));

        assertEquals("foo", StringUtils.removeAll("foooo", "o+$").replace("fo", "fo"));
        assertEquals("f", StringUtils.removeAll("foooo", "o"));
        assertEquals("ooo", StringUtils.removeFirst("foooo", "f"));
        assertEquals("f", StringUtils.removePattern("f\n", "\\s"));

        assertEquals("woxf", StringUtils.replaceChars("hoxf", 'h', 'w'));
        assertEquals("woxf", StringUtils.replaceChars("hoxf", "ho", "wo"));
        assertEquals("ab", StringUtils.replaceChars("ho", "ho", "ab"));

        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abcde", new String[] {"ab"}, new String[] {"d", "ab"});
            }
        });
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "ab"});
            }
        });

        assertEquals("foo", StringUtils.replaceAll("fAo", "A", "o"));
        assertEquals("foo", StringUtils.replaceFirst("fAo", "A", "o"));
        assertEquals("f.o", StringUtils.replacePattern("f\no", "\\s", "."));
    }

    @Test
    void testAbbreviateFamily() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc", StringUtils.abbreviate("abc", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
        assertEquals("...fg", StringUtils.abbreviate("abcdefg", 5, 5));
        assertEquals("a(...)", StringUtils.abbreviate("abcdefg", "(...)", 6));

        assertEquals("ab...yz", StringUtils.abbreviateMiddle("abcdefghiyz", "...", 7));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", "...", 7));
        assertNull(StringUtils.abbreviateMiddle(null, "...", 7));

        assertNull(StringUtils.truncate(null, 3));
        assertEquals("abc", StringUtils.truncate("abcdef", 3));
        assertEquals("", StringUtils.truncate("abcdef", 0));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdef", -1);
            }
        });
        assertEquals("cde", StringUtils.truncate("abcdef", 2, 3));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdef", -1, 3);
            }
        });
    }

    @Test
    void testCaseFamily() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("Foo", StringUtils.capitalize("foo"));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("FOO", StringUtils.capitalize("FOO"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("foo", StringUtils.uncapitalize("Foo"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));

        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ROOT));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));

        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
    }

    @Test
    void testReverseFamily() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("abc", StringUtils.reverseDelimited("abc", '.'));

        assertNull(StringUtils.rotate(null, 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("", StringUtils.rotate("", 3));
    }

    @Test
    void testPadFamily() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxy", StringUtils.rightPad("ab", 4, "xy"));

        assertNull(StringUtils.center(null, 4));
        assertEquals("  ab  ", StringUtils.center("ab", 6));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
        assertEquals("abcd", StringUtils.center("abcd", 2, " "));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 3));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 5));
        assertEquals("bc", StringUtils.mid("abc", -2, 5));
        assertEquals("", StringUtils.mid("", 0, 5));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("aaa", StringUtils.repeat('a', 3));
        assertEquals("", StringUtils.repeat('a', 0));
        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));
        assertEquals("", StringUtils.repeat("a", ",", 0));
        assertNull(StringUtils.repeat(null, ",", 3));
    }

    @Test
    void testCharClassPredicates() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab1"));
        assertFalse(StringUtils.isAlpha("ab c"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertTrue(StringUtils.isAlphanumeric("ab1"));
        assertFalse(StringUtils.isAlphanumeric("ab-1"));

        assertTrue(StringUtils.isAlphanumericSpace("ab 1"));
        assertFalse(StringUtils.isAlphanumericSpace("ab-1"));

        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab1"));

        assertFalse(StringUtils.isNumeric(null));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("12.3"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable("abc123 !"));
        assertFalse(StringUtils.isAsciiPrintable("abc\u0001"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABC123"));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(3, StringUtils.countMatches("aaa", "a"));
        assertEquals(2, StringUtils.countMatches("abcabc", 'a'));
    }

    @Test
    void testDefaultAndFirstNon() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("d", StringUtils.defaultIfEmpty("", "d"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "d"));
        assertNull(StringUtils.defaultIfEmpty(null, null));

        assertEquals("d", StringUtils.defaultIfBlank(" ", "d"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "d"));

        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));
        assertNull(StringUtils.firstNonBlank((CharSequence[]) null));
        assertNull(StringUtils.firstNonBlank(" ", ""));

        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty(null, ""));
    }

    @Test
    void testDistanceAlgorithms() {
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc"));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });

        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd", 5));
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "xyz", 1));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("abc", "abd", -1);
            }
        });

        assertEquals(1.0d, StringUtils.getJaroWinklerDistance("foo", "foo"), 0.0001d);
        assertTrue(StringUtils.getJaroWinklerDistance("frog", "fog") > 0.9d);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "foo");
            }
        });

        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertTrue(StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH) > 0);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "b", Locale.ENGLISH);
            }
        });
    }

    @Test
    void testNormalizeAndDeleteWhitespace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c  "));

        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b c "));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("", StringUtils.wrap("", '"'));
        assertEquals("xabcx", StringUtils.wrap("abc", "x"));

        assertNull(StringUtils.wrapIfMissing(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("abc", "x"));
        assertEquals("xabcx", StringUtils.wrapIfMissing("xabcx", "x"));

        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));
        assertEquals("abc", StringUtils.unwrap("xabcx", "x"));
    }

    @Test
    void testStartsEndsWithFamily() {
        assertFalse(StringUtils.startsWith(null, "a"));
        assertTrue(StringUtils.startsWith("abc", "ab"));
        assertFalse(StringUtils.startsWith("abc", "AB"));
        assertTrue(StringUtils.startsWithIgnoreCase("abc", "AB"));

        assertTrue(StringUtils.startsWithAny("abc", "xy", "ab"));
        assertFalse(StringUtils.startsWithAny("abc", "xy", "yz"));
        assertFalse(StringUtils.startsWithAny(null, "xy"));

        assertFalse(StringUtils.endsWith(null, "a"));
        assertTrue(StringUtils.endsWith("abc", "bc"));
        assertTrue(StringUtils.endsWithIgnoreCase("abc", "BC"));
        assertTrue(StringUtils.endsWithAny("abc", "xy", "bc"));
        assertFalse(StringUtils.endsWithAny("abc", "xy"));

        assertNull(StringUtils.appendIfMissing(null, "x"));
        assertEquals("abcx", StringUtils.appendIfMissing("abc", "x"));
        assertEquals("abcx", StringUtils.appendIfMissing("abcx", "x"));
        assertEquals("abcX", StringUtils.appendIfMissingIgnoreCase("abcX", "x"));

        assertNull(StringUtils.prependIfMissing(null, "x"));
        assertEquals("xabc", StringUtils.prependIfMissing("abc", "x"));
        assertEquals("xabc", StringUtils.prependIfMissing("xabc", "x"));
        assertEquals("Xabc", StringUtils.prependIfMissingIgnoreCase("Xabc", "x"));
    }

    @Test
    void testChompChopDifference() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
        assertEquals("abc", StringUtils.chomp("abc--", "--"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));

        assertEquals("", StringUtils.difference("abc", "abc"));
        assertNull(StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("ty", StringUtils.difference("abc", "abty"));
    }

    @Test
    void testCommonPrefixDigitsLength() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));

        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("1234", StringUtils.getDigits("a1b2c3d4"));

        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testToCodePointsAndOverlay() {
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.toCodePoints(null);
            }
        });

        assertNull(StringUtils.overlay(null, "x", 0, 1));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("abcdef", StringUtils.overlay("abcdef", null, 6, 6));
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -1, 0));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 100, 100));
    }

    @Test
    void testStripAccentsAndMisc() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));

        assertEquals("ab", StringUtils.valueOf(new char[] {'a', 'b'}));
        assertNull(StringUtils.valueOf(null));

        assertSame(StringUtils.EMPTY, "");
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }

    @Test
    void testCapitalizeAndSwapCaseEdgeCases() {
        assertEquals("A", StringUtils.capitalize("a"));
        assertEquals("1bc", StringUtils.uncapitalize("1bc"));
        assertEquals("ABC123", StringUtils.swapCase("abc123"));
    }
}
