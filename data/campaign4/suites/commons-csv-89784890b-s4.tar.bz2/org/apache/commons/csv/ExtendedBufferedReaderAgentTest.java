package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedBufferedReader}, based solely on its documented contract.
 */
public class ExtendedBufferedReaderAgentTest {

    private static final int EOF = -1;

    // -------------------- getLastChar() --------------------

    @Test
    public void testGetLastCharInitiallyUndefinedNotEof() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        // No read has happened yet: must not be confused with the EOF marker.
        assertFalse(reader.getLastChar() == EOF);
    }

    @Test
    public void testGetLastCharAfterSingleCharRead() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        int ch = reader.read();
        assertEquals('a', ch);
        assertEquals('a', reader.getLastChar());
    }

    @Test
    public void testGetLastCharAfterReachingEof() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        int ch = reader.read();
        assertEquals(EOF, ch);
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    public void testGetLastCharNotAffectedByPeek() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("xyz"));
        reader.read();
        int lastCharAfterRead = reader.getLastChar();
        reader.peek(new char[2]);
        // peek() must not be reflected by getLastChar() per the documented contract.
        assertEquals(lastCharAfterRead, reader.getLastChar());
    }

    @Test
    public void testGetLastCharAfterBulkRead() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        char[] buf = new char[6];
        reader.read(buf, 0, 6);
        assertEquals('f', reader.getLastChar());
    }

    // -------------------- getPosition() --------------------

    @Test
    public void testGetPositionStartsAtZero() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0, reader.getPosition());
    }

    @Test
    public void testGetPositionAdvancesByOnePerCharRead() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        reader.read();
        assertEquals(1, reader.getPosition());
        reader.read();
        assertEquals(2, reader.getPosition());
    }

    @Test
    public void testGetPositionAdvancesByBulkReadLength() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        char[] buf = new char[4];
        int n = reader.read(buf, 0, 4);
        assertEquals(4, n);
        assertEquals(4, reader.getPosition());
    }

    @Test
    public void testGetPositionUnaffectedByPeek() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        reader.peek(new char[3]);
        assertEquals(0, reader.getPosition());
    }

    // -------------------- getLineNumber() --------------------

    @Test
    public void testGetLineNumberStartsAtZero() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2\n"));
        assertEquals(0, reader.getLineNumber());
    }

    @Test
    public void testGetLineNumberIncrementsOnReadLine() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2\n"));
        long before = reader.getLineNumber();
        String line = reader.readLine();
        assertEquals("line1", line);
        assertEquals(before + 1, reader.getLineNumber());

        line = reader.readLine();
        assertEquals("line2", line);
        assertEquals(before + 2, reader.getLineNumber());
    }

    // -------------------- read() --------------------

    @Test
    public void testReadReturnsSuccessiveChars() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals(EOF, reader.read());
    }

    @Test
    public void testReadOnEmptyStreamReturnsEof() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(EOF, reader.read());
    }

    @Test
    public void testReadAfterEofKeepsReturningEof() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a"));
        assertEquals('a', reader.read());
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.read());
    }

    // -------------------- read(char[], int, int) --------------------

    @Test
    public void testReadIntoBufferFull() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        char[] buf = new char[6];
        int n = reader.read(buf, 0, 6);
        assertEquals(6, n);
        assertEquals("abcdef", new String(buf));
    }

    @Test
    public void testReadIntoBufferWithOffset() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        char[] buf = new char[6];
        int n = reader.read(buf, 2, 3);
        assertEquals(3, n);
        assertEquals('a', buf[2]);
        assertEquals('b', buf[3]);
        assertEquals('c', buf[4]);
    }

    @Test
    public void testReadIntoBufferZeroLengthReturnsZero() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        char[] buf = new char[3];
        int n = reader.read(buf, 0, 0);
        assertEquals(0, n);
    }

    @Test
    public void testReadIntoBufferAtEofReturnsEof() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        char[] buf = new char[3];
        int n = reader.read(buf, 0, 3);
        assertEquals(EOF, n);
    }

    @Test
    public void testReadIntoBufferShorterThanRequestedAtEndOfStream() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        char[] buf = new char[10];
        int n = reader.read(buf, 0, 10);
        assertEquals(3, n);
        assertEquals('a', buf[0]);
        assertEquals('b', buf[1]);
        assertEquals('c', buf[2]);
    }

    // -------------------- peek(char[]) --------------------

    @Test
    public void testPeekDoesNotConsumeCharacters() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcde"));
        char[] array = new char[3];
        int n = reader.peek(array);
        assertEquals(3, n);
        assertEquals('a', array[0]);
        assertEquals('b', array[1]);
        assertEquals('c', array[2]);
        // The characters are still unread afterwards.
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
    }

    @Test
    public void testPeekAtEofReturnsEof() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        char[] array = new char[3];
        int n = reader.peek(array);
        assertEquals(EOF, n);
    }

    @Test
    public void testPeekShorterStreamThanArrayReturnsAvailableCount() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        char[] array = new char[5];
        int n = reader.peek(array);
        assertEquals(2, n);
        assertEquals('a', array[0]);
        assertEquals('b', array[1]);
    }

    @Test
    public void testPeekRepeatedCallsReturnSameData() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        char[] first = new char[3];
        char[] second = new char[3];
        reader.peek(first);
        reader.peek(second);
        assertEquals(new String(first), new String(second));
    }

    // -------------------- readLine() --------------------

    @Test
    public void testReadLineDropsTerminator() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2\n"));
        assertEquals("line1", reader.readLine());
        assertEquals("line2", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    public void testReadLineLastEolCharacterIsLastChar() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2\n"));
        reader.readLine();
        assertEquals('\n', reader.getLastChar());
    }

    @Test
    public void testReadLineAtEofReturnsNullAndSetsEofLastChar() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        String line = reader.readLine();
        assertNull(line);
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    public void testReadLineWithoutTrailingTerminatorReturnsFinalPartialLine() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("onlyline"));
        assertEquals("onlyline", reader.readLine());
        assertNull(reader.readLine());
    }

    // -------------------- mark(int) / reset() --------------------

    @Test
    public void testMarkAndResetRewindsToMarkedPosition() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        reader.mark(10);
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        reader.reset();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
    }

    // -------------------- close() --------------------

    @Test
    public void testCloseThenReadThrowsIOException() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        reader.close();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }

    // -------------------- constructors / getBytesRead() --------------------

    @Test
    public void testDefaultConstructorDoesNotTrackBytes() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"));
        reader.read(new char[5], 0, 5);
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testTrackBytesTrueWithCharsetCountsEncodedBytes() throws IOException {
        ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        reader.read();
        reader.read();
        reader.read();
        // 'a', 'b', 'c' are each a single byte in UTF-8.
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    public void testTrackBytesTrueWithMultiByteCharacter() throws IOException {
        ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("é"), StandardCharsets.UTF_8, true);
        reader.read();
        // U+00E9 ('e' with acute accent) encodes to 2 bytes in UTF-8.
        assertEquals(2, reader.getBytesRead());
    }

    @Test
    public void testTrackBytesTrueWithNullCharsetDoesNotTrackBytes() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), null, true);
        reader.read();
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testTrackBytesFalseWithCharsetDoesNotTrackBytes() throws IOException {
        ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        reader.read();
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testConstructedReaderIsUsableImmediately() throws IOException {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("z"));
        assertTrue(reader.read() == 'z');
    }
}
