/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");
    private static final TimeZone TOKYO = TimeZone.getTimeZone("Asia/Tokyo");

    private static Calendar newCalendar(final TimeZone tz, final Locale locale) {
        final Calendar cal = Calendar.getInstance(tz, locale);
        cal.set(2023, Calendar.JUNE, 15, 10, 30, 45);
        cal.set(Calendar.MILLISECOND, 123);
        return cal;
    }

    @Test
    void testFormatDateMatchesSimpleDateFormat() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", NEW_YORK, Locale.US);
        final Date date = newCalendar(NEW_YORK, Locale.US).getTime();

        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        sdf.setTimeZone(NEW_YORK);

        assertEquals(sdf.format(date), printer.format(date));
    }

    @Test
    void testFormatLongMatchesDate() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS", NEW_YORK, Locale.US);
        final Date date = newCalendar(NEW_YORK, Locale.US).getTime();

        assertEquals(printer.format(date), printer.format(date.getTime()));
    }

    @Test
    void testFormatCalendarUsesConfiguredTimeZoneNotCalendarTimeZone() {
        // Printer is configured for Tokyo, but the Calendar passed in is in New York time.
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm", TOKYO, Locale.US);
        final Calendar nyCalendar = newCalendar(NEW_YORK, Locale.US);

        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        sdf.setTimeZone(TOKYO);

        assertEquals(sdf.format(nyCalendar.getTime()), printer.format(nyCalendar));
        // The original calendar must not be mutated by format().
        assertEquals(NEW_YORK, nyCalendar.getTimeZone());
    }

    @Test
    void testFormatCalendarWithMatchingTimeZoneDoesNotClone() {
        final FastDatePrinter printer = new FastDatePrinter("HH:mm", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);

        final StringBuilder buf = new StringBuilder();
        final StringBuilder result = printer.format(cal, buf);

        assertTrue(result == buf);
        assertEquals("10:30", result.toString());
    }

    @Test
    void testFormatCalendarStringBufferUsesCalendarInstant() {
        // format(Calendar, StringBuffer) formats via calendar.getTime(), so the printer's own
        // time zone is applied regardless of the time zone set on the supplied Calendar.
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm", TOKYO, Locale.US);
        final Calendar nyCalendar = newCalendar(NEW_YORK, Locale.US);

        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        sdf.setTimeZone(TOKYO);

        final StringBuffer buf = new StringBuffer();
        final StringBuffer result = printer.format(nyCalendar, buf);

        assertTrue(result == buf);
        assertEquals(sdf.format(nyCalendar.getTime()), result.toString());
    }

    @Test
    void testFormatObjectDispatchesByType() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);
        final Date date = cal.getTime();

        assertEquals(printer.format(date), printer.format((Object) date));
        assertEquals(printer.format(cal), printer.format((Object) cal));
        assertEquals(printer.format(date.getTime()), printer.format((Object) Long.valueOf(date.getTime())));
    }

    @Test
    void testFormatObjectRejectsUnsupportedType() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
        assertTrue(ex.getMessage().contains("Unknown class"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectStringBufferDispatchesByType() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);
        final Date date = cal.getTime();

        final StringBuffer dateBuf = new StringBuffer();
        printer.format((Object) date, dateBuf, new FieldPosition(0));
        assertEquals(printer.format(date), dateBuf.toString());

        final StringBuffer calBuf = new StringBuffer();
        printer.format((Object) cal, calBuf, new FieldPosition(0));
        assertEquals(printer.format(cal), calBuf.toString());

        final StringBuffer longBuf = new StringBuffer();
        printer.format((Object) Long.valueOf(date.getTime()), longBuf, new FieldPosition(0));
        assertEquals(printer.format(date.getTime()), longBuf.toString());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectStringBufferRejectsUnsupportedType() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) Boolean.TRUE, new StringBuffer(), new FieldPosition(0));
            }
        });
    }

    @Test
    void testGetPatternTimeZoneLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.GERMANY);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(NEW_YORK, printer.getTimeZone());
        assertEquals(Locale.GERMANY, printer.getLocale());
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", NEW_YORK, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, NEW_YORK, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsOnFormat() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", null, Locale.US);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format(new Date());
            }
        });
    }

    @Test
    void testGetMaxLengthEstimateIsNonNegativeAndSufficient() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss.SSSZZ", NEW_YORK, Locale.US);
        final Date date = newCalendar(NEW_YORK, Locale.US).getTime();
        final String formatted = printer.format(date);

        assertTrue(printer.getMaxLengthEstimate() >= formatted.length());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter a = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDatePrinter b = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDatePrinter diffPattern = new FastDatePrinter("yyyy/MM/dd", NEW_YORK, Locale.US);
        final FastDatePrinter diffZone = new FastDatePrinter("yyyy-MM-dd", TOKYO, Locale.US);
        final FastDatePrinter diffLocale = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.GERMANY);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffZone);
        assertNotEquals(a, diffLocale);
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZoneId() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        final String str = printer.toString();

        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains(NEW_YORK.getID()));
        assertTrue(str.startsWith("FastDatePrinter["));
    }

    @Test
    void testIllegalPatternCharacterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy-qq", NEW_YORK, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("Illegal pattern component"));
    }

    @Test
    void testIsoPatternTooLongThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("XXXX", NEW_YORK, Locale.US);
            }
        });
    }

    @Test
    void testIsoPatternVariants() {
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);

        final String x1 = new FastDatePrinter("X", NEW_YORK, Locale.US).format(cal);
        final String x2 = new FastDatePrinter("XX", NEW_YORK, Locale.US).format(cal);
        final String x3 = new FastDatePrinter("XXX", NEW_YORK, Locale.US).format(cal);

        // New York is UTC-04:00 in June (daylight saving).
        assertEquals("-04", x1);
        assertEquals("-0400", x2);
        assertEquals("-04:00", x3);
    }

    @Test
    void testTwelveHourFieldMapsMidnightToTwelve() {
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.set(2023, Calendar.JUNE, 15, 0, 5, 0);

        final FastDatePrinter printer = new FastDatePrinter("hh:mm", NEW_YORK, Locale.US);
        assertEquals("12:05", printer.format(cal));
    }

    @Test
    void testTwentyFourHourFieldMapsMidnightToTwentyFour() {
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.set(2023, Calendar.JUNE, 15, 0, 5, 0);

        final FastDatePrinter printer = new FastDatePrinter("kk:mm", NEW_YORK, Locale.US);
        assertEquals("24:05", printer.format(cal));
    }

    @Test
    void testTwoDigitNumberFieldOverflowsPaddingWhenValueHasMoreDigits() {
        // SS with a NumberRule field (millisecond) selects TwoDigitNumberField; values >= 100
        // are not truncated, they simply take up more than two characters.
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.set(2023, Calendar.JUNE, 15, 10, 30, 45);
        cal.set(Calendar.MILLISECOND, 123);

        final FastDatePrinter printer = new FastDatePrinter("SS", NEW_YORK, Locale.US);
        assertEquals("123", printer.format(cal));
    }

    @Test
    void testPaddedNumberFieldPadsWithLeadingZeros() {
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.set(2023, Calendar.JUNE, 15, 10, 30, 45);
        cal.set(Calendar.MILLISECOND, 7);

        final FastDatePrinter printer = new FastDatePrinter("SSS", NEW_YORK, Locale.US);
        assertEquals("007", printer.format(cal));
    }

    @Test
    void testUnpaddedYearFieldHandlesSmallYear() {
        final Calendar cal = new GregorianCalendar(NEW_YORK, Locale.US);
        cal.clear();
        cal.set(Calendar.ERA, GregorianCalendar.AD);
        cal.set(Calendar.YEAR, 7);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);

        final FastDatePrinter printer = new FastDatePrinter("yyyy", NEW_YORK, Locale.US);
        assertEquals("0007", printer.format(cal));
    }

    @Test
    void testTwoDigitYearFieldTruncatesToLastTwoDigits() {
        final Calendar cal = new GregorianCalendar(NEW_YORK, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 2023);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);

        final FastDatePrinter printer = new FastDatePrinter("yy", NEW_YORK, Locale.US);
        assertEquals("23", printer.format(cal));
    }

    @Test
    void testLiteralTextAndEscapedQuote() {
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);
        final FastDatePrinter printer = new FastDatePrinter("yyyy 'o''clock' HH", NEW_YORK, Locale.US);
        assertEquals("2023 o'clock 10", printer.format(cal));
    }

    @Test
    void testTimeZoneNumberRuleWithAndWithoutColon() {
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);

        final FastDatePrinter noColon = new FastDatePrinter("Z", NEW_YORK, Locale.US);
        final FastDatePrinter withColon = new FastDatePrinter("ZZZ", NEW_YORK, Locale.US);

        assertEquals("-0400", noColon.format(cal));
        assertEquals("-04:00", withColon.format(cal));
    }

    @Test
    void testTextFieldsForEraMonthAndWeekday() {
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);
        final FastDatePrinter printer = new FastDatePrinter("G MMMM EEEE", NEW_YORK, Locale.US);

        assertEquals("AD June Thursday", printer.format(cal));
    }

    @Test
    void testAmPmMarker() {
        final Calendar morning = Calendar.getInstance(NEW_YORK, Locale.US);
        morning.set(2023, Calendar.JUNE, 15, 9, 0, 0);
        final Calendar afternoon = Calendar.getInstance(NEW_YORK, Locale.US);
        afternoon.set(2023, Calendar.JUNE, 15, 15, 0, 0);

        final FastDatePrinter printer = new FastDatePrinter("a", NEW_YORK, Locale.US);
        assertEquals("AM", printer.format(morning));
        assertEquals("PM", printer.format(afternoon));
    }

    @Test
    void testSerializationRoundTripReinitializesRulesAndStillFormats() throws IOException, ClassNotFoundException {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", NEW_YORK, Locale.US);
        final Date date = newCalendar(NEW_YORK, Locale.US).getTime();
        final String expected = printer.format(date);

        final ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        final ObjectOutputStream objOut = new ObjectOutputStream(byteOut);
        objOut.writeObject(printer);
        objOut.close();

        final ObjectInputStream objIn = new ObjectInputStream(new ByteArrayInputStream(byteOut.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) objIn.readObject();
        objIn.close();

        assertNotNull(deserialized);
        assertEquals(printer, deserialized);
        assertEquals(expected, deserialized.format(date));
        assertEquals(printer.getMaxLengthEstimate(), deserialized.getMaxLengthEstimate());
    }

    @Test
    void testParsePatternThrowsOnTrailingUnmatchedQuote() {
        // An unterminated quoted literal is parsed as a single-character literal rule
        // ("'" is dropped as the quote delimiter leaving an empty literal), not an error;
        // this exercises the StringLiteral/CharacterLiteral split in parsePattern().
        final FastDatePrinter printer = new FastDatePrinter("yyyy'", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar(NEW_YORK, Locale.US);
        assertEquals("2023", printer.format(cal));
    }
}
