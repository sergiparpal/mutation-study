/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    @Test
    public void testGetFractionIntInt_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_overflowOnNegate() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom_basic() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenom_negativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenom_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 2, -3);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -2, 3);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom_overflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 1);
            }
        });
    }

    @Test
    public void testGetFractionDouble_basic() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_negative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_wholeNumber() {
        final Fraction f = Fraction.getFraction(5.0d);
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_nanThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((double) Integer.MAX_VALUE + 1.0d);
            }
        });
    }

    @Test
    public void testGetFractionString_doubleFormat() {
        final Fraction f = Fraction.getFraction("1.25");
        assertEquals(5, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionString_mixedFormat() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_simpleFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_wholeNumber() {
        final Fraction f = Fraction.getFraction("8");
        assertEquals(8, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionString_malformedMixedThrowsNFE() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3-7");
            }
        });
    }

    @Test
    public void testGetFractionString_zeroDenominatorWrapsArithmeticExceptionAsCause() {
        final NumberFormatException nfe = assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1/0");
            }
        });
        assertTrue(nfe.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionString_invalidNumberThrowsNFE() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("abc");
            }
        });
    }

    @Test
    public void testGetReducedFraction_reduces() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorNormalizesToZero() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFraction_negativeDenominatorNormalized() {
        final Fraction f = Fraction.getReducedFraction(4, -8);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    @Test
    public void testAbs_positiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbs_negativeReturnsPositive() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAdd_basic() {
        final Fraction f = Fraction.getFraction(1, 3).add(Fraction.getFraction(1, 3));
        assertEquals(2, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testAdd_zeroIdentity() {
        final Fraction f = Fraction.ZERO.add(Fraction.getFraction(2, 5));
        assertEquals(2, f.getNumerator());
        assertEquals(5, f.getDenominator());
    }

    @Test
    public void testAdd_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.add(null);
            }
        });
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction f1 = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f1.add(Fraction.ONE);
            }
        });
    }

    @Test
    public void testCompareTo_lessEqualGreater() {
        final Fraction oneThird = Fraction.getFraction(1, 3);
        final Fraction twoThirds = Fraction.getFraction(2, 3);
        assertTrue(oneThird.compareTo(twoThirds) < 0);
        assertTrue(twoThirds.compareTo(oneThird) > 0);
        assertEquals(0, oneThird.compareTo(Fraction.getFraction(1, 3)));
        // 1/2 and 2/4 are numerically equal though not equals()
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareTo_sameInstance() {
        final Fraction f = Fraction.getFraction(5, 9);
        assertEquals(0, f.compareTo(f));
    }

    @Test
    public void testCompareTo_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.compareTo(null);
            }
        });
    }

    @Test
    public void testDivideBy_basic() {
        final Fraction f = Fraction.getFraction(1, 3).divideBy(Fraction.getFraction(2, 3));
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testDivideBy_zeroNumeratorYieldsZero() {
        final Fraction f = Fraction.ZERO.divideBy(Fraction.getFraction(3, 5));
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testDivideBy_byZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideBy_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.divideBy(null);
            }
        });
    }

    @Test
    public void testDoubleValue() {
        assertEquals(0.75d, Fraction.getFraction(3, 4).doubleValue(), 0.0d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.75f, Fraction.getFraction(3, 4).floatValue(), 0.0f);
    }

    @Test
    public void testIntValue_truncatesTowardZero() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWhole_negative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    public void testEquals_sameNumeratorDenominator() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
    }

    @Test
    public void testEquals_unreducedNotEqual() {
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
    }

    @Test
    public void testEquals_notAFraction() {
        assertFalse(Fraction.ONE.equals("1/1"));
    }

    @Test
    public void testEquals_null() {
        assertFalse(Fraction.ONE.equals(null));
    }

    @Test
    public void testEquals_self() {
        assertTrue(Fraction.ONE.equals(Fraction.ONE));
    }

    @Test
    public void testHashCode_consistentWithEquals() {
        final Fraction a = Fraction.getFraction(3, 5);
        final Fraction b = Fraction.getFraction(3, 5);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testInvert_basic() {
        final Fraction f = Fraction.getFraction(3, 7).invert();
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvert_negative() {
        final Fraction f = Fraction.getFraction(-3, 7).invert();
        assertEquals(-7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvert_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    @Test
    public void testMultiplyBy_basic() {
        final Fraction f = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testMultiplyBy_zeroYieldsZero() {
        final Fraction f = Fraction.getFraction(2, 3).multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testMultiplyBy_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.multiplyBy(null);
            }
        });
    }

    @Test
    public void testNegate_basic() {
        final Fraction f = Fraction.getFraction(3, 7).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testNegate_minValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    @Test
    public void testPow_positive() {
        final Fraction f = Fraction.getFraction(2, 3).pow(3);
        assertEquals(8, f.getNumerator());
        assertEquals(27, f.getDenominator());
    }

    @Test
    public void testPow_zeroReturnsOneEvenForZeroBase() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPow_one() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPow_negative() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-2);
        assertEquals(9, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testPow_minValueExponentDoesNotThrowOnTrivialBase() {
        // base reduces to a fraction whose inverse ultimately collapses through squaring;
        // using ONE avoids any overflow while still exercising the MIN_VALUE branch.
        final Fraction f = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testReduce_reducesToLowestTerms() {
        final Fraction f = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testReduce_alreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduce_zeroNumeratorNotZeroConstantReturnsZero() {
        final Fraction f = Fraction.getFraction(0, 5);
        final Fraction reduced = f.reduce();
        assertEquals(0, reduced.getNumerator());
        assertEquals(1, reduced.getDenominator());
    }

    @Test
    public void testSubtract_basic() {
        final Fraction f = Fraction.getFraction(2, 3).subtract(Fraction.getFraction(1, 3));
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testSubtract_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.subtract(null);
            }
        });
    }

    @Test
    public void testToProperString_wholeOnly() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperString_zero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperString_negativeOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperString_mixedNumber() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperString_negativeMixedNumber() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperString_properFractionOnly() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToProperString_cachedValueConsistent() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(f.toProperString(), f.toProperString());
    }

    @Test
    public void testToString_basic() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
    }

    @Test
    public void testToString_cachedValueConsistent() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(f.toString(), f.toString());
    }

    @Test
    public void testIntValueAndLongValue_wholeNumberExactly() {
        final Fraction f = Fraction.getFraction(10, 2);
        assertEquals(5, f.intValue());
        assertEquals(5L, f.longValue());
        assertEquals(5.0d, f.doubleValue(), 0.0d);
    }
}
