/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    @Test
    void testNewFormatBasics() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals("|", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.newFormat('\n');
            }
        });
    }

    @Test
    void testDefaultFormatSettings() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getTrim());
        assertFalse(format.getTrailingDelimiter());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
    }

    @Test
    void testExcelFormatSettings() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testMySqlFormatSettings() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertNull(format.getQuoteCharacter());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testValueOfAndPredefined() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.valueOf("NoSuchFormat");
            }
        });
    }

    @Test
    void testBuilderDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    void testBuilderCreateFromFormatCopiesState() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setTrim(true).get();
        final CSVFormat copy = CSVFormat.Builder.create(original).get();
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDelimiter("");
            }
        });
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDelimiter("\r");
            }
        });
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setCommentMarker('\n');
            }
        });
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setEscape('\r');
            }
        });
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setQuote('\n');
            }
        });
    }

    @Test
    void testSetDuplicateHeaderModeRejectsNull() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDuplicateHeaderMode(null);
            }
        });
    }

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setQuote(null).setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setEscape(null).setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderDisallowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B", "A").get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeaderAllowEmptyAllowsBlankDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "").get();
        assertArrayEquals(new String[] {"A", "", ""}, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeaderAllowEmptyRejectsNonBlankDuplicates() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get();
            }
        });
    }

    @Test
    void testSetHeaderFromEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header = format.getHeader();
        header[0] = "MUTATED";
        assertArrayEquals(new String[] {"A", "B"}, format.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", "two").get();
        final String[] comments = format.getHeaderComments();
        comments[0] = "MUTATED";
        assertArrayEquals(new String[] {"one", "two"}, format.getHeaderComments());
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').setHeader("A", "B").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').setHeader("A", "B").get();
        final CSVFormat c = CSVFormat.DEFAULT.builder().setDelimiter(':').setHeader("A", "B").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
        assertEquals(a, a);
    }

    @Test
    void testFormatValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatQuotesValuesWithDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        final CSVFormat format = CSVFormat.newFormat('\t');
        assertEquals('\t', format.getDelimiter());
    }

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringReflectsQuoteAndComment() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("QuoteChar=<\">"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testBuilderRoundTrip() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat rebuilt = original.builder().get();
        assertEquals(original, rebuilt);
        assertNotSame(original, rebuilt);
    }

    @Test
    void testPrintRecordAndPrintln() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintNullValueUsesEmptyStringByDefault() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueUsesNullStringWhenSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintAppendableReturnsWorkingPrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        assertNotNull(printer);
        printer.printRecord("1", "2");
        printer.close();
        assertEquals("1,2\r\n", writer.toString());
    }

    @Test
    void testParseReturnsWorkingParser() throws IOException {
        final Reader reader = new StringReader("a,b\n1,2\n");
        final CSVParser parser = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get().parse(reader);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get("col1"));
        assertEquals("2", records.get(1).get("col2"));
        parser.close();
    }

    @Test
    void testMaxRowsLimitsParsing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        assertEquals(1L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        final CSVParser parser = format.parse(new StringReader("1\n2\n3\n"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        parser.close();
    }

    @Test
    void testMaxRowsZeroMeansUnlimited() {
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
    }

    @Test
    void testDeprecatedWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
        assertNotEquals(format, CSVFormat.DEFAULT);
    }

    @Test
    void testDeprecatedWithHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        assertArrayEquals(new String[] {"A", "B"}, format.getHeader());
    }

    @Test
    void testDeprecatedWithQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testDeprecatedWithAllowDuplicateHeaderNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testIsQuoteCharacterSetAndEscapeCharacterSet() {
        final CSVFormat quoted = CSVFormat.DEFAULT;
        assertTrue(quoted.isQuoteCharacterSet());
        final CSVFormat noQuote = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(noQuote.isQuoteCharacterSet());
        final CSVFormat escaped = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertTrue(escaped.isEscapeCharacterSet());
    }
}
