package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FractionAgentTest {

    private static final double DELTA = 0.0000001d;

    // ---------------------------------------------------------------
    // Public static final fields
    // ---------------------------------------------------------------

    @Test
    public void testConstantZero() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
    }

    @Test
    public void testConstantOne() {
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
    }

    @Test
    public void testConstantOneHalf() {
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
    }

    @Test
    public void testConstantOneThird() {
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
    }

    @Test
    public void testConstantTwoThirds() {
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
    }

    @Test
    public void testConstantOneQuarter() {
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
    }

    @Test
    public void testConstantTwoQuarters() {
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantThreeQuarters() {
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantOneFifth() {
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
    }

    @Test
    public void testConstantTwoFifths() {
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantThreeFifths() {
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantFourFifths() {
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ---------------------------------------------------------------
    // getFraction(double)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionDoubleHalf() {
        Fraction f = Fraction.getFraction(0.5d);
        assertEquals(0.5d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionDoubleZero() {
        Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0.0d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionDoubleOne() {
        Fraction f = Fraction.getFraction(1.0d);
        assertEquals(1.0d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionDoubleOneThird() {
        Fraction f = Fraction.getFraction(1.0d / 3.0d);
        assertEquals(1.0d / 3.0d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1.0e10d);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooNegativeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(-1.0e10d);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionIntIntNormal() {
        Fraction f = Fraction.getFraction(3, 4);
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSign() {
        Fraction f = Fraction.getFraction(3, -4);
        assertEquals(-3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroNumerator() {
        Fraction f = Fraction.getFraction(0, 5);
        assertEquals(0, f.getNumerator());
        assertEquals(5, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntIntMinValueNumeratorNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(int, int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionWholeNumDenomNormal() {
        Fraction f = Fraction.getFraction(1, 3, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeWhole() {
        Fraction f = Fraction.getFraction(-1, 3, 4);
        assertEquals(-7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenomZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, 1, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenomOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(String)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionStringSimpleFraction() {
        Fraction f = Fraction.getFraction("1/2");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringProperFraction() {
        Fraction f = Fraction.getFraction("1 3/4");
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        Fraction f = Fraction.getFraction("7");
        assertEquals(7, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        Fraction f = Fraction.getFraction("0.5");
        assertEquals(0.5d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringInvalidFormatThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                Fraction.getFraction("not a fraction");
            }
        });
    }

    @Test
    public void testGetFractionStringEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                Fraction.getFraction("");
            }
        });
    }

    // ---------------------------------------------------------------
    // getReducedFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetReducedFractionReduces() {
        Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionNegativeDenominatorMovesSign() {
        Fraction f = Fraction.getReducedFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // abs()
    // ---------------------------------------------------------------

    @Test
    public void testAbsOfPositive() {
        Fraction f = Fraction.getFraction(3, 4);
        Fraction result = f.abs();
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testAbsOfNegative() {
        Fraction f = Fraction.getFraction(-3, 4);
        Fraction result = f.abs();
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    // ---------------------------------------------------------------
    // add(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testAddNormal() {
        Fraction result = Fraction.ONE_HALF.add(Fraction.ONE_THIRD);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE_HALF.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                big.add(big);
            }
        });
    }

    // ---------------------------------------------------------------
    // compareTo(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testCompareToGreater() {
        assertTrue(Fraction.ONE_HALF.compareTo(Fraction.ONE_THIRD) > 0);
    }

    @Test
    public void testCompareToLess() {
        assertTrue(Fraction.ONE_THIRD.compareTo(Fraction.ONE_HALF) < 0);
    }

    @Test
    public void testCompareToEqualDespiteDifferentRepresentation() {
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.TWO_QUARTERS));
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE_HALF.compareTo(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // divideBy(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testDivideByNormal() {
        Fraction result = Fraction.ONE_HALF.divideBy(Fraction.ONE_QUARTER);
        assertEquals(2.0d, result.doubleValue(), DELTA);
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.ONE_HALF.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE_HALF.divideBy(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // doubleValue()
    // ---------------------------------------------------------------

    @Test
    public void testDoubleValue() {
        assertEquals(0.5d, Fraction.ONE_HALF.doubleValue(), DELTA);
        assertEquals(0.0d, Fraction.ZERO.doubleValue(), DELTA);
    }

    // ---------------------------------------------------------------
    // equals(Object)
    // ---------------------------------------------------------------

    @Test
    public void testEqualsSameValue() {
        assertTrue(Fraction.ONE_HALF.equals(Fraction.getFraction(1, 2)));
    }

    @Test
    public void testEqualsDifferentRepresentationNotEqual() {
        assertFalse(Fraction.getFraction(1, 2).equals(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(Fraction.ONE_HALF.equals(null));
    }

    @Test
    public void testEqualsNonFractionObject() {
        assertFalse(Fraction.ONE_HALF.equals("1/2"));
    }

    // ---------------------------------------------------------------
    // floatValue()
    // ---------------------------------------------------------------

    @Test
    public void testFloatValue() {
        assertEquals(0.5f, Fraction.ONE_HALF.floatValue(), 0.0000001f);
    }

    // ---------------------------------------------------------------
    // getDenominator() / getNumerator()
    // ---------------------------------------------------------------

    @Test
    public void testGetNumeratorImproperFraction() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ---------------------------------------------------------------
    // getProperNumerator() / getProperWhole()
    // ---------------------------------------------------------------

    @Test
    public void testProperPartsPositiveImproperFraction() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testProperPartsNegativeImproperFraction() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testProperPartsSimpleFraction() {
        assertEquals(0, Fraction.ONE_HALF.getProperWhole());
        assertEquals(1, Fraction.ONE_HALF.getProperNumerator());
    }

    // ---------------------------------------------------------------
    // hashCode()
    // ---------------------------------------------------------------

    @Test
    public void testHashCodeConsistentWithEquals() {
        Fraction a = Fraction.ONE_HALF;
        Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    // ---------------------------------------------------------------
    // intValue() / longValue()
    // ---------------------------------------------------------------

    @Test
    public void testIntValueAndLongValue() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.intValue());
        assertEquals(1L, f.longValue());
    }

    @Test
    public void testIntValueAndLongValueNegative() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.intValue());
        assertEquals(-1L, f.longValue());
    }

    // ---------------------------------------------------------------
    // invert()
    // ---------------------------------------------------------------

    @Test
    public void testInvertNormal() {
        Fraction f = Fraction.getFraction(3, 4);
        Fraction result = f.invert();
        assertEquals(4, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    // ---------------------------------------------------------------
    // multiplyBy(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testMultiplyByNormal() {
        Fraction result = Fraction.ONE_HALF.multiplyBy(Fraction.TWO_THIRDS);
        assertEquals(1, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE_HALF.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction two = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                big.multiplyBy(two);
            }
        });
    }

    // ---------------------------------------------------------------
    // negate()
    // ---------------------------------------------------------------

    @Test
    public void testNegateNormal() {
        Fraction result = Fraction.ONE_HALF.negate();
        assertEquals(-1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    // ---------------------------------------------------------------
    // pow(int)
    // ---------------------------------------------------------------

    @Test
    public void testPowZeroReturnsOneEvenForZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOneReturnsThis() {
        Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowPositive() {
        Fraction result = Fraction.ONE_HALF.pow(2);
        assertEquals(1, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPowOverflowThrows() {
        final Fraction two = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                two.pow(32);
            }
        });
    }

    // ---------------------------------------------------------------
    // reduce()
    // ---------------------------------------------------------------

    @Test
    public void testReduceSimplifies() {
        Fraction f = Fraction.getFraction(2, 4);
        Fraction result = f.reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsThis() {
        Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.reduce());
    }

    // ---------------------------------------------------------------
    // subtract(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testSubtractNormal() {
        Fraction result = Fraction.ONE_HALF.subtract(Fraction.ONE_THIRD);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE_HALF.subtract(null);
            }
        });
    }

    @Test
    public void testSubtractOverflowThrows() {
        final Fraction minFraction = Fraction.getFraction(Integer.MIN_VALUE, 1);
        final Fraction maxFraction = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                minFraction.subtract(maxFraction);
            }
        });
    }

    // ---------------------------------------------------------------
    // toProperString()
    // ---------------------------------------------------------------

    @Test
    public void testToProperStringSimpleFraction() {
        assertEquals("1/2", Fraction.ONE_HALF.toProperString());
    }

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringWholeOnly() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    // ---------------------------------------------------------------
    // toString()
    // ---------------------------------------------------------------

    @Test
    public void testToStringFormat() {
        assertEquals("7/4", Fraction.getFraction(7, 4).toString());
        assertEquals("1/2", Fraction.ONE_HALF.toString());
        assertEquals("0/1", Fraction.ZERO.toString());
    }

    // ---------------------------------------------------------------
    // Number superclass / Comparable interface sanity
    // ---------------------------------------------------------------

    @Test
    public void testIsNumberAndComparable() {
        assertTrue(Fraction.ONE_HALF instanceof Number);
        assertTrue(Fraction.ONE_HALF instanceof Comparable);
        assertNotNull(Fraction.ONE_HALF);
    }
}
