/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link Validate}.
 */
class ValidateAgentTest {

    // -------------------- isTrue --------------------

    @Test
    void testIsTrue_simple_true() {
        Validate.isTrue(true);
    }

    @Test
    void testIsTrue_simple_false() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false);
            }
        });
        assertEquals("The validated expression is false", e.getMessage());
    }

    @Test
    void testIsTrue_withMessage_false() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "msg %s", "x");
            }
        });
        assertEquals("msg x", e.getMessage());
    }

    @Test
    void testIsTrue_withLongValue() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "value is %d", 7L);
            }
        });
        assertEquals("value is 7", e.getMessage());
    }

    @Test
    void testIsTrue_withDoubleValue() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "value is %s", 1.5d);
            }
        });
        assertEquals("value is 1.5", e.getMessage());
    }

    @Test
    void testIsTrue_withSupplier_true_doesNotCallSupplier() {
        Validate.isTrue(true, new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                fail("supplier should not be invoked when expression is true");
                return "unused";
            }
        });
    }

    @Test
    void testIsTrue_withSupplier_false() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, new java.util.function.Supplier<String>() {
                    @Override
                    public String get() {
                        return "supplied message";
                    }
                });
            }
        });
        assertEquals("supplied message", e.getMessage());
    }

    // -------------------- notNull --------------------

    @Test
    void testNotNull_returnsSameInstance() {
        final String obj = "value";
        assertSame(obj, Validate.notNull(obj));
    }

    @Test
    void testNotNull_null_throwsNPE() {
        final NullPointerException e = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null);
            }
        });
        assertEquals("The validated object is null", e.getMessage());
    }

    @Test
    void testNotNull_withMessage_null_throwsNPEWithMessage() {
        final NullPointerException e = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null, "custom %s", "msg");
            }
        });
        assertEquals("custom msg", e.getMessage());
    }

    // -------------------- notEmpty (CharSequence) --------------------

    @Test
    void testNotEmptyCharSequence_valid() {
        assertEquals("abc", Validate.notEmpty("abc"));
    }

    @Test
    void testNotEmptyCharSequence_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((String) null);
            }
        });
    }

    @Test
    void testNotEmptyCharSequence_empty_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty("");
            }
        });
        assertEquals("The validated character sequence is empty", e.getMessage());
    }

    // -------------------- notEmpty (Collection) --------------------

    @Test
    void testNotEmptyCollection_valid() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertSame(list, Validate.notEmpty(list));
    }

    @Test
    void testNotEmptyCollection_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((List<?>) null);
            }
        });
    }

    @Test
    void testNotEmptyCollection_empty_throwsIAE() {
        final List<String> list = new ArrayList<String>();
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(list);
            }
        });
        assertEquals("The validated collection is empty", e.getMessage());
    }

    // -------------------- notEmpty (Map) --------------------

    @Test
    void testNotEmptyMap_valid() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertSame(map, Validate.notEmpty(map));
    }

    @Test
    void testNotEmptyMap_empty_throwsIAE() {
        final Map<String, String> map = new HashMap<String, String>();
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(map);
            }
        });
        assertEquals("The validated map is empty", e.getMessage());
    }

    // -------------------- notEmpty (array) --------------------

    @Test
    void testNotEmptyArray_valid() {
        final String[] array = {"a", "b"};
        assertSame(array, Validate.notEmpty(array));
    }

    @Test
    void testNotEmptyArray_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((String[]) null);
            }
        });
    }

    @Test
    void testNotEmptyArray_empty_throwsIAE() {
        final String[] array = new String[0];
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(array);
            }
        });
        assertEquals("The validated array is empty", e.getMessage());
    }

    // -------------------- notBlank --------------------

    @Test
    void testNotBlank_valid() {
        assertEquals("abc", Validate.notBlank("abc"));
    }

    @Test
    void testNotBlank_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank((String) null);
            }
        });
    }

    @Test
    void testNotBlank_whitespace_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("   ");
            }
        });
        assertEquals("The validated character sequence is blank", e.getMessage());
    }

    @Test
    void testNotBlank_empty_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("");
            }
        });
    }

    // -------------------- noNullElements (array) --------------------

    @Test
    void testNoNullElementsArray_valid() {
        final String[] array = {"a", "b"};
        assertSame(array, Validate.noNullElements(array));
    }

    @Test
    void testNoNullElementsArray_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((String[]) null);
            }
        });
    }

    @Test
    void testNoNullElementsArray_withNullElement_throwsIAEWithIndex() {
        final String[] array = {"a", null, "c"};
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(array);
            }
        });
        assertEquals("The validated array contains null element at index: 1", e.getMessage());
    }

    // -------------------- noNullElements (iterable) --------------------

    @Test
    void testNoNullElementsIterable_valid() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertSame(list, Validate.noNullElements(list));
    }

    @Test
    void testNoNullElementsIterable_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((List<?>) null);
            }
        });
    }

    @Test
    void testNoNullElementsIterable_withNullElement_throwsIAEWithIndex() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add(null);
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(list);
            }
        });
        assertEquals("The validated collection contains null element at index: 0", e.getMessage());
    }

    // -------------------- validIndex (array) --------------------

    @Test
    void testValidIndexArray_valid() {
        final String[] array = {"a", "b", "c"};
        assertSame(array, Validate.validIndex(array, 1));
    }

    @Test
    void testValidIndexArray_negative_throwsIOOBE() {
        final String[] array = {"a"};
        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(array, -1);
            }
        });
        assertEquals("The validated array index is invalid: -1", e.getMessage());
    }

    @Test
    void testValidIndexArray_tooLarge_throwsIOOBE() {
        final String[] array = {"a"};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(array, 1);
            }
        });
    }

    // -------------------- validIndex (collection) --------------------

    @Test
    void testValidIndexCollection_valid() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertSame(list, Validate.validIndex(list, 0));
    }

    @Test
    void testValidIndexCollection_boundaryTooLarge_throwsIOOBE() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, 1);
            }
        });
        assertEquals("The validated collection index is invalid: 1", e.getMessage());
    }

    // -------------------- validIndex (CharSequence) --------------------

    @Test
    void testValidIndexCharSequence_valid() {
        assertEquals("abc", Validate.validIndex("abc", 2));
    }

    @Test
    void testValidIndexCharSequence_tooLarge_throwsIOOBE() {
        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex("abc", 3);
            }
        });
        assertEquals("The validated character sequence index is invalid: 3", e.getMessage());
    }

    @Test
    void testValidIndexCharSequence_null_throwsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((String) null, 0);
            }
        });
    }

    // -------------------- validState --------------------

    @Test
    void testValidState_true() {
        Validate.validState(true);
    }

    @Test
    void testValidState_false_throwsISE() {
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false);
            }
        });
        assertEquals("The validated state is false", e.getMessage());
    }

    @Test
    void testValidState_falseWithMessage_throwsISEWithMessage() {
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false, "state %s", "bad");
            }
        });
        assertEquals("state bad", e.getMessage());
    }

    // -------------------- matchesPattern --------------------

    @Test
    void testMatchesPattern_valid() {
        Validate.matchesPattern("hi", "[a-z]*");
    }

    @Test
    void testMatchesPattern_invalid_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("Hi123", "[a-z]*");
            }
        });
        assertEquals("The string Hi123 does not match the pattern [a-z]*", e.getMessage());
    }

    @Test
    void testMatchesPattern_withMessage_invalid() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("Hi123", "[a-z]*", "%s does not match %s", "Hi123", "[a-z]*");
            }
        });
        assertEquals("Hi123 does not match [a-z]*", e.getMessage());
    }

    // -------------------- notNaN --------------------

    @Test
    void testNotNaN_valid() {
        Validate.notNaN(1.0d);
    }

    @Test
    void testNotNaN_nan_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNaN(Double.NaN);
            }
        });
        assertEquals("The validated value is not a number", e.getMessage());
    }

    // -------------------- finite --------------------

    @Test
    void testFinite_valid() {
        Validate.finite(1.0d);
    }

    @Test
    void testFinite_positiveInfinity_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.POSITIVE_INFINITY);
            }
        });
    }

    @Test
    void testFinite_negativeInfinity_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NEGATIVE_INFINITY);
            }
        });
    }

    @Test
    void testFinite_nan_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NaN);
            }
        });
    }

    // -------------------- inclusiveBetween (long) --------------------

    @Test
    void testInclusiveBetweenLong_withinRange() {
        Validate.inclusiveBetween(0L, 2L, 1L);
    }

    @Test
    void testInclusiveBetweenLong_atLowerBoundary() {
        Validate.inclusiveBetween(0L, 2L, 0L);
    }

    @Test
    void testInclusiveBetweenLong_atUpperBoundary() {
        Validate.inclusiveBetween(0L, 2L, 2L);
    }

    @Test
    void testInclusiveBetweenLong_belowRange_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, -1L);
            }
        });
        assertEquals("The value -1 is not in the specified inclusive range of 0 to 2", e.getMessage());
    }

    @Test
    void testInclusiveBetweenLong_aboveRange_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L);
            }
        });
    }

    @Test
    void testInclusiveBetweenLong_withMessage_outOfRange() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L, "out of range");
            }
        });
        assertEquals("out of range", e.getMessage());
    }

    // -------------------- inclusiveBetween (double) --------------------

    @Test
    void testInclusiveBetweenDouble_withinRange() {
        Validate.inclusiveBetween(0.1, 2.1, 1.1);
    }

    @Test
    void testInclusiveBetweenDouble_nan_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, Double.NaN);
            }
        });
    }

    @Test
    void testInclusiveBetweenDouble_belowRange_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 0.0);
            }
        });
    }

    // -------------------- inclusiveBetween (Comparable) --------------------

    @Test
    void testInclusiveBetweenComparable_withinRange() {
        Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1));
    }

    @Test
    void testInclusiveBetweenComparable_belowRange_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(-1));
            }
        });
        assertEquals("The value -1 is not in the specified inclusive range of 0 to 2", e.getMessage());
    }

    @Test
    void testInclusiveBetweenComparable_withMessage_outOfRange() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(5), "bad %s", "value");
            }
        });
        assertEquals("bad value", e.getMessage());
    }

    // -------------------- exclusiveBetween (long) --------------------

    @Test
    void testExclusiveBetweenLong_withinRange() {
        Validate.exclusiveBetween(0L, 2L, 1L);
    }

    @Test
    void testExclusiveBetweenLong_atLowerBoundary_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 0L);
            }
        });
        assertEquals("The value 0 is not in the specified exclusive range of 0 to 2", e.getMessage());
    }

    @Test
    void testExclusiveBetweenLong_atUpperBoundary_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 2L);
            }
        });
    }

    @Test
    void testExclusiveBetweenLong_withMessage_outOfRange() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 2L, "bad");
            }
        });
        assertEquals("bad", e.getMessage());
    }

    // -------------------- exclusiveBetween (double) --------------------

    @Test
    void testExclusiveBetweenDouble_withinRange() {
        Validate.exclusiveBetween(0.1, 2.1, 1.1);
    }

    @Test
    void testExclusiveBetweenDouble_nan_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, Double.NaN);
            }
        });
    }

    // -------------------- exclusiveBetween (Comparable) --------------------

    @Test
    void testExclusiveBetweenComparable_withinRange() {
        Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1));
    }

    @Test
    void testExclusiveBetweenComparable_atBoundary_throwsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0));
            }
        });
    }

    @Test
    void testExclusiveBetweenComparable_withMessage_outOfRange() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(2), "bad %s", "x");
            }
        });
        assertEquals("bad x", e.getMessage());
    }

    // -------------------- isAssignableFrom --------------------

    @Test
    void testIsAssignableFrom_valid() {
        Validate.isAssignableFrom(Number.class, Integer.class);
    }

    @Test
    void testIsAssignableFrom_invalid_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(Integer.class, String.class);
            }
        });
        assertEquals("Cannot assign a java.lang.String to a java.lang.Integer", e.getMessage());
    }

    @Test
    void testIsAssignableFrom_withMessage_invalid() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(Integer.class, String.class, "cannot assign %s", "String");
            }
        });
        assertEquals("cannot assign String", e.getMessage());
    }

    // -------------------- isInstanceOf --------------------

    @Test
    void testIsInstanceOf_valid() {
        Validate.isInstanceOf(String.class, "hello");
    }

    @Test
    void testIsInstanceOf_invalid_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, Integer.valueOf(1));
            }
        });
        assertEquals("Expected type: java.lang.String, actual: java.lang.Integer", e.getMessage());
    }

    @Test
    void testIsInstanceOf_null_throwsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, null);
            }
        });
        assertEquals("Expected type: java.lang.String, actual: null", e.getMessage());
    }

    @Test
    void testIsInstanceOf_withMessage_invalid() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, Integer.valueOf(1), "wrong type %s", "int");
            }
        });
        assertEquals("wrong type int", e.getMessage());
    }

    // -------------------- constructor --------------------

    @Test
    void testConstructor_createsInstance() {
        final Validate validate = new Validate();
        assertNotNull(validate);
    }
}
