package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class StringEscapeUtilsAgentTest {

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        StringEscapeUtils instance = new StringEscapeUtils();
        assertNotNull(instance);
    }

    // ---------------------------------------------------------------
    // Static translator fields - documented as public, static, final,
    // non-null.
    // ---------------------------------------------------------------

    @Test
    public void testTranslatorFieldsAreNonNull() {
        Object[] translators = new Object[] {
            StringEscapeUtils.ESCAPE_JAVA,
            StringEscapeUtils.ESCAPE_ECMASCRIPT,
            StringEscapeUtils.ESCAPE_JSON,
            StringEscapeUtils.ESCAPE_XML,
            StringEscapeUtils.ESCAPE_XML10,
            StringEscapeUtils.ESCAPE_XML11,
            StringEscapeUtils.ESCAPE_HTML3,
            StringEscapeUtils.ESCAPE_HTML4,
            StringEscapeUtils.ESCAPE_CSV,
            StringEscapeUtils.UNESCAPE_JAVA,
            StringEscapeUtils.UNESCAPE_ECMASCRIPT,
            StringEscapeUtils.UNESCAPE_JSON,
            StringEscapeUtils.UNESCAPE_HTML3,
            StringEscapeUtils.UNESCAPE_HTML4,
            StringEscapeUtils.UNESCAPE_XML,
            StringEscapeUtils.UNESCAPE_CSV
        };
        for (int i = 0; i < translators.length; i++) {
            assertNotNull(translators[i]);
        }
    }

    // ---------------------------------------------------------------
    // escapeCsv
    // ---------------------------------------------------------------

    @Test
    public void testEscapeCsvNull() {
        assertNull(StringEscapeUtils.escapeCsv(null));
    }

    @Test
    public void testEscapeCsvEmpty() {
        assertEquals("", StringEscapeUtils.escapeCsv(""));
    }

    @Test
    public void testEscapeCsvUnchangedWhenNoSpecialChars() {
        assertEquals("abc", StringEscapeUtils.escapeCsv("abc"));
    }

    @Test
    public void testEscapeCsvWithComma() {
        assertEquals("\"a,b\"", StringEscapeUtils.escapeCsv("a,b"));
    }

    @Test
    public void testEscapeCsvWithNewline() {
        assertEquals("\"a\nb\"", StringEscapeUtils.escapeCsv("a\nb"));
    }

    @Test
    public void testEscapeCsvWithDoubleQuote() {
        assertEquals("\"a\"\"b\"", StringEscapeUtils.escapeCsv("a\"b"));
    }

    // ---------------------------------------------------------------
    // escapeEcmaScript
    // ---------------------------------------------------------------

    @Test
    public void testEscapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.escapeEcmaScript(null));
    }

    @Test
    public void testEscapeEcmaScriptTab() {
        assertEquals("\\t", StringEscapeUtils.escapeEcmaScript("\t"));
    }

    @Test
    public void testEscapeEcmaScriptExampleFromJavadoc() {
        String input = "He didn't say, \"Stop!\"";
        String expected = "He didn\\'t say, \\\"Stop!\\\"";
        assertEquals(expected, StringEscapeUtils.escapeEcmaScript(input));
    }

    @Test
    public void testEscapeEcmaScriptForwardSlash() {
        assertEquals("\\/", StringEscapeUtils.escapeEcmaScript("/"));
    }

    // ---------------------------------------------------------------
    // escapeHtml3
    // ---------------------------------------------------------------

    @Test
    public void testEscapeHtml3Null() {
        assertNull(StringEscapeUtils.escapeHtml3(null));
    }

    @Test
    public void testEscapeHtml3Unchanged() {
        assertEquals("hello", StringEscapeUtils.escapeHtml3("hello"));
    }

    @Test
    public void testEscapeHtml3BasicEntities() {
        assertEquals("&lt;", StringEscapeUtils.escapeHtml3("<"));
        assertEquals("&gt;", StringEscapeUtils.escapeHtml3(">"));
        assertEquals("&amp;", StringEscapeUtils.escapeHtml3("&"));
        assertEquals("&quot;", StringEscapeUtils.escapeHtml3("\""));
    }

    // ---------------------------------------------------------------
    // escapeHtml4
    // ---------------------------------------------------------------

    @Test
    public void testEscapeHtml4Null() {
        assertNull(StringEscapeUtils.escapeHtml4(null));
    }

    @Test
    public void testEscapeHtml4ExampleFromJavadoc() {
        String input = "\"bread\" & \"butter\"";
        String expected = "&quot;bread&quot; &amp; &quot;butter&quot;";
        assertEquals(expected, StringEscapeUtils.escapeHtml4(input));
    }

    @Test
    public void testEscapeHtml4ApostropheNotEscaped() {
        assertEquals("it's", StringEscapeUtils.escapeHtml4("it's"));
    }

    @Test
    public void testEscapeHtml4AccentedCharacter() {
        assertEquals("caf&eacute;", StringEscapeUtils.escapeHtml4("café"));
    }

    // ---------------------------------------------------------------
    // escapeJava
    // ---------------------------------------------------------------

    @Test
    public void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    @Test
    public void testEscapeJavaTab() {
        assertEquals("\\t", StringEscapeUtils.escapeJava("\t"));
    }

    @Test
    public void testEscapeJavaExampleFromJavadoc() {
        String input = "He didn't say, \"Stop!\"";
        String expected = "He didn't say, \\\"Stop!\\\"";
        assertEquals(expected, StringEscapeUtils.escapeJava(input));
    }

    @Test
    public void testEscapeJavaForwardSlashNotEscaped() {
        assertEquals("/", StringEscapeUtils.escapeJava("/"));
    }

    @Test
    public void testEscapeJavaBackslash() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    // ---------------------------------------------------------------
    // escapeJson
    // ---------------------------------------------------------------

    @Test
    public void testEscapeJsonNull() {
        assertNull(StringEscapeUtils.escapeJson(null));
    }

    @Test
    public void testEscapeJsonForwardSlashEscaped() {
        assertEquals("\\/", StringEscapeUtils.escapeJson("/"));
    }

    @Test
    public void testEscapeJsonQuotesEscapedApostropheNot() {
        String input = "He didn't say, \"Stop!\"";
        String expected = "He didn't say, \\\"Stop!\\\"";
        assertEquals(expected, StringEscapeUtils.escapeJson(input));
    }

    @Test
    public void testEscapeJsonTab() {
        assertEquals("\\t", StringEscapeUtils.escapeJson("\t"));
    }

    // ---------------------------------------------------------------
    // escapeXml (deprecated, basic 5 entities only)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    @Test
    public void testEscapeXmlBasicEntities() {
        assertEquals("&lt;", StringEscapeUtils.escapeXml("<"));
        assertEquals("&gt;", StringEscapeUtils.escapeXml(">"));
        assertEquals("&amp;", StringEscapeUtils.escapeXml("&"));
        assertEquals("&quot;", StringEscapeUtils.escapeXml("\""));
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
    }

    @Test
    public void testEscapeXmlUnicodeAboveAsciiNotEscaped() {
        assertEquals("café", StringEscapeUtils.escapeXml("café"));
    }

    // ---------------------------------------------------------------
    // escapeXml10
    // ---------------------------------------------------------------

    @Test
    public void testEscapeXml10Null() {
        assertNull(StringEscapeUtils.escapeXml10(null));
    }

    @Test
    public void testEscapeXml10BasicEntities() {
        assertEquals("&lt;", StringEscapeUtils.escapeXml10("<"));
        assertEquals("&gt;", StringEscapeUtils.escapeXml10(">"));
        assertEquals("&amp;", StringEscapeUtils.escapeXml10("&"));
        assertEquals("&quot;", StringEscapeUtils.escapeXml10("\""));
    }

    @Test
    public void testEscapeXml10RemovesDisallowedControlCharacters() {
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0000b"));
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0001b"));
    }

    @Test
    public void testEscapeXml10PreservesTabNewlineCarriageReturn() {
        assertEquals("a\tb\nc\rd", StringEscapeUtils.escapeXml10("a\tb\nc\rd"));
    }

    @Test
    public void testEscapeXml10EscapesReservedControlRange() {
        String result = StringEscapeUtils.escapeXml10("a\u007fb");
        assertFalse(result.indexOf('\u007f') >= 0);
        assertTrue(result.indexOf('&') >= 0);
    }

    // ---------------------------------------------------------------
    // escapeXml11
    // ---------------------------------------------------------------

    @Test
    public void testEscapeXml11Null() {
        assertNull(StringEscapeUtils.escapeXml11(null));
    }

    @Test
    public void testEscapeXml11BasicEntities() {
        assertEquals("&lt;", StringEscapeUtils.escapeXml11("<"));
        assertEquals("&gt;", StringEscapeUtils.escapeXml11(">"));
        assertEquals("&amp;", StringEscapeUtils.escapeXml11("&"));
        assertEquals("&quot;", StringEscapeUtils.escapeXml11("\""));
    }

    @Test
    public void testEscapeXml11RemovesNullByte() {
        assertEquals("ab", StringEscapeUtils.escapeXml11("a\u0000b"));
    }

    @Test
    public void testEscapeXml11PreservesTabNewlineCarriageReturn() {
        assertEquals("a\tb\nc\rd", StringEscapeUtils.escapeXml11("a\tb\nc\rd"));
    }

    @Test
    public void testEscapeXml11EscapesLowControlCharacters() {
        String result = StringEscapeUtils.escapeXml11("a\u0001b");
        assertFalse(result.indexOf('\u0001') >= 0);
        assertTrue(result.indexOf('&') >= 0);
    }

    // ---------------------------------------------------------------
    // unescapeCsv
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeCsvNull() {
        assertNull(StringEscapeUtils.unescapeCsv(null));
    }

    @Test
    public void testUnescapeCsvUnchangedWhenNotQuoted() {
        assertEquals("abc", StringEscapeUtils.unescapeCsv("abc"));
    }

    @Test
    public void testUnescapeCsvUnchangedWhenQuotedWithoutSpecialChars() {
        assertEquals("\"abc\"", StringEscapeUtils.unescapeCsv("\"abc\""));
    }

    @Test
    public void testUnescapeCsvStripsQuotesAroundComma() {
        assertEquals("a,b", StringEscapeUtils.unescapeCsv("\"a,b\""));
    }

    @Test
    public void testUnescapeCsvUnescapesDoubledQuotes() {
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("\"a\"\"b\""));
    }

    // ---------------------------------------------------------------
    // unescapeEcmaScript
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.unescapeEcmaScript(null));
    }

    @Test
    public void testUnescapeEcmaScriptTabSequence() {
        assertEquals("\t", StringEscapeUtils.unescapeEcmaScript("\\t"));
    }

    @Test
    public void testUnescapeEcmaScriptDoubleBackslashBeforeNNotNewline() {
        assertEquals("\\n", StringEscapeUtils.unescapeEcmaScript("\\\\n"));
    }

    @Test
    public void testUnescapeEcmaScriptPlainTextUnchanged() {
        assertEquals("hello", StringEscapeUtils.unescapeEcmaScript("hello"));
    }

    // ---------------------------------------------------------------
    // unescapeHtml3
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeHtml3Null() {
        assertNull(StringEscapeUtils.unescapeHtml3(null));
    }

    @Test
    public void testUnescapeHtml3BasicEntities() {
        assertEquals("<", StringEscapeUtils.unescapeHtml3("&lt;"));
        assertEquals(">", StringEscapeUtils.unescapeHtml3("&gt;"));
        assertEquals("&", StringEscapeUtils.unescapeHtml3("&amp;"));
        assertEquals("\"", StringEscapeUtils.unescapeHtml3("&quot;"));
    }

    // ---------------------------------------------------------------
    // unescapeHtml4
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeHtml4Null() {
        assertNull(StringEscapeUtils.unescapeHtml4(null));
    }

    @Test
    public void testUnescapeHtml4ExampleFromJavadoc() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml4("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    public void testUnescapeHtml4UnrecognizedEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml4("&gt;&zzzz;x"));
    }

    // ---------------------------------------------------------------
    // unescapeJava
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    @Test
    public void testUnescapeJavaTabSequence() {
        assertEquals("\t", StringEscapeUtils.unescapeJava("\\t"));
    }

    @Test
    public void testUnescapeJavaDoubleBackslashBeforeNNotNewline() {
        assertEquals("\\n", StringEscapeUtils.unescapeJava("\\\\n"));
    }

    @Test
    public void testUnescapeJavaPlainTextUnchanged() {
        assertEquals("hello", StringEscapeUtils.unescapeJava("hello"));
    }

    // ---------------------------------------------------------------
    // unescapeJson
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeJsonNull() {
        assertNull(StringEscapeUtils.unescapeJson(null));
    }

    @Test
    public void testUnescapeJsonTabSequence() {
        assertEquals("\t", StringEscapeUtils.unescapeJson("\\t"));
    }

    @Test
    public void testUnescapeJsonPlainTextUnchanged() {
        assertEquals("hello", StringEscapeUtils.unescapeJson("hello"));
    }

    // ---------------------------------------------------------------
    // unescapeXml
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    public void testUnescapeXmlBasicEntities() {
        assertEquals("<", StringEscapeUtils.unescapeXml("&lt;"));
        assertEquals(">", StringEscapeUtils.unescapeXml("&gt;"));
        assertEquals("&", StringEscapeUtils.unescapeXml("&amp;"));
        assertEquals("\"", StringEscapeUtils.unescapeXml("&quot;"));
        assertEquals("'", StringEscapeUtils.unescapeXml("&apos;"));
    }

    @Test
    public void testUnescapeXmlNumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeXml("&#65;"));
    }
}
