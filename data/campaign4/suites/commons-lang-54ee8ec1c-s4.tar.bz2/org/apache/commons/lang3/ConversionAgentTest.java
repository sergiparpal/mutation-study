package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ConversionAgentTest {

    @SuppressWarnings("deprecation")
    @Test
    public void testDeprecatedConstructorIsUsable() {
        assertNotNull(new Conversion());
    }

    // ---- binaryBeMsb0ToHexDigit(boolean[]) ----

    @Test
    public void testBinaryBeMsb0ToHexDigitOneArg() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] {true, false, false, false}));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitOneArgEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitOneArgNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit((boolean[]) null);
            }
        });
    }

    // ---- binaryBeMsb0ToHexDigit(boolean[], int) ----

    @Test
    public void testBinaryBeMsb0ToHexDigitTwoArg() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] {true, false, false, false}, 0));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitTwoArgEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[0], 0);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitTwoArgNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(null, 0);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitTwoArgSrcPosOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[] {true, false, false, false}, 4);
            }
        });
    }

    // ---- binaryToByte ----

    @Test
    public void testBinaryToByteExtractsLsb0Bits() {
        boolean[] src = {true, false, true, false, false, false, false, false};
        byte result = Conversion.binaryToByte(src, 0, (byte) 0, 0, 8);
        assertEquals((byte) 5, result);
    }

    @Test
    public void testBinaryToByteMergesWithDstInit() {
        boolean[] src = {true, false, true, false};
        byte result = Conversion.binaryToByte(src, 0, (byte) 0xF0, 0, 4);
        assertEquals((byte) 0xF5, result);
    }

    @Test
    public void testBinaryToByteDstPosPlacement() {
        boolean[] src = {true};
        byte result = Conversion.binaryToByte(src, 0, (byte) 0, 7, 1);
        assertEquals((byte) 0x80, result);
    }

    @Test
    public void testBinaryToByteNullSrcThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.binaryToByte(null, 0, (byte) 0, 0, 1);
            }
        });
    }

    @Test
    public void testBinaryToByteWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToByte(new boolean[8], 0, (byte) 0, 1, 8);
            }
        });
    }

    @Test
    public void testBinaryToByteArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.binaryToByte(new boolean[4], 2, (byte) 0, 0, 4);
            }
        });
    }

    // ---- binaryToHexDigit(boolean[]) ----

    @Test
    public void testBinaryToHexDigitOneArg() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] {true, false, false, false}));
    }

    @Test
    public void testBinaryToHexDigitOneArgEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitOneArgNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigit((boolean[]) null);
            }
        });
    }

    // ---- binaryToHexDigit(boolean[], int) ----

    @Test
    public void testBinaryToHexDigitTwoArg() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] {true, false, false, false}, 0));
    }

    @Test
    public void testBinaryToHexDigitTwoArgEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigit(new boolean[0], 0);
            }
        });
    }

    // ---- binaryToHexDigitMsb0_4bits(boolean[]) ----

    @Test
    public void testBinaryToHexDigitMsb0OneArg() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] {true, false, false, false}));
    }

    @Test
    public void testBinaryToHexDigitMsb0OneArgTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[] {true, false, false});
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0OneArgTooLongThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[9]);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0OneArgEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[0]);
            }
        });
    }

    // ---- binaryToHexDigitMsb0_4bits(boolean[], int) ----

    @Test
    public void testBinaryToHexDigitMsb0TwoArg() {
        boolean[] src = {true, false, false, true, true, false, true, false};
        assertEquals('D', Conversion.binaryToHexDigitMsb0_4bits(src, 3));
    }

    @Test
    public void testBinaryToHexDigitMsb0TwoArgRemainingTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[8], 5);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0TwoArgTooLongThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[9], 0);
            }
        });
    }

    // ---- binaryToInt ----

    @Test
    public void testBinaryToIntExtractsLsb0Bits() {
        boolean[] src = new boolean[32];
        src[0] = true;
        src[2] = true;
        int result = Conversion.binaryToInt(src, 0, 0, 0, 32);
        assertEquals(5, result);
    }

    @Test
    public void testBinaryToIntNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.binaryToInt(null, 0, 0, 0, 1);
            }
        });
    }

    @Test
    public void testBinaryToIntWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToInt(new boolean[32], 0, 0, 1, 32);
            }
        });
    }

    @Test
    public void testBinaryToIntArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.binaryToInt(new boolean[4], 2, 0, 0, 4);
            }
        });
    }

    // ---- binaryToLong ----

    @Test
    public void testBinaryToLongExtractsLsb0Bits() {
        boolean[] src = new boolean[64];
        src[0] = true;
        src[2] = true;
        long result = Conversion.binaryToLong(src, 0, 0L, 0, 64);
        assertEquals(5L, result);
    }

    @Test
    public void testBinaryToLongWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToLong(new boolean[64], 0, 0L, 1, 64);
            }
        });
    }

    @Test
    public void testBinaryToLongArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.binaryToLong(new boolean[4], 2, 0L, 0, 4);
            }
        });
    }

    // ---- binaryToShort ----

    @Test
    public void testBinaryToShortExtractsLsb0Bits() {
        boolean[] src = new boolean[16];
        src[0] = true;
        src[2] = true;
        short result = Conversion.binaryToShort(src, 0, (short) 0, 0, 16);
        assertEquals((short) 5, result);
    }

    @Test
    public void testBinaryToShortWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.binaryToShort(new boolean[16], 0, (short) 0, 1, 16);
            }
        });
    }

    @Test
    public void testBinaryToShortArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.binaryToShort(new boolean[4], 2, (short) 0, 0, 4);
            }
        });
    }

    // ---- byteArrayToInt ----

    @Test
    public void testByteArrayToIntLittleEndian() {
        byte[] src = {(byte) 0x78, (byte) 0x56, (byte) 0x34, (byte) 0x12};
        assertEquals(0x12345678, Conversion.byteArrayToInt(src, 0, 0, 0, 4));
    }

    @Test
    public void testByteArrayToIntMergesWithDstInit() {
        byte[] src = {(byte) 0x05};
        assertEquals(0xF0000005, Conversion.byteArrayToInt(src, 0, 0xF0000000, 0, 1));
    }

    @Test
    public void testByteArrayToIntNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToInt(null, 0, 0, 0, 1);
            }
        });
    }

    @Test
    public void testByteArrayToIntWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToInt(new byte[4], 0, 0, 8, 4);
            }
        });
    }

    @Test
    public void testByteArrayToIntArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToInt(new byte[2], 0, 0, 0, 4);
            }
        });
    }

    // ---- byteArrayToLong ----

    @Test
    public void testByteArrayToLongLittleEndian() {
        byte[] src = {(byte) 0x88, (byte) 0x77, (byte) 0x66, (byte) 0x55,
            (byte) 0x44, (byte) 0x33, (byte) 0x22, (byte) 0x11};
        assertEquals(0x1122334455667788L, Conversion.byteArrayToLong(src, 0, 0L, 0, 8));
    }

    @Test
    public void testByteArrayToLongWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToLong(new byte[8], 0, 0L, 8, 8);
            }
        });
    }

    @Test
    public void testByteArrayToLongArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToLong(new byte[4], 0, 0L, 0, 8);
            }
        });
    }

    // ---- byteArrayToShort ----

    @Test
    public void testByteArrayToShortLittleEndian() {
        byte[] src = {(byte) 0x34, (byte) 0x12};
        assertEquals((short) 0x1234, Conversion.byteArrayToShort(src, 0, (short) 0, 0, 2));
    }

    @Test
    public void testByteArrayToShortWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToShort(new byte[2], 0, (short) 0, 8, 2);
            }
        });
    }

    @Test
    public void testByteArrayToShortArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToShort(new byte[1], 0, (short) 0, 0, 2);
            }
        });
    }

    // ---- byteArrayToUuid ----

    @Test
    public void testByteArrayToUuidRoundTrip() {
        UUID uuid = UUID.fromString("12345678-9abc-def0-1122-334455667788");
        byte[] dst = new byte[16];
        Conversion.uuidToByteArray(uuid, dst, 0, 16);
        UUID back = Conversion.byteArrayToUuid(dst, 0);
        assertEquals(uuid, back);
    }

    @Test
    public void testByteArrayToUuidWithOffsetRoundTrip() {
        UUID uuid = UUID.fromString("00000000-0000-0000-0000-000000000001");
        byte[] dst = new byte[20];
        Conversion.uuidToByteArray(uuid, dst, 3, 16);
        UUID back = Conversion.byteArrayToUuid(dst, 3);
        assertEquals(uuid, back);
    }

    @Test
    public void testByteArrayToUuidNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToUuid(null, 0);
            }
        });
    }

    @Test
    public void testByteArrayToUuidTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToUuid(new byte[10], 0);
            }
        });
    }

    @Test
    public void testByteArrayToUuidNotEnoughRemainingThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteArrayToUuid(new byte[20], 10);
            }
        });
    }

    // ---- byteToBinary ----

    @Test
    public void testByteToBinaryExtractsLsb0Bits() {
        boolean[] dst = new boolean[8];
        boolean[] result = Conversion.byteToBinary((byte) 5, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(
            new boolean[] {true, false, true, false, false, false, false, false}, result);
    }

    @Test
    public void testByteToBinaryNullDstThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.byteToBinary((byte) 1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testByteToBinaryWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteToBinary((byte) 1, 1, new boolean[8], 0, 8);
            }
        });
    }

    @Test
    public void testByteToBinaryArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.byteToBinary((byte) 1, 0, new boolean[4], 2, 4);
            }
        });
    }

    // ---- byteToHex ----

    @Test
    public void testByteToHexRoundTrip() {
        byte src = (byte) 0x3D;
        String hex = Conversion.byteToHex(src, 0, "", 0, 2);
        assertEquals(2, hex.length());
        assertTrue(hex.matches("[0-9a-f]{2}"));
        assertEquals(src, Conversion.hexToByte(hex, 0, (byte) 0, 0, 2));
    }

    @Test
    public void testByteToHexWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.byteToHex((byte) 1, 0, "", 0, 3);
            }
        });
    }

    @Test
    public void testByteToHexDstTooShortThrows() {
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.byteToHex((byte) 1, 0, "", 1, 1);
            }
        });
    }

    // ---- hexDigitMsb0ToBinary ----

    @Test
    public void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] {false, false, false, true}, Conversion.hexDigitMsb0ToBinary('1'));
    }

    @Test
    public void testHexDigitMsb0ToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexDigitMsb0ToBinary('g');
            }
        });
    }

    // ---- hexDigitMsb0ToInt ----

    @Test
    public void testHexDigitMsb0ToInt() {
        assertEquals(8, Conversion.hexDigitMsb0ToInt('1'));
    }

    @Test
    public void testHexDigitMsb0ToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexDigitMsb0ToInt('x');
            }
        });
    }

    // ---- hexDigitToBinary ----

    @Test
    public void testHexDigitToBinary() {
        assertArrayEquals(new boolean[] {true, false, false, false}, Conversion.hexDigitToBinary('1'));
    }

    @Test
    public void testHexDigitToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexDigitToBinary('z');
            }
        });
    }

    // ---- hexDigitToInt ----

    @Test
    public void testHexDigitToInt() {
        assertEquals(1, Conversion.hexDigitToInt('1'));
        assertEquals(0, Conversion.hexDigitToInt('0'));
    }

    @Test
    public void testHexDigitToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexDigitToInt('!');
            }
        });
    }

    // ---- hexToByte ----

    @Test
    public void testHexToByteWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexToByte("000", 0, (byte) 0, 0, 3);
            }
        });
    }

    @Test
    public void testHexToByteMergesWithDstInit() {
        byte result = Conversion.hexToByte("0", 0, (byte) 0xF0, 0, 1);
        assertEquals((byte) 0xF0, result);
    }

    // ---- hexToInt ----

    @Test
    public void testHexToIntWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexToInt("000000000", 0, 0, 0, 9);
            }
        });
    }

    @Test
    public void testHexToIntValidFullWidthDoesNotThrow() {
        Conversion.hexToInt("00000000", 0, 0, 0, 8);
    }

    // ---- hexToLong ----

    @Test
    public void testHexToLongWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexToLong("00000000000000000", 0, 0L, 0, 17);
            }
        });
    }

    @Test
    public void testHexToLongValidFullWidthDoesNotThrow() {
        Conversion.hexToLong("0000000000000000", 0, 0L, 0, 16);
    }

    // ---- hexToShort ----

    @Test
    public void testHexToShortWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.hexToShort("00000", 0, (short) 0, 0, 5);
            }
        });
    }

    @Test
    public void testHexToShortValidFullWidthDoesNotThrow() {
        Conversion.hexToShort("0000", 0, (short) 0, 0, 4);
    }

    // ---- intArrayToLong ----

    @Test
    public void testIntArrayToLongLittleEndian() {
        int[] src = {0x55667788, 0x11223344};
        assertEquals(0x1122334455667788L, Conversion.intArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    public void testIntArrayToLongNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.intArrayToLong(null, 0, 0L, 0, 1);
            }
        });
    }

    @Test
    public void testIntArrayToLongWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intArrayToLong(new int[2], 0, 0L, 32, 2);
            }
        });
    }

    @Test
    public void testIntArrayToLongArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.intArrayToLong(new int[1], 0, 0L, 0, 2);
            }
        });
    }

    // ---- intToBinary ----

    @Test
    public void testIntToBinaryExtractsLsb0Bits() {
        boolean[] dst = new boolean[32];
        boolean[] result = Conversion.intToBinary(5, 0, dst, 0, 32);
        assertSame(dst, result);
        assertTrue(result[0]);
        assertTrue(!result[1]);
        assertTrue(result[2]);
        for (int i = 3; i < 32; i++) {
            assertTrue(!result[i]);
        }
    }

    @Test
    public void testIntToBinaryNullDstThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.intToBinary(1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testIntToBinaryWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToBinary(1, 1, new boolean[32], 0, 32);
            }
        });
    }

    @Test
    public void testIntToBinaryArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.intToBinary(1, 0, new boolean[4], 2, 4);
            }
        });
    }

    // ---- intToByteArray ----

    @Test
    public void testIntToByteArrayLittleEndian() {
        byte[] dst = new byte[4];
        byte[] result = Conversion.intToByteArray(0x12345678, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(
            new byte[] {(byte) 0x78, (byte) 0x56, (byte) 0x34, (byte) 0x12}, result);
    }

    @Test
    public void testIntToByteArrayPartialExtraction() {
        byte[] dst = new byte[2];
        Conversion.intToByteArray(0x12345678, 8, dst, 0, 2);
        assertArrayEquals(new byte[] {(byte) 0x56, (byte) 0x34}, dst);
    }

    @Test
    public void testIntToByteArrayNullDstThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.intToByteArray(1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testIntToByteArrayWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToByteArray(1, 8, new byte[4], 0, 4);
            }
        });
    }

    @Test
    public void testIntToByteArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.intToByteArray(1, 0, new byte[2], 1, 2);
            }
        });
    }

    // ---- intToHex ----

    @Test
    public void testIntToHexRoundTrip() {
        String hex = Conversion.intToHex(0x1234ABCD, 0, "", 0, 8);
        assertEquals(8, hex.length());
        assertTrue(hex.matches("[0-9a-f]{8}"));
        assertEquals(0x1234ABCD, Conversion.hexToInt(hex, 0, 0, 0, 8));
    }

    @Test
    public void testIntToHexWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToHex(1, 0, "", 0, 9);
            }
        });
    }

    @Test
    public void testIntToHexDstTooShortThrows() {
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.intToHex(1, 0, "", 1, 1);
            }
        });
    }

    // ---- intToHexDigit ----

    @Test
    public void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('1', Conversion.intToHexDigit(1));
        assertEquals('A', Conversion.intToHexDigit(10));
        assertEquals('F', Conversion.intToHexDigit(15));
    }

    @Test
    public void testIntToHexDigitBelowRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToHexDigit(-1);
            }
        });
    }

    @Test
    public void testIntToHexDigitAboveRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToHexDigit(16);
            }
        });
    }

    // ---- intToHexDigitMsb0 ----

    @Test
    public void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0));
        assertEquals('8', Conversion.intToHexDigitMsb0(1));
        assertEquals('5', Conversion.intToHexDigitMsb0(10));
        assertEquals('1', Conversion.intToHexDigitMsb0(8));
        assertEquals('F', Conversion.intToHexDigitMsb0(15));
    }

    @Test
    public void testIntToHexDigitMsb0BelowRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToHexDigitMsb0(-1);
            }
        });
    }

    @Test
    public void testIntToHexDigitMsb0AboveRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToHexDigitMsb0(16);
            }
        });
    }

    // ---- intToShortArray ----

    @Test
    public void testIntToShortArrayLittleEndian() {
        short[] dst = new short[2];
        short[] result = Conversion.intToShortArray(0x12345678, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] {(short) 0x5678, (short) 0x1234}, result);
    }

    @Test
    public void testIntToShortArrayNullDstThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.intToShortArray(1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testIntToShortArrayWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.intToShortArray(1, 16, new short[2], 0, 2);
            }
        });
    }

    @Test
    public void testIntToShortArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.intToShortArray(1, 0, new short[1], 0, 2);
            }
        });
    }

    // ---- longToBinary ----

    @Test
    public void testLongToBinaryExtractsLsb0Bits() {
        boolean[] dst = new boolean[64];
        boolean[] result = Conversion.longToBinary(5L, 0, dst, 0, 64);
        assertSame(dst, result);
        assertTrue(result[0]);
        assertTrue(!result[1]);
        assertTrue(result[2]);
    }

    @Test
    public void testLongToBinaryWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.longToBinary(1L, 1, new boolean[64], 0, 64);
            }
        });
    }

    @Test
    public void testLongToBinaryArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.longToBinary(1L, 0, new boolean[4], 2, 4);
            }
        });
    }

    // ---- longToByteArray ----

    @Test
    public void testLongToByteArrayLittleEndian() {
        byte[] dst = new byte[8];
        Conversion.longToByteArray(0x1122334455667788L, 0, dst, 0, 8);
        assertArrayEquals(
            new byte[] {(byte) 0x88, (byte) 0x77, (byte) 0x66, (byte) 0x55,
                (byte) 0x44, (byte) 0x33, (byte) 0x22, (byte) 0x11},
            dst);
    }

    @Test
    public void testLongToByteArrayWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.longToByteArray(1L, 8, new byte[8], 0, 8);
            }
        });
    }

    @Test
    public void testLongToByteArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.longToByteArray(1L, 0, new byte[4], 0, 8);
            }
        });
    }

    // ---- longToHex ----

    @Test
    public void testLongToHexRoundTrip() {
        String hex = Conversion.longToHex(0x1234567890ABCDEFL, 0, "", 0, 16);
        assertEquals(16, hex.length());
        assertTrue(hex.matches("[0-9a-f]{16}"));
        assertEquals(0x1234567890ABCDEFL, Conversion.hexToLong(hex, 0, 0L, 0, 16));
    }

    @Test
    public void testLongToHexWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.longToHex(1L, 0, "", 0, 17);
            }
        });
    }

    // ---- longToIntArray ----

    @Test
    public void testLongToIntArrayLittleEndian() {
        int[] dst = new int[2];
        Conversion.longToIntArray(0x1122334455667788L, 0, dst, 0, 2);
        assertArrayEquals(new int[] {0x55667788, 0x11223344}, dst);
    }

    @Test
    public void testLongToIntArrayWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.longToIntArray(1L, 32, new int[2], 0, 2);
            }
        });
    }

    @Test
    public void testLongToIntArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.longToIntArray(1L, 0, new int[1], 0, 2);
            }
        });
    }

    // ---- longToShortArray ----

    @Test
    public void testLongToShortArrayLittleEndian() {
        short[] dst = new short[4];
        Conversion.longToShortArray(0x1122334455667788L, 0, dst, 0, 4);
        assertArrayEquals(
            new short[] {(short) 0x7788, (short) 0x5566, (short) 0x3344, (short) 0x1122}, dst);
    }

    @Test
    public void testLongToShortArrayWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.longToShortArray(1L, 48, new short[4], 0, 4);
            }
        });
    }

    @Test
    public void testLongToShortArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.longToShortArray(1L, 0, new short[2], 0, 4);
            }
        });
    }

    // ---- shortArrayToInt ----

    @Test
    public void testShortArrayToIntLittleEndian() {
        short[] src = {(short) 0x5678, (short) 0x1234};
        assertEquals(0x12345678, Conversion.shortArrayToInt(src, 0, 0, 0, 2));
    }

    @Test
    public void testShortArrayToIntWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.shortArrayToInt(new short[2], 0, 0, 16, 2);
            }
        });
    }

    @Test
    public void testShortArrayToIntArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.shortArrayToInt(new short[1], 0, 0, 0, 2);
            }
        });
    }

    // ---- shortArrayToLong ----

    @Test
    public void testShortArrayToLongLittleEndian() {
        short[] src = {(short) 0x7788, (short) 0x5566, (short) 0x3344, (short) 0x1122};
        assertEquals(0x1122334455667788L, Conversion.shortArrayToLong(src, 0, 0L, 0, 4));
    }

    @Test
    public void testShortArrayToLongWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.shortArrayToLong(new short[4], 0, 0L, 48, 4);
            }
        });
    }

    @Test
    public void testShortArrayToLongArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.shortArrayToLong(new short[2], 0, 0L, 0, 4);
            }
        });
    }

    // ---- shortToBinary ----

    @Test
    public void testShortToBinaryExtractsLsb0Bits() {
        boolean[] dst = new boolean[16];
        boolean[] result = Conversion.shortToBinary((short) 5, 0, dst, 0, 16);
        assertSame(dst, result);
        assertTrue(result[0]);
        assertTrue(!result[1]);
        assertTrue(result[2]);
    }

    @Test
    public void testShortToBinaryWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.shortToBinary((short) 1, 1, new boolean[16], 0, 16);
            }
        });
    }

    @Test
    public void testShortToBinaryArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.shortToBinary((short) 1, 0, new boolean[4], 2, 4);
            }
        });
    }

    // ---- shortToByteArray ----

    @Test
    public void testShortToByteArrayLittleEndian() {
        byte[] dst = new byte[2];
        Conversion.shortToByteArray((short) 0x1234, 0, dst, 0, 2);
        assertArrayEquals(new byte[] {(byte) 0x34, (byte) 0x12}, dst);
    }

    @Test
    public void testShortToByteArrayWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.shortToByteArray((short) 1, 8, new byte[2], 0, 2);
            }
        });
    }

    @Test
    public void testShortToByteArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.shortToByteArray((short) 1, 0, new byte[1], 0, 2);
            }
        });
    }

    // ---- shortToHex ----

    @Test
    public void testShortToHexRoundTrip() {
        String hex = Conversion.shortToHex((short) 0x1234, 0, "", 0, 4);
        assertEquals(4, hex.length());
        assertTrue(hex.matches("[0-9a-f]{4}"));
        assertEquals((short) 0x1234, Conversion.hexToShort(hex, 0, (short) 0, 0, 4));
    }

    @Test
    public void testShortToHexWidthOverflowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.shortToHex((short) 1, 0, "", 0, 5);
            }
        });
    }

    @Test
    public void testShortToHexDstTooShortThrows() {
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.shortToHex((short) 1, 0, "", 1, 1);
            }
        });
    }

    // ---- uuidToByteArray ----

    @Test
    public void testUuidToByteArrayReturnsSameDstReference() {
        byte[] dst = new byte[16];
        byte[] result = Conversion.uuidToByteArray(UUID.randomUUID(), dst, 0, 16);
        assertSame(dst, result);
    }

    @Test
    public void testUuidToByteArrayNullDstThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Conversion.uuidToByteArray(UUID.randomUUID(), null, 0, 16);
            }
        });
    }

    @Test
    public void testUuidToByteArrayTooManyBytesThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Conversion.uuidToByteArray(UUID.randomUUID(), new byte[20], 0, 17);
            }
        });
    }

    @Test
    public void testUuidToByteArrayArrayBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Conversion.uuidToByteArray(UUID.randomUUID(), new byte[10], 5, 10);
            }
        });
    }
}
