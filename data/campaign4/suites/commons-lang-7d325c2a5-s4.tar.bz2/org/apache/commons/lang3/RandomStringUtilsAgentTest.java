package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RandomStringUtils}, based solely on the published javadoc contract.
 */
public class RandomStringUtilsAgentTest {

    // ----------------------------------------------------------------------
    // helpers
    // ----------------------------------------------------------------------

    private static void assertAllInRange(String s, int lo, int hi) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            assertTrue(c >= lo && c <= hi, "char " + (int) c + " out of range [" + lo + "," + hi + "]");
        }
    }

    private static void assertAllLetters(String s) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)), "not a letter: " + s.charAt(i));
        }
    }

    private static void assertAllDigits(String s) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)), "not a digit: " + s.charAt(i));
        }
    }

    private static void assertAllLetterOrDigit(String s) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)), "not letter-or-digit: " + s.charAt(i));
        }
    }

    private static void assertNoSpace(String s) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(s.charAt(i) != ' ', "unexpected space character");
        }
    }

    // ----------------------------------------------------------------------
    // Singleton factory methods: secure(), secureStrong(), insecure()
    // ----------------------------------------------------------------------

    @Test
    public void testSecureIsSingleton() {
        RandomStringUtils a = RandomStringUtils.secure();
        RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testSecureStrongIsSingleton() {
        RandomStringUtils a = RandomStringUtils.secureStrong();
        RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testInsecureIsSingleton() {
        RandomStringUtils a = RandomStringUtils.insecure();
        RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testDeprecatedConstructorProducesWorkingInstance() {
        @SuppressWarnings("deprecation")
        RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertEquals(5, instance.next(5).length());
        assertEquals("", instance.next(0));
    }

    @Test
    public void testToStringNotNull() {
        RandomStringUtils instance = RandomStringUtils.secure();
        assertNotNull(instance.toString());
    }

    // ----------------------------------------------------------------------
    // next(int)
    // ----------------------------------------------------------------------

    @Test
    public void testNextCountZero() {
        assertEquals("", RandomStringUtils.secure().next(0));
    }

    @Test
    public void testNextCountPositiveLengthAtLeastCount() {
        String s = RandomStringUtils.secure().next(50);
        assertNotNull(s);
        assertTrue(s.length() >= 50);
    }

    @Test
    public void testNextCountNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1);
            }
        });
    }

    // ----------------------------------------------------------------------
    // next(int, boolean, boolean)
    // ----------------------------------------------------------------------

    @Test
    public void testNextLettersOnly() {
        String s = RandomStringUtils.secure().next(100, true, false);
        assertEquals(100, s.length());
        assertAllLetters(s);
    }

    @Test
    public void testNextNumbersOnly() {
        String s = RandomStringUtils.secure().next(100, false, true);
        assertEquals(100, s.length());
        assertAllDigits(s);
    }

    @Test
    public void testNextLettersAndNumbers() {
        String s = RandomStringUtils.secure().next(100, true, true);
        assertEquals(100, s.length());
        assertAllLetterOrDigit(s);
    }

    @Test
    public void testNextLettersNumbersCountZero() {
        assertEquals("", RandomStringUtils.secure().next(0, true, true));
    }

    @Test
    public void testNextLettersNumbersNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, true, true);
            }
        });
    }

    // ----------------------------------------------------------------------
    // next(int, char...)
    // ----------------------------------------------------------------------

    @Test
    public void testNextCharsSingleCharRepeated() {
        String s = RandomStringUtils.secure().next(5, new char[] { 'a' });
        assertEquals("aaaaa", s);
    }

    @Test
    public void testNextCharsNullAllowed() {
        String s = RandomStringUtils.secure().next(5, (char[]) null);
        assertEquals(5, s.length());
    }

    @Test
    public void testNextCharsNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, new char[] { 'a', 'b' });
            }
        });
    }

    // ----------------------------------------------------------------------
    // next(int, int, int, boolean, boolean)
    // ----------------------------------------------------------------------

    @Test
    public void testNextStartEndLettersRange() {
        String s = RandomStringUtils.secure().next(80, 'a', 'z' + 1, true, false);
        assertEquals(80, s.length());
        assertAllInRange(s, 'a', 'z');
        assertAllLetters(s);
    }

    @Test
    public void testNextStartEndCountZero() {
        assertEquals("", RandomStringUtils.secure().next(0, 'a', 'z' + 1, true, false));
    }

    @Test
    public void testNextStartEndNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, 'a', 'z' + 1, true, false);
            }
        });
    }

    // ----------------------------------------------------------------------
    // next(int, int, int, boolean, boolean, char...)
    // ----------------------------------------------------------------------

    @Test
    public void testNextStartEndCharsSingleChoice() {
        char[] chars = { 'x' };
        String s = RandomStringUtils.secure().next(6, 0, 1, false, false, chars);
        assertEquals("xxxxxx", s);
    }

    @Test
    public void testNextStartEndCharsOutOfBoundsThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        final char[] chars = { 'a' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                r.next(3, 0, 5, false, false, chars);
            }
        });
    }

    @Test
    public void testNextStartEndCharsNegativeCountThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        final char[] chars = { 'a', 'b' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, 0, 1, false, false, chars);
            }
        });
    }

    // ----------------------------------------------------------------------
    // next(int, String)
    // ----------------------------------------------------------------------

    @Test
    public void testNextWithCharString() {
        String s = RandomStringUtils.secure().next(30, "abc");
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c');
        }
    }

    @Test
    public void testNextWithNullStringAllowed() {
        String s = RandomStringUtils.secure().next(5, (String) null);
        assertEquals(5, s.length());
    }

    @Test
    public void testNextWithEmptyStringThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(0, "");
            }
        });
    }

    @Test
    public void testNextWithStringNegativeCountThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.next(-1, "abc");
            }
        });
    }

    // ----------------------------------------------------------------------
    // nextAlphabetic
    // ----------------------------------------------------------------------

    @Test
    public void testNextAlphabeticCount() {
        String s = RandomStringUtils.secure().nextAlphabetic(40);
        assertEquals(40, s.length());
        assertAllLetters(s);
    }

    @Test
    public void testNextAlphabeticCountZero() {
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0));
    }

    @Test
    public void testNextAlphabeticNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextAlphabetic(-1);
            }
        });
    }

    @Test
    public void testNextAlphabeticRange() {
        String s = RandomStringUtils.secure().nextAlphabetic(5, 6);
        assertEquals(5, s.length());
        assertAllLetters(s);
    }

    @Test
    public void testNextAlphabeticRangeEmpty() {
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0, 1));
    }

    // ----------------------------------------------------------------------
    // nextAlphanumeric
    // ----------------------------------------------------------------------

    @Test
    public void testNextAlphanumericCount() {
        String s = RandomStringUtils.secure().nextAlphanumeric(40);
        assertEquals(40, s.length());
        assertAllLetterOrDigit(s);
    }

    @Test
    public void testNextAlphanumericCountZero() {
        assertEquals("", RandomStringUtils.secure().nextAlphanumeric(0));
    }

    @Test
    public void testNextAlphanumericNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextAlphanumeric(-1);
            }
        });
    }

    @Test
    public void testNextAlphanumericRange() {
        String s = RandomStringUtils.secure().nextAlphanumeric(5, 6);
        assertEquals(5, s.length());
        assertAllLetterOrDigit(s);
    }

    // ----------------------------------------------------------------------
    // nextAscii
    // ----------------------------------------------------------------------

    @Test
    public void testNextAsciiCount() {
        String s = RandomStringUtils.secure().nextAscii(40);
        assertEquals(40, s.length());
        assertAllInRange(s, 32, 126);
    }

    @Test
    public void testNextAsciiCountZero() {
        assertEquals("", RandomStringUtils.secure().nextAscii(0));
    }

    @Test
    public void testNextAsciiNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextAscii(-1);
            }
        });
    }

    @Test
    public void testNextAsciiRange() {
        String s = RandomStringUtils.secure().nextAscii(5, 6);
        assertEquals(5, s.length());
        assertAllInRange(s, 32, 126);
    }

    // ----------------------------------------------------------------------
    // nextGraph
    // ----------------------------------------------------------------------

    @Test
    public void testNextGraphCount() {
        String s = RandomStringUtils.secure().nextGraph(40);
        assertEquals(40, s.length());
        assertAllInRange(s, 33, 126);
        assertNoSpace(s);
    }

    @Test
    public void testNextGraphCountZero() {
        assertEquals("", RandomStringUtils.secure().nextGraph(0));
    }

    @Test
    public void testNextGraphNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextGraph(-1);
            }
        });
    }

    @Test
    public void testNextGraphRange() {
        String s = RandomStringUtils.secure().nextGraph(5, 6);
        assertEquals(5, s.length());
        assertAllInRange(s, 33, 126);
    }

    // ----------------------------------------------------------------------
    // nextNumeric
    // ----------------------------------------------------------------------

    @Test
    public void testNextNumericCount() {
        String s = RandomStringUtils.secure().nextNumeric(40);
        assertEquals(40, s.length());
        assertAllDigits(s);
    }

    @Test
    public void testNextNumericCountZero() {
        assertEquals("", RandomStringUtils.secure().nextNumeric(0));
    }

    @Test
    public void testNextNumericNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextNumeric(-1);
            }
        });
    }

    @Test
    public void testNextNumericRange() {
        String s = RandomStringUtils.secure().nextNumeric(5, 6);
        assertEquals(5, s.length());
        assertAllDigits(s);
    }

    // ----------------------------------------------------------------------
    // nextPrint
    // ----------------------------------------------------------------------

    @Test
    public void testNextPrintCount() {
        String s = RandomStringUtils.secure().nextPrint(40);
        assertEquals(40, s.length());
        assertAllInRange(s, 32, 126);
    }

    @Test
    public void testNextPrintCountZero() {
        assertEquals("", RandomStringUtils.secure().nextPrint(0));
    }

    @Test
    public void testNextPrintNegativeThrows() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                r.nextPrint(-1);
            }
        });
    }

    @Test
    public void testNextPrintRange() {
        String s = RandomStringUtils.secure().nextPrint(5, 6);
        assertEquals(5, s.length());
        assertAllInRange(s, 32, 126);
    }

    // ----------------------------------------------------------------------
    // Deprecated static random(...) methods: mirror the next(...) contract.
    // ----------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomCountPositiveLengthAtLeastCount() {
        String s = RandomStringUtils.random(50);
        assertNotNull(s);
        assertTrue(s.length() >= 50);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomCountNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomLettersOnly() {
        String s = RandomStringUtils.random(100, true, false);
        assertEquals(100, s.length());
        assertAllLetters(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomNumbersOnly() {
        String s = RandomStringUtils.random(100, false, true);
        assertEquals(100, s.length());
        assertAllDigits(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomLettersNumbersNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, true, true);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomCharsSingleCharRepeated() {
        String s = RandomStringUtils.random(5, new char[] { 'a' });
        assertEquals("aaaaa", s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomCharsNullAllowed() {
        String s = RandomStringUtils.random(5, (char[]) null);
        assertEquals(5, s.length());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomCharsNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, new char[] { 'a', 'b' });
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomStartEndLettersRange() {
        String s = RandomStringUtils.random(80, 'a', 'z' + 1, true, false);
        assertEquals(80, s.length());
        assertAllInRange(s, 'a', 'z');
        assertAllLetters(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomStartEndNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 'a', 'z' + 1, true, false);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomStartEndCharsSingleChoice() {
        char[] chars = { 'x' };
        String s = RandomStringUtils.random(6, 0, 1, false, false, chars);
        assertEquals("xxxxxx", s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomStartEndCharsOutOfBoundsThrows() {
        final char[] chars = { 'a' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(3, 0, 5, false, false, chars);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomStartEndCharsNegativeCountThrows() {
        final char[] chars = { 'a', 'b' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 1, false, false, chars);
            }
        });
    }

    @Test
    public void testRandomWithCharString() {
        String s = RandomStringUtils.random(30, "abc");
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c');
        }
    }

    @Test
    public void testRandomWithNullStringAllowed() {
        String s = RandomStringUtils.random(5, (String) null);
        assertEquals(5, s.length());
    }

    @Test
    public void testRandomWithEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(0, "");
            }
        });
    }

    @Test
    public void testRandomWithStringNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, "abc");
            }
        });
    }

    // ----------------------------------------------------------------------
    // random(int, int, int, boolean, boolean, char[], Random) - the core method
    // ----------------------------------------------------------------------

    @Test
    public void testRandomCoreSingleCharDeterministic() {
        char[] chars = { 'Q' };
        String s = RandomStringUtils.random(7, 0, 1, false, false, chars, new Random(123));
        assertEquals("QQQQQQQ", s);
    }

    @Test
    public void testRandomCoreCountZero() {
        char[] chars = { 'Q' };
        assertEquals("", RandomStringUtils.random(0, 0, 1, false, false, chars, new Random(1)));
    }

    @Test
    public void testRandomCoreNegativeCountThrows() {
        final char[] chars = { 'a', 'b' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 2, false, false, chars, new Random(1));
            }
        });
    }

    @Test
    public void testRandomCoreEmptyCharsThrows() {
        final char[] chars = new char[0];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 0, false, false, chars, new Random(1));
            }
        });
    }

    @Test
    public void testRandomCoreOutOfBoundsThrows() {
        final char[] chars = { 'a', 'b' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(3, 0, 10, false, false, chars, new Random(1));
            }
        });
    }

    // ----------------------------------------------------------------------
    // Deprecated static randomAlphabetic / randomAlphanumeric / randomAscii /
    // randomGraph / randomNumeric / randomPrint methods.
    // ----------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphabeticCount() {
        String s = RandomStringUtils.randomAlphabetic(40);
        assertEquals(40, s.length());
        assertAllLetters(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphabeticCountZero() {
        assertEquals("", RandomStringUtils.randomAlphabetic(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphabeticNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphabeticRange() {
        String s = RandomStringUtils.randomAlphabetic(5, 6);
        assertEquals(5, s.length());
        assertAllLetters(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphabeticRangeEmpty() {
        assertEquals("", RandomStringUtils.randomAlphabetic(0, 1));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphanumericCount() {
        String s = RandomStringUtils.randomAlphanumeric(40);
        assertEquals(40, s.length());
        assertAllLetterOrDigit(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphanumericCountZero() {
        assertEquals("", RandomStringUtils.randomAlphanumeric(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphanumericNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphanumeric(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAlphanumericRange() {
        String s = RandomStringUtils.randomAlphanumeric(5, 6);
        assertEquals(5, s.length());
        assertAllLetterOrDigit(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAsciiCount() {
        String s = RandomStringUtils.randomAscii(40);
        assertEquals(40, s.length());
        assertAllInRange(s, 32, 126);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAsciiCountZero() {
        assertEquals("", RandomStringUtils.randomAscii(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAsciiNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAscii(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomAsciiRange() {
        String s = RandomStringUtils.randomAscii(5, 6);
        assertEquals(5, s.length());
        assertAllInRange(s, 32, 126);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomGraphCount() {
        String s = RandomStringUtils.randomGraph(40);
        assertEquals(40, s.length());
        assertAllInRange(s, 33, 126);
        assertNoSpace(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomGraphCountZero() {
        assertEquals("", RandomStringUtils.randomGraph(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomGraphNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomGraph(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomGraphRange() {
        String s = RandomStringUtils.randomGraph(5, 6);
        assertEquals(5, s.length());
        assertAllInRange(s, 33, 126);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomNumericCount() {
        String s = RandomStringUtils.randomNumeric(40);
        assertEquals(40, s.length());
        assertAllDigits(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomNumericCountZero() {
        assertEquals("", RandomStringUtils.randomNumeric(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomNumericNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomNumeric(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomNumericRange() {
        String s = RandomStringUtils.randomNumeric(5, 6);
        assertEquals(5, s.length());
        assertAllDigits(s);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomPrintCount() {
        String s = RandomStringUtils.randomPrint(40);
        assertEquals(40, s.length());
        assertAllInRange(s, 32, 126);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomPrintCountZero() {
        assertEquals("", RandomStringUtils.randomPrint(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomPrintNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomPrint(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testRandomPrintRange() {
        String s = RandomStringUtils.randomPrint(5, 6);
        assertEquals(5, s.length());
        assertAllInRange(s, 32, 126);
    }
}
