/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    private static boolean isOnlyFrom(final String str, final char[] validChars) {
        for (int i = 0; i < str.length(); i++) {
            boolean found = false;
            for (final char validChar : validChars) {
                if (str.charAt(i) == validChar) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    // ----- Singleton accessors -----

    @Test
    void testSecureSingleton() {
        assertSame(RandomStringUtils.secure(), RandomStringUtils.secure());
        assertNotNull(RandomStringUtils.secure());
    }

    @Test
    void testSecureStrongSingleton() {
        assertSame(RandomStringUtils.secureStrong(), RandomStringUtils.secureStrong());
        assertNotNull(RandomStringUtils.secureStrong());
    }

    @Test
    void testInsecureSingleton() {
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
        assertNotNull(RandomStringUtils.insecure());
    }

    @Test
    void testSingletonsDistinct() {
        assertFalse(RandomStringUtils.secure() == RandomStringUtils.insecure());
        assertFalse(RandomStringUtils.secure() == RandomStringUtils.secureStrong());
    }

    @Test
    void testDeprecatedConstructor() {
        @SuppressWarnings("deprecation")
        final RandomStringUtils instance = new RandomStringUtils();
        final String result = instance.next(5);
        assertEquals(5, result.length());
    }

    @Test
    void testToString() {
        assertTrue(RandomStringUtils.secure().toString().contains("RandomStringUtils"));
    }

    // ----- Deprecated static random(...) methods -----

    @Test
    void testRandomZeroLength() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(0);
        assertEquals("", result);
    }

    @Test
    void testRandomNegativeLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    void testRandomCountLength() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(50);
        assertEquals(50, result.length());
    }

    @Test
    void testRandomLettersOnly() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(200, true, false);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetter(result.charAt(i)), "Not a letter: " + result.charAt(i));
        }
    }

    @Test
    void testRandomNumbersOnly() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(200, false, true);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isDigit(result.charAt(i)), "Not a digit: " + result.charAt(i));
        }
    }

    @Test
    void testRandomWithCharsArray() {
        final char[] chars = { 'x', 'y', 'z' };
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(100, chars);
        assertEquals(100, result.length());
        assertTrue(isOnlyFrom(result, chars));
    }

    @Test
    void testRandomWithNullCharsArray() {
        final char[] chars = null;
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(10, chars);
        assertEquals(10, result.length());
    }

    @Test
    void testRandomWithEmptyCharsArrayThrows() {
        final char[] empty = {};
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(5, empty);
            }
        });
    }

    @Test
    void testRandomStartEndLettersNumbers() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(100, 'a', 'f' + 1, true, false);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 'a' && c <= 'f', "Char out of range: " + c);
        }
    }

    @Test
    void testRandomFullSignatureWithCharsArray() {
        final char[] chars = { 'a', 'b', 'c', 'd' };
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(50, 0, chars.length, false, false, chars);
        assertEquals(50, result.length());
        assertTrue(isOnlyFrom(result, chars));
    }

    @Test
    void testRandomWithString() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(20, "ab");
        assertEquals(20, result.length());
        assertTrue(isOnlyFrom(result, new char[] { 'a', 'b' }));
    }

    @Test
    void testRandomWithNullString() {
        final String nullChars = null;
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.random(10, nullChars);
        assertEquals(10, result.length());
    }

    // ----- random(count, start, end, letters, numbers, chars, random) edge/error cases -----

    @Test
    void testRandomCountLessThanZeroThrows() {
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(-5, 0, 0, false, false, null, random);
            }
        });
    }

    @Test
    void testRandomEndLessOrEqualStartThrows() {
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(5, 10, 10, false, false, null, random);
            }
        });
    }

    @Test
    void testRandomNegativeStartThrows() {
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(5, -1, 10, false, false, null, random);
            }
        });
    }

    @Test
    void testRandomStartBeyondCharsLengthThrows() {
        final char[] chars = { 'a', 'b' };
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(5, 2, 3, false, false, chars, random);
            }
        });
    }

    @Test
    void testRandomEndBeyondCharsLengthThrows() {
        final char[] chars = { 'a', 'b' };
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(5, 0, 5, false, false, chars, random);
            }
        });
    }

    @Test
    void testRandomNoLettersInRangeThrows() {
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                // code points 0-4 are control characters: no letters present
                RandomStringUtils.random(5, 0, 5, true, false, null, random);
            }
        });
    }

    @Test
    void testRandomNoDigitsInRangeThrows() {
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                // code points 0-4 are control characters: no digits present
                RandomStringUtils.random(5, 0, 5, false, true, null, random);
            }
        });
    }

    @Test
    void testRandomCharsArrayHasNoMatchingLettersThrows() {
        final char[] digitsOnly = { '0', '1', '2' };
        final Random random = new Random();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.random(5, 0, digitsOnly.length, true, false, digitsOnly, random);
            }
        });
    }

    @Test
    void testRandomZeroCountReturnsEmptyEvenWithBadRange() {
        final Random random = new Random();
        final String result = RandomStringUtils.random(0, 10, 5, false, false, null, random);
        assertEquals("", result);
    }

    @Test
    void testRandomAllAlphanumericFastPath() {
        final Random random = new Random();
        final String result = RandomStringUtils.random(500, 0, 0, true, true, null, random);
        assertEquals(500, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(Character.isLetterOrDigit(c), "Not alphanumeric: " + c);
        }
    }

    // ----- Deprecated static convenience methods -----

    @Test
    void testRandomAlphabetic() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.randomAlphabetic(100);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetter(result.charAt(i)));
        }
    }

    @Test
    void testRandomAlphabeticRange() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.randomAlphabetic(5, 6);
        assertEquals(5, result.length());
    }

    @Test
    void testRandomAlphabeticRangeEqualBoundsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                RandomStringUtils.randomAlphabetic(5, 3);
            }
        });
    }

    @Test
    void testRandomAlphanumeric() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.randomAlphanumeric(100);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetterOrDigit(result.charAt(i)));
        }
    }

    @Test
    void testRandomAlphanumericRange() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.randomAlphanumeric(3, 4);
        assertEquals(3, result.length());
    }

    @Test
    void testRandomAscii() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.randomAscii(100);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char out of ASCII printable range: " + (int) c);
        }
    }

    @Test
    void testRandomAsciiRange() {
        @SuppressWarnings("deprecation")
        final String result = RandomStringUtils.randomAscii(2, 3);
        assertEquals(2, result.length());
    }

    @Test
    void testRandomGraph() {
        final String result = RandomStringUtils.randomGraph(100);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 33 && c < 126, "Char out of graph range: " + (int) c);
        }
    }

    @Test
    void testRandomGraphRange() {
        final String result = RandomStringUtils.randomGraph(4, 5);
        assertEquals(4, result.length());
    }

    @Test
    void testRandomNumeric() {
        final String result = RandomStringUtils.randomNumeric(100);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isDigit(result.charAt(i)));
        }
    }

    @Test
    void testRandomNumericRange() {
        final String result = RandomStringUtils.randomNumeric(6, 7);
        assertEquals(6, result.length());
    }

    @Test
    void testRandomPrint() {
        final String result = RandomStringUtils.randomPrint(100);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 32 && c < 126, "Char out of print range: " + (int) c);
        }
    }

    @Test
    void testRandomPrintRange() {
        final String result = RandomStringUtils.randomPrint(1, 2);
        assertEquals(1, result.length());
    }

    // ----- Instance next(...) methods -----

    @Test
    void testNextZeroLength() {
        final String result = RandomStringUtils.secure().next(0);
        assertEquals("", result);
    }

    @Test
    void testNextNegativeLengthThrows() {
        final RandomStringUtils instance = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                instance.next(-3);
            }
        });
    }

    @Test
    void testNextCountOnly() {
        final String result = RandomStringUtils.secure().next(42);
        assertEquals(42, result.length());
    }

    @Test
    void testNextWithLettersNumbers() {
        final String result = RandomStringUtils.insecure().next(50, true, false);
        assertEquals(50, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetter(result.charAt(i)));
        }
    }

    @Test
    void testNextWithCharsVarargs() {
        final String result = RandomStringUtils.secureStrong().next(30, 'q', 'r', 's');
        assertEquals(30, result.length());
        assertTrue(isOnlyFrom(result, new char[] { 'q', 'r', 's' }));
    }

    @Test
    void testNextWithNullCharsVarargs() {
        final char[] chars = null;
        final String result = RandomStringUtils.secure().next(7, chars);
        assertEquals(7, result.length());
    }

    @Test
    void testNextWithStartEndLettersNumbers() {
        final String result = RandomStringUtils.insecure().next(60, 'a', 'c' + 1, true, false);
        assertEquals(60, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 'a' && c <= 'c');
        }
    }

    @Test
    void testNextWithFullSignature() {
        final char[] chars = { 'm', 'n' };
        final String result = RandomStringUtils.secure().next(25, 0, chars.length, false, false, chars);
        assertEquals(25, result.length());
        assertTrue(isOnlyFrom(result, chars));
    }

    @Test
    void testNextWithString() {
        final String result = RandomStringUtils.secure().next(15, "xy");
        assertEquals(15, result.length());
        assertTrue(isOnlyFrom(result, new char[] { 'x', 'y' }));
    }

    @Test
    void testNextWithNullString() {
        final String nullChars = null;
        final String result = RandomStringUtils.secure().next(9, nullChars);
        assertEquals(9, result.length());
    }

    @Test
    void testNextAlphabetic() {
        final String result = RandomStringUtils.secure().nextAlphabetic(40);
        assertEquals(40, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetter(result.charAt(i)));
        }
    }

    @Test
    void testNextAlphabeticRangeEqualBounds() {
        final String result = RandomStringUtils.secure().nextAlphabetic(5, 5);
        assertEquals(5, result.length());
    }

    @Test
    void testNextAlphabeticRangeInvertedThrows() {
        final RandomStringUtils instance = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                instance.nextAlphabetic(10, 5);
            }
        });
    }

    @Test
    void testNextAlphanumeric() {
        final String result = RandomStringUtils.secure().nextAlphanumeric(40);
        assertEquals(40, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetterOrDigit(result.charAt(i)));
        }
    }

    @Test
    void testNextAlphanumericRange() {
        final String result = RandomStringUtils.secure().nextAlphanumeric(3, 4);
        assertEquals(3, result.length());
    }

    @Test
    void testNextAscii() {
        final String result = RandomStringUtils.secure().nextAscii(40);
        assertEquals(40, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testNextAsciiRange() {
        final String result = RandomStringUtils.secure().nextAscii(2, 3);
        assertEquals(2, result.length());
    }

    @Test
    void testNextGraph() {
        final String result = RandomStringUtils.secure().nextGraph(40);
        assertEquals(40, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 33 && c < 126);
        }
    }

    @Test
    void testNextGraphRange() {
        final String result = RandomStringUtils.secure().nextGraph(4, 5);
        assertEquals(4, result.length());
    }

    @Test
    void testNextNumeric() {
        final String result = RandomStringUtils.secure().nextNumeric(40);
        assertEquals(40, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isDigit(result.charAt(i)));
        }
    }

    @Test
    void testNextNumericRange() {
        final String result = RandomStringUtils.secure().nextNumeric(6, 7);
        assertEquals(6, result.length());
    }

    @Test
    void testNextPrint() {
        final String result = RandomStringUtils.secure().nextPrint(40);
        assertEquals(40, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 32 && c < 126);
        }
    }

    @Test
    void testNextPrintRange() {
        final String result = RandomStringUtils.secure().nextPrint(1, 2);
        assertEquals(1, result.length());
    }
}
