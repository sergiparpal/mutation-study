/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private static final char CR = '\r';
    private static final char LF = '\n';

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialState() throws Exception {
        try (ExtendedBufferedReader br = create("abc")) {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals(0, br.getLineNumber());
            assertEquals(0, br.getBytesRead());
        }
    }

    @Test
    void testReadSingleCharUpdatesPositionAndLastChar() throws Exception {
        try (ExtendedBufferedReader br = create("ab")) {
            assertEquals('a', br.read());
            assertEquals('a', br.getLastChar());
            assertEquals(1, br.getPosition());
            // Non-EOL char read: line counter shows the "current" line.
            assertEquals(1, br.getLineNumber());
            assertEquals('b', br.read());
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
        }
    }

    @Test
    void testReadAtEofReturnsEofAndSetsLastChar() throws Exception {
        try (ExtendedBufferedReader br = create("")) {
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
            // position is incremented unconditionally by read(), even at EOF.
            assertEquals(1, br.getPosition());
            assertEquals(EOF, br.read());
            assertEquals(2, br.getPosition());
        }
    }

    @Test
    void testPeekDoesNotConsume() throws Exception {
        try (ExtendedBufferedReader br = create("xy")) {
            assertEquals('x', br.peek());
            assertEquals('x', br.peek());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('x', br.read());
            assertEquals('y', br.peek());
            assertEquals('x', br.getLastChar());
            assertEquals(1, br.getPosition());
        }
    }

    @Test
    void testPeekAtEof() throws Exception {
        try (ExtendedBufferedReader br = create("")) {
            assertEquals(EOF, br.peek());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
        }
    }

    @Test
    void testReadBufferZeroLengthDoesNotConsume() throws Exception {
        try (ExtendedBufferedReader br = create("abc")) {
            final char[] buf = new char[5];
            assertEquals(0, br.read(buf, 0, 0));
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
        }
    }

    @Test
    void testReadBufferAtEofReturnsEofAndSetsLastChar() throws Exception {
        try (ExtendedBufferedReader br = create("")) {
            final char[] buf = new char[5];
            assertEquals(EOF, br.read(buf, 0, 5));
            assertEquals(EOF, br.getLastChar());
        }
    }

    @Test
    void testReadBufferPartialAtEndOfStream() throws Exception {
        try (ExtendedBufferedReader br = create("ab")) {
            final char[] buf = new char[5];
            assertEquals(2, br.read(buf, 0, 5));
            assertEquals('a', buf[0]);
            assertEquals('b', buf[1]);
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
            assertEquals(EOF, br.read(buf, 0, 5));
        }
    }

    @Test
    void testReadBufferNegativeOffsetThrows() throws Exception {
        try (ExtendedBufferedReader br = create("abc")) {
            assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read(new char[3], -1, 1);
                }
            });
        }
    }

    @Test
    void testReadLineEmptyInputReturnsNull() throws Exception {
        try (ExtendedBufferedReader br = create("")) {
            assertNull(br.readLine());
            assertEquals(0, br.getLineNumber());
        }
    }

    @Test
    void testReadLineNoTrailingTerminator() throws Exception {
        try (ExtendedBufferedReader br = create("end")) {
            assertEquals("end", br.readLine());
            assertEquals(EOF, br.getLastChar());
            assertNull(br.readLine());
        }
    }

    @Test
    void testReadLineCrLfTreatedAsSingleTerminator() throws Exception {
        try (ExtendedBufferedReader br = create("foo\r\nbar")) {
            assertEquals("foo", br.readLine());
            assertEquals(1, br.getLineNumber());
            assertEquals("bar", br.readLine());
            assertNull(br.readLine());
        }
    }

    @Test
    void testReadLineBlankLines() throws Exception {
        try (ExtendedBufferedReader br = create("\n\n")) {
            assertEquals("", br.readLine());
            assertEquals(1, br.getLineNumber());
            assertEquals("", br.readLine());
            assertEquals(2, br.getLineNumber());
            assertNull(br.readLine());
        }
    }

    @Test
    void testSplitCrLfAcrossBufferReadsNotDoubleCounted() throws Exception {
        try (ExtendedBufferedReader br = create("1\r\n2")) {
            final char[] buf = new char[2];
            assertEquals(2, br.read(buf, 0, 2)); // reads "1\r"
            assertEquals(CR, br.getLastChar());
            assertEquals(1, br.getLineNumber());
            assertEquals(2, br.read(buf, 0, 2)); // reads "\n2"
            assertEquals('2', br.getLastChar());
            // One full line was terminated (CRLF counted once); now mid line 2.
            assertEquals(2, br.getLineNumber());
        }
    }

    @Test
    void testMarkAndResetRestoreState() throws Exception {
        try (ExtendedBufferedReader br = create("1\r\n2\r\n3")) {
            assertEquals('1', br.read());
            assertEquals(CR, br.read());
            final long positionAtMark = br.getPosition();
            final long lineNumberAtMark = br.getLineNumber();
            final int lastCharAtMark = br.getLastChar();
            br.mark(10);
            assertEquals(LF, br.read());
            assertEquals('2', br.read());
            br.reset();
            assertEquals(positionAtMark, br.getPosition());
            assertEquals(lineNumberAtMark, br.getLineNumber());
            assertEquals(lastCharAtMark, br.getLastChar());
            // Stream position itself must also have rewound.
            assertEquals(LF, br.read());
        }
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws Exception {
        final ExtendedBufferedReader br = create("abc");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testBytesReadDisabledByDefaultConstructor() throws Exception {
        try (ExtendedBufferedReader br = create("abc")) {
            br.read();
            br.read();
            br.read();
            assertEquals(0, br.getBytesRead());
        }
    }

    @Test
    void testBytesReadTrackingDisabledWhenFlagFalse() throws Exception {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false)) {
            final char[] buf = new char[3];
            br.read(buf, 0, 3);
            assertEquals(0, br.getBytesRead());
        }
    }

    @Test
    void testBytesReadTrackingAsciiSingleByteCharset() throws Exception {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true)) {
            final char[] buf = new char[3];
            assertEquals(3, br.read(buf, 0, 3));
            assertEquals(3, br.getBytesRead());
        }
    }

    @Test
    void testBytesReadTrackingUtf16FixedWidthWithoutBomDuplication() throws Exception {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("AB"), StandardCharsets.UTF_16, true)) {
            assertEquals('A', br.read());
            assertEquals(2, br.getBytesRead());
            assertEquals('B', br.read());
            // BOM must only be subtracted once per char, not accumulated.
            assertEquals(4, br.getBytesRead());
        }
    }

    @Test
    void testBytesReadTrackingSupplementaryCharacterViaBuffer() throws Exception {
        final String input = "😀"; // U+1F600 GRINNING FACE
        final char[] buffer = new char[input.length()];
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true)) {
            assertEquals(input.length(), br.read(buffer, 0, buffer.length));
            assertArrayEquals(input.toCharArray(), buffer);
            assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        }
    }

    @Test
    void testBytesReadTrackingLoneLowSurrogateThrows() throws Exception {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uDC00"), StandardCharsets.UTF_8, true)) {
            assertThrows(CharacterCodingException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read();
                }
            });
        }
    }

    @Test
    void testGetLineNumberAtStartIsZero() throws Exception {
        try (ExtendedBufferedReader br = create("abc")) {
            assertEquals(0, br.getLineNumber());
        }
    }
}
