package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for the deprecated
 * {@link org.apache.commons.lang3.text.ExtendedMessageFormat}, based solely on
 * the documented contract in the generated javadoc (api/).
 */
@SuppressWarnings("deprecation")
public class ExtendedMessageFormatAgentTest {

    /** Simple {@link FormatFactory} that always hands back an upper-casing {@link Format}. */
    private static class UpperCaseFormatFactory implements FormatFactory {
        public Format getFormat(String name, String arguments, Locale locale) {
            return new UpperCaseFormat();
        }
    }

    /** Format that upper-cases whatever String representation it is given. */
    private static class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
            return toAppendTo;
        }

        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    private static Map<String, FormatFactory> upperCaseRegistry() {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        return registry;
    }

    // --- constructor(pattern) -------------------------------------------------

    @Test
    public void testConstructorPatternOnly_literalText() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Simple text, no arguments.");
        assertEquals("Simple text, no arguments.", emf.format(new Object[0]));
    }

    @Test
    public void testConstructorPatternOnly_argumentSubstitution() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructorPatternOnly_reordersArgumentsByIndex() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{1} {0}");
        assertEquals("b a", emf.format(new Object[] {"a", "b"}));
    }

    @Test
    public void testConstructorPatternOnly_badPatternThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    public void testConstructorPatternOnly_unknownFormatTypeThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0,bogus}");
            }
        });
    }

    // --- constructor(pattern, locale) -----------------------------------------

    @Test
    public void testConstructorWithLocale_usesGivenLocaleForNumberFormatting() {
        ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number}", Locale.US);
        ExtendedMessageFormat germany = new ExtendedMessageFormat("{0,number}", Locale.GERMANY);

        assertEquals("1,234.5", us.format(new Object[] {Double.valueOf(1234.5d)}));
        assertEquals("1.234,5", germany.format(new Object[] {Double.valueOf(1234.5d)}));
    }

    @Test
    public void testConstructorWithLocale_badPatternThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new ExtendedMessageFormat("{0", Locale.US);
            }
        });
    }

    // --- constructor(pattern, locale, registry) --------------------------------

    @Test
    public void testConstructorWithLocaleAndRegistry_usesRegisteredFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperCaseRegistry());
        assertEquals("HELLO", emf.format(new Object[] {"hello"}));
    }

    @Test
    public void testConstructorWithLocaleAndRegistry_nullRegistryBehavesLikeNoRegistry() {
        Map<String, FormatFactory> nullRegistry = null;
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0}", Locale.US, nullRegistry);
        assertEquals("Value: 5", emf.format(new Object[] {Integer.valueOf(5)}));
    }

    // --- constructor(pattern, registry) -----------------------------------------

    @Test
    public void testConstructorWithRegistry_defaultLocaleUsesRegisteredFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperCaseRegistry());
        assertEquals("HELLO", emf.format(new Object[] {"hello"}));
    }

    @Test
    public void testConstructorWithRegistry_nullRegistryBehavesLikeNoRegistry() {
        Map<String, FormatFactory> nullRegistry = null;
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0}", nullRegistry);
        assertEquals("Value: 5", emf.format(new Object[] {Integer.valueOf(5)}));
    }

    // --- applyPattern ------------------------------------------------------------

    @Test
    public void testApplyPattern_changesPatternAndFormattingBehavior() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Initial {0}");
        emf.applyPattern("Updated {0}");
        assertEquals("Updated {0}", emf.toPattern());
        assertEquals("Updated X", emf.format(new Object[] {"X"}));
    }

    @Test
    public void testApplyPattern_badPatternThrowsIllegalArgumentException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Initial {0}");
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                emf.applyPattern("{0");
            }
        });
    }

    // --- toPattern -----------------------------------------------------------------

    @Test
    public void testToPattern_roundTripsSimplePattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    // --- disabled mutator methods ---------------------------------------------------

    @Test
    public void testSetFormat_alwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormat(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    public void testSetFormatByArgumentIndex_alwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    public void testSetFormats_alwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormats(new Format[] {java.text.NumberFormat.getInstance()});
            }
        });
    }

    @Test
    public void testSetFormatsByArgumentIndex_alwaysThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {java.text.NumberFormat.getInstance()});
            }
        });
    }

    // --- equals / hashCode -----------------------------------------------------------

    @Test
    public void testEquals_isReflexive() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", Locale.US);
        assertTrue(emf.equals(emf));
    }

    @Test
    public void testEquals_trueForSamePatternAndLocale() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("Hi {0}", Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEquals_falseForDifferentPattern() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("Bye {0}", Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEquals_falseForNullAndForDifferentType() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}", Locale.US);
        assertFalse(a.equals(null));
        assertFalse(a.equals("Hi {0}"));
    }

    // --- inherited Cloneable / Serializable markers ---------------------------------

    @Test
    public void testImplementsCloneableAndSerializable() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}");
        assertTrue(emf instanceof Cloneable);
        assertTrue(emf instanceof java.io.Serializable);
    }

    @Test
    public void testClone_producesDistinctButEqualInstance() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", Locale.US);
        Object clone = emf.clone();
        assertNotNull(clone);
        assertNotSame(emf, clone);
        assertTrue(clone instanceof ExtendedMessageFormat);
        ExtendedMessageFormat clonedEmf = (ExtendedMessageFormat) clone;
        assertEquals(emf.toPattern(), clonedEmf.toPattern());
        assertEquals(emf, clonedEmf);
    }

    // --- choice sub-format pass-through (inherited MessageFormat behavior) -----------

    @Test
    public void testChoiceSubformat_isSupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#no files|1#one file|1<{0,number} files}");
        assertEquals("no files", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one file", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("2 files", emf.format(new Object[] {Integer.valueOf(2)}));
    }
}
