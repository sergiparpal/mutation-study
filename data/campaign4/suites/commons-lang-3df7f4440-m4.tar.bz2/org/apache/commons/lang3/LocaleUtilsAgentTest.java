/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    @Test
    void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertTrue(list.size() > 0);
        assertTrue(list.contains(Locale.US));
        // Confirm sorted by toString().
        for (int i = 1; i < list.size(); i++) {
            assertTrue(list.get(i - 1).toString().compareTo(list.get(i).toString()) <= 0);
        }
        // Same reference returned on repeated calls.
        assertSame(list, LocaleUtils.availableLocaleList());
    }

    @Test
    void testAvailableLocaleListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        try {
            list.add(Locale.CANADA);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertTrue(set.size() > 0);
        assertTrue(set.contains(Locale.US));
        assertSame(set, LocaleUtils.availableLocaleSet());
        try {
            set.add(new Locale("zz", "ZZ"));
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    void testCountriesByLanguageNull() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguageEn() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertNotNull(list);
        assertTrue(list.size() > 0);
        for (final Locale locale : list) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
        // Cached: same list instance on second call.
        assertSame(list, LocaleUtils.countriesByLanguage("en"));
        try {
            list.add(Locale.US);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    void testCountriesByLanguageUnknown() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryNull() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryUs() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        assertTrue(list.size() > 0);
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
        assertSame(list, LocaleUtils.languagesByCountry("US"));
    }

    @Test
    void testLanguagesByCountryUnknown() {
        final List<Locale> list = LocaleUtils.languagesByCountry("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("zz", "ZZ", "zzzz")));
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("", "")));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("fr", "CA")));
    }

    @Test
    void testLocaleLookupListSingleArgNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListSingleArgRoot() {
        final Locale root = new Locale("", "");
        final List<Locale> list = LocaleUtils.localeLookupList(root);
        assertEquals(1, list.size());
        assertEquals(root, list.get(0));
        try {
            list.add(Locale.US);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    void testLocaleLookupListSingleArgVariant() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    void testLocaleLookupListTwoArgsNullLocale() {
        final List<Locale> list = LocaleUtils.localeLookupList(null, Locale.ENGLISH);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListTwoArgsWithDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final Locale defaultLocale = new Locale("en");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(new Locale("en"), list.get(3));
    }

    @Test
    void testLocaleLookupListTwoArgsDefaultAlreadyPresent() {
        final Locale locale = new Locale("fr");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, new Locale("fr"));
        assertEquals(1, list.size());
        assertEquals(new Locale("fr"), list.get(0));
    }

    @Test
    void testToLocaleFromLocale() {
        assertSame(Locale.CANADA, LocaleUtils.toLocale(Locale.CANADA));
        final Locale result = LocaleUtils.toLocale((Locale) null);
        assertEquals(Locale.getDefault(), result);
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        final Locale result = LocaleUtils.toLocale("");
        assertEquals("", result.getLanguage());
        assertEquals("", result.getCountry());
        assertEquals("", result.getVariant());
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        final Locale result = LocaleUtils.toLocale("en");
        assertEquals("en", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void testToLocaleStringLanguageCountryUnderscore() {
        final Locale result = LocaleUtils.toLocale("en_GB");
        assertEquals("en", result.getLanguage());
        assertEquals("GB", result.getCountry());
        assertEquals("", result.getVariant());
    }

    @Test
    void testToLocaleStringLanguageCountryDash() {
        final Locale result = LocaleUtils.toLocale("en-GB");
        assertEquals("en", result.getLanguage());
        assertEquals("GB", result.getCountry());
    }

    @Test
    void testToLocaleStringNumericArea() {
        final Locale result = LocaleUtils.toLocale("en_001");
        assertEquals("en", result.getLanguage());
        assertEquals("001", result.getCountry());
    }

    @Test
    void testToLocaleStringWithVariant() {
        final Locale result = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", result.getLanguage());
        assertEquals("GB", result.getCountry());
        assertEquals("xxx", result.getVariant());
    }

    @Test
    void testToLocaleStringCountryOnlyIso() {
        final Locale result = LocaleUtils.toLocale("US");
        assertEquals("", result.getLanguage());
        assertEquals("US", result.getCountry());
    }

    @Test
    void testToLocaleStringUnderscorePrefixCountryOnly() {
        final Locale result = LocaleUtils.toLocale("_GB");
        assertEquals("", result.getLanguage());
        assertEquals("GB", result.getCountry());
    }

    @Test
    void testToLocaleStringUnderscorePrefixWithVariant() {
        final Locale result = LocaleUtils.toLocale("_GB_P");
        assertEquals("", result.getLanguage());
        assertEquals("GB", result.getCountry());
        assertEquals("P", result.getVariant());
    }

    @Test
    void testToLocaleStringTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("e");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscoreTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscoreLowerCaseCountry() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscoreFourCharsNotFive() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBx");
            }
        });
    }

    @Test
    void testToLocaleStringMixedCaseLanguage() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("Us");
            }
        });
    }

    @Test
    void testToLocaleStringShortInvalidCountry() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_G");
            }
        });
    }

    @Test
    void testToLocaleStringEmptyVariantSegment() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_GB_");
            }
        });
    }

    @Test
    void testToLocaleStringTwoLetterLanguageLowerCase() {
        final Locale result = LocaleUtils.toLocale("zz");
        assertEquals("zz", result.getLanguage());
        assertEquals("", result.getCountry());
    }

    @Test
    void testToLocaleStringThreeLetterLanguage() {
        final Locale result = LocaleUtils.toLocale("zzz");
        assertEquals("zzz", result.getLanguage());
    }

    @Test
    void testConstructorIsPublicAndDeprecated() throws Exception {
        final LocaleUtils instance = new LocaleUtils();
        assertNotNull(instance);
        final java.lang.reflect.Constructor<LocaleUtils> ctor = LocaleUtils.class.getDeclaredConstructor();
        assertTrue(java.lang.reflect.Modifier.isPublic(ctor.getModifiers()));
        assertTrue(ctor.isAnnotationPresent(Deprecated.class));
    }

    /**
     * Minimal local stand-in for {@code org.junit.jupiter.api.function.Executable}
     * compatible with the {@code --release 8} build (no lambdas used elsewhere).
     */
    private interface Executable extends org.junit.jupiter.api.function.Executable {
        // marker
    }
}
