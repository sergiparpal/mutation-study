package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}, based solely on its documented contract.
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static FastDatePrinter newPrinter(String pattern, TimeZone tz, Locale locale) {
        return new FastDatePrinter(pattern, tz, locale);
    }

    private static FastDatePrinter newPrinter(String pattern) {
        return newPrinter(pattern, UTC, Locale.US);
    }

    // ---------------------------------------------------------------
    // Constructor / basic getters
    // ---------------------------------------------------------------

    @Test
    public void testConstructorStoresPatternTimeZoneAndLocale() {
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        Locale locale = Locale.FRANCE;
        FastDatePrinter printer = newPrinter("yyyy-MM-dd", tz, locale);

        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(tz, printer.getTimeZone());
        assertEquals(locale, printer.getLocale());
    }

    @Test
    public void testConstructorNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                newPrinter(null, UTC, Locale.US);
            }
        });
    }

    @Test
    public void testConstructorNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                newPrinter("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    public void testConstructorNullLocaleThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                newPrinter("yyyy", UTC, null);
            }
        });
    }

    @Test
    public void testConstructorWithInvalidPatternEventuallyThrowsIllegalArgumentException() {
        // An unterminated quoted literal is not a valid SimpleDateFormat-compatible pattern.
        // parsePattern() documents that invalid patterns throw IllegalArgumentException; a
        // FastDatePrinter must parse its pattern at some point before (or while) it is used.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                FastDatePrinter bad = newPrinter("yyyy'unterminated", UTC, Locale.US);
                bad.format(0L);
            }
        });
    }

    @Test
    public void testStyleConstantsHaveDocumentedValues() {
        assertEquals(0, FastDatePrinter.FULL);
        assertEquals(1, FastDatePrinter.LONG);
        assertEquals(2, FastDatePrinter.MEDIUM);
        assertEquals(3, FastDatePrinter.SHORT);
    }

    // ---------------------------------------------------------------
    // format(long) and friends
    // ---------------------------------------------------------------

    @Test
    public void testFormatLongAtEpoch() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss");
        assertEquals("1970-01-01T00:00:00", printer.format(0L));
    }

    @Test
    public void testFormatLongBeforeEpoch() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        // One day before the epoch.
        assertEquals("1969-12-31", printer.format(-86400000L));
    }

    @Test
    public void testFormatLongMatchesSimpleDateFormatForOrdinaryPatterns() {
        String[] patterns = {
            "yyyy-MM-dd HH:mm:ss.SSS",
            "EEEE, MMMM dd yyyy",
            "h:mm a",
            "D",
            "w",
            "k:m:s",
            "K:m a",
            "G yyyy"
        };
        long[] instants = {
            0L,
            1000000000000L,
            -1000000000000L,
            1700000000000L
        };
        for (int p = 0; p < patterns.length; p++) {
            String pattern = patterns[p];
            FastDatePrinter printer = newPrinter(pattern);
            SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
            sdf.setTimeZone(UTC);
            for (int i = 0; i < instants.length; i++) {
                long millis = instants[i];
                assertEquals(sdf.format(new Date(millis)), printer.format(millis),
                        "pattern=" + pattern + " millis=" + millis);
            }
        }
    }

    @Test
    public void testFormatLongIntoStringBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format(0L, buf);
        assertSame(buf, result);
        assertEquals("prefix-1970-01-01", result.toString());
    }

    @Test
    public void testFormatLongIntoAppendableStringBuilder() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        StringBuilder sb = new StringBuilder("prefix-");
        StringBuilder result = printer.format(0L, sb);
        assertSame(sb, result);
        assertEquals("prefix-1970-01-01", result.toString());
    }

    // ---------------------------------------------------------------
    // format(Date)
    // ---------------------------------------------------------------

    @Test
    public void testFormatDateMatchesFormatLong() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss");
        long millis = 1234567890000L;
        Date date = new Date(millis);
        assertEquals(printer.format(millis), printer.format(date));
    }

    @Test
    public void testFormatDateIntoStringBufferAppends() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        Date date = new Date(0L);
        StringBuffer buf = new StringBuffer("X");
        StringBuffer result = printer.format(date, buf);
        assertSame(buf, result);
        assertEquals("X1970-01-01", result.toString());
    }

    @Test
    public void testFormatDateIntoAppendable() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        Date date = new Date(0L);
        StringBuilder sb = new StringBuilder("X");
        StringBuilder result = printer.format(date, sb);
        assertSame(sb, result);
        assertEquals("X1970-01-01", result.toString());
    }

    // ---------------------------------------------------------------
    // format(Calendar) - the calendar's own time zone only affects the
    // instant, the printer's own time zone determines the rendered zone.
    // ---------------------------------------------------------------

    @Test
    public void testFormatCalendarUsesPrinterTimeZoneNotCalendarTimeZone() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss");
        long millis = 1000000000000L;

        Calendar calNY = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        calNY.setTimeInMillis(millis);

        Calendar calTokyo = Calendar.getInstance(TimeZone.getTimeZone("Asia/Tokyo"));
        calTokyo.setTimeInMillis(millis);

        String expected = printer.format(millis);
        assertEquals(expected, printer.format(calNY));
        assertEquals(expected, printer.format(calTokyo));
    }

    @Test
    public void testFormatCalendarIntoStringBufferAppends() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance(UTC);
        cal.setTimeInMillis(0L);
        StringBuffer buf = new StringBuffer("X");
        StringBuffer result = printer.format(cal, buf);
        assertSame(buf, result);
        assertEquals("X1970-01-01", result.toString());
    }

    @Test
    public void testFormatCalendarIntoAppendable() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance(UTC);
        cal.setTimeInMillis(0L);
        StringBuilder sb = new StringBuilder("X");
        StringBuilder result = printer.format(cal, sb);
        assertSame(sb, result);
        assertEquals("X1970-01-01", result.toString());
    }

    // ---------------------------------------------------------------
    // package-private format(Object) - Date, Calendar or Long
    // ---------------------------------------------------------------

    @Test
    public void testFormatObjectAcceptsDateCalendarAndLong() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss");
        long millis = 987654321000L;
        Date date = new Date(millis);
        Calendar cal = Calendar.getInstance(UTC);
        cal.setTimeInMillis(millis);
        Long boxed = Long.valueOf(millis);

        assertEquals(printer.format(date), printer.format((Object) date));
        assertEquals(printer.format(cal), printer.format((Object) cal));
        assertEquals(printer.format(millis), printer.format((Object) boxed));
    }

    // ---------------------------------------------------------------
    // deprecated format(Object, StringBuffer, FieldPosition)
    // ---------------------------------------------------------------

    @Test
    public void testDeprecatedFormatObjectReturnsSameBufferAndIgnoresFieldPosition() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        Date date = new Date(0L);
        StringBuffer buf = new StringBuffer("X");
        FieldPosition pos = new FieldPosition(0);
        int beginBefore = pos.getBeginIndex();
        int endBefore = pos.getEndIndex();

        StringBuffer result = printer.format((Object) date, buf, pos);

        assertSame(buf, result);
        assertEquals("X1970-01-01", result.toString());
        assertEquals(beginBefore, pos.getBeginIndex());
        assertEquals(endBefore, pos.getEndIndex());
    }

    // ---------------------------------------------------------------
    // getMaxLengthEstimate
    // ---------------------------------------------------------------

    @Test
    public void testGetMaxLengthEstimateBoundsActualFormattedLength() {
        String pattern = "EEEE, dd MMMM yyyy HH:mm:ss.SSS Z";
        FastDatePrinter printer = newPrinter(pattern);
        int estimate = printer.getMaxLengthEstimate();

        Calendar cal = Calendar.getInstance(UTC);
        for (int month = 0; month < 12; month++) {
            cal.set(2024, month, 15, 1, 2, 3);
            String formatted = printer.format(cal.getTimeInMillis());
            assertTrue(formatted.length() <= estimate,
                    "formatted=" + formatted + " length=" + formatted.length() + " estimate=" + estimate);
        }
    }

    @Test
    public void testGetMaxLengthEstimateForEmptyPattern() {
        FastDatePrinter printer = newPrinter("");
        assertEquals(0, printer.getMaxLengthEstimate());
        assertEquals("", printer.format(0L));
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertTrue(printer.equals(printer));
    }

    @Test
    public void testEqualsAgainstNullAndDifferentType() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertFalse(printer.equals(null));
        assertFalse(printer.equals("yyyy-MM-dd"));
    }

    @Test
    public void testEqualInstancesHaveEqualHashCodes() {
        FastDatePrinter a = newPrinter("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        FastDatePrinter b = newPrinter("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);

        assertNotSame(a, b);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testDifferentPatternsAreNotEqual() {
        FastDatePrinter a = newPrinter("yyyy-MM-dd");
        FastDatePrinter b = newPrinter("dd-MM-yyyy");
        assertNotEquals(a, b);
    }

    // ---------------------------------------------------------------
    // toString
    // ---------------------------------------------------------------

    @Test
    public void testToStringIsNotNullOrEmpty() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        String s = printer.toString();
        assertNotNull(s);
        assertFalse(s.isEmpty());
    }

    // ---------------------------------------------------------------
    // parsePattern (protected)
    // ---------------------------------------------------------------

    @Test
    public void testParsePatternReturnsNonEmptyListForNonEmptyPattern() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        List<?> rules = printer.parsePattern();
        assertNotNull(rules);
        assertFalse(rules.isEmpty());
    }

    @Test
    public void testParsePatternReturnsEmptyListForEmptyPattern() {
        FastDatePrinter printer = newPrinter("");
        List<?> rules = printer.parsePattern();
        assertNotNull(rules);
        assertTrue(rules.isEmpty());
    }

    // ---------------------------------------------------------------
    // parseToken (protected)
    // ---------------------------------------------------------------

    @Test
    public void testParseTokenReturnsPrefixOfRemainingPattern() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        String pattern = "yyyy-MM-dd";

        int[] indexRef = new int[] {0};
        String token = printer.parseToken(pattern, indexRef);
        assertNotNull(token);
        assertTrue(token.length() > 0);
        assertTrue(pattern.substring(0).startsWith(token));
        assertTrue(indexRef[0] >= 0 && indexRef[0] < pattern.length());
    }

    @Test
    public void testParseTokenFromMiddleOfPattern() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        String pattern = "yyyy-MM-dd";
        int startIndex = 5; // second 'M'

        int[] indexRef = new int[] {startIndex};
        String token = printer.parseToken(pattern, indexRef);
        assertNotNull(token);
        assertTrue(token.length() > 0);
        assertTrue(pattern.substring(startIndex).startsWith(token));
        assertTrue(indexRef[0] >= startIndex);
    }

    // ---------------------------------------------------------------
    // selectNumberRule (protected)
    // ---------------------------------------------------------------

    @Test
    public void testSelectNumberRuleReturnsNonNullRule() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertNotNull(printer.selectNumberRule(Calendar.YEAR, 4));
        assertNotNull(printer.selectNumberRule(Calendar.DAY_OF_MONTH, 0));
        assertNotNull(printer.selectNumberRule(Calendar.HOUR_OF_DAY, 2));
    }

    // ---------------------------------------------------------------
    // applyRules (deprecated, protected)
    // ---------------------------------------------------------------

    @Test
    public void testApplyRulesReturnsSameBufferAndAppendsFormattedCalendar() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss");
        Calendar cal = Calendar.getInstance(UTC);
        cal.setTimeInMillis(0L);

        StringBuffer buf = new StringBuffer("pre-");
        StringBuffer result = printer.applyRules(cal, buf);

        assertSame(buf, result);
        assertEquals("pre-" + printer.format(cal), buf.toString());
    }

    // ---------------------------------------------------------------
    // package-private static clear() and getTimeZoneDisplay()
    // ---------------------------------------------------------------

    @Test
    public void testGetTimeZoneDisplayMatchesTimeZoneGetDisplayName() {
        TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");

        String expectedShort = tz.getDisplayName(false, TimeZone.SHORT, Locale.US);
        String actualShort = FastDatePrinter.getTimeZoneDisplay(tz, false, TimeZone.SHORT, Locale.US);
        assertEquals(expectedShort, actualShort);

        String expectedLongDst = tz.getDisplayName(true, TimeZone.LONG, Locale.US);
        String actualLongDst = FastDatePrinter.getTimeZoneDisplay(tz, true, TimeZone.LONG, Locale.US);
        assertEquals(expectedLongDst, actualLongDst);
    }

    @Test
    public void testClearDoesNotCorruptSubsequentTimeZoneDisplayLookups() {
        TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
        String before = FastDatePrinter.getTimeZoneDisplay(tz, false, TimeZone.SHORT, Locale.US);

        FastDatePrinter.clear();

        String after = FastDatePrinter.getTimeZoneDisplay(tz, false, TimeZone.SHORT, Locale.US);
        assertEquals(before, after);
    }

    // ---------------------------------------------------------------
    // 'Z' / 'ZZ' time zone patterns (documented RFC822 / ISO8601 extended)
    // ---------------------------------------------------------------

    @Test
    public void testRfc822TimeZonePatternZ() {
        TimeZone plus8 = TimeZone.getTimeZone("GMT+08:00");
        FastDatePrinter printer = newPrinter("Z", plus8, Locale.US);
        assertEquals("+0800", printer.format(0L));

        TimeZone minus11 = TimeZone.getTimeZone("GMT-11:00");
        FastDatePrinter printer2 = newPrinter("Z", minus11, Locale.US);
        assertEquals("-1100", printer2.format(0L));
    }

    @Test
    public void testIso8601ExtendedTimeZonePatternZZ() {
        TimeZone plus8 = TimeZone.getTimeZone("GMT+08:00");
        FastDatePrinter printer = newPrinter("ZZ", plus8, Locale.US);
        assertEquals("+08:00", printer.format(0L));

        TimeZone minus11 = TimeZone.getTimeZone("GMT-11:00");
        FastDatePrinter printer2 = newPrinter("ZZ", minus11, Locale.US);
        assertEquals("-11:00", printer2.format(0L));
    }

    @Test
    public void testIso8601PatternXMatchesSimpleDateFormat() {
        String pattern = "X";
        TimeZone plus8 = TimeZone.getTimeZone("GMT+08:00");
        FastDatePrinter printer = newPrinter(pattern, plus8, Locale.US);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(plus8);
        assertEquals(sdf.format(new Date(0L)), printer.format(0L));
    }

    // ---------------------------------------------------------------
    // Quoted literal text handling (SimpleDateFormat-compatible quoting)
    // ---------------------------------------------------------------

    @Test
    public void testQuotedLiteralTextIsPassedThroughUnchanged() {
        FastDatePrinter printer = newPrinter("yyyy'-at-'HH");
        assertEquals("1970-at-00", printer.format(0L));
    }

    @Test
    public void testDoubledSingleQuoteProducesLiteralQuoteCharacter() {
        FastDatePrinter printer = newPrinter("HH''mm");
        SimpleDateFormat sdf = new SimpleDateFormat("HH''mm", Locale.US);
        sdf.setTimeZone(UTC);
        assertEquals(sdf.format(new Date(0L)), printer.format(0L));
    }
}
