package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;

public class StringUtilsAgentTest {

    @Test
    public void testConstants() {
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("", StringUtils.EMPTY);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }

    @Test
    public void testAbbreviateMaxWidth() {
        assertNull(StringUtils.abbreviate(null, 10));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testAbbreviateOffsetMaxWidth() {
        assertNull(StringUtils.abbreviate(null, 5, 10));
        assertEquals("", StringUtils.abbreviate("", 0, 4));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", -1, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 0, 10));
        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 8, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 12, 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefghij", 0, 3);
            }
        });
    }

    @Test
    public void testAbbreviateMarker() {
        assertNull(StringUtils.abbreviate(null, "...", 10));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", null, 10));
        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("ab..", StringUtils.abbreviate("abcdefg", "..", 4));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.abbreviate("abcdefg", "...", 3);
            }
        });
    }

    @Test
    public void testAbbreviateMarkerOffsetMaxWidth() {
        assertNull(StringUtils.abbreviate(null, null, 2, 4));
        assertEquals("abcdefghijklmno", StringUtils.abbreviate("abcdefghijklmno", null, 3, 4));
        assertEquals("abcdefg---", StringUtils.abbreviate("abcdefghijklmno", "---", -1, 10));
        assertEquals("::efghij::", StringUtils.abbreviate("abcdefghijklmno", "::", 4, 10));
        assertEquals("*ghijklmno", StringUtils.abbreviate("abcdefghijklmno", "*", 9, 10));
    }

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    public void testCapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));
    }

    @Test
    public void testUncapitalize() {
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("cat"));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testCenterIntDefaultPad() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals(" a  ", StringUtils.center("a", 4));
    }

    @Test
    public void testCenterChar() {
        assertNull(StringUtils.center(null, 4, ' '));
        assertEquals("    ", StringUtils.center("", 4, ' '));
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    public void testCenterString() {
        assertNull(StringUtils.center(null, 4, " "));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
    }

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc ", StringUtils.chomp("abc \r"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
        assertEquals("abc\n", StringUtils.chomp("abc\n\r"));
        assertEquals("abc\n\rabc", StringUtils.chomp("abc\n\rabc"));
        assertEquals("", StringUtils.chomp("\r\n"));
    }

    @Test
    public void testChompSeparator() {
        assertNull(StringUtils.chomp(null, "x"));
        assertEquals("", StringUtils.chomp("", "x"));
        assertEquals("foo", StringUtils.chomp("foobar", "bar"));
        assertEquals("foobar", StringUtils.chomp("foobar", "baz"));
        assertEquals("", StringUtils.chomp("foo", "foo"));
        assertEquals("foo ", StringUtils.chomp("foo ", "foo"));
        assertEquals(" ", StringUtils.chomp(" foo", "foo"));
        assertEquals("foo", StringUtils.chomp("foo", "foooo"));
        assertEquals("foo", StringUtils.chomp("foo", ""));
        assertEquals("foo", StringUtils.chomp("foo", null));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc ", StringUtils.chop("abc \r"));
        assertEquals("abc", StringUtils.chop("abc\n"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("abc\nab", StringUtils.chop("abc\nabc"));
        assertEquals("", StringUtils.chop("a"));
        assertEquals("", StringUtils.chop("\r\n"));
    }

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertTrue(StringUtils.compare("a", "B") > 0);
    }

    @Test
    public void testCompareNullIsLess() {
        assertEquals(0, StringUtils.compare(null, null, true));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);
    }

    @Test
    public void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase(null, null));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
        assertTrue(StringUtils.compareIgnoreCase("a", null) > 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
    }

    @Test
    public void testCompareIgnoreCaseNullIsLess() {
        assertEquals(0, StringUtils.compareIgnoreCase(null, null, true));
        assertTrue(StringUtils.compareIgnoreCase(null, "a", false) > 0);
        assertTrue(StringUtils.compareIgnoreCase("a", null, true) > 0);
    }

    @Test
    public void testContainsCharSequence() {
        assertFalse(StringUtils.contains((CharSequence) null, "a"));
        assertFalse(StringUtils.contains("abc", (CharSequence) null));
        assertTrue(StringUtils.contains("", ""));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsChar() {
        assertFalse(StringUtils.contains((CharSequence) null, 'a'));
        assertFalse(StringUtils.contains("", 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContainsAnyChars() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("", 'a'));
        assertFalse(StringUtils.containsAny("aba", new char[0]));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'b', 'y'));
        assertFalse(StringUtils.containsAny("aba", 'z'));
    }

    @Test
    public void testContainsAnyCharSequence() {
        assertFalse(StringUtils.containsAny(null, "a"));
        assertFalse(StringUtils.containsAny("", "a"));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "$.#yF"));
        assertFalse(StringUtils.containsAny("aba", "z"));
    }

    @Test
    public void testContainsAnyVarargs() {
        assertFalse(StringUtils.containsAny((CharSequence) null, "a"));
        assertFalse(StringUtils.containsAny("abcd", (CharSequence[]) null));
        assertTrue(StringUtils.containsAny("abcd", "ab", null));
        assertTrue(StringUtils.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAnyIgnoreCase() {
        assertFalse(StringUtils.containsAnyIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "D", "ABC"));
        assertTrue(StringUtils.containsAnyIgnoreCase("ABC", "d", "abc"));
    }

    @Test
    public void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, ""));
        assertFalse(StringUtils.containsIgnoreCase("abc", null));
        assertTrue(StringUtils.containsIgnoreCase("", ""));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));
    }

    @Test
    public void testContainsNoneChars() {
        assertTrue(StringUtils.containsNone(null, 'a'));
        assertTrue(StringUtils.containsNone("", 'a'));
        assertTrue(StringUtils.containsNone("ab1", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abz", 'x', 'y', 'z'));
    }

    @Test
    public void testContainsNoneCharSequence() {
        assertTrue(StringUtils.containsNone(null, "xyz"));
        assertTrue(StringUtils.containsNone("ab", ""));
        assertTrue(StringUtils.containsNone("ab1", "xyz"));
        assertFalse(StringUtils.containsNone("abz", "xyz"));
    }

    @Test
    public void testContainsOnlyChars() {
        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertTrue(StringUtils.containsOnly("", 'a'));
        assertFalse(StringUtils.containsOnly("ab", new char[0]));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("ab1", 'a', 'b', 'c'));
    }

    @Test
    public void testContainsOnlyCharSequence() {
        assertFalse(StringUtils.containsOnly(null, "abc"));
        assertTrue(StringUtils.containsOnly("", "abc"));
        assertFalse(StringUtils.containsOnly("ab", ""));
        assertTrue(StringUtils.containsOnly("abab", "abc"));
        assertFalse(StringUtils.containsOnly("abz", "abc"));
    }

    @Test
    public void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace(""));
        assertFalse(StringUtils.containsWhitespace("ab"));
        assertTrue(StringUtils.containsWhitespace(" ab"));
        assertTrue(StringUtils.containsWhitespace("a b"));
        assertTrue(StringUtils.containsWhitespace("ab "));
    }

    @Test
    public void testCountMatchesChar() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'b'));
        assertEquals(0, StringUtils.countMatches("abba", 'x'));
    }

    @Test
    public void testCountMatchesCharSequence() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("", "a"));
        assertEquals(0, StringUtils.countMatches("abba", (CharSequence) null));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
        assertEquals(1, StringUtils.countMatches("ababa", "aba"));
    }

    @Test
    public void testDefaultIfBlank() {
        assertEquals("NULL", StringUtils.defaultIfBlank(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfBlank("bat", "NULL"));
        assertNull(StringUtils.defaultIfBlank("", null));
    }

    @Test
    public void testDefaultIfEmpty() {
        assertEquals("NULL", StringUtils.defaultIfEmpty(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals(" ", StringUtils.defaultIfEmpty(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfEmpty("bat", "NULL"));
        assertNull(StringUtils.defaultIfEmpty("", null));
    }

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("", StringUtils.defaultString(""));
        assertEquals("bat", StringUtils.defaultString("bat"));
    }

    @Test
    public void testDefaultStringWithDefault() {
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("", StringUtils.defaultString("", "NULL"));
        assertEquals("bat", StringUtils.defaultString("bat", "NULL"));
    }

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("abc"));
        assertEquals("abc", StringUtils.deleteWhitespace("   ab  c  "));
    }

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", ""));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "xyz"));
    }

    @Test
    public void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertFalse(StringUtils.endsWith("abcdef", null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithAny() {
        assertFalse(StringUtils.endsWithAny(null, (CharSequence[]) null));
        assertFalse(StringUtils.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(StringUtils.endsWithAny("abcxyz", ""));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz"));
        assertTrue(StringUtils.endsWithAny("abcxyz", null, "xyz", "abc"));
        assertTrue(StringUtils.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(StringUtils.endsWithAny("abcXYZ", "def", "xyz"));
    }

    @Test
    public void testEndsWithIgnoreCase() {
        assertTrue(StringUtils.endsWithIgnoreCase(null, null));
        assertFalse(StringUtils.endsWithIgnoreCase(null, "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("abcdef", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertFalse(StringUtils.endsWithIgnoreCase("ABCDEF", "cde"));
    }

    @Test
    public void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsAny() {
        assertFalse(StringUtils.equalsAny(null, (CharSequence[]) null));
        assertTrue(StringUtils.equalsAny(null, null, null));
        assertFalse(StringUtils.equalsAny(null, "abc", "def"));
        assertFalse(StringUtils.equalsAny("abc", null, "def"));
        assertTrue(StringUtils.equalsAny("abc", "abc", "def"));
        assertFalse(StringUtils.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAnyIgnoreCase() {
        assertFalse(StringUtils.equalsAnyIgnoreCase(null, (CharSequence[]) null));
        assertTrue(StringUtils.equalsAnyIgnoreCase(null, null, null));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    public void testFirstNonBlank() {
        assertNull(StringUtils.firstNonBlank(null, null, null));
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("abc", StringUtils.firstNonBlank("abc"));
        assertEquals("xyz", StringUtils.firstNonBlank(null, "xyz"));
        assertEquals("xyz", StringUtils.firstNonBlank(null, "", " ", "xyz"));
        assertNull(StringUtils.firstNonBlank());
    }

    @Test
    public void testFirstNonEmpty() {
        assertNull(StringUtils.firstNonEmpty(null, null, null));
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
        assertEquals("abc", StringUtils.firstNonEmpty("abc"));
        assertEquals("xyz", StringUtils.firstNonEmpty("", "xyz"));
        assertNull(StringUtils.firstNonEmpty());
    }

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {}));
        assertEquals("abc", StringUtils.getCommonPrefix(new String[] {"abc"}));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {null, null}));
        assertEquals("a", StringUtils.getCommonPrefix(new String[] {"abc", "a"}));
        assertEquals("ab", StringUtils.getCommonPrefix(new String[] {"ab", "abxyz"}));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {"abcde", "xyz"}));
        assertEquals("i am a ", StringUtils.getCommonPrefix(new String[] {"i am a machine", "i am a robot"}));
    }

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1000", StringUtils.getDigits("1000$"));
        assertEquals("112345", StringUtils.getDigits("1123~45"));
        assertEquals("5417543010", StringUtils.getDigits("(541) 754-3010"));
    }

    @Test
    public void testGetFuzzyDistance() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.getFuzzyDistance(null, null, null);
            }
        });
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(0, StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Room", "o", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Workshop", "w", Locale.ENGLISH));
        assertEquals(2, StringUtils.getFuzzyDistance("Workshop", "ws", Locale.ENGLISH));
        assertEquals(4, StringUtils.getFuzzyDistance("Workshop", "wo", Locale.ENGLISH));
    }

    @Test
    public void testGetIfBlank() {
        assertEquals("NULL", StringUtils.getIfBlank(null, new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        }));
        assertEquals("bat", StringUtils.getIfBlank("bat", new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        }));
        assertNull(StringUtils.getIfBlank("", null));
    }

    @Test
    public void testGetIfEmpty() {
        assertEquals("NULL", StringUtils.getIfEmpty("", new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        }));
        assertEquals(" ", StringUtils.getIfEmpty(" ", new Supplier<String>() {
            public String get() {
                return "NULL";
            }
        }));
        assertNull(StringUtils.getIfEmpty("", null));
    }

    @Test
    public void testGetJaroWinklerDistance() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, null);
            }
        });
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("", ""), 0.0001);
        assertEquals(0.93, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.01);
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("fly", "ant"), 0.0001);
        assertEquals(0.88, StringUtils.getJaroWinklerDistance("hello", "hallo"), 0.01);
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
        assertEquals(1, StringUtils.getLevenshteinDistance("hello", "hallo"));
    }

    @Test
    public void testGetLevenshteinDistanceThreshold() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 0));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 8));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("aaapppp", "", 6));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
    }

    @Test
    public void testIndexOfCharSequence() {
        assertEquals(-1, StringUtils.indexOf((CharSequence) null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", (CharSequence) null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(-1, StringUtils.indexOf("", "a"));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));
        assertEquals(0, StringUtils.indexOf("aabaabaa", ""));
    }

    @Test
    public void testIndexOfCharSequenceFromIndex() {
        assertEquals(-1, StringUtils.indexOf((CharSequence) null, "a", 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", "b", 9));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", -1));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "", 2));
        assertEquals(3, StringUtils.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfChar() {
        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'a'));
        assertEquals(-1, StringUtils.indexOf("", 'a'));
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
        assertEquals(-1, StringUtils.indexOf("aaaaaaaa", 'Z'));
    }

    @Test
    public void testIndexOfCharFromIndex() {
        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'b', 0));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", 'b', 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", 'b', 9));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', -1));
    }

    @Test
    public void testIndexOfAnyChars() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", (char[]) null));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 'b', 'y'));
        assertEquals(-1, StringUtils.indexOfAny("aba", 'z'));
    }

    @Test
    public void testIndexOfAnyCharSequences() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, "ab"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", (CharSequence[]) null));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(1, StringUtils.indexOfAny("zzabyycdxx", "zab", "aby"));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", ""));
    }

    @Test
    public void testIndexOfAnyWithStart() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 0, 'a'));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 0, 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 0, 'b', 'y'));
        assertEquals(-1, StringUtils.indexOfAny("aba", 0, 'z'));
    }

    @Test
    public void testIndexOfAnyString() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, "za"));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", "za"));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", "by"));
        assertEquals(-1, StringUtils.indexOfAny("aba", "z"));
    }

    @Test
    public void testIndexOfAnyBut() {
        assertEquals(-1, StringUtils.indexOfAnyBut((CharSequence) null, 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", new char[] {'z', 'a'}));
        assertEquals(0, StringUtils.indexOfAnyBut("aba", new char[] {'z'}));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", new char[] {'a', 'b'}));
    }

    @Test
    public void testIndexOfAnyButCharSequence() {
        assertEquals(-1, StringUtils.indexOfAnyBut((CharSequence) null, "za"));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));
        assertEquals(-1, StringUtils.indexOfAnyBut("zzabyycdxx", ""));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", "ab"));
    }

    @Test
    public void testIndexOfDifferenceArray() {
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] {}));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] {"abc"}));
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[] {"", "abc"}));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] {"abc", "abc"}));
        assertEquals(1, StringUtils.indexOfDifference(new CharSequence[] {"abc", "a"}));
        assertEquals(7, StringUtils.indexOfDifference(new CharSequence[] {"i am a machine", "i am a robot"}));
    }

    @Test
    public void testIndexOfDifferenceTwo() {
        assertEquals(-1, StringUtils.indexOfDifference(null, null));
        assertEquals(-1, StringUtils.indexOfDifference("", ""));
        assertEquals(0, StringUtils.indexOfDifference("", "abc"));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("ab", "abxyz"));
        assertEquals(0, StringUtils.indexOfDifference("abcde", "xyz"));
    }

    @Test
    public void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase((CharSequence) null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("", ""));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "b"));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOfIgnoreCaseFromIndex() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase((CharSequence) null, "a", 0));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A", 0));
        assertEquals(5, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 3));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 9));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B", -1));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("abc", "", 9));
    }

    @Test
    public void testIsAllBlank() {
        assertTrue(StringUtils.isAllBlank((CharSequence) null));
        assertFalse(StringUtils.isAllBlank(null, "foo"));
        assertTrue(StringUtils.isAllBlank(null, null));
        assertFalse(StringUtils.isAllBlank("", "bar"));
        assertFalse(StringUtils.isAllBlank("foo", "bar"));
        assertTrue(StringUtils.isAllBlank(new CharSequence[] {}));
    }

    @Test
    public void testIsAllEmpty() {
        assertTrue(StringUtils.isAllEmpty((CharSequence) null));
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertTrue(StringUtils.isAllEmpty(new CharSequence[] {}));
        assertFalse(StringUtils.isAllEmpty(null, "foo"));
        assertFalse(StringUtils.isAllEmpty(" ", "bar"));
    }

    @Test
    public void testIsAllLowerCase() {
        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertFalse(StringUtils.isAllLowerCase("  "));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab1c"));
    }

    @Test
    public void testIsAllUpperCase() {
        assertFalse(StringUtils.isAllUpperCase(null));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));
        assertFalse(StringUtils.isAllUpperCase("A1C"));
    }

    @Test
    public void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));
    }

    @Test
    public void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("abc"));
        assertFalse(StringUtils.isAlphanumeric("ab c"));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    public void testIsAlphanumericSpace() {
        assertFalse(StringUtils.isAlphanumericSpace(null));
        assertTrue(StringUtils.isAlphanumericSpace(""));
        assertTrue(StringUtils.isAlphanumericSpace("ab c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab-c"));
    }

    @Test
    public void testIsAlphaSpace() {
        assertFalse(StringUtils.isAlphaSpace(null));
        assertTrue(StringUtils.isAlphaSpace(""));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2c"));
    }

    @Test
    public void testIsAnyBlank() {
        assertTrue(StringUtils.isAnyBlank((CharSequence) null));
        assertFalse(StringUtils.isAnyBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAnyBlank(null, "foo"));
        assertTrue(StringUtils.isAnyBlank("", "bar"));
        assertFalse(StringUtils.isAnyBlank(new CharSequence[] {}));
        assertTrue(StringUtils.isAnyBlank(new CharSequence[] {""}));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));
    }

    @Test
    public void testIsAnyEmpty() {
        assertTrue(StringUtils.isAnyEmpty((CharSequence) null));
        assertFalse(StringUtils.isAnyEmpty((CharSequence[]) null));
        assertTrue(StringUtils.isAnyEmpty(null, "foo"));
        assertFalse(StringUtils.isAnyEmpty(" ", "bar"));
        assertFalse(StringUtils.isAnyEmpty(new CharSequence[] {}));
        assertTrue(StringUtils.isAnyEmpty(new CharSequence[] {""}));
    }

    @Test
    public void testIsAsciiPrintable() {
        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable(" "));
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
        assertFalse(StringUtils.isAsciiPrintable("Ceki Gülcü"));
    }

    @Test
    public void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));
    }

    @Test
    public void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));
    }

    @Test
    public void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
        assertTrue(StringUtils.isMixedCase("A1c"));
    }

    @Test
    public void testIsNoneBlank() {
        assertFalse(StringUtils.isNoneBlank((CharSequence) null));
        assertTrue(StringUtils.isNoneBlank((CharSequence[]) null));
        assertFalse(StringUtils.isNoneBlank(null, "foo"));
        assertTrue(StringUtils.isNoneBlank(new CharSequence[] {}));
        assertFalse(StringUtils.isNoneBlank(new CharSequence[] {""}));
        assertTrue(StringUtils.isNoneBlank("foo", "bar"));
    }

    @Test
    public void testIsNoneEmpty() {
        assertFalse(StringUtils.isNoneEmpty((CharSequence) null));
        assertTrue(StringUtils.isNoneEmpty((CharSequence[]) null));
        assertFalse(StringUtils.isNoneEmpty(null, "foo"));
        assertTrue(StringUtils.isNoneEmpty(new CharSequence[] {}));
        assertFalse(StringUtils.isNoneEmpty(new CharSequence[] {""}));
        assertTrue(StringUtils.isNoneEmpty(" ", "bar"));
    }

    @Test
    public void testIsNotBlank() {
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(""));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));
        assertTrue(StringUtils.isNotEmpty("bob"));
    }

    @Test
    public void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric("  "));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("ab2c"));
        assertFalse(StringUtils.isNumeric("12-3"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertFalse(StringUtils.isNumeric("+123"));
    }

    @Test
    public void testIsNumericSpace() {
        assertFalse(StringUtils.isNumericSpace(null));
        assertTrue(StringUtils.isNumericSpace(""));
        assertTrue(StringUtils.isNumericSpace("  "));
        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("ab2c"));
        assertFalse(StringUtils.isNumericSpace("12.3"));
    }

    @Test
    public void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace("abc"));
    }

    @Test
    public void testJoinBooleanArray() {
        assertNull(StringUtils.join((boolean[]) null, ';'));
        assertEquals("", StringUtils.join(new boolean[] {}, ';'));
        assertEquals("false;false", StringUtils.join(new boolean[] {false, false}, ';'));
    }

    @Test
    public void testJoinIntArray() {
        assertNull(StringUtils.join((int[]) null, ';'));
        assertEquals("", StringUtils.join(new int[] {}, ';'));
        assertEquals("1;2;3", StringUtils.join(new int[] {1, 2, 3}, ';'));
    }

    @Test
    public void testJoinIntArrayStartEnd() {
        assertEquals("2;3", StringUtils.join(new int[] {1, 2, 3}, ';', 1, 3));
        assertEquals("", StringUtils.join(new int[] {1, 2, 3}, ';', 2, 2));
    }

    @Test
    public void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ';'));
        assertEquals("", StringUtils.join(new Object[] {}, ';'));
        assertEquals("", StringUtils.join(new Object[] {null}, ';'));
        assertEquals("a;b;c", StringUtils.join(new Object[] {"a", "b", "c"}, ';'));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
        assertEquals(";;a", StringUtils.join(new Object[] {null, "", "a"}, ';'));
    }

    @Test
    public void testJoinObjectArrayStartEnd() {
        assertNull(StringUtils.join((Object[]) null, "--", 0, 3));
        assertEquals("a--b--c", StringUtils.join(new Object[] {"a", "b", "c"}, "--", 0, 3));
        assertEquals("b--c", StringUtils.join(new Object[] {"a", "b", "c"}, "--", 1, 3));
        assertEquals("c", StringUtils.join(new Object[] {"a", "b", "c"}, "--", 2, 3));
        assertEquals("", StringUtils.join(new Object[] {"a", "b", "c"}, "--", 2, 2));
    }

    @Test
    public void testJoinIterable() {
        List<Integer> list = new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(3);
        assertNull(StringUtils.join((Iterable<?>) null, ';'));
        assertEquals("1;2;3", StringUtils.join((Iterable<?>) list, ';'));
    }

    @Test
    public void testJoinList() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        assertEquals("a--b--c", StringUtils.join(list, "--", 0, 3));
        assertEquals("b--c", StringUtils.join(list, "--", 1, 3));
    }

    @Test
    public void testJoinVarargs() {
        assertNull(StringUtils.join((Object[]) null));
        assertEquals("abc", StringUtils.join("a", "b", "c"));
        assertEquals("a", StringUtils.join(null, "", "a"));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a,b", StringUtils.joinWith(",", "a", "b"));
        assertEquals("a,b,", StringUtils.joinWith(",", "a", "b", ""));
        assertEquals("a,,b", StringUtils.joinWith(",", "a", null, "b"));
        assertEquals("ab", StringUtils.joinWith(null, "a", "b"));
    }

    @Test
    public void testLastIndexOfCharSequence() {
        assertEquals(-1, StringUtils.lastIndexOf((CharSequence) null, "a"));
        assertEquals(0, StringUtils.lastIndexOf("", ""));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, StringUtils.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, StringUtils.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfCharSequenceFromIndex() {
        assertEquals(-1, StringUtils.lastIndexOf((CharSequence) null, "a", 0));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, StringUtils.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b", 2));
    }

    @Test
    public void testLastIndexOfChar() {
        assertEquals(-1, StringUtils.lastIndexOf((CharSequence) null, 'a'));
        assertEquals(-1, StringUtils.lastIndexOf("", 'a'));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b'));
    }

    @Test
    public void testLastIndexOfCharFromIndex() {
        assertEquals(-1, StringUtils.lastIndexOf((CharSequence) null, 'b', 0));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b', 8));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", 'b', 4));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", 'b', 0));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", 'b', -1));
    }

    @Test
    public void testLastIndexOfAny() {
        assertEquals(-1, StringUtils.lastIndexOfAny((CharSequence) null, "ab"));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", (CharSequence[]) null));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(10, StringUtils.lastIndexOfAny("zzabyycdxx", "mn", ""));
    }

    @Test
    public void testLastIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase((CharSequence) null, "a"));
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(4, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "AB"));
    }

    @Test
    public void testLastIndexOfIgnoreCaseFromIndex() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase((CharSequence) null, "a", 0));
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", 8));
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", -1));
        assertEquals(0, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A", 0));
    }

    @Test
    public void testLastOrdinalIndexOf() {
        assertEquals(-1, StringUtils.lastOrdinalIndexOf((CharSequence) null, "a", 1));
        assertEquals(0, StringUtils.lastOrdinalIndexOf("", "", 1));
        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
        assertEquals(1, StringUtils.lastOrdinalIndexOf("aabaabaa", "ab", 2));
    }

    @Test
    public void testLeft() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("", StringUtils.left("", 3));
        assertEquals("", StringUtils.left("abc", 0));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("bat", StringUtils.leftPad("bat", 3));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", -1));
    }

    @Test
    public void testLeftPadChar() {
        assertNull(StringUtils.leftPad(null, 3, 'z'));
        assertEquals("zzz", StringUtils.leftPad("", 3, 'z'));
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
    }

    @Test
    public void testLeftPadString() {
        assertNull(StringUtils.leftPad(null, 3, "z"));
        assertEquals("zzz", StringUtils.leftPad("", 3, "z"));
        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));
        assertEquals("yzyzybat", StringUtils.leftPad("bat", 8, "yz"));
        assertEquals("  bat", StringUtils.leftPad("bat", 5, (String) null));
        assertEquals("  bat", StringUtils.leftPad("bat", 5, ""));
    }

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    public void testLowerCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("", StringUtils.lowerCase(""));
        assertEquals("abc", StringUtils.lowerCase("aBc"));
    }

    @Test
    public void testLowerCaseLocale() {
        assertNull(StringUtils.lowerCase(null, Locale.ENGLISH));
        assertEquals("abc", StringUtils.lowerCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testMid() {
        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("", 0, 4));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("abc", StringUtils.mid("abc", 0, 4));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("abc", StringUtils.normalizeSpace("  abc  "));
        assertEquals("ab c", StringUtils.normalizeSpace("ab   c"));
        assertEquals("a b c", StringUtils.normalizeSpace(" a \t b \n c "));
    }

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf((CharSequence) null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("", "", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "b", 2));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "ab", 2));
    }

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, "x", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    public void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, null));
        assertEquals("abc", StringUtils.prependIfMissing("abc", null));
        assertEquals("xyz", StringUtils.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", StringUtils.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingIgnoreCase() {
        assertNull(StringUtils.prependIfMissingIgnoreCase(null, null));
        assertEquals("xyzabc", StringUtils.prependIfMissingIgnoreCase("abc", "xyz"));
        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }

    @Test
    public void testRemoveChar() {
        assertNull(StringUtils.remove(null, 'u'));
        assertEquals("", StringUtils.remove("", 'u'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("queued", StringUtils.remove("queued", 'z'));
    }

    @Test
    public void testRemoveString() {
        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("", StringUtils.remove("", "ue"));
        assertEquals("queued", StringUtils.remove("queued", (String) null));
        assertEquals("queued", StringUtils.remove("queued", ""));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("queued", StringUtils.remove("queued", "zz"));
    }

    @Test
    public void testRemoveAll() {
        assertNull(StringUtils.removeAll((String) null, ".*"));
        assertEquals("any", StringUtils.removeAll("any", (String) null));
        assertEquals("any", StringUtils.removeAll("any", ""));
        assertEquals("", StringUtils.removeAll("any", ".*"));
        assertEquals("", StringUtils.removeAll("abc", ".?"));
        assertEquals("ABC123", StringUtils.removeAll("ABCabc123abc", "[a-z]"));
    }

    @Test
    public void testRemoveEnd() {
        assertNull(StringUtils.removeEnd(null, "x"));
        assertEquals("", StringUtils.removeEnd("", "x"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", (String) null));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("abc", StringUtils.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEndIgnoreCase() {
        assertNull(StringUtils.removeEndIgnoreCase(null, "x"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".COM"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));
    }

    @Test
    public void testRemoveFirst() {
        assertNull(StringUtils.removeFirst((String) null, ".*"));
        assertEquals("any", StringUtils.removeFirst("any", (String) null));
        assertEquals("", StringUtils.removeFirst("any", ".*"));
        assertEquals("bc", StringUtils.removeFirst("abc", ".?"));
        assertEquals("ABC123abc", StringUtils.removeFirst("ABCabc123abc", "[a-z]+"));
    }

    @Test
    public void testRemoveIgnoreCase() {
        assertNull(StringUtils.removeIgnoreCase(null, "x"));
        assertEquals("", StringUtils.removeIgnoreCase("", "x"));
        assertEquals("queued", StringUtils.removeIgnoreCase("queued", (String) null));
        assertEquals("qd", StringUtils.removeIgnoreCase("quEUed", "UE"));
        assertEquals("queued", StringUtils.removeIgnoreCase("queued", "zZ"));
    }

    @Test
    public void testRemovePattern() {
        assertNull(StringUtils.removePattern(null, ".*"));
        assertEquals("any", StringUtils.removePattern("any", (String) null));
        assertEquals("ABC123", StringUtils.removePattern("ABCabc123", "[a-z]"));
    }

    @Test
    public void testRemoveStartChar() {
        assertNull(StringUtils.removeStart((String) null, '/'));
        assertEquals("", StringUtils.removeStart("", '/'));
        assertEquals("path", StringUtils.removeStart("/path", '/'));
        assertEquals("path", StringUtils.removeStart("path", '/'));
    }

    @Test
    public void testRemoveStartString() {
        assertNull(StringUtils.removeStart((String) null, "www."));
        assertEquals("", StringUtils.removeStart("", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", (String) null));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
        assertEquals("abc", StringUtils.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStartIgnoreCase() {
        assertNull(StringUtils.removeStartIgnoreCase((String) null, "www."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "WWW."));
    }

    @Test
    public void testRepeatChar() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat('e', -2));
    }

    @Test
    public void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("", 0));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));
    }

    @Test
    public void testRepeatWithSeparator() {
        assertNull(StringUtils.repeat(null, null, 2));
        assertEquals("", StringUtils.repeat("", (String) null, 0));
        assertEquals("xx", StringUtils.repeat("", "x", 3));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    public void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("", StringUtils.replace("", "a", "b"));
        assertEquals("any", StringUtils.replace("any", (String) null, "b"));
        assertEquals("any", StringUtils.replace("any", "a", (String) null));
        assertEquals("any", StringUtils.replace("any", "", "b"));
        assertEquals("aba", StringUtils.replace("aba", "a", (String) null));
        assertEquals("b", StringUtils.replace("aba", "a", ""));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceMax() {
        assertNull(StringUtils.replace(null, "a", "b", 1));
        assertEquals("abaa", StringUtils.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
        assertEquals("zbza", StringUtils.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", StringUtils.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceAllRegex() {
        assertNull(StringUtils.replaceAll(null, ".*", "zzz"));
        assertEquals("zzz", StringUtils.replaceAll("", "", "zzz"));
        assertEquals("", StringUtils.replaceAll("", ".+", "zzz"));
        assertEquals("ZZaZZbZZcZZ", StringUtils.replaceAll("abc", "", "ZZ"));
        assertEquals("ABC___123", StringUtils.replaceAll("ABCabc123", "[a-z]", "_"));
    }

    @Test
    public void testReplaceCharsCharToChar() {
        assertNull(StringUtils.replaceChars(null, 'b', 'y'));
        assertEquals("", StringUtils.replaceChars("", 'b', 'y'));
        assertEquals("aycya", StringUtils.replaceChars("abcba", 'b', 'y'));
        assertEquals("abcba", StringUtils.replaceChars("abcba", 'z', 'y'));
    }

    @Test
    public void testReplaceCharsStringToString() {
        assertNull(StringUtils.replaceChars(null, "b", "y"));
        assertEquals("abc", StringUtils.replaceChars("abc", (String) null, "y"));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", (String) null));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yzx"));
        assertEquals("ayya", StringUtils.replaceChars("abcba", "bc", "y"));
    }

    @Test
    public void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("aba", StringUtils.replaceEach("aba", null, null));
        assertEquals("b", StringUtils.replaceEach("aba", new String[] {"a"}, new String[] {""}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("dcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
    }

    @Test
    public void testReplaceEachRepeatedly() {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "ab"});
            }
        });
    }

    @Test
    public void testReplaceFirst() {
        assertNull(StringUtils.replaceFirst(null, ".*", "zzz"));
        assertEquals("zzz", StringUtils.replaceFirst("", "", "zzz"));
        assertEquals("ZZabc", StringUtils.replaceFirst("abc", "", "ZZ"));
        assertEquals("ABC_bc123", StringUtils.replaceFirst("ABCabc123", "[a-z]", "_"));
    }

    @Test
    public void testReplaceIgnoreCase() {
        assertNull(StringUtils.replaceIgnoreCase(null, "a", "z"));
        assertEquals("b", StringUtils.replaceIgnoreCase("abA", "A", ""));
        assertEquals("zbz", StringUtils.replaceIgnoreCase("aba", "A", "z"));
    }

    @Test
    public void testReplaceIgnoreCaseMax() {
        assertEquals("abaa", StringUtils.replaceIgnoreCase("abaa", "a", "z", 0));
        assertEquals("zbaa", StringUtils.replaceIgnoreCase("abaa", "A", "z", 1));
        assertEquals("zbza", StringUtils.replaceIgnoreCase("abAa", "a", "z", 2));
        assertEquals("zbzz", StringUtils.replaceIgnoreCase("abAa", "a", "z", -1));
    }

    @Test
    public void testReplaceOnce() {
        assertNull(StringUtils.replaceOnce(null, "a", "z"));
        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceIgnoreCase() {
        assertNull(StringUtils.replaceOnceIgnoreCase(null, "a", "z"));
        assertEquals("Foofoo", StringUtils.replaceOnceIgnoreCase("FoOFoofoo", "foo", ""));
    }

    @Test
    public void testReplacePattern() {
        assertNull(StringUtils.replacePattern(null, ".*", "z"));
        assertEquals("ABC_123", StringUtils.replacePattern("ABCabc123", "[^A-Z0-9]+", "_"));
        assertEquals("Lorem_ipsum_dolor_sit", StringUtils.replacePattern("Lorem ipsum  dolor   sit", "( +)([a-z]+)", "_$2"));
    }

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("tab", StringUtils.reverse("bat"));
    }

    @Test
    public void testReverseDelimited() {
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("", StringUtils.reverseDelimited("", '.'));
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    public void testRight() {
        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("", StringUtils.right("abc", 0));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("   ", StringUtils.rightPad("", 3));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("bat", StringUtils.rightPad("bat", -1));
    }

    @Test
    public void testRightPadChar() {
        assertEquals("zzz", StringUtils.rightPad("", 3, 'z'));
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
    }

    @Test
    public void testRightPadString() {
        assertEquals("batyz", StringUtils.rightPad("bat", 5, "yz"));
        assertEquals("batyzyzy", StringUtils.rightPad("bat", 8, "yz"));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5, (String) null));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5, ""));
    }

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -9));
    }

    @Test
    public void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[] {}, StringUtils.split(""));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] {"abc"}, StringUtils.split(" abc "));
    }

    @Test
    public void testSplitChar() {
        assertNull(StringUtils.split(null, '.'));
        assertArrayEquals(new String[] {}, StringUtils.split("", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[] {"a:b:c"}, StringUtils.split("a:b:c", '.'));
    }

    @Test
    public void testSplitStringSeparator() {
        assertNull(StringUtils.split(null, "."));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc def", (String) null));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitStringSeparatorMax() {
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":", 0));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
    }

    @Test
    public void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[] {}, StringUtils.splitByCharacterType(""));
        assertArrayEquals(new String[] {"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
        assertArrayEquals(new String[] {"number", "5"}, StringUtils.splitByCharacterType("number5"));
        assertArrayEquals(new String[] {"foo", "B", "ar"}, StringUtils.splitByCharacterType("fooBar"));
        assertArrayEquals(new String[] {"ASFR", "ules"}, StringUtils.splitByCharacterType("ASFRules"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase() {
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
        assertArrayEquals(new String[] {"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] {"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    public void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "-!-"));
        assertArrayEquals(new String[] {}, StringUtils.splitByWholeSeparator("", "-!-"));
        assertArrayEquals(new String[] {"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab de fg", (String) null));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByWholeSeparatorMax() {
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.splitByWholeSeparator("ab:cd:ef", ":", 2));
        assertArrayEquals(new String[] {"ab", "cd-!-ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-", 2));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens() {
        assertNull(StringUtils.splitByWholeSeparatorPreserveAllTokens(null, "-!-"));
        assertArrayEquals(new String[] {"ab", "", "", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab   de fg", (String) null));
    }

    @Test
    public void testSplitPreserveAllTokens() {
        assertNull(StringUtils.splitPreserveAllTokens(null));
        assertArrayEquals(new String[] {"abc", "", "def"}, StringUtils.splitPreserveAllTokens("abc  def"));
        assertArrayEquals(new String[] {"", "abc", ""}, StringUtils.splitPreserveAllTokens(" abc "));
    }

    @Test
    public void testSplitPreserveAllTokensChar() {
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] {"", "a", "b", "c", ""}, StringUtils.splitPreserveAllTokens(" a b c ", ' '));
    }

    @Test
    public void testSplitPreserveAllTokensStringSeparator() {
        assertArrayEquals(new String[] {"ab", "cd", "ef", ""}, StringUtils.splitPreserveAllTokens("ab:cd:ef:", ":"));
        assertArrayEquals(new String[] {"", "", "cd", "ef"}, StringUtils.splitPreserveAllTokens("::cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokensStringSeparatorMax() {
        assertArrayEquals(new String[] {"ab", "", "", "de", "fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", (String) null, 0));
        assertArrayEquals(new String[] {"ab", "", "", "de", "fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", (String) null, 4));
    }

    @Test
    public void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAny() {
        assertFalse(StringUtils.startsWithAny(null, (CharSequence[]) null));
        assertTrue(StringUtils.startsWithAny("abcxyz", ""));
        assertTrue(StringUtils.startsWithAny("abcxyz", null, "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    @Test
    public void testStartsWithIgnoreCase() {
        assertTrue(StringUtils.startsWithIgnoreCase(null, null));
        assertFalse(StringUtils.startsWithIgnoreCase(null, "abc"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }

    @Test
    public void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc"));
        assertEquals("ab c", StringUtils.strip(" ab c "));
    }

    @Test
    public void testStripWithChars() {
        assertNull(StringUtils.strip(null, "xyz"));
        assertEquals("abc", StringUtils.strip("abc", null));
        assertEquals("  abc", StringUtils.strip("  abcyx", "xyz"));
    }

    @Test
    public void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    public void testStripAll() {
        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {}, StringUtils.stripAll(new String[] {}));
        assertArrayEquals(new String[] {"abc", "abc"}, StringUtils.stripAll(new String[] {"abc", "  abc"}));
        assertArrayEquals(new String[] {"abc", null}, StringUtils.stripAll(new String[] {"abc  ", null}));
    }

    @Test
    public void testStripAllWithChars() {
        assertArrayEquals(new String[] {"abc  ", null}, StringUtils.stripAll(new String[] {"abc  ", null}, "yz"));
        assertArrayEquals(new String[] {"abc", null}, StringUtils.stripAll(new String[] {"yabcz", null}, "yz"));
    }

    @Test
    public void testStripEnd() {
        assertNull(StringUtils.stripEnd(null, "xyz"));
        assertEquals("abc", StringUtils.stripEnd("abc", ""));
        assertEquals("  abc", StringUtils.stripEnd("  abc", null));
        assertEquals("  abc", StringUtils.stripEnd("  abcyx", "xyz"));
        assertEquals("12", StringUtils.stripEnd("120.00", ".0"));
    }

    @Test
    public void testStripStart() {
        assertNull(StringUtils.stripStart(null, "xyz"));
        assertEquals("abc  ", StringUtils.stripStart("abc  ", null));
        assertEquals("abc  ", StringUtils.stripStart("yxabc  ", "xyz"));
    }

    @Test
    public void testStripToEmpty() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));
        assertEquals("abc", StringUtils.stripToEmpty("  abc"));
    }

    @Test
    public void testStripToNull() {
        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc"));
    }

    @Test
    public void testSubstring() {
        assertNull(StringUtils.substring(null, 2));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("abc", StringUtils.substring("abc", 0));
        assertEquals("c", StringUtils.substring("abc", 2));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", -2));
        assertEquals("abc", StringUtils.substring("abc", -4));
    }

    @Test
    public void testSubstringStartEnd() {
        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("", StringUtils.substring("abc", 4, 6));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    public void testSubstringAfterChar() {
        assertNull(StringUtils.substringAfter(null, 'a'));
        assertEquals("", StringUtils.substringAfter("", 'a'));
        assertEquals("bc", StringUtils.substringAfter("abc", 'a'));
        assertEquals("", StringUtils.substringAfter("abc", 'd'));
        assertEquals("abc", StringUtils.substringAfter(" abc", 32));
    }

    @Test
    public void testSubstringAfterString() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("abc", StringUtils.substringAfter("abc", ""));
    }

    @Test
    public void testSubstringAfterLastChar() {
        assertNull(StringUtils.substringAfterLast(null, 'a'));
        assertEquals("a", StringUtils.substringAfterLast("abcba", 'b'));
        assertEquals("", StringUtils.substringAfterLast("a", 'a'));
        assertEquals("", StringUtils.substringAfterLast("a", 'z'));
    }

    @Test
    public void testSubstringAfterLastString() {
        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("", StringUtils.substringAfterLast("abc", ""));
        assertEquals("", StringUtils.substringAfterLast("abc", (String) null));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("a", "a"));
    }

    @Test
    public void testSubstringBeforeChar() {
        assertNull(StringUtils.substringBefore(null, 'a'));
        assertEquals("", StringUtils.substringBefore("abc", 'a'));
        assertEquals("a", StringUtils.substringBefore("abcba", 'b'));
        assertEquals("abc", StringUtils.substringBefore("abc", 'd'));
    }

    @Test
    public void testSubstringBeforeString() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("abc", ""));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
    }

    @Test
    public void testSubstringBeforeLast() {
        assertNull(StringUtils.substringBeforeLast(null, "b"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("", StringUtils.substringBeforeLast("a", "a"));
        assertEquals("a", StringUtils.substringBeforeLast("a", "z"));
        assertEquals("a", StringUtils.substringBeforeLast("a", (String) null));
        assertEquals("a", StringUtils.substringBeforeLast("a", ""));
    }

    @Test
    public void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
    }

    @Test
    public void testSubstringBetweenOpenClose() {
        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertNull(StringUtils.substringBetween(null, "[", "]"));
        assertNull(StringUtils.substringBetween("", "", "]"));
        assertEquals("abc", StringUtils.substringBetween("yabcz", "y", "z"));
        assertEquals("abc", StringUtils.substringBetween("yabczyabcz", "y", "z"));
    }

    @Test
    public void testSubstringsBetween() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[] {}, StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testToCodePoints() {
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[] {}, StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
    }

    @Test
    public void testToEncodedString() {
        assertEquals("abc", StringUtils.toEncodedString(new byte[] {97, 98, 99}, java.nio.charset.StandardCharsets.UTF_8));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.toEncodedString(null, java.nio.charset.StandardCharsets.UTF_8);
            }
        });
    }

    @Test
    public void testGetBytesCharset() {
        assertArrayEquals(new byte[] {}, StringUtils.getBytes(null, java.nio.charset.StandardCharsets.UTF_8));
        assertArrayEquals(new byte[] {97, 98, 99}, StringUtils.getBytes("abc", java.nio.charset.StandardCharsets.UTF_8));
    }

    @Test
    public void testToRootLowerCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
    }

    @Test
    public void testToRootUpperCase() {
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    @Test
    public void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("    abc    "));
    }

    @Test
    public void testTrimAsciiControl() {
        assertNull(StringUtils.trimAsciiControl(null));
        assertEquals("", StringUtils.trimAsciiControl(""));
        assertEquals("abc", StringUtils.trimAsciiControl("\u0001abc\u0001"));
    }

    @Test
    public void testTrimToEmpty() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("     "));
        assertEquals("abc", StringUtils.trimToEmpty("    abc    "));
    }

    @Test
    public void testTrimToNull() {
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("     "));
        assertEquals("abc", StringUtils.trimToNull("    abc    "));
    }

    @Test
    public void testTruncateTwoArg() {
        assertNull(StringUtils.truncate(null, 2));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 8));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    public void testTruncateThreeArg() {
        assertNull(StringUtils.truncate(null, 2, 4));
        assertEquals("", StringUtils.truncate("", 2, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("peach", StringUtils.truncate("raspberry peach", 10, 15));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghijklmno", 0, 10));
        assertEquals("abcdefghijklmno", StringUtils.truncate("abcdefghijklmno", 0, Integer.MAX_VALUE));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", Integer.MAX_VALUE, Integer.MAX_VALUE));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghijklmno", -1, 10);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                StringUtils.truncate("abcdefghij", 3, -1);
            }
        });
    }

    @Test
    public void testUnwrapChar() {
        assertNull(StringUtils.unwrap(null, '\0'));
        assertEquals("a", StringUtils.unwrap("a", 'a'));
        assertEquals("", StringUtils.unwrap("aa", 'a'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("ABabcBA", StringUtils.unwrap("AABabcBAA", 'A'));
        assertEquals("A", StringUtils.unwrap("A", '#'));
        assertEquals("#A", StringUtils.unwrap("#A", '#'));
    }

    @Test
    public void testUnwrapString() {
        assertNull(StringUtils.unwrap(null, "1"));
        assertEquals("a", StringUtils.unwrap("a", "a"));
        assertEquals("", StringUtils.unwrap("aa", "a"));
        assertEquals("abc", StringUtils.unwrap("'abc'", "'"));
        assertEquals("BabcB", StringUtils.unwrap("AABabcBAA", "AA"));
        assertEquals("A", StringUtils.unwrap("A", "#"));
    }

    @Test
    public void testUpperCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
    }

    @Test
    public void testUpperCaseLocale() {
        assertNull(StringUtils.upperCase(null, Locale.ENGLISH));
        assertEquals("ABC", StringUtils.upperCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    @Test
    public void testWrapChar() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("'ab'", StringUtils.wrap("ab", '\''));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", '\"'));
    }

    @Test
    public void testWrapString() {
        assertNull(StringUtils.wrap(null, "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", "\""));
        assertEquals("'abcd''", StringUtils.wrap("abcd'", "'"));
    }

    @Test
    public void testWrapIfMissingChar() {
        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("", StringUtils.wrapIfMissing("", 'x'));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", '\0'));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", 'x'));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", '\"'));
        assertEquals("/", StringUtils.wrapIfMissing("/", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("/a/b/c", '/'));
    }

    @Test
    public void testWrapIfMissingString() {
        assertNull(StringUtils.wrapIfMissing(null, "x"));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", (String) null));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", "x"));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", "\""));
        assertEquals("'abcd'", StringUtils.wrapIfMissing("'abcd'", "'"));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c/", "/"));
    }

    @Test
    public void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, null));
        assertEquals("abc", StringUtils.appendIfMissing("abc", null));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", StringUtils.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissingIgnoreCase() {
        assertNull(StringUtils.appendIfMissingIgnoreCase(null, null));
        assertEquals("abcxyz", StringUtils.appendIfMissingIgnoreCase("abc", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));
    }

    @Test
    public void testIsAllLowerUpperCaseBoundaryLengthOne() {
        assertTrue(StringUtils.isAllLowerCase("a"));
        assertTrue(StringUtils.isAllUpperCase("A"));
    }
}
