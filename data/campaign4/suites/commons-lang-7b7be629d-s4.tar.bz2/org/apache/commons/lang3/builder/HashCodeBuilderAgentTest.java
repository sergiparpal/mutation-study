package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Self-contained tests for {@link HashCodeBuilder} based solely on its documented contract.
 */
public class HashCodeBuilderAgentTest {

    // Fixtures used by the reflection based tests. Kept inside this file so the
    // test class remains self-contained.

    private static class SimpleFixture {
        @SuppressWarnings("unused")
        private final int a;
        @SuppressWarnings("unused")
        private final int b;

        SimpleFixture(int a, int b) {
            this.a = a;
            this.b = b;
        }
    }

    private static class TransientFixture {
        @SuppressWarnings("unused")
        private final int a;
        @SuppressWarnings("unused")
        private transient int t;

        TransientFixture(int a, int t) {
            this.a = a;
            this.t = t;
        }
    }

    private static class ParentFixture {
        @SuppressWarnings("unused")
        private final int p;

        ParentFixture(int p) {
            this.p = p;
        }
    }

    private static class ChildFixture extends ParentFixture {
        @SuppressWarnings("unused")
        private final int c;

        ChildFixture(int p, int c) {
            super(p);
            this.c = c;
        }
    }

    private static class StaticFieldFixture {
        @SuppressWarnings("unused")
        private final int a;
        static int s = 0;

        StaticFieldFixture(int a) {
            this.a = a;
        }
    }

    // ----------------------------------------------------------------
    // Constructors
    // ----------------------------------------------------------------

    @Test
    public void testDefaultConstructorIsDeterministic() {
        HashCodeBuilder builder = new HashCodeBuilder();
        int first = builder.toHashCode();
        int second = builder.toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testTwoArgConstructorRejectsEvenInitialNumber() {
        try {
            new HashCodeBuilder(16, 37);
            fail("Expected IllegalArgumentException for even initial number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testTwoArgConstructorRejectsEvenMultiplierNumber() {
        try {
            new HashCodeBuilder(17, 38);
            fail("Expected IllegalArgumentException for even multiplier number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testTwoArgConstructorRejectsBothEvenNumbers() {
        try {
            new HashCodeBuilder(16, 38);
            fail("Expected IllegalArgumentException for two even numbers");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testTwoArgConstructorAcceptsOddNumbersIncludingNegative() {
        HashCodeBuilder builder = new HashCodeBuilder(-17, -37);
        // must not throw, and must follow the documented formula.
        assertEquals(-17 * -37 + 45, builder.append(45).toHashCode());
    }

    // ----------------------------------------------------------------
    // append(int) / the documented worked example from the class javadoc
    // ----------------------------------------------------------------

    @Test
    public void testAppendIntMatchesDocumentedExample() {
        // "if the current hashCode is 17, and the multiplier is 37, then appending
        // the integer 45 will create a hash code of 674, namely 17 * 37 + 45."
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        int result = builder.append(45).toHashCode();
        assertEquals(674, result);
    }

    @Test
    public void testAppendIntAccumulatesMultiplicatively() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(45);
        int afterFirst = builder.toHashCode();
        assertEquals(674, afterFirst);

        builder.append(45);
        int afterSecond = builder.toHashCode();
        assertEquals(afterFirst * 37 + 45, afterSecond);
    }

    @Test
    public void testAppendReturnsSameInstanceForFluentChaining() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        assertSame(builder, builder.append(1));
        assertSame(builder, builder.append(true));
        assertSame(builder, builder.append((byte) 1));
        assertSame(builder, builder.append((char) 'x'));
        assertSame(builder, builder.append((short) 1));
        assertSame(builder, builder.append(1L));
        assertSame(builder, builder.append(1.0f));
        assertSame(builder, builder.append(1.0d));
        assertSame(builder, builder.append(new Object()));
        assertSame(builder, builder.append(new int[] {1, 2}));
        assertSame(builder, builder.append(new boolean[] {true, false}));
        assertSame(builder, builder.append(new byte[] {1, 2}));
        assertSame(builder, builder.append(new char[] {'a', 'b'}));
        assertSame(builder, builder.append(new short[] {1, 2}));
        assertSame(builder, builder.append(new long[] {1L, 2L}));
        assertSame(builder, builder.append(new float[] {1.0f}));
        assertSame(builder, builder.append(new double[] {1.0d}));
        assertSame(builder, builder.append(new Object[] {"x", "y"}));
        assertSame(builder, builder.appendSuper(1));
    }

    // ----------------------------------------------------------------
    // append(boolean): documented to add 1 for true and 0 for false.
    // ----------------------------------------------------------------

    @Test
    public void testAppendBooleanTrueAddsOne() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        int result = builder.append(true).toHashCode();
        assertEquals(17 * 37 + 1, result);
    }

    @Test
    public void testAppendBooleanFalseAddsZero() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        int result = builder.append(false).toHashCode();
        assertEquals(17 * 37, result);
    }

    @Test
    public void testAppendBooleanDiffersFromAppendBooleanFalse() {
        int trueResult = new HashCodeBuilder(17, 37).append(true).toHashCode();
        int falseResult = new HashCodeBuilder(17, 37).append(false).toHashCode();
        assertNotEquals(trueResult, falseResult);
    }

    // ----------------------------------------------------------------
    // appendSuper: adds the super hashCode using the same int based formula.
    // ----------------------------------------------------------------

    @Test
    public void testAppendSuperFollowsSameFormulaAsAppendInt() {
        int viaAppendSuper = new HashCodeBuilder(17, 37).appendSuper(45).toHashCode();
        int viaAppendInt = new HashCodeBuilder(17, 37).append(45).toHashCode();
        assertEquals(viaAppendInt, viaAppendSuper);
    }

    // ----------------------------------------------------------------
    // builder() factory method
    // ----------------------------------------------------------------

    @Test
    public void testBuilderFactoryReturnsUsableBuilder() {
        HashCodeBuilder.Builder factory = HashCodeBuilder.builder();
        assertNotNull(factory);

        HashCodeBuilder built = factory.setInitialOddNumber(17).setMultiplierOddNumber(37).get();
        assertNotNull(built);
        assertEquals(674, built.append(45).toHashCode());
    }

    // ----------------------------------------------------------------
    // build() / toHashCode() / hashCode()
    // ----------------------------------------------------------------

    @Test
    public void testBuildReturnsBoxedToHashCode() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(45);
        Integer built = builder.build();
        assertEquals(Integer.valueOf(674), built);
        assertEquals(builder.toHashCode(), built.intValue());
    }

    @Test
    public void testHashCodeMethodDelegatesToToHashCode() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(45).append(true);
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    // ----------------------------------------------------------------
    // equals(Object): "Implements equals using the hash code."
    // ----------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(45);
        assertTrue(builder.equals(builder));
    }

    @Test
    public void testEqualsTrueForEqualComputedHashCodes() {
        HashCodeBuilder a = new HashCodeBuilder(17, 37).append(45);
        HashCodeBuilder b = new HashCodeBuilder(17, 37).append(45);
        assertEquals(a.toHashCode(), b.toHashCode());
        assertTrue(a.equals(b));
    }

    @Test
    public void testEqualsFalseForDifferentComputedHashCodes() {
        HashCodeBuilder a = new HashCodeBuilder(17, 37).append(45);
        HashCodeBuilder b = new HashCodeBuilder(17, 37).append(46);
        assertNotEquals(a.toHashCode(), b.toHashCode());
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForNull() {
        HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(45);
        assertFalse(builder.equals(null));
    }

    // ----------------------------------------------------------------
    // reflectionHashCode(Object, boolean)
    // ----------------------------------------------------------------

    @Test
    public void testReflectionHashCodeConstantWhenNoFieldsFound() {
        int first = HashCodeBuilder.reflectionHashCode(new Object(), false);
        int second = HashCodeBuilder.reflectionHashCode(new Object(), false);
        assertEquals(first, second);
    }

    @Test
    public void testReflectionHashCodeTwoArgNullObjectThrowsNpe() {
        try {
            HashCodeBuilder.reflectionHashCode(null, false);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeIgnoresTransientFieldsWhenNotRequested() {
        TransientFixture withLowTransient = new TransientFixture(1, 100);
        TransientFixture withHighTransient = new TransientFixture(1, 200);
        int hashLow = HashCodeBuilder.reflectionHashCode(withLowTransient, false);
        int hashHigh = HashCodeBuilder.reflectionHashCode(withHighTransient, false);
        assertEquals(hashLow, hashHigh);
    }

    @Test
    public void testReflectionHashCodeIncludesTransientFieldsWhenRequested() {
        TransientFixture withLowTransient = new TransientFixture(1, 100);
        TransientFixture withHighTransient = new TransientFixture(1, 200);
        int hashLow = HashCodeBuilder.reflectionHashCode(withLowTransient, true);
        int hashHigh = HashCodeBuilder.reflectionHashCode(withHighTransient, true);
        assertNotEquals(hashLow, hashHigh);
    }

    // ----------------------------------------------------------------
    // reflectionHashCode(Object, String...) / (Object, Collection<String>)
    // ----------------------------------------------------------------

    @Test
    public void testReflectionHashCodeDiffersWhenFieldsDiffer() {
        SimpleFixture s1 = new SimpleFixture(1, 2);
        SimpleFixture s2 = new SimpleFixture(1, 3);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(s1), HashCodeBuilder.reflectionHashCode(s2));
    }

    @Test
    public void testReflectionHashCodeVarargsExcludeFieldMakesHashesEqual() {
        SimpleFixture s1 = new SimpleFixture(1, 2);
        SimpleFixture s2 = new SimpleFixture(1, 3);
        int hashExcludingB1 = HashCodeBuilder.reflectionHashCode(s1, "b");
        int hashExcludingB2 = HashCodeBuilder.reflectionHashCode(s2, "b");
        assertEquals(hashExcludingB1, hashExcludingB2);
    }

    @Test
    public void testReflectionHashCodeCollectionExcludeFieldMakesHashesEqual() {
        SimpleFixture s1 = new SimpleFixture(1, 2);
        SimpleFixture s2 = new SimpleFixture(1, 3);
        List<String> excludeFields = new ArrayList<String>();
        excludeFields.add("b");
        int hashExcludingB1 = HashCodeBuilder.reflectionHashCode(s1, excludeFields);
        int hashExcludingB2 = HashCodeBuilder.reflectionHashCode(s2, excludeFields);
        assertEquals(hashExcludingB1, hashExcludingB2);
    }

    @Test
    public void testReflectionHashCodeVarargsNullObjectThrowsNpe() {
        try {
            HashCodeBuilder.reflectionHashCode(null, "field");
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeCollectionNullObjectThrowsNpe() {
        try {
            HashCodeBuilder.reflectionHashCode(null, Collections.<String>emptyList());
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeIgnoresStaticFields() {
        StaticFieldFixture fixture = new StaticFieldFixture(5);
        int before = HashCodeBuilder.reflectionHashCode(fixture);
        StaticFieldFixture.s = 999;
        int after = HashCodeBuilder.reflectionHashCode(fixture);
        assertEquals(before, after);
    }

    // ----------------------------------------------------------------
    // reflectionHashCode(int, int, Object)
    // ----------------------------------------------------------------

    @Test
    public void testReflectionHashCodeThreeArgRejectsZeroInitialNumber() {
        try {
            HashCodeBuilder.reflectionHashCode(0, 37, new Object());
            fail("Expected IllegalArgumentException for zero initial number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeThreeArgRejectsEvenInitialNumber() {
        try {
            HashCodeBuilder.reflectionHashCode(18, 37, new Object());
            fail("Expected IllegalArgumentException for even initial number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeThreeArgRejectsEvenMultiplierNumber() {
        try {
            HashCodeBuilder.reflectionHashCode(17, 38, new Object());
            fail("Expected IllegalArgumentException for even multiplier number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeThreeArgNullObjectThrowsNpe() {
        try {
            HashCodeBuilder.reflectionHashCode(17, 37, null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeThreeArgIsDeterministic() {
        SimpleFixture fixture = new SimpleFixture(1, 2);
        int first = HashCodeBuilder.reflectionHashCode(17, 37, fixture);
        int second = HashCodeBuilder.reflectionHashCode(17, 37, fixture);
        assertEquals(first, second);
    }

    // ----------------------------------------------------------------
    // reflectionHashCode(int, int, Object, boolean)
    // ----------------------------------------------------------------

    @Test
    public void testReflectionHashCodeFourArgNullObjectThrowsNpe() {
        try {
            HashCodeBuilder.reflectionHashCode(17, 37, null, false);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeFourArgRejectsEvenNumber() {
        try {
            HashCodeBuilder.reflectionHashCode(17, 38, new Object(), false);
            fail("Expected IllegalArgumentException for even multiplier number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ----------------------------------------------------------------
    // reflectionHashCode(int, int, T, boolean, Class, String...)
    // ----------------------------------------------------------------

    @Test
    public void testReflectionHashCodeWithReflectUpToClassLimitsSuperclassFields() {
        ChildFixture childWithParentOne = new ChildFixture(1, 2);
        ChildFixture childWithParentNine = new ChildFixture(9, 2);

        int includingParentOne = HashCodeBuilder.reflectionHashCode(
                17, 37, childWithParentOne, false, ParentFixture.class);
        int includingParentNine = HashCodeBuilder.reflectionHashCode(
                17, 37, childWithParentNine, false, ParentFixture.class);
        assertNotEquals(includingParentOne, includingParentNine);

        int excludingParentOne = HashCodeBuilder.reflectionHashCode(
                17, 37, childWithParentOne, false, ChildFixture.class);
        int excludingParentNine = HashCodeBuilder.reflectionHashCode(
                17, 37, childWithParentNine, false, ChildFixture.class);
        assertEquals(excludingParentOne, excludingParentNine);
    }

    @Test
    public void testReflectionHashCodeNullReflectUpToClassTreatedAsObject() {
        ChildFixture child = new ChildFixture(1, 2);
        int withNull = HashCodeBuilder.reflectionHashCode(17, 37, child, false, null);
        int withObjectClass = HashCodeBuilder.reflectionHashCode(17, 37, child, false, Object.class);
        assertEquals(withObjectClass, withNull);
    }

    @Test
    public void testReflectionHashCodeSixArgNullObjectThrowsNpe() {
        try {
            HashCodeBuilder.reflectionHashCode(17, 37, null, false, Object.class);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeSixArgRejectsEvenNumber() {
        try {
            HashCodeBuilder.reflectionHashCode(16, 37, new SimpleFixture(1, 2), false, Object.class);
            fail("Expected IllegalArgumentException for even initial number");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testReflectionHashCodeSixArgExcludeFieldsMakesHashesEqual() {
        SimpleFixture s1 = new SimpleFixture(1, 2);
        SimpleFixture s2 = new SimpleFixture(1, 3);
        int hashExcludingB1 = HashCodeBuilder.reflectionHashCode(
                17, 37, s1, false, Object.class, "b");
        int hashExcludingB2 = HashCodeBuilder.reflectionHashCode(
                17, 37, s2, false, Object.class, "b");
        assertEquals(hashExcludingB1, hashExcludingB2);
    }

    // ----------------------------------------------------------------
    // package-private registry helpers (reachable since this test class
    // lives in the same package).
    // ----------------------------------------------------------------

    @Test
    public void testIsRegisteredFalseForObjectNotBeingTraversed() {
        assertFalse(HashCodeBuilder.isRegistered(new Object()));
    }

    @Test
    public void testGetRegistryReturnsNonNullSetWithoutUntrackedObject() {
        Set registry = HashCodeBuilder.getRegistry();
        assertNotNull(registry);
        assertFalse(registry.contains(new Object()));
    }
}
