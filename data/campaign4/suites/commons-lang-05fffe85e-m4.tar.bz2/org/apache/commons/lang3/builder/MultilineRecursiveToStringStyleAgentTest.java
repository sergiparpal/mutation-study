/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MultilineRecursiveToStringStyle}.
 *
 * <p>
 * Tests call the protected {@code appendDetail}/{@code reflectionAppendArrayDetail} methods directly
 * (this test lives in the same package) to assert on the exact buffer content produced, independently
 * of {@link ToStringBuilder}/{@link ReflectionToStringBuilder} scaffolding.
 * </p>
 */
public class MultilineRecursiveToStringStyleAgentTest {

    /** Simple fixture with a single field, used to check object recursion formatting. */
    private static final class Fixture {
        @SuppressWarnings("unused")
        String title = "Manager";
    }

    private static String header(final Object o) {
        return o.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(o));
    }

    @Test
    public void testAppendDetailIntArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new int[] { 1, 2, 3 });
        assertEquals("{\n    1,\n    2,\n    3\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailBooleanArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new boolean[] { true, false });
        assertEquals("{\n    true,\n    false\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailByteArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new byte[] { 1, 2 });
        assertEquals("{\n    1,\n    2\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailCharArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new char[] { 'a', 'b' });
        assertEquals("{\n    a,\n    b\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailDoubleArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new double[] { 1.5, 2.5 });
        assertEquals("{\n    1.5,\n    2.5\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailFloatArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new float[] { 1.5f, 2.5f });
        assertEquals("{\n    1.5,\n    2.5\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailLongArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new long[] { 10L, 20L });
        assertEquals("{\n    10,\n    20\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailShortArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new short[] { 3, 4 });
        assertEquals("{\n    3,\n    4\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailObjectArrayOfStrings() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new Object[] { "a", "b" });
        assertEquals("{\n    a,\n    b\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailEmptyArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new int[0]);
        assertEquals("{\n    \n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailNestedObjectArrayIndentsEachLevel() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new Object[] { new int[] { 1, 2 }, "x" });
        assertEquals("{\n    {\n      1,\n      2\n    },\n    x\n  }", buffer.toString());
    }

    @Test
    public void testAppendDetailNullArrayThrowsAndLeaksIndentState() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer failing = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                style.appendDetail(failing, "f", (int[]) null);
            }
        });
        // The spaces increment is not restored (no finally), so the next call uses deeper indent.
        final StringBuffer next = new StringBuffer();
        style.appendDetail(next, "f", new int[] { 9 });
        assertEquals("{\n      9\n    }", next.toString());
    }

    @Test
    public void testAppendDetailDoesNotLeakIndentOnSuccessiveSuccessfulCalls() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer first = new StringBuffer();
        style.appendDetail(first, "f", new int[] { 1 });
        final StringBuffer second = new StringBuffer();
        style.appendDetail(second, "f", new int[] { 2 });
        assertEquals("{\n    1\n  }", first.toString());
        assertEquals("{\n    2\n  }", second.toString());
    }

    @Test
    public void testAppendDetailObjectNullValue() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", (Object) null);
        assertEquals("null", buffer.toString());
    }

    @Test
    public void testAppendDetailObjectStringValueNotRecursed() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", (Object) "hello");
        assertEquals("hello", buffer.toString());
    }

    @Test
    public void testAppendDetailObjectPrimitiveWrapperNotRecursed() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", Integer.valueOf(42));
        assertEquals("42", buffer.toString());
    }

    @Test
    public void testAppendDetailObjectNumberSubclassNotRecursed() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new BigDecimal("3.14"));
        assertEquals("3.14", buffer.toString());
    }

    @Test
    public void testAppendDetailObjectAtomicBooleanNotRecursed() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "f", new AtomicBoolean(true));
        assertEquals("true", buffer.toString());
    }

    @Test
    public void testAppendDetailObjectCustomPojoRecursedWithIncreasedIndent() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final Fixture fixture = new Fixture();
        style.appendDetail(buffer, "f", (Object) fixture);
        final String expected = header(fixture) + "[\n    title=Manager\n  ]";
        assertEquals(expected, buffer.toString());
    }

    @Test
    public void testReflectionAppendArrayDetailDirect() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.reflectionAppendArrayDetail(buffer, null, new int[] { 7, 8, 9 });
        assertEquals("{\n    7,\n    8,\n    9\n  }", buffer.toString());
    }

    @Test
    public void testIntegrationWithToStringBuilderOrdersFieldsAtBaseIndent() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final Fixture job = new Fixture();
        final Object root = new Object();
        final String s = new ToStringBuilder(root, style)
                .append("name", "Stephen")
                .append("age", 29)
                .append("ints", new int[] { 1, 2 })
                .append("job", job)
                .toString();

        final String expected = header(root)
                + "[\n"
                + "  name=Stephen,\n"
                + "  age=29,\n"
                + "  ints={\n"
                + "    1,\n"
                + "    2\n"
                + "  },\n"
                + "  job=" + header(job) + "[\n    title=Manager\n  ]\n"
                + "]";
        assertEquals(expected, s);
    }

    @Test
    public void testIntegrationWithReflectionToStringBuilderOnSingleFieldPojo() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final Fixture fixture = new Fixture();
        final String s = new ReflectionToStringBuilder(fixture, style).toString();
        assertEquals(header(fixture) + "[\n  title=Manager\n]", s);
    }

    @Test
    public void testIntegrationWithReflectionToStringBuilderOnTopLevelArray() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final int[] array = { 7, 8, 9 };
        final String s = new ReflectionToStringBuilder(array, style).toString();
        assertEquals(header(array) + "[\n  {\n    7,\n    8,\n    9\n  }\n]", s);
    }

    @Test
    public void testStyleInstancesAreIndependent() {
        final MultilineRecursiveToStringStyle styleA = new MultilineRecursiveToStringStyle();
        final MultilineRecursiveToStringStyle styleB = new MultilineRecursiveToStringStyle();

        final StringBuffer leaking = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                styleA.appendDetail(leaking, "f", (int[]) null);
            }
        });

        // styleB was never touched, so it must still use the base indent.
        final StringBuffer fresh = new StringBuffer();
        styleB.appendDetail(fresh, "f", new int[] { 1 });
        assertEquals("{\n    1\n  }", fresh.toString());
    }

    @Test
    public void testConstructorAppliesDefaultTwoSpaceBaseIndent() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        assertEquals("[" + System.lineSeparator() + "  ", style.getContentStart());
        assertEquals(System.lineSeparator() + "]", style.getContentEnd());
        assertEquals("{" + System.lineSeparator() + "  ", style.getArrayStart());
        assertEquals(System.lineSeparator() + "}", style.getArrayEnd());
        assertTrue(style.isUseClassName());
    }
}
