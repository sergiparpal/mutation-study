package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TimedSemaphore}, based solely on its documented contract.
 */
public class TimedSemaphoreAgentTest {

    private static final long PERIOD = 5;
    private static final TimeUnit UNIT = TimeUnit.SECONDS;

    // ---- construction / validation ----------------------------------------------------------

    @Test
    public void testDeprecatedConstructorRejectsZeroPeriod() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new TimedSemaphore(0, UNIT, 10);
            }
        });
    }

    @Test
    public void testDeprecatedConstructorRejectsNegativePeriod() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new TimedSemaphore(-1, UNIT, 10);
            }
        });
    }

    @Test
    public void testDeprecatedConstructorWithServiceRejectsZeroPeriod() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new TimedSemaphore(null, 0, UNIT, 10);
            }
        });
    }

    @Test
    public void testDeprecatedConstructorWithNullServiceCreatesDefaultExecutor() {
        TimedSemaphore sem = new TimedSemaphore(null, PERIOD, UNIT, 10);
        try {
            assertNotNull(sem.getExecutorService());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testDeprecatedConstructorWithServiceUsesProvidedExecutor() {
        ScheduledExecutorService service = Executors.newScheduledThreadPool(1);
        TimedSemaphore sem = new TimedSemaphore(service, PERIOD, UNIT, 10);
        try {
            assertSame(service, sem.getExecutorService());
        } finally {
            sem.shutdown();
            service.shutdown();
        }
    }

    @Test
    public void testGetPeriodUnitAndLimitReflectConstructorArgs() {
        TimedSemaphore sem = new TimedSemaphore(250, TimeUnit.MILLISECONDS, 7);
        try {
            assertEquals(250L, sem.getPeriod());
            assertEquals(TimeUnit.MILLISECONDS, sem.getUnit());
            assertEquals(7, sem.getLimit());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testNoLimitConstantIsZero() {
        assertEquals(0, TimedSemaphore.NO_LIMIT);
    }

    // ---- initial state ------------------------------------------------------------------------

    @Test
    public void testInitialStateBeforeAnyAcquire() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 5);
        try {
            assertEquals(0, sem.getAcquireCount());
            assertEquals(5, sem.getAvailablePermits());
            assertEquals(0, sem.getLastAcquiresPerPeriod());
            assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0001d);
            assertFalse(sem.isShutdown());
        } finally {
            sem.shutdown();
        }
    }

    // ---- limit management ----------------------------------------------------------------------

    @Test
    public void testSetLimitUpdatesLimit() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 5);
        try {
            sem.setLimit(20);
            assertEquals(20, sem.getLimit());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testSetLimitToNoLimitDisablesBlocking() throws InterruptedException {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 1);
        try {
            sem.setLimit(TimedSemaphore.NO_LIMIT);
            assertEquals(TimedSemaphore.NO_LIMIT, sem.getLimit());
            for (int i = 0; i < 50; i++) {
                assertTrue(sem.tryAcquire());
            }
        } finally {
            sem.shutdown();
        }
    }

    // ---- acquire / tryAcquire behavior ----------------------------------------------------------

    @Test
    public void testTryAcquireRespectsLimitAndUpdatesCounters() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 2);
        try {
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertFalse(sem.tryAcquire());
            assertEquals(2, sem.getAcquireCount());
            assertEquals(0, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testAcquireIncrementsCountAndDecrementsAvailablePermits() throws InterruptedException {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 3);
        try {
            sem.acquire();
            assertEquals(1, sem.getAcquireCount());
            assertEquals(2, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testAcquireBlocksUntilPeriodElapsesThenSucceeds() throws InterruptedException {
        final long periodMillis = 150;
        final TimedSemaphore sem = new TimedSemaphore(periodMillis, TimeUnit.MILLISECONDS, 1);
        try {
            sem.acquire();
            assertEquals(1, sem.getAcquireCount());

            final CountDownLatch started = new CountDownLatch(1);
            final CountDownLatch finished = new CountDownLatch(1);
            final long[] elapsedNanos = new long[1];

            Thread blockedAcquirer = new Thread(new Runnable() {
                @Override
                public void run() {
                    started.countDown();
                    long startTime = System.nanoTime();
                    try {
                        sem.acquire();
                        elapsedNanos[0] = System.nanoTime() - startTime;
                        finished.countDown();
                    } catch (InterruptedException e) {
                        // propagate as test failure by leaving finished uncounted
                    }
                }
            });
            blockedAcquirer.start();
            assertTrue(started.await(2, TimeUnit.SECONDS));

            boolean completed = finished.await(2, TimeUnit.SECONDS);
            blockedAcquirer.join(2000);

            assertTrue(completed, "second acquire() should unblock once the period elapses");
            long elapsedMillis = elapsedNanos[0] / 1000000L;
            assertTrue(elapsedMillis >= periodMillis / 2,
                    "acquire() returned too quickly to have waited for the next period: " + elapsedMillis + "ms");
        } finally {
            sem.shutdown();
        }
    }

    // ---- shutdown -------------------------------------------------------------------------------

    @Test
    public void testShutdownSetsFlagAndIsIdempotent() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 5);
        assertFalse(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
    }

    @Test
    public void testAcquireAfterShutdownThrowsIllegalStateException() {
        final TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 5);
        sem.shutdown();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sem.acquire();
            }
        });
    }

    @Test
    public void testTryAcquireAfterShutdownThrowsIllegalStateException() {
        final TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 5);
        sem.shutdown();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sem.tryAcquire();
            }
        });
    }

    // ---- package-private / protected hooks (same package access) --------------------------------

    @Test
    public void testEndOfPeriodResetsCounterAndUpdatesLastAcquiresPerPeriod() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 10);
        try {
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertEquals(3, sem.getAcquireCount());

            sem.endOfPeriod();

            assertEquals(0, sem.getAcquireCount());
            assertEquals(3, sem.getLastAcquiresPerPeriod());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testGetAverageCallsPerPeriodAfterOnePeriod() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 10);
        try {
            sem.tryAcquire();
            sem.tryAcquire();
            sem.tryAcquire();
            sem.endOfPeriod();

            assertEquals(3.0d, sem.getAverageCallsPerPeriod(), 0.0001d);
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testStartTimerReturnsNonNullFuture() {
        TimedSemaphore sem = new TimedSemaphore(PERIOD, UNIT, 10);
        try {
            ScheduledFuture<?> future = sem.startTimer();
            assertNotNull(future);
            assertFalse(future.isDone());
        } finally {
            sem.shutdown();
        }
    }

    // ---- builder ----------------------------------------------------------------------------------

    @Test
    public void testBuilderCreatesSemaphoreWithConfiguredValues() {
        TimedSemaphore sem = TimedSemaphore.builder()
                .setPeriod(400)
                .setTimeUnit(TimeUnit.MILLISECONDS)
                .setLimit(9)
                .get();
        try {
            assertEquals(400L, sem.getPeriod());
            assertEquals(TimeUnit.MILLISECONDS, sem.getUnit());
            assertEquals(9, sem.getLimit());
            assertFalse(sem.isShutdown());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    public void testBuilderSetServiceIsUsedByCreatedSemaphore() {
        ScheduledExecutorService service = Executors.newScheduledThreadPool(1);
        TimedSemaphore sem = TimedSemaphore.builder()
                .setPeriod(PERIOD)
                .setTimeUnit(UNIT)
                .setLimit(1)
                .setService(service)
                .get();
        try {
            assertSame(service, sem.getExecutorService());
        } finally {
            sem.shutdown();
            service.shutdown();
        }
    }

    @Test
    public void testBuilderRejectsNonPositivePeriod() {
        final TimedSemaphore.Builder builder = TimedSemaphore.builder()
                .setPeriod(0)
                .setTimeUnit(UNIT)
                .setLimit(5);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.get();
            }
        });
    }
}
