package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ClassUtilsAgentTest {

    interface Alpha {
    }

    interface Beta extends Alpha {
    }

    static class Base implements Beta {
    }

    static class Derived extends Base implements Comparable<Derived> {
        public int compareTo(Derived other) {
            return 0;
        }
    }

    static class PackagePrivateNested {
    }

    private static class PrivateNested {
    }

    class NonStaticInner {
    }

    static class StaticNested {
    }

    // ---- fields ----

    @Test
    public void testFields() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    // ---- deprecated constructor ----

    @SuppressWarnings("deprecation")
    @Test
    public void testConstructor() {
        assertNotNull(new ClassUtils());
    }

    // ---- comparator() ----

    @Test
    public void testComparator() {
        Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        assertTrue(comparator.compare(Integer.class, String.class) < 0);
        assertTrue(comparator.compare(String.class, Integer.class) > 0);
        assertEquals(0, comparator.compare(String.class, String.class));

        List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        Collections.sort(list, comparator);
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    // ---- convertClassesToClassNames(List) ----

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));

        List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        classes.add(Integer.class);
        List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(3, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
        assertEquals("java.lang.Integer", names.get(2));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testConvertClassesToClassNamesClassCastException() {
        List raw = new ArrayList();
        raw.add("notAClass");
        final List<Class<?>> badList = raw;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.convertClassesToClassNames(badList);
            }
        });
    }

    // ---- convertClassNamesToClasses(List) ----

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));

        List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add(null);
        names.add("no.such.ClassExists");
        List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testConvertClassNamesToClassesClassCastException() {
        List raw = new ArrayList();
        raw.add(Integer.valueOf(1));
        final List<String> badList = raw;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.convertClassNamesToClasses(badList);
            }
        });
    }

    // ---- getAbbreviatedName(Class, int) ----

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
    }

    // ---- getAbbreviatedName(String, int) ----

    @Test
    public void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    // ---- getAllInterfaces(Class) ----

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));

        List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Derived.class);
        Set<Class<?>> expected = new HashSet<Class<?>>();
        expected.add(Alpha.class);
        expected.add(Beta.class);
        expected.add(Comparable.class);
        assertEquals(expected.size(), interfaces.size());
        assertEquals(expected, new HashSet<Class<?>>(interfaces));
    }

    // ---- getAllSuperclasses(Class) ----

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));

        List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Derived.class);
        assertEquals(Arrays.asList(Base.class, Object.class), superclasses);
    }

    // ---- getCanonicalName ----

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("java.util.Map.Entry", ClassUtils.getCanonicalName(Map.Entry.class));
    }

    @Test
    public void testGetCanonicalNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "NULL"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc"));
    }

    @Test
    public void testGetCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc", "NULL"));
    }

    // ---- getClass(ClassLoader, String[, boolean]) ----

    @Test
    public void testGetClassClassLoaderString() throws ClassNotFoundException {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        assertEquals(String.class, ClassUtils.getClass(cl, "java.lang.String"));
        assertEquals(String[].class, ClassUtils.getClass(cl, "java.lang.String[]"));
        assertEquals(Map.Entry[].class, ClassUtils.getClass(cl, "java.util.Map.Entry[]"));
        assertEquals(Map.Entry[].class, ClassUtils.getClass(cl, "java.util.Map$Entry[]"));
        assertEquals(String[].class, ClassUtils.getClass(cl, "[Ljava.lang.String;"));

        assertThrows(ClassNotFoundException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass(Thread.currentThread().getContextClassLoader(), "no.such.ClassExists");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass(Thread.currentThread().getContextClassLoader(), (String) null);
            }
        });
    }

    @Test
    public void testGetClassClassLoaderStringBoolean() throws ClassNotFoundException {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        assertEquals(String.class, ClassUtils.getClass(cl, "java.lang.String", false));
        assertEquals(String.class, ClassUtils.getClass(cl, "java.lang.String", true));
    }

    @Test
    public void testGetClassString() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertThrows(ClassNotFoundException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass("no.such.ClassExists");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassStringBoolean() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", false));
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", true));
    }

    // ---- getComponentType ----

    @Test
    public void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
        Class<Object[]> nullArrayClass = null;
        assertNull(ClassUtils.getComponentType(nullArrayClass));
    }

    // ---- getName ----

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "NULL"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("abc"));
    }

    @Test
    public void testGetNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName("abc", "NULL"));
    }

    // ---- getPackageCanonicalName ----

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("abc", "NULL"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageCanonicalName("Foo"));
    }

    // ---- getPackageName ----

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageName("abc", "NULL"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName("Foo"));
    }

    // ---- getPrimitiveClass (package-private) ----

    @Test
    public void testGetPrimitiveClass() {
        assertEquals(byte.class, ClassUtils.getPrimitiveClass("byte"));
        assertEquals(int.class, ClassUtils.getPrimitiveClass("int"));
        assertEquals(boolean.class, ClassUtils.getPrimitiveClass("boolean"));
    }

    // ---- getPublicMethod ----

    @Test
    public void testGetPublicMethod() throws Exception {
        Set<String> set = Collections.unmodifiableSet(new HashSet<String>());
        Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty", new Class[0]);
        assertNotNull(method);
        assertTrue(((Boolean) method.invoke(set, new Object[0])).booleanValue());
        assertTrue(java.lang.reflect.Modifier.isPublic(method.getDeclaringClass().getModifiers()));

        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodHere", new Class[0]);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "isEmpty", new Class[0]);
            }
        });
    }

    // ---- getShortCanonicalName ----

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class));
    }

    @Test
    public void testGetShortCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortCanonicalName("abc", "NULL"));
    }

    @Test
    public void testGetShortCanonicalNameString() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("Map.Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getName()));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getCanonicalName()));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[]"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[][]"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class.getCanonicalName()));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class.getName()));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("[[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("int[]"));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("int[][]"));
    }

    // ---- getShortClassName ----

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
    }

    @Test
    public void testGetShortClassNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortClassName("abc", "NULL"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    // ---- getSimpleName ----

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("Entry", ClassUtils.getSimpleName(Map.Entry.class));
    }

    @Test
    public void testGetSimpleNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName(String.class, "NULL"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("abc"));
    }

    @Test
    public void testGetSimpleNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName("abc", "NULL"));
    }

    // ---- hierarchy ----

    @Test
    public void testHierarchy() {
        List<Class<?>> list = new ArrayList<Class<?>>();
        for (Class<?> c : ClassUtils.hierarchy(Derived.class)) {
            list.add(c);
        }
        assertEquals(Arrays.asList(Derived.class, Base.class, Object.class), list);
    }

    @Test
    public void testHierarchyExclude() {
        List<Class<?>> list = new ArrayList<Class<?>>();
        for (Class<?> c : ClassUtils.hierarchy(Derived.class, ClassUtils.Interfaces.EXCLUDE)) {
            list.add(c);
        }
        assertEquals(Arrays.asList(Derived.class, Base.class, Object.class), list);
    }

    @Test
    public void testHierarchyInclude() {
        Set<Class<?>> set = new HashSet<Class<?>>();
        Class<?> first = null;
        for (Class<?> c : ClassUtils.hierarchy(Derived.class, ClassUtils.Interfaces.INCLUDE)) {
            if (first == null) {
                first = c;
            }
            set.add(c);
        }
        assertEquals(Derived.class, first);
        Set<Class<?>> expected = new HashSet<Class<?>>();
        expected.add(Derived.class);
        expected.add(Base.class);
        expected.add(Object.class);
        expected.add(Alpha.class);
        expected.add(Beta.class);
        expected.add(Comparable.class);
        assertEquals(expected, set);
    }

    // ---- isAssignable(Class, Class) ----

    @Test
    public void testIsAssignableClassClass() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
    }

    // ---- isAssignable(Class, Class, boolean) ----

    @Test
    public void testIsAssignableClassClassBoolean() {
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
        assertTrue(ClassUtils.isAssignable(int.class, int.class, false));
    }

    // ---- isAssignable(Class[], Class...) ----

    @Test
    public void testIsAssignableArray() {
        assertTrue(ClassUtils.isAssignable(new Class[] { String.class, Integer.class },
                new Class[] { Object.class, Number.class }));
        assertFalse(ClassUtils.isAssignable(new Class[] { String.class },
                new Class[] { Integer.class }));
    }

    // ---- isAssignable(Class[], Class[], boolean) ----

    @Test
    public void testIsAssignableArrayBoolean() {
        assertFalse(ClassUtils.isAssignable(new Class[] { Integer.class }, new Class[] { int.class }, false));
        assertTrue(ClassUtils.isAssignable(new Class[] { Integer.class }, new Class[] { int.class }, true));
        assertFalse(ClassUtils.isAssignable(new Class[] { int.class }, new Class[] { int.class, long.class }, true));
    }

    // ---- isInnerClass ----

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(StaticNested.class));
        assertTrue(ClassUtils.isInnerClass(NonStaticInner.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
    }

    // ---- isPrimitiveOrWrapper ----

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    // ---- isPrimitiveWrapper ----

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    // ---- isPublic ----

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PackagePrivateNested.class));
        assertFalse(ClassUtils.isPublic(PrivateNested.class));
    }

    // ---- primitivesToWrappers ----

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, boolean.class);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertEquals(Boolean.class, result[2]);
    }

    // ---- primitiveToWrapper ----

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    // ---- toClass ----

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        Class<?>[] result = ClassUtils.toClass("abc", Integer.valueOf(1), null);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    // ---- wrappersToPrimitives ----

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, Boolean.class);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertEquals(boolean.class, result[2]);
    }

    // ---- wrapperToPrimitive ----

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    // ---- ClassUtils.Interfaces enum ----

    @Test
    public void testInterfacesEnum() {
        ClassUtils.Interfaces[] values = ClassUtils.Interfaces.values();
        assertEquals(2, values.length);
        assertEquals(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertEquals(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.Interfaces.valueOf("NO_SUCH_VALUE");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ClassUtils.Interfaces.valueOf(null);
            }
        });
    }
}
