package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    @Test
    public void testConstructorAndGettersThreeArg() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", fdp.getPattern());
        assertEquals(UTC, fdp.getTimeZone());
        assertEquals(Locale.US, fdp.getLocale());
    }

    @Test
    public void testConstructorFourArgGetters() {
        Date centuryStart = new GregorianCalendar(1960, Calendar.JANUARY, 1).getTime();
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.UK, centuryStart);
        assertEquals("yyyy-MM-dd", fdp.getPattern());
        assertEquals(UTC, fdp.getTimeZone());
        assertEquals(Locale.UK, fdp.getLocale());
    }

    @Test
    public void testConstructorFourArgNullLocaleDefaultsToSystemDefault() {
        Date centuryStart = new GregorianCalendar(1960, Calendar.JANUARY, 1).getTime();
        Locale expectedDefault = Locale.getDefault();
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, null, centuryStart);
        assertEquals(expectedDefault, fdp.getLocale());
    }

    @Test
    public void testParseStringSuccess() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15 10:20:30");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(10, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(20, cal.get(Calendar.MINUTE));
        assertEquals(30, cal.get(Calendar.SECOND));
    }

    @Test
    public void testParseStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                fdp.parse("not-a-date");
            }
        });
    }

    @Test
    public void testParseStringOnlyParsesBeginning() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15 ignored trailing text");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseStringParsePositionSuccessUpdatesIndex() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date result = fdp.parse("2023-06-15", pos);
        assertNotNull(result);
        assertEquals(10, pos.getIndex());
    }

    @Test
    public void testParseStringParsePositionFailureReturnsNullAndSetsErrorIndex() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date result = fdp.parse("20AB-06-15", pos);
        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    public void testParseStringParsePositionCalendarFullConsumption() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        boolean parsed = fdp.parse("2023-06-15", pos, cal);
        assertTrue(parsed);
        assertEquals(10, pos.getIndex());
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseStringParsePositionCalendarPartialConsumption() {
        FastDateParser fdp = new FastDateParser("yyyy", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        boolean parsed = fdp.parse("2023abc", pos, cal);
        assertTrue(parsed);
        assertEquals(4, pos.getIndex());
        assertEquals(2023, cal.get(Calendar.YEAR));
    }

    @Test
    public void testParseStringParsePositionCalendarFailureReturnsFalseAndSetsErrorIndex() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        boolean parsed = fdp.parse("20AB-06-15", pos, cal);
        assertFalse(parsed);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    public void testParseThrowsIllegalArgumentExceptionForOutOfRangeFieldWithNonLenientCalendar() {
        final FastDateParser fdp = new FastDateParser("HH", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.setLenient(false);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                fdp.parse("99", pos, cal);
            }
        });
    }

    @Test
    public void testLenientModeNormalizesOverflowMinutesIntoHours() {
        FastDateParser fdp = new FastDateParser("HH:mm", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        assertTrue(cal.isLenient());
        boolean parsed = fdp.parse("00:90", pos, cal);
        assertTrue(parsed);
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(30, cal.get(Calendar.MINUTE));
    }

    @Test
    public void testParseObjectStringReturnsDate() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Object result = fdp.parseObject("2023-06-15");
        assertTrue(result instanceof Date);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime((Date) result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseObjectStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() throws Throwable {
                fdp.parseObject("not-a-date");
            }
        });
    }

    @Test
    public void testParseObjectStringParsePositionReturnsDate() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Object result = fdp.parseObject("2023-06-15", pos);
        assertTrue(result instanceof Date);
    }

    @Test
    public void testEqualsReflexiveAndEqualInstances() {
        FastDateParser fdp1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser fdp2 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        assertTrue(fdp1.equals(fdp1));
        assertTrue(fdp1.equals(fdp2));
        assertTrue(fdp2.equals(fdp1));
        assertEquals(fdp1.hashCode(), fdp2.hashCode());
    }

    @Test
    public void testEqualsDifferentPatternNotEqual() {
        FastDateParser fdp1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser fdp2 = new FastDateParser("dd-MM-yyyy", UTC, Locale.US);
        assertFalse(fdp1.equals(fdp2));
    }

    @Test
    public void testEqualsAgainstNullAndOtherType() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(fdp.equals(null));
        assertFalse(fdp.equals("yyyy-MM-dd"));
    }

    @Test
    public void testToStringNotNullOrEmpty() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        String s = fdp.toString();
        assertNotNull(s);
        assertFalse(s.isEmpty());
    }

    @Test
    public void testToStringAllNotNullOrEmpty() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        String s = fdp.toStringAll();
        assertNotNull(s);
        assertFalse(s.isEmpty());
    }

    @Test
    public void testClearDoesNotBreakFutureParsing() throws ParseException {
        FastDateParser.clear();
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15");
        assertNotNull(result);
        FastDateParser.clear();
        Date result2 = fdp.parse("2023-06-15");
        assertEquals(result, result2);
    }

    @Test
    public void testGetPatternsReturnsNonEmptyList() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        List<?> patterns = fdp.getPatterns();
        assertNotNull(patterns);
        assertFalse(patterns.isEmpty());
    }

    @Test
    public void testSerializationRoundTrip() throws Exception {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(fdp);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(fdp.getPattern(), deserialized.getPattern());
        assertEquals(fdp.getTimeZone(), deserialized.getTimeZone());
        assertEquals(fdp.getLocale(), deserialized.getLocale());
        assertTrue(fdp.equals(deserialized));

        Date original = fdp.parse("2023-06-15");
        Date afterRoundTrip = deserialized.parse("2023-06-15");
        assertEquals(original, afterRoundTrip);
    }

    @Test
    public void testSingleZAcceptsRfc822OffsetWithoutColon() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZ", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15T10:00:00+0800");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test
    public void testSingleZRejectsColonSeparatedOffset() {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZ", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date result = fdp.parse("2023-06-15T10:00:00+08:00", pos);
        assertNull(result);
    }

    @Test
    public void testDoubleZAcceptsZuluOffset() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZZ", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15T10:00:00Z");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(10, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
    }

    @Test
    public void testDoubleZAcceptsColonSeparatedOffset() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZZ", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15T10:00:00+08:00");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test
    public void testTripleZAcceptsColonSeparatedOffset() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZZZ", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15T10:00:00+08:00");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTripleZAcceptsRfc822Offset() throws ParseException {
        FastDateParser fdp = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZZZ", UTC, Locale.US);
        Date result = fdp.parse("2023-06-15T10:00:00+0800");
        assertNotNull(result);

        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(result);
        assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTwoDigitYearResolvedRelativeToCenturyStart() {
        Date centuryStart1900 = new GregorianCalendar(1900, Calendar.JANUARY, 1).getTime();
        Date centuryStart2000 = new GregorianCalendar(2000, Calendar.JANUARY, 1).getTime();

        FastDateParser fdp1900 = new FastDateParser("yy", UTC, Locale.US, centuryStart1900);
        FastDateParser fdp2000 = new FastDateParser("yy", UTC, Locale.US, centuryStart2000);

        Date result1900 = fdp1900.parse("50", new ParsePosition(0));
        Date result2000 = fdp2000.parse("50", new ParsePosition(0));

        assertNotNull(result1900);
        assertNotNull(result2000);

        Calendar cal1900 = Calendar.getInstance(UTC, Locale.US);
        cal1900.setTime(result1900);
        Calendar cal2000 = Calendar.getInstance(UTC, Locale.US);
        cal2000.setTime(result2000);

        assertEquals(1950, cal1900.get(Calendar.YEAR));
        assertEquals(2050, cal2000.get(Calendar.YEAR));
    }

    @Test
    public void testJapaneseImperialLocaleFieldIsUsableLocale() {
        Locale japaneseImperial = FastDateParser.JAPANESE_IMPERIAL;
        assertNotNull(japaneseImperial);

        FastDateParser fdp = new FastDateParser("yyyy-MM-dd", UTC, japaneseImperial);
        assertEquals(japaneseImperial, fdp.getLocale());
    }
}
