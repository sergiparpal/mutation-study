package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class FractionAgentTest {

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());

        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());

        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());

        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());

        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());

        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());

        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());

        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());

        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());

        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());

        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());

        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ---------------------------------------------------------------
    // getFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionIntInt() {
        Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntDoubleNegativeCancels() {
        Fraction f = Fraction.getFraction(-3, -7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntIntMinValueNumeratorNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(int, int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionWholeNumeratorDenominator() {
        Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorNegativeWhole() {
        Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, 3, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, 3, -7);
            }
        });
    }

    @Test
    public void testGetFractionWholeNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1, -3, 7);
            }
        });
    }

    @Test
    public void testGetFractionWholeOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(String)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionStringWholeNumeratorDenominator() {
        Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNumeratorDenominator() {
        Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        Fraction f = Fraction.getFraction("0.5");
        assertEquals(0.5d, f.doubleValue(), 0.0001d);
    }

    @Test
    public void testGetFractionStringNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringInvalidThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                Fraction.getFraction("not a fraction");
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(double)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionDoubleCloseToValue() {
        Fraction f = Fraction.getFraction(0.5d);
        assertEquals(0.5d, f.doubleValue(), 0.0001d);

        Fraction zero = Fraction.getFraction(0.0d);
        assertEquals(0.0d, zero.doubleValue(), 0.0001d);

        Fraction negHalf = Fraction.getFraction(-0.5d);
        assertEquals(-0.5d, negHalf.doubleValue(), 0.0001d);
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getFraction(1.0e10d);
            }
        });
    }

    // ---------------------------------------------------------------
    // getReducedFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetReducedFraction() {
        Fraction f = Fraction.getReducedFraction(4, 8);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionNegativeDenominatorMovesSignToNumerator() {
        Fraction f = Fraction.getReducedFraction(4, -8);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumerator() {
        Fraction f = Fraction.getReducedFraction(0, 5);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // abs()
    // ---------------------------------------------------------------

    @Test
    public void testAbsOnPositiveReturnsSameInstance() {
        Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsOnNegativeFlipsSign() {
        Fraction f = Fraction.getFraction(-3, 7);
        Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAbsOnZero() {
        Fraction abs = Fraction.ZERO.abs();
        assertEquals(0, abs.getNumerator());
    }

    // ---------------------------------------------------------------
    // add(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testAdd() {
        Fraction result = Fraction.ONE_HALF.add(Fraction.ONE_HALF);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());

        Fraction thirds = Fraction.ONE_THIRD.add(Fraction.ONE_THIRD);
        assertEquals(2, thirds.getNumerator());
        assertEquals(3, thirds.getDenominator());
    }

    @Test
    public void testAddNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                big.add(Fraction.ONE);
            }
        });
    }

    // ---------------------------------------------------------------
    // subtract(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testSubtract() {
        Fraction result = Fraction.ONE.subtract(Fraction.ONE_THIRD);
        assertEquals(2, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE.subtract(null);
            }
        });
    }

    @Test
    public void testSubtractOverflowThrows() {
        final Fraction small = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                small.subtract(Fraction.ONE);
            }
        });
    }

    // ---------------------------------------------------------------
    // multiplyBy(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testMultiplyBy() {
        Fraction result = Fraction.ONE_HALF.multiplyBy(Fraction.TWO_THIRDS);
        assertEquals(1, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testMultiplyByNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                big.multiplyBy(Fraction.getFraction(2, 1));
            }
        });
    }

    // ---------------------------------------------------------------
    // divideBy(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testDivideBy() {
        Fraction result = Fraction.ONE_HALF.divideBy(Fraction.ONE_THIRD);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideByNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE.divideBy(null);
            }
        });
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.ONE.divideBy(Fraction.ZERO);
            }
        });
    }

    // ---------------------------------------------------------------
    // invert()
    // ---------------------------------------------------------------

    @Test
    public void testInvertNotReduced() {
        Fraction f = Fraction.getFraction(2, 4);
        Fraction inverted = f.invert();
        assertEquals(4, inverted.getNumerator());
        assertEquals(2, inverted.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        Fraction f = Fraction.getFraction(-2, 4);
        Fraction inverted = f.invert();
        assertEquals(-4, inverted.getNumerator());
        assertEquals(2, inverted.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    // ---------------------------------------------------------------
    // negate()
    // ---------------------------------------------------------------

    @Test
    public void testNegateNotReduced() {
        Fraction f = Fraction.getFraction(2, 4);
        Fraction negated = f.negate();
        assertEquals(-2, negated.getNumerator());
        assertEquals(4, negated.getDenominator());
    }

    @Test
    public void testNegateTwiceReturnsOriginalValue() {
        Fraction f = Fraction.getFraction(2, 4);
        Fraction negatedTwice = f.negate().negate();
        assertEquals(2, negatedTwice.getNumerator());
        assertEquals(4, negatedTwice.getDenominator());
    }

    // ---------------------------------------------------------------
    // pow(int)
    // ---------------------------------------------------------------

    @Test
    public void testPowZeroReturnsOneConstant() {
        Fraction f = Fraction.getFraction(3, 7);
        assertSame(Fraction.ONE, f.pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowReduced() {
        Fraction result = Fraction.TWO_THIRDS.pow(2);
        assertEquals(4, result.getNumerator());
        assertEquals(9, result.getDenominator());
    }

    @Test
    public void testPowOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                big.pow(2);
            }
        });
    }

    // ---------------------------------------------------------------
    // reduce()
    // ---------------------------------------------------------------

    @Test
    public void testReduce() {
        Fraction f = Fraction.getFraction(2, 4);
        Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceZeroNumerator() {
        Fraction f = Fraction.getFraction(0, 5);
        Fraction reduced = f.reduce();
        assertEquals(0, reduced.getNumerator());
        assertEquals(1, reduced.getDenominator());
    }

    // ---------------------------------------------------------------
    // getNumerator() / getDenominator()
    // ---------------------------------------------------------------

    @Test
    public void testGetNumeratorCanBeImproper() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ---------------------------------------------------------------
    // getProperNumerator() / getProperWhole()
    // ---------------------------------------------------------------

    @Test
    public void testProperPartsOfImproperFraction() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testProperPartsOfNegativeImproperFraction() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testProperPartsOfExactWholeFraction() {
        Fraction f = Fraction.getFraction(4, 2);
        assertEquals(2, f.getProperWhole());
        assertEquals(0, f.getProperNumerator());
    }

    // ---------------------------------------------------------------
    // intValue() / longValue() / doubleValue() / floatValue()
    // ---------------------------------------------------------------

    @Test
    public void testNumberConversions() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.intValue());
        assertEquals(1L, f.longValue());
        assertEquals(1.75d, f.doubleValue(), 0.0001d);
        assertEquals(1.75f, f.floatValue(), 0.0001f);
    }

    @Test
    public void testNumberConversionsNegative() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.intValue());
        assertEquals(-1L, f.longValue());
        assertEquals(-1.75d, f.doubleValue(), 0.0001d);
        assertEquals(-1.75f, f.floatValue(), 0.0001f);
    }

    // ---------------------------------------------------------------
    // equals(Object) / hashCode()
    // ---------------------------------------------------------------

    @Test
    public void testEqualsSameValue() {
        Fraction a = Fraction.getFraction(1, 2);
        Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDifferentButMathematicallyEqualValuesAreNotEqual() {
        Fraction half = Fraction.getFraction(1, 2);
        Fraction twoQuarters = Fraction.getFraction(2, 4);
        assertFalse(half.equals(twoQuarters));
    }

    @Test
    public void testEqualsNullAndOtherType() {
        Fraction f = Fraction.getFraction(1, 2);
        assertFalse(f.equals(null));
        assertFalse(f.equals("1/2"));
    }

    // ---------------------------------------------------------------
    // compareTo(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testCompareTo() {
        assertTrue(Fraction.ONE_HALF.compareTo(Fraction.ONE_THIRD) > 0);
        assertTrue(Fraction.ONE_THIRD.compareTo(Fraction.ONE_HALF) < 0);
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.ONE_HALF));
    }

    @Test
    public void testCompareToInconsistentWithEquals() {
        Fraction half = Fraction.getFraction(1, 2);
        Fraction twoQuarters = Fraction.getFraction(2, 4);
        assertEquals(0, half.compareTo(twoQuarters));
        assertFalse(half.equals(twoQuarters));
    }

    @Test
    public void testCompareToNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Fraction.ONE.compareTo(null);
            }
        });
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testCompareToWrongTypeThrowsClassCastException() {
        final Comparable raw = Fraction.ONE;
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() {
                raw.compareTo("not a fraction");
            }
        });
    }

    // ---------------------------------------------------------------
    // toString() / toProperString()
    // ---------------------------------------------------------------

    @Test
    public void testToString() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
        assertEquals("2/4", Fraction.getFraction(2, 4).toString());
        assertEquals("-3/4", Fraction.getFraction(-3, 4).toString());
    }

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringNegativeImproperFraction() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperStringWholeOmittedWhenZero() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    @Test
    public void testToProperStringNumeratorOmittedWhenZero() {
        assertEquals("2", Fraction.getFraction(4, 2).toProperString());
    }
}
