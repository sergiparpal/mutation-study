/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.h2.tools.SimpleResultSet;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum FixtureHeader {
        NAME, EMAIL, PHONE
    }

    // --- Builder.create() --------------------------------------------------

    @Test
    void testBuilderCreateDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getAutoFlush());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat copy = CSVFormat.Builder.create(CSVFormat.EXCEL).get();
        assertEquals(CSVFormat.EXCEL, copy);
        assertNotSame(CSVFormat.EXCEL, copy);
    }

    @Test
    void testBuilderMethod() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat rebuilt = builder.get();
        assertEquals(CSVFormat.DEFAULT, rebuilt);
    }

    @Test
    void testBuildDelegatesToGet() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter(';');
        assertEquals(builder.get(), builder.build());
    }

    // --- newFormat -----------------------------------------------------

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    void testNewFormatRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
    }

    // --- Builder setters: delimiter -------------------------------------

    @Test
    void testSetDelimiterChar() {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(';').get();
        assertEquals(";", format.getDelimiterString());
        assertEquals(';', format.getDelimiter());
    }

    @Test
    void testSetDelimiterStringMultiChar() {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
        assertEquals(':', format.getDelimiter());
    }

    @Test
    void testSetDelimiterRejectsLineBreakChar() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDelimiter('\r');
            }
        });
    }

    @Test
    void testSetDelimiterRejectsLineBreakInString() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDelimiter("a\nb");
            }
        });
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDelimiter("");
            }
        });
    }

    // --- Builder setters: comment marker ---------------------------------

    @Test
    void testSetCommentMarkerChar() {
        final CSVFormat format = CSVFormat.Builder.create().setCommentMarker('#').get();
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setCommentMarker('\n');
            }
        });
    }

    @Test
    void testCommentMarkerNotSetByDefault() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getCommentMarker());
    }

    // --- Builder setters: escape ------------------------------------------

    @Test
    void testSetEscapeChar() {
        final CSVFormat format = CSVFormat.Builder.create().setEscape('\\').get();
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setEscape('\r');
            }
        });
    }

    @Test
    void testEscapeNotSetByDefault() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertFalse(format.isEscapeCharacterSet());
        assertEquals(0, format.getEscapeChar());
    }

    // --- Builder setters: quote --------------------------------------------

    @Test
    void testSetQuoteChar() {
        final CSVFormat format = CSVFormat.Builder.create().setQuote('\'').get();
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());
    }

    @Test
    void testSetQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.Builder.create().setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setQuote('\n');
            }
        });
    }

    // --- Builder setters: duplicate header mode ---------------------------

    @Test
    void testSetDuplicateHeaderModeRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDuplicateHeaderMode(null);
            }
        });
    }

    @Test
    void testSetAllowDuplicateHeaderNamesDeprecated() {
        final CSVFormat allow = CSVFormat.Builder.create().setAllowDuplicateHeaderNames(true).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, allow.getDuplicateHeaderMode());
        assertTrue(allow.getAllowDuplicateHeaderNames());
        final CSVFormat disallow = CSVFormat.Builder.create().setAllowDuplicateHeaderNames(false).get();
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, disallow.getDuplicateHeaderMode());
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    // --- Builder setters: header -------------------------------------------

    @Test
    void testSetHeaderVarargsStoresCopy() {
        final String[] headers = { "a", "b" };
        final CSVFormat format = CSVFormat.Builder.create().setHeader(headers).get();
        headers[0] = "mutated";
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader("a", "b").get();
        final String[] first = format.getHeader();
        first[0] = "mutated";
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderEmptyMeansAutoDetect() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testSetHeaderEnumClass() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader(FixtureHeader.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderEnumClassNullDisablesHeader() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderResultSet() throws SQLException {
        final SimpleResultSet rs = new SimpleResultSet();
        rs.addColumn("ID", Types.INTEGER, 10, 0);
        rs.addColumn("NAME", Types.VARCHAR, 50, 0);
        final CSVFormat format = CSVFormat.Builder.create().setHeader((ResultSet) rs).get();
        assertArrayEquals(new String[] { "ID", "NAME" }, format.getHeader());
    }

    @Test
    void testSetHeaderResultSetNullDisablesHeader() throws SQLException {
        final CSVFormat format = CSVFormat.Builder.create().setHeader((ResultSet) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderResultSetMetaData() throws SQLException {
        final SimpleResultSet rs = new SimpleResultSet();
        rs.addColumn("COL1", Types.VARCHAR, 10, 0);
        rs.addColumn("COL2", Types.VARCHAR, 10, 0);
        final CSVFormat format = CSVFormat.Builder.create().setHeader(rs.getMetaData()).get();
        assertArrayEquals(new String[] { "COL1", "COL2" }, format.getHeader());
    }

    // --- Builder setters: header comments ----------------------------------

    @Test
    void testSetHeaderCommentsStrings() {
        final CSVFormat format = CSVFormat.Builder.create().setHeaderComments("line1", "line2").get();
        assertArrayEquals(new String[] { "line1", "line2" }, format.getHeaderComments());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.Builder.create().setHeaderComments("line1").get();
        final String[] comments = format.getHeaderComments();
        comments[0] = "mutated";
        assertArrayEquals(new String[] { "line1" }, format.getHeaderComments());
    }

    @Test
    void testSetHeaderCommentsObjectsConvertsToString() {
        final CSVFormat format = CSVFormat.Builder.create().setHeaderComments(new Object[] { Integer.valueOf(1), null, "x" }).get();
        assertArrayEquals(new String[] { "1", null, "x" }, format.getHeaderComments());
    }

    @Test
    void testHeaderCommentsNullByDefault() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertNull(format.getHeaderComments());
    }

    // --- Simple boolean/value setters --------------------------------------

    @Test
    void testSetAllowMissingColumnNames() {
        assertTrue(CSVFormat.Builder.create().setAllowMissingColumnNames(true).get().getAllowMissingColumnNames());
        assertFalse(CSVFormat.Builder.create().setAllowMissingColumnNames(false).get().getAllowMissingColumnNames());
    }

    @Test
    void testSetAutoFlush() {
        assertTrue(CSVFormat.Builder.create().setAutoFlush(true).get().getAutoFlush());
    }

    @Test
    void testSetIgnoreEmptyLines() {
        assertFalse(CSVFormat.Builder.create().setIgnoreEmptyLines(false).get().getIgnoreEmptyLines());
    }

    @Test
    void testSetIgnoreHeaderCase() {
        assertTrue(CSVFormat.Builder.create().setIgnoreHeaderCase(true).get().getIgnoreHeaderCase());
    }

    @Test
    void testSetIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.Builder.create().setIgnoreSurroundingSpaces(true).get().getIgnoreSurroundingSpaces());
    }

    @Test
    void testSetLenientEof() {
        assertTrue(CSVFormat.Builder.create().setLenientEof(true).get().getLenientEof());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.Builder.create().setMaxRows(5).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        final CSVFormat unlimited = CSVFormat.Builder.create().setMaxRows(0).get();
        assertFalse(unlimited.useMaxRows());
    }

    @Test
    void testSetNullStringAndQuotedNullString() {
        final CSVFormat format = CSVFormat.Builder.create().setNullString("NULL").get();
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testNullStringNotSetByDefault() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testSetQuoteMode() {
        final CSVFormat format = CSVFormat.Builder.create().setQuoteMode(QuoteMode.ALL).get();
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testSetRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.Builder.create().setRecordSeparator('\n').get();
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testSetRecordSeparatorString() {
        final CSVFormat format = CSVFormat.Builder.create().setRecordSeparator("\r\n").get();
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    void testSetSkipHeaderRecord() {
        assertTrue(CSVFormat.Builder.create().setSkipHeaderRecord(true).get().getSkipHeaderRecord());
    }

    @Test
    void testSetTrailingData() {
        assertTrue(CSVFormat.Builder.create().setTrailingData(true).get().getTrailingData());
    }

    @Test
    void testSetTrailingDelimiter() {
        assertTrue(CSVFormat.Builder.create().setTrailingDelimiter(true).get().getTrailingDelimiter());
    }

    @Test
    void testSetTrim() {
        assertTrue(CSVFormat.Builder.create().setTrim(true).get().getTrim());
    }

    // --- equals / hashCode / toString --------------------------------------

    @Test
    void testEqualsReflexiveAndSameSettings() {
        final CSVFormat a = CSVFormat.Builder.create().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.Builder.create().setDelimiter(';').get();
        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentSettingsNotEqual() {
        final CSVFormat a = CSVFormat.Builder.create().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.Builder.create().setDelimiter(',').get();
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final CSVFormat a = CSVFormat.DEFAULT;
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
    }

    @Test
    void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("QuoteChar=<\">"));
    }

    // --- validate() ----------------------------------------------------

    @Test
    void testValidateQuoteEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDelimiter('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.Builder.create().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeadersDisallowedThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeadersAllowedByDefault() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader("a", "a").get();
        assertArrayEquals(new String[] { "a", "a" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateEmptyHeadersAllowed() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "").get();
        assertArrayEquals(new String[] { "", "" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateNonEmptyHeadersDisallowedUnderAllowEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get();
            }
        });
    }

    // --- parse / format / print ----------------------------------------

    @Test
    void testParseWithHeaderAndSkipHeaderRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final Reader reader = new StringReader("name,age\r\nJohn,30\r\n");
        final CSVParser parser = format.parse(reader);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals("John", record.get("name"));
            assertEquals("30", record.get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testFormatStripsTrailingRecordSeparator() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", formatted);
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b");
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        final StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",\n", sb.toString());
    }

    @Test
    void testPrintlnWithoutTrailingDelimiterOrSeparator() throws IOException {
        final CSVFormat format = CSVFormat.newFormat(',');
        final StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintNullValueWithoutNullString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintNullValueWithNullStringMinimalMode() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testPrintNullValueWithNullStringAllMode() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("\"NULL\"", sb.toString());
    }

    @Test
    void testPrinterCreatesWorkingPrinter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        try {
            printer.printRecord("x", "y");
        } finally {
            printer.close();
        }
        assertEquals("x,y\r\n", sb.toString());
    }

    // --- Predefined constants settings -------------------------------------

    @Test
    void testDefaultFormatSettings() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
    }

    @Test
    void testExcelFormatSettings() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
        assertEquals(",", CSVFormat.EXCEL.getDelimiterString());
    }

    @Test
    void testMySqlFormatSettings() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
    }

    @Test
    void testOracleFormatSettings() {
        assertEquals(",", CSVFormat.ORACLE.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.ORACLE.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.ORACLE.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.ORACLE.getNullString());
        assertTrue(CSVFormat.ORACLE.getTrim());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.ORACLE.getQuoteMode());
        assertEquals(System.lineSeparator(), CSVFormat.ORACLE.getRecordSeparator());
    }

    @Test
    void testPostgreSqlCsvFormatSettings() {
        assertEquals(",", CSVFormat.POSTGRESQL_CSV.getDelimiterString());
        assertNull(CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.POSTGRESQL_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_CSV.getRecordSeparator());
        assertEquals("", CSVFormat.POSTGRESQL_CSV.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_CSV.getQuoteMode());
    }

    @Test
    void testPostgreSqlTextFormatSettings() {
        assertEquals("\t", CSVFormat.POSTGRESQL_TEXT.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.POSTGRESQL_TEXT.getEscapeCharacter());
        assertNull(CSVFormat.POSTGRESQL_TEXT.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_TEXT.getRecordSeparator());
        assertEquals("\\N", CSVFormat.POSTGRESQL_TEXT.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_TEXT.getQuoteMode());
    }

    @Test
    void testTdfFormatSettings() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testRfc4180FormatSettings() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertEquals(",", CSVFormat.RFC4180.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
    }

    @Test
    void testInformixUnloadFormatSettings() {
        assertEquals("|", CSVFormat.INFORMIX_UNLOAD.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD.getRecordSeparator());
    }

    @Test
    void testInformixUnloadCsvFormatSettings() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD_CSV.getRecordSeparator());
    }

    @Test
    void testMongoDbCsvFormatSettings() {
        assertEquals(",", CSVFormat.MONGODB_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_CSV.getQuoteMode());
    }

    @Test
    void testMongoDbTsvFormatSettings() {
        assertEquals("\t", CSVFormat.MONGODB_TSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_TSV.getQuoteMode());
        assertFalse(CSVFormat.MONGODB_TSV.getSkipHeaderRecord());
    }

    // --- valueOf ---------------------------------------------------------

    @Test
    void testValueOfKnownNames() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotARealFormat");
            }
        });
    }

    // --- deprecated with* methods -------------------------------------

    @Test
    void testWithDelimiterDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testWithDelimiterDeprecatedRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withDelimiter('\r');
            }
        });
    }

    @Test
    void testWithHeaderDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    void testWithFirstRecordAsHeaderDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testWithTrimDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    void testWithSystemRecordSeparatorDeprecated() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    void testWithQuoteDeprecated() {
        assertEquals(Character.valueOf('\''), CSVFormat.DEFAULT.withQuote('\'').getQuoteCharacter());
        assertNull(CSVFormat.DEFAULT.withQuote((Character) null).getQuoteCharacter());
    }

    @Test
    void testWithTrailingDelimiterDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
    }
}
