/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class TextStyleAgentTest {

    @Test
    void testBuilderDefaults() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertEquals(TextStyle.Alignment.LEFT, builder.get().getAlignment());
        assertEquals(0, builder.getLeftPad());
        assertEquals(0, builder.getIndent());
        assertTrue(builder.isScalable());
        assertEquals(0, builder.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, builder.getMaxWidth());
    }

    @Test
    void testDefaultConstant() {
        assertEquals(TextStyle.Alignment.LEFT, TextStyle.DEFAULT.getAlignment());
        assertEquals(0, TextStyle.DEFAULT.getLeftPad());
        assertEquals(0, TextStyle.DEFAULT.getIndent());
        assertTrue(TextStyle.DEFAULT.isScalable());
        assertEquals(0, TextStyle.DEFAULT.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, TextStyle.DEFAULT.getMaxWidth());
    }

    @Test
    void testBuilderSettersAndGet() {
        final TextStyle.Builder builder = TextStyle.builder();
        final TextStyle.Builder returned = builder.setAlignment(TextStyle.Alignment.RIGHT).setIndent(3).setLeftPad(2).setMaxWidth(20).setMinWidth(5)
                .setScalable(false);
        assertSame(builder, returned, "setters should return this instance");
        assertEquals(TextStyle.Alignment.RIGHT, builder.get().getAlignment());
        assertEquals(3, builder.getIndent());
        assertEquals(2, builder.getLeftPad());
        assertEquals(20, builder.getMaxWidth());
        assertEquals(5, builder.getMinWidth());
        assertFalse(builder.isScalable());

        final TextStyle style = builder.get();
        assertEquals(TextStyle.Alignment.RIGHT, style.getAlignment());
        assertEquals(3, style.getIndent());
        assertEquals(2, style.getLeftPad());
        assertEquals(20, style.getMaxWidth());
        assertEquals(5, style.getMinWidth());
        assertFalse(style.isScalable());
    }

    @Test
    void testSetTextStyleCopiesAllProperties() {
        final TextStyle source = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(4).setLeftPad(6).setMaxWidth(40).setMinWidth(10)
                .setScalable(false).get();
        final TextStyle.Builder target = TextStyle.builder();
        final TextStyle.Builder returned = target.setTextStyle(source);
        assertSame(target, returned, "setTextStyle should return this instance");

        final TextStyle copy = target.get();
        assertEquals(source.getAlignment(), copy.getAlignment());
        assertEquals(source.getIndent(), copy.getIndent());
        assertEquals(source.getLeftPad(), copy.getLeftPad());
        assertEquals(source.getMaxWidth(), copy.getMaxWidth());
        assertEquals(source.getMinWidth(), copy.getMinWidth());
        assertEquals(source.isScalable(), copy.isScalable());
    }

    @Test
    void testPadTextLongerThanMaxWidthReturnsUnchanged() {
        final TextStyle style = TextStyle.builder().setMaxWidth(4).get();
        final CharSequence result = style.pad(false, "hello world");
        assertEquals("hello world", result.toString());
    }

    @Test
    void testPadTextEqualToMaxWidthReturnsUnchanged() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence result = style.pad(false, "hello");
        assertEquals("hello", result.toString());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthNoIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("abc       ", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentWithIndentAdded() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals("  abc     ", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentIndentIgnoredWhenNotEnoughRoom() {
        // restLen (maxWidth - text.length()) = 1, indent = 2 -> restLen < indent so indent is dropped
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(true, "aaaaaaaaa");
        assertEquals("aaaaaaaaa ", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthNoIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(4).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("abc", result.toString());
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(4).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals("    abc", result.toString());
    }

    @Test
    void testPadRightAlignmentWithMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("       abc", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadRightAlignmentWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals("  " + "     " + "abc", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadRightAlignmentUnsetMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setIndent(4).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("abc", result.toString());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthEvenPadding() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(7).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("  abc  ", result.toString());
        assertEquals(7, result.length());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthOddPadding() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(8).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals(8, result.length());
        assertEquals("  abc   ", result.toString());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithoutIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(4).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("abc", result.toString());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(4).get();
        final CharSequence result = style.pad(true, "abc");
        // indent 4 split 2/2 around the text
        assertEquals("  abc  ", result.toString());
        assertEquals(7, result.length());
    }

    @Test
    void testPadEmptyText() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence result = style.pad(false, "");
        assertEquals("     ", result.toString());
        assertEquals(5, result.length());
    }

    @Test
    void testToStringContainsFieldsWithUnsetMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setLeftPad(1).setIndent(2).setMinWidth(3).get();
        final String str = style.toString();
        assertNotNull(str);
        assertTrue(str.contains("CENTER"));
        assertTrue(str.contains("unset"));
        assertTrue(str.contains("l:1"));
        assertTrue(str.contains("i:2"));
        assertTrue(str.contains("min:3"));
    }

    @Test
    void testToStringContainsFieldsWithSetMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(42).get();
        final String str = style.toString();
        assertTrue(str.contains("max:42"));
        assertFalse(str.contains("unset"));
    }

    @Test
    void testAlignmentEnumValues() {
        final TextStyle.Alignment[] values = TextStyle.Alignment.values();
        assertEquals(3, values.length);
        assertEquals(TextStyle.Alignment.LEFT, TextStyle.Alignment.valueOf("LEFT"));
        assertEquals(TextStyle.Alignment.CENTER, TextStyle.Alignment.valueOf("CENTER"));
        assertEquals(TextStyle.Alignment.RIGHT, TextStyle.Alignment.valueOf("RIGHT"));
    }

    @Test
    void testUnsetMaxWidthIsIntegerMaxValue() {
        assertEquals(Integer.MAX_VALUE, TextStyle.UNSET_MAX_WIDTH);
    }
}
