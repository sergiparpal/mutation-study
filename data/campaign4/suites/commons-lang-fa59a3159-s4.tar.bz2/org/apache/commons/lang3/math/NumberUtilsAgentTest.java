package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // Reusable constant fields
    // ---------------------------------------------------------------

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    // ---------------------------------------------------------------
    // Deprecated constructor: still public per contract
    // ---------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testPublicConstructor() {
        assertNotNull(new NumberUtils());
    }

    // ---------------------------------------------------------------
    // compare(...)
    // ---------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
    }

    @Test
    public void testCreateBigDecimalInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("16"), NumberUtils.createBigInteger("0x10"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createDouble
    // ---------------------------------------------------------------

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createFloat
    // ---------------------------------------------------------------

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(16), NumberUtils.createInteger("0x10"));
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(Long.valueOf(16L), NumberUtils.createLong("0x10"));
    }

    @Test
    public void testCreateLongInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createLong("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainIntegerYieldsInteger() {
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLargeIntegralYieldsLong() {
        Number n = NumberUtils.createNumber("12345678901");
        assertTrue(n instanceof Long);
        assertEquals(12345678901L, n.longValue());
    }

    @Test
    public void testCreateNumberHugeIntegralYieldsBigInteger() {
        String huge = "123456789012345678901234567890";
        Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    public void testCreateNumberLongSuffix() {
        Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        Number n = NumberUtils.createNumber("1.5F");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        Number n = NumberUtils.createNumber("1.5D");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberHexYieldsInteger() {
        Number n = NumberUtils.createNumber("0x10");
        assertTrue(n instanceof Integer);
        assertEquals(16, n.intValue());
    }

    @Test
    public void testCreateNumberNegativeHex() {
        Number n = NumberUtils.createNumber("-0x10");
        assertTrue(n instanceof Integer);
        assertEquals(-16, n.intValue());
    }

    @Test
    public void testCreateNumberLeadingZeroIsOctal() {
        Number n = NumberUtils.createNumber("010");
        assertEquals(8, n.intValue());
    }

    @Test
    public void testCreateNumberNotTrimmed() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createNumber(" 123");
            }
        });
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createNumber("not a number");
            }
        });
    }

    @Test
    public void testCreateNumberEveryCreatableStringIsCreatable() {
        String[] values = {"123", "123L", "1.5", "1.5F", "1.5D", "0x10", "-123", "010", "1.2e-5"};
        for (int i = 0; i < values.length; i++) {
            assertTrue(NumberUtils.isCreatable(values[i]));
            assertNotNull(NumberUtils.createNumber(values[i]));
        }
    }

    // ---------------------------------------------------------------
    // isCreatable
    // ---------------------------------------------------------------

    @Test
    public void testIsCreatableNull() {
        assertFalse(NumberUtils.isCreatable(null));
    }

    @Test
    public void testIsCreatableEmpty() {
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    public void testIsCreatableBlank() {
        assertFalse(NumberUtils.isCreatable("   "));
    }

    @Test
    public void testIsCreatableValidDecimal() {
        assertTrue(NumberUtils.isCreatable("123"));
    }

    @Test
    public void testIsCreatableValidHex() {
        assertTrue(NumberUtils.isCreatable("0x1A"));
    }

    @Test
    public void testIsCreatableValidWithTypeQualifier() {
        assertTrue(NumberUtils.isCreatable("123L"));
    }

    @Test
    public void testIsCreatableInvalidOctal() {
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    public void testIsCreatableLeadingZeroDecimalPoint() {
        assertTrue(NumberUtils.isCreatable("0.09"));
    }

    @Test
    public void testIsCreatableNonNumeric() {
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    public void testIsDigitsNull() {
        assertFalse(NumberUtils.isDigits(null));
    }

    @Test
    public void testIsDigitsEmpty() {
        assertFalse(NumberUtils.isDigits(""));
    }

    @Test
    public void testIsDigitsAllDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
    }

    @Test
    public void testIsDigitsWithDecimalPoint() {
        assertFalse(NumberUtils.isDigits("12.3"));
    }

    @Test
    public void testIsDigitsNonNumeric() {
        assertFalse(NumberUtils.isDigits("12a"));
    }

    // ---------------------------------------------------------------
    // isNumber (deprecated, same contract as isCreatable)
    // ---------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberNull() {
        assertFalse(NumberUtils.isNumber(null));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberEmpty() {
        assertFalse(NumberUtils.isNumber(""));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberValid() {
        assertTrue(NumberUtils.isNumber("123"));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberInvalidOctal() {
        assertFalse(NumberUtils.isNumber("09"));
    }

    // ---------------------------------------------------------------
    // isParsable
    // ---------------------------------------------------------------

    @Test
    public void testIsParsableNull() {
        assertFalse(NumberUtils.isParsable(null));
    }

    @Test
    public void testIsParsableEmpty() {
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    public void testIsParsableInteger() {
        assertTrue(NumberUtils.isParsable("123"));
    }

    @Test
    public void testIsParsableScientificNotation() {
        assertTrue(NumberUtils.isParsable("1.2e-5"));
    }

    @Test
    public void testIsParsableTypeSuffix() {
        assertTrue(NumberUtils.isParsable("2.0f"));
    }

    @Test
    public void testIsParsableHexNotParsable() {
        // 0x1 is accepted by createNumber/isCreatable but not by the parseXxx methods isParsable relies on.
        assertFalse(NumberUtils.isParsable("0x1"));
    }

    // ---------------------------------------------------------------
    // max / min - varargs
    // ---------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 9, NumberUtils.max(new byte[] {3, 9, -1}));
    }

    @Test
    public void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxByteThreeValues() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(3, 9, -1));
    }

    @Test
    public void testMaxIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMaxIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max((int[]) null);
            }
        });
    }

    @Test
    public void testMaxIntThreeValues() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(new long[] {3L, 9L, -1L}));
    }

    @Test
    public void testMaxLongThreeValues() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max(new short[] {3, 9, -1}));
    }

    @Test
    public void testMaxShortThreeValues() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(9.0f, NumberUtils.max(new float[] {3.0f, 9.0f, -1.0f}), 0.0f);
    }

    @Test
    public void testMaxFloatThreeValuesWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(9.0d, NumberUtils.max(new double[] {3.0d, 9.0d, -1.0d}), 0.0d);
    }

    @Test
    public void testMaxDoubleThreeValuesWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) -1, NumberUtils.min(new byte[] {3, 9, -1}));
    }

    @Test
    public void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    public void testMinByteThreeValues() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinIntArray() {
        assertEquals(-1, NumberUtils.min(3, 9, -1));
    }

    @Test
    public void testMinIntThreeValues() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
    }

    @Test
    public void testMinLongArray() {
        assertEquals(-1L, NumberUtils.min(new long[] {3L, 9L, -1L}));
    }

    @Test
    public void testMinLongThreeValues() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) -1, NumberUtils.min(new short[] {3, 9, -1}));
    }

    @Test
    public void testMinShortThreeValues() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(-1.0f, NumberUtils.min(new float[] {3.0f, 9.0f, -1.0f}), 0.0f);
    }

    @Test
    public void testMinFloatThreeValuesWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(-1.0d, NumberUtils.min(new double[] {3.0d, 9.0d, -1.0d}), 0.0d);
    }

    @Test
    public void testMinDoubleThreeValuesWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    // ---------------------------------------------------------------
    // toByte / toShort / toInt / toLong / toFloat / toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToByteNull() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
    }

    @Test
    public void testToByteEmpty() {
        assertEquals((byte) 0, NumberUtils.toByte(""));
    }

    @Test
    public void testToByteValid() {
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    public void testToByteInvalidFallsBackToZero() {
        assertEquals((byte) 0, NumberUtils.toByte("not a number"));
    }

    @Test
    public void testToByteWithDefaultNull() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
    }

    @Test
    public void testToByteWithDefaultEmpty() {
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
    }

    @Test
    public void testToByteWithDefaultValid() {
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
    }

    @Test
    public void testToShortNull() {
        assertEquals((short) 0, NumberUtils.toShort(null));
    }

    @Test
    public void testToShortEmpty() {
        assertEquals((short) 0, NumberUtils.toShort(""));
    }

    @Test
    public void testToShortValid() {
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    public void testToShortWithDefaultNull() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
    }

    @Test
    public void testToShortWithDefaultValid() {
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
    }

    @Test
    public void testToIntNull() {
        assertEquals(0, NumberUtils.toInt(null));
    }

    @Test
    public void testToIntEmpty() {
        assertEquals(0, NumberUtils.toInt(""));
    }

    @Test
    public void testToIntValid() {
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    public void testToIntWithDefaultNull() {
        assertEquals(1, NumberUtils.toInt(null, 1));
    }

    @Test
    public void testToIntWithDefaultValid() {
        assertEquals(1, NumberUtils.toInt("1", 0));
    }

    @Test
    public void testToLongNull() {
        assertEquals(0L, NumberUtils.toLong(null));
    }

    @Test
    public void testToLongEmpty() {
        assertEquals(0L, NumberUtils.toLong(""));
    }

    @Test
    public void testToLongValid() {
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    public void testToLongWithDefaultNull() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
    }

    @Test
    public void testToLongWithDefaultValid() {
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    @Test
    public void testToFloatNull() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
    }

    @Test
    public void testToFloatEmpty() {
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
    }

    @Test
    public void testToFloatValid() {
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    public void testToFloatWithDefaultNull() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
    }

    @Test
    public void testToFloatWithDefaultValid() {
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    @Test
    public void testToDoubleStringNull() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
    }

    @Test
    public void testToDoubleStringEmpty() {
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
    }

    @Test
    public void testToDoubleStringValid() {
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefaultNull() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefaultValid() {
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalNull() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalValid() {
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefaultNull() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefaultValid() {
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalHalfEven() {
        assertEquals(new BigDecimal("2.46"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.455")));
        assertEquals(new BigDecimal("2.46"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.465")));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.455"), 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.46"), result);
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRoundingNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 4, RoundingMode.HALF_UP));
    }

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
    }

    @Test
    public void testToScaledBigDecimalDoubleValid() {
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d)));
    }

    @Test
    public void testToScaledBigDecimalDoubleWithScaleAndRoundingNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
    }

    @Test
    public void testToScaledBigDecimalFloatValid() {
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f)));
    }

    @Test
    public void testToScaledBigDecimalFloatWithScaleAndRoundingNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    public void testToScaledBigDecimalStringValid() {
        assertEquals(new BigDecimal("2.50"), NumberUtils.toScaledBigDecimal("2.5"));
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.455", 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.46"), result);
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRoundingNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.HALF_UP));
    }
}
