package org.apache.commons.lang3.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link MemberUtils}, based solely on the published javadoc contract.
 */
public class MemberUtilsAgentTest {

    public static class Fixture {

        public Fixture() {
        }

        public Fixture(final String s) {
        }

        public Fixture(final Object o) {
        }

        @SuppressWarnings("unused")
        private Fixture(final int i) {
        }

        public void foo(final String s) {
        }

        public void foo(final Object o) {
        }

        @SuppressWarnings("unused")
        private void bar(final String s) {
        }

        public static void baz() {
        }

        public void qux(final String a, final String b) {
        }
    }

    // --- isStatic ---------------------------------------------------------

    @Test
    public void testIsStaticTrueForStaticMember() throws Exception {
        final Method m = Fixture.class.getMethod("baz");
        assertTrue(MemberUtils.isStatic(m));
    }

    @Test
    public void testIsStaticFalseForInstanceMember() throws Exception {
        final Method m = Fixture.class.getMethod("foo", String.class);
        assertFalse(MemberUtils.isStatic(m));
    }

    @Test
    public void testIsStaticFalseForNull() {
        assertFalse(MemberUtils.isStatic((Member) null));
    }

    // --- isPublic -----------------------------------------------------------

    @Test
    public void testIsPublicTrueForPublicMember() throws Exception {
        final Method m = Fixture.class.getMethod("foo", String.class);
        assertTrue(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicFalseForPrivateMember() throws Exception {
        final Method m = Fixture.class.getDeclaredMethod("bar", String.class);
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicFalseForNull() {
        assertFalse(MemberUtils.isPublic((Member) null));
    }

    // --- isAccessible ---------------------------------------------------------

    @Test
    public void testIsAccessibleTrueForPublicMember() throws Exception {
        final Method m = Fixture.class.getMethod("foo", String.class);
        assertTrue(MemberUtils.isAccessible(m));
    }

    @Test
    public void testIsAccessibleFalseForPrivateMember() throws Exception {
        final Method m = Fixture.class.getDeclaredMethod("bar", String.class);
        assertFalse(MemberUtils.isAccessible(m));
    }

    @Test
    public void testIsAccessibleFalseForNull() {
        assertFalse(MemberUtils.isAccessible(null));
    }

    // --- isPackage ---------------------------------------------------------

    @Test
    public void testIsPackageTrueForNoModifiers() {
        assertTrue(MemberUtils.isPackage(0));
    }

    @Test
    public void testIsPackageTrueForStaticOrFinalAlone() {
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
        assertTrue(MemberUtils.isPackage(Modifier.FINAL | Modifier.STATIC));
    }

    @Test
    public void testIsPackageFalseForPublic() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
    }

    @Test
    public void testIsPackageFalseForProtected() {
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
    }

    @Test
    public void testIsPackageFalseForPrivate() {
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    // --- isMatchingMethod ---------------------------------------------------------

    @Test
    public void testIsMatchingMethodExactType() throws Exception {
        final Method fooString = Fixture.class.getMethod("foo", String.class);
        assertTrue(MemberUtils.isMatchingMethod(fooString, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingMethodAssignableActualType() throws Exception {
        final Method fooObject = Fixture.class.getMethod("foo", Object.class);
        assertTrue(MemberUtils.isMatchingMethod(fooObject, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingMethodUnassignableActualType() throws Exception {
        final Method fooString = Fixture.class.getMethod("foo", String.class);
        assertFalse(MemberUtils.isMatchingMethod(fooString, new Class[] {Object.class}));
        assertFalse(MemberUtils.isMatchingMethod(fooString, new Class[] {Integer.class}));
    }

    @Test
    public void testIsMatchingMethodWrongParameterCount() throws Exception {
        final Method fooString = Fixture.class.getMethod("foo", String.class);
        assertFalse(MemberUtils.isMatchingMethod(fooString, new Class[0]));
        assertFalse(MemberUtils.isMatchingMethod(fooString, new Class[] {String.class, String.class}));
    }

    @Test
    public void testIsMatchingMethodNoArgMethod() throws Exception {
        final Method baz = Fixture.class.getMethod("baz");
        assertTrue(MemberUtils.isMatchingMethod(baz, new Class[0]));
    }

    @Test
    public void testIsMatchingMethodTwoArgMethod() throws Exception {
        final Method qux = Fixture.class.getMethod("qux", String.class, String.class);
        assertTrue(MemberUtils.isMatchingMethod(qux, new Class[] {String.class, String.class}));
    }

    // --- isMatchingConstructor ---------------------------------------------------------

    @Test
    public void testIsMatchingConstructorExactType() throws Exception {
        final Constructor<Fixture> ctorString = Fixture.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(ctorString, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingConstructorAssignableActualType() throws Exception {
        final Constructor<Fixture> ctorObject = Fixture.class.getConstructor(Object.class);
        assertTrue(MemberUtils.isMatchingConstructor(ctorObject, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingConstructorUnassignableActualType() throws Exception {
        final Constructor<Fixture> ctorString = Fixture.class.getConstructor(String.class);
        assertFalse(MemberUtils.isMatchingConstructor(ctorString, new Class[] {Object.class}));
    }

    @Test
    public void testIsMatchingConstructorWrongParameterCount() throws Exception {
        final Constructor<Fixture> ctorNoArg = Fixture.class.getConstructor();
        assertTrue(MemberUtils.isMatchingConstructor(ctorNoArg, new Class[0]));
        assertFalse(MemberUtils.isMatchingConstructor(ctorNoArg, new Class[] {String.class}));
    }

    // --- compareMethodFit ---------------------------------------------------------

    @Test
    public void testCompareMethodFitPrefersMoreSpecificParameter() throws Exception {
        final Method fooString = Fixture.class.getMethod("foo", String.class);
        final Method fooObject = Fixture.class.getMethod("foo", Object.class);
        final Class<?>[] actual = {String.class};

        assertTrue(MemberUtils.compareMethodFit(fooString, fooObject, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(fooObject, fooString, actual) > 0);
    }

    @Test
    public void testCompareMethodFitSameMethodIsZero() throws Exception {
        final Method fooString = Fixture.class.getMethod("foo", String.class);
        final Class<?>[] actual = {String.class};

        assertEquals(0, MemberUtils.compareMethodFit(fooString, fooString, actual));
    }

    // --- compareConstructorFit ---------------------------------------------------------

    @Test
    public void testCompareConstructorFitPrefersMoreSpecificParameter() throws Exception {
        final Constructor<Fixture> ctorString = Fixture.class.getConstructor(String.class);
        final Constructor<Fixture> ctorObject = Fixture.class.getConstructor(Object.class);
        final Class<?>[] actual = {String.class};

        assertTrue(MemberUtils.compareConstructorFit(ctorString, ctorObject, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(ctorObject, ctorString, actual) > 0);
    }

    @Test
    public void testCompareConstructorFitSameConstructorIsZero() throws Exception {
        final Constructor<Fixture> ctorString = Fixture.class.getConstructor(String.class);
        final Class<?>[] actual = {String.class};

        assertEquals(0, MemberUtils.compareConstructorFit(ctorString, ctorString, actual));
    }

    // --- setAccessibleWorkaround ---------------------------------------------------------

    @Test
    public void testSetAccessibleWorkaroundOnPrivateMemberMakesItAccessible() throws Exception {
        final Method bar = Fixture.class.getDeclaredMethod("bar", String.class);
        assertFalse(bar.isAccessible());

        final Method result = MemberUtils.setAccessibleWorkaround(bar);

        assertSame(bar, result);
        assertTrue(bar.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundOnPublicMemberReturnsSameInstance() throws Exception {
        final Method foo = Fixture.class.getMethod("foo", String.class);

        final Method result = MemberUtils.setAccessibleWorkaround(foo);

        assertSame(foo, result);
        assertTrue(foo.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundWithNullReturnsNull() {
        final Method nullMethod = null;
        final Method result = MemberUtils.setAccessibleWorkaround(nullMethod);

        assertNull(result);
    }

    // --- constructor ---------------------------------------------------------

    @Test
    public void testPackagePrivateConstructorIsUsable() throws Exception {
        final Constructor<MemberUtils> ctor = MemberUtils.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        final MemberUtils instance = ctor.newInstance();

        assertTrue(instance instanceof MemberUtils);
    }
}
