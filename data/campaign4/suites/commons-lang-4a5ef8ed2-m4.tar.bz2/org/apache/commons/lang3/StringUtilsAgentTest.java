/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Locale;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    // ----- abbreviate / abbreviateMiddle -----

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testAbbreviateWithOffset() {
        assertEquals("...fg", StringUtils.abbreviate("abcdefg", 5, 5));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 0, 10));
    }

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, ".", 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 1));
        assertEquals("ab.g", StringUtils.abbreviateMiddle("abcdefg", ".", 4));
        assertEquals("abcdefg", StringUtils.abbreviateMiddle("abcdefg", ".", 7));
    }

    // ----- capitalize / uncapitalize / swapCase -----

    @Test
    public void testCapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));
    }

    @Test
    public void testUncapitalize() {
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    // ----- center -----

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", 0));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
    }

    // ----- chomp / chop -----

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
        assertEquals("", StringUtils.chomp("\n"));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("abc"));
    }

    // ----- compare / compareIgnoreCase -----

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
    }

    @Test
    public void testCompareNullIsLess() {
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare(null, "a", true) < 0);
    }

    @Test
    public void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
    }

    // ----- contains family -----

    @Test
    public void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsChar() {
        assertFalse(StringUtils.contains(null, 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContainsAny() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'y'));
    }

    @Test
    public void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "z"));
    }

    @Test
    public void testContainsNone() {
        assertTrue(StringUtils.containsNone(null, 'a'));
        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));
    }

    @Test
    public void testContainsOnly() {
        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertFalse(StringUtils.containsOnly("ab", (char[]) null));
        assertTrue(StringUtils.containsOnly("", 'a'));
        assertTrue(StringUtils.containsOnly("aaa", 'a'));
        assertFalse(StringUtils.containsOnly("aba", 'a', 'c'));
    }

    @Test
    public void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace(" "));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("ab c"));
    }

    // ----- countMatches -----

    @Test
    public void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(0, StringUtils.countMatches("abc", "z"));
    }

    // ----- default* / firstNon* -----

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
    }

    @Test
    public void testDefaultIfEmpty() {
        assertEquals("NULL", StringUtils.defaultIfEmpty(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
    }

    @Test
    public void testDefaultIfBlank() {
        assertEquals("NULL", StringUtils.defaultIfBlank(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NULL"));
    }

    @Test
    public void testFirstNonBlank() {
        assertNull(StringUtils.firstNonBlank());
        assertNull(StringUtils.firstNonBlank(null, "", "  "));
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "abc"));
    }

    @Test
    public void testFirstNonEmpty() {
        assertNull(StringUtils.firstNonEmpty());
        assertNull(StringUtils.firstNonEmpty(null, ""));
        assertEquals("  ", StringUtils.firstNonEmpty(null, "", "  "));
    }

    // ----- deleteWhitespace -----

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));
    }

    // ----- difference / indexOfDifference / getCommonPrefix -----

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("ty", StringUtils.difference("ab", "aty"));
        assertEquals("", StringUtils.difference("abc", "abc"));
    }

    @Test
    public void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "aXc"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence) null, (CharSequence) null));
    }

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String) null));
        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abcdef", "abcxyz"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
    }

    // ----- endsWith family -----

    @Test
    public void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "abc"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
    }

    @Test
    public void testEndsWithIgnoreCase() {
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertFalse(StringUtils.endsWithIgnoreCase("ABCDEF", "cde"));
    }

    @Test
    public void testEndsWithAny() {
        assertFalse(StringUtils.endsWithAny(null, "abc"));
        assertFalse(StringUtils.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "abc"));
    }

    // ----- equals family -----

    @Test
    public void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    public void testEqualsAny() {
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
    }

    @Test
    public void testEqualsAnyIgnoreCase() {
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "def"));
    }

    // ----- indexOf family -----

    @Test
    public void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
    }

    @Test
    public void testIndexOfWithStart() {
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", "b", 9));
    }

    @Test
    public void testIndexOfAny() {
        assertEquals(-1, StringUtils.indexOfAny(null, 'a', 'b'));
        assertEquals(-1, StringUtils.indexOfAny("abc", (char[]) null));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", 'x', 'y'));
    }

    @Test
    public void testIndexOfAnyBut() {
        assertEquals(-1, StringUtils.indexOfAnyBut(null, "ab"));
        assertEquals(3, StringUtils.indexOfAnyBut("aabcd", "ab"));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", "ab"));
    }

    @Test
    public void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
    }

    @Test
    public void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));
    }

    @Test
    public void testLastIndexOfAny() {
        assertEquals(-1, StringUtils.lastIndexOfAny(null, "a"));
        assertEquals(2, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
    }

    @Test
    public void testLastIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase(null, "A"));
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aAbaabAa", "A"));
    }

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(3, StringUtils.ordinalIndexOf("aabaabaa", "a", 3));
    }

    @Test
    public void testLastOrdinalIndexOf() {
        assertEquals(-1, StringUtils.lastOrdinalIndexOf(null, "a", 1));
        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
    }

    // ----- isXxx family -----

    @Test
    public void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
    }

    @Test
    public void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
    }

    @Test
    public void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));
    }

    @Test
    public void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("ab1c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    public void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));
    }

    @Test
    public void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace("ab"));
    }

    @Test
    public void testIsAllLowerCase() {
        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab c"));
    }

    @Test
    public void testIsAllUpperCase() {
        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));
    }

    @Test
    public void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBC"));
    }

    @Test
    public void testIsAnyBlankAndAllBlank() {
        assertTrue(StringUtils.isAnyBlank("a", null));
        assertFalse(StringUtils.isAnyBlank("a", "b"));
        assertTrue(StringUtils.isAllBlank((String) null, " "));
        assertFalse(StringUtils.isAllBlank("a", " "));
    }

    @Test
    public void testIsAnyEmptyAndAllEmpty() {
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "b"));
    }

    @Test
    public void testIsAsciiPrintable() {
        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("abc "));
        assertFalse(StringUtils.isAsciiPrintable("ab\u0001c"));
    }

    // ----- join / joinWith -----

    @Test
    public void testJoinArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] {"a"}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a,b,c", StringUtils.joinWith(",", "a", "b", "c"));
        assertEquals(",", StringUtils.joinWith(",", null, null));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    // ----- left / right / mid -----

    @Test
    public void testLeft() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("", StringUtils.left("abc", 0));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testRight() {
        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testMid() {
        assertNull(StringUtils.mid(null, 0, 3));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("abc", 5, 2));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 5));
        assertEquals("abc", StringUtils.mid("abc", -1, 5));
    }

    // ----- leftPad / rightPad -----

    @Test
    public void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", -1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyxyab", StringUtils.leftPad("ab", 6, "xy"));
    }

    @Test
    public void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", -1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxyxy", StringUtils.rightPad("ab", 6, "xy"));
    }

    // ----- length -----

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    // ----- lowerCase / upperCase / toRootXxxCase -----

    @Test
    public void testLowerUpperCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));
    }

    @Test
    public void testToRootCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    // ----- normalizeSpace -----

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    // ----- overlay -----

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcd", "ef", 2, 4));
        assertEquals("abefcd", StringUtils.overlay("abcd", "ef", 2, 2));
    }

    // ----- prependIfMissing / appendIfMissing -----

    @Test
    public void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, "xx"));
        assertEquals("xxabc", StringUtils.prependIfMissing("abc", "xx"));
        assertEquals("xxabc", StringUtils.prependIfMissing("xxabc", "xx"));
    }

    @Test
    public void testPrependIfMissingIgnoreCase() {
        assertEquals("XXabc", StringUtils.prependIfMissingIgnoreCase("XXabc", "xx"));
    }

    @Test
    public void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "xx"));
        assertEquals("abcxx", StringUtils.appendIfMissing("abc", "xx"));
        assertEquals("abcxx", StringUtils.appendIfMissing("abcxx", "xx"));
    }

    @Test
    public void testAppendIfMissingIgnoreCase() {
        assertEquals("abcXX", StringUtils.appendIfMissingIgnoreCase("abcXX", "xx"));
    }

    // ----- remove family -----

    @Test
    public void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeout", StringUtils.remove("queued", 'u'));
        assertEquals("abc", StringUtils.remove("abc", 'x'));
    }

    @Test
    public void testRemoveString() {
        assertNull(StringUtils.remove((String) null, "a"));
        assertEquals("abc", StringUtils.remove("abc", (String) null));
        assertEquals("qeud", StringUtils.remove("queued", "ue"));
    }

    @Test
    public void testRemoveAll() {
        assertEquals("AB", StringUtils.removeAll("A<__>\n<__>B", "<__>\\n?"));
        assertNull(StringUtils.removeAll(null, "x"));
    }

    @Test
    public void testRemoveFirst() {
        assertEquals("foo", StringUtils.removeFirst("foobar", "bar"));
        assertNull(StringUtils.removeFirst(null, "x"));
    }

    @Test
    public void testRemovePattern() {
        assertNull(StringUtils.removePattern(null, "x"));
        assertEquals("AB", StringUtils.removePattern("A<__>\n<__>B", "<.*>"));
    }

    @Test
    public void testRemoveEnd() {
        assertNull(StringUtils.removeEnd(null, "xx"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com.", "."));
        assertEquals("abc", StringUtils.removeEnd("abc", "xyz"));
    }

    @Test
    public void testRemoveEndIgnoreCase() {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com.", "."));
        assertEquals("abc", StringUtils.removeEndIgnoreCase("abcXX", "xx"));
    }

    @Test
    public void testRemoveStart() {
        assertNull(StringUtils.removeStart(null, "xx"));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("abc", StringUtils.removeStart("abc", "xyz"));
    }

    @Test
    public void testRemoveStartIgnoreCase() {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("WWW.domain.com", "www."));
    }

    @Test
    public void testRemoveIgnoreCase() {
        assertEquals("qeud", StringUtils.removeIgnoreCase("queued", "UE"));
    }

    // ----- repeat -----

    @Test
    public void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
    }

    @Test
    public void testRepeatWithSeparator() {
        assertEquals("", StringUtils.repeat("ab", "-", -1));
        assertEquals("ab-ab-ab", StringUtils.repeat("ab", "-", 3));
        assertEquals("---", StringUtils.repeat("-", 3));
    }

    @Test
    public void testRepeatChar() {
        assertEquals("zzz", StringUtils.repeat('z', 3));
        assertEquals("", StringUtils.repeat('z', 0));
    }

    // ----- replace family -----

    @Test
    public void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
        assertEquals("axc", StringUtils.replace("abc", "b", "x"));
        assertEquals("", StringUtils.replace("aaa", "a", ""));
    }

    @Test
    public void testReplaceWithMax() {
        assertEquals("xax", StringUtils.replace("aax", "a", "x", 1));
        assertEquals("xxx", StringUtils.replace("aax", "a", "x", -1));
    }

    @Test
    public void testReplaceOnce() {
        assertEquals("fzzbar", StringUtils.replaceOnce("foobar", "oo", "zz"));
    }

    @Test
    public void testReplaceIgnoreCase() {
        assertEquals("xax", StringUtils.replaceIgnoreCase("AAx", "a", "x", 1));
    }

    @Test
    public void testReplaceOnceIgnoreCase() {
        assertEquals("fzzbar", StringUtils.replaceOnceIgnoreCase("fOObar", "oo", "zz"));
    }

    @Test
    public void testReplaceChars() {
        assertNull(StringUtils.replaceChars((String) null, 'b', 'y'));
        assertEquals("ayc", StringUtils.replaceChars("abc", 'b', 'y'));
        assertEquals("ayzet", StringUtils.replaceChars("abcdet", "bcd", "yz"));
    }

    @Test
    public void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abcde", new String[] {"ab"}, new String[] {"w", "t"});
            }
        });
    }

    @Test
    public void testReplaceEachRepeatedly() {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
    }

    @Test
    public void testReplacePattern() {
        assertNull(StringUtils.replacePattern(null, "x", "y"));
        assertEquals("AB", StringUtils.replacePattern("A\n<__>\nB", "<.*>", ""));
    }

    // ----- reverse / reverseDelimited -----

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    public void testReverseDelimited() {
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("abc", StringUtils.reverseDelimited("abc", '.'));
    }

    // ----- rotate -----

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    // ----- split family -----

    @Test
    public void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.split("ab:cd", ':'));
    }

    @Test
    public void testSplitWithSeparatorChar() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.split("a..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens() {
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] {"", "a", "b", "c", ""}, StringUtils.splitPreserveAllTokens(".a.b.c.", '.'));
    }

    @Test
    public void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab  cd ef", null));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens() {
        assertArrayEquals(new String[] {"ab", "", "cd", "ef"},
                StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!--!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[] {"ab", " ", "de"}, StringUtils.splitByCharacterType("ab de"));
        assertArrayEquals(new String[] {"number", "5"}, StringUtils.splitByCharacterType("number5"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase() {
        assertArrayEquals(new String[] {"ab", "De"}, StringUtils.splitByCharacterTypeCamelCase("abDe"));
    }

    // ----- startsWith family -----

    @Test
    public void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithIgnoreCase() {
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAny() {
        assertFalse(StringUtils.startsWithAny(null, "abc"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz"));
    }

    // ----- strip family -----

    @Test
    public void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc  ", StringUtils.strip("  abc  ", " \t"));
    }

    @Test
    public void testStripStartAndEnd() {
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
    }

    @Test
    public void testStripToEmptyAndNull() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToEmpty("  abc  "));
    }

    @Test
    public void testStripAll() {
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.stripAll(new String[] {" abc ", " def "}));
        assertNull(StringUtils.stripAll((String[]) null));
    }

    @Test
    public void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    // ----- substring family -----

    @Test
    public void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("abc", StringUtils.substring("abcde", 0, 3));
    }

    @Test
    public void testSubstringAfterAndBefore() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
    }

    @Test
    public void testSubstringAfterLastAndBeforeLast() {
        assertEquals("ba", StringUtils.substringAfterLast("abcba", "c"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "d"));
    }

    @Test
    public void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertEquals("bar", StringUtils.substringBetween("wx[bar]yz", "[", "]"));
        assertNull(StringUtils.substringBetween("abc", "1", "2"));
    }

    @Test
    public void testSubstringsBetween() {
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
        assertNull(StringUtils.substringsBetween("[a][b]", "[", "x"));
    }

    // ----- trim / truncate -----

    @Test
    public void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    public void testTrimToEmptyAndNull() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));
    }

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("", StringUtils.truncate("abcdefg", 0));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    public void testTruncateWithOffset() {
        assertEquals("cdefg", StringUtils.truncate("abcdefg", 2, 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1, 5);
            }
        });
    }

    // ----- unwrap / wrap / wrapIfMissing -----

    @Test
    public void testUnwrapChar() {
        assertNull(StringUtils.unwrap(null, '\''));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("abc", StringUtils.unwrap("abc", '\''));
    }

    @Test
    public void testUnwrapString() {
        assertEquals("abc", StringUtils.unwrap("\"abc\"", "\""));
        assertEquals("abc", StringUtils.unwrap("abc", "\""));
    }

    @Test
    public void testWrapChar() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
    }

    @Test
    public void testWrapString() {
        assertEquals("\"abc\"", StringUtils.wrap("abc", "\""));
        assertEquals("abc", StringUtils.wrap("abc", (String) null));
    }

    @Test
    public void testWrapIfMissingChar() {
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
    }

    @Test
    public void testWrapIfMissingString() {
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", "\""));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", "\""));
    }

    // ----- getDigits / toCodePoints -----

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("12345", StringUtils.getDigits("age: 12345 years"));
    }

    @Test
    public void testToCodePoints() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.toCodePoints("");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.toCodePoints(null);
            }
        });
    }

    // ----- distance algorithms -----

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(7, StringUtils.getLevenshteinDistance("", "frog"));
        assertEquals(1, StringUtils.getLevenshteinDistance("fog", "frog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
    }

    @Test
    public void testGetLevenshteinDistanceWithThreshold() {
        assertEquals(1, StringUtils.getLevenshteinDistance("fog", "frog", 2));
        assertEquals(-1, StringUtils.getLevenshteinDistance("fog", "frog", 0));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("fog", "frog", -1);
            }
        });
    }

    @Test
    public void testGetJaroWinklerDistance() {
        assertEquals(0.93d, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.01d);
        assertEquals(0.0d, StringUtils.getJaroWinklerDistance("", ""), 0.0d);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "fog");
            }
        });
    }

    @Test
    public void testGetFuzzyDistance() {
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertTrue(StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH) >= 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "b", Locale.ENGLISH);
            }
        });
    }

    // ----- getIfEmpty / getIfBlank -----

    @Test
    public void testGetIfEmpty() {
        Supplier<String> zzSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        };
        assertEquals("zz", StringUtils.getIfEmpty("", zzSupplier));
        assertEquals("abc", StringUtils.getIfEmpty("abc", zzSupplier));
        assertNull(StringUtils.getIfEmpty("", null));
    }

    @Test
    public void testGetIfBlank() {
        Supplier<String> zzSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        };
        assertEquals("zz", StringUtils.getIfBlank("  ", zzSupplier));
        assertEquals("abc", StringUtils.getIfBlank("abc", zzSupplier));
    }

    // ----- toString / valueOf -----

    @Test
    public void testToStringByteArray() throws java.io.UnsupportedEncodingException {
        assertNull(StringUtils.toString((byte[]) null, "UTF-8"));
        assertEquals("abc", StringUtils.toString("abc".getBytes("UTF-8"), "UTF-8"));
    }

    @Test
    public void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        char[] chars = {'a', 'b', 'c'};
        assertEquals("abc", StringUtils.valueOf(chars));
    }
}
