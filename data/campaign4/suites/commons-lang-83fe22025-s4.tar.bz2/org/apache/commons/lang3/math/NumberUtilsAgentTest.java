package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class NumberUtilsAgentTest {

    // ---- Constants ----

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    // ---- compare ----

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---- createBigDecimal ----

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        BigDecimal result = NumberUtils.createBigDecimal("1.5");
        assertEquals(new BigDecimal("1.5"), result);
    }

    @Test
    public void testCreateBigDecimalInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---- createBigInteger ----

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("255"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createBigInteger("not a number");
            }
        });
    }

    // ---- createDouble ----

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    // ---- createFloat ----

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    // ---- createInteger ----

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(16), NumberUtils.createInteger("0x10"));
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateIntegerInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    // ---- createLong ----

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(Long.valueOf(16L), NumberUtils.createLong("0x10"));
    }

    @Test
    public void testCreateLongInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createLong("not a number");
            }
        });
    }

    // ---- createNumber ----

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        Number n = NumberUtils.createNumber("123");
        assertEquals(123, n.intValue());
        assertTrue(n instanceof Integer);
    }

    @Test
    public void testCreateNumberHex() {
        Number n = NumberUtils.createNumber("0x10");
        assertEquals(16, n.intValue());
    }

    @Test
    public void testCreateNumberLongQualifier() {
        Number n = NumberUtils.createNumber("3L");
        assertTrue(n instanceof Long);
        assertEquals(3L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatQualifier() {
        Number n = NumberUtils.createNumber("3.5F");
        assertTrue(n instanceof Float);
        assertEquals(3.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleQualifier() {
        Number n = NumberUtils.createNumber("3.5D");
        assertTrue(n instanceof Double);
        assertEquals(3.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberBigIntegerForHugeValue() {
        String huge = "123456789012345678901234567890";
        Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    public void testCreateNumberInvalidLeadingSpaceNotTrimmed() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber(" 1");
            }
        });
    }

    @Test
    public void testCreateNumberInvalidOctalDigit() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("09");
            }
        });
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() {
                NumberUtils.createNumber("not a number");
            }
        });
    }

    // ---- isCreatable ----

    @Test
    public void testIsCreatableNull() {
        assertFalse(NumberUtils.isCreatable(null));
    }

    @Test
    public void testIsCreatableEmpty() {
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    public void testIsCreatableInvalidOctal() {
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    public void testIsCreatableLeadingZeroDecimal() {
        assertTrue(NumberUtils.isCreatable("0.09"));
    }

    @Test
    public void testIsCreatableTypeQualifier() {
        assertTrue(NumberUtils.isCreatable("123L"));
    }

    @Test
    public void testIsCreatableHex() {
        assertTrue(NumberUtils.isCreatable("0x1A"));
    }

    @Test
    public void testIsCreatablePlainInteger() {
        assertTrue(NumberUtils.isCreatable("123"));
    }

    @Test
    public void testIsCreatableConsistentWithCreateNumber() {
        assertTrue(NumberUtils.isCreatable("42"));
        assertEquals(42, NumberUtils.createNumber("42").intValue());
    }

    // ---- isDigits ----

    @Test
    public void testIsDigitsNull() {
        assertFalse(NumberUtils.isDigits(null));
    }

    @Test
    public void testIsDigitsEmpty() {
        assertFalse(NumberUtils.isDigits(""));
    }

    @Test
    public void testIsDigitsAllDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
    }

    @Test
    public void testIsDigitsWithDecimalPoint() {
        assertFalse(NumberUtils.isDigits("123.45"));
    }

    @Test
    public void testIsDigitsWithSpace() {
        assertFalse(NumberUtils.isDigits("12 345"));
    }

    // ---- isNumber (deprecated, same contract as isCreatable) ----

    @Test
    public void testIsNumberNull() {
        assertFalse(NumberUtils.isNumber(null));
    }

    @Test
    public void testIsNumberEmpty() {
        assertFalse(NumberUtils.isNumber(""));
    }

    @Test
    public void testIsNumberInvalidOctal() {
        assertFalse(NumberUtils.isNumber("09"));
    }

    @Test
    public void testIsNumberValidHex() {
        assertTrue(NumberUtils.isNumber("0x1A"));
    }

    @Test
    public void testIsNumberValidPlain() {
        assertTrue(NumberUtils.isNumber("123"));
    }

    // ---- isParsable ----

    @Test
    public void testIsParsableNull() {
        assertFalse(NumberUtils.isParsable(null));
    }

    @Test
    public void testIsParsableEmpty() {
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    public void testIsParsablePlainInteger() {
        assertTrue(NumberUtils.isParsable("123"));
    }

    @Test
    public void testIsParsableScientificNotation() {
        assertTrue(NumberUtils.isParsable("1.2e-5"));
    }

    @Test
    public void testIsParsableFloatSuffix() {
        assertTrue(NumberUtils.isParsable("2.0f"));
    }

    @Test
    public void testIsParsableDoubleSuffix() {
        assertTrue(NumberUtils.isParsable("2.0d"));
    }

    @Test
    public void testIsParsableNaN() {
        assertTrue(NumberUtils.isParsable("NaN"));
    }

    @Test
    public void testIsParsableInfinity() {
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("+Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
    }

    @Test
    public void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("abc"));
    }

    @Test
    public void testIsParsableHexNotParsable() {
        // Integer.parseInt/Long.parseLong do not accept the 0x prefix.
        assertFalse(NumberUtils.isParsable("0x1A"));
    }

    // ---- max/min: byte ----

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMaxByteArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxByteThreeValues() {
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 9, (byte) 3));
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinByteArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    public void testMinByteArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteThreeValues() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 9, (byte) 3));
    }

    // ---- max/min: short ----

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMaxShortArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
    }

    @Test
    public void testMaxShortArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMaxShortThreeValues() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 3));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMinShortArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
    }

    @Test
    public void testMinShortArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    public void testMinShortThreeValues() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 3));
    }

    // ---- max/min: int ----

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
    }

    @Test
    public void testMaxIntArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
    }

    @Test
    public void testMaxIntArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMaxIntThreeValues() {
        assertEquals(9, NumberUtils.max(1, 9, 3));
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
    }

    @Test
    public void testMinIntArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
    }

    @Test
    public void testMinIntArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMinIntThreeValues() {
        assertEquals(1, NumberUtils.min(1, 9, 3));
    }

    // ---- max/min: long ----

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxLongArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
    }

    @Test
    public void testMaxLongArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    public void testMaxLongThreeValues() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 3L));
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    public void testMinLongArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
    }

    @Test
    public void testMinLongArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMinLongThreeValues() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 3L));
    }

    // ---- max/min: float ----

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.5f, 5.5f, 3.5f), 0.0f);
    }

    @Test
    public void testMaxFloatArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
    }

    @Test
    public void testMaxFloatArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMaxFloatThreeValuesNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMaxFloatThreeValuesInfinity() {
        assertEquals(Float.POSITIVE_INFINITY, NumberUtils.max(Float.POSITIVE_INFINITY, 1.0f, 2.0f), 0.0f);
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1.5f, NumberUtils.min(1.5f, 5.5f, 3.5f), 0.0f);
    }

    @Test
    public void testMinFloatArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
    }

    @Test
    public void testMinFloatArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    public void testMinFloatThreeValuesNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMinFloatThreeValuesInfinity() {
        assertEquals(Float.NEGATIVE_INFINITY, NumberUtils.min(Float.NEGATIVE_INFINITY, 1.0f, 2.0f), 0.0f);
    }

    // ---- max/min: double ----

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.5d, 5.5d, 3.5d), 0.0d);
    }

    @Test
    public void testMaxDoubleArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
    }

    @Test
    public void testMaxDoubleArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMaxDoubleThreeValuesNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    public void testMaxDoubleThreeValuesInfinity() {
        assertEquals(Double.POSITIVE_INFINITY, NumberUtils.max(Double.POSITIVE_INFINITY, 1.0d, 2.0d), 0.0d);
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1.5d, NumberUtils.min(1.5d, 5.5d, 3.5d), 0.0d);
    }

    @Test
    public void testMinDoubleArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
    }

    @Test
    public void testMinDoubleArrayEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    public void testMinDoubleThreeValuesNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    public void testMinDoubleThreeValuesInfinity() {
        assertEquals(Double.NEGATIVE_INFINITY, NumberUtils.min(Double.NEGATIVE_INFINITY, 1.0d, 2.0d), 0.0d);
    }

    // ---- toByte ----

    @Test
    public void testToByteNull() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
    }

    @Test
    public void testToByteEmpty() {
        assertEquals((byte) 0, NumberUtils.toByte(""));
    }

    @Test
    public void testToByteValid() {
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    public void testToByteWithDefaultNull() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
    }

    @Test
    public void testToByteWithDefaultEmpty() {
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
    }

    @Test
    public void testToByteWithDefaultValid() {
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
    }

    @Test
    public void testToByteWithDefaultInvalid() {
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    // ---- toDouble(String) ----

    @Test
    public void testToDoubleStringNull() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
    }

    @Test
    public void testToDoubleStringEmpty() {
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
    }

    @Test
    public void testToDoubleStringValid() {
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefaultNull() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefaultEmpty() {
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefaultValid() {
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefaultInvalid() {
        assertEquals(9.9d, NumberUtils.toDouble("not a number", 9.9d), 0.0d);
    }

    // ---- toDouble(BigDecimal) ----

    @Test
    public void testToDoubleBigDecimalNull() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalValid() {
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefaultNull() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefaultValid() {
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---- toFloat ----

    @Test
    public void testToFloatNull() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
    }

    @Test
    public void testToFloatEmpty() {
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
    }

    @Test
    public void testToFloatValid() {
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    public void testToFloatWithDefaultNull() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
    }

    @Test
    public void testToFloatWithDefaultEmpty() {
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
    }

    @Test
    public void testToFloatWithDefaultValid() {
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    @Test
    public void testToFloatWithDefaultInvalid() {
        assertEquals(9.9f, NumberUtils.toFloat("not a number", 9.9f), 0.0f);
    }

    // ---- toInt ----

    @Test
    public void testToIntNull() {
        assertEquals(0, NumberUtils.toInt(null));
    }

    @Test
    public void testToIntEmpty() {
        assertEquals(0, NumberUtils.toInt(""));
    }

    @Test
    public void testToIntValid() {
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    public void testToIntWithDefaultNull() {
        assertEquals(1, NumberUtils.toInt(null, 1));
    }

    @Test
    public void testToIntWithDefaultEmpty() {
        assertEquals(1, NumberUtils.toInt("", 1));
    }

    @Test
    public void testToIntWithDefaultValid() {
        assertEquals(1, NumberUtils.toInt("1", 0));
    }

    @Test
    public void testToIntWithDefaultInvalid() {
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    // ---- toLong ----

    @Test
    public void testToLongNull() {
        assertEquals(0L, NumberUtils.toLong(null));
    }

    @Test
    public void testToLongEmpty() {
        assertEquals(0L, NumberUtils.toLong(""));
    }

    @Test
    public void testToLongValid() {
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    public void testToLongWithDefaultNull() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
    }

    @Test
    public void testToLongWithDefaultEmpty() {
        assertEquals(1L, NumberUtils.toLong("", 1L));
    }

    @Test
    public void testToLongWithDefaultValid() {
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    @Test
    public void testToLongWithDefaultInvalid() {
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    // ---- toShort ----

    @Test
    public void testToShortNull() {
        assertEquals((short) 0, NumberUtils.toShort(null));
    }

    @Test
    public void testToShortEmpty() {
        assertEquals((short) 0, NumberUtils.toShort(""));
    }

    @Test
    public void testToShortValid() {
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    public void testToShortWithDefaultNull() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
    }

    @Test
    public void testToShortWithDefaultEmpty() {
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
    }

    @Test
    public void testToShortWithDefaultValid() {
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
    }

    @Test
    public void testToShortWithDefaultInvalid() {
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    // ---- toScaledBigDecimal ----

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((BigDecimal) null)));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1"));
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 2, RoundingMode.HALF_UP);
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("1.23").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndRoundingHalfUpExactHalf() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.255"), 2, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("1.26").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalNullWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal((BigDecimal) null, 2, RoundingMode.HALF_UP);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Double) null)));
    }

    @Test
    public void testToScaledBigDecimalDoubleDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(1.0d));
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalDoubleWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(1.255d), 2, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("1.26").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalDoubleNullWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((Float) null)));
    }

    @Test
    public void testToScaledBigDecimalFloatDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.0f));
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalFloatWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.25f), 1, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("1.3").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalFloatNullWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(0, BigDecimal.ZERO.compareTo(NumberUtils.toScaledBigDecimal((String) null)));
    }

    @Test
    public void testToScaledBigDecimalStringDefaultScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("1");
        assertEquals(2, result.scale());
        assertEquals(0, new BigDecimal("1.00").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalStringWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal("1.255", 2, RoundingMode.HALF_UP);
        assertEquals(0, new BigDecimal("1.26").compareTo(result));
    }

    @Test
    public void testToScaledBigDecimalStringNullWithScaleAndRounding() {
        BigDecimal result = NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }
}
