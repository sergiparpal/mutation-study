package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class TypeHandlerAgentTest {

    @Test
    public void testCreateClassFound() throws ParseException {
        Class<?> clazz = TypeHandler.createClass("java.lang.String");
        assertSame(String.class, clazz);
    }

    @Test
    public void testCreateClassNotFoundThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createClass("no.such.ClassXyzAbc");
            }
        });
    }

    @Test
    public void testCreateDateAlwaysThrowsUnsupportedOperationException() {
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createDate("2024-01-01");
            }
        });
    }

    @Test
    public void testCreateDefaultMapIsNotNullAndNotEmpty() {
        Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        assertNotNull(map);
        assertFalse(map.isEmpty());
    }

    @Test
    public void testCreateDefaultMapCallsAreConsistent() {
        Map<Class<?>, Converter<?, ? extends Throwable>> map1 = TypeHandler.createDefaultMap();
        Map<Class<?>, Converter<?, ? extends Throwable>> map2 = TypeHandler.createDefaultMap();
        assertEquals(map1.size(), map2.size());
    }

    @Test
    public void testCreateFile() throws ParseException {
        File file = TypeHandler.createFile("/tmp/some-agent-test-file.txt");
        assertEquals(new File("/tmp/some-agent-test-file.txt"), file);
    }

    @Test
    public void testCreateFilesAlwaysThrowsUnsupportedOperationException() {
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createFiles("/tmp/a.txt,/tmp/b.txt");
            }
        });
    }

    @Test
    public void testCreateNumberInteger() throws ParseException {
        Number n = TypeHandler.createNumber("42");
        assertEquals(Long.valueOf(42L), n);
    }

    @Test
    public void testCreateNumberDecimal() throws ParseException {
        Number n = TypeHandler.createNumber("3.14");
        assertEquals(Double.valueOf(3.14), n);
    }

    @Test
    public void testCreateNumberInvalidThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createNumber("not-a-number");
            }
        });
    }

    @Test
    public void testCreateObjectSuccess() throws ParseException {
        Object obj = TypeHandler.createObject("java.util.ArrayList");
        assertNotNull(obj);
        assertTrue(obj instanceof java.util.ArrayList);
    }

    @Test
    public void testCreateObjectClassNotFoundThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createObject("no.such.ClassXyzAbc");
            }
        });
    }

    @Test
    public void testCreateObjectNoAccessibleConstructorThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createObject("java.lang.Math");
            }
        });
    }

    @Test
    public void testCreateURLWellFormed() throws ParseException, java.net.MalformedURLException {
        URL url = TypeHandler.createURL("https://example.com/path");
        assertEquals(new URL("https://example.com/path"), url);
    }

    @Test
    public void testCreateURLMalformedThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createURL("this is not a url");
            }
        });
    }

    @Test
    public void testCreateValueWithStringClassIsIdentity() throws ParseException {
        String value = TypeHandler.createValue("hello", String.class);
        assertEquals("hello", value);
    }

    @Test
    public void testCreateValueWithClassClassSuccess() throws ParseException {
        Class<?> clazz = TypeHandler.createValue("java.lang.String", Class.class);
        assertSame(String.class, clazz);
    }

    @Test
    public void testCreateValueWithClassClassFailureThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createValue("no.such.ClassXyzAbc", Class.class);
            }
        });
    }

    @Test
    public void testCreateValueWithFileClassSuccess() throws ParseException {
        File file = TypeHandler.createValue("/tmp/another-agent-test-file.txt", File.class);
        assertEquals(new File("/tmp/another-agent-test-file.txt"), file);
    }

    @Test
    public void testCreateValueWithURLClassFailureThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.createValue("this is not a url", URL.class);
            }
        });
    }

    @Test
    public void testGetDefaultIsNotNull() {
        TypeHandler handler = TypeHandler.getDefault();
        assertNotNull(handler);
    }

    @Test
    public void testConstructorWithCustomConverterMapIsUsedByGetConverter() throws ParseException {
        Map<Class<?>, Converter<?, ? extends Throwable>> map =
                new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        Converter<String, ParseException> custom = new Converter<String, ParseException>() {
            public String apply(String value) throws ParseException {
                return value + "-converted";
            }
        };
        map.put(String.class, custom);
        TypeHandler handler = new TypeHandler(map);

        Converter<String, ?> retrieved = handler.getConverter(String.class);
        assertSame(custom, retrieved);
    }

    @Test
    public void testGetConverterReturnsDefaultWhenAbsent() {
        Map<Class<?>, Converter<?, ? extends Throwable>> map =
                new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        TypeHandler handler = new TypeHandler(map);

        Converter<Integer, ?> fallback = handler.getConverter(Integer.class);
        assertSame(Converter.DEFAULT, fallback);
    }

    @Test
    public void testNoArgConstructorGetConverterFallsBackToDefaultForUnregisteredType() {
        TypeHandler handler = new TypeHandler();
        Converter<String, ?> converter = handler.getConverter(String.class);
        assertSame(Converter.DEFAULT, converter);
    }

    @Test
    public void testOpenFileExistingReadableFile() throws IOException, ParseException {
        File tempFile = File.createTempFile("type-handler-agent-test", ".txt");
        tempFile.deleteOnExit();
        FileInputStream fis = TypeHandler.openFile(tempFile.getAbsolutePath());
        try {
            assertNotNull(fis);
        } finally {
            fis.close();
        }
    }

    @Test
    public void testOpenFileNonExistentFileThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Throwable {
                TypeHandler.openFile("/tmp/does-not-exist-agent-test-xyz-12345.txt");
            }
        });
    }
}
