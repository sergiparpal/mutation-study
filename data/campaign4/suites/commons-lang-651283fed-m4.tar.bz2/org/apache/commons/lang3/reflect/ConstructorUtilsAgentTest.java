/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ConstructorUtils}.
 */
public class ConstructorUtilsAgentTest {

    /** Public fixture with overloaded and varargs constructors. */
    public static class Foo {

        public final String marker;

        public Foo() {
            marker = "no-arg";
        }

        public Foo(final String s) {
            marker = "string:" + s;
        }

        public Foo(final Number n) {
            marker = "number:" + n;
        }

        public Foo(final Object... args) {
            marker = "varargs:" + args.length;
        }

        // package-private constructor: never returned by Class#getConstructor
        Foo(final boolean flag) {
            marker = "package:" + flag;
        }
    }

    /** Public fixture without varargs, so "no match" cases are reachable. */
    public static class Simple {

        public final int code;

        public Simple() {
            code = 0;
        }

        public Simple(final String s) {
            code = s.length();
        }
    }

    public abstract static class AbstractFoo {

        public AbstractFoo() {
            // empty
        }
    }

    public static class ThrowingCtor {

        public ThrowingCtor() {
            throw new IllegalStateException("boom");
        }
    }

    /** Package-private top level-equivalent fixture: never "accessible" per ConstructorUtils. */
    static class PackagePrivateClass {

        public PackagePrivateClass() {
            // empty
        }
    }

    // ---- getAccessibleConstructor(Class, Class...) ----

    @Test
    public void testGetAccessibleConstructorClassFound() throws Exception {
        final Constructor<Foo> ctor = ConstructorUtils.getAccessibleConstructor(Foo.class);
        assertNotNull(ctor);
        assertEquals("no-arg", ctor.newInstance().marker);
    }

    @Test
    public void testGetAccessibleConstructorClassNotFound() {
        // only a package-private constructor accepts a boolean
        assertNull(ConstructorUtils.getAccessibleConstructor(Foo.class, boolean.class));
    }

    @Test
    public void testGetAccessibleConstructorClassNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getAccessibleConstructor((Class<Object>) null);
            }
        });
    }

    @Test
    public void testGetAccessibleConstructorOnNonPublicClassReturnsNull() {
        assertNull(ConstructorUtils.getAccessibleConstructor(PackagePrivateClass.class));
    }

    // ---- getAccessibleConstructor(Constructor) ----

    @Test
    public void testGetAccessibleConstructorFromConstructorObject() throws Exception {
        final Constructor<Foo> raw = Foo.class.getConstructor(String.class);
        final Constructor<Foo> result = ConstructorUtils.getAccessibleConstructor(raw);
        assertNotNull(result);
        assertEquals("string:hi", result.newInstance("hi").marker);
    }

    @Test
    public void testGetAccessibleConstructorFromConstructorObjectNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getAccessibleConstructor((Constructor<Object>) null);
            }
        });
    }

    // ---- getMatchingAccessibleConstructor ----

    @Test
    public void testGetMatchingAccessibleConstructorExact() {
        final Constructor<Foo> ctor = ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, String.class);
        assertNotNull(ctor);
        assertEquals(String.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructorPrefersCloserAssignableMatchOverVarArgs() {
        // Integer is assignable to Number (distance 1) and to Object (distance 2, via varargs);
        // the Number constructor must win.
        final Constructor<Foo> ctor = ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, Integer.class);
        assertNotNull(ctor);
        assertEquals(1, ctor.getParameterTypes().length);
        assertEquals(Number.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructorUsesVarArgsWhenNoOtherMatches() {
        final Constructor<Foo> ctor = ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, String.class, String.class, String.class);
        assertNotNull(ctor);
        assertTrue(ctor.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleConstructorNoMatchReturnsNull() {
        assertNull(ConstructorUtils.getMatchingAccessibleConstructor(Simple.class, Integer.class));
    }

    @Test
    public void testGetMatchingAccessibleConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getMatchingAccessibleConstructor((Class<Object>) null);
            }
        });
    }

    // ---- invokeConstructor ----

    @Test
    public void testInvokeConstructorNoArgs() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class);
        assertEquals("no-arg", foo.marker);
    }

    @Test
    public void testInvokeConstructorInfersExactType() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, "hi");
        assertEquals("string:hi", foo.marker);
    }

    @Test
    public void testInvokeConstructorAutoboxesToNumber() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, Integer.valueOf(5));
        assertEquals("number:5", foo.marker);
    }

    @Test
    public void testInvokeConstructorUsesVarArgsForExtraArgs() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, "a", "b", "c");
        assertEquals("varargs:3", foo.marker);
    }

    @Test
    public void testInvokeConstructorNoMatchThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(Simple.class, Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeConstructorOnNonPublicClassThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(PackagePrivateClass.class);
            }
        });
    }

    @Test
    public void testInvokeConstructorOnAbstractClassThrowsInstantiationException() {
        assertThrows(InstantiationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(AbstractFoo.class);
            }
        });
    }

    @Test
    public void testInvokeConstructorPropagatesExceptionFromConstructor() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(ThrowingCtor.class);
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    @Test
    public void testInvokeConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(null);
            }
        });
    }

    // ---- invokeExactConstructor ----

    @Test
    public void testInvokeExactConstructorNoArgs() throws Exception {
        final Foo foo = ConstructorUtils.invokeExactConstructor(Foo.class);
        assertEquals("no-arg", foo.marker);
    }

    @Test
    public void testInvokeExactConstructorExactStringMatch() throws Exception {
        final Foo foo = ConstructorUtils.invokeExactConstructor(Foo.class, "hi");
        assertEquals("string:hi", foo.marker);
    }

    @Test
    public void testInvokeExactConstructorRejectsAssignableOnlyMatch() {
        // Integer is assignable to Number, but invokeExactConstructor requires an exact signature match.
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(Foo.class, Integer.valueOf(5));
            }
        });
    }

    @Test
    public void testInvokeExactConstructorNoMatchThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(Simple.class, Integer.valueOf(1));
            }
        });
    }

    // ---- misc ----

    @Test
    public void testPublicNoArgConstructorIsUsable() {
        assertNotNull(new ConstructorUtils());
    }
}
