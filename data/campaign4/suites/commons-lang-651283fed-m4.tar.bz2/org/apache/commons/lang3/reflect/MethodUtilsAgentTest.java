/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface Marker {
        // empty
    }

    /** Public fixture with a set of overloaded, varargs, static, and failing methods. */
    public static class Sample {

        public String noArgs() {
            return "no-args";
        }

        public String oneArg(final String s) {
            return "one:" + s;
        }

        public String numberArg(final Number n) {
            return "number:" + n;
        }

        public String varArgs(final Object... args) {
            return "varargs:" + args.length;
        }

        public static String staticNoArgs() {
            return "static-no-args";
        }

        public static String staticOneArg(final String s) {
            return "static-one:" + s;
        }

        public String throwing() {
            throw new IllegalStateException("boom");
        }

        private String privateEcho(final String s) {
            return "priv:" + s;
        }

        @Marker
        public void annotated() {
            // empty
        }

        public void notAnnotated() {
            // empty
        }
    }

    public interface Greeter {
        String greet();
    }

    /** Package-private implementation; its public method is only reachable through the public interface. */
    static class PackagePrivateImpl implements Greeter {
        @Override
        public String greet() {
            return "hi";
        }
    }

    public static class PublicSub extends PackagePrivateImpl {
        // inherits greet() from a package-private superclass
    }

    public interface Taggable {
        @Marker
        void tag();
    }

    public static class TaggableImpl implements Taggable {
        @Override
        public void tag() {
            // intentionally not annotated directly; the annotation lives on the interface method
        }
    }

    public interface Shape {
        void draw();
    }

    public static class BaseShape implements Shape {
        @Override
        public void draw() {
            // empty
        }
    }

    public static class SubShape extends BaseShape {
        @Override
        public void draw() {
            // empty
        }
    }

    /** Generic interface implementation: the compiler adds a synthetic bridge method with the same
     * name and declaring class as the real one, which is how getMatchingMethod can see two equally-fit
     * candidates declared on the very same class and must report the ambiguity. */
    public interface Box<T> {
        void set(T value);
    }

    public static class NumberBox implements Box<Number> {
        @Override
        public void set(final Number value) {
            // empty
        }
    }

    // ---- getMethodObject ----

    @Test
    public void testGetMethodObjectFound() {
        final Method m = MethodUtils.getMethodObject(Sample.class, "oneArg", String.class);
        assertNotNull(m);
        assertEquals("oneArg", m.getName());
    }

    @Test
    public void testGetMethodObjectNotFound() {
        assertNull(MethodUtils.getMethodObject(Sample.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObjectNullArgsReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "oneArg", String.class));
        assertNull(MethodUtils.getMethodObject(Sample.class, null));
    }

    // ---- getAccessibleMethod ----

    @Test
    public void testGetAccessibleMethodClassStringParams() {
        final Method m = MethodUtils.getAccessibleMethod(Sample.class, "noArgs");
        assertNotNull(m);
    }

    @Test
    public void testGetAccessibleMethodReturnsNullForPrivateMethod() throws Exception {
        final Method privateMethod = Sample.class.getDeclaredMethod("privateEcho", String.class);
        assertNull(MethodUtils.getAccessibleMethod(Sample.class, privateMethod));
    }

    @Test
    public void testGetAccessibleMethodSingleArgNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethodFindsInterfaceMethodOnNonPublicClass() throws Exception {
        final Method declared = PackagePrivateImpl.class.getDeclaredMethod("greet");
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, declared);
        assertNotNull(accessible);
        assertEquals(Greeter.class, accessible.getDeclaringClass());
        assertEquals("hi", accessible.invoke(new PackagePrivateImpl()));
    }

    @Test
    public void testGetAccessibleMethodShortCircuitsWhenDeclaringClassParamIsPublic() throws Exception {
        final Method declared = PackagePrivateImpl.class.getDeclaredMethod("greet");
        // When the class passed in is itself public, the method is returned unchanged.
        final Method accessible = MethodUtils.getAccessibleMethod(PublicSub.class, declared);
        assertEquals(declared, accessible);
    }

    // ---- getMatchingAccessibleMethod ----

    @Test
    public void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "oneArg", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodPrefersCloserMatchOverVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "varArgs", Integer.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethodPrefersNumberOverVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "numberArg", Integer.class);
        assertNotNull(m);
        assertEquals(Number.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Sample.class, "oneArg", Thread.class));
    }

    // ---- getMatchingMethod ----

    @Test
    public void testGetMatchingMethodExact() {
        final Method m = MethodUtils.getMatchingMethod(Sample.class, "oneArg", String.class);
        assertNotNull(m);
    }

    @Test
    public void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "oneArg", String.class);
            }
        });
    }

    @Test
    public void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Sample.class, "");
            }
        });
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrowsIllegalState() {
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(NumberBox.class, "set", Integer.class);
            }
        });
    }

    // ---- getAnnotation ----

    @Test
    public void testGetAnnotationDirect() throws Exception {
        final Method m = Sample.class.getMethod("annotated");
        assertNotNull(MethodUtils.getAnnotation(m, Marker.class, false, false));
    }

    @Test
    public void testGetAnnotationMissingReturnsNull() throws Exception {
        final Method m = Sample.class.getMethod("notAnnotated");
        assertNull(MethodUtils.getAnnotation(m, Marker.class, true, true));
    }

    @Test
    public void testGetAnnotationSearchSupersFindsInterfaceAnnotation() throws Exception {
        final Method m = TaggableImpl.class.getMethod("tag");
        assertNull(MethodUtils.getAnnotation(m, Marker.class, false, true));
        assertNotNull(MethodUtils.getAnnotation(m, Marker.class, true, true));
    }

    @Test
    public void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, Marker.class, true, true);
            }
        });
    }

    // ---- getMethodsListWithAnnotation / getMethodsWithAnnotation ----

    @Test
    public void testGetMethodsListWithAnnotationDirect() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Sample.class, Marker.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsWithAnnotationSearchSupers() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(TaggableImpl.class, Marker.class, true, true);
        assertEquals(1, methods.length);
        assertEquals("tag", methods[0].getName());
    }

    @Test
    public void testGetMethodsWithAnnotationNoSearchSupersFindsNoneOnImpl() {
        // without searching supers, the annotation that lives on the interface method is invisible
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(TaggableImpl.class, Marker.class, false, true);
        assertEquals(0, methods.length);
    }

    @Test
    public void testGetMethodsListWithAnnotationNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, Marker.class);
            }
        });
    }

    // ---- getOverrideHierarchy ----

    @Test
    public void testGetOverrideHierarchyIncludesInterfaces() throws Exception {
        final Method m = SubShape.class.getMethod("draw");
        final java.util.Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.INCLUDE);
        assertEquals(3, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyExcludesInterfaces() throws Exception {
        final Method m = SubShape.class.getMethod("draw");
        final java.util.Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE);
            }
        });
    }

    // ---- invokeMethod ----

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        assertEquals("no-args", MethodUtils.invokeMethod(new Sample(), "noArgs"));
    }

    @Test
    public void testInvokeMethodWithArgs() throws Exception {
        assertEquals("one:x", MethodUtils.invokeMethod(new Sample(), "oneArg", "x"));
    }

    @Test
    public void testInvokeMethodAutoboxesToNumber() throws Exception {
        assertEquals("number:3", MethodUtils.invokeMethod(new Sample(), "numberArg", Integer.valueOf(3)));
    }

    @Test
    public void testInvokeMethodVarArgs() throws Exception {
        assertEquals("varargs:2", MethodUtils.invokeMethod(new Sample(), "varArgs", "a", "b"));
    }

    @Test
    public void testInvokeMethodNoMatchThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Sample(), "oneArg", Thread.currentThread());
            }
        });
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNullPointer() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "noArgs");
            }
        });
    }

    @Test
    public void testInvokeMethodPropagatesUnderlyingException() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Sample(), "throwing");
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    @Test
    public void testInvokeMethodWithoutForceAccessCannotReachPrivateMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Sample(), false, "privateEcho", "x");
            }
        });
    }

    @Test
    public void testInvokeMethodWithForceAccessReachesPrivateMethod() throws Exception {
        assertEquals("priv:x", MethodUtils.invokeMethod(new Sample(), true, "privateEcho", "x"));
    }

    // ---- invokeExactMethod ----

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        assertEquals("no-args", MethodUtils.invokeExactMethod(new Sample(), "noArgs"));
    }

    @Test
    public void testInvokeExactMethodExactMatch() throws Exception {
        assertEquals("one:x", MethodUtils.invokeExactMethod(new Sample(), "oneArg", "x"));
    }

    @Test
    public void testInvokeExactMethodRejectsAssignableOnlyMatch() {
        // Integer is assignable to Number, but invokeExactMethod requires the exact runtime type.
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new Sample(), "numberArg", Integer.valueOf(3));
            }
        });
    }

    @Test
    public void testInvokeExactMethodWithExplicitParamTypes() throws Exception {
        assertEquals("number:3", MethodUtils.invokeExactMethod(new Sample(), "numberArg",
                new Object[] {Integer.valueOf(3)}, new Class[] {Number.class}));
    }

    // ---- invokeStaticMethod / invokeExactStaticMethod ----

    @Test
    public void testInvokeStaticMethodNoArgs() throws Exception {
        assertEquals("static-no-args", MethodUtils.invokeStaticMethod(Sample.class, "staticNoArgs"));
    }

    @Test
    public void testInvokeStaticMethodWithArgs() throws Exception {
        assertEquals("static-one:x", MethodUtils.invokeStaticMethod(Sample.class, "staticOneArg", "x"));
    }

    @Test
    public void testInvokeStaticMethodNoMatchThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Sample.class, "staticOneArg", Thread.currentThread());
            }
        });
    }

    @Test
    public void testInvokeExactStaticMethodExactMatch() throws Exception {
        assertEquals("static-one:x", MethodUtils.invokeExactStaticMethod(Sample.class, "staticOneArg", "x"));
    }

    @Test
    public void testInvokeExactStaticMethodRejectsAssignableOnlyMatch() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(Sample.class, "staticOneArg",
                        new Object[] {Integer.valueOf(1)}, new Class[] {Object.class});
            }
        });
    }

    // ---- misc ----

    @Test
    public void testPublicNoArgConstructorIsUsable() {
        assertNotNull(new MethodUtils());
    }
}
