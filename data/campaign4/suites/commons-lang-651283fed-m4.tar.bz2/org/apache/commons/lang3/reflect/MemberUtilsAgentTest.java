/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MemberUtils}.
 */
public class MemberUtilsAgentTest {

    /** Package-private nested class: used to exercise setAccessibleWorkaround's "package superclass" case. */
    static class PackagePrivateHost {

        public void publicMethod() {
            // empty
        }

        void packageMethod() {
            // empty
        }

        private void privateMethod() {
            // empty
        }
    }

    /** Public nested class: public method already fully accessible without any workaround. */
    public static class PublicHost {

        public void publicMethod() {
            // empty
        }
    }

    /** Generic interface implementation triggers a synthetic bridge method. */
    static class NumberBox implements Comparable<NumberBox> {

        private final int value;

        NumberBox(final int value) {
            this.value = value;
        }

        @Override
        public int compareTo(final NumberBox other) {
            return Integer.compare(value, other.value);
        }
    }

    /** Overloaded methods/constructors used for fit-comparison and matching tests. */
    static class Overloads {

        Overloads(final String s) {
            // empty
        }

        Overloads(final Object o) {
            // empty
        }

        void call(final String s) {
            // empty
        }

        void call(final Object o) {
            // empty
        }

        void callVarArgs(final String first, final Object... rest) {
            // empty
        }

        void callNumberVarArgs(final String first, final Number... rest) {
            // empty
        }
    }

    // ---- isPublic ----

    @Test
    public void testIsPublicWithPublicMethod() throws Exception {
        final Method m = PackagePrivateHost.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicWithPackageMethod() throws Exception {
        final Method m = PackagePrivateHost.class.getDeclaredMethod("packageMethod");
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicWithPrivateMethod() throws Exception {
        final Method m = PackagePrivateHost.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicWithNull() {
        assertFalse(MemberUtils.isPublic(null));
    }

    // ---- isStatic ----

    @Test
    public void testIsStaticWithInstanceMethod() throws Exception {
        final Method m = PackagePrivateHost.class.getMethod("publicMethod");
        assertFalse(MemberUtils.isStatic(m));
    }

    @Test
    public void testIsStaticWithStaticConstructorLikeMember() throws Exception {
        final Constructor<Overloads> ctor = Overloads.class.getDeclaredConstructor(String.class);
        // constructors are never static
        assertFalse(MemberUtils.isStatic(ctor));
    }

    @Test
    public void testIsStaticWithNull() {
        assertFalse(MemberUtils.isStatic(null));
    }

    // ---- isPackage ----

    @Test
    public void testIsPackageWithNoModifiers() {
        assertTrue(MemberUtils.isPackage(0));
    }

    @Test
    public void testIsPackageWithPublicModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
    }

    @Test
    public void testIsPackageWithProtectedModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
    }

    @Test
    public void testIsPackageWithPrivateModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    public void testIsPackageWithUnrelatedModifier() {
        // STATIC alone does not imply an access level, so package access remains true
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
    }

    // ---- isAccessible ----

    @Test
    public void testIsAccessibleWithPublicNonSyntheticMethod() throws Exception {
        final Method m = NumberBox.class.getDeclaredMethod("compareTo", NumberBox.class);
        assertFalse(m.isSynthetic());
        assertTrue(MemberUtils.isAccessible(m));
    }

    @Test
    public void testIsAccessibleWithSyntheticBridgeMethod() throws Exception {
        Method bridge = null;
        for (final Method m : NumberBox.class.getDeclaredMethods()) {
            if (m.isBridge()) {
                bridge = m;
                break;
            }
        }
        assertNotNull(bridge, "expected the compiler to generate a bridge method for Comparable<NumberBox>");
        assertTrue(bridge.isSynthetic());
        assertTrue(Modifier.isPublic(bridge.getModifiers()));
        assertFalse(MemberUtils.isAccessible(bridge));
    }

    @Test
    public void testIsAccessibleWithPackagePrivateMethod() throws Exception {
        final Method m = PackagePrivateHost.class.getDeclaredMethod("packageMethod");
        assertFalse(MemberUtils.isAccessible(m));
    }

    // ---- isMatchingConstructor / isMatchingMethod ----

    @Test
    public void testIsMatchingConstructorExact() throws Exception {
        final Constructor<Overloads> ctor = Overloads.class.getDeclaredConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(ctor, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingConstructorAssignable() throws Exception {
        final Constructor<Overloads> ctor = Overloads.class.getDeclaredConstructor(Object.class);
        assertTrue(MemberUtils.isMatchingConstructor(ctor, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingConstructorNotAssignable() throws Exception {
        final Constructor<Overloads> ctor = Overloads.class.getDeclaredConstructor(String.class);
        assertFalse(MemberUtils.isMatchingConstructor(ctor, new Class[] {Integer.class}));
    }

    @Test
    public void testIsMatchingConstructorWrongArity() throws Exception {
        final Constructor<Overloads> ctor = Overloads.class.getDeclaredConstructor(String.class);
        assertFalse(MemberUtils.isMatchingConstructor(ctor, new Class[0]));
        assertFalse(MemberUtils.isMatchingConstructor(ctor, null));
    }

    @Test
    public void testIsMatchingMethodExact() throws Exception {
        final Method m = Overloads.class.getDeclaredMethod("call", String.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingMethodNotMatching() throws Exception {
        final Method m = Overloads.class.getDeclaredMethod("call", String.class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] {Integer.class}));
    }

    @Test
    public void testIsMatchingMethodVarArgsAcceptsZeroExtra() throws Exception {
        final Method m = Overloads.class.getDeclaredMethod("callVarArgs", String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingMethodVarArgsAcceptsMultipleExtra() throws Exception {
        final Method m = Overloads.class.getDeclaredMethod("callVarArgs", String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {String.class, Integer.class, "x".getClass()}));
    }

    @Test
    public void testIsMatchingMethodVarArgsRejectsBadLeadingType() throws Exception {
        final Method m = Overloads.class.getDeclaredMethod("callVarArgs", String.class, Object[].class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] {Integer.class}));
    }

    @Test
    public void testIsMatchingMethodVarArgsRejectsBadTrailingType() throws Exception {
        final Method m = Overloads.class.getDeclaredMethod("callNumberVarArgs", String.class, Number[].class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] {String.class, String.class}));
    }

    // ---- compareConstructorFit / compareMethodFit ----

    @Test
    public void testCompareMethodFitPrefersExactMatch() throws Exception {
        final Method strMethod = Overloads.class.getDeclaredMethod("call", String.class);
        final Method objMethod = Overloads.class.getDeclaredMethod("call", Object.class);
        final Class<?>[] actual = {String.class};
        assertTrue(MemberUtils.compareMethodFit(strMethod, objMethod, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(objMethod, strMethod, actual) > 0);
    }

    @Test
    public void testCompareMethodFitSameMethodIsZero() throws Exception {
        final Method strMethod = Overloads.class.getDeclaredMethod("call", String.class);
        final Class<?>[] actual = {String.class};
        assertEquals(0, MemberUtils.compareMethodFit(strMethod, strMethod, actual));
    }

    @Test
    public void testCompareConstructorFitPrefersExactMatch() throws Exception {
        final Constructor<Overloads> strCtor = Overloads.class.getDeclaredConstructor(String.class);
        final Constructor<Overloads> objCtor = Overloads.class.getDeclaredConstructor(Object.class);
        final Class<?>[] actual = {String.class};
        assertTrue(MemberUtils.compareConstructorFit(strCtor, objCtor, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(objCtor, strCtor, actual) > 0);
    }

    // ---- setAccessibleWorkaround ----

    @Test
    public void testSetAccessibleWorkaroundNull() {
        assertNull(MemberUtils.<Method>setAccessibleWorkaround(null));
    }

    @Test
    public void testSetAccessibleWorkaroundOnPublicMethodOfPackagePrivateClass() throws Exception {
        final Method m = PackagePrivateHost.class.getMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundOnPublicMethodOfPublicClassIsNoOp() throws Exception {
        final Method m = PublicHost.class.getMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        // declaring class is public, so the workaround does not need to flip the flag
        assertFalse(result.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundOnPrivateMethodIsNoOp() throws Exception {
        final Method m = PackagePrivateHost.class.getDeclaredMethod("privateMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertFalse(result.isAccessible());
    }
}
