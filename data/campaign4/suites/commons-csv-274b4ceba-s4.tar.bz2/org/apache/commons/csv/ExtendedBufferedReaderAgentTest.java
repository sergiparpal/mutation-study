package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Tests for {@link ExtendedBufferedReader} based solely on its documented contract.
 */
public class ExtendedBufferedReaderAgentTest {

    private static void assertNotAValidChar(final int value) {
        // Documented valid range for getLastChar() is 0 to 65535; sentinel values
        // (no char read yet, or EOF) must fall outside that range.
        assertTrue(value < 0 || value > 65535, "Expected a sentinel value outside 0-65535 but was " + value);
    }

    @Test
    public void testDefaultConstructorInitialState() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0L, reader.getPosition());
        assertEquals(0L, reader.getLineNumber());
        assertEquals(0L, reader.getBytesRead());
        assertNotAValidChar(reader.getLastChar());
    }

    @Test
    public void testReadSingleCharUpdatesPositionAndLastChar() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("AB"));

        final int c1 = reader.read();
        assertEquals('A', c1);
        assertEquals(1L, reader.getPosition());
        assertEquals('A', reader.getLastChar());

        final int c2 = reader.read();
        assertEquals('B', c2);
        assertEquals(2L, reader.getPosition());
        assertEquals('B', reader.getLastChar());

        final int c3 = reader.read();
        assertEquals(-1, c3);
        assertEquals(-1, reader.getLastChar());
        assertEquals(2L, reader.getPosition());
    }

    @Test
    public void testReadEmptyStreamReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(-1, reader.read());
        assertEquals(-1, reader.getLastChar());
        assertEquals(0L, reader.getPosition());
    }

    @Test
    public void testReadCharArrayUpdatesPositionAndLastChar() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("Hello"));
        final char[] buf = new char[3];

        final int n1 = reader.read(buf, 0, 3);
        assertEquals(3, n1);
        assertArrayEquals(new char[] {'H', 'e', 'l'}, buf);
        assertEquals(3L, reader.getPosition());
        assertEquals('l', reader.getLastChar());

        final int n2 = reader.read(buf, 0, 3);
        assertEquals(2, n2);
        assertEquals(5L, reader.getPosition());
        assertEquals('o', reader.getLastChar());

        final int n3 = reader.read(buf, 0, 3);
        assertEquals(-1, n3);
        assertEquals(-1, reader.getLastChar());
    }

    @Test
    public void testReadCharArrayZeroLengthReturnsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[3];
        final int n = reader.read(buf, 0, 0);
        assertEquals(0, n);
        assertEquals(0L, reader.getPosition());
    }

    @Test
    public void testReadCharArrayInvalidRangeThrowsIndexOutOfBoundsException() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[5];
        try {
            reader.read(buf, 3, 5);
            fail("Expected IndexOutOfBoundsException");
        } catch (final IndexOutOfBoundsException expected) {
            // expected per java.io.Reader#read(char[], int, int) contract
        } catch (final IOException e) {
            fail("Expected IndexOutOfBoundsException but got IOException: " + e);
        }
    }

    @Test
    public void testReadLineDropsLfAndIncrementsLineNumber() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2"));

        final String l1 = reader.readLine();
        assertEquals("line1", l1);
        assertEquals(1L, reader.getLineNumber());
        assertEquals('\n', reader.getLastChar());

        final String l2 = reader.readLine();
        assertEquals("line2", l2);
        assertEquals(2L, reader.getLineNumber());
        assertEquals(-1, reader.getLastChar());

        final String l3 = reader.readLine();
        assertNull(l3);
    }

    @Test
    public void testReadLineDropsCrLf() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\r\nb"));
        assertEquals("a", reader.readLine());
        assertEquals("b", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    public void testReadLineDropsCrOnly() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\rb"));
        assertEquals("a", reader.readLine());
        assertEquals("b", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    public void testReadLineReturnsNullAtEofOfEmptyStream() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertNull(reader.readLine());
        assertEquals(0L, reader.getLineNumber());
    }

    @Test
    public void testReadLineEmptyLines() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\n\n"));
        assertEquals("", reader.readLine());
        assertEquals(1L, reader.getLineNumber());
        assertEquals("", reader.readLine());
        assertEquals(2L, reader.getLineNumber());
        assertNull(reader.readLine());
    }

    @Test
    public void testMarkResetAllowsRereadingChars() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());

        reader.mark(10);
        assertEquals('c', reader.read());

        reader.reset();
        assertEquals('c', reader.read());
        assertEquals('d', reader.read());
    }

    @Test
    public void testResetWithoutMarkThrowsIOException() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        try {
            reader.reset();
            fail("Expected IOException");
        } catch (final IOException expected) {
            // expected: reset() is documented to throw IOException
        }
    }

    @Test
    public void testCloseThenReadThrowsIOException() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        reader.close();
        try {
            reader.read();
            fail("Expected IOException after close");
        } catch (final IOException expected) {
            // expected
        }
    }

    @Test
    public void testBytesReadIsZeroWhenNoByteTrackingByDefaultConstructor() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        reader.read();
        reader.read();
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testBytesReadIsZeroWhenTrackBytesExplicitlyFalse() throws IOException {
        final ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        reader.read();
        reader.read();
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testBytesReadIsZeroWhenTrackBytesTrueButCharsetNull() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), null, true);
        reader.read();
        reader.read();
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testBytesReadTracksEncodedBytesWhenEnabled() throws IOException {
        final ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        reader.read();
        reader.read();
        reader.read();
        assertEquals(3L, reader.getBytesRead());
    }

    @Test
    public void testPositionCountsCharactersNotBytes() throws IOException {
        // U+00E9 ('e' with acute accent) encodes to 2 bytes in UTF-8 but is a single char.
        final ExtendedBufferedReader reader =
                new ExtendedBufferedReader(new StringReader("é"), StandardCharsets.UTF_8, true);
        final int c = reader.read();
        assertEquals('é', c);
        assertEquals(1L, reader.getPosition());
        assertEquals(2L, reader.getBytesRead());
    }
}
