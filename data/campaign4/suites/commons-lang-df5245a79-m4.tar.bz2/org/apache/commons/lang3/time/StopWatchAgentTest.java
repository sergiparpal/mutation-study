/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link StopWatch}.
 */
class StopWatchAgentTest {

    @Test
    void testCreateFactoryReturnsUnstartedWatch() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testCreateStartedFactoryReturnsStartedWatch() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    void testMessageConstructorStoresMessage() {
        final StopWatch watch = new StopWatch("myMessage");
        assertEquals("myMessage", watch.getMessage());
    }

    @Test
    void testGetNanoTimeBeforeStartIsZero() {
        final StopWatch watch = new StopWatch();
        assertEquals(0L, watch.getNanoTime());
        assertEquals(0L, watch.getTime());
        assertEquals(Duration.ZERO, watch.getDuration());
    }

    @Test
    void testStartSetsRunningState() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
        Thread.sleep(20);
        final long nanos = watch.getNanoTime();
        assertTrue(nanos > 0, "expected elapsed nanos > 0 but was " + nanos);
    }

    @Test
    void testStartTwiceWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.start();
            }
        });
        assertEquals("Stopwatch already started.", e.getMessage());
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.start();
            }
        });
        assertEquals("Stopwatch must be reset before being restarted.", e.getMessage());
    }

    @Test
    void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.stop();
            }
        });
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testStopSetsStoppedState() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(10);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        final long stoppedTime = watch.getTime();
        // Time must not advance further once stopped.
        assertEquals(stoppedTime, watch.getTime());
    }

    @Test
    void testResetReturnsToUnstartedState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertEquals(0L, watch.getNanoTime());
        assertTrue(watch.getSplits().isEmpty());
        // Reset allows starting again without an exception.
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.suspend();
            }
        });
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.suspend();
            }
        });
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.resume();
            }
        });
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    void testSuspendAndResumeDoesNotCountSuspendedTime() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(20);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedNanos = watch.getNanoTime();
        Thread.sleep(50);
        // Time frozen while suspended.
        assertEquals(suspendedNanos, watch.getNanoTime());
        watch.resume();
        assertTrue(watch.isStarted());
        assertFalse(watch.isSuspended());
        final long resumedNanos = watch.getNanoTime();
        assertTrue(resumedNanos >= suspendedNanos);
    }

    @Test
    void testSplitWithoutRunningThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.split();
            }
        });
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getSplitTime();
            }
        });
        assertEquals("Stopwatch must be split to get the split time.", e.getMessage());
    }

    @Test
    void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getSplitNanoTime();
            }
        });
        assertEquals("Stopwatch must be split to get the split time.", e.getMessage());
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.unsplit();
            }
        });
        assertEquals("Stopwatch has not been split.", e.getMessage());
    }

    @Test
    void testSplitRecordsSplitTimeAndKeepsWatchRunning() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(20);
        watch.split();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        final long splitNanos = watch.getSplitNanoTime();
        assertTrue(splitNanos > 0, "expected split nanos > 0 but was " + splitNanos);
        assertEquals(Duration.ofNanos(splitNanos), watch.getSplitDuration());
        assertEquals(splitNanos / 1000000L, watch.getSplitTime());
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertEquals(Duration.ofNanos(splitNanos), splits.get(0).getDuration());
    }

    @Test
    void testSplitWithLabelStoresLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
    }

    @Test
    void testMultipleSplitsAccumulateInOrder() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        watch.unsplit();
        watch.split("b");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("b", splits.get(0).getLabel());
    }

    @Test
    void testUnsplitRemovesLastSplitAndKeepsStartTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
        // getSplitTime is no longer valid once unsplit.
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getSplitNanoTime();
            }
        });
        // The watch must still be running, start time unaffected.
        assertTrue(watch.isStarted());
    }

    @Test
    void testGetSplitsReturnsUnmodifiableView() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getStartInstant();
            }
        });
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    void testGetStartInstantAndStartTimeAfterStart() {
        final StopWatch watch = new StopWatch();
        final Instant before = Instant.now();
        watch.start();
        final Instant after = Instant.now();
        final Instant started = watch.getStartInstant();
        assertNotNull(started);
        assertFalse(started.isBefore(before.minusSeconds(1)));
        assertFalse(started.isAfter(after.plusSeconds(1)));
        assertEquals(started.toEpochMilli(), watch.getStartTime());
    }

    @Test
    void testGetStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getStopInstant();
            }
        });
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    void testGetStopInstantAfterStop() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final Instant stopped = watch.getStopInstant();
        assertNotNull(stopped);
        assertEquals(stopped.toEpochMilli(), watch.getStopTime());
    }

    @Test
    void testGetTimeWithTimeUnitConversion() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final long nanos = watch.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), watch.getTime(TimeUnit.MILLISECONDS));
        assertEquals(TimeUnit.NANOSECONDS.toSeconds(nanos), watch.getTime(TimeUnit.SECONDS));
    }

    @Test
    void testFormatTimeAndToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String formatted = watch.formatTime();
        assertEquals(formatted, watch.toString());
        assertTrue(formatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"), "unexpected format: " + formatted);
    }

    @Test
    void testToStringWithMessagePrefixesMessage() {
        final StopWatch watch = new StopWatch("prefix");
        watch.start();
        watch.stop();
        final String str = watch.toString();
        assertTrue(str.startsWith("prefix "), "expected message prefix in: " + str);
    }

    @Test
    void testFormatSplitTimeAndToSplitStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String formatted = watch.formatSplitTime();
        assertEquals(formatted, watch.toSplitString());
        assertTrue(formatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"), "unexpected format: " + formatted);
    }

    @Test
    void testToSplitStringWithMessagePrefixesMessage() {
        final StopWatch watch = new StopWatch("splitMsg");
        watch.start();
        watch.split();
        final String str = watch.toSplitString();
        assertTrue(str.startsWith("splitMsg "), "expected message prefix in: " + str);
    }

    @Test
    void testGetDelegatesAndSuspendsAfterCall() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetResumesSuspendedWatchAndSuspendsAgain() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final Integer result = watch.get(new java.util.function.Supplier<Integer>() {
            @Override
            public Integer get() {
                return 42;
            }
        });
        assertEquals(Integer.valueOf(42), result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunDelegatesAndSuspendsAfterCall() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = new boolean[1];
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTPropagatesThrowable() {
        final StopWatch watch = new StopWatch();
        final Exception thrown = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getT(new FailableSupplier<String, Exception>() {
                    @Override
                    public String get() throws Exception {
                        throw new java.io.IOException("boom");
                    }
                });
            }
        });
        assertEquals("boom", thrown.getMessage());
        // Even though the supplier failed, the watch must still be suspended afterwards.
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesThrowable() {
        final StopWatch watch = new StopWatch();
        final Exception thrown = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw new java.io.IOException("bang");
                    }
                });
            }
        });
        assertEquals("bang", thrown.getMessage());
        assertTrue(watch.isSuspended());
    }

    @Test
    void testSplitClassAccessors() {
        final Duration duration = Duration.ofMillis(123);
        final StopWatch.Split split = new StopWatch.Split("label1", duration);
        assertEquals("label1", split.getLabel());
        assertSame(duration, split.getDuration());
        assertEquals("label1", split.getLeft());
        assertEquals(duration, split.getRight());
        assertTrue(split.toString().contains("label1"));
    }
}
