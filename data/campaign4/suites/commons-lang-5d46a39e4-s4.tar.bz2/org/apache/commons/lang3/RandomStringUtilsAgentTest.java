package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RandomStringUtils}, based solely on the documented
 * contract in the generated javadoc.
 */
public class RandomStringUtilsAgentTest {

    // ---------------------------------------------------------------
    // helpers
    // ---------------------------------------------------------------

    private static boolean isAsciiLetter(final char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    private static boolean isAsciiDigit(final char c) {
        return c >= '0' && c <= '9';
    }

    private static void assertAllLetters(final String s) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(isAsciiLetter(s.charAt(i)), "expected a letter but got: " + s.charAt(i));
        }
    }

    private static void assertAllDigits(final String s) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(isAsciiDigit(s.charAt(i)), "expected a digit but got: " + s.charAt(i));
        }
    }

    private static void assertAllLetterOrDigit(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(isAsciiLetter(c) || isAsciiDigit(c), "expected a letter or digit but got: " + c);
        }
    }

    private static void assertAllInRange(final String s, final int lowInclusive, final int highInclusive) {
        for (int i = 0; i < s.length(); i++) {
            final int c = s.charAt(i);
            assertTrue(c >= lowInclusive && c <= highInclusive,
                    "char " + c + " not in range [" + lowInclusive + "," + highInclusive + "]");
        }
    }

    /** Private high surrogates (0xDB80-0xDBFF) must never be produced. */
    private static void assertNoPrivateHighSurrogates(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertFalse(c >= 0xDB80 && c <= 0xDBFF, "private high surrogate found: " + Integer.toHexString(c));
        }
    }

    /** High/low surrogates must always be correctly paired. */
    private static void assertSurrogatePairingValid(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (Character.isHighSurrogate(c)) {
                assertTrue(i + 1 < s.length() && Character.isLowSurrogate(s.charAt(i + 1)),
                        "unpaired high surrogate at index " + i);
            } else if (Character.isLowSurrogate(c)) {
                assertTrue(i > 0 && Character.isHighSurrogate(s.charAt(i - 1)),
                        "unpaired low surrogate at index " + i);
            }
        }
    }

    // ---------------------------------------------------------------
    // deprecated static random(...) family
    // ---------------------------------------------------------------

    @Test
    public void testStaticRandomCount() {
        assertEquals("", RandomStringUtils.random(0));
        final String s = RandomStringUtils.random(100);
        assertNotNull(s);
        assertEquals(100, s.length());
        assertSurrogatePairingValid(s);
        assertNoPrivateHighSurrogates(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    public void testStaticRandomCountLettersNumbers() {
        assertAllLetters(RandomStringUtils.random(50, true, false));
        assertAllDigits(RandomStringUtils.random(50, false, true));
        assertAllLetterOrDigit(RandomStringUtils.random(50, true, true));
        assertEquals(0, RandomStringUtils.random(0, true, true).length());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, true, true);
            }
        });
    }

    @Test
    public void testStaticRandomCountCharsVarargs() {
        final String s = RandomStringUtils.random(30, 'x');
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertEquals('x', s.charAt(i));
        }
        assertEquals(0, RandomStringUtils.random(0, (char[]) null).length());
        assertEquals(20, RandomStringUtils.random(20, (char[]) null).length());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 'a', 'b');
            }
        });
    }

    @Test
    public void testStaticRandomStartEndLettersNumbers() {
        final String lower = RandomStringUtils.random(40, 97, 123, true, false);
        assertEquals(40, lower.length());
        for (int i = 0; i < lower.length(); i++) {
            assertTrue(lower.charAt(i) >= 'a' && lower.charAt(i) <= 'z');
        }
        final String digits = RandomStringUtils.random(40, 48, 58, false, true);
        assertAllDigits(digits);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true);
            }
        });
    }

    @Test
    public void testStaticRandomStartEndLettersNumbersCharsVarargs() {
        final char[] chars = {'a', 'b', 'c'};
        final String s = RandomStringUtils.random(25, 0, chars.length, false, false, chars);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c');
        }
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true, (char[]) null);
            }
        });
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                final char[] tooSmall = {'a', 'b', 'c'};
                RandomStringUtils.random(5, 5, 10, false, false, tooSmall);
            }
        });
    }

    @Test
    public void testStaticRandomCountString() {
        assertEquals("zzz", RandomStringUtils.random(3, "z"));
        assertEquals(15, RandomStringUtils.random(15, (String) null).length());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, "abc");
            }
        });
    }

    @Test
    public void testStaticRandomWithSuppliedRandomDigitsRange() {
        final Random r1 = new Random(42L);
        final Random r2 = new Random(42L);
        final String s1 = RandomStringUtils.random(60, 48, 58, false, false, null, r1);
        final String s2 = RandomStringUtils.random(60, 48, 58, false, false, null, r2);
        assertEquals(60, s1.length());
        assertEquals(s1, s2);
        assertAllDigits(s1);
    }

    @Test
    public void testStaticRandomWithSuppliedRandomLettersRange() {
        final String s = RandomStringUtils.random(40, 97, 123, true, false, null, new Random(7L));
        assertEquals(40, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(s.charAt(i) >= 'a' && s.charAt(i) <= 'z');
        }
    }

    @Test
    public void testStaticRandomWithSuppliedRandomDefaultRangeIsReproducible() {
        final String s1 = RandomStringUtils.random(50, 0, 0, false, false, null, new Random(99L));
        final String s2 = RandomStringUtils.random(50, 0, 0, false, false, null, new Random(99L));
        assertNotNull(s1);
        assertEquals(s1, s2);
    }

    @Test
    public void testStaticRandomWithSuppliedRandomErrors() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, false, false, null, new Random(1L));
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 0, false, false, new char[0], new Random(1L));
            }
        });
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                final char[] tooSmall = {'a', 'b', 'c'};
                RandomStringUtils.random(5, 5, 10, false, false, tooSmall, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomAlphabetic() {
        assertEquals("", RandomStringUtils.randomAlphabetic(0));
        final String s = RandomStringUtils.randomAlphabetic(50);
        assertEquals(50, s.length());
        assertAllLetters(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(-1);
            }
        });
        final String bounded = RandomStringUtils.randomAlphabetic(5, 6);
        assertEquals(5, bounded.length());
        assertAllLetters(bounded);
        final String ranged = RandomStringUtils.randomAlphabetic(3, 8);
        assertTrue(ranged.length() >= 3 && ranged.length() < 8);
    }

    @Test
    public void testStaticRandomAlphanumeric() {
        assertEquals("", RandomStringUtils.randomAlphanumeric(0));
        final String s = RandomStringUtils.randomAlphanumeric(50);
        assertEquals(50, s.length());
        assertAllLetterOrDigit(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphanumeric(-1);
            }
        });
        final String bounded = RandomStringUtils.randomAlphanumeric(5, 6);
        assertEquals(5, bounded.length());
        assertAllLetterOrDigit(bounded);
    }

    @Test
    public void testStaticRandomAscii() {
        assertEquals("", RandomStringUtils.randomAscii(0));
        final String s = RandomStringUtils.randomAscii(80);
        assertEquals(80, s.length());
        assertAllInRange(s, 32, 126);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAscii(-1);
            }
        });
        final String bounded = RandomStringUtils.randomAscii(5, 6);
        assertEquals(5, bounded.length());
        assertAllInRange(bounded, 32, 126);
    }

    @Test
    public void testStaticRandomGraph() {
        assertEquals("", RandomStringUtils.randomGraph(0));
        final String s = RandomStringUtils.randomGraph(80);
        assertEquals(80, s.length());
        assertAllInRange(s, 33, 126);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomGraph(-1);
            }
        });
        final String bounded = RandomStringUtils.randomGraph(5, 6);
        assertEquals(5, bounded.length());
        assertAllInRange(bounded, 33, 126);
    }

    @Test
    public void testStaticRandomNumeric() {
        assertEquals("", RandomStringUtils.randomNumeric(0));
        final String s = RandomStringUtils.randomNumeric(50);
        assertEquals(50, s.length());
        assertAllDigits(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomNumeric(-1);
            }
        });
        final String bounded = RandomStringUtils.randomNumeric(5, 6);
        assertEquals(5, bounded.length());
        assertAllDigits(bounded);
    }

    @Test
    public void testStaticRandomPrint() {
        assertEquals("", RandomStringUtils.randomPrint(0));
        final String s = RandomStringUtils.randomPrint(80);
        assertEquals(80, s.length());
        assertAllInRange(s, 32, 126);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomPrint(-1);
            }
        });
        final String bounded = RandomStringUtils.randomPrint(5, 6);
        assertEquals(5, bounded.length());
        assertAllInRange(bounded, 32, 126);
    }

    // ---------------------------------------------------------------
    // singleton accessors
    // ---------------------------------------------------------------

    @Test
    public void testInsecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testSecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    public void testSecureStrongSingleton() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertSame(a, b);
    }

    // ---------------------------------------------------------------
    // instance next(...) family (exercised via insecure(), which is fast)
    // ---------------------------------------------------------------

    @Test
    public void testNextCount() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.next(0));
        final String s = rsu.next(200);
        assertEquals(200, s.length());
        assertSurrogatePairingValid(s);
        assertNoPrivateHighSurrogates(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1);
            }
        });
    }

    @Test
    public void testNextCountLettersNumbers() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertAllLetters(rsu.next(50, true, false));
        assertAllDigits(rsu.next(50, false, true));
        assertAllLetterOrDigit(rsu.next(50, true, true));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1, true, true);
            }
        });
    }

    @Test
    public void testNextCountCharsVarargs() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final String s = rsu.next(30, 'x');
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertEquals('x', s.charAt(i));
        }
        assertEquals(20, rsu.next(20, (char[]) null).length());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1, 'a', 'b');
            }
        });
    }

    @Test
    public void testNextCountString() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("zzz", rsu.next(3, "z"));
        assertEquals(15, rsu.next(15, (String) null).length());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, "");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1, "abc");
            }
        });
    }

    @Test
    public void testNextStartEndLettersNumbers() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final String lower = rsu.next(40, 97, 123, true, false);
        assertEquals(40, lower.length());
        for (int i = 0; i < lower.length(); i++) {
            assertTrue(lower.charAt(i) >= 'a' && lower.charAt(i) <= 'z');
        }
        final String digits = rsu.next(40, 48, 58, false, true);
        assertAllDigits(digits);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1, 0, 0, true, true);
            }
        });
    }

    @Test
    public void testNextStartEndLettersNumbersCharsVarargs() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final char[] chars = {'a', 'b', 'c'};
        final String s = rsu.next(25, 0, chars.length, false, false, chars);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c');
        }
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1, 0, 0, true, true, (char[]) null);
            }
        });
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                final char[] tooSmall = {'a', 'b', 'c'};
                RandomStringUtils.insecure().next(5, 5, 10, false, false, tooSmall);
            }
        });
    }

    @Test
    public void testNextAlphabetic() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.nextAlphabetic(0));
        final String s = rsu.nextAlphabetic(50);
        assertEquals(50, s.length());
        assertAllLetters(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAlphabetic(-1);
            }
        });
        final String bounded = rsu.nextAlphabetic(5, 6);
        assertEquals(5, bounded.length());
        assertAllLetters(bounded);
    }

    @Test
    public void testNextAlphanumeric() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.nextAlphanumeric(0));
        final String s = rsu.nextAlphanumeric(50);
        assertEquals(50, s.length());
        assertAllLetterOrDigit(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAlphanumeric(-1);
            }
        });
        final String bounded = rsu.nextAlphanumeric(5, 6);
        assertEquals(5, bounded.length());
        assertAllLetterOrDigit(bounded);
    }

    @Test
    public void testNextAscii() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.nextAscii(0));
        final String s = rsu.nextAscii(80);
        assertEquals(80, s.length());
        assertAllInRange(s, 32, 126);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAscii(-1);
            }
        });
        final String bounded = rsu.nextAscii(5, 6);
        assertEquals(5, bounded.length());
        assertAllInRange(bounded, 32, 126);
    }

    @Test
    public void testNextGraph() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.nextGraph(0));
        final String s = rsu.nextGraph(80);
        assertEquals(80, s.length());
        assertAllInRange(s, 33, 126);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextGraph(-1);
            }
        });
        final String bounded = rsu.nextGraph(5, 6);
        assertEquals(5, bounded.length());
        assertAllInRange(bounded, 33, 126);
    }

    @Test
    public void testNextNumeric() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.nextNumeric(0));
        final String s = rsu.nextNumeric(50);
        assertEquals(50, s.length());
        assertAllDigits(s);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextNumeric(-1);
            }
        });
        final String bounded = rsu.nextNumeric(5, 6);
        assertEquals(5, bounded.length());
        assertAllDigits(bounded);
    }

    @Test
    public void testNextPrint() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        assertEquals("", rsu.nextPrint(0));
        final String s = rsu.nextPrint(80);
        assertEquals(80, s.length());
        assertAllInRange(s, 32, 126);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextPrint(-1);
            }
        });
        final String bounded = rsu.nextPrint(5, 6);
        assertEquals(5, bounded.length());
        assertAllInRange(bounded, 32, 126);
    }

    @Test
    public void testSecureInstanceNextProducesExpectedLengthAndCharset() {
        final RandomStringUtils rsu = RandomStringUtils.secure();
        final String s = rsu.nextAlphanumeric(40);
        assertEquals(40, s.length());
        assertAllLetterOrDigit(s);
    }

    @Test
    public void testToString() {
        final RandomStringUtils rsu = RandomStringUtils.insecure();
        final String first = rsu.toString();
        final String second = rsu.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }
}
