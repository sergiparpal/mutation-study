/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;

/**
 * Test class for {@code EventCountCircuitBreaker}.
 */
class EventCountCircuitBreakerAgentTest {

    /**
     * A test double for {@code EventCountCircuitBreaker} that allows the current time to be
     * controlled manually so that check interval boundaries can be tested deterministically.
     */
    private static final class ControllableTimeCircuitBreaker extends EventCountCircuitBreaker {

        private long currentTime;

        ControllableTimeCircuitBreaker(final int openingThreshold, final long openingInterval, final TimeUnit openingUnit,
                final int closingThreshold, final long closingInterval, final TimeUnit closingUnit) {
            super(openingThreshold, openingInterval, openingUnit, closingThreshold, closingInterval, closingUnit);
        }

        void advanceTime(final long amount, final TimeUnit unit) {
            currentTime += unit.toNanos(amount);
        }

        @Override
        long nanoTime() {
            return currentTime;
        }
    }

    @Test
    void testThreeArgConstructorUsesSameThresholdAndInterval() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 2, TimeUnit.SECONDS);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getClosingInterval());
    }

    @Test
    void testFourArgConstructorUsesSameIntervalForBothChecks() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 3, TimeUnit.SECONDS, 4);
        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(4, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(3), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(3), breaker.getClosingInterval());
    }

    @Test
    void testSixArgConstructorSetsAllPropertiesIndependently() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 2, TimeUnit.MINUTES, 5, 10, TimeUnit.MINUTES);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.MINUTES.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.MINUTES.toNanos(10), breaker.getClosingInterval());
    }

    @Test
    void testInitialStateIsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
        assertTrue(breaker.checkState());
    }

    @Test
    void testNegativeIncrementIsRejected() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        try {
            breaker.incrementAndCheckState(Integer.valueOf(-1));
            fail("Expected an IllegalArgumentException for a negative increment");
        } catch (final IllegalArgumentException ex) {
            assertTrue(ex.getMessage().contains("-1"));
        }
        // the rejected increment must not have changed the state
        assertTrue(breaker.isClosed());
    }

    @Test
    void testZeroIncrementDoesNotOpenBreaker() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        for (int i = 0; i < 10; i++) {
            assertTrue(breaker.incrementAndCheckState(Integer.valueOf(0)));
        }
        assertTrue(breaker.isClosed());
    }

    @Test
    void testIncrementAndCheckStateNoArgIncrementsByOne() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(3, 1, TimeUnit.SECONDS, 3, 1, TimeUnit.SECONDS);
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        // fourth event within the same interval exceeds the threshold of 3
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testExceedingOpeningThresholdWithinIntervalOpensBreaker() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(5, 1, TimeUnit.SECONDS, 5, 1, TimeUnit.SECONDS);
        for (int i = 0; i < 5; i++) {
            assertTrue(breaker.incrementAndCheckState());
        }
        // the sixth event in the same interval exceeds the threshold
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
        assertFalse(breaker.isClosed());
    }

    @Test
    void testZeroOpeningThresholdOpensOnFirstEvent() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(0, 1, TimeUnit.SECONDS, 0, 1, TimeUnit.SECONDS);
        assertTrue(breaker.isClosed());
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testEventsSpreadOverMultipleIntervalsDoNotAccumulate() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(5, 1, TimeUnit.SECONDS, 5, 1, TimeUnit.SECONDS);
        for (int i = 0; i < 5; i++) {
            assertTrue(breaker.incrementAndCheckState());
        }
        assertTrue(breaker.isClosed());

        // move past the end of the check interval; the counter must reset instead of
        // continuing to accumulate, so another batch of 5 must not trip the breaker either
        breaker.advanceTime(2, TimeUnit.SECONDS);
        for (int i = 0; i < 5; i++) {
            assertTrue(breaker.incrementAndCheckState());
        }
        assertTrue(breaker.isClosed());
    }

    @Test
    void testBreakerClosesAgainAfterLowActivityDuringClosingInterval() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(5, 1, TimeUnit.SECONDS, 5, 1, TimeUnit.SECONDS);
        for (int i = 0; i < 5; i++) {
            breaker.incrementAndCheckState();
        }
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());

        // move past the closing interval without generating further events;
        // since the event count during the open interval (0) is below the closing threshold,
        // the breaker should close itself again
        breaker.advanceTime(2, TimeUnit.SECONDS);
        assertTrue(breaker.checkState());
        assertTrue(breaker.isClosed());
    }

    @Test
    void testBreakerStaysOpenIfActivityRemainsAboveClosingThreshold() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(5, 1, TimeUnit.SECONDS, 5, 1, TimeUnit.SECONDS);
        for (int i = 0; i < 6; i++) {
            breaker.incrementAndCheckState();
        }
        assertTrue(breaker.isOpen());

        // generate more events than the closing threshold while still within the open interval
        for (int i = 0; i < 6; i++) {
            breaker.incrementAndCheckState();
        }
        assertTrue(breaker.isOpen());

        // now move past the closing interval; since activity during the just-finished
        // interval (6) is not below the closing threshold (5), the breaker must stay open
        breaker.advanceTime(2, TimeUnit.SECONDS);
        assertFalse(breaker.checkState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testManualOpenAndClose() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        breaker.open();
        assertTrue(breaker.isOpen());
        assertFalse(breaker.checkState());

        breaker.close();
        assertTrue(breaker.isClosed());
        assertTrue(breaker.checkState());
    }

    @Test
    void testChangeListenerIsNotifiedOnStateTransition() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        final AtomicInteger callCount = new AtomicInteger();
        final PropertyChangeListener listener = new PropertyChangeListener() {
            @Override
            public void propertyChange(final PropertyChangeEvent evt) {
                callCount.incrementAndGet();
                assertEquals(AbstractCircuitBreaker.PROPERTY_NAME, evt.getPropertyName());
                assertEquals(Boolean.FALSE, evt.getOldValue());
                assertEquals(Boolean.TRUE, evt.getNewValue());
            }
        };
        breaker.addChangeListener(listener);
        breaker.open();
        assertEquals(1, callCount.get());
    }

    @Test
    void testChangeListenerCanBeRemoved() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        final AtomicInteger callCount = new AtomicInteger();
        final PropertyChangeListener listener = new PropertyChangeListener() {
            @Override
            public void propertyChange(final PropertyChangeEvent evt) {
                callCount.incrementAndGet();
            }
        };
        breaker.addChangeListener(listener);
        breaker.removeChangeListener(listener);
        breaker.open();
        assertEquals(0, callCount.get());
    }

    @Test
    void testNullChangeListenerIsIgnored() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.SECONDS);
        breaker.addChangeListener(null);
        breaker.open();
        assertTrue(breaker.isOpen());
    }

    @Test
    void testCloseResetsCounterSoThresholdCanBeReachedAgain() {
        final ControllableTimeCircuitBreaker breaker = new ControllableTimeCircuitBreaker(5, 1, TimeUnit.SECONDS, 5, 1, TimeUnit.SECONDS);
        for (int i = 0; i < 4; i++) {
            assertTrue(breaker.incrementAndCheckState());
        }
        breaker.close();
        // after closing, the internal counter is reset, so 4 more events should not open it
        for (int i = 0; i < 4; i++) {
            assertTrue(breaker.incrementAndCheckState());
        }
        assertTrue(breaker.isClosed());
    }

}
