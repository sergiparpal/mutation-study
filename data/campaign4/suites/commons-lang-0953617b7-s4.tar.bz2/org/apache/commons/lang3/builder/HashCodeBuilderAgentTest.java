package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class HashCodeBuilderAgentTest {

    private static class Empty {
    }

    private static class TwoFields {
        @SuppressWarnings("unused")
        private int a = 1;
        @SuppressWarnings("unused")
        private int b = 2;
    }

    private static class Parent {
        @SuppressWarnings("unused")
        private int p = 1;
    }

    private static class Child extends Parent {
        @SuppressWarnings("unused")
        private int c = 2;
    }

    private static class Transientish {
        @SuppressWarnings("unused")
        private transient int t;

        Transientish(final int t) {
            this.t = t;
        }
    }

    // ---- constructors ----

    @Test
    public void testDefaultConstructorIsDeterministic() {
        final HashCodeBuilder hcb = new HashCodeBuilder();
        final int first = hcb.toHashCode();
        final int second = hcb.toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testTwoArgConstructorStartsAtInitialValue() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37);
        assertEquals(17, hcb.toHashCode());
    }

    @Test
    public void testTwoArgConstructorAllowsNegativeOddNumbers() {
        final HashCodeBuilder hcb = new HashCodeBuilder(-3, -5);
        assertEquals(-3, hcb.toHashCode());
    }

    @Test
    public void testConstructorRejectsEvenInitialNumber() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(2, 37);
            }
        });
    }

    @Test
    public void testConstructorRejectsEvenMultiplierNumber() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 4);
            }
        });
    }

    @Test
    public void testConstructorRejectsZeroInitialNumber() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(0, 37);
            }
        });
    }

    @Test
    public void testConstructorRejectsZeroMultiplierNumber() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 0);
            }
        });
    }

    // ---- append(boolean) ----

    @Test
    public void testAppendBooleanTrueAddsOne() {
        assertEquals(2, new HashCodeBuilder(1, 1).append(true).toHashCode());
    }

    @Test
    public void testAppendBooleanFalseAddsZero() {
        assertEquals(1, new HashCodeBuilder(1, 1).append(false).toHashCode());
    }

    @Test
    public void testAppendBooleanArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new boolean[] {true, false}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new boolean[] {true, false}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((boolean[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((boolean[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(byte) ----

    @Test
    public void testAppendByte() {
        final int first = new HashCodeBuilder(3, 5).append((byte) 9).toHashCode();
        final int second = new HashCodeBuilder(3, 5).append((byte) 9).toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testAppendByteArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new byte[] {1, 2, 3}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new byte[] {1, 2, 3}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((byte[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((byte[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(char) ----

    @Test
    public void testAppendChar() {
        final int first = new HashCodeBuilder(3, 5).append('Q').toHashCode();
        final int second = new HashCodeBuilder(3, 5).append('Q').toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testAppendCharArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new char[] {'a', 'b'}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new char[] {'a', 'b'}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((char[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((char[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(short) ----

    @Test
    public void testAppendShort() {
        final int first = new HashCodeBuilder(3, 5).append((short) 11).toHashCode();
        final int second = new HashCodeBuilder(3, 5).append((short) 11).toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testAppendShortArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new short[] {1, 2}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new short[] {1, 2}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((short[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((short[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(int) ----

    @Test
    public void testAppendIntMatchesDocumentedExample() {
        // From the class javadoc: initial=17, multiplier=37, appending 45 gives 17*37+45=674.
        assertEquals(674, new HashCodeBuilder(17, 37).append(45).toHashCode());
    }

    @Test
    public void testAppendIntArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new int[] {1, 2, 3}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new int[] {1, 2, 3}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((int[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((int[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(long) ----

    @Test
    public void testAppendLong() {
        final int first = new HashCodeBuilder(3, 5).append(123456789L).toHashCode();
        final int second = new HashCodeBuilder(3, 5).append(123456789L).toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testAppendLongArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new long[] {1L, 2L}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new long[] {1L, 2L}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((long[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((long[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(float) ----

    @Test
    public void testAppendFloat() {
        final int first = new HashCodeBuilder(3, 5).append(1.5f).toHashCode();
        final int second = new HashCodeBuilder(3, 5).append(1.5f).toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testAppendFloatArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new float[] {1.5f, 2.5f}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new float[] {1.5f, 2.5f}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((float[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((float[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(double) ----

    @Test
    public void testAppendDouble() {
        final int first = new HashCodeBuilder(3, 5).append(1.5d).toHashCode();
        final int second = new HashCodeBuilder(3, 5).append(1.5d).toHashCode();
        assertEquals(first, second);
    }

    @Test
    public void testAppendDoubleArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new double[] {1.5d, 2.5d}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new double[] {1.5d, 2.5d}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((double[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((double[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- append(Object) / append(Object[]) ----

    @Test
    public void testAppendObject() {
        final int first = new HashCodeBuilder(3, 5).append(Integer.valueOf(9)).toHashCode();
        final int second = new HashCodeBuilder(3, 5).append(Integer.valueOf(9)).toHashCode();
        assertEquals(first, second);

        final int withNull = new HashCodeBuilder(3, 5).append((Object) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((Object) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    @Test
    public void testAppendObjectArray() {
        final int withArray = new HashCodeBuilder(3, 5).append(new Object[] {"a", "b"}).toHashCode();
        final int sameArray = new HashCodeBuilder(3, 5).append(new Object[] {"a", "b"}).toHashCode();
        assertEquals(withArray, sameArray);

        final int withNull = new HashCodeBuilder(3, 5).append((Object[]) null).toHashCode();
        final int withNullAgain = new HashCodeBuilder(3, 5).append((Object[]) null).toHashCode();
        assertEquals(withNull, withNullAgain);
    }

    // ---- appendSuper ----

    @Test
    public void testAppendSuperAppliesFormula() {
        assertEquals(6, new HashCodeBuilder(1, 1).appendSuper(5).toHashCode());
    }

    // ---- fluent chaining ----

    @Test
    public void testAllAppendMethodsReturnThisInstance() {
        final HashCodeBuilder hcb = new HashCodeBuilder(3, 5);
        final HashCodeBuilder returned = hcb.append(true)
                .append((byte) 1)
                .append('a')
                .append((short) 2)
                .append(3)
                .append(4L)
                .append(5f)
                .append(6d)
                .append(new Object())
                .append(new boolean[] {true})
                .append(new byte[] {1})
                .append(new char[] {'a'})
                .append(new short[] {1})
                .append(new int[] {1})
                .append(new long[] {1L})
                .append(new float[] {1f})
                .append(new double[] {1d})
                .append(new Object[] {"x"})
                .appendSuper(7);
        assertSame(hcb, returned);
    }

    // ---- build / toHashCode / hashCode ----

    @Test
    public void testBuildToHashCodeAndHashCodeAgree() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37).append(45);
        assertEquals(Integer.valueOf(674), hcb.build());
        assertEquals(674, hcb.toHashCode());
        assertEquals(674, hcb.hashCode());
    }

    // ---- equals ----

    @Test
    public void testEqualsUsesHashCode() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(45);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(45);
        final HashCodeBuilder c = new HashCodeBuilder(17, 37).append(46);

        assertTrue(a.equals(a));
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertFalse(a.equals(c));
        assertFalse(a.equals(null));
        assertFalse(a.equals("not a HashCodeBuilder"));
    }

    // ---- builder() factory ----

    @Test
    public void testBuilderFactoryChainingAndGet() {
        final HashCodeBuilder.Builder builder = HashCodeBuilder.builder();
        assertNotNull(builder);
        assertSame(builder, builder.setInitialOddNumber(9));
        assertSame(builder, builder.setMultiplierOddNumber(11));
        final HashCodeBuilder hcb = builder.get();
        assertNotNull(hcb);
        assertEquals(9, hcb.toHashCode());
    }

    // ---- isRegistered / getRegistry ----

    @Test
    public void testIsRegisteredFalseOutsideReflection() {
        assertFalse(HashCodeBuilder.isRegistered(new Object()));
    }

    @Test
    public void testGetRegistryOutsideReflectionHasNoEntries() {
        final Set<?> registry = HashCodeBuilder.getRegistry();
        assertTrue(registry == null || registry.isEmpty());
    }

    // ---- reflectionHashCode: no-fields-found returns the initial number ----

    @Test
    public void testReflectionHashCodeThreeArgReturnsInitialWhenNoFields() {
        assertEquals(7, HashCodeBuilder.reflectionHashCode(7, 3, new Empty()));
    }

    @Test
    public void testReflectionHashCodeFourArgReturnsInitialWhenNoFields() {
        assertEquals(7, HashCodeBuilder.reflectionHashCode(7, 3, new Empty(), true));
        assertEquals(7, HashCodeBuilder.reflectionHashCode(7, 3, new Empty(), false));
    }

    @Test
    public void testReflectionHashCodeGenericOverloadReturnsInitialWhenAllFieldsExcluded() {
        final int result = HashCodeBuilder.reflectionHashCode(7, 3, new TwoFields(), false, null, new String[] {"a", "b"});
        assertEquals(7, result);
    }

    // ---- reflectionHashCode: reflectUpToClass controls which superclass fields are included ----

    @Test
    public void testReflectionHashCodeReflectUpToClassLimitsIncludedFields() {
        final Child child = new Child();

        // Only Child's own field "c" (=2) is included: 7*3+2=23.
        final int childOnly = HashCodeBuilder.reflectionHashCode(7, 3, child, false, Child.class, new String[0]);
        assertEquals(23, childOnly);

        // Only Parent's field "p" (=1) is included when "c" is excluded: 7*3+1=22.
        final int parentOnly = HashCodeBuilder.reflectionHashCode(7, 3, child, false, Parent.class, new String[] {"c"});
        assertEquals(22, parentOnly);

        // With both fields included (reflect up to Parent, nothing excluded) the result differs from
        // either single-field result, since an extra field contributes to the computed hash code.
        final int both = HashCodeBuilder.reflectionHashCode(7, 3, child, false, Parent.class, new String[0]);
        assertNotEquals(childOnly, both);
        assertNotEquals(parentOnly, both);
    }

    // ---- reflectionHashCode: hard-coded-constant overloads ----

    @Test
    public void testReflectionHashCodeHardcodedOverloadsAgreeWhenNoFieldsAreUsed() {
        final int constant = HashCodeBuilder.reflectionHashCode(new Empty(), false);

        assertEquals(constant, HashCodeBuilder.reflectionHashCode(new TwoFields(), "a", "b"));
        assertEquals(constant, HashCodeBuilder.reflectionHashCode(new TwoFields(), Arrays.asList("a", "b")));
        assertEquals(constant, HashCodeBuilder.reflectionHashCode(new Transientish(99), false));
        assertEquals(constant, HashCodeBuilder.reflectionHashCode(new Transientish(100), false));
    }

    @Test
    public void testReflectionHashCodeTestTransientsIncludesTransientField() {
        final int notTested = HashCodeBuilder.reflectionHashCode(new Transientish(99), false);
        final int testedA = HashCodeBuilder.reflectionHashCode(new Transientish(99), true);
        final int testedB = HashCodeBuilder.reflectionHashCode(new Transientish(100), true);

        // When transients are excluded, the field value cannot affect the result.
        assertEquals(notTested, HashCodeBuilder.reflectionHashCode(new Transientish(100), false));
        // When transients are included, different field values must produce different results.
        assertNotEquals(testedA, testedB);
    }

    @Test
    public void testReflectionHashCodeExcludeFieldsCollectionOverload() {
        final TwoFields obj = new TwoFields();
        final int excludedBoth = HashCodeBuilder.reflectionHashCode(obj, Arrays.asList("a", "b"));
        final int excludedBothAgain = HashCodeBuilder.reflectionHashCode(obj, Collections.singletonList("a"));
        // Excluding only "a" still leaves "b" contributing, so the results must differ.
        assertNotEquals(excludedBoth, excludedBothAgain);
    }

    // ---- reflectionHashCode: null object throws NullPointerException ----

    @Test
    public void testReflectionHashCodeThreeArgNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(1, 3, null);
            }
        });
    }

    @Test
    public void testReflectionHashCodeFourArgNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(1, 3, null, true);
            }
        });
    }

    @Test
    public void testReflectionHashCodeGenericOverloadNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(1, 3, null, true, null, new String[0]);
            }
        });
    }

    @Test
    public void testReflectionHashCodeBooleanOverloadNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, false);
            }
        });
    }

    @Test
    public void testReflectionHashCodeVarargsOverloadNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, "x");
            }
        });
    }

    @Test
    public void testReflectionHashCodeCollectionOverloadNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, Arrays.asList("x"));
            }
        });
    }

    // ---- reflectionHashCode: zero or even seed numbers throw IllegalArgumentException ----

    @Test
    public void testReflectionHashCodeThreeArgRejectsEvenOrZeroNumbers() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(0, 3, new Empty());
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(4, 3, new Empty());
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(3, 0, new Empty());
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(3, 4, new Empty());
            }
        });
    }

    @Test
    public void testReflectionHashCodeFourArgRejectsEvenOrZeroNumbers() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(0, 3, new Empty(), true);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(3, 2, new Empty(), true);
            }
        });
    }

    // ---- sanity: distinct builder instances with the same configuration are not the same object ----

    @Test
    public void testDistinctBuildersAreNotSameInstanceEvenWhenEqual() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(1);
        assertNotSame(a, b);
        assertEquals(a.toHashCode(), b.toHashCode());
    }
}
