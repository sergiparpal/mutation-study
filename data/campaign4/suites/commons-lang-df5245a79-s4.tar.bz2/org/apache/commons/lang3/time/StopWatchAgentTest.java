package org.apache.commons.lang3.time;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class StopWatchAgentTest {

    private static final String TIME_PATTERN = "\\d+:\\d{2}:\\d{2}\\.\\d{3}";

    @Test
    public void testDefaultConstructorState() {
        StopWatch sw = new StopWatch();
        assertNull(sw.getMessage());
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    public void testMessageConstructorStoresMessage() {
        StopWatch sw = new StopWatch("my-watch");
        assertEquals("my-watch", sw.getMessage());
    }

    @Test
    public void testCreateReturnsUnstartedWatch() {
        StopWatch sw = StopWatch.create();
        assertNotNull(sw);
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
    }

    @Test
    public void testCreateStartedReturnsStartedWatch() {
        StopWatch sw = StopWatch.createStarted();
        assertNotNull(sw);
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
    }

    @Test
    public void testStartSetsStartedAndNotStopped() {
        StopWatch sw = new StopWatch();
        sw.start();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    public void testStartTwiceWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.start();
            }
        });
    }

    @Test
    public void testStopBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testStopAfterStartIsStopped() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertTrue(sw.isStopped());
    }

    @Test
    public void testStopTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testSuspendBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testSuspendAfterStartMarksSuspended() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertTrue(sw.isSuspended());
        assertTrue(sw.isStarted());
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.resume();
            }
        });
    }

    @Test
    public void testResumeBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.resume();
            }
        });
    }

    @Test
    public void testResumeAfterSuspendClearsSuspended() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        sw.resume();
        assertFalse(sw.isSuspended());
        assertTrue(sw.isStarted());
    }

    @Test
    public void testSplitBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testSplitTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.unsplit();
            }
        });
    }

    @Test
    public void testSplitThenUnsplitAllowsSplitAgain() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.unsplit();
        sw.split();
        assertTrue(sw.getSplitNanoTime() >= 0);
    }

    @Test
    public void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getSplitNanoTime();
            }
        });
    }

    @Test
    public void testGetSplitDurationWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getSplitDuration();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getSplitTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetSplitDurationAndNanoTimeAndMillisAreConsistent() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        Duration splitDuration = sw.getSplitDuration();
        long splitNanos = sw.getSplitNanoTime();
        long splitMillis = sw.getSplitTime();
        assertNotNull(splitDuration);
        assertFalse(splitDuration.isNegative());
        assertEquals(splitDuration.toNanos(), splitNanos);
        assertEquals(splitDuration.toMillis(), splitMillis);
    }

    @Test
    public void testGetSplitsInitiallyEmpty() {
        StopWatch sw = new StopWatch();
        List<StopWatch.Split> splits = sw.getSplits();
        assertNotNull(splits);
        assertTrue(splits.isEmpty());
    }

    @Test
    public void testSplitWithLabelRecordsSplit() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split("first");
        List<StopWatch.Split> splits = sw.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
        sw.unsplit();
        sw.split("second");
        splits = sw.getSplits();
        assertEquals(2, splits.size());
        assertEquals("second", splits.get(1).getLabel());
    }

    @Test
    public void testSplitWithLabelBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.split("label");
            }
        });
    }

    @Test
    public void testGetStartInstantBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getStartInstant();
            }
        });
    }

    @Test
    public void testGetStartInstantAfterStartIsCloseToNow() {
        StopWatch sw = new StopWatch();
        Instant before = Instant.now();
        sw.start();
        Instant start = sw.getStartInstant();
        Instant after = Instant.now();
        assertNotNull(start);
        assertFalse(start.isBefore(before));
        assertFalse(start.isAfter(after));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStartTimeBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getStartTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStartTimeMatchesStartInstant() {
        StopWatch sw = new StopWatch();
        sw.start();
        assertEquals(sw.getStartInstant().toEpochMilli(), sw.getStartTime());
    }

    @Test
    public void testGetStopInstantBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getStopInstant();
            }
        });
    }

    @Test
    public void testGetStopInstantAfterStopIsNotBeforeStart() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        Instant start = sw.getStartInstant();
        Instant stop = sw.getStopInstant();
        assertNotNull(stop);
        assertFalse(stop.isBefore(start));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStopTimeBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.getStopTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStopTimeMatchesStopInstant() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getStopInstant().toEpochMilli(), sw.getStopTime());
    }

    @Test
    public void testGetTimeAndDurationAndNanoTimeConsistentAfterStop() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        long millis = sw.getTime();
        Duration duration = sw.getDuration();
        long nanos = sw.getNanoTime();
        assertTrue(millis >= 0);
        assertTrue(nanos >= 0);
        assertNotNull(duration);
        assertFalse(duration.isNegative());
        assertEquals(duration.toMillis(), millis);
        assertEquals(duration.toNanos(), nanos);
    }

    @Test
    public void testGetTimeWithTimeUnitRoundsDown() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        long hours = sw.getTime(TimeUnit.HOURS);
        assertEquals(0L, hours);
    }

    @Test
    public void testResetClearsStateAndAllowsRestart() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        sw.reset();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        sw.start();
        assertTrue(sw.isStarted());
    }

    @Test
    public void testResetAfterDoubleStartFailureAllowsNewStart() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sw.start();
            }
        });
        sw.reset();
        sw.start();
        assertTrue(sw.isStarted());
    }

    @Test
    public void testToStringWithMessageHasPrefixAndFormat() {
        StopWatch sw = new StopWatch("myLabel");
        sw.start();
        sw.stop();
        String s = sw.toString();
        assertTrue(s.startsWith("myLabel "));
        assertTrue(s.substring("myLabel ".length()).matches(TIME_PATTERN));
    }

    @Test
    public void testToStringWithoutMessageHasNoPrefix() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        String s = sw.toString();
        assertTrue(s.matches(TIME_PATTERN));
    }

    @Test
    public void testToSplitStringWithMessageHasPrefixAndFormat() {
        StopWatch sw = new StopWatch("split-label");
        sw.start();
        sw.split();
        String s = sw.toSplitString();
        assertTrue(s.startsWith("split-label "));
        assertTrue(s.substring("split-label ".length()).matches(TIME_PATTERN));
    }

    @Test
    public void testToSplitStringWithoutMessageHasNoPrefix() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        String s = sw.toSplitString();
        assertTrue(s.matches(TIME_PATTERN));
    }

    @Test
    public void testFormatTimeMatchesHmsPattern() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        String formatted = sw.formatTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches(TIME_PATTERN));
    }

    @Test
    public void testFormatSplitTimeMatchesHmsPattern() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        String formatted = sw.formatSplitTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches(TIME_PATTERN));
    }

    @Test
    public void testGetDelegatesToSupplierAndReturnsItsResult() {
        StopWatch sw = new StopWatch();
        final Object expected = "result-value";
        Object actual = sw.get(new Supplier<Object>() {
            public Object get() {
                return expected;
            }
        });
        assertSame(expected, actual);
    }

    @Test
    public void testRunDelegatesToRunnable() {
        StopWatch sw = new StopWatch();
        final boolean[] ran = {false};
        sw.run(new Runnable() {
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
    }

    @Test
    public void testGetTDelegatesToFailableSupplierAndReturnsItsResult() throws Throwable {
        StopWatch sw = new StopWatch();
        final Object expected = "t-result";
        Object actual = sw.getT(new FailableSupplier<Object, Throwable>() {
            public Object get() {
                return expected;
            }
        });
        assertSame(expected, actual);
    }

    @Test
    public void testGetTPropagatesThrownException() {
        final StopWatch sw = new StopWatch();
        final RuntimeException boom = new RuntimeException("boom");
        Throwable thrown = assertThrows(RuntimeException.class, new Executable() {
            public void execute() throws Throwable {
                sw.getT(new FailableSupplier<Object, Throwable>() {
                    public Object get() {
                        throw boom;
                    }
                });
            }
        });
        assertSame(boom, thrown);
    }

    @Test
    public void testRunTDelegatesToFailableRunnable() throws Throwable {
        StopWatch sw = new StopWatch();
        final boolean[] ran = {false};
        sw.runT(new FailableRunnable<Throwable>() {
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
    }

    @Test
    public void testRunTPropagatesThrownException() {
        final StopWatch sw = new StopWatch();
        final RuntimeException boom = new RuntimeException("boom-run");
        Throwable thrown = assertThrows(RuntimeException.class, new Executable() {
            public void execute() throws Throwable {
                sw.runT(new FailableRunnable<Throwable>() {
                    public void run() {
                        throw boom;
                    }
                });
            }
        });
        assertSame(boom, thrown);
    }

    @Test
    public void testSplitClassStoresLabelAndDuration() {
        Duration d = Duration.ofMillis(500);
        StopWatch.Split split = new StopWatch.Split("label1", d);
        assertEquals("label1", split.getLabel());
        assertEquals(d, split.getDuration());
        assertNotNull(split.toString());
    }
}
