/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.apache.commons.csv.CSVFormat.Builder;
import org.apache.commons.csv.CSVFormat.Predefined;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum TestHeaderEnum {
        NAME, EMAIL, PHONE
    }

    @Test
    void testDefaultFormatValues() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testNewFormatDelimiter() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals('|', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\n'));
    }

    @Test
    void testValueOfPredefined() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test
    void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NoSuchFormat"));
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, Predefined.Excel.getFormat());
        assertEquals(CSVFormat.TDF, Predefined.TDF.getFormat());
    }

    @Test
    void testBuilderDelimiterCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("").get());
    }

    @Test
    void testBuilderDelimiterCannotBeLineBreakChar() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter('\n').get());
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter('\r').get());
    }

    @Test
    void testBuilderDelimiterCannotContainLineBreakString() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("a\nb").get());
    }

    @Test
    void testBuilderQuoteCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuote('\n').get());
    }

    @Test
    void testBuilderEscapeCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setEscape('\r').get());
    }

    @Test
    void testBuilderCommentMarkerCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setCommentMarker('\n').get());
    }

    @Test
    void testQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testQuoteCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testEscapeCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setEscape((Character) null).setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = Builder.create().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderNamesDisallowedThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setHeader("A", "B", "A").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get());
    }

    @Test
    void testDuplicateHeaderNamesAllowedAllByDefault() {
        final CSVFormat format = Builder.create().setHeader("A", "B", "A").get();
        assertArrayEquals(new String[] { "A", "B", "A" }, format.getHeader());
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowedWithAllowEmptyMode() {
        final CSVFormat format = Builder.create().setHeader("A", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] { "A", "", "" }, format.getHeader());
    }

    @Test
    void testDuplicateNonEmptyHeaderNamesDisallowedWithAllowEmptyMode() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = Builder.create().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = Builder.create().setDelimiter(',').setCommentMarker('#').setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = Builder.create().setHeader(TestHeaderEnum.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final CSVFormat format = Builder.create().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testWithHeaderVarargs() {
        final CSVFormat base = CSVFormat.DEFAULT;
        final CSVFormat withHeader = base.withHeader("X", "Y");
        assertArrayEquals(new String[] { "X", "Y" }, withHeader.getHeader());
        assertNull(base.getHeader());
    }

    @Test
    void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', format.getDelimiter());
    }

    @Test
    void testWithQuote() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        final CSVFormat disabled = format.withQuote((Character) null);
        assertNull(disabled.getQuoteCharacter());
        assertFalse(disabled.isQuoteCharacterSet());
    }

    @Test
    void testWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    void testWithCommentMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
        final CSVFormat none = CSVFormat.DEFAULT;
        assertFalse(none.isNullStringSet());
    }

    @Test
    void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testWithRecordSeparatorString() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    void testWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @Test
    void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    void testWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withHeaderComments("Line1", "Line2");
        assertArrayEquals(new String[] { "Line1", "Line2" }, format.getHeaderComments());
    }

    @Test
    void testWithAllowDuplicateHeaderNamesDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(format.getAllowDuplicateHeaderNames());
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
    }

    @Test
    void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    void testImmutabilityOfWithMethods() {
        final CSVFormat original = CSVFormat.DEFAULT;
        original.withDelimiter(';');
        assertEquals(',', original.getDelimiter());
    }

    @Test
    void testBuilderPreservesSourceFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.withDelimiter('|').withQuote('\'');
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.withDelimiter(';');
        final CSVFormat b = CSVFormat.DEFAULT.withDelimiter(';');
        final CSVFormat c = CSVFormat.DEFAULT.withDelimiter(':');
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
        assertEquals(a, a);
    }

    @Test
    void testFormatValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatWithQuotedValue() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringReflectsCommentAndEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withEscape('\\');
        final String str = format.toString();
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("Escape=<\\>"));
    }

    @Test
    void testPrintAndParseRoundTrip() throws IOException {
        final StringWriter writer = new StringWriter();
        try (CSVPrinter printer = CSVFormat.DEFAULT.print(writer)) {
            printer.printRecord("one", "two", "three");
        }
        assertEquals("one,two,three\r\n", writer.toString());

        try (CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader(writer.toString()))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals("one", record.get(0));
            assertEquals("two", record.get(1));
            assertEquals("three", record.get(2));
        }
    }

    @Test
    void testPrintObjectAppendableNewRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("value,with,comma", writer, true);
        assertEquals("\"value,with,comma\"", writer.toString());
    }

    @Test
    void testPrintlnWritesRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    void testSetHeaderFromResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = new ResultSetMetaDataStub(new String[] { "ID", "NAME" }).asProxy();
        final CSVFormat format = Builder.create().setHeader(metaData).get();
        assertArrayEquals(new String[] { "ID", "NAME" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSet() throws SQLException {
        final ResultSetMetaDataStub metaData = new ResultSetMetaDataStub(new String[] { "COL1" });
        final ResultSet resultSet = new ResultSetStub(metaData).asProxy();
        final CSVFormat format = Builder.create().setHeader(resultSet).get();
        assertArrayEquals(new String[] { "COL1" }, format.getHeader());
    }

    @Test
    void testGetMaxRowsDefaultIsZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = Builder.create().setMaxRows(5).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    void testGetDelimiterString() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    void testPredefinedFormatSpecifics() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());

        assertEquals(',', CSVFormat.RFC4180.getDelimiter());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());

        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());

        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    /**
     * Minimal stand-in for ResultSetMetaData used only to feed setHeader(ResultSetMetaData).
     */
    private static final class ResultSetMetaDataStub implements java.lang.reflect.InvocationHandler {
        private final String[] labels;

        ResultSetMetaDataStub(final String[] labels) {
            this.labels = labels;
        }

        ResultSetMetaData asProxy() {
            return (ResultSetMetaData) java.lang.reflect.Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { ResultSetMetaData.class }, this);
        }

        @Override
        public Object invoke(final Object proxy, final java.lang.reflect.Method method, final Object[] args) {
            final String name = method.getName();
            if ("getColumnCount".equals(name)) {
                return Integer.valueOf(labels.length);
            }
            if ("getColumnLabel".equals(name)) {
                final int index = ((Integer) args[0]).intValue();
                return labels[index - 1];
            }
            throw new UnsupportedOperationException(name);
        }
    }

    private static final class ResultSetStub implements java.lang.reflect.InvocationHandler {
        private final ResultSetMetaDataStub metaData;

        ResultSetStub(final ResultSetMetaDataStub metaData) {
            this.metaData = metaData;
        }

        ResultSet asProxy() {
            return (ResultSet) java.lang.reflect.Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { ResultSet.class }, this);
        }

        @Override
        public Object invoke(final Object proxy, final java.lang.reflect.Method method, final Object[] args) {
            if ("getMetaData".equals(method.getName())) {
                return metaData.asProxy();
            }
            throw new UnsupportedOperationException(method.getName());
        }
    }
}
