/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ToStringStyle}.
 */
class ToStringStyleAgentTest {

    /**
     * Concrete subclass used to instantiate the abstract {@link ToStringStyle} with default settings.
     */
    private static final class PlainToStringStyle extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    private PlainToStringStyle newStyle() {
        return new PlainToStringStyle();
    }

    // --- default values ---

    @Test
    void testDefaultGetters() {
        final PlainToStringStyle style = newStyle();
        assertEquals("[", style.getContentStart());
        assertEquals("]", style.getContentEnd());
        assertEquals("=", style.getFieldNameValueSeparator());
        assertEquals(",", style.getFieldSeparator());
        assertEquals("{", style.getArrayStart());
        assertEquals(",", style.getArraySeparator());
        assertEquals("}", style.getArrayEnd());
        assertEquals("<null>", style.getNullText());
        assertEquals("<size=", style.getSizeStartText());
        assertEquals(">", style.getSizeEndText());
        assertEquals("<", style.getSummaryObjectStartText());
        assertEquals(">", style.getSummaryObjectEndText());
        assertTrue(style.isUseFieldNames());
        assertTrue(style.isUseClassName());
        assertFalse(style.isUseShortClassName());
        assertTrue(style.isUseIdentityHashCode());
        assertTrue(style.isArrayContentDetail());
        assertTrue(style.isDefaultFullDetail());
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
    }

    // --- setters: normal values and null boundary (converted to "") ---

    @Test
    void testSetContentStartAndEnd() {
        final PlainToStringStyle style = newStyle();
        style.setContentStart("<");
        style.setContentEnd(">");
        assertEquals("<", style.getContentStart());
        assertEquals(">", style.getContentEnd());
        style.setContentStart(null);
        style.setContentEnd(null);
        assertEquals("", style.getContentStart());
        assertEquals("", style.getContentEnd());
    }

    @Test
    void testSetFieldNameValueSeparator() {
        final PlainToStringStyle style = newStyle();
        style.setFieldNameValueSeparator(":");
        assertEquals(":", style.getFieldNameValueSeparator());
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());
    }

    @Test
    void testSetFieldSeparator() {
        final PlainToStringStyle style = newStyle();
        style.setFieldSeparator(";");
        assertEquals(";", style.getFieldSeparator());
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());
    }

    @Test
    void testSetArrayStartSeparatorEnd() {
        final PlainToStringStyle style = newStyle();
        style.setArrayStart("(");
        style.setArraySeparator("|");
        style.setArrayEnd(")");
        assertEquals("(", style.getArrayStart());
        assertEquals("|", style.getArraySeparator());
        assertEquals(")", style.getArrayEnd());
        style.setArrayStart(null);
        style.setArraySeparator(null);
        style.setArrayEnd(null);
        assertEquals("", style.getArrayStart());
        assertEquals("", style.getArraySeparator());
        assertEquals("", style.getArrayEnd());
    }

    @Test
    void testSetNullText() {
        final PlainToStringStyle style = newStyle();
        style.setNullText("NULL");
        assertEquals("NULL", style.getNullText());
        style.setNullText(null);
        assertEquals("", style.getNullText());
    }

    @Test
    void testSetSizeStartAndEndText() {
        final PlainToStringStyle style = newStyle();
        style.setSizeStartText("size(");
        style.setSizeEndText(")");
        assertEquals("size(", style.getSizeStartText());
        assertEquals(")", style.getSizeEndText());
        style.setSizeStartText(null);
        style.setSizeEndText(null);
        assertEquals("", style.getSizeStartText());
        assertEquals("", style.getSizeEndText());
    }

    @Test
    void testSetSummaryObjectStartAndEndText() {
        final PlainToStringStyle style = newStyle();
        style.setSummaryObjectStartText("[[");
        style.setSummaryObjectEndText("]]");
        assertEquals("[[", style.getSummaryObjectStartText());
        assertEquals("]]", style.getSummaryObjectEndText());
        style.setSummaryObjectStartText(null);
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectStartText());
        assertEquals("", style.getSummaryObjectEndText());
    }

    @Test
    void testSetBooleanFlags() {
        final PlainToStringStyle style = newStyle();
        style.setUseClassName(false);
        style.setUseFieldNames(false);
        style.setUseIdentityHashCode(false);
        style.setUseShortClassName(true);
        style.setArrayContentDetail(false);
        style.setDefaultFullDetail(false);
        style.setFieldSeparatorAtStart(true);
        style.setFieldSeparatorAtEnd(true);
        assertFalse(style.isUseClassName());
        assertFalse(style.isUseFieldNames());
        assertFalse(style.isUseIdentityHashCode());
        assertTrue(style.isUseShortClassName());
        assertFalse(style.isArrayContentDetail());
        assertFalse(style.isDefaultFullDetail());
        assertTrue(style.isFieldSeparatorAtStart());
        assertTrue(style.isFieldSeparatorAtEnd());
    }

    // --- isFullDetail ---

    @Test
    void testIsFullDetailWithNullUsesDefault() {
        final PlainToStringStyle style = newStyle();
        assertTrue(style.isFullDetail(null));
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    @Test
    void testIsFullDetailExplicit() {
        final PlainToStringStyle style = newStyle();
        assertTrue(style.isFullDetail(Boolean.TRUE));
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    // --- getShortClassName ---

    @Test
    void testGetShortClassName() {
        final PlainToStringStyle style = newStyle();
        assertEquals("String", style.getShortClassName(String.class));
    }

    // --- appendStart / appendEnd / append field ---

    @Test
    void testAppendStartWithNullObjectIsNoOp() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, null);
        assertEquals(0, buffer.length());
    }

    @Test
    void testAppendStartAppendEndFullCycle() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        final Object obj = new Object();
        style.appendStart(buffer, obj);
        style.append(buffer, "name", (Object) "John", Boolean.TRUE);
        style.appendEnd(buffer, obj);
        final String result = buffer.toString();
        assertTrue(result.startsWith(Object.class.getName() + "@"));
        assertTrue(result.endsWith("name=John]"));
        assertFalse(ToStringStyle.isRegistered(obj));
    }

    @Test
    void testAppendFieldWithoutFieldNames() {
        final PlainToStringStyle style = newStyle();
        style.setUseFieldNames(false);
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "ignoredName", 5);
        assertEquals("5,", buffer.toString());
    }

    @Test
    void testAppendFieldWithNullFieldName() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, null, 5);
        assertEquals("5,", buffer.toString());
    }

    // --- append primitive values ---

    @Test
    void testAppendBoolean() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", true);
        assertEquals("f=true,", buffer.toString());
    }

    @Test
    void testAppendInt() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 42);
        assertEquals("f=42,", buffer.toString());
    }

    @Test
    void testAppendLong() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 42L);
        assertEquals("f=42,", buffer.toString());
    }

    @Test
    void testAppendDouble() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 1.5d);
        assertEquals("f=1.5,", buffer.toString());
    }

    @Test
    void testAppendFloat() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 1.5f);
        assertEquals("f=1.5,", buffer.toString());
    }

    @Test
    void testAppendByte() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (byte) 7);
        assertEquals("f=7,", buffer.toString());
    }

    @Test
    void testAppendShort() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (short) 7);
        assertEquals("f=7,", buffer.toString());
    }

    @Test
    void testAppendChar() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 'x');
        assertEquals("f=x,", buffer.toString());
    }

    // --- append arrays: null, detail and summary ---

    @Test
    void testAppendIntArrayNull() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (int[]) null, null);
        assertEquals("f=<null>,", buffer.toString());
    }

    @Test
    void testAppendIntArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new int[] {1, 2, 3}, Boolean.TRUE);
        assertEquals("f={1,2,3},", buffer.toString());
    }

    @Test
    void testAppendIntArraySummary() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new int[] {1, 2, 3}, Boolean.FALSE);
        assertEquals("f=<size=3>,", buffer.toString());
    }

    @Test
    void testAppendEmptyIntArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new int[0], Boolean.TRUE);
        assertEquals("f={},", buffer.toString());
    }

    @Test
    void testAppendBooleanArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new boolean[] {true, false}, Boolean.TRUE);
        assertEquals("f={true,false},", buffer.toString());
    }

    @Test
    void testAppendByteArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new byte[] {1, 2}, Boolean.TRUE);
        assertEquals("f={1,2},", buffer.toString());
    }

    @Test
    void testAppendCharArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new char[] {'a', 'b'}, Boolean.TRUE);
        assertEquals("f={a,b},", buffer.toString());
    }

    @Test
    void testAppendDoubleArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new double[] {1.0, 2.0}, Boolean.TRUE);
        assertEquals("f={1.0,2.0},", buffer.toString());
    }

    @Test
    void testAppendFloatArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new float[] {1.0f, 2.0f}, Boolean.TRUE);
        assertEquals("f={1.0,2.0},", buffer.toString());
    }

    @Test
    void testAppendLongArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new long[] {1L, 2L}, Boolean.TRUE);
        assertEquals("f={1,2},", buffer.toString());
    }

    @Test
    void testAppendShortArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new short[] {1, 2}, Boolean.TRUE);
        assertEquals("f={1,2},", buffer.toString());
    }

    @Test
    void testAppendObjectArrayNull() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (Object[]) null, null);
        assertEquals("f=<null>,", buffer.toString());
    }

    @Test
    void testAppendObjectArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new Object[] {"a", "b"}, Boolean.TRUE);
        assertEquals("f={a,b},", buffer.toString());
    }

    @Test
    void testAppendObjectArraySummary() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new Object[] {"a", "b"}, Boolean.FALSE);
        assertEquals("f=<size=2>,", buffer.toString());
    }

    @Test
    void testAppendObjectArrayWithNullElement() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", new Object[] {null, "b"}, Boolean.TRUE);
        assertEquals("f={<null>,b},", buffer.toString());
    }

    // --- append Object value ---

    @Test
    void testAppendObjectValueNull() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", (Object) null, Boolean.TRUE);
        assertEquals("f=<null>,", buffer.toString());
    }

    @Test
    void testAppendObjectValueDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", "hello", Boolean.TRUE);
        assertEquals("f=hello,", buffer.toString());
    }

    @Test
    void testAppendObjectValueSummary() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", "hello", Boolean.FALSE);
        assertEquals("f=<String>,", buffer.toString());
    }

    @Test
    void testAppendCollectionDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        style.append(buffer, "f", (Object) list, Boolean.TRUE);
        assertEquals("f=[a, b],", buffer.toString());
    }

    @Test
    void testAppendCollectionSummary() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        style.append(buffer, "f", (Object) list, Boolean.FALSE);
        assertEquals("f=<size=2>,", buffer.toString());
    }

    @Test
    void testAppendMapDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        final Map<String, Integer> map = new LinkedHashMap<String, Integer>();
        map.put("a", 1);
        style.append(buffer, "f", (Object) map, Boolean.TRUE);
        assertEquals("f={a=1},", buffer.toString());
    }

    // --- cyclic object detection ---

    @Test
    void testAppendInternalCyclicObject() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        final Object cyclic = new Object();
        ToStringStyle.register(cyclic);
        try {
            style.appendInternal(buffer, "f", cyclic, true);
            assertTrue(buffer.toString().contains(Object.class.getName()));
        } finally {
            ToStringStyle.unregister(cyclic);
        }
        assertFalse(ToStringStyle.isRegistered(cyclic));
    }

    @Test
    void testRegisterUnregisterAndRegistry() {
        final Object value = new Object();
        assertFalse(ToStringStyle.isRegistered(value));
        ToStringStyle.register(value);
        assertTrue(ToStringStyle.isRegistered(value));
        assertNotNull(ToStringStyle.getRegistry());
        assertTrue(ToStringStyle.getRegistry().containsKey(value));
        ToStringStyle.unregister(value);
        assertFalse(ToStringStyle.isRegistered(value));
    }

    @Test
    void testUnregisterNullIsNoOp() {
        ToStringStyle.unregister(null);
        assertFalse(ToStringStyle.isRegistered(null));
    }

    // --- appendSuper / appendToString ---

    @Test
    void testAppendSuperWithNullIsNoOp() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer("existing,");
        style.appendSuper(buffer, null);
        assertEquals("existing,", buffer.toString());
    }

    @Test
    void testAppendToStringMergesContent() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer("existing,");
        style.appendToString(buffer, "[a=1,b=2]");
        assertEquals("existing,a=1,b=2,", buffer.toString());
    }

    @Test
    void testAppendToStringWithNoBracketsIsNoOp() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer("existing,");
        style.appendToString(buffer, "no brackets here");
        assertEquals("existing,", buffer.toString());
    }

    @Test
    void testAppendToStringWithEmptyContentIsNoOp() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer("existing,");
        style.appendToString(buffer, "[]");
        assertEquals("existing,", buffer.toString());
    }

    // --- removeLastFieldSeparator ---

    @Test
    void testRemoveLastFieldSeparatorWhenPresent() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer("a=1,");
        style.removeLastFieldSeparator(buffer);
        assertEquals("a=1", buffer.toString());
    }

    @Test
    void testRemoveLastFieldSeparatorWhenAbsent() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer("a=1");
        style.removeLastFieldSeparator(buffer);
        assertEquals("a=1", buffer.toString());
    }

    // --- reflectionAppendArrayDetail ---

    @Test
    void testReflectionAppendArrayDetail() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.reflectionAppendArrayDetail(buffer, "f", new int[] {9, 8, 7});
        assertEquals("{9,8,7}", buffer.toString());
    }

    @Test
    void testReflectionAppendArrayDetailEmpty() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        style.reflectionAppendArrayDetail(buffer, "f", new String[0]);
        assertEquals("{}", buffer.toString());
    }

    // --- appendCyclicObject ---

    @Test
    void testAppendCyclicObjectDirect() {
        final PlainToStringStyle style = newStyle();
        final StringBuffer buffer = new StringBuffer();
        final Object value = new Object();
        style.appendCyclicObject(buffer, "f", value);
        assertTrue(buffer.toString().contains(Object.class.getName()));
    }

    // --- public static style constants ---

    @Test
    void testPublicStyleConstantsAreNotNull() {
        assertNotNull(ToStringStyle.DEFAULT_STYLE);
        assertNotNull(ToStringStyle.MULTI_LINE_STYLE);
        assertNotNull(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertNotNull(ToStringStyle.SHORT_PREFIX_STYLE);
        assertNotNull(ToStringStyle.SIMPLE_STYLE);
        assertNotNull(ToStringStyle.NO_CLASS_NAME_STYLE);
        assertNotNull(ToStringStyle.JSON_STYLE);
    }

    @Test
    void testJsonStyleRejectsNullFieldName() {
        final StringBuffer buffer = new StringBuffer();
        try {
            ToStringStyle.JSON_STYLE.append(buffer, null, "value", Boolean.TRUE);
            throw new AssertionError("expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected: JSON style requires a field name
        }
    }

    @Test
    void testJsonStyleRejectsSummaryMode() {
        final StringBuffer buffer = new StringBuffer();
        try {
            ToStringStyle.JSON_STYLE.append(buffer, "f", "value", Boolean.FALSE);
            throw new AssertionError("expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected: JSON style requires full detail
        }
    }
}
