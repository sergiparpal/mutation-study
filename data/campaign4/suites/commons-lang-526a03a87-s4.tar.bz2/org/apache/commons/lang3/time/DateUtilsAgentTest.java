package org.apache.commons.lang3.time;

import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link DateUtils}, based solely on its javadoc contract.
 */
public class DateUtilsAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar utcCalendar() {
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        return cal;
    }

    private static Calendar utcCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = utcCalendar();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date utcDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return utcCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------

    @Test
    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    // ------------------------------------------------------------------
    // addXxx
    // ------------------------------------------------------------------

    @Test
    public void testAddDays() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        long originalMillis = date.getTime();
        Date result = DateUtils.addDays(date, 5);
        assertEquals(utcDate(2020, Calendar.JANUARY, 20, 10, 0, 0, 0), result);
        assertEquals(originalMillis, date.getTime());
        Date resultNeg = DateUtils.addDays(date, -20);
        assertEquals(utcDate(2019, Calendar.DECEMBER, 26, 10, 0, 0, 0), resultNeg);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
    }

    @Test
    public void testAddHours() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        Date result = DateUtils.addHours(date, 20);
        assertEquals(utcDate(2020, Calendar.JANUARY, 16, 6, 0, 0, 0), result);
        Date resultNeg = DateUtils.addHours(date, -11);
        assertEquals(utcDate(2020, Calendar.JANUARY, 14, 23, 0, 0, 0), resultNeg);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addHours(null, 1);
            }
        });
    }

    @Test
    public void testAddMinutes() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 50, 0, 0);
        Date result = DateUtils.addMinutes(date, 20);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 11, 10, 0, 0), result);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addMinutes(null, 1);
            }
        });
    }

    @Test
    public void testAddSeconds() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 50, 0);
        Date result = DateUtils.addSeconds(date, 20);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 1, 10, 0), result);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addSeconds(null, 1);
            }
        });
    }

    @Test
    public void testAddMilliseconds() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 900);
        Date result = DateUtils.addMilliseconds(date, 200);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 1, 100), result);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addMilliseconds(null, 1);
            }
        });
    }

    @Test
    public void testAddWeeks() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        Date result = DateUtils.addWeeks(date, 2);
        assertEquals(utcDate(2020, Calendar.JANUARY, 29, 10, 0, 0, 0), result);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addWeeks(null, 1);
            }
        });
    }

    @Test
    public void testAddMonthsRollover() {
        Date date = utcDate(2020, Calendar.JANUARY, 31, 0, 0, 0, 0);
        Date result = DateUtils.addMonths(date, 1);
        // Calendar-based addition: Jan 31 + 1 month normalizes past Feb 29 (2020 is leap) to Mar 2.
        assertEquals(utcDate(2020, Calendar.MARCH, 2, 0, 0, 0, 0), result);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addMonths(null, 1);
            }
        });
    }

    @Test
    public void testAddYearsLeapRollover() {
        Date date = utcDate(2020, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        Date result = DateUtils.addYears(date, 1);
        // 2021 is not leap: Feb 29 normalizes forward to Mar 1.
        assertEquals(utcDate(2021, Calendar.MARCH, 1, 0, 0, 0, 0), result);
        Date resultNeg = DateUtils.addYears(date, -4);
        assertEquals(utcDate(2016, Calendar.FEBRUARY, 29, 0, 0, 0, 0), resultNeg);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.addYears(null, 1);
            }
        });
    }

    // ------------------------------------------------------------------
    // ceiling / round / truncate
    // ------------------------------------------------------------------

    @Test
    public void testCeilingDate() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling(date, Calendar.HOUR));
        assertEquals(utcDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.ceiling(date, Calendar.MONTH));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR);
            }
        });
    }

    @Test
    public void testCeilingCalendar() {
        Calendar cal = utcCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.ceiling(cal, Calendar.HOUR);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result.getTime());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR);
            }
        });
    }

    @Test
    public void testCeilingObject() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = utcCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling((Object) date, Calendar.HOUR));
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling((Object) cal, Calendar.HOUR));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.ceiling((Object) null, Calendar.HOUR);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() {
                DateUtils.ceiling((Object) "not a date", Calendar.HOUR);
            }
        });
    }

    @Test
    public void testCeilingArithmeticOverflow() {
        final Calendar cal = utcCalendar(2000, Calendar.MARCH, 28, 13, 45, 1, 231);
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                DateUtils.ceiling(cal, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testRoundDate() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.round(date, Calendar.HOUR));
        assertEquals(utcDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.round(date, Calendar.MONTH));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.round((Date) null, Calendar.HOUR);
            }
        });
    }

    @Test
    public void testRoundCalendar() {
        Calendar cal = utcCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.round(cal, Calendar.HOUR);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result.getTime());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.round((Calendar) null, Calendar.HOUR);
            }
        });
    }

    @Test
    public void testRoundObject() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.round((Object) date, Calendar.HOUR));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.round((Object) null, Calendar.HOUR);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() {
                DateUtils.round((Object) "not a date", Calendar.HOUR);
            }
        });
    }

    @Test
    public void testRoundArithmeticOverflow() {
        final Calendar cal = utcCalendar(2000, Calendar.MARCH, 28, 13, 45, 1, 231);
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                DateUtils.round(cal, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testRoundDownBoundary() {
        // Less than half an hour past the hour rounds down.
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 10, 0, 0);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.round(date, Calendar.HOUR));
    }

    @Test
    public void testTruncateDate() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate(date, Calendar.HOUR));
        assertEquals(utcDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.truncate(date, Calendar.MONTH));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.HOUR);
            }
        });
    }

    @Test
    public void testTruncateCalendar() {
        Calendar cal = utcCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.truncate(cal, Calendar.HOUR);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), result.getTime());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncate((Calendar) null, Calendar.HOUR);
            }
        });
    }

    @Test
    public void testTruncateObject() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = utcCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate((Object) date, Calendar.HOUR));
        assertEquals(utcDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate((Object) cal, Calendar.HOUR));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncate((Object) null, Calendar.HOUR);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() {
                DateUtils.truncate((Object) "not a date", Calendar.HOUR);
            }
        });
    }

    @Test
    public void testTruncateArithmeticOverflow() {
        final Calendar cal = utcCalendar(2000, Calendar.MARCH, 28, 13, 45, 1, 231);
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, new Executable() {
            public void execute() {
                DateUtils.truncate(cal, Calendar.MONTH);
            }
        });
    }

    // ------------------------------------------------------------------
    // getFragmentInXxx
    // ------------------------------------------------------------------

    @Test
    public void testGetFragmentInDaysDate() {
        Date jan28 = utcDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        Date feb28 = utcDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
        assertEquals(0L, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInDays(jan28, Calendar.DATE));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
    }

    @Test
    public void testGetFragmentInDaysCalendar() {
        Calendar jan28 = utcCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        Calendar feb28 = utcCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
    }

    @Test
    public void testGetFragmentInHours() {
        Date jan1 = utcDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Date jan6 = utcDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Date jan16 = utcDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(7L, DateUtils.getFragmentInHours(jan1, Calendar.DAY_OF_YEAR));
        assertEquals(7L, DateUtils.getFragmentInHours(jan6, Calendar.DAY_OF_YEAR));
        assertEquals(7L, DateUtils.getFragmentInHours(jan1, Calendar.MONTH));
        assertEquals(127L, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInHours(jan16, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInHours(jan1, Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.getFragmentInHours((Date) null, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testGetFragmentInMinutes() {
        Date jan1 = utcDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Date jan6 = utcDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Date jan16 = utcDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan6, Calendar.HOUR_OF_DAY));
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1, Calendar.MONTH));
        assertEquals(435L, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInMinutes(jan16, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInMinutes(jan1, Calendar.MINUTE));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.getFragmentInMinutes((Date) null, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testGetFragmentInSeconds() {
        Date jan1 = utcDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Date jan6 = utcDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Date jan16 = utcDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(10L, DateUtils.getFragmentInSeconds(jan1, Calendar.MINUTE));
        assertEquals(10L, DateUtils.getFragmentInSeconds(jan6, Calendar.MINUTE));
        assertEquals(26110L, DateUtils.getFragmentInSeconds(jan6, Calendar.DAY_OF_YEAR));
        assertEquals(0L, DateUtils.getFragmentInSeconds(jan16, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInSeconds(jan1, Calendar.SECOND));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.getFragmentInSeconds((Date) null, Calendar.MINUTE);
            }
        });
    }

    @Test
    public void testGetFragmentInMilliseconds() {
        Date jan1 = utcDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        Date jan6 = utcDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        Date jan16 = utcDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(jan1, Calendar.SECOND));
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(jan6, Calendar.SECOND));
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MINUTE));
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(jan16, Calendar.MILLISECOND));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.getFragmentInMilliseconds((Date) null, Calendar.SECOND);
            }
        });
    }

    // ------------------------------------------------------------------
    // isSameDay / isSameInstant / isSameLocalTime
    // ------------------------------------------------------------------

    @Test
    public void testIsSameDayDate() {
        Date d1 = utcDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = utcDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Date d3 = utcDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.isSameDay((Date) null, new Date());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.isSameDay(new Date(), (Date) null);
            }
        });
    }

    @Test
    public void testIsSameDayCalendar() {
        Calendar c1 = utcCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = utcCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar c3 = utcCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
        assertFalse(DateUtils.isSameDay(c1, c3));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.isSameDay((Calendar) null, Calendar.getInstance());
            }
        });
    }

    @Test
    public void testIsSameInstantDate() {
        long millis = utcDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0).getTime();
        Date d1 = new Date(millis);
        Date d2 = new Date(millis);
        Date d3 = new Date(millis + 1);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.isSameInstant((Date) null, new Date());
            }
        });
    }

    @Test
    public void testIsSameInstantCalendar() {
        Date date = utcDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c1 = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        c1.setTime(date);
        Calendar c2 = new GregorianCalendar(TimeZone.getTimeZone("America/New_York"));
        c2.setTime(date);
        // Same instant, different time zone/fields.
        assertTrue(DateUtils.isSameInstant(c1, c2));
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            }
        });
    }

    @Test
    public void testIsSameLocalTime() {
        TimeZone tz1 = TimeZone.getTimeZone("UTC");
        TimeZone tz2 = TimeZone.getTimeZone("America/New_York");
        Calendar c1 = new GregorianCalendar(tz1);
        c1.set(2002, Calendar.MARCH, 28, 13, 45, 0);
        c1.set(Calendar.MILLISECOND, 0);
        Calendar c2 = new GregorianCalendar(tz2);
        c2.set(2002, Calendar.MARCH, 28, 13, 45, 0);
        c2.set(Calendar.MILLISECOND, 0);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c2));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.isSameLocalTime((Calendar) null, Calendar.getInstance());
            }
        });
    }

    // ------------------------------------------------------------------
    // iterator
    // ------------------------------------------------------------------

    @Test
    public void testIteratorRangeMonthSunday() {
        Calendar focus = utcCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertEquals(Calendar.THURSDAY, focus.get(Calendar.DAY_OF_WEEK));
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        assertTrue(it.hasNext());
        Calendar first = it.next();
        assertEquals(utcDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0), first.getTime());
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(utcDate(2002, Calendar.AUGUST, 3, 0, 0, 0, 0), last.getTime());
        assertEquals(35, count);
    }

    @Test
    public void testIteratorRangeWeekSunday() {
        Calendar focus = utcCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    public void testIteratorDateOverload() {
        Date focus = utcDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = it.next();
        assertEquals(utcDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0), first.getTime());
    }

    @Test
    public void testIteratorObjectOverload() {
        Date focusDate = utcDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Calendar focusCal = utcCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<?> itDate = DateUtils.iterator((Object) focusDate, DateUtils.RANGE_MONTH_SUNDAY);
        Iterator<?> itCal = DateUtils.iterator((Object) focusCal, DateUtils.RANGE_MONTH_SUNDAY);
        Object firstFromDate = itDate.next();
        Object firstFromCal = itCal.next();
        assertTrue(firstFromDate instanceof Calendar);
        assertEquals(((Calendar) firstFromDate).getTime(), ((Calendar) firstFromCal).getTime());
        assertThrows(ClassCastException.class, new Executable() {
            public void execute() {
                DateUtils.iterator((Object) "not a date", DateUtils.RANGE_MONTH_SUNDAY);
            }
        });
    }

    @Test
    public void testIteratorInvalidRangeStyle() {
        final Calendar focus = utcCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.iterator(focus, 99999);
            }
        });
    }

    @Test
    public void testIteratorNullArguments() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    // ------------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ------------------------------------------------------------------

    @Test
    public void testParseDateHappyPath() throws ParseException {
        Date result = DateUtils.parseDate("2021-01-02", "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test
    public void testParseDateTriesEachPatternInTurn() throws ParseException {
        Date result = DateUtils.parseDate("2021/01/02", "yyyy-MM-dd", "yyyy/MM/dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateMustConsumeWholeString() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate("2021-01-02 extra", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void testParseDateNoMatchingPattern() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate("not a date", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void testParseDateNoPatternsAtAll() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate("2021-01-02");
            }
        });
    }

    @Test
    public void testParseDateNullArguments() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate("2021-01-02", (String[]) null);
            }
        });
    }

    @Test
    public void testParseDateWithLocale() throws ParseException {
        Date result = DateUtils.parseDate("March 5, 2020", Locale.US, "MMMM d, yyyy");
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateNullLocaleFallsBackToDefault() throws ParseException {
        Date withNullLocale = DateUtils.parseDate("2021-01-02", (Locale) null, "yyyy-MM-dd");
        Date withoutLocale = DateUtils.parseDate("2021-01-02", "yyyy-MM-dd");
        assertEquals(withoutLocale, withNullLocale);
    }

    @Test
    public void testParseDateWithLocaleNullArguments() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate(null, Locale.US, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDate("2021-01-02", Locale.US, (String[]) null);
            }
        });
    }

    @Test
    public void testParseDateLenientAllowsOverflow() throws ParseException {
        // Documented example: lenient parsing allows "February 942, 1996".
        Date result = DateUtils.parseDate("February 942, 1996", Locale.US, "MMMM d, yyyy");
        assertNotNull(result);
    }

    @Test
    public void testParseDateStrictlyRejectsOverflow() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDateStrictly("February 942, 1996", Locale.US, "MMMM d, yyyy");
            }
        });
    }

    @Test
    public void testParseDateStrictlyHappyPath() throws ParseException {
        Date result = DateUtils.parseDateStrictly("2021-01-02", "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateStrictlyMustConsumeWholeString() {
        assertThrows(ParseException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDateStrictly("2021-01-02 extra", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void testParseDateStrictlyNullArguments() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Exception {
                DateUtils.parseDateStrictly("2021-01-02", (String[]) null);
            }
        });
    }

    @Test
    public void testParseDateStrictlyNullLocaleFallsBackToDefault() throws ParseException {
        Date withNullLocale = DateUtils.parseDateStrictly("2021-01-02", (Locale) null, "yyyy-MM-dd");
        Date withoutLocale = DateUtils.parseDateStrictly("2021-01-02", "yyyy-MM-dd");
        assertEquals(withoutLocale, withNullLocale);
    }

    // ------------------------------------------------------------------
    // setXxx
    // ------------------------------------------------------------------

    @Test
    public void testSetDays() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        long originalMillis = date.getTime();
        assertEquals(utcDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0), DateUtils.setDays(date, 1));
        assertEquals(utcDate(2020, Calendar.JANUARY, 31, 10, 0, 0, 0), DateUtils.setDays(date, 31));
        assertEquals(originalMillis, date.getTime());
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setDays(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setDays(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 32);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setDays(null, 1);
            }
        });
    }

    @Test
    public void testSetHours() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 0);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 0, 30, 0, 0), DateUtils.setHours(date, 0));
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 23, 30, 0, 0), DateUtils.setHours(date, 23));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setHours(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setHours(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 24);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setHours(null, 0);
            }
        });
    }

    @Test
    public void testSetMilliseconds() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 500);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 0), DateUtils.setMilliseconds(date, 0));
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 999), DateUtils.setMilliseconds(date, 999));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setMilliseconds(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setMilliseconds(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 1000);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setMilliseconds(null, 0);
            }
        });
    }

    @Test
    public void testSetMinutes() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 0);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), DateUtils.setMinutes(date, 0));
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 59, 0, 0), DateUtils.setMinutes(date, 59));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setMinutes(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setMinutes(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 60);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setMinutes(null, 0);
            }
        });
    }

    @Test
    public void testSetMonths() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), DateUtils.setMonths(date, 0));
        assertEquals(utcDate(2020, Calendar.DECEMBER, 15, 10, 0, 0, 0), DateUtils.setMonths(date, 11));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setMonths(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setMonths(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 12);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setMonths(null, 0);
            }
        });
    }

    @Test
    public void testSetSeconds() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 15, 0);
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 0), DateUtils.setSeconds(date, 0));
        assertEquals(utcDate(2020, Calendar.JANUARY, 15, 10, 30, 59, 0), DateUtils.setSeconds(date, 59));
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setSeconds(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                DateUtils.setSeconds(utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0), 60);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setSeconds(null, 0);
            }
        });
    }

    @Test
    public void testSetYears() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        Date result = DateUtils.setYears(date, 2050);
        Calendar cal = utcCalendar();
        cal.setTime(result);
        assertEquals(2050, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.setYears(null, 2000);
            }
        });
    }

    // ------------------------------------------------------------------
    // toCalendar
    // ------------------------------------------------------------------

    @Test
    public void testToCalendar() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    public void testToCalendarWithTimeZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date, cal.getTime());
        assertEquals(tz, cal.getTimeZone());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.toCalendar(new Date(), (TimeZone) null);
            }
        });
    }

    // ------------------------------------------------------------------
    // toLocalDateTime / toOffsetDateTime / toZonedDateTime
    // ------------------------------------------------------------------

    @Test
    public void testToLocalDateTimeWithTimeZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        LocalDateTime result = DateUtils.toLocalDateTime(date, tz);
        LocalDateTime expected = date.toInstant().atZone(tz.toZoneId()).toLocalDateTime();
        assertEquals(expected, result);
    }

    @Test
    public void testToLocalDateTimeNullTimeZoneMapsToDefault() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        LocalDateTime withNull = DateUtils.toLocalDateTime(date, (TimeZone) null);
        LocalDateTime withDefault = DateUtils.toLocalDateTime(date, TimeZone.getDefault());
        assertEquals(withDefault, withNull);
    }

    @Test
    public void testToLocalDateTimeSingleArgUsesDefaultZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        LocalDateTime result = DateUtils.toLocalDateTime(date);
        LocalDateTime expected = DateUtils.toLocalDateTime(date, TimeZone.getDefault());
        assertEquals(expected, result);
    }

    @Test
    public void testToOffsetDateTimeWithTimeZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        OffsetDateTime result = DateUtils.toOffsetDateTime(date, tz);
        OffsetDateTime expected = date.toInstant().atZone(tz.toZoneId()).toOffsetDateTime();
        assertEquals(expected, result);
        assertEquals(date.toInstant(), result.toInstant());
    }

    @Test
    public void testToOffsetDateTimeSingleArgUsesDefaultZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        OffsetDateTime result = DateUtils.toOffsetDateTime(date);
        OffsetDateTime expected = DateUtils.toOffsetDateTime(date, TimeZone.getDefault());
        assertEquals(expected, result);
    }

    @Test
    public void testToZonedDateTimeWithTimeZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        ZoneId zoneId = tz.toZoneId();
        ZonedDateTime result = DateUtils.toZonedDateTime(date, tz);
        ZonedDateTime expected = date.toInstant().atZone(zoneId);
        assertEquals(expected, result);
        assertEquals(date.toInstant(), result.toInstant());
    }

    @Test
    public void testToZonedDateTimeSingleArgUsesDefaultZone() {
        Date date = utcDate(2020, Calendar.JANUARY, 15, 10, 30, 45, 123);
        ZonedDateTime result = DateUtils.toZonedDateTime(date);
        ZonedDateTime expected = DateUtils.toZonedDateTime(date, TimeZone.getDefault());
        assertEquals(expected, result);
    }

    // ------------------------------------------------------------------
    // truncatedCompareTo / truncatedEquals
    // ------------------------------------------------------------------

    @Test
    public void testTruncatedCompareToDate() {
        Date d1 = utcDate(2020, Calendar.JANUARY, 1, 10, 15, 30, 0);
        Date d2 = utcDate(2020, Calendar.JANUARY, 1, 11, 45, 50, 0);
        Date d3 = utcDate(2020, Calendar.JANUARY, 2, 10, 15, 30, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(d1, d2, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(d2, d1, Calendar.HOUR_OF_DAY) > 0);
        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.DATE) < 0);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncatedCompareTo((Date) null, new Date(), Calendar.DATE);
            }
        });
    }

    @Test
    public void testTruncatedCompareToCalendar() {
        Calendar c1 = utcCalendar(2020, Calendar.JANUARY, 1, 10, 15, 30, 0);
        Calendar c2 = utcCalendar(2020, Calendar.JANUARY, 1, 11, 45, 50, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(c1, c2, Calendar.HOUR_OF_DAY) < 0);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncatedCompareTo((Calendar) null, Calendar.getInstance(), Calendar.DATE);
            }
        });
    }

    @Test
    public void testTruncatedEqualsDate() {
        Date d1 = utcDate(2020, Calendar.JANUARY, 1, 10, 15, 30, 0);
        Date d2 = utcDate(2020, Calendar.JANUARY, 1, 11, 45, 50, 0);
        Date d3 = utcDate(2020, Calendar.JANUARY, 2, 10, 15, 30, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DATE));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncatedEquals((Date) null, new Date(), Calendar.DATE);
            }
        });
    }

    @Test
    public void testTruncatedEqualsCalendar() {
        Calendar c1 = utcCalendar(2020, Calendar.JANUARY, 1, 10, 15, 30, 0);
        Calendar c2 = utcCalendar(2020, Calendar.JANUARY, 1, 11, 45, 50, 0);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                DateUtils.truncatedEquals((Calendar) null, Calendar.getInstance(), Calendar.DATE);
            }
        });
    }
}
