/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link SystemProperties}.
 */
class SystemPropertiesAgentTest {

    private static final String CUSTOM_KEY = "SystemPropertiesAgentTest.customProperty";

    /**
     * Runs the given action with the given system property set to the given value, restoring the
     * previous value (or absence thereof) afterward.
     */
    private void withProperty(final String key, final String value, final Runnable action) {
        final String original = System.getProperty(key);
        try {
            if (value == null) {
                System.clearProperty(key);
            } else {
                System.setProperty(key, value);
            }
            action.run();
        } finally {
            if (original == null) {
                System.clearProperty(key);
            } else {
                System.setProperty(key, original);
            }
        }
    }

    private static BooleanSupplier booleanSupplier(final boolean value) {
        return new BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return value;
            }
        };
    }

    private static IntSupplier intSupplier(final int value) {
        return new IntSupplier() {
            @Override
            public int getAsInt() {
                return value;
            }
        };
    }

    private static LongSupplier longSupplier(final long value) {
        return new LongSupplier() {
            @Override
            public long getAsLong() {
                return value;
            }
        };
    }

    private static <T> Supplier<T> constantSupplier(final T value) {
        return new Supplier<T>() {
            @Override
            public T get() {
                return value;
            }
        };
    }

    @Test
    void testGetProperty_knownValue() {
        withProperty(CUSTOM_KEY, "aValue", new Runnable() {
            @Override
            public void run() {
                assertEquals("aValue", SystemProperties.getProperty(CUSTOM_KEY));
            }
        });
    }

    @Test
    void testGetProperty_absentReturnsNull() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertNull(SystemProperties.getProperty(CUSTOM_KEY));
            }
        });
    }

    @Test
    void testGetProperty_nullPropertyNameReturnsNull() {
        assertNull(SystemProperties.getProperty(null));
    }

    @Test
    void testGetProperty_emptyPropertyNameReturnsNull() {
        assertNull(SystemProperties.getProperty(""));
    }

    @Test
    void testGetPropertyStringDefault_absentReturnsDefault() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertEquals("fallback", SystemProperties.getProperty(CUSTOM_KEY, "fallback"));
            }
        });
    }

    @Test
    void testGetPropertyStringDefault_presentReturnsValue() {
        withProperty(CUSTOM_KEY, "present", new Runnable() {
            @Override
            public void run() {
                assertEquals("present", SystemProperties.getProperty(CUSTOM_KEY, "fallback"));
            }
        });
    }

    @Test
    void testGetPropertyEmptyName_usesSupplier() {
        assertEquals("fallback", SystemProperties.getProperty("", "fallback"));
    }

    @Test
    void testGetBoolean_true() {
        withProperty(CUSTOM_KEY, "true", new Runnable() {
            @Override
            public void run() {
                assertTrue(SystemProperties.getBoolean(CUSTOM_KEY, booleanSupplier(false)));
            }
        });
    }

    @Test
    void testGetBoolean_falseForNonBooleanText() {
        withProperty(CUSTOM_KEY, "notABoolean", new Runnable() {
            @Override
            public void run() {
                assertFalse(SystemProperties.getBoolean(CUSTOM_KEY, booleanSupplier(true)));
            }
        });
    }

    @Test
    void testGetBoolean_absentUsesDefaultSupplier() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertTrue(SystemProperties.getBoolean(CUSTOM_KEY, booleanSupplier(true)));
                assertFalse(SystemProperties.getBoolean(CUSTOM_KEY, booleanSupplier(false)));
            }
        });
    }

    @Test
    void testGetBoolean_absentAndNullSupplierReturnsFalse() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertFalse(SystemProperties.getBoolean(CUSTOM_KEY, null));
            }
        });
    }

    @Test
    void testGetBooleanWithClass_composesKeyFromSimpleClassName() {
        final String composedKey = String.class.getSimpleName() + "." + "flag";
        withProperty(composedKey, "true", new Runnable() {
            @Override
            public void run() {
                assertTrue(SystemProperties.getBoolean(String.class, "flag", booleanSupplier(false)));
            }
        });
    }

    @Test
    void testGetInt_parsesValue() {
        withProperty(CUSTOM_KEY, "42", new Runnable() {
            @Override
            public void run() {
                assertEquals(42, SystemProperties.getInt(CUSTOM_KEY, intSupplier(-1)));
            }
        });
    }

    @Test
    void testGetInt_absentUsesDefaultSupplier() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertEquals(7, SystemProperties.getInt(CUSTOM_KEY, intSupplier(7)));
            }
        });
    }

    @Test
    void testGetInt_absentAndNullSupplierReturnsZero() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertEquals(0, SystemProperties.getInt(CUSTOM_KEY, null));
            }
        });
    }

    @Test
    void testGetInt_invalidNumberThrows() {
        withProperty(CUSTOM_KEY, "notANumber", new Runnable() {
            @Override
            public void run() {
                assertThrows(NumberFormatException.class, new Executable() {
                    @Override
                    public void execute() {
                        SystemProperties.getInt(CUSTOM_KEY, intSupplier(0));
                    }
                });
            }
        });
    }

    @Test
    void testGetIntWithClass_composesKeyFromSimpleClassName() {
        final String composedKey = Integer.class.getSimpleName() + "." + "count";
        withProperty(composedKey, "99", new Runnable() {
            @Override
            public void run() {
                assertEquals(99, SystemProperties.getInt(Integer.class, "count", intSupplier(-1)));
            }
        });
    }

    @Test
    void testGetLong_parsesValue() {
        withProperty(CUSTOM_KEY, "123456789012", new Runnable() {
            @Override
            public void run() {
                assertEquals(123456789012L, SystemProperties.getLong(CUSTOM_KEY, longSupplier(-1L)));
            }
        });
    }

    @Test
    void testGetLong_absentUsesDefaultSupplier() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertEquals(123L, SystemProperties.getLong(CUSTOM_KEY, longSupplier(123L)));
            }
        });
    }

    @Test
    void testGetLong_absentAndNullSupplierReturnsZero() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertEquals(0L, SystemProperties.getLong(CUSTOM_KEY, null));
            }
        });
    }

    @Test
    void testGetLong_invalidNumberThrows() {
        withProperty(CUSTOM_KEY, "notANumber", new Runnable() {
            @Override
            public void run() {
                assertThrows(NumberFormatException.class, new Executable() {
                    @Override
                    public void execute() {
                        SystemProperties.getLong(CUSTOM_KEY, longSupplier(0L));
                    }
                });
            }
        });
    }

    @Test
    void testGetLongWithClass_composesKeyFromSimpleClassName() {
        final String composedKey = Long.class.getSimpleName() + "." + "big";
        withProperty(composedKey, "555", new Runnable() {
            @Override
            public void run() {
                assertEquals(555L, SystemProperties.getLong(Long.class, "big", longSupplier(-1L)));
            }
        });
    }

    @Test
    void testGetPath_parsesValue() {
        withProperty(CUSTOM_KEY, "a" + java.io.File.separator + "b", new Runnable() {
            @Override
            public void run() {
                final Path expected = Paths.get("a", "b");
                assertEquals(expected, SystemProperties.getPath(CUSTOM_KEY, SystemPropertiesAgentTest.<Path>constantSupplier(null)));
            }
        });
    }

    @Test
    void testGetPath_absentUsesDefaultSupplier() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                final Path fallback = Paths.get("fallback");
                assertEquals(fallback, SystemProperties.getPath(CUSTOM_KEY, constantSupplier(fallback)));
            }
        });
    }

    @Test
    void testGetPath_absentAndNullSupplierReturnsNull() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertNull(SystemProperties.getPath(CUSTOM_KEY, null));
            }
        });
    }

    @Test
    void testIsPropertySet_trueWhenSet() {
        withProperty(CUSTOM_KEY, "anything", new Runnable() {
            @Override
            public void run() {
                assertTrue(SystemProperties.isPropertySet(CUSTOM_KEY));
            }
        });
    }

    @Test
    void testIsPropertySet_falseWhenAbsent() {
        withProperty(CUSTOM_KEY, null, new Runnable() {
            @Override
            public void run() {
                assertFalse(SystemProperties.isPropertySet(CUSTOM_KEY));
            }
        });
    }

    @Test
    void testGetLineSeparator_matchesSystemProperty() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator());
    }

    @Test
    void testGetLineSeparatorWithDefault_presentIgnoresDefault() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator(constantSupplier("SHOULD_NOT_BE_USED")));
    }

    @Test
    void testGetLineSeparatorWithDefault_absentUsesDefault() {
        withProperty("line.separator", null, new Runnable() {
            @Override
            public void run() {
                assertEquals("fallbackSeparator", SystemProperties.getLineSeparator(constantSupplier("fallbackSeparator")));
            }
        });
    }

    @Test
    void testGetUserName_matchesSystemProperty() {
        assertEquals(System.getProperty("user.name"), SystemProperties.getUserName());
    }

    @Test
    void testGetUserNameWithDefault_absentUsesDefault() {
        withProperty("user.name", null, new Runnable() {
            @Override
            public void run() {
                assertEquals("defaultUser", SystemProperties.getUserName("defaultUser"));
            }
        });
    }

    @Test
    void testGetUserNameWithDefault_presentIgnoresDefault() {
        withProperty("user.name", "actualUser", new Runnable() {
            @Override
            public void run() {
                assertEquals("actualUser", SystemProperties.getUserName("defaultUser"));
            }
        });
    }

    @Test
    void testGetJavaSpecificationVersion_matchesSystemProperty() {
        assertEquals(System.getProperty("java.specification.version"), SystemProperties.getJavaSpecificationVersion());
    }

    @Test
    void testGetJavaSpecificationVersionWithDefault_absentUsesDefault() {
        withProperty("java.specification.version", null, new Runnable() {
            @Override
            public void run() {
                assertEquals("99", SystemProperties.getJavaSpecificationVersion("99"));
            }
        });
    }

    @Test
    void testPlainGetters_matchUnderlyingSystemProperties() {
        assertEquals(System.getProperty("file.encoding"), SystemProperties.getFileEncoding());
        assertEquals(System.getProperty("file.separator"), SystemProperties.getFileSeparator());
        assertEquals(System.getProperty("java.class.path"), SystemProperties.getJavaClassPath());
        assertEquals(System.getProperty("java.home"), SystemProperties.getJavaHome());
        assertEquals(System.getProperty("java.io.tmpdir"), SystemProperties.getJavaIoTmpdir());
        assertEquals(System.getProperty("java.version"), SystemProperties.getJavaVersion());
        assertEquals(System.getProperty("os.name"), SystemProperties.getOsName());
        assertEquals(System.getProperty("os.arch"), SystemProperties.getOsArch());
        assertEquals(System.getProperty("os.version"), SystemProperties.getOsVersion());
        assertEquals(System.getProperty("path.separator"), SystemProperties.getPathSeparator());
        assertEquals(System.getProperty("user.dir"), SystemProperties.getUserDir());
        assertEquals(System.getProperty("user.home"), SystemProperties.getUserHome());
    }

    @Test
    void testGetJavaClassPath_isNotNullOnAJvm() {
        assertNotNull(SystemProperties.getJavaClassPath());
    }

    @Test
    void testDeprecatedAwtToolkit_matchesSystemPropertyEvenIfAbsent() {
        assertEquals(System.getProperty("awt.toolkit"), SystemProperties.getAwtToolkit());
    }

    @Test
    void testConstructor_isUsable() {
        assertNotNull(new SystemProperties());
    }
}
