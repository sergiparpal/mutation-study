/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    /** A GregorianCalendar subclass used to exercise the getClass() check in isSameLocalTime. */
    private static final class OtherCalendar extends GregorianCalendar {
        private static final long serialVersionUID = 1L;
    }

    private static Date parse(final String pattern, final String text) throws ParseException {
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.ENGLISH);
        sdf.setLenient(false);
        return sdf.parse(text);
    }

    private static Calendar calendarOf(final int year, final int month, final int day, final int hour,
            final int minute, final int second, final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    // ---- constants ----

    @Test
    void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    void testDeprecatedPublicConstructor() {
        assertNotNull(new DateUtils());
    }

    // ---- addXxx ----

    @Test
    void testAddDays() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 10, 30, 0, 0).getTime();
        final long originalMillis = base.getTime();
        final Date result = DateUtils.addDays(base, 10);
        assertEquals(originalMillis, base.getTime(), "original date must not be mutated");
        assertNotSame(base, result);
        final Calendar c = DateUtils.toCalendar(result);
        assertEquals(25, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JANUARY, c.get(Calendar.MONTH));

        final Date backward = DateUtils.addDays(base, -20);
        final Calendar c2 = DateUtils.toCalendar(backward);
        assertEquals(Calendar.DECEMBER, c2.get(Calendar.MONTH));
        assertEquals(2022, c2.get(Calendar.YEAR));
    }

    @Test
    void testAddHours() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 10, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addHours(base, 5));
        assertEquals(15, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testAddMinutes() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 10, 30, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addMinutes(base, 45));
        assertEquals(11, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(15, c.get(Calendar.MINUTE));
    }

    @Test
    void testAddSeconds() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 10, 30, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addSeconds(base, 90));
        assertEquals(31, c.get(Calendar.MINUTE));
        assertEquals(30, c.get(Calendar.SECOND));
    }

    @Test
    void testAddMilliseconds() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 10, 30, 0, 100).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addMilliseconds(base, 50));
        assertEquals(150, c.get(Calendar.MILLISECOND));
    }

    @Test
    void testAddWeeks() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addWeeks(base, 1));
        assertEquals(22, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddMonths() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addMonths(base, 2));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(15, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddYears() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.addYears(base, 1));
        assertEquals(2024, c.get(Calendar.YEAR));
    }

    @Test
    void testAddMethods_nullDate_throwNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addHours(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMinutes(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addSeconds(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMilliseconds(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addWeeks(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMonths(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addYears(null, 1);
            }
        });
    }

    // ---- truncate ----

    @Test
    void testTruncateDate_hourAndMonth() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:00:00.000"), DateUtils.truncate(d, Calendar.HOUR));
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 01, 2002 0:00:00.000"), DateUtils.truncate(d, Calendar.MONTH));
    }

    @Test
    void testTruncateCalendar_returnsNewInstanceAndLeavesOriginalUnchanged() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        final Calendar original = DateUtils.toCalendar(d);
        final long originalMillis = original.getTimeInMillis();
        final Calendar truncated = DateUtils.truncate(original, Calendar.HOUR);
        assertNotSame(original, truncated);
        assertEquals(originalMillis, original.getTimeInMillis(), "original calendar must not be mutated");
        assertEquals(13, truncated.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, truncated.get(Calendar.MINUTE));
        assertEquals(0, truncated.get(Calendar.SECOND));
        assertEquals(0, truncated.get(Calendar.MILLISECOND));
    }

    @Test
    void testTruncateObject_dispatchesToDateAndCalendar() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        final Calendar c = DateUtils.toCalendar(d);
        final Date expected = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:00:00.000");
        assertEquals(expected, DateUtils.truncate((Object) d, Calendar.HOUR));
        assertEquals(expected, DateUtils.truncate((Object) c, Calendar.HOUR));
    }

    @Test
    void testTruncateObject_invalidType_throwsClassCastException() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate("not a date", Calendar.HOUR);
            }
        });
    }

    @Test
    void testTruncate_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Calendar) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) null, Calendar.HOUR);
            }
        });
    }

    @Test
    void testTruncate_semiMonth() throws ParseException {
        // Last day of the first half of February 2007 rounds (truncates) down to Feb 1.
        final Date lastOfFirstHalf = parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 15, 2007 23:59:59.999");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 01, 2007 0:00:00.000"),
                DateUtils.truncate(lastOfFirstHalf, DateUtils.SEMI_MONTH));
        final Date secondHalf = parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 20, 2007 10:00:00.000");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 16, 2007 0:00:00.000"),
                DateUtils.truncate(secondHalf, DateUtils.SEMI_MONTH));
    }

    @Test
    void testTruncate_yearOverflow_throwsArithmeticException() {
        final Calendar huge = Calendar.getInstance();
        huge.clear();
        huge.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(huge, Calendar.MONTH);
            }
        });
    }

    // ---- round ----

    @Test
    void testRound_hour_roundsUpAndDown() throws ParseException {
        // 45 minutes rounds up, matches the documented example.
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 14:00:00.000"), DateUtils.round(d, Calendar.HOUR));

        final Date downish = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:10:00.000");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:00:00.000"), DateUtils.round(downish, Calendar.HOUR));
    }

    @Test
    void testRound_calendarOverload_doesNotMutateOriginal() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        final Calendar original = DateUtils.toCalendar(d);
        final long originalMillis = original.getTimeInMillis();
        final Calendar rounded = DateUtils.round(original, Calendar.HOUR);
        assertEquals(originalMillis, original.getTimeInMillis());
        assertEquals(14, rounded.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRound_object_dispatch() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        final Calendar c = DateUtils.toCalendar(d);
        final Date expected = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 14:00:00.000");
        assertEquals(expected, DateUtils.round((Object) d, Calendar.HOUR));
        assertEquals(expected, DateUtils.round((Object) c, Calendar.HOUR));
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round(Integer.valueOf(1), Calendar.HOUR);
            }
        });
    }

    @Test
    void testRound_semiMonth() throws ParseException {
        // SEMI_MONTH rounding depends only on the day-of-month, with the boundary between day 8 and day 9.
        final Date lastRoundDown = parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 08, 2007 23:59:59.999");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 01, 2007 0:00:00.000"),
                DateUtils.round(lastRoundDown, DateUtils.SEMI_MONTH));
        final Date firstRoundUp = parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 09, 2007 0:00:00.000");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Feb 16, 2007 0:00:00.000"),
                DateUtils.round(firstRoundUp, DateUtils.SEMI_MONTH));
    }

    @Test
    void testRound_amPm() throws ParseException {
        final Date am = parse("MMM dd, yyyy H:mm:ss.SSS", "Jun 01, 2008 5:00:00.000");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Jun 01, 2008 0:00:00.000"), DateUtils.round(am, Calendar.AM_PM));
        final Date pm = parse("MMM dd, yyyy H:mm:ss.SSS", "Jun 01, 2008 18:00:00.000");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Jun 02, 2008 0:00:00.000"), DateUtils.round(pm, Calendar.AM_PM));
    }

    @Test
    void testRound_invalidField_throwsIllegalArgumentException() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round(d, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testRound_yearOverflow_throwsArithmeticException() {
        final Calendar huge = Calendar.getInstance();
        huge.clear();
        huge.set(Calendar.YEAR, 280000001);
        final Date hugeDate = huge.getTime();
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round(hugeDate, Calendar.MONTH);
            }
        });
    }

    @Test
    void testRound_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Date) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Calendar) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) null, Calendar.HOUR);
            }
        });
    }

    // ---- ceiling ----

    @Test
    void testCeiling_hourAndMonth() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:45:01.231");
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 14:00:00.000"), DateUtils.ceiling(d, Calendar.HOUR));
        assertEquals(parse("MMM dd, yyyy H:mm:ss.SSS", "Apr 01, 2002 0:00:00.000"), DateUtils.ceiling(d, Calendar.MONTH));
    }

    @Test
    void testCeiling_exactlyOnBoundary_returnsSameInstant() throws ParseException {
        final Date d = parse("MMM dd, yyyy H:mm:ss.SSS", "Mar 28, 2002 13:00:00.000");
        assertEquals(d, DateUtils.ceiling(d, Calendar.HOUR));
    }

    @Test
    void testCeiling_object_invalidType_throwsClassCastException() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(new Object(), Calendar.HOUR);
            }
        });
    }

    @Test
    void testCeiling_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) null, Calendar.HOUR);
            }
        });
    }

    // ---- fragments ----

    @Test
    void testGetFragmentInDays() {
        final Calendar c = calendarOf(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(59, DateUtils.getFragmentInDays(c, Calendar.YEAR));
        assertEquals(28, DateUtils.getFragmentInDays(c, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInDays(c.getTime(), Calendar.DATE));
    }

    @Test
    void testGetFragmentInHours() {
        final Calendar c = calendarOf(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(c, Calendar.DAY_OF_YEAR));
        assertEquals(127, DateUtils.getFragmentInHours(c, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInHours(c.getTime(), Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Calendar c = calendarOf(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(c, Calendar.HOUR_OF_DAY));
        // 5 full days (day 6 minus offset 1) plus 7h15m leftover: 5*1440 + 7*60 + 15
        assertEquals(7635, DateUtils.getFragmentInMinutes(c.getTime(), Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Calendar c = calendarOf(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(c, Calendar.MINUTE));
        assertEquals(26110, DateUtils.getFragmentInSeconds(c.getTime(), Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Calendar c = calendarOf(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(c, Calendar.SECOND));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(c.getTime(), Calendar.MINUTE));
        assertEquals(0, DateUtils.getFragmentInMilliseconds(c.getTime(), Calendar.MILLISECOND));
    }

    @Test
    void testGetFragment_unsupportedFragment_throwsIllegalArgumentException() {
        final Calendar c = calendarOf(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(c, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testGetFragment_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
    }

    // ---- isSameXxx ----

    @Test
    void testIsSameDay() {
        final Calendar cal1 = calendarOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = calendarOf(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Calendar cal3 = calendarOf(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertFalse(DateUtils.isSameDay(cal1, cal3));
        assertTrue(DateUtils.isSameDay(cal1.getTime(), cal2.getTime()));
        assertFalse(DateUtils.isSameDay(cal1.getTime(), cal3.getTime()));
    }

    @Test
    void testIsSameDay_null_throwsNullPointerException() {
        final Calendar cal = calendarOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay(cal, null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Date) null, cal.getTime());
            }
        });
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = new Date(1000L);
        final Date d2 = new Date(1000L);
        final Date d3 = new Date(2000L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));

        final Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(1000L);
        final Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c2.setTimeInMillis(1000L);
        assertTrue(DateUtils.isSameInstant(c1, c2), "different time zones but same instant");
        final Calendar c3 = Calendar.getInstance();
        c3.setTimeInMillis(2000L);
        assertFalse(DateUtils.isSameInstant(c1, c3));
    }

    @Test
    void testIsSameInstant_null_throwsNullPointerException() {
        final Date d = new Date(0L);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant(d, null);
            }
        });
        final Calendar c = Calendar.getInstance();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Calendar) null, c);
            }
        });
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar c1 = calendarOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar c2 = calendarOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));

        final Calendar c3 = calendarOf(2002, Calendar.MARCH, 28, 13, 45, 1, 232);
        assertFalse(DateUtils.isSameLocalTime(c1, c3));

        final Calendar other = new OtherCalendar();
        other.clear();
        other.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        other.set(Calendar.MILLISECOND, 231);
        assertFalse(DateUtils.isSameLocalTime(c1, other), "different Calendar subclasses must not be considered equal");
    }

    @Test
    void testIsSameLocalTime_null_throwsNullPointerException() {
        final Calendar c = Calendar.getInstance();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(c, null);
            }
        });
    }

    // ---- iterator ----

    @Test
    void testIterator_rangeWeekSunday() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY));
        assertEquals(7, days.size());
        assertEquals(Calendar.SUNDAY, days.get(0).get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, days.get(6).get(Calendar.DAY_OF_WEEK));
        assertTrue(containsSameDay(days, focus));
    }

    @Test
    void testIterator_rangeWeekMonday() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY));
        assertEquals(7, days.size());
        assertEquals(Calendar.MONDAY, days.get(0).get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SUNDAY, days.get(6).get(Calendar.DAY_OF_WEEK));
        assertTrue(containsSameDay(days, focus));
    }

    @Test
    void testIterator_rangeWeekRelative() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE));
        assertEquals(7, days.size());
        assertTrue(DateUtils.isSameDay(days.get(0), focus));
        final Calendar expectedLast = (Calendar) focus.clone();
        expectedLast.add(Calendar.DATE, 6);
        assertTrue(DateUtils.isSameDay(days.get(6), expectedLast));
    }

    @Test
    void testIterator_rangeWeekCenter() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER));
        assertEquals(7, days.size());
        assertTrue(DateUtils.isSameDay(days.get(3), focus), "focus date must be in the middle");
    }

    @Test
    void testIterator_rangeMonthSunday() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY));
        assertEquals(Calendar.SUNDAY, days.get(0).get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, days.get(days.size() - 1).get(Calendar.DAY_OF_WEEK));
        int julyDays = 0;
        for (final Calendar d : days) {
            if (d.get(Calendar.MONTH) == Calendar.JULY && d.get(Calendar.YEAR) == 2023) {
                julyDays++;
            }
        }
        assertEquals(31, julyDays, "every day of July must be present");
    }

    @Test
    void testIterator_rangeMonthMonday() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_MONTH_MONDAY));
        assertEquals(Calendar.MONDAY, days.get(0).get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SUNDAY, days.get(days.size() - 1).get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIterator_invalidRangeStyle_throwsIllegalArgumentException() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator(focus, 999);
            }
        });
    }

    @Test
    void testIterator_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIterator_dateOverloadMatchesCalendarOverload() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final java.util.List<Calendar> fromCalendar = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY));
        final Iterator<?> fromDate = DateUtils.iterator(focus.getTime(), DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        while (fromDate.hasNext()) {
            final Calendar next = (Calendar) fromDate.next();
            assertTrue(DateUtils.isSameDay(next, fromCalendar.get(count)));
            count++;
        }
        assertEquals(fromCalendar.size(), count);
    }

    @Test
    void testIterator_objectOverload_invalidType_throwsClassCastException() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator("not a date or calendar", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIterator_exhausted_throwsNoSuchElementException() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        while (it.hasNext()) {
            it.next();
        }
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIterator_removeThrowsUnsupportedOperationException() {
        final Calendar focus = calendarOf(2023, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    private static java.util.List<Calendar> drain(final Iterator<Calendar> it) {
        final java.util.List<Calendar> result = new java.util.ArrayList<Calendar>();
        while (it.hasNext()) {
            result.add(it.next());
        }
        return result;
    }

    private static boolean containsSameDay(final java.util.List<Calendar> days, final Calendar focus) {
        for (final Calendar d : days) {
            if (DateUtils.isSameDay(d, focus)) {
                return true;
            }
        }
        return false;
    }

    // ---- parseDate / parseDateStrictly ----

    @Test
    void testParseDate_singlePattern() throws ParseException {
        final Date d = DateUtils.parseDate("2023-07-04", "yyyy-MM-dd");
        final Calendar c = DateUtils.toCalendar(d);
        assertEquals(2023, c.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, c.get(Calendar.MONTH));
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDate_firstMatchingPatternWins() throws ParseException {
        final Date d = DateUtils.parseDate("04/07/2023", "yyyy-MM-dd", "dd/MM/yyyy");
        final Calendar c = DateUtils.toCalendar(d);
        assertEquals(2023, c.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, c.get(Calendar.MONTH));
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDate_withLocale() throws ParseException {
        final Date d = DateUtils.parseDate("4 juillet 2023", Locale.FRENCH, "d MMMM yyyy");
        final Calendar c = DateUtils.toCalendar(d);
        assertEquals(2023, c.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, c.get(Calendar.MONTH));
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDate_noPatternMatches_throwsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("not-a-date-at-all", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDate_lenientRollsOverInvalidDay() throws ParseException {
        // 2023 is not a leap year: Feb 30 rolls over to Mar 2 when parsed leniently.
        final Date d = DateUtils.parseDate("2023-02-30", "yyyy-MM-dd");
        final Calendar c = DateUtils.toCalendar(d);
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(2, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateStrictly_rejectsRolledOverDay() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2023-02-30", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateStrictly_acceptsValidDate() throws ParseException {
        final Date d = DateUtils.parseDateStrictly("2023-07-04", "yyyy-MM-dd");
        final Calendar c = DateUtils.toCalendar(d);
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDate_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2023-07-04", (String[]) null);
            }
        });
    }

    // ---- setXxx ----

    @Test
    void testSetDays_validAndInvalid() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setDays(base, 20));
        assertEquals(20, c.get(Calendar.DAY_OF_MONTH));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(base, 32);
            }
        });
    }

    @Test
    void testSetHours_validAndInvalid() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setHours(base, 23));
        assertEquals(23, c.get(Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(base, 24);
            }
        });
    }

    @Test
    void testSetMinutes_validAndInvalid() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setMinutes(base, 59));
        assertEquals(59, c.get(Calendar.MINUTE));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(base, 60);
            }
        });
    }

    @Test
    void testSetSeconds_validAndInvalid() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setSeconds(base, 59));
        assertEquals(59, c.get(Calendar.SECOND));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(base, 60);
            }
        });
    }

    @Test
    void testSetMilliseconds_validAndInvalid() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setMilliseconds(base, 999));
        assertEquals(999, c.get(Calendar.MILLISECOND));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(base, 1000);
            }
        });
    }

    @Test
    void testSetMonths_validAndInvalid() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setMonths(base, Calendar.DECEMBER));
        assertEquals(Calendar.DECEMBER, c.get(Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(base, 12);
            }
        });
    }

    @Test
    void testSetYears() {
        final Date base = calendarOf(2023, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        final Calendar c = DateUtils.toCalendar(DateUtils.setYears(base, 1999));
        assertEquals(1999, c.get(Calendar.YEAR));
    }

    @Test
    void testSetMethods_null_throwNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setYears(null, 1);
            }
        });
    }

    // ---- conversions ----

    @Test
    void testToCalendar() {
        final Date d = new Date(123456789L);
        final Calendar c = DateUtils.toCalendar(d);
        assertEquals(123456789L, c.getTimeInMillis());
    }

    @Test
    void testToCalendar_withTimeZone() {
        final Date d = new Date(123456789L);
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar c = DateUtils.toCalendar(d, tz);
        assertEquals(123456789L, c.getTimeInMillis());
        assertEquals(tz, c.getTimeZone());
    }

    @Test
    void testToCalendar_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            }
        });
        final Date d = new Date(0L);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(d, null);
            }
        });
    }

    @Test
    void testToLocalDateTime() {
        final Date epoch = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(epoch, TimeZone.getTimeZone("UTC"));
        assertEquals(LocalDateTime.of(1970, 1, 1, 0, 0, 0), ldt);
    }

    @Test
    void testToLocalDateTime_defaultTimeZoneMatchesExplicitDefault() {
        final Date d = new Date(1000000000L);
        assertEquals(DateUtils.toLocalDateTime(d, TimeZone.getDefault()), DateUtils.toLocalDateTime(d));
    }

    @Test
    void testToOffsetDateTime() {
        final Date epoch = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(epoch, TimeZone.getTimeZone("UTC"));
        assertEquals(ZoneOffset.UTC, odt.getOffset());
        assertEquals(1970, odt.getYear());
        assertEquals(1, odt.getMonthValue());
        assertEquals(1, odt.getDayOfMonth());
    }

    @Test
    void testToZonedDateTime() {
        final Date epoch = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(epoch, TimeZone.getTimeZone("UTC"));
        assertEquals(1970, zdt.getYear());
        assertEquals(1, zdt.getMonthValue());
        assertEquals(1, zdt.getDayOfMonth());
        assertEquals(0, zdt.getHour());
    }

    // ---- truncatedCompareTo / truncatedEquals ----

    @Test
    void testTruncatedCompareToAndEquals_calendar() {
        final Calendar c1 = calendarOf(2023, Calendar.JANUARY, 15, 10, 0, 0, 0);
        final Calendar c2 = calendarOf(2023, Calendar.JANUARY, 15, 23, 59, 59, 999);
        final Calendar c3 = calendarOf(2023, Calendar.JANUARY, 16, 0, 0, 0, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(c1, c3, Calendar.DATE) < 0);
        assertFalse(DateUtils.truncatedEquals(c1, c3, Calendar.DATE));
    }

    @Test
    void testTruncatedCompareToAndEquals_date() {
        final Date d1 = calendarOf(2023, Calendar.JANUARY, 15, 10, 0, 0, 0).getTime();
        final Date d2 = calendarOf(2023, Calendar.JANUARY, 15, 23, 59, 59, 999).getTime();
        final Date d3 = calendarOf(2023, Calendar.JANUARY, 16, 0, 0, 0, 0).getTime();
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(d3, d1, Calendar.DATE) > 0);
        assertNotEquals(DateUtils.truncate(d1, Calendar.DATE), DateUtils.truncate(d3, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DATE));
    }
}
