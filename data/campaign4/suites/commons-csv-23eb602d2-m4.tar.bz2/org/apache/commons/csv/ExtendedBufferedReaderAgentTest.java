/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createReader(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialStateBeforeAnyRead() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        br.close();
    }

    @Test
    void testReadSingleCharUpdatesPositionAndLastChar() throws IOException {
        final ExtendedBufferedReader br = createReader("ab");
        assertEquals('a', br.read());
        assertEquals('a', br.getLastChar());
        assertEquals(1, br.getPosition());
        assertEquals('b', br.read());
        assertEquals('b', br.getLastChar());
        assertEquals(2, br.getPosition());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        // position is incremented on every call to read(), even at EOF
        assertEquals(3, br.getPosition());
        br.close();
    }

    @Test
    void testEmptyInputReturnsEofEverywhere() throws IOException {
        final ExtendedBufferedReader br = createReader("");
        assertEquals(EOF, br.peek());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        assertNull(br.readLine());
        assertEquals(0, br.read(new char[10], 0, 0));
        br.close();
    }

    @Test
    void testReadBufferLengthZeroReturnsZeroWithoutConsuming() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        final char[] buf = new char[5];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('a', br.read());
        br.close();
    }

    @Test
    void testReadBufferFullyAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader br = createReader("");
        final char[] buf = new char[5];
        assertEquals(EOF, br.read(buf, 0, 5));
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testGetLineNumberAtVariousStates() throws IOException {
        final ExtendedBufferedReader br = createReader("a\nb");
        assertEquals(0, br.getLineNumber());
        assertEquals('a', br.read());
        // lastChar is 'a', not CR/LF/UNDEFINED/EOF, so getLineNumber adds 1 even though
        // lineNumber counter itself is still 0
        assertEquals(1, br.getLineNumber());
        assertEquals('\n', br.read());
        assertEquals(1, br.getLineNumber());
        assertEquals('b', br.read());
        assertEquals(2, br.getLineNumber());
        assertEquals(EOF, br.read());
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadLineDropsTerminatorsAndHandlesCrLf() throws IOException {
        final ExtendedBufferedReader br = createReader("foo\r\nbar\n\rbaz");
        assertEquals("foo", br.readLine());
        assertEquals("bar", br.readLine());
        assertEquals("", br.readLine());
        assertEquals("baz", br.readLine());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testPeekDoesNotAdvancePositionOrLastChar() throws IOException {
        final ExtendedBufferedReader br = createReader("xy");
        assertEquals('x', br.peek());
        assertEquals('x', br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getPosition());
        assertEquals('x', br.read());
        assertEquals('y', br.peek());
        assertEquals('x', br.getLastChar());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader br = createReader("abcdef");
        assertEquals('a', br.read());
        assertEquals('b', br.read());
        br.mark(10);
        final long markedPosition = br.getPosition();
        final long markedLineNumber = br.getLineNumber();
        final int markedLastChar = br.getLastChar();
        assertEquals('c', br.read());
        assertEquals('d', br.read());
        assertEquals(4, br.getPosition());
        br.reset();
        assertEquals(markedPosition, br.getPosition());
        assertEquals(markedLineNumber, br.getLineNumber());
        assertEquals(markedLastChar, br.getLastChar());
        assertEquals('c', br.read());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        assertEquals('a', br.read());
        assertEquals('a', br.getLastChar());
        br.close();
        assertEquals(EOF, br.getLastChar());
    }

    @Test
    void testCloseThenReadThrows() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        br.close();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testDefaultConstructorDoesNotTrackBytes() throws IOException {
        final ExtendedBufferedReader br = createReader("hello");
        assertEquals(0, br.getBytesRead());
        assertEquals('h', br.read());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testCharsetConstructorWithTrackBytesTrueCountsBytes() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("ab"), StandardCharsets.UTF_8, true);
        assertEquals(0, br.getBytesRead());
        assertEquals('a', br.read());
        assertEquals(1, br.getBytesRead());
        assertEquals('b', br.read());
        assertEquals(2, br.getBytesRead());
        br.close();
    }

    @Test
    void testCharsetConstructorWithTrackBytesFalseDoesNotCountBytes() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("ab"), StandardCharsets.UTF_8, false);
        assertEquals('a', br.read());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testCharsetConstructorWithNullCharsetDoesNotCountBytes() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("ab"), null, true);
        assertEquals('a', br.read());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadForMultiByteUtf8Character() throws IOException {
        // The euro sign is encoded as 3 bytes in UTF-8.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("€"), StandardCharsets.UTF_8, true);
        assertEquals('€', br.read());
        assertEquals(3, br.getBytesRead());
        br.close();
    }

    @Test
    void testReadIntoBufferTracksLastCharAndLineNumber() throws IOException {
        final ExtendedBufferedReader br = createReader("12\r\n34");
        final char[] buf = new char[6];
        final int len = br.read(buf, 0, 6);
        assertEquals(6, len);
        assertEquals('4', br.getLastChar());
        // lastChar is '4', which is not CR/LF/EOF/UNDEFINED, so getLineNumber() reports
        // the internal counter (1, for the single CRLF) plus 1
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadIntoBufferWithOffset() throws IOException {
        final ExtendedBufferedReader br = createReader("abcdefg");
        final char[] buf = new char[5];
        final int len = br.read(buf, 2, 3);
        assertEquals(3, len);
        assertEquals('a', buf[2]);
        assertEquals('b', buf[3]);
        assertEquals('c', buf[4]);
        assertEquals('c', br.getLastChar());
        assertEquals(3, br.getPosition());
        br.close();
    }

    @Test
    void testMarkSupported() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        assertTrue(br.markSupported());
        br.close();
    }
}
