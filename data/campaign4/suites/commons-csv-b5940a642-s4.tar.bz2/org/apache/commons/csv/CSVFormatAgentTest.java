package org.apache.commons.csv;

import java.io.File;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CSVFormatAgentTest {

    // ---- Predefined formats: field values per documented Builder settings ----

    @Test
    public void testDefaultFieldValues() {
        CSVFormat f = CSVFormat.DEFAULT;
        assertEquals(",", f.getDelimiterString());
        assertEquals(',', f.getDelimiter());
        assertArrayEquals(new char[] { ',' }, f.getDelimiterCharArray());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertTrue(f.isQuoteCharacterSet());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
        assertNull(f.getEscapeCharacter());
        assertEquals(0, f.getEscapeChar());
        assertFalse(f.isEscapeCharacterSet());
        assertNull(f.getQuoteMode());
        assertNull(f.getNullString());
        assertFalse(f.isNullStringSet());
        assertNull(f.getHeader());
        assertNull(f.getHeaderComments());
        assertNull(f.getCommentMarker());
        assertFalse(f.isCommentMarkerSet());
        assertFalse(f.getAllowMissingColumnNames());
        assertFalse(f.getTrailingData());
        assertFalse(f.getTrailingDelimiter());
        assertFalse(f.getTrim());
        assertFalse(f.getLenientEof());
        assertFalse(f.getSkipHeaderRecord());
        assertFalse(f.getIgnoreHeaderCase());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getAutoFlush());
        assertTrue(f.getMaxRows() <= 0);
    }

    @Test
    public void testExcelFieldValues() {
        CSVFormat f = CSVFormat.EXCEL;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
        assertFalse(f.getIgnoreEmptyLines());
        assertTrue(f.getAllowMissingColumnNames());
        assertTrue(f.getTrailingData());
        assertTrue(f.getLenientEof());
    }

    @Test
    public void testRfc4180FieldValues() {
        CSVFormat f = CSVFormat.RFC4180;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testTdfFieldValues() {
        CSVFormat f = CSVFormat.TDF;
        assertEquals("\t", f.getDelimiterString());
        assertTrue(f.getIgnoreSurroundingSpaces());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
    }

    @Test
    public void testMySqlFieldValues() {
        CSVFormat f = CSVFormat.MYSQL;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertEquals('\\', f.getEscapeChar());
        assertTrue(f.isEscapeCharacterSet());
        assertFalse(f.getIgnoreEmptyLines());
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals("\\N", f.getNullString());
        assertTrue(f.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testOracleFieldValues() {
        CSVFormat f = CSVFormat.ORACLE;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\\N", f.getNullString());
        assertTrue(f.getTrim());
        assertEquals(System.lineSeparator(), f.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testPostgresqlCsvFieldValues() {
        CSVFormat f = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", f.getDelimiterString());
        assertNull(f.getEscapeCharacter());
        assertFalse(f.isEscapeCharacterSet());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals("", f.getNullString());
        assertTrue(f.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testPostgresqlTextFieldValues() {
        CSVFormat f = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertFalse(f.getIgnoreEmptyLines());
        assertNull(f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals("\\N", f.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    @Test
    public void testMongoDbCsvFieldValues() {
        CSVFormat f = CSVFormat.MONGODB_CSV;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFieldValues() {
        CSVFormat f = CSVFormat.MONGODB_TSV;
        assertEquals("\t", f.getDelimiterString());
        assertEquals(Character.valueOf('"'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());
        assertFalse(f.getSkipHeaderRecord());
    }

    @Test
    public void testInformixUnloadFieldValues() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", f.getDelimiterString());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
    }

    @Test
    public void testInformixUnloadCsvFieldValues() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", f.getDelimiterString());
        assertFalse(f.isEscapeCharacterSet());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\n", f.getRecordSeparator());
    }

    // ---- newFormat ----

    @Test
    public void testNewFormatBasic() {
        CSVFormat f = CSVFormat.newFormat(';');
        assertEquals(";", f.getDelimiterString());
        assertNull(f.getQuoteCharacter());
        assertNull(f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
        assertNull(f.getHeader());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // ---- valueOf ----

    @Test
    public void testValueOfPredefinedNames() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
        assertEquals(CSVFormat.ORACLE, CSVFormat.valueOf("Oracle"));
        assertEquals(CSVFormat.POSTGRESQL_CSV, CSVFormat.valueOf("PostgreSQLCsv"));
        assertEquals(CSVFormat.POSTGRESQL_TEXT, CSVFormat.valueOf("PostgreSQLText"));
        assertEquals(CSVFormat.MONGODB_CSV, CSVFormat.valueOf("MongoDBCsv"));
        assertEquals(CSVFormat.MONGODB_TSV, CSVFormat.valueOf("MongoDBTsv"));
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.valueOf("InformixUnload"));
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.valueOf("InformixUnloadCsv"));
    }

    @Test
    public void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.valueOf("NotAPredefinedFormat");
            }
        });
    }

    @Test
    public void testValueOfNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.valueOf(null);
            }
        });
    }

    // ---- builder() / Builder.create / Builder.get / build / copy / clone ----

    @Test
    public void testBuilderCreateEqualsDefault() {
        CSVFormat created = CSVFormat.Builder.create().get();
        assertEquals(CSVFormat.DEFAULT, created);
        assertEquals(CSVFormat.DEFAULT.hashCode(), created.hashCode());
    }

    @Test
    public void testBuilderCreateFromFormatPreservesSettings() {
        CSVFormat copyOfExcel = CSVFormat.Builder.create(CSVFormat.EXCEL).get();
        assertEquals(CSVFormat.EXCEL, copyOfExcel);
    }

    @Test
    public void testBuilderRoundTripPreservesSettings() {
        CSVFormat custom = CSVFormat.DEFAULT.builder().setDelimiter(';').setQuote('\'').setNullString("NULL").get();
        CSVFormat roundTrip = custom.builder().get();
        assertEquals(custom, roundTrip);
    }

    @Test
    public void testBuilderImmutabilityOfAlreadyBuiltFormat() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat.Builder builder = original.builder();
        builder.setDelimiter(';');
        CSVFormat changed = builder.get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", changed.getDelimiterString());
    }

    @Test
    public void testBuildDeprecatedAliasMatchesGet() {
        CSVFormat viaBuild = CSVFormat.DEFAULT.builder().build();
        CSVFormat viaGet = CSVFormat.DEFAULT.builder().get();
        assertEquals(viaGet, viaBuild);
    }

    @Test
    public void testCopyInstanceEqualsOriginal() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
        assertEquals(CSVFormat.DEFAULT.hashCode(), copy.hashCode());
    }

    @Test
    public void testCopyStaticNullSafe() {
        assertNull(CSVFormat.copy(null));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.copy(CSVFormat.DEFAULT));
    }

    @Test
    public void testCloneNullSafe() {
        assertNull(CSVFormat.clone((String[]) null));
        String[] source = { "a", "b" };
        String[] cloned = CSVFormat.clone(source);
        assertArrayEquals(source, cloned);
        assertNotSame(source, cloned);
    }

    // ---- equals / hashCode / toString ----

    @Test
    public void testEqualsReflexive() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
    }

    @Test
    public void testEqualsDistinctPredefinedFormatsNotEqual() {
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.EXCEL);
        assertNotEquals(CSVFormat.MYSQL, CSVFormat.ORACLE);
    }

    @Test
    public void testEqualsAgainstNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testEqualsForEquivalentlyBuiltFormats() {
        CSVFormat a = CSVFormat.newFormat(',').builder().setQuote('"').get();
        CSVFormat b = CSVFormat.newFormat(',').builder().setQuote('"').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDiffersWhenOneFieldDiffers() {
        CSVFormat a = CSVFormat.newFormat(',').builder().setQuote('"').get();
        CSVFormat b = CSVFormat.newFormat(',').builder().setQuote('\'').get();
        assertNotEquals(a, b);
    }

    @Test
    public void testToStringIsConsistentForEqualInstances() {
        String s1 = CSVFormat.DEFAULT.toString();
        String s2 = CSVFormat.DEFAULT.copy().toString();
        assertNotNull(s1);
        assertEquals(s1, s2);
    }

    // ---- header / headerComments defensive copies ----

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        String[] h1 = f.getHeader();
        assertArrayEquals(new String[] { "A", "B" }, h1);
        h1[0] = "Z";
        String[] h2 = f.getHeader();
        assertArrayEquals(new String[] { "A", "B" }, h2);
    }

    @Test
    public void testSetHeaderKeepsCopyOfInputArray() {
        String[] header = { "A", "B" };
        CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setHeader(header);
        header[0] = "MUTATED";
        CSVFormat f = builder.get();
        assertArrayEquals(new String[] { "A", "B" }, f.getHeader());
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        String[] c1 = f.getHeaderComments();
        assertArrayEquals(new String[] { "c1", "c2" }, c1);
        c1[0] = "MUTATED";
        assertArrayEquals(new String[] { "c1", "c2" }, f.getHeaderComments());
    }

    @Test
    public void testHeaderAndHeaderCommentsNullByDefault() {
        assertNull(CSVFormat.DEFAULT.getHeader());
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // ---- individual setter/getter round trips via Builder ----

    @Test
    public void testCommentMarkerSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(f.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), f.getCommentMarker());
        CSVFormat cleared = f.builder().setCommentMarker((Character) null).get();
        assertFalse(cleared.isCommentMarkerSet());
        assertNull(cleared.getCommentMarker());
    }

    @Test
    public void testEscapeCharacterSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertTrue(f.isEscapeCharacterSet());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertEquals('\\', f.getEscapeChar());
        CSVFormat cleared = CSVFormat.MYSQL.builder().setEscape((Character) null).get();
        assertFalse(cleared.isEscapeCharacterSet());
        assertNull(cleared.getEscapeCharacter());
        assertEquals(0, cleared.getEscapeChar());
    }

    @Test
    public void testNullStringSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(f.isNullStringSet());
        assertEquals("NULL", f.getNullString());
    }

    @Test
    public void testQuoteCharacterSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(f.isQuoteCharacterSet());
        assertNull(f.getQuoteCharacter());
        CSVFormat withQuote = f.builder().setQuote('\'').get();
        assertTrue(withQuote.isQuoteCharacterSet());
        assertEquals(Character.valueOf('\''), withQuote.getQuoteCharacter());
    }

    @Test
    public void testMaxRowsSetAndGet() {
        assertTrue(CSVFormat.DEFAULT.getMaxRows() <= 0);
        CSVFormat f = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, f.getMaxRows());
    }

    @Test
    public void testAutoFlushSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
        CSVFormat f = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        assertTrue(f.getAutoFlush());
    }

    @Test
    public void testLenientEofSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getLenientEof());
        CSVFormat f = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        assertTrue(f.getLenientEof());
    }

    @Test
    public void testTrailingDataSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getTrailingData());
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        assertTrue(f.getTrailingData());
    }

    @Test
    public void testTrailingDelimiterSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        assertTrue(f.getTrailingDelimiter());
    }

    @Test
    public void testSkipHeaderRecordSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        CSVFormat f = CSVFormat.DEFAULT.builder().setSkipHeaderRecord(true).get();
        assertTrue(f.getSkipHeaderRecord());
    }

    @Test
    public void testIgnoreHeaderCaseSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
        CSVFormat f = CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(true).get();
        assertTrue(f.getIgnoreHeaderCase());
    }

    @Test
    public void testIgnoreSurroundingSpacesSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
        CSVFormat f = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testIgnoreEmptyLinesSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        assertFalse(f.getIgnoreEmptyLines());
    }

    @Test
    public void testTrimSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertTrue(f.getTrim());
    }

    @Test
    public void testAllowMissingColumnNamesSetAndGet() {
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        CSVFormat f = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).get();
        assertTrue(f.getAllowMissingColumnNames());
    }

    @Test
    public void testDuplicateHeaderModeSetAndGet() {
        CSVFormat f = CSVFormat.newFormat(',').builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, f.getDuplicateHeaderMode());
    }

    @Test
    public void testDelimiterStringMultiCharSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals("::", f.getDelimiterString());
        assertArrayEquals(new char[] { ':', ':' }, f.getDelimiterCharArray());
        assertEquals(':', f.getDelimiter());
    }

    @Test
    public void testQuoteModeSetAndGet() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL_NON_NULL).get();
        assertEquals(QuoteMode.ALL_NON_NULL, f.getQuoteMode());
    }

    // ---- format(Object...) ----

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatNoValuesIsEmpty() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("x,\"a,b\",y", CSVFormat.DEFAULT.format("x", "a,b", "y"));
    }

    @Test
    public void testFormatEscapesEmbeddedQuoteCharacter() {
        assertEquals("\"a\"\"b\"", CSVFormat.DEFAULT.format("a\"b"));
    }

    @Test
    public void testFormatWritesNullStringForNullValue() {
        CSVFormat f = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL,x", f.format((Object) null, "x"));
    }

    // ---- print(Object, Appendable, boolean) ----

    @Test
    public void testPrintValueAsNewRecordWritesPlainValue() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("abc", sb, true);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testPrintValueNotNewRecordPrependsDelimiter() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("abc", sb, false);
        assertEquals(",abc", sb.toString());
    }

    @Test
    public void testPrintTrimsValueWhenTrimEnabled() throws Exception {
        CSVFormat f = CSVFormat.DEFAULT.builder().setTrim(true).get();
        StringBuilder sb = new StringBuilder();
        f.print(" hello ", sb, true);
        assertEquals("hello", sb.toString());
    }

    // ---- println(Appendable) ----

    @Test
    public void testPrintlnWritesRecordSeparatorOnly() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setRecordSeparator("\n").get();
        StringBuilder sb = new StringBuilder();
        f.println(sb);
        assertEquals("\n", sb.toString());
    }

    @Test
    public void testPrintlnWritesTrailingDelimiterThenRecordSeparator() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setRecordSeparator("\n").setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        f.println(sb);
        assertEquals(",\n", sb.toString());
    }

    @Test
    public void testPrintlnWritesNothingWhenNeitherSet() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',');
        StringBuilder sb = new StringBuilder();
        f.println(sb);
        assertEquals("", sb.toString());
    }

    // ---- printRecord(Appendable, Object...) ----

    @Test
    public void testPrintRecordWritesValuesAndRecordSeparator() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setRecordSeparator("\n").get();
        StringBuilder sb = new StringBuilder();
        f.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\n", sb.toString());
    }

    @Test
    public void testPrintRecordWithNoValuesWritesOnlyRecordSeparator() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setRecordSeparator("\n").get();
        StringBuilder sb = new StringBuilder();
        f.printRecord(sb);
        assertEquals("\n", sb.toString());
    }

    @Test
    public void testPrintRecordWithTrailingDelimiter() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setRecordSeparator("\n").setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        f.printRecord(sb, "a", "b");
        assertEquals("a,b,\n", sb.toString());
    }

    // ---- print(Appendable) / print(File, Charset) / print(Path, Charset) / printer() ----

    @Test
    public void testPrintAppendableReturnsPrinterAndWritesHeaderImmediately() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setHeader("A", "B").setRecordSeparator("\n").get();
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = f.print(sb);
        assertNotNull(printer);
        assertEquals("A,B\n", sb.toString());
    }

    @Test
    public void testPrintFileWritesHeaderImmediately() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setHeader("A", "B").setRecordSeparator("\n").get();
        File file = File.createTempFile("CSVFormatAgentTest", ".csv");
        try {
            CSVPrinter printer = f.print(file, StandardCharsets.UTF_8);
            printer.close();
            String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            assertEquals("A,B\n", content);
        } finally {
            file.delete();
        }
    }

    @Test
    public void testPrintPathWritesHeaderImmediately() throws Exception {
        CSVFormat f = CSVFormat.newFormat(',').builder().setHeader("A", "B").setRecordSeparator("\n").get();
        Path path = Files.createTempFile("CSVFormatAgentTest", ".csv");
        try {
            CSVPrinter printer = f.print(path, StandardCharsets.UTF_8);
            printer.close();
            String content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            assertEquals("A,B\n", content);
        } finally {
            Files.deleteIfExists(path);
        }
    }

    @Test
    public void testPrinterReturnsNonNullPrinter() throws Exception {
        CSVPrinter printer = CSVFormat.DEFAULT.printer();
        assertNotNull(printer);
    }

    // ---- parse(Reader) ----

    @Test
    public void testParseReturnsNonNullParser() throws Exception {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b\r\n"));
        assertNotNull(parser);
    }

    // ---- deprecated with* bridge methods ----

    @Test
    public void testWithDelimiterDeprecatedBuildsNewImmutableFormat() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat changed = original.withDelimiter(';');
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", changed.getDelimiterString());
    }

    @Test
    public void testWithDelimiterDeprecatedRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithEscapeDeprecatedRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withEscape('\r');
            }
        });
    }

    @Test
    public void testWithQuoteDeprecatedRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withQuote('\n');
            }
        });
    }

    @Test
    public void testWithCommentMarkerDeprecatedRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withCommentMarker('\r');
            }
        });
    }

    @Test
    public void testWithRecordSeparatorDeprecatedRejectsInvalidSeparator() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withRecordSeparator("XYZ");
            }
        });
    }

    @Test
    public void testWithRecordSeparatorDeprecatedAcceptsValidSeparator() {
        CSVFormat f = CSVFormat.DEFAULT.withRecordSeparator("\n");
        assertEquals("\n", f.getRecordSeparator());
    }

    @Test
    public void testWithHeaderDeprecatedVarargsSetsHeader() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader("name", "email");
        assertArrayEquals(new String[] { "name", "email" }, f.getHeader());
    }

    @Test
    public void testWithAllowMissingColumnNamesDeprecatedNoArgSetsTrue() {
        CSVFormat f = CSVFormat.DEFAULT.withAllowMissingColumnNames();
        assertTrue(f.getAllowMissingColumnNames());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesDeprecatedNoArgSetsTrue() {
        CSVFormat f = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces();
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithFirstRecordAsHeaderDeprecatedSetsHeaderAndSkip() {
        CSVFormat f = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], f.getHeader());
        assertTrue(f.getSkipHeaderRecord());
    }

    @Test
    public void testGetDelimiterDeprecatedReturnsFirstCharacter() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
    }

    @Test
    public void testGetAllowDuplicateHeaderNamesDeprecatedReflectsAllowAllMode() {
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
    }
}
