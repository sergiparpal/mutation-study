/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetWithMultipleOptions() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalEntityWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#65;"));
    }

    @Test
    void testHexEntityLowerXWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#x41;"));
    }

    @Test
    void testHexEntityUpperXWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#X41;"));
    }

    @Test
    void testDecimalEntityMissingSemicolonDefaultIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#65 rest";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testDecimalEntityMissingSemicolonOptional() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A rest", neu.translate("&#65 rest"));
    }

    @Test
    void testDecimalEntityMissingSemicolonErrors() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new ThrowingCall(neu, "&#65 rest"));
        assertEquals("Semi-colon required at end of numeric entity", ex.getMessage());
    }

    @Test
    void testNotAnEntityPlainAmpersand() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test &", neu.translate("Test &"));
    }

    @Test
    void testTrailingHashOnly() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test &#", neu.translate("Test &#"));
    }

    @Test
    void testTrailingLowerXOnly() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test &#x", neu.translate("Test &#x"));
    }

    @Test
    void testTrailingUpperXOnly() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test &#X", neu.translate("Test &#X"));
    }

    @Test
    void testSupplementaryCharacterUnescaping() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#68642;";
        final String expected = "𐰢";
        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testNonNumericEntityReturnsZeroAndWritesNothing() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#abc;", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testEntityValueAboveMaxCodePointReturnsZero() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final long tooLarge = ((long) Character.MAX_CODE_POINT) + 1L;
        final String input = "&#" + tooLarge + ";";
        final int consumed = neu.translate(input, 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateAtNonZeroIndexReturnsLengthConsumed() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final String input = "xx&#65;";
        final int consumed = neu.translate(input, 2, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateReturnsZeroWhenCharAtIndexIsNotAmpersand() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("abc", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateReturnsZeroWhenNotEnoughRoomAfterAmpersandHash() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        // "&#" at the very end: index < seqEnd - 2 fails since seqEnd - index == 2
        final int consumed = neu.translate("a&#", 1, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testHexOnlyXWithNothingAfterReturnsZero() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#x", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testZeroCodePointEntity() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        assertEquals("\u0000", neu.translate("&#0;"));
    }

    /**
     * Avoids lambdas (restricted syntax) while still exercising
     * {@link NumericEntityUnescaper#translate(CharSequence)}.
     */
    private static final class ThrowingCall implements org.junit.jupiter.api.function.Executable {
        private final NumericEntityUnescaper unescaper;
        private final String input;

        ThrowingCall(final NumericEntityUnescaper unescaper, final String input) {
            this.unescaper = unescaper;
            this.input = input;
        }

        @Override
        public void execute() throws Throwable {
            unescaper.translate(input);
        }
    }
}
