/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * Simple {@link FormatFactory} that upper-cases its input, used to exercise the
     * custom format registry.
     */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new Format() {
                private static final long serialVersionUID = 1L;

                @Override
                public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
                    return toAppendTo.append(String.valueOf(obj).toUpperCase());
                }

                @Override
                public Object parseObject(final String source, final ParsePosition pos) {
                    return source;
                }
            };
        }
    }

    private static Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        return registry;
    }

    @Test
    void testDefaultLocaleConstructor() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("Hello, World!", emf.format(new Object[] { "World" }));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    @Test
    void testLocaleConstructor() {
        final ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number,0.0}", Locale.US);
        final ExtendedMessageFormat de = new ExtendedMessageFormat("{0,number,0.0}", Locale.GERMANY);
        assertEquals("1.5", us.format(new Object[] { Double.valueOf(1.5d) }));
        assertEquals("1,5", de.format(new Object[] { Double.valueOf(1.5d) }));
        assertEquals(Locale.US, us.getLocale());
        assertEquals(Locale.GERMANY, de.getLocale());
    }

    @Test
    void testRegistryConstructorDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testRegistryConstructorWithLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
        assertEquals(Locale.US, emf.getLocale());
    }

    @Test
    void testCustomFormatPreservedInToPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("pre {0,upper} post", upperRegistry());
        assertEquals("pre {0,upper} post", emf.toPattern());
        assertEquals("pre XYZ post", emf.format(new Object[] { "xyz" }));
    }

    @Test
    void testUnknownRegistryNameNotHandledByBaseFormatThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknownFormat}", upperRegistry());
            }
        });
    }

    @Test
    void testNullRegistryUsesPlainMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, null);
        assertEquals("abc", emf.format(new Object[] { "abc" }));
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    void testQuotedTextPreserved() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0}", upperRegistry());
        assertEquals("it's World", emf.format(new Object[] { "World" }));
    }

    @Test
    void testEqualsAndHashCode() {
        final Map<String, FormatFactory> sharedRegistry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US, sharedRegistry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US, sharedRegistry);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());

        final ExtendedMessageFormat differentPattern = new ExtendedMessageFormat("{0}!", Locale.US, sharedRegistry);
        assertNotEquals(a, differentPattern);

        final ExtendedMessageFormat differentLocale = new ExtendedMessageFormat("{0}", Locale.GERMANY, sharedRegistry);
        assertNotEquals(a, differentLocale);

        assertNotEquals(a, "not a format");
        assertFalse(a.equals(null));
    }

    @Test
    void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, null);
            }
        });
    }

    @Test
    void testSetFormatByIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, null);
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[0]);
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[0]);
            }
        });
    }

    @Test
    void testUnterminatedQuotedString() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("'abc", upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated quoted string"));
    }

    @Test
    void testUnterminatedFormatElementAfterIndex() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testUnterminatedFormatDescription() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testInvalidFormatArgumentIndex() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{a}", upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    void testUnknownFormatTypeWithoutRegistryThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,notARealFormat}");
            }
        });
    }

    @Test
    void testNullPatternThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    void testApplyPatternAfterConstructionUpdatesState() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertEquals("{0}", emf.toPattern());
        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("", upperRegistry());
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    @Test
    void testMultipleArgumentsWithMixedFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}-{1}-{0,upper}", upperRegistry());
        assertEquals("AB-cd-AB", emf.format(new Object[] { "ab", "cd" }));
        assertNotNull(emf.toPattern());
    }
}
