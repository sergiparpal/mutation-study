package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class StringsAgentTest {

    // --- singletons ---

    @Test
    public void testSingletonsCaseSensitivity() {
        assertNotNull(Strings.CS);
        assertNotNull(Strings.CI);
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // --- compare ---

    @Test
    public void testCompareCaseSensitive() {
        assertEquals(0, Strings.CS.compare(null, null));
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "b") < 0);
        assertTrue(Strings.CS.compare("b", "a") > 0);
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    public void testCompareCaseInsensitive() {
        assertEquals(0, Strings.CI.compare(null, null));
        assertTrue(Strings.CI.compare(null, "a") < 0);
        assertTrue(Strings.CI.compare("a", null) > 0);
        assertEquals(0, Strings.CI.compare("abc", "abc"));
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "b") < 0);
        assertTrue(Strings.CI.compare("b", "a") > 0);
        assertTrue(Strings.CI.compare("a", "B") < 0);
        assertTrue(Strings.CI.compare("A", "b") < 0);
        assertTrue(Strings.CI.compare("ab", "ABC") < 0);
    }

    // --- isNullIsLess (package-private) ---

    @Test
    public void testIsNullIsLessDefaults() {
        assertTrue(Strings.CS.isNullIsLess());
        assertTrue(Strings.CI.isNullIsLess());
    }

    // --- initialCapacity (package-private static) ---

    @Test
    public void testInitialCapacityNoGrowth() {
        assertEquals(10, Strings.initialCapacity(10, 2, 2, -1));
        assertEquals(100, Strings.initialCapacity(100, 3, 3, -1));
        assertEquals(0, Strings.initialCapacity(0, 0, 0, 0));
    }

    @Test
    public void testInitialCapacityNeverNegative() {
        int result = Strings.initialCapacity(1, 1000000, 0, -1);
        assertEquals(0, result);
    }

    @Test
    public void testInitialCapacityClampedBelowIntMax() {
        int result = Strings.initialCapacity(0, 0, Integer.MAX_VALUE, -1);
        assertTrue(result > 0);
        assertTrue(result < Integer.MAX_VALUE);
    }

    // --- contains ---

    @Test
    public void testContainsCaseSensitive() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
    }

    @Test
    public void testContainsCaseInsensitive() {
        assertFalse(Strings.CI.contains(null, "a"));
        assertFalse(Strings.CI.contains("a", null));
        assertTrue(Strings.CI.contains("", ""));
        assertTrue(Strings.CI.contains("abc", ""));
        assertTrue(Strings.CI.contains("abc", "a"));
        assertFalse(Strings.CI.contains("abc", "z"));
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
    }

    // --- containsAny ---

    @Test
    public void testContainsAnyCaseSensitive() {
        assertFalse(Strings.CS.containsAny(null, "x"));
        assertFalse(Strings.CS.containsAny("", "x"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc", new CharSequence[0]));
        assertTrue(Strings.CS.containsAny("abcd", "ab", null));
        assertTrue(Strings.CS.containsAny("abcd", "ab", "cd"));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAnyCaseInsensitive() {
        assertFalse(Strings.CI.containsAny(null, "x"));
        assertFalse(Strings.CI.containsAny("", "x"));
        assertFalse(Strings.CI.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CI.containsAny("abc", new CharSequence[0]));
        assertTrue(Strings.CI.containsAny("abcd", "ab", null));
        assertTrue(Strings.CI.containsAny("abc", "D", "ABC"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    // --- endsWith / endsWithAny ---

    @Test
    public void testEndsWithCaseSensitive() {
        assertTrue(Strings.CS.endsWith(null, null));
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "cde"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithCaseInsensitive() {
        assertTrue(Strings.CI.endsWith(null, null));
        assertFalse(Strings.CI.endsWith(null, "def"));
        assertFalse(Strings.CI.endsWith("abcdef", null));
        assertTrue(Strings.CI.endsWith("abcdef", "def"));
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    @Test
    public void testEndsWithAny() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, new String[] {"abc"}));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.endsWithAny("abcxyz", new String[] {""}));
        assertTrue(Strings.CS.endsWithAny("abcxyz", new String[] {"xyz"}));
        assertTrue(Strings.CS.endsWithAny("abcxyz", new String[] {null, "xyz", "abc"}));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // --- equals (CharSequence,CharSequence) and (String,String) ---

    @Test
    public void testEqualsCharSequenceCaseSensitive() {
        CharSequence cs1 = "abc";
        CharSequence cs2 = "ABC";
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, cs1));
        assertFalse(Strings.CS.equals(cs1, (CharSequence) null));
        assertTrue(Strings.CS.equals(cs1, (CharSequence) "abc"));
        assertFalse(Strings.CS.equals(cs1, cs2));
    }

    @Test
    public void testEqualsCharSequenceCaseInsensitive() {
        CharSequence cs1 = "abc";
        CharSequence cs2 = "ABC";
        assertTrue(Strings.CI.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CI.equals((CharSequence) null, cs1));
        assertFalse(Strings.CI.equals(cs1, (CharSequence) null));
        assertTrue(Strings.CI.equals(cs1, (CharSequence) "abc"));
        assertTrue(Strings.CI.equals(cs1, cs2));
    }

    @Test
    public void testEqualsStringCaseSensitive() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsStringCaseInsensitive() {
        assertTrue(Strings.CI.equals((String) null, (String) null));
        assertFalse(Strings.CI.equals((String) null, "abc"));
        assertFalse(Strings.CI.equals("abc", (String) null));
        assertTrue(Strings.CI.equals("abc", "abc"));
        assertTrue(Strings.CI.equals("abc", "ABC"));
    }

    // --- equalsAny ---

    @Test
    public void testEqualsAnyCaseSensitive() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CS.equalsAny(null, null, null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAnyCaseInsensitive() {
        assertFalse(Strings.CI.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CI.equalsAny(null, null, null));
        assertFalse(Strings.CI.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CI.equalsAny("abc", null, "def"));
        assertTrue(Strings.CI.equalsAny("abc", "abc", "def"));
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // --- indexOf(CharSequence, CharSequence) ---

    @Test
    public void testIndexOfTwoArgCaseSensitive() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(-1, Strings.CS.indexOf("", "a"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", ""));
    }

    @Test
    public void testIndexOfTwoArgCaseInsensitive() {
        assertEquals(-1, Strings.CI.indexOf(null, "a"));
        assertEquals(-1, Strings.CI.indexOf("a", null));
        assertEquals(0, Strings.CI.indexOf("", ""));
        assertEquals(0, Strings.CI.indexOf(" ", " "));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "ab"));
    }

    // --- indexOf(CharSequence, CharSequence, int) ---

    @Test
    public void testIndexOfThreeArgCaseSensitive() {
        assertEquals(-1, Strings.CS.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", null, 0));
        assertEquals(0, Strings.CS.indexOf("", "", 0));
        assertEquals(-1, Strings.CS.indexOf("", "a", 0));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a", 0));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", 0));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfThreeArgCaseInsensitive() {
        assertEquals(-1, Strings.CI.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CI.indexOf("a", null, 0));
        assertEquals(0, Strings.CI.indexOf("", "", 0));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
    }

    // --- lastIndexOf(CharSequence, CharSequence) ---

    @Test
    public void testLastIndexOfTwoArgCaseSensitive() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfTwoArgCaseInsensitive() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CI.lastIndexOf("a", null));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B"));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB"));
    }

    // --- lastIndexOf(CharSequence, CharSequence, int) ---

    @Test
    public void testLastIndexOfThreeArgCaseSensitive() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null, 0));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    public void testLastIndexOfThreeArgCaseInsensitive() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("a", null, 0));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 8));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // --- appendIfMissing ---

    @Test
    public void testAppendIfMissingCaseSensitive() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));

        assertNull(Strings.CS.appendIfMissing(null, null, (CharSequence[]) null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null, (CharSequence[]) null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz", (CharSequence[]) null));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", new CharSequence[] {null}));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz", "mno"));
        assertEquals("abcMNOxyz", Strings.CS.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissingCaseInsensitive() {
        assertNull(Strings.CI.appendIfMissing(null, null));
        assertEquals("abc", Strings.CI.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CI.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
    }

    // --- prependIfMissing ---

    @Test
    public void testPrependIfMissingCaseSensitive() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));

        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", new CharSequence[] {null}));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", "xyz", ""));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", "mno"));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
        assertEquals("xyzMNOabc", Strings.CS.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingCaseInsensitive() {
        assertNull(Strings.CI.prependIfMissing(null, null));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
        assertEquals("MNOabc", Strings.CI.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    // --- remove ---

    @Test
    public void testRemoveCaseSensitive() {
        assertNull(Strings.CS.remove(null, "a"));
        assertEquals("", Strings.CS.remove("", "a"));
        assertEquals("abc", Strings.CS.remove("abc", null));
        assertEquals("abc", Strings.CS.remove("abc", ""));
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    public void testRemoveCaseInsensitive() {
        assertNull(Strings.CI.remove(null, "a"));
        assertEquals("", Strings.CI.remove("", "a"));
        assertEquals("abc", Strings.CI.remove("abc", null));
        assertEquals("abc", Strings.CI.remove("abc", ""));
        assertEquals("qd", Strings.CI.remove("queued", "ue"));
        assertEquals("queued", Strings.CI.remove("queued", "zz"));
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    // --- removeEnd ---

    @Test
    public void testRemoveEndCaseSensitive() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEndCaseInsensitive() {
        assertNull(Strings.CI.removeEnd(null, "x"));
        assertEquals("", Strings.CI.removeEnd("", "x"));
        assertEquals("abc", Strings.CI.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CI.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CI.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CI.removeEnd("abc", ""));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // --- removeStart ---

    @Test
    public void testRemoveStartCaseSensitive() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStartCaseInsensitive() {
        assertNull(Strings.CI.removeStart(null, "x"));
        assertEquals("", Strings.CI.removeStart("", "x"));
        assertEquals("abc", Strings.CI.removeStart("abc", null));
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
        assertEquals("domain.com", Strings.CI.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CI.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CI.removeStart("abc", ""));
    }

    // --- replace(text, search, replacement) ---

    @Test
    public void testReplaceCaseSensitive() {
        assertNull(Strings.CS.replace(null, "a", "z"));
        assertEquals("", Strings.CS.replace("", "a", "z"));
        assertEquals("any", Strings.CS.replace("any", null, "z"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "z"));
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceCaseInsensitive() {
        assertNull(Strings.CI.replace(null, "a", "z"));
        assertEquals("", Strings.CI.replace("", "a", "z"));
        assertEquals("any", Strings.CI.replace("any", null, "z"));
        assertEquals("any", Strings.CI.replace("any", "a", null));
        assertEquals("any", Strings.CI.replace("any", "", "z"));
        assertEquals("aba", Strings.CI.replace("aba", "a", null));
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    // --- replace(text, search, replacement, max) ---

    @Test
    public void testReplaceWithMaxCaseSensitive() {
        assertNull(Strings.CS.replace(null, "a", "z", -1));
        assertEquals("", Strings.CS.replace("", "a", "z", -1));
        assertEquals("any", Strings.CS.replace("any", null, "z", -1));
        assertEquals("any", Strings.CS.replace("any", "a", null, -1));
        assertEquals("any", Strings.CS.replace("any", "", "z", -1));
        assertEquals("any", Strings.CS.replace("any", "a", "z", 0));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CS.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceWithMaxCaseInsensitive() {
        assertNull(Strings.CI.replace(null, "a", "z", -1));
        assertEquals("", Strings.CI.replace("", "a", "z", -1));
        assertEquals("any", Strings.CI.replace("any", null, "z", -1));
        assertEquals("any", Strings.CI.replace("any", "a", null, -1));
        assertEquals("any", Strings.CI.replace("any", "", "z", -1));
        assertEquals("any", Strings.CI.replace("any", "a", "z", 0));
        assertEquals("abaa", Strings.CI.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CI.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CI.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CI.replace("abaa", "A", "z", 1));
        assertEquals("zbza", Strings.CI.replace("abAa", "a", "z", 2));
        assertEquals("zbzz", Strings.CI.replace("abAa", "a", "z", -1));
    }

    // --- replaceOnce ---

    @Test
    public void testReplaceOnceCaseSensitive() {
        assertNull(Strings.CS.replaceOnce(null, "a", "z"));
        assertEquals("", Strings.CS.replaceOnce("", "a", "z"));
        assertEquals("any", Strings.CS.replaceOnce("any", null, "z"));
        assertEquals("any", Strings.CS.replaceOnce("any", "a", null));
        assertEquals("any", Strings.CS.replaceOnce("any", "", "z"));
        assertEquals("aba", Strings.CS.replaceOnce("aba", "a", null));
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceCaseInsensitive() {
        assertNull(Strings.CI.replaceOnce(null, "a", "z"));
        assertEquals("", Strings.CI.replaceOnce("", "a", "z"));
        assertEquals("any", Strings.CI.replaceOnce("any", null, "z"));
        assertEquals("any", Strings.CI.replaceOnce("any", "a", null));
        assertEquals("any", Strings.CI.replaceOnce("any", "", "z"));
        assertEquals("aba", Strings.CI.replaceOnce("aba", "a", null));
        assertEquals("ba", Strings.CI.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CI.replaceOnce("aba", "a", "z"));
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // --- startsWith / startsWithAny ---

    @Test
    public void testStartsWithCaseSensitive() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithCaseInsensitive() {
        assertTrue(Strings.CI.startsWith(null, null));
        assertFalse(Strings.CI.startsWith(null, "abc"));
        assertFalse(Strings.CI.startsWith("abcdef", null));
        assertTrue(Strings.CI.startsWith("abcdef", "abc"));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAnyCaseSensitive() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, new String[] {"abc"}));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.startsWithAny("abcxyz", new String[] {""}));
        assertTrue(Strings.CS.startsWithAny("abcxyz", new String[] {"abc"}));
        assertTrue(Strings.CS.startsWithAny("abcxyz", new String[] {null, "xyz", "abc"}));
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertFalse(Strings.CS.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    @Test
    public void testStartsWithAnyCaseInsensitive() {
        assertFalse(Strings.CI.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CI.startsWithAny(null, new String[] {"aBc"}));
        assertFalse(Strings.CI.startsWithAny("AbCxYz", (CharSequence[]) null));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", new String[] {""}));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", new String[] {"aBc"}));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", new String[] {null, "XyZ", "aBc"}));
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    // --- builder ---

    @Test
    public void testBuilderReturnsUsableInstance() {
        Strings.Builder builder = Strings.builder();
        assertNotNull(builder);
        Strings built = builder.get();
        assertNotNull(built);
    }

    @Test
    public void testBuilderSetIgnoreCaseTrueProducesCaseInsensitive() {
        Strings built = Strings.builder().setIgnoreCase(true).get();
        assertFalse(built.isCaseSensitive());
        assertTrue(built.equals("abc", "ABC"));
    }

    @Test
    public void testBuilderSetIgnoreCaseFalseProducesCaseSensitive() {
        Strings built = Strings.builder().setIgnoreCase(false).get();
        assertTrue(built.isCaseSensitive());
        assertFalse(built.equals("abc", "ABC"));
    }

    @Test
    public void testBuilderSetNullIsLess() {
        Strings nullIsLess = Strings.builder().setNullIsLess(true).get();
        assertTrue(nullIsLess.isNullIsLess());

        Strings nullIsNotLess = Strings.builder().setNullIsLess(false).get();
        assertFalse(nullIsNotLess.isNullIsLess());
    }

    @Test
    public void testSameInstanceIdentity() {
        assertSame(Strings.CS, Strings.CS);
        assertSame(Strings.CI, Strings.CI);
    }
}
