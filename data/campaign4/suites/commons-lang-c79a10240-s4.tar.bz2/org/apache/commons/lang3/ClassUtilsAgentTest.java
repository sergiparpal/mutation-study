package org.apache.commons.lang3;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClassUtilsAgentTest {

    static class Nested {
    }

    private static List<Class<?>> toList(Iterable<Class<?>> iterable) {
        List<Class<?>> list = new ArrayList<Class<?>>();
        Iterator<Class<?>> it = iterable.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list;
    }

    // ---- constants ----

    @Test
    void constants() {
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
    }

    // ---- comparator ----

    @Test
    void comparatorOrdersByName() {
        Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        assertEquals(0, comparator.compare(String.class, String.class));
        assertTrue(comparator.compare(Integer.class, String.class) < 0);
        assertTrue(comparator.compare(String.class, Integer.class) > 0);
    }

    // ---- convertClassesToClassNames ----

    @Test
    void convertClassesToClassNamesNullInput() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    void convertClassesToClassNamesHappyPath() {
        List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        List<String> result = ClassUtils.convertClassesToClassNames(input);
        assertNotSame(input, result);
        assertEquals(2, result.size());
        assertEquals("java.lang.String", result.get(0));
        assertNull(result.get(1));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    void convertClassesToClassNamesRejectsNonClassEntries() {
        List rawList = new ArrayList();
        rawList.add("notAClass");
        final List<Class<?>> badList = rawList;
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.convertClassesToClassNames(badList);
            }
        });
    }

    // ---- convertClassNamesToClasses ----

    @Test
    void convertClassNamesToClassesNullInput() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    void convertClassNamesToClassesHappyPath() {
        List<String> input = new ArrayList<String>();
        input.add("java.lang.String");
        input.add(null);
        input.add("no.such.ClassXyz");
        List<Class<?>> result = ClassUtils.convertClassNamesToClasses(input);
        assertNotSame(input, result);
        assertEquals(3, result.size());
        assertEquals(String.class, result.get(0));
        assertNull(result.get(1));
        assertNull(result.get(2));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    void convertClassNamesToClassesRejectsNonStringEntries() {
        List rawList = new ArrayList();
        rawList.add(Integer.valueOf(1));
        final List<String> badList = rawList;
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.convertClassNamesToClasses(badList);
            }
        });
    }

    // ---- getAbbreviatedName(Class, int) ----

    @Test
    void getAbbreviatedNameClassNullInput() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
    }

    @Test
    void getAbbreviatedNameClassHappyPath() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    void getAbbreviatedNameClassRejectsNonPositiveLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName(String.class, -1);
            }
        });
    }

    // ---- getAbbreviatedName(String, int) ----

    @Test
    void getAbbreviatedNameStringNullOrEmpty() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("", ClassUtils.getAbbreviatedName("", 1));
    }

    @Test
    void getAbbreviatedNameStringExamplesFromJavadoc() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    void getAbbreviatedNameStringRejectsNonPositiveLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
    }

    // ---- getAllInterfaces ----

    @Test
    void getAllInterfacesNullInput() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void getAllInterfacesHappyPath() {
        List<Class<?>> interfaces = ClassUtils.getAllInterfaces(ArrayList.class);
        assertNotNull(interfaces);
        assertTrue(interfaces.contains(List.class));
        assertTrue(interfaces.contains(java.util.Collection.class));
        assertTrue(interfaces.contains(Iterable.class));
        assertTrue(interfaces.contains(java.io.Serializable.class));
        assertTrue(interfaces.contains(Cloneable.class));
        assertTrue(interfaces.contains(java.util.RandomAccess.class));
        // no duplicates
        Set<Class<?>> asSet = new HashSet<Class<?>>(interfaces);
        assertEquals(asSet.size(), interfaces.size());
    }

    // ---- getAllSuperclasses ----

    @Test
    void getAllSuperclassesNullInput() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void getAllSuperclassesHappyPath() {
        List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Integer.class);
        List<Class<?>> expected = new ArrayList<Class<?>>();
        expected.add(Number.class);
        expected.add(Object.class);
        assertEquals(expected, superclasses);
    }

    @Test
    void getAllSuperclassesOfObjectIsEmpty() {
        List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Object.class);
        assertNotNull(superclasses);
        assertTrue(superclasses.isEmpty());
    }

    // ---- getCanonicalName ----

    @Test
    void getCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("java.util.Map.Entry", ClassUtils.getCanonicalName(Map.Entry.class));
    }

    @Test
    void getCanonicalNameClassWithDefault() {
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "N/A"));
    }

    @Test
    void getCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hi"));
    }

    @Test
    void getCanonicalNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hi", "N/A"));
    }

    // ---- getClass ----

    @Test
    void getClassByNameRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void getClassByNameNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("no.such.ClassXyz");
            }
        });
    }

    @Test
    void getClassByNameHappyPath() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    void getClassByNameWithInitializeFlag() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String", false));
    }

    @Test
    void getClassWithClassLoader() throws ClassNotFoundException {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", true));
    }

    @Test
    void getClassRejectsTooManyArrayDimensions() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 300; i++) {
            sb.append('[');
        }
        sb.append('I');
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    void getClassRejectsTooLongName() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    // ---- getComponentType ----

    @Test
    void getComponentTypeHappyPath() {
        Class<String> component = ClassUtils.getComponentType(String[].class);
        assertEquals(String.class, component);
    }

    @Test
    void getComponentTypeNullInput() {
        Class<?> component = ClassUtils.getComponentType(null);
        assertNull(component);
    }

    // ---- getName ----

    @Test
    void getNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("[I", ClassUtils.getName(int[].class));
    }

    @Test
    void getNameClassWithDefault() {
        assertEquals("N/A", ClassUtils.getName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "N/A"));
    }

    @Test
    void getNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    @Test
    void getNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName("hi", "N/A"));
    }

    // ---- getPackageCanonicalName ----

    @Test
    void getPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    void getPackageCanonicalNameObject() {
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hi", "N/A"));
    }

    @Test
    void getPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageCanonicalName("NoPackageClassXyz"));
    }

    // ---- getPackageName ----

    @Test
    void getPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    void getPackageNameObject() {
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageName("hi", "N/A"));
    }

    @Test
    void getPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName("NoPackageClassXyz"));
    }

    // ---- getPublicMethod ----

    @Test
    void getPublicMethodRejectsNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "isEmpty");
            }
        });
    }

    @Test
    void getPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExistAtAll");
            }
        });
    }

    @Test
    void getPublicMethodReturnsInvokableMethodFromPublicClass() throws Exception {
        Set<String> set = Collections.unmodifiableSet(new HashSet<String>());
        Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty");
        assertNotNull(method);
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        Object result = method.invoke(set);
        assertEquals(Boolean.TRUE, result);
    }

    // ---- getShortCanonicalName ----

    @Test
    void getShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
    }

    @Test
    void getShortCanonicalNameObject() {
        assertEquals("N/A", ClassUtils.getShortCanonicalName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hi", "N/A"));
    }

    @Test
    void getShortCanonicalNameStringExamplesFromJavadoc() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("Map.Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getName()));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getCanonicalName()));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils[]"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("int[][]", ClassUtils.getShortCanonicalName("[[I"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("int[]"));
    }

    // ---- getShortClassName ----

    @Test
    void getShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
    }

    @Test
    void getShortClassNameObject() {
        assertEquals("N/A", ClassUtils.getShortClassName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "N/A"));
    }

    @Test
    void getShortClassNameStringInnerClassExampleFromJavadoc() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    // ---- getSimpleName ----

    @Test
    void getSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("Entry", ClassUtils.getSimpleName(Map.Entry.class));
    }

    @Test
    void getSimpleNameClassWithDefault() {
        assertEquals("N/A", ClassUtils.getSimpleName((Class<?>) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName(String.class, "N/A"));
    }

    @Test
    void getSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
        // per javadoc: passing a Class instance delegates to getSimpleName(Class)
        assertEquals("String", ClassUtils.getSimpleName((Object) String.class));
    }

    @Test
    void getSimpleNameObjectWithDefault() {
        assertEquals("N/A", ClassUtils.getSimpleName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName("hi", "N/A"));
    }

    // ---- hierarchy ----

    @Test
    void hierarchyExcludesInterfacesByDefault() {
        List<Class<?>> list = toList(ClassUtils.hierarchy(ArrayList.class));
        assertEquals(ArrayList.class, list.get(0));
        assertEquals(Object.class, list.get(list.size() - 1));
        assertFalse(list.contains(List.class));
    }

    @Test
    void hierarchyIncludeInterfaces() {
        List<Class<?>> list = toList(ClassUtils.hierarchy(ArrayList.class, ClassUtils.Interfaces.INCLUDE));
        assertTrue(list.contains(List.class));
    }

    @Test
    void hierarchyExcludeInterfaces() {
        List<Class<?>> list = toList(ClassUtils.hierarchy(ArrayList.class, ClassUtils.Interfaces.EXCLUDE));
        assertFalse(list.contains(List.class));
    }

    // ---- isAssignable(Class, Class) ----

    @Test
    void isAssignableClassToClass() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, (Class<?>) null));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable(Integer.class, Number.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
    }

    @Test
    void isAssignableClassToClassWithAutoboxingFlag() {
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
        assertTrue(ClassUtils.isAssignable(int.class, long.class, false));
    }

    // ---- isAssignable(Class[], Class...) ----

    @Test
    void isAssignableClassArrayVarargs() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { String.class }, Object.class));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { String.class, Integer.class }, Object.class));
    }

    @Test
    void isAssignableClassArrayToClassArrayWithAutoboxingFlag() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { int.class }, new Class<?>[] { Integer.class }, false));
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { int.class }, new Class<?>[] { Integer.class }, true));
    }

    // ---- isInnerClass ----

    @Test
    void isInnerClassBehavior() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
        assertTrue(ClassUtils.isInnerClass(Nested.class));
    }

    // ---- isPrimitiveOrWrapper ----

    @Test
    void isPrimitiveOrWrapperBehavior() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    // ---- isPrimitiveWrapper ----

    @Test
    void isPrimitiveWrapperBehavior() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    // ---- isPublic ----

    @Test
    void isPublicBehavior() {
        assertTrue(ClassUtils.isPublic(String.class));
        List<?> emptyList = Collections.emptyList();
        assertFalse(ClassUtils.isPublic(emptyList.getClass()));
    }

    @Test
    void isPublicRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    // ---- primitivesToWrappers ----

    @Test
    void primitivesToWrappersNullInput() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    void primitivesToWrappersEmptyInput() {
        Class<?>[] result = ClassUtils.primitivesToWrappers();
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    void primitivesToWrappersHappyPath() {
        Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, null, String.class);
        assertArrayEquals(new Class<?>[] { Integer.class, null, String.class }, result);
    }

    // ---- primitiveToWrapper ----

    @Test
    void primitiveToWrapperBehavior() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    // ---- toClass ----

    @Test
    void toClassNullInput() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    void toClassEmptyInput() {
        Class<?>[] result = ClassUtils.toClass();
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    void toClassHappyPath() {
        Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, result);
    }

    // ---- wrappersToPrimitives ----

    @Test
    void wrappersToPrimitivesNullInput() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    void wrappersToPrimitivesEmptyInput() {
        Class<?>[] result = ClassUtils.wrappersToPrimitives();
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    void wrappersToPrimitivesHappyPath() {
        Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertArrayEquals(new Class<?>[] { int.class, null, null }, result);
    }

    // ---- wrapperToPrimitive ----

    @Test
    void wrapperToPrimitiveBehavior() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }
}
