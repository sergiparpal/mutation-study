/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
@SuppressWarnings("deprecation")
class StrBuilderAgentTest {

    @Test
    void testConstructors() {
        final StrBuilder empty = new StrBuilder();
        assertEquals(0, empty.length());
        assertEquals("", empty.toString());

        final StrBuilder fromNull = new StrBuilder((String) null);
        assertEquals(0, fromNull.length());

        final StrBuilder fromStr = new StrBuilder("abc");
        assertEquals(3, fromStr.length());
        assertEquals("abc", fromStr.toString());

        final StrBuilder withCapacity = new StrBuilder(0);
        assertTrue(withCapacity.capacity() > 0);
    }

    @Test
    void testAppendVariousTypes() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(' ').append(1).append(' ').append(2L).append(' ').append(1.5d).append(' ').append(1.5f);
        assertEquals("true 1 2 1.5 1.5", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.append((String) null);
        assertEquals(0, sb2.length());
        assertEquals("", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.append((Object) null);
        assertEquals("", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.append("abcdef", 1, 3);
        assertEquals("bcd", sb4.toString());
    }

    @Test
    void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals(0, sb.length());

        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());

        sb.append(new char[] {'x', 'y', 'z', 'w'}, 1, 2);
        assertEquals("abcyz", sb.toString());

        try {
            sb.append(new char[] {'a'}, -1, 1);
            throw new AssertionError("expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }

        try {
            sb.append(new char[] {'a'}, 0, 5);
            throw new AssertionError("expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    void testAppendNullTextConfigurable() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
        assertEquals("NULL", sb.getNullText());
    }

    @Test
    void testCharAtSetCharAtBoundaries() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));

        try {
            sb.charAt(-1);
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.charAt(3);
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }

        sb.setCharAt(0, 'z');
        assertEquals("zbc", sb.toString());
        try {
            sb.setCharAt(10, 'x');
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    void testClearAndIsEmpty() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
        sb.clear();
        assertEquals(0, sb.length());
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        assertEquals("", sb.toString());
    }

    @Test
    void testContains() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains('h'));
        assertFalse(sb.contains('z'));
        assertTrue(sb.contains("world"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    void testDeleteFamily() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcdef");
        sb2.delete(1, 100);
        assertEquals("a", sb2.toString());

        try {
            new StrBuilder("abc").delete(-1, 2);
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            new StrBuilder("abc").delete(2, 1);
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }

        final StrBuilder sb3 = new StrBuilder("aabbaabbaa");
        sb3.deleteAll('a');
        assertEquals("bbbb", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("one two one two");
        sb4.deleteAll("one");
        assertEquals(" two  two", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("one two one two");
        sb5.deleteFirst("one");
        assertEquals(" two one two", sb5.toString());

        final StrBuilder sb6 = new StrBuilder("abc");
        sb6.deleteCharAt(1);
        assertEquals("ac", sb6.toString());
        try {
            sb6.deleteCharAt(100);
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    void testStartsWithEndsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
        assertTrue(sb.startsWith(""));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        final StrBuilder sb = new StrBuilder("abcabcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('z'));
        assertEquals(0, sb.indexOf("abc"));
        assertEquals(3, sb.indexOf("abc", 1));
        assertEquals(-1, sb.indexOf("xyz"));

        assertEquals(6, sb.lastIndexOf('a'));
        assertEquals(6, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf("xyz"));
    }

    @Test
    void testInsertVariousTypes() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, "b");
        assertEquals("abc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("ac");
        sb2.insert(1, (String) null);
        assertEquals("ac", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("ac");
        sb3.insert(1, 5);
        assertEquals("a5c", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("ac");
        sb4.insert(1, true);
        assertEquals("atruec", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("ac");
        sb5.insert(1, 'b');
        assertEquals("abc", sb5.toString());

        try {
            sb.insert(-1, "x");
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.insert(100, "x");
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    void testReplaceFamily() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcabc");
        sb2.replaceAll("a", "Z");
        assertEquals("ZbcZbc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abcabc");
        sb3.replaceFirst("a", "Z");
        assertEquals("Zbcabc", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("aabbcc");
        sb4.replaceAll('a', 'z');
        assertEquals("zzbbcc", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("aabbcc");
        sb5.replaceFirst('a', 'z');
        assertEquals("zabbcc", sb5.toString());
    }

    @Test
    void testReverseTrim() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.reverse();
        assertEquals("cba", sb.toString());
        sb.reverse();
        assertEquals("abc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("  abc  ");
        sb2.trim();
        assertEquals("abc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.trim();
        assertEquals("", sb3.toString());
    }

    @Test
    void testLengthSizeCapacitySetLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(6, sb.length());
        assertEquals(6, sb.size());

        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());

        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));

        try {
            sb.setLength(-1);
            throw new AssertionError("expected exception");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    void testEnsureCapacityAndMinimize() {
        final StrBuilder sb = new StrBuilder(5);
        final int initialCapacity = sb.capacity();
        sb.ensureCapacity(1000);
        assertTrue(sb.capacity() >= 1000);

        sb.append("abc");
        sb.ensureCapacity(10);
        assertTrue(sb.capacity() >= 1000);

        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
        assertTrue(initialCapacity > 0);
    }

    @Test
    void testEqualsAndHashCode() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("ABC");

        assertTrue(sb1.equals(sb2));
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((StrBuilder) null));
        assertEquals(sb1.hashCode(), sb2.hashCode());

        assertTrue(sb1.equalsIgnoreCase(sb3));
        try {
            sb1.equalsIgnoreCase(null);
            throw new AssertionError("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // actual behavior: no null guard despite Javadoc claim
        }
    }

    @Test
    void testSubstringLeftRightMid() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
        assertEquals("cd", sb.substring(2, 4));

        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(0));
        assertEquals("abcdef", sb.leftString(100));
        assertEquals("", sb.leftString(-1));

        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("abcdef", sb.rightString(100));

        assertEquals("cd", sb.midString(2, 2));
        assertEquals("abcdef", sb.midString(-5, 100));
        assertEquals("", sb.midString(2, 0));
    }

    @Test
    void testToCharArrayAndGetChars() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] all = sb.toCharArray();
        assertEquals(6, all.length);
        assertEquals('a', all[0]);

        final char[] part = sb.toCharArray(1, 3);
        assertEquals(2, part.length);
        assertEquals('b', part[0]);
        assertEquals('c', part[1]);

        final char[] dest = new char[6];
        sb.getChars(dest);
        assertEquals('a', dest[0]);
        assertEquals('f', dest[5]);
    }

    @Test
    void testAppendPaddingAndFixedWidth() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadLeft(7, 5, '0');
        assertEquals("00007", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendFixedWidthPadRight(7, 5, '0');
        assertEquals("70000", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendFixedWidthPadLeft(123456, 3, '0');
        assertEquals("456", sb4.toString());
    }

    @Test
    void testAppendSeparator() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(",");
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendSeparator(",", 0);
        sb2.append("first");
        sb2.appendSeparator(",", 1);
        sb2.append("second");
        assertEquals("first,second", sb2.toString());
    }

    @Test
    void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, "-");
        assertEquals("a-b-c", sb.toString());
    }

    @Test
    void testCharSequenceInterfaceMethods() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(6, sb.length());
        assertEquals('b', sb.charAt(1));
        final CharSequence sub = sb.subSequence(1, 4);
        assertEquals("bcd", sub.toString());
    }

    @Test
    void testBuild() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.build());
    }

    @Test
    void testAsReaderWriterTokenizer() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());

        final StrBuilder sb2 = new StrBuilder();
        final Writer writer = sb2.asWriter();
        writer.write("xyz");
        assertEquals("xyz", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb3.asTokenizer();
        assertEquals("a", tokenizer.next());
        assertEquals("b", tokenizer.next());
        assertEquals("c", tokenizer.next());
        assertFalse(tokenizer.hasNext());
    }

    @Test
    void testReadFromReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Reader src = new java.io.StringReader("hello");
        final int readCount = sb.readFrom(src);
        assertEquals(5, readCount);
        assertEquals("hello", sb.toString());
    }

    @Test
    void testToStringReturnsNewStringEachTime() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s1 = sb.toString();
        final String s2 = sb.toString();
        assertEquals(s1, s2);
        assertFalse(s1 == s2);
    }

    @Test
    void testSetNullTextEmptyBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    @Test
    void testFluentChaining() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append("a").append("b").append("c");
        assertSame(sb, result);
        assertEquals("abc", sb.toString());
    }
}
