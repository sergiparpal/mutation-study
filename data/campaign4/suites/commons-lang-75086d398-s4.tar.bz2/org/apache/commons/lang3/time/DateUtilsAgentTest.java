package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DateUtilsAgentTest {

    private static Calendar newCal(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date newDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return newCal(year, month, day, hour, minute, second, millis).getTime();
    }

    private static Date newDate(int year, int month, int day) {
        return newDate(year, month, day, 0, 0, 0, 0);
    }

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(1000L * 60L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(1000L * 60L * 60L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(1000L * 60L * 60L * 24L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    public void testRangeAndSemiMonthConstantsAreDistinct() {
        Set<Integer> values = new HashSet<Integer>();
        values.add(DateUtils.SEMI_MONTH);
        values.add(DateUtils.RANGE_WEEK_SUNDAY);
        values.add(DateUtils.RANGE_WEEK_MONDAY);
        values.add(DateUtils.RANGE_WEEK_RELATIVE);
        values.add(DateUtils.RANGE_WEEK_CENTER);
        values.add(DateUtils.RANGE_MONTH_SUNDAY);
        values.add(DateUtils.RANGE_MONTH_MONDAY);
        assertEquals(7, values.size());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testDeprecatedPublicConstructor() {
        DateUtils instance = new DateUtils();
        assertNotNull(instance);
    }

    // ---------------------------------------------------------------
    // addXxx
    // ---------------------------------------------------------------

    @Test
    public void testAddDays() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        long originalMillis = date.getTime();

        Calendar expected = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expected.add(Calendar.DATE, 5);
        Date result = DateUtils.addDays(date, 5);
        assertEquals(expected.getTime(), result);
        assertEquals(originalMillis, date.getTime());
        assertNotSame(date, result);

        Calendar expectedNeg = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        expectedNeg.add(Calendar.DATE, -3);
        assertEquals(expectedNeg.getTime(), DateUtils.addDays(date, -3));

        assertEquals(date.getTime(), DateUtils.addDays(date, 0).getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
    }

    @Test
    public void testAddWeeks() {
        Date date = newDate(2002, Calendar.MARCH, 28);
        Calendar expected = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        expected.add(Calendar.WEEK_OF_YEAR, 2);
        assertEquals(expected.getTime(), DateUtils.addWeeks(date, 2));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addWeeks(null, 1);
            }
        });
    }

    @Test
    public void testAddMonths() {
        Date date = newDate(2002, Calendar.MARCH, 28);
        Calendar expected = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        expected.add(Calendar.MONTH, 1);
        assertEquals(expected.getTime(), DateUtils.addMonths(date, 1));

        Calendar expectedNeg = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        expectedNeg.add(Calendar.MONTH, -4);
        assertEquals(expectedNeg.getTime(), DateUtils.addMonths(date, -4));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMonths(null, 1);
            }
        });
    }

    @Test
    public void testAddYears() {
        Date date = newDate(2002, Calendar.MARCH, 28);
        Calendar expected = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        expected.add(Calendar.YEAR, 3);
        assertEquals(expected.getTime(), DateUtils.addYears(date, 3));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addYears(null, 1);
            }
        });
    }

    @Test
    public void testAddHours() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.addHours(date, 5);
        assertEquals(date.getTime() + 5L * DateUtils.MILLIS_PER_HOUR, result.getTime());

        Date resultNeg = DateUtils.addHours(date, -2);
        assertEquals(date.getTime() - 2L * DateUtils.MILLIS_PER_HOUR, resultNeg.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addHours(null, 1);
            }
        });
    }

    @Test
    public void testAddMinutes() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.addMinutes(date, 90);
        assertEquals(date.getTime() + 90L * DateUtils.MILLIS_PER_MINUTE, result.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMinutes(null, 1);
            }
        });
    }

    @Test
    public void testAddSeconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.addSeconds(date, 125);
        assertEquals(date.getTime() + 125L * DateUtils.MILLIS_PER_SECOND, result.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addSeconds(null, 1);
            }
        });
    }

    @Test
    public void testAddMilliseconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.addMilliseconds(date, 777);
        assertEquals(date.getTime() + 777L, result.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMilliseconds(null, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // setXxx
    // ---------------------------------------------------------------

    @Test
    public void testSetDays() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setDays(date, 31);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(31, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(7, cal.get(Calendar.HOUR_OF_DAY));

        result = DateUtils.setDays(date, 1);
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(newDate(2002, Calendar.JANUARY, 10), 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(newDate(2002, Calendar.JANUARY, 10), 32);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(null, 1);
            }
        });
    }

    @Test
    public void testSetHours() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setHours(date, 0);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));

        result = DateUtils.setHours(date, 23);
        cal.setTime(result);
        assertEquals(23, cal.get(Calendar.HOUR_OF_DAY));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(newDate(2002, Calendar.JANUARY, 10), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(newDate(2002, Calendar.JANUARY, 10), 24);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(null, 1);
            }
        });
    }

    @Test
    public void testSetMinutes() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setMinutes(date, 0);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(0, cal.get(Calendar.MINUTE));

        result = DateUtils.setMinutes(date, 59);
        cal.setTime(result);
        assertEquals(59, cal.get(Calendar.MINUTE));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(newDate(2002, Calendar.JANUARY, 10), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(newDate(2002, Calendar.JANUARY, 10), 60);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(null, 1);
            }
        });
    }

    @Test
    public void testSetSeconds() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setSeconds(date, 0);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(0, cal.get(Calendar.SECOND));

        result = DateUtils.setSeconds(date, 59);
        cal.setTime(result);
        assertEquals(59, cal.get(Calendar.SECOND));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(newDate(2002, Calendar.JANUARY, 10), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(newDate(2002, Calendar.JANUARY, 10), 60);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(null, 1);
            }
        });
    }

    @Test
    public void testSetMilliseconds() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setMilliseconds(date, 0);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(0, cal.get(Calendar.MILLISECOND));

        result = DateUtils.setMilliseconds(date, 999);
        cal.setTime(result);
        assertEquals(999, cal.get(Calendar.MILLISECOND));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(newDate(2002, Calendar.JANUARY, 10), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(newDate(2002, Calendar.JANUARY, 10), 1000);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(null, 1);
            }
        });
    }

    @Test
    public void testSetMonths() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setMonths(date, 0);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));

        result = DateUtils.setMonths(date, 11);
        cal.setTime(result);
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(newDate(2002, Calendar.JANUARY, 10), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(newDate(2002, Calendar.JANUARY, 10), 12);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(null, 1);
            }
        });
    }

    @Test
    public void testSetYears() {
        Date date = newDate(2002, Calendar.JANUARY, 10, 7, 8, 9, 10);
        Date result = DateUtils.setYears(date, 1999);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1999, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(10, cal.get(Calendar.DAY_OF_MONTH));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setYears(null, 2000);
            }
        });
    }

    // ---------------------------------------------------------------
    // toCalendar / toXxxDateTime
    // ---------------------------------------------------------------

    @Test
    public void testToCalendar() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date.getTime(), cal.getTimeInMillis());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    public void testToCalendarWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("America/New_York");
        Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date.getTime(), cal.getTimeInMillis());
        assertEquals(tz, cal.getTimeZone());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(newDate(2002, Calendar.MARCH, 28), null);
            }
        });
    }

    @Test
    public void testToLocalDateTime() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        LocalDateTime expected = date.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDateTime();
        assertEquals(expected, DateUtils.toLocalDateTime(date));
    }

    @Test
    public void testToLocalDateTimeWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("Asia/Tokyo");
        LocalDateTime expected = date.toInstant().atZone(tz.toZoneId()).toLocalDateTime();
        assertEquals(expected, DateUtils.toLocalDateTime(date, tz));

        assertEquals(DateUtils.toLocalDateTime(date), DateUtils.toLocalDateTime(date, null));
    }

    @Test
    public void testToOffsetDateTime() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        OffsetDateTime expected = date.toInstant().atZone(java.time.ZoneId.systemDefault()).toOffsetDateTime();
        assertEquals(expected, DateUtils.toOffsetDateTime(date));
    }

    @Test
    public void testToOffsetDateTimeWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("Asia/Tokyo");
        OffsetDateTime expected = date.toInstant().atZone(tz.toZoneId()).toOffsetDateTime();
        assertEquals(expected, DateUtils.toOffsetDateTime(date, tz));

        assertEquals(DateUtils.toOffsetDateTime(date), DateUtils.toOffsetDateTime(date, null));
    }

    @Test
    public void testToZonedDateTime() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        ZonedDateTime expected = date.toInstant().atZone(java.time.ZoneId.systemDefault());
        assertEquals(expected, DateUtils.toZonedDateTime(date));
    }

    @Test
    public void testToZonedDateTimeWithTimeZone() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        TimeZone tz = TimeZone.getTimeZone("Asia/Tokyo");
        ZonedDateTime expected = date.toInstant().atZone(tz.toZoneId());
        assertEquals(expected, DateUtils.toZonedDateTime(date, tz));

        assertEquals(DateUtils.toZonedDateTime(date), DateUtils.toZonedDateTime(date, null));
    }

    // ---------------------------------------------------------------
    // isSameXxx
    // ---------------------------------------------------------------

    @Test
    public void testIsSameDayDate() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Date) null, newDate(2002, Calendar.MARCH, 28));
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay(newDate(2002, Calendar.MARCH, 28), (Date) null);
            }
        });
    }

    @Test
    public void testIsSameDayCalendar() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCal(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar c3 = newCal(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
        assertFalse(DateUtils.isSameDay(c1, c3));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Calendar) null, newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0));
            }
        });
    }

    @Test
    public void testIsSameInstantDate() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date d2 = new Date(d1.getTime());
        Date d3 = new Date(d1.getTime() + 1L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Date) null, (Date) null);
            }
        });
    }

    @Test
    public void testIsSameInstantCalendar() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c3 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 232);
        assertTrue(DateUtils.isSameInstant(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c3));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Calendar) null, (Calendar) null);
            }
        });
    }

    @Test
    public void testIsSameLocalTime() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        c2.clear();
        c2.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        c2.set(Calendar.MILLISECOND, 231);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));

        Calendar c3 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 232);
        assertFalse(DateUtils.isSameLocalTime(c1, c3));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime((Calendar) null, (Calendar) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // truncate
    // ---------------------------------------------------------------

    @Test
    public void testTruncateCalendar() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncatedHour = DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 13, 0, 0, 0).getTime(), truncatedHour.getTime());

        Calendar cal2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncatedMonth = DateUtils.truncate(cal2, Calendar.MONTH);
        assertEquals(newCal(2002, Calendar.MARCH, 1, 0, 0, 0, 0).getTime(), truncatedMonth.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });

        final Calendar overflow = Calendar.getInstance();
        overflow.clear();
        overflow.set(Calendar.YEAR, 300000000);
        overflow.set(Calendar.MONTH, Calendar.JANUARY);
        overflow.set(Calendar.DAY_OF_MONTH, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(overflow, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testTruncateDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncatedHour = DateUtils.truncate(date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncatedHour);

        Date truncatedMonth = DateUtils.truncate(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 1), truncatedMonth);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testTruncateObject() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncatedFromDate = DateUtils.truncate((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncatedFromDate);

        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncatedFromCal = DateUtils.truncate((Object) cal, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncatedFromCal);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    // ---------------------------------------------------------------
    // round
    // ---------------------------------------------------------------

    @Test
    public void testRoundCalendarHourAndMonth() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar roundedHour = DateUtils.round(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 14, 0, 0, 0).getTime(), roundedHour.getTime());

        Calendar cal2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar roundedMonth = DateUtils.round(cal2, Calendar.MONTH);
        assertEquals(newCal(2002, Calendar.APRIL, 1, 0, 0, 0, 0).getTime(), roundedMonth.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });

        final Calendar overflow = Calendar.getInstance();
        overflow.clear();
        overflow.set(Calendar.YEAR, 300000000);
        overflow.set(Calendar.MONTH, Calendar.JANUARY);
        overflow.set(Calendar.DAY_OF_MONTH, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round(overflow, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testRoundMinuteThreshold() {
        Calendar below = newCal(2002, Calendar.MARCH, 28, 10, 15, 29, 0);
        Calendar roundedBelow = DateUtils.round(below, Calendar.MINUTE);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 10, 15, 0, 0).getTime(), roundedBelow.getTime());

        Calendar above = newCal(2002, Calendar.MARCH, 28, 10, 15, 31, 0);
        Calendar roundedAbove = DateUtils.round(above, Calendar.MINUTE);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 10, 16, 0, 0).getTime(), roundedAbove.getTime());
    }

    @Test
    public void testRoundHourThreshold() {
        Calendar below = newCal(2002, Calendar.MARCH, 28, 10, 29, 0, 0);
        Calendar roundedBelow = DateUtils.round(below, Calendar.HOUR_OF_DAY);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 10, 0, 0, 0).getTime(), roundedBelow.getTime());

        Calendar above = newCal(2002, Calendar.MARCH, 28, 10, 31, 0, 0);
        Calendar roundedAbove = DateUtils.round(above, Calendar.HOUR_OF_DAY);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 11, 0, 0, 0).getTime(), roundedAbove.getTime());
    }

    @Test
    public void testRoundMonthDayThresholdInTwentyEightDayMonth() {
        Calendar day14 = newCal(2002, Calendar.FEBRUARY, 14, 0, 0, 0, 0);
        Calendar rounded14 = DateUtils.round(day14, Calendar.MONTH);
        assertEquals(newCal(2002, Calendar.FEBRUARY, 1, 0, 0, 0, 0).getTime(), rounded14.getTime());

        Calendar day15 = newCal(2002, Calendar.FEBRUARY, 15, 0, 0, 0, 0);
        Calendar rounded15 = DateUtils.round(day15, Calendar.MONTH);
        assertEquals(newCal(2002, Calendar.MARCH, 1, 0, 0, 0, 0).getTime(), rounded15.getTime());
    }

    @Test
    public void testRoundYearThresholdAtJuly() {
        Calendar beforeJuly = newCal(2002, Calendar.MAY, 10, 0, 0, 0, 0);
        Calendar roundedBefore = DateUtils.round(beforeJuly, Calendar.YEAR);
        assertEquals(newCal(2002, Calendar.JANUARY, 1, 0, 0, 0, 0).getTime(), roundedBefore.getTime());

        Calendar afterJuly = newCal(2002, Calendar.AUGUST, 10, 0, 0, 0, 0);
        Calendar roundedAfter = DateUtils.round(afterJuly, Calendar.YEAR);
        assertEquals(newCal(2003, Calendar.JANUARY, 1, 0, 0, 0, 0).getTime(), roundedAfter.getTime());
    }

    @Test
    public void testRoundSemiMonth() {
        Calendar early = newCal(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        Calendar roundedEarly = DateUtils.round(early, DateUtils.SEMI_MONTH);
        assertEquals(newCal(2002, Calendar.MARCH, 1, 0, 0, 0, 0).getTime(), roundedEarly.getTime());

        Calendar mid = newCal(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        Calendar roundedMid = DateUtils.round(mid, DateUtils.SEMI_MONTH);
        assertEquals(newCal(2002, Calendar.MARCH, 16, 0, 0, 0, 0).getTime(), roundedMid.getTime());

        Calendar late = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Calendar roundedLate = DateUtils.round(late, DateUtils.SEMI_MONTH);
        assertEquals(newCal(2002, Calendar.APRIL, 1, 0, 0, 0, 0).getTime(), roundedLate.getTime());
    }

    @Test
    public void testRoundDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testRoundObject() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    // ---------------------------------------------------------------
    // ceiling
    // ---------------------------------------------------------------

    @Test
    public void testCeilingCalendar() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar ceilHour = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 14, 0, 0, 0).getTime(), ceilHour.getTime());

        Calendar cal2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar ceilMonth = DateUtils.ceiling(cal2, Calendar.MONTH);
        assertEquals(newCal(2002, Calendar.APRIL, 1, 0, 0, 0, 0).getTime(), ceilMonth.getTime());

        // A date already at the boundary should still ceil forward.
        Calendar onBoundary = newCal(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        Calendar ceilOnBoundary = DateUtils.ceiling(onBoundary, Calendar.MONTH);
        assertEquals(newCal(2002, Calendar.MARCH, 1, 0, 0, 0, 0).getTime(), ceilOnBoundary.getTime());

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });

        final Calendar overflow = Calendar.getInstance();
        overflow.clear();
        overflow.set(Calendar.YEAR, 300000000);
        overflow.set(Calendar.MONTH, Calendar.JANUARY);
        overflow.set(Calendar.DAY_OF_MONTH, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(overflow, Calendar.MONTH);
            }
        });
    }

    @Test
    public void testCeilingDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date ceilHour = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), ceilHour);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testCeilingObject() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date ceil = DateUtils.ceiling((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), ceil);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    // ---------------------------------------------------------------
    // truncatedEquals / truncatedCompareTo
    // ---------------------------------------------------------------

    @Test
    public void testTruncatedEqualsAndCompareToDate() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date d2 = newDate(2002, Calendar.MARCH, 28, 13, 50, 59, 999);
        Date d3 = newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0);

        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.HOUR_OF_DAY));
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.HOUR_OF_DAY));
        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(d3, d1, Calendar.HOUR_OF_DAY) > 0);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedEquals((Date) null, (Date) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedCompareTo((Date) null, (Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void testTruncatedEqualsAndCompareToCalendar() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c2 = newCal(2002, Calendar.MARCH, 28, 13, 50, 59, 999);
        Calendar c3 = newCal(2002, Calendar.MARCH, 28, 14, 0, 0, 0);

        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
        assertFalse(DateUtils.truncatedEquals(c1, c3, Calendar.HOUR_OF_DAY));
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.HOUR_OF_DAY));
        assertTrue(DateUtils.truncatedCompareTo(c1, c3, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(c3, c1, Calendar.HOUR_OF_DAY) > 0);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedEquals((Calendar) null, (Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedCompareTo((Calendar) null, (Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFragmentInXxx
    // ---------------------------------------------------------------

    @Test
    public void testGetFragmentInDays() {
        Calendar jan28 = newCal(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(jan28.getTime(), Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));
        assertEquals(0L, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));

        Calendar feb28 = newCal(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.MONTH);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.MONTH);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(newCal(2008, Calendar.JANUARY, 28, 0, 0, 0, 0), Calendar.DAY_OF_WEEK);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(newDate(2008, Calendar.JANUARY, 28), Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    public void testGetFragmentInHours() {
        Calendar jan1 = newCal(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7L, DateUtils.getFragmentInHours(jan1, Calendar.DAY_OF_YEAR));
        assertEquals(7L, DateUtils.getFragmentInHours(jan1.getTime(), Calendar.DAY_OF_YEAR));

        Calendar jan6 = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127L, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInHours(jan6, Calendar.MILLISECOND));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInHours((Calendar) null, Calendar.MONTH);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInHours((Date) null, Calendar.MONTH);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInHours(newDate(2008, Calendar.JANUARY, 1), Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    public void testGetFragmentInMinutes() {
        Calendar jan1 = newCal(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1.getTime(), Calendar.HOUR_OF_DAY));

        Calendar jan6 = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(435L, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInMinutes(jan6, Calendar.MILLISECOND));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInMinutes((Calendar) null, Calendar.MONTH);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInMinutes((Date) null, Calendar.MONTH);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInMinutes(newDate(2008, Calendar.JANUARY, 1), Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    public void testGetFragmentInSeconds() {
        Calendar jan1 = newCal(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10L, DateUtils.getFragmentInSeconds(jan1, Calendar.MINUTE));
        assertEquals(10L, DateUtils.getFragmentInSeconds(jan1.getTime(), Calendar.MINUTE));

        Calendar jan6 = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110L, DateUtils.getFragmentInSeconds(jan6, Calendar.DAY_OF_YEAR));
        assertEquals(0L, DateUtils.getFragmentInSeconds(jan6, Calendar.MILLISECOND));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInSeconds((Calendar) null, Calendar.MINUTE);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInSeconds((Date) null, Calendar.MINUTE);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInSeconds(newDate(2008, Calendar.JANUARY, 1), Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    public void testGetFragmentInMilliseconds() {
        Calendar jan1 = newCal(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(jan1, Calendar.SECOND));
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(jan1.getTime(), Calendar.SECOND));

        Calendar jan6 = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MINUTE));
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MILLISECOND));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInMilliseconds((Calendar) null, Calendar.SECOND);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInMilliseconds((Date) null, Calendar.SECOND);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInMilliseconds(newDate(2008, Calendar.JANUARY, 1), Calendar.DAY_OF_WEEK);
            }
        });
    }

    // ---------------------------------------------------------------
    // iterator
    // ---------------------------------------------------------------

    @Test
    public void testIteratorCalendarMonthSunday() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);

        assertTrue(it.hasNext());
        Calendar first = it.next();
        assertTrue(DateUtils.isSameDay(first, newCal(2002, Calendar.JUNE, 30, 0, 0, 0, 0)));

        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertTrue(DateUtils.isSameDay(last, newCal(2002, Calendar.AUGUST, 3, 0, 0, 0, 0)));
        assertEquals(35, count);
        assertFalse(it.hasNext());

        final Iterator<Calendar> exhausted = it;
        assertThrows(java.util.NoSuchElementException.class, new Executable() {
            @Override
            public void execute() {
                exhausted.next();
            }
        });
    }

    @Test
    public void testIteratorDate() {
        Date focus = newDate(2002, Calendar.JULY, 4);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(35, count);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Date) null, DateUtils.RANGE_MONTH_SUNDAY);
            }
        });
    }

    @Test
    public void testIteratorObject() {
        Date focusDate = newDate(2002, Calendar.JULY, 4);
        Iterator<?> itFromDate = DateUtils.iterator((Object) focusDate, DateUtils.RANGE_MONTH_SUNDAY);
        int countDate = 0;
        while (itFromDate.hasNext()) {
            itFromDate.next();
            countDate++;
        }
        assertEquals(35, countDate);

        Calendar focusCal = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<?> itFromCal = DateUtils.iterator((Object) focusCal, DateUtils.RANGE_MONTH_SUNDAY);
        int countCal = 0;
        while (itFromCal.hasNext()) {
            itFromCal.next();
            countCal++;
        }
        assertEquals(35, countCal);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) null, DateUtils.RANGE_MONTH_SUNDAY);
            }
        });
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) "not a date", DateUtils.RANGE_MONTH_SUNDAY);
            }
        });
    }

    @Test
    public void testIteratorInvalidRangeStyle() {
        final Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator(focus, -999);
            }
        });
    }

    // ---------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ---------------------------------------------------------------

    @Test
    public void testParseDateBasic() throws ParseException {
        Date parsed = DateUtils.parseDate("2020-01-15", "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(parsed);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateTriesEachPatternInTurn() throws ParseException {
        Date parsed = DateUtils.parseDate("2020-01-15", "yyyy", "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(parsed);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateRequiresWholeStringConsumed() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2020-01-15extra", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void testParseDateNoPatternsThrows() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2020-01-15", new String[0]);
            }
        });
    }

    @Test
    public void testParseDateNullArguments() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2020-01-15", (String[]) null);
            }
        });
    }

    @Test
    public void testParseDateWithNullLocaleUsesSystemLocale() throws ParseException {
        Date withNullLocale = DateUtils.parseDate("2020-01-15", (Locale) null, "yyyy-MM-dd");
        Date withoutLocale = DateUtils.parseDate("2020-01-15", "yyyy-MM-dd");
        assertEquals(withoutLocale, withNullLocale);
    }

    @Test
    public void testParseDateWithExplicitLocale() throws ParseException {
        Date parsed = DateUtils.parseDate("1 janvier 2020", Locale.FRENCH, "d MMMM yyyy");
        Calendar cal = Calendar.getInstance();
        cal.setTime(parsed);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateStrictlyRejectsLenientOverflow() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("February 942, 1996", "MMMM d, yyyy");
            }
        });

        // The lenient parser, by contrast, accepts the same malformed input.
        try {
            Date lenient = DateUtils.parseDate("February 942, 1996", "MMMM d, yyyy");
            assertNotNull(lenient);
        } catch (ParseException e) {
            throw new AssertionError("Lenient parseDate unexpectedly rejected a rollover date", e);
        }
    }

    @Test
    public void testParseDateStrictlyBasic() throws ParseException {
        Date parsed = DateUtils.parseDateStrictly("2020-01-15", "yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(parsed);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateStrictlyNoPatternsThrows() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2020-01-15", new String[0]);
            }
        });
    }

    @Test
    public void testParseDateStrictlyNullArguments() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2020-01-15", (String[]) null);
            }
        });
    }

    @Test
    public void testParseDateStrictlyWithNullLocaleUsesSystemLocale() throws ParseException {
        Date withNullLocale = DateUtils.parseDateStrictly("2020-01-15", (Locale) null, "yyyy-MM-dd");
        Date withoutLocale = DateUtils.parseDateStrictly("2020-01-15", "yyyy-MM-dd");
        assertEquals(withoutLocale, withNullLocale);
    }
}
