package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertSame;

public class StringsAgentTest {

    // ---------------------------------------------------------------
    // Singleton / instance properties
    // ---------------------------------------------------------------

    @Test
    public void testSingletonsAreDistinctAndStable() {
        assertNotNull(Strings.CS);
        assertNotNull(Strings.CI);
        assertNotSame(Strings.CS, Strings.CI);
        assertSame(Strings.CS, Strings.CS);
        assertSame(Strings.CI, Strings.CI);
    }

    @Test
    public void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    @Test
    public void testIsNullIsLess() {
        // compare() documents null as always less than non-null for both CS and CI.
        assertTrue(Strings.CS.isNullIsLess());
        assertTrue(Strings.CI.isNullIsLess());
    }

    @Test
    public void testBuilderReturnsNewDistinctInstance() {
        Strings.Builder b1 = Strings.builder();
        Strings.Builder b2 = Strings.builder();
        assertNotNull(b1);
        assertNotNull(b2);
        assertNotSame(b1, b2);
    }

    // ---------------------------------------------------------------
    // compare
    // ---------------------------------------------------------------

    @Test
    public void testCompareCS() {
        assertEquals(0, Strings.CS.compare(null, null));
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "b") < 0);
        assertTrue(Strings.CS.compare("b", "a") > 0);
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    public void testCompareCI() {
        assertEquals(0, Strings.CI.compare(null, null));
        assertTrue(Strings.CI.compare(null, "a") < 0);
        assertTrue(Strings.CI.compare("a", null) > 0);
        assertEquals(0, Strings.CI.compare("abc", "abc"));
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "b") < 0);
        assertTrue(Strings.CI.compare("b", "a") > 0);
        assertTrue(Strings.CI.compare("a", "B") < 0);
        assertTrue(Strings.CI.compare("A", "b") < 0);
        assertTrue(Strings.CI.compare("ab", "ABC") < 0);
    }

    // ---------------------------------------------------------------
    // contains
    // ---------------------------------------------------------------

    @Test
    public void testContainsCS() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
    }

    @Test
    public void testContainsCI() {
        assertFalse(Strings.CI.contains(null, "a"));
        assertFalse(Strings.CI.contains("a", null));
        assertTrue(Strings.CI.contains("", ""));
        assertTrue(Strings.CI.contains("abc", ""));
        assertTrue(Strings.CI.contains("abc", "a"));
        assertFalse(Strings.CI.contains("abc", "z"));
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
    }

    // ---------------------------------------------------------------
    // containsAny
    // ---------------------------------------------------------------

    @Test
    public void testContainsAnyCS() {
        assertFalse(Strings.CS.containsAny(null, "ab"));
        assertFalse(Strings.CS.containsAny("", "ab"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc", new CharSequence[0]));
        assertTrue(Strings.CS.containsAny("abcd", "ab", null));
        assertTrue(Strings.CS.containsAny("abcd", "ab", "cd"));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAnyCI() {
        assertFalse(Strings.CI.containsAny(null, "ab"));
        assertFalse(Strings.CI.containsAny("", "ab"));
        assertFalse(Strings.CI.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CI.containsAny("abc", new CharSequence[0]));
        assertTrue(Strings.CI.containsAny("abcd", "ab", null));
        assertTrue(Strings.CI.containsAny("abcd", "ab", "cd"));
        assertTrue(Strings.CI.containsAny("abc", "d", "abc"));
        assertTrue(Strings.CI.containsAny("abc", "D", "ABC"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    // ---------------------------------------------------------------
    // endsWith / endsWithAny
    // ---------------------------------------------------------------

    @Test
    public void testEndsWithCS() {
        assertTrue(Strings.CS.endsWith(null, null));
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "cde"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithCI() {
        assertTrue(Strings.CI.endsWith(null, null));
        assertFalse(Strings.CI.endsWith(null, "def"));
        assertFalse(Strings.CI.endsWith("abcdef", null));
        assertTrue(Strings.CI.endsWith("abcdef", "def"));
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    @Test
    public void testEndsWithAnyCS() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    @Test
    public void testEndsWithAnyCI() {
        assertFalse(Strings.CI.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CI.endsWithAny(null, "abc"));
        assertFalse(Strings.CI.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CI.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CI.endsWithAny("abcxyz", "XYZ"));
        assertTrue(Strings.CI.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // ---------------------------------------------------------------
    // equals (CharSequence, CharSequence) and (String, String)
    // ---------------------------------------------------------------

    @Test
    public void testEqualsCharSequenceCS() {
        CharSequence a = "abc";
        CharSequence b = "ABC";
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, a));
        assertFalse(Strings.CS.equals(a, (CharSequence) null));
        assertTrue(Strings.CS.equals(a, "abc"));
        assertFalse(Strings.CS.equals(a, b));
    }

    @Test
    public void testEqualsCharSequenceCI() {
        CharSequence a = "abc";
        CharSequence b = "ABC";
        assertTrue(Strings.CI.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CI.equals((CharSequence) null, a));
        assertFalse(Strings.CI.equals(a, (CharSequence) null));
        assertTrue(Strings.CI.equals(a, "abc"));
        assertTrue(Strings.CI.equals(a, b));
    }

    @Test
    public void testEqualsStringCS() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsStringCI() {
        assertTrue(Strings.CI.equals((String) null, (String) null));
        assertFalse(Strings.CI.equals((String) null, "abc"));
        assertFalse(Strings.CI.equals("abc", (String) null));
        assertTrue(Strings.CI.equals("abc", "abc"));
        assertTrue(Strings.CI.equals("abc", "ABC"));
    }

    // ---------------------------------------------------------------
    // equalsAny
    // ---------------------------------------------------------------

    @Test
    public void testEqualsAnyCS() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CS.equalsAny(null, null, null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAnyCI() {
        assertFalse(Strings.CI.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CI.equalsAny(null, null, null));
        assertFalse(Strings.CI.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CI.equalsAny("abc", null, "def"));
        assertTrue(Strings.CI.equalsAny("abc", "abc", "def"));
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // ---------------------------------------------------------------
    // indexOf (2-arg and 3-arg)
    // ---------------------------------------------------------------

    @Test
    public void testIndexOfTwoArgCS() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(-1, Strings.CS.indexOf("", "x"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", ""));
    }

    @Test
    public void testIndexOfTwoArgCI() {
        assertEquals(-1, Strings.CI.indexOf(null, "a"));
        assertEquals(-1, Strings.CI.indexOf("a", null));
        assertEquals(0, Strings.CI.indexOf("", ""));
        assertEquals(0, Strings.CI.indexOf(" ", " "));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B"));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB"));
    }

    @Test
    public void testIndexOfThreeArgCS() {
        assertEquals(-1, Strings.CS.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", null, 0));
        assertEquals(0, Strings.CS.indexOf("", "", 0));
        assertEquals(-1, Strings.CS.indexOf("", "x", 0));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a", 0));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", 0));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfThreeArgCI() {
        assertEquals(-1, Strings.CI.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CI.indexOf("a", null, 0));
        assertEquals(0, Strings.CI.indexOf("", "", 0));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
        // Differs from CS: CS.indexOf("abc", "", 9) == 3
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
    }

    // ---------------------------------------------------------------
    // lastIndexOf (2-arg and 3-arg)
    // ---------------------------------------------------------------

    @Test
    public void testLastIndexOfTwoArgCS() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfTwoArgCI() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CI.lastIndexOf("a", null));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B"));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB"));
    }

    @Test
    public void testLastIndexOfThreeArgCS() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a", 8));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null, 8));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        // Negative start position returns -1 (unlike indexOf, which treats negative as zero).
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    public void testLastIndexOfThreeArgCI() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a", 8));
        assertEquals(-1, Strings.CI.lastIndexOf("a", null, 8));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 8));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // ---------------------------------------------------------------
    // appendIfMissing
    // ---------------------------------------------------------------

    @Test
    public void testAppendIfMissingCS() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));

        assertNull(Strings.CS.appendIfMissing(null, null, (CharSequence) null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null, (CharSequence) null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz", (CharSequence) null));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", new CharSequence[]{null}));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz", "mno"));
        assertEquals("abcMNOxyz", Strings.CS.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissingCI() {
        assertNull(Strings.CI.appendIfMissing(null, null));
        assertEquals("abc", Strings.CI.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CI.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));

        assertNull(Strings.CI.appendIfMissing(null, null, (CharSequence) null));
        assertEquals("abc", Strings.CI.appendIfMissing("abc", null, (CharSequence) null));
        assertEquals("xyz", Strings.CI.appendIfMissing("", "xyz", (CharSequence) null));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abc", "xyz", new CharSequence[]{null}));
        assertEquals("abc", Strings.CI.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abcxyz", "xyz", "mno"));
        assertEquals("abcmno", Strings.CI.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz", "mno"));
        assertEquals("abcMNO", Strings.CI.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    // ---------------------------------------------------------------
    // prependIfMissing
    // ---------------------------------------------------------------

    @Test
    public void testPrependIfMissingCS() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));

        assertNull(Strings.CS.prependIfMissing(null, null, (CharSequence) null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null, (CharSequence) null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz", (CharSequence) null));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", new CharSequence[]{null}));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", "xyz", ""));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", "mno"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz", "mno"));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz", "mno"));
        assertEquals("xyzMNOabc", Strings.CS.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingCI() {
        assertNull(Strings.CI.prependIfMissing(null, null));
        assertEquals("abc", Strings.CI.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CI.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));

        assertNull(Strings.CI.prependIfMissing(null, null, (CharSequence) null));
        assertEquals("abc", Strings.CI.prependIfMissing("abc", null, (CharSequence) null));
        assertEquals("xyz", Strings.CI.prependIfMissing("", "xyz", (CharSequence) null));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("abc", "xyz", new CharSequence[]{null}));
        assertEquals("abc", Strings.CI.prependIfMissing("abc", "xyz", ""));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("abc", "xyz", "mno"));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("xyzabc", "xyz", "mno"));
        assertEquals("mnoabc", Strings.CI.prependIfMissing("mnoabc", "xyz", "mno"));
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz", "mno"));
        assertEquals("MNOabc", Strings.CI.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    // ---------------------------------------------------------------
    // remove
    // ---------------------------------------------------------------

    @Test
    public void testRemoveCS() {
        assertNull(Strings.CS.remove(null, "x"));
        assertEquals("", Strings.CS.remove("", "x"));
        assertEquals("queued", Strings.CS.remove("queued", null));
        assertEquals("queued", Strings.CS.remove("queued", ""));
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    public void testRemoveCI() {
        assertNull(Strings.CI.remove(null, "x"));
        assertEquals("", Strings.CI.remove("", "x"));
        assertEquals("queued", Strings.CI.remove("queued", null));
        assertEquals("queued", Strings.CI.remove("queued", ""));
        assertEquals("qd", Strings.CI.remove("queued", "ue"));
        assertEquals("queued", Strings.CI.remove("queued", "zz"));
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    // ---------------------------------------------------------------
    // removeEnd
    // ---------------------------------------------------------------

    @Test
    public void testRemoveEndCS() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEndCI() {
        assertNull(Strings.CI.removeEnd(null, "x"));
        assertEquals("", Strings.CI.removeEnd("", "x"));
        assertEquals("abc", Strings.CI.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CI.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CI.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CI.removeEnd("abc", ""));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // ---------------------------------------------------------------
    // removeStart
    // ---------------------------------------------------------------

    @Test
    public void testRemoveStartCS() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStartCI() {
        assertNull(Strings.CI.removeStart(null, "x"));
        assertEquals("", Strings.CI.removeStart("", "x"));
        assertEquals("abc", Strings.CI.removeStart("abc", null));
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
        assertEquals("domain.com", Strings.CI.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CI.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CI.removeStart("abc", ""));
    }

    // ---------------------------------------------------------------
    // replace (3-arg)
    // ---------------------------------------------------------------

    @Test
    public void testReplaceCS() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceCI() {
        assertNull(Strings.CI.replace(null, "a", "b"));
        assertEquals("", Strings.CI.replace("", "a", "b"));
        assertEquals("any", Strings.CI.replace("any", null, "b"));
        assertEquals("any", Strings.CI.replace("any", "a", null));
        assertEquals("any", Strings.CI.replace("any", "", "b"));
        assertEquals("aba", Strings.CI.replace("aba", "a", null));
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    // ---------------------------------------------------------------
    // replace (4-arg, with max)
    // ---------------------------------------------------------------

    @Test
    public void testReplaceWithMaxCS() {
        assertNull(Strings.CS.replace(null, "a", "z", 1));
        assertEquals("", Strings.CS.replace("", "a", "z", 1));
        assertEquals("any", Strings.CS.replace("any", null, "z", 1));
        assertEquals("any", Strings.CS.replace("any", "a", null, 1));
        assertEquals("any", Strings.CS.replace("any", "", "z", 1));
        assertEquals("any", Strings.CS.replace("any", "a", "z", 0));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CS.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceWithMaxCI() {
        assertNull(Strings.CI.replace(null, "a", "z", 1));
        assertEquals("", Strings.CI.replace("", "a", "z", 1));
        assertEquals("any", Strings.CI.replace("any", null, "z", 1));
        assertEquals("any", Strings.CI.replace("any", "a", null, 1));
        assertEquals("any", Strings.CI.replace("any", "", "z", 1));
        assertEquals("any", Strings.CI.replace("any", "a", "z", 0));
        assertEquals("abaa", Strings.CI.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CI.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CI.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CI.replace("abaa", "A", "z", 1));
        assertEquals("zbza", Strings.CI.replace("abAa", "a", "z", 2));
        assertEquals("zbzz", Strings.CI.replace("abAa", "a", "z", -1));
    }

    // ---------------------------------------------------------------
    // replaceOnce
    // ---------------------------------------------------------------

    @Test
    public void testReplaceOnceCS() {
        assertNull(Strings.CS.replaceOnce(null, "a", "z"));
        assertEquals("", Strings.CS.replaceOnce("", "a", "z"));
        assertEquals("any", Strings.CS.replaceOnce("any", null, "z"));
        assertEquals("any", Strings.CS.replaceOnce("any", "a", null));
        assertEquals("any", Strings.CS.replaceOnce("any", "", "z"));
        assertEquals("aba", Strings.CS.replaceOnce("aba", "a", null));
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceCI() {
        assertNull(Strings.CI.replaceOnce(null, "a", "z"));
        assertEquals("", Strings.CI.replaceOnce("", "a", "z"));
        assertEquals("any", Strings.CI.replaceOnce("any", null, "z"));
        assertEquals("any", Strings.CI.replaceOnce("any", "a", null));
        assertEquals("any", Strings.CI.replaceOnce("any", "", "z"));
        assertEquals("aba", Strings.CI.replaceOnce("aba", "a", null));
        assertEquals("ba", Strings.CI.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CI.replaceOnce("aba", "a", "z"));
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // ---------------------------------------------------------------
    // startsWith / startsWithAny
    // ---------------------------------------------------------------

    @Test
    public void testStartsWithCS() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithCI() {
        assertTrue(Strings.CI.startsWith(null, null));
        assertFalse(Strings.CI.startsWith(null, "abc"));
        assertFalse(Strings.CI.startsWith("abcdef", null));
        assertTrue(Strings.CI.startsWith("abcdef", "abc"));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAnyCS() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertFalse(Strings.CS.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    @Test
    public void testStartsWithAnyCI() {
        assertFalse(Strings.CI.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CI.startsWithAny(null, "aBc"));
        assertFalse(Strings.CI.startsWithAny("AbCxYz", (CharSequence[]) null));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", ""));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", "aBc"));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", null, "XyZ", "aBc"));
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }
}
