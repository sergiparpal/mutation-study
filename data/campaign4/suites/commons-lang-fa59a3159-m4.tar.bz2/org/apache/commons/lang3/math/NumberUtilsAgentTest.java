/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructor() {
        assertNotNullInstance(new NumberUtils());
    }

    private void assertNotNullInstance(final Object obj) {
        assertTrue(obj instanceof NumberUtils);
    }

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue());
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue());
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue());
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue());
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue());
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue());
        assertEquals(Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals(Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    // --- compare ---

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // --- createBigDecimal ---

    @Test
    void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
    }

    @Test
    void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // --- createBigInteger ---

    @Test
    void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("255"));
    }

    @Test
    void testCreateBigIntegerNegative() {
        assertEquals(BigInteger.valueOf(-255), NumberUtils.createBigInteger("-255"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("#FF"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    // --- createDouble ---

    @Test
    void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // --- createFloat ---

    @Test
    void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // --- createInteger ---

    @Test
    void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
    }

    @Test
    void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    void testCreateIntegerInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // --- createLong ---

    @Test
    void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    void testCreateLongHex() {
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
    }

    @Test
    void testCreateLongInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // --- createNumber ---

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    void testCreateNumberInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("not a number at all");
            }
        });
    }

    @Test
    void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    void testCreateNumberLongRange() {
        final Number n = NumberUtils.createNumber("" + ((long) Integer.MAX_VALUE + 1L));
        assertTrue(n instanceof Long);
    }

    @Test
    void testCreateNumberBigIntegerRange() {
        final String huge = "123456789012345678901234567890";
        final Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    void testCreateNumberLSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    void testCreateNumberFSuffix() {
        final Number n = NumberUtils.createNumber("1.5F");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue());
    }

    @Test
    void testCreateNumberDSuffix() {
        final Number n = NumberUtils.createNumber("1.5D");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue());
    }

    @Test
    void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    void testCreateNumberDecimalPoint() {
        final Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue());
    }

    @Test
    void testCreateNumberInvalidLSuffixThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    // --- isCreatable / isNumber ---

    @Test
    void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
    }

    @Test
    void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("  "));
    }

    @Test
    void testIsNumberDelegatesToIsCreatable() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
    }

    // --- isDigits ---

    @Test
    void testIsDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    // --- isParsable ---

    @Test
    void testIsParsable() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("1.5L"));
    }

    // --- max/min arrays ---

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 3, (byte) 5, (byte) 1));
    }

    @Test
    void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(3.3d, 5.5d, 1.1d));
    }

    @Test
    void testMaxDoubleArrayNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(3.3d, Double.NaN, 1.1d)));
    }

    @Test
    void testMaxDoubleArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(3.3f, 5.5f, 1.1f));
    }

    @Test
    void testMaxFloatArrayNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(3.3f, Float.NaN, 1.1f)));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(3, 5, 1));
    }

    @Test
    void testMaxIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(3L, 5L, 1L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 3, (short) 5, (short) 1));
    }

    @Test
    void testMaxThreeValues() {
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 9, (byte) 3));
        assertEquals(9.0d, NumberUtils.max(1.0d, 9.0d, 3.0d));
        assertEquals(9.0f, NumberUtils.max(1.0f, 9.0f, 3.0f));
        assertEquals(9, NumberUtils.max(1, 9, 3));
        assertEquals(9L, NumberUtils.max(1L, 9L, 3L));
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 3));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 5, (byte) 1));
    }

    @Test
    void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.1d, NumberUtils.min(3.3d, 5.5d, 1.1d));
    }

    @Test
    void testMinDoubleArrayNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(3.3d, Double.NaN, 1.1d)));
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.1f, NumberUtils.min(3.3f, 5.5f, 1.1f));
    }

    @Test
    void testMinFloatArrayNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(3.3f, Float.NaN, 1.1f)));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(3, 5, 1));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(3L, 5L, 1L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 5, (short) 1));
    }

    @Test
    void testMinThreeValues() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 9, (byte) 3));
        assertEquals(1.0d, NumberUtils.min(1.0d, 9.0d, 3.0d));
        assertEquals(1.0f, NumberUtils.min(1.0f, 9.0f, 3.0f));
        assertEquals(1, NumberUtils.min(1, 9, 3));
        assertEquals(1L, NumberUtils.min(1L, 9L, 3L));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 3));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    // --- toByte / toShort / toInt / toLong / toFloat / toDouble (String) ---

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("abc", (byte) 2));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("abc", (short) 2));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("abc", 2));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("abc", 2L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f));
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f));
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f));
        assertEquals(2.2f, NumberUtils.toFloat("abc", 2.2f));
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d));
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d));
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d));
        assertEquals(2.2d, NumberUtils.toDouble("abc", 2.2d));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d));
    }

    // --- toScaledBigDecimal ---

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.22"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.225")));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.23"), 1, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 1, RoundingMode.DOWN));
        assertEquals(new BigDecimal("1.2"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.25"), 1, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d), 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.25f), 1, RoundingMode.HALF_UP);
        assertEquals(1, result.scale());
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235", 2, RoundingMode.HALF_UP));
    }
}
