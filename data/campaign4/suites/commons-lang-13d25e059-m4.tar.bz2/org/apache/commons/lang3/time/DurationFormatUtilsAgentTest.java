/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationFormatUtils}.
 */
class DurationFormatUtilsAgentTest {

    // 2 days, 3 hours, 4 minutes, 5 seconds, 6 millis.
    private static final long TOTAL_MILLIS = 183845006L;

    private static long utcMillis(final int year, final int month, final int day, final int hour, final int minute, final int second) {
        final Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.clear();
        calendar.set(year, month, day, hour, minute, second);
        return calendar.getTimeInMillis();
    }

    @Test
    void testConstructorIsPublicForBeanCompliance() {
        assertNotNull(new DurationFormatUtils());
    }

    @Test
    void testFormatDurationDefaultsToPadded() {
        assertEquals("000:00:00:00.000", DurationFormatUtils.formatDuration(0, "ddd:HH:mm:ss.SSS"));
    }

    @Test
    void testFormatDurationMillisecondsAfterSecondsIsPaddedToAtLeastThreeDigits() {
        // the "S" millisecond token following a seconds token is always at least 3 digits wide,
        // regardless of padWithZeros or of the token's own repeat count.
        assertEquals("2d3h4m5s006S", DurationFormatUtils.formatDuration(TOTAL_MILLIS, "d'd'H'h'm'm's's'S'S'"));
        assertEquals("2d3h4m5s006S", DurationFormatUtils.formatDuration(TOTAL_MILLIS, "d'd'H'h'm'm's's'S'S'", false));
    }

    @Test
    void testFormatDurationUnusedLargerFieldsFoldIntoRequestedField() {
        // no 'd' token: the days are folded into hours.
        assertEquals("51", DurationFormatUtils.formatDuration(TOTAL_MILLIS, "H"));
        // no field above seconds requested: everything folds into seconds.
        assertEquals("183845", DurationFormatUtils.formatDuration(TOTAL_MILLIS, "s"));
    }

    @Test
    void testFormatDurationPaddingWidthFromTokenCount() {
        assertEquals("0000", DurationFormatUtils.formatDuration(5, "HHHH"));
        assertEquals("0", DurationFormatUtils.formatDuration(5, "HHHH", false));
    }

    @Test
    void testFormatDurationZero() {
        assertEquals("0", DurationFormatUtils.formatDuration(0, "d"));
    }

    @Test
    void testFormatDurationNegativeThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1, "d");
            }
        });
        assertTrue(e.getMessage().contains("durationMillis"));
    }

    @Test
    void testFormatDurationLongMaxValue() {
        assertEquals("106751991167", DurationFormatUtils.formatDuration(Long.MAX_VALUE, "d"));
    }

    @Test
    void testFormatDurationHms() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
        assertEquals("00:00:00.001", DurationFormatUtils.formatDurationHMS(1));
        assertEquals("01:01:01.001", DurationFormatUtils.formatDurationHMS(3661001));
    }

    @Test
    void testFormatDurationIso() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
        assertEquals("P0Y0M2DT3H4M5.006S", DurationFormatUtils.formatDurationISO(TOTAL_MILLIS));
    }

    @Test
    void testFormatDurationWordsZeroNoSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0, false, false));
    }

    @Test
    void testFormatDurationWordsZeroSuppressBoth() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
    }

    @Test
    void testFormatDurationWordsZeroSuppressLeadingOnly() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, false));
    }

    @Test
    void testFormatDurationWordsZeroSuppressTrailingOnly() {
        assertEquals("0 days", DurationFormatUtils.formatDurationWords(0, false, true));
    }

    @Test
    void testFormatDurationWordsSingularPluralization() {
        assertEquals("1 second", DurationFormatUtils.formatDurationWords(1000, true, true));
        assertEquals("1 minute", DurationFormatUtils.formatDurationWords(60000, true, true));
        assertEquals("1 hour", DurationFormatUtils.formatDurationWords(3600000, true, true));
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(86400000, true, true));
        assertEquals("1 minute 5 seconds", DurationFormatUtils.formatDurationWords(65000, true, true));
    }

    @Test
    void testFormatDurationWordsNoSuppressionNeeded() {
        assertEquals("2 days 3 hours 4 minutes 5 seconds", DurationFormatUtils.formatDurationWords(TOTAL_MILLIS, false, false));
        assertEquals("2 days 3 hours 4 minutes 5 seconds", DurationFormatUtils.formatDurationWords(TOTAL_MILLIS, true, true));
    }

    @Test
    void testFormatDurationWordsOnlySuppressesLeadingAndTrailingNotMiddle() {
        // 2 days, 0 hours, 4 minutes, 5 seconds: the zero hour is in the middle and must survive suppression.
        final long millis = 173045000L;
        assertEquals("2 days 0 hours 4 minutes 5 seconds", DurationFormatUtils.formatDurationWords(millis, false, false));
        assertEquals("2 days 0 hours 4 minutes 5 seconds", DurationFormatUtils.formatDurationWords(millis, true, true));
    }

    @Test
    void testFormatDurationWordsSuppressTrailingChain() {
        // 2 days, 3 hours, 0 minutes, 0 seconds: trailing zero minutes/seconds should be stripped.
        final long millis = 183600000L;
        assertEquals("2 days 3 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(millis, false, false));
        assertEquals("2 days 3 hours", DurationFormatUtils.formatDurationWords(millis, false, true));
        assertEquals("2 days 3 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(millis, true, false));
    }

    @Test
    void testFormatPeriodWithAllComponents() {
        final long start = utcMillis(2020, Calendar.JANUARY, 15, 10, 0, 0);
        final long end = utcMillis(2020, Calendar.MARCH, 10, 12, 30, 15);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        assertEquals("0000-01-26T02:30:15", DurationFormatUtils.formatPeriod(start, end, "yyyy'-'MM'-'dd'T'HH':'mm':'ss", true, utc));
        assertEquals("0y1M26d", DurationFormatUtils.formatPeriod(start, end, "y'y'M'M'd'd'", true, utc));
    }

    @Test
    void testFormatPeriodFoldsUnrequestedFields() {
        final long start = utcMillis(2020, Calendar.JANUARY, 15, 10, 0, 0);
        final long end = utcMillis(2020, Calendar.MARCH, 10, 12, 30, 15);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        // no 'y' token: years fold into months.
        assertEquals("1M26d", DurationFormatUtils.formatPeriod(start, end, "M'M'd'd'", true, utc));
        // no 'y' or 'M' token: everything folds into days.
        assertEquals("55d", DurationFormatUtils.formatPeriod(start, end, "d'd'", true, utc));
        // no 'H' token: days'-worth of hours fold into minutes.
        assertEquals("55d150m15s", DurationFormatUtils.formatPeriod(start, end, "d'd'm'm's's'", true, utc));
        // no 'm' token: minutes fold into seconds.
        assertEquals("55d2h1815s", DurationFormatUtils.formatPeriod(start, end, "d'd'H'h's's'", true, utc));
        // no 's' token: seconds fold into milliseconds.
        assertEquals("55d2h30m15000S", DurationFormatUtils.formatPeriod(start, end, "d'd'H'h'm'm'S'S'", true, utc));
        // default 3-arg overload (no padding flag/timezone given explicitly) uses no 'y' token either.
        assertEquals("55d3h30m15s", DurationFormatUtils.formatPeriod(start, end, "d'd'H'h'm'm's's'"));
    }

    @Test
    void testFormatPeriodSameInstant() {
        final long instant = utcMillis(2020, Calendar.JANUARY, 15, 10, 0, 0);
        assertEquals("0y0M0d0h0m0s", DurationFormatUtils.formatPeriod(instant, instant, "y'y'M'M'd'd'H'h'm'm's's'", true, TimeZone.getTimeZone("UTC")));
    }

    @Test
    void testFormatPeriodStartAfterEndThrows() {
        final long start = utcMillis(2020, Calendar.JANUARY, 15, 10, 0, 0);
        final long end = utcMillis(2020, Calendar.MARCH, 10, 12, 30, 15);
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(end, start, "d");
            }
        });
        assertTrue(e.getMessage().contains("startMillis"));
    }

    @Test
    void testFormatPeriodIso() {
        final long start = utcMillis(2020, Calendar.JANUARY, 15, 10, 0, 0);
        final long end = utcMillis(2020, Calendar.MARCH, 10, 12, 30, 15);
        assertEquals("P0Y1M26DT3H30M15.000S", DurationFormatUtils.formatPeriodISO(start, end));
    }

    @Test
    void testLexxTokenizesRepeatedAndDistinctCharacters() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'H'h'm'm's's'");
        assertEquals(8, tokens.length);
        assertEquals(DurationFormatUtils.d, tokens[0].getValue());
        assertEquals(1, tokens[0].getCount());
        assertEquals(DurationFormatUtils.H, tokens[2].getValue());
        assertEquals(DurationFormatUtils.m, tokens[4].getValue());
        assertEquals(DurationFormatUtils.s, tokens[6].getValue());
    }

    @Test
    void testLexxMergesRepeatedTokenChars() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("dd");
        assertEquals(1, tokens.length);
        assertEquals(2, tokens[0].getCount());
    }

    @Test
    void testLexxDefaultLiteralBranchForUnknownCharacters() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("abc");
        assertEquals(1, tokens.length);
        assertEquals("abc", tokens[0].getValue().toString());
    }

    @Test
    void testLexxEmptyPatternProducesNoTokens() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("");
        assertEquals(0, tokens.length);
    }

    @Test
    void testLexxNestedOptionalBlockThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[[d]]");
            }
        });
        assertTrue(e.getMessage().contains("Nested optional"));
    }

    @Test
    void testLexxUnopenedOptionalBlockThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("d]");
            }
        });
        assertTrue(e.getMessage().contains("unopened optional"));
    }

    @Test
    void testLexxUnmatchedQuoteThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("'d");
            }
        });
        assertTrue(e.getMessage().contains("Unmatched quote"));
    }

    @Test
    void testLexxUnmatchedOptionalThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d");
            }
        });
        assertTrue(e.getMessage().contains("Unmatched optional"));
    }

    @Test
    void testTokenEqualsAndHashCode() {
        final DurationFormatUtils.Token[] dd1 = DurationFormatUtils.lexx("dd");
        final DurationFormatUtils.Token[] dd2 = DurationFormatUtils.lexx("dd");
        final DurationFormatUtils.Token[] dOnly = DurationFormatUtils.lexx("d");
        assertTrue(dd1[0].equals(dd2[0]));
        assertFalse(dd1[0].equals(dOnly[0]));
        assertFalse(dd1[0].equals("not a token"));
        assertFalse(dd1[0].equals(null));
        assertEquals(dd1[0].hashCode(), dOnly[0].hashCode());
    }

    @Test
    void testTokenToString() {
        final DurationFormatUtils.Token[] dd = DurationFormatUtils.lexx("dd");
        assertEquals("dd", dd[0].toString());
        final DurationFormatUtils.Token[] d1 = DurationFormatUtils.lexx("d");
        assertEquals("d", d1[0].toString());
    }

    @Test
    void testTokenContainsTokenWithValue() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("dd");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.d));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
    }

    @Test
    void testFormatOptionalTokensFollowJavadocExamples() {
        assertEquals("1d0h0m0s", applyFormat("d'd'H'h'm'm's's'", 1, 0, 0, 0));
        assertEquals("0d1h0m0s", applyFormat("d'd'H'h'm'm's's'", 0, 1, 0, 0));
        assertEquals("0d0h1m0s", applyFormat("d'd'H'h'm'm's's'", 0, 0, 1, 0));
        assertEquals("0d0h0m0s", applyFormat("d'd'H'h'm'm's's'", 0, 0, 0, 0));

        assertEquals("1d0s", applyFormat("d'd'[H'h'm'm']s's'", 1, 0, 0, 0));
        assertEquals("0d1h0s", applyFormat("d'd'[H'h'm'm']s's'", 0, 1, 0, 0));
        assertEquals("0d1m0s", applyFormat("d'd'[H'h'm'm']s's'", 0, 0, 1, 0));
        assertEquals("0d0s", applyFormat("d'd'[H'h'm'm']s's'", 0, 0, 0, 0));

        assertEquals("1d0s", applyFormat("[d'd'H'h'm'm']s's'", 1, 0, 0, 0));
        assertEquals("1h0s", applyFormat("[d'd'H'h'm'm']s's'", 0, 1, 0, 0));
        assertEquals("1m0s", applyFormat("[d'd'H'h'm'm']s's'", 0, 0, 1, 0));
        assertEquals("0s", applyFormat("[d'd'H'h'm'm']s's'", 0, 0, 0, 0));

        assertEquals("1d", applyFormat("[d'd'H'h'm'm's's']", 1, 0, 0, 0));
        assertEquals("1h", applyFormat("[d'd'H'h'm'm's's']", 0, 1, 0, 0));
        assertEquals("1m", applyFormat("[d'd'H'h'm'm's's']", 0, 0, 1, 0));
        assertEquals("", applyFormat("[d'd'H'h'm'm's's']", 0, 0, 0, 0));

        assertEquals("{1}00:00", applyFormat("['{'d'}']HH':'mm", 1, 0, 0, 0));
        assertEquals("01:00", applyFormat("['{'d'}']HH':'mm", 0, 1, 0, 0));
        assertEquals("00:01", applyFormat("['{'d'}']HH':'mm", 0, 0, 1, 0));
        assertEquals("00:00", applyFormat("['{'d'}']HH':'mm", 0, 0, 0, 0));
    }

    private static String applyFormat(final String pattern, final long days, final long hours, final long minutes, final long seconds) {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx(pattern);
        return DurationFormatUtils.format(tokens, 0, 0, days, hours, minutes, seconds, 0, true);
    }
}
