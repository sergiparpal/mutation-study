/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link org.apache.commons.lang3.text.translate.UnicodeUnescaper}.
 */
@Deprecated
class UnicodeUnescaperAgentTest {

    @Test
    void testTranslateUnicodeUppercaseHex() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0041");
        assertEquals("A", result);
    }

    @Test
    void testTranslateUnicodeLowercaseHex() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0061");
        assertEquals("a", result);
    }

    @Test
    void testTranslateWithPlusSign() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u+0041");
        assertEquals("A", result);
    }

    @Test
    void testTranslateWithMultipleUChars() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uuuu0041");
        assertEquals("A", result);
    }

    @Test
    void testTranslateWithMultipleUCharsAndPlusSign() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uuu+0041");
        assertEquals("A", result);
    }

    @Test
    void testTranslateEmbeddedInLargerString() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("foo \\u0041 bar");
        assertEquals("foo A bar", result);
    }

    @Test
    void testTranslateNoBackslash() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("0041");
        assertEquals("0041", result);
    }

    @Test
    void testTranslateBackslashWithoutU() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\n0041");
        assertEquals("\\n0041", result);
    }

    @Test
    void testTranslateTrailingBackslash() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        // lone backslash at end of input, no following char
        final String result = uu.translate("abc\\");
        assertEquals("abc\\", result);
    }

    @Test
    void testTranslateNullInput() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertNull(uu.translate((CharSequence) null));
    }

    @Test
    void testTranslateEmptyInput() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("", uu.translate(""));
    }

    @Test
    void testTranslateNotEnoughDigitsThrows() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                uu.translate("\\u004");
            }
        });
        assertTrue(ex.getMessage().contains("Less than 4 hex digits"));
    }

    @Test
    void testTranslateInvalidHexThrows() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                uu.translate("\\uXXXX");
            }
        });
        assertTrue(ex.getMessage().contains("Unable to parse unicode value"));
    }

    @Test
    void testTranslateDirectMethodReturnsConsumedCount() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("\\u0041", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateDirectMethodWithPlusConsumedCount() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("\\u+0041", 0, writer);
        assertEquals(7, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateDirectMethodNoMatchReturnsZero() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("abcd", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateDirectMethodAtNonZeroIndex() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final String input = "x\\u0042";
        final int consumed = uu.translate(input, 1, writer);
        assertEquals(6, consumed);
        assertEquals("B", writer.toString());
    }

    @Test
    void testTranslateBackslashAtEndOfInput() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        // backslash is the very last character, so index + 1 < length() is false
        final int consumed = uu.translate("\\", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateSignCharacterInUnicodeValueThrows() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        // the first '+' after 'u' is consumed as the optional plus indicator, leaving the
        // second '+' as part of the literal 4-char hex window, which starts with a sign character.
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws IOException {
                uu.translate("\\u++123", 0, writer);
            }
        });
        assertTrue(ex.getMessage().contains("Sign character in unicode value"));
    }

    @Test
    void testHighValueCodePoint() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uFFFF");
        assertEquals(1, result.length());
        assertEquals(0xFFFF, result.charAt(0));
    }
}
