/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
@SuppressWarnings("deprecation")
class StringUtilsAgentTest {

    // ---------------------------------------------------------------
    // isEmpty / isBlank family
    // ---------------------------------------------------------------

    @Test
    void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));
    }

    @Test
    void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank("  abc  "));
    }

    @Test
    void testIsNotBlank() {
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank("  "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    void testIsAnyAllNoneEmptyBlank() {
        assertTrue(StringUtils.isAnyEmpty("abc", ""));
        assertFalse(StringUtils.isAnyEmpty("abc", "def"));
        assertFalse(StringUtils.isAnyEmpty());

        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "x"));
        assertTrue(StringUtils.isAllEmpty());

        assertTrue(StringUtils.isAnyBlank("abc", " "));
        assertFalse(StringUtils.isAnyBlank("abc", "def"));

        assertTrue(StringUtils.isAllBlank("", " ", null));
        assertFalse(StringUtils.isAllBlank("", "x"));

        assertTrue(StringUtils.isNoneEmpty("abc", "def"));
        assertFalse(StringUtils.isNoneEmpty("abc", ""));

        assertTrue(StringUtils.isNoneBlank("abc", "def"));
        assertFalse(StringUtils.isNoneBlank("abc", " "));
    }

    // ---------------------------------------------------------------
    // trim / strip
    // ---------------------------------------------------------------

    @Test
    void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    void testTrimToEmptyAndNull() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));

        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull(" abc "));
    }

    @Test
    void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip(" \t abc \n "));
        assertEquals("abc  ", StringUtils.stripStart(" \tabc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc \t", null));
        assertEquals("abcyx", StringUtils.strip("xxabcyx", "xy"));
    }

    @Test
    void testStripToEmptyAndNull() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));

        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull(" abc "));
    }

    @Test
    void testStripAll() {
        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {"abc", "xyz"}, StringUtils.stripAll(new String[] {" abc ", " xyz "}));
    }

    @Test
    void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a\tb\nc "));
    }

    // ---------------------------------------------------------------
    // equals / compare
    // ---------------------------------------------------------------

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abd"));
    }

    @Test
    void testEqualsAny() {
        assertTrue(StringUtils.equalsAny("abc", "def", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "def", "ghi"));
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "DEF", "ABC"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare(null, "a", true) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertEquals(0, StringUtils.compare("a", "a"));
    }

    @Test
    void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf family
    // ---------------------------------------------------------------

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 2));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
    }

    @Test
    void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 2));
    }

    @Test
    void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "b"));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b", 3));
    }

    @Test
    void testIndexOfAnyAndBut() {
        assertEquals(-1, StringUtils.indexOfAny(null, "a", "b"));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", "za"));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", (String[]) null));

        assertEquals(-1, StringUtils.indexOfAnyBut(null, "a"));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", "b"));
    }

    @Test
    void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 10));
        assertEquals(-1, StringUtils.lastOrdinalIndexOf("", "", 0));
    }

    @Test
    void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "abd") == 2 ? 1 : StringUtils.indexOfDifference("abc", "abd"));
        assertEquals(2, StringUtils.indexOfDifference("abc", "abd"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence) null, (CharSequence) null));
    }

    // ---------------------------------------------------------------
    // contains family
    // ---------------------------------------------------------------

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));
        assertTrue(StringUtils.contains("abc", 'b'));
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
    }

    @Test
    void testContainsAny() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("zzabyycdxx", 'k', 'q'));

        assertTrue(StringUtils.containsAny("abc", "b", "z"));
        assertFalse(StringUtils.containsAny("abc", (CharSequence[]) null));

        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "B"));
    }

    @Test
    void testContainsNoneAndOnly() {
        assertTrue(StringUtils.containsNone(null, 'a'));
        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'x', 'a'));

        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertTrue(StringUtils.containsOnly("aaa", 'a'));
        assertFalse(StringUtils.containsOnly("aab", 'a'));
        assertTrue(StringUtils.containsOnly("", 'a'));
    }

    @Test
    void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace(" "));
        assertTrue(StringUtils.containsWhitespace("ab c"));
        assertFalse(StringUtils.containsWhitespace("abc"));
    }

    // ---------------------------------------------------------------
    // startsWith / endsWith family
    // ---------------------------------------------------------------

    @Test
    void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "qrs"));
    }

    @Test
    void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "qrs"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "abc", "qrs"));
    }

    // ---------------------------------------------------------------
    // substring family
    // ---------------------------------------------------------------

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("de", StringUtils.substring("abcde", -2));
        assertEquals("", StringUtils.substring("abcde", 10));
    }

    @Test
    void testSubstringStartEnd() {
        assertNull(StringUtils.substring(null, 0, 1));
        assertEquals("", StringUtils.substring("", 0, 1));
        assertEquals("ab", StringUtils.substring("abcde", 0, 2));
        assertEquals("abcde", StringUtils.substring("abcde", 0, 100));
        assertEquals("", StringUtils.substring("abcde", 3, 1));
        assertEquals("cde", StringUtils.substring("abcde", -3, 100));
    }

    @Test
    void testSubstringBeforeAfter() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("", StringUtils.substringBefore("abc", "a"));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("abc", StringUtils.substringAfter("abc", null));
    }

    @Test
    void testSubstringBeforeAfterLast() {
        assertNull(StringUtils.substringBeforeLast(null, "a"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("", StringUtils.substringBeforeLast("abc", "d"));

        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "d"));
        assertEquals("", StringUtils.substringAfterLast("abc", null));
    }

    @Test
    void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", "tag"));
        assertNull(StringUtils.substringBetween("abc", "", null));
        assertEquals("bar", StringUtils.substringBetween("[bar]", "[", "]"));
        assertNull(StringUtils.substringBetween("abc", "x"));
    }

    @Test
    void testSubstringsBetween() {
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
        assertArrayEquals(new String[0], StringUtils.substringsBetween("abc", "[", "]"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("", StringUtils.mid("abc", 10, 2));
    }

    // ---------------------------------------------------------------
    // join
    // ---------------------------------------------------------------

    @Test
    void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] {"a"}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ",", 1, 3));
    }

    @Test
    void testJoinWith() {
        assertEquals("a,b,c", StringUtils.joinWith(",", "a", "b", "c"));
        assertEquals("", StringUtils.joinWith(",", (Object[]) null));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(null, "a", "b");
            }
        });
    }

    // ---------------------------------------------------------------
    // split family
    // ---------------------------------------------------------------

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", "."));
    }

    @Test
    void testSplitPreserveAllTokens() {
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] {"", "a", "b", "c", ""}, StringUtils.splitPreserveAllTokens(".a.b.c.", '.'));
    }

    @Test
    void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab--cd--ef", "--"));

        assertArrayEquals(new String[] {"ab", "", "cd", "ef"},
                StringUtils.splitByWholeSeparatorPreserveAllTokens("ab--!-cd-!-ef".replace("--!-", "-!--!-"), "-!-"));
    }

    @Test
    void testSplitByCharacterType() {
        assertArrayEquals(new String[] {"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
        assertArrayEquals(new String[] {"ab", "De", "Fg"}, StringUtils.splitByCharacterTypeCamelCase("abDeFg"));
    }

    // ---------------------------------------------------------------
    // pad family
    // ---------------------------------------------------------------

    @Test
    void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));
    }

    @Test
    void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxy", StringUtils.rightPad("ab", 4, "xy"));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertEquals("xxaxx", StringUtils.center("a", 5, 'x'));
    }

    // ---------------------------------------------------------------
    // case family
    // ---------------------------------------------------------------

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ROOT));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));
    }

    @Test
    void testRootCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    @Test
    void testCapitalizeUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAT", StringUtils.capitalize("CAT"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testIsAllUpperLowerCase() {
        assertFalse(StringUtils.isAllUpperCase(null));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("abC"));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
    }

    @Test
    void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    // ---------------------------------------------------------------
    // char-type checks
    // ---------------------------------------------------------------

    @Test
    void testIsAlphaFamily() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab1"));
        assertFalse(StringUtils.isAlpha("ab c"));

        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab1 c"));

        assertTrue(StringUtils.isAlphanumeric("ab1"));
        assertFalse(StringUtils.isAlphanumeric("ab1 "));

        assertTrue(StringUtils.isAlphanumericSpace("ab1 c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab1_c"));
    }

    @Test
    void testIsNumericFamily() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("12.3"));
    }

    @Test
    void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace("ab2c"));
    }

    @Test
    void testIsAsciiPrintable() {
        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("Ceki"));
        assertFalse(StringUtils.isAsciiPrintable("ab\u0000"));
    }

    // ---------------------------------------------------------------
    // remove / replace family
    // ---------------------------------------------------------------

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeu", StringUtils.remove("queued", 'u'));
        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("qd", StringUtils.remove("queued", "ue"));

        assertEquals("abc", StringUtils.removeStart("abcabc", null));
        assertEquals("abc", StringUtils.removeStart("abcabc", "abc"));
        assertEquals("", StringUtils.removeStart("", "abc"));

        assertEquals("abc", StringUtils.removeEnd("abcabc", "abc"));
        assertEquals("abc", StringUtils.removeEnd("abcabc", null));

        assertEquals("abc", StringUtils.removeStartIgnoreCase("ABCabc", "abc"));
        assertEquals("abc", StringUtils.removeEndIgnoreCase("abcABC", "abc"));
        assertEquals("abcabc", StringUtils.removeIgnoreCase("abcXXXabc", "xxx"));
    }

    @Test
    void testRemoveFirstAndAll() {
        assertNull(StringUtils.removeAll(null, "a"));
        assertEquals("-", StringUtils.removeAll("A<__>\n<__>B", "<__>\\n?"));
        assertNull(StringUtils.removeFirst(null, "a"));
        assertEquals("foo", StringUtils.removeFirst("foo<bar>", "<.*>"));
    }

    @Test
    void testRemovePattern() {
        assertNull(StringUtils.removePattern(null, "x"));
        assertEquals("AB", StringUtils.removePattern("A<_>\n<_>B", "<.*>"));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("zzz", StringUtils.replace("aaa", "a", "z"));
        assertEquals("zza", StringUtils.replace("aaa", "a", "z", 2));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
    }

    @Test
    void testReplaceOnce() {
        assertNull(StringUtils.replaceOnce(null, "a", "b"));
        assertEquals("zaa", StringUtils.replaceOnce("aaa", "a", "z"));
        assertEquals("zaa", StringUtils.replaceOnceIgnoreCase("Aaa", "a", "z"));
    }

    @Test
    void testReplaceIgnoreCase() {
        assertEquals("zzz", StringUtils.replaceIgnoreCase("AaA", "a", "z"));
        assertEquals("zzA", StringUtils.replaceIgnoreCase("AaA", "a", "z", 2));
    }

    @Test
    void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abcde", new String[] {"ab"}, new String[] {"w", "t"});
            }
        });
    }

    @Test
    void testReplaceEachRepeatedly() {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"wd", "t"}));
    }

    @Test
    void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, "a", "b"));
        assertEquals("jelly", StringUtils.replaceChars("hello", "ho", "jy"));
        assertEquals("ab", StringUtils.replaceChars("abc", "c", null));
    }

    @Test
    void testReplaceAllAndFirstAndPattern() {
        assertNull(StringUtils.replaceAll(null, "a", "b"));
        assertEquals("foo", StringUtils.replaceAll("<_><_>foo", "<_>", ""));
        assertNull(StringUtils.replaceFirst(null, "a", "b"));
        assertEquals("foo<_>", StringUtils.replaceFirst("<_>foo<_>", "<_>", ""));
        assertEquals("AB", StringUtils.replacePattern("A<__>\n<__>B", "<.*>", ""));
    }

    @Test
    void testOverlay() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertNull(StringUtils.overlay(null, "x", 0, 0));
    }

    // ---------------------------------------------------------------
    // defaults
    // ---------------------------------------------------------------

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
    }

    @Test
    void testDefaultIfEmptyAndBlank() {
        assertEquals("NULL", StringUtils.defaultIfEmpty(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfBlank(null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NULL"));
    }

    @Test
    void testFirstNonEmptyBlank() {
        assertNull(StringUtils.firstNonEmpty());
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonBlank((CharSequence[]) null));
        assertEquals("abc", StringUtils.firstNonBlank(null, " ", "abc"));
    }

    @Test
    void testGetIfEmptyAndBlank() {
        assertEquals("NULL", StringUtils.getIfEmpty(null, new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "NULL";
            }
        }));
        assertEquals("abc", StringUtils.getIfEmpty("abc", new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "NULL";
            }
        }));
        assertEquals("NULL", StringUtils.getIfBlank("  ", new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "NULL";
            }
        }));
    }

    // ---------------------------------------------------------------
    // misc
    // ---------------------------------------------------------------

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(3, StringUtils.countMatches("aaa", "a"));
        assertEquals(2, StringUtils.countMatches("ababa", "ab"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat(null, "-", -1));
        assertEquals("a-b-c", StringUtils.repeat("a-b-c", 1));
        assertEquals("ab-ab-ab", StringUtils.repeat("ab", "-", 3));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    void testReverseDelimited() {
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("a", StringUtils.reverseDelimited("a", '.'));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, ".", 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 10));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("", StringUtils.chomp(""));

        assertNull(StringUtils.chop(null));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop(""));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 3));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertEquals("cde", StringUtils.truncate("abcdefg", 2, 3));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1, 3);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", 0, -1);
            }
        });
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("xabcx", StringUtils.wrap("abc", "x"));

        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));

        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
        assertEquals("'abc'", StringUtils.wrapIfMissing("abc", "'"));
    }

    @Test
    void testAppendPrependIfMissing() {
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));

        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd", "ab"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("i18n", StringUtils.getCommonPrefix("i18n", "i18n"));
    }

    @Test
    void testDifference() {
        assertEquals("", StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("ty", StringUtils.difference("abcde", "abcty"));
        assertEquals("", StringUtils.difference("abc", "abc"));
    }

    @Test
    void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("1800100200", StringUtils.getDigits("1800 100 200"));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    @Test
    void testToCodePoints() {
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
    }

    @Test
    void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    void testGetBytes() throws UnsupportedEncodingException {
        assertNull(StringUtils.getBytes(null, StandardCharsets.UTF_8));
        assertArrayEquals("abc".getBytes(StandardCharsets.UTF_8), StringUtils.getBytes("abc", StandardCharsets.UTF_8));
        assertArrayEquals("abc".getBytes("UTF-8"), StringUtils.getBytes("abc", "UTF-8"));
        assertNull(StringUtils.getBytes(null, "UTF-8"));
        assertThrows(UnsupportedEncodingException.class, new Executable() {
            @Override
            public void execute() throws UnsupportedEncodingException {
                StringUtils.getBytes("abc", "NOT-A-REAL-CHARSET");
            }
        });
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(7, StringUtils.getLevenshteinDistance("", "elephant"));
        assertEquals(1, StringUtils.getLevenshteinDistance("foo", "foo"));
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
        assertEquals(1, StringUtils.getLevenshteinDistance("Apache", "apache", 1) == -1 ? -1 : 1);
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 3));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    @Test
    void testGetFuzzyDistance() {
        assertEquals(3, StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH));
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance("a", "b", null);
            }
        });
    }

    @Test
    void testGetJaroWinklerDistance() {
        assertEquals(0.93d, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.01d);
        assertEquals(1.0d, StringUtils.getJaroWinklerDistance("", ""), 0.01d);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "a");
            }
        });
    }

    @Test
    void testToEncodedStringAndToString() {
        final byte[] bytes = "abc".getBytes(StandardCharsets.UTF_8);
        assertEquals("abc", StringUtils.toEncodedString(bytes, StandardCharsets.UTF_8));
        assertEquals("abc", StringUtils.toString(bytes, "UTF-8"));
        assertNull(StringUtils.toString((byte[]) null, "UTF-8"));
    }

    @Test
    void testValueOf() {
        final char[] chars = {'a', 'b', 'c'};
        assertEquals("abc", StringUtils.valueOf(chars));
        assertNull(StringUtils.valueOf((char[]) null));
    }

    /**
     * Minimal local stand-in for {@code org.junit.jupiter.api.function.Executable}
     * to keep this test class fully self-contained and avoid depending on a
     * lambda (not permitted at the project's --release 8 source level here).
     */
    private interface Executable extends org.junit.jupiter.api.function.Executable {
    }
}
