/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    /**
     * A simple fixture with a mix of field types, used to exercise the
     * reflection based hash code methods.
     */
    static class ReflectionFixture {
        @SuppressWarnings("unused")
        private final transient int transientField = 7;
        @SuppressWarnings("unused")
        private final int intField;
        @SuppressWarnings("unused")
        private final String stringField;
        @SuppressWarnings("unused")
        private static final int staticField = 99;

        ReflectionFixture(final int intField, final String stringField) {
            this.intField = intField;
            this.stringField = stringField;
        }
    }

    static class ExcludeFieldFixture {
        @SuppressWarnings("unused")
        private final int included;
        @HashCodeExclude
        @SuppressWarnings("unused")
        private final int excluded;

        ExcludeFieldFixture(final int included, final int excluded) {
            this.included = included;
            this.excluded = excluded;
        }
    }

    static class ReflectionSub extends ReflectionFixture {
        @SuppressWarnings("unused")
        private final int subField;

        ReflectionSub(final int intField, final String stringField, final int subField) {
            super(intField, stringField);
            this.subField = subField;
        }
    }

    static class GrandParentFixture {
        @SuppressWarnings("unused")
        private final int grandField;

        GrandParentFixture(final int grandField) {
            this.grandField = grandField;
        }
    }

    static class ParentFixture extends GrandParentFixture {
        @SuppressWarnings("unused")
        private final int parentField;

        ParentFixture(final int grandField, final int parentField) {
            super(grandField);
            this.parentField = parentField;
        }
    }

    static class ChildFixture extends ParentFixture {
        @SuppressWarnings("unused")
        private final int childField;

        ChildFixture(final int grandField, final int parentField, final int childField) {
            super(grandField, parentField);
            this.childField = childField;
        }
    }

    static class SelfReferencingFixture {
        @SuppressWarnings("unused")
        private SelfReferencingFixture other;
        @SuppressWarnings("unused")
        private final int value;

        SelfReferencingFixture(final int value) {
            this.value = value;
        }
    }

    @Test
    void testDefaultConstructorMatchesExplicit17And37() {
        final HashCodeBuilder defaultBuilder = new HashCodeBuilder();
        final HashCodeBuilder explicitBuilder = new HashCodeBuilder(17, 37);
        assertEquals(explicitBuilder.toHashCode(), defaultBuilder.toHashCode());
    }

    @Test
    void testConstructorRejectsEvenInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(18, 37);
            }
        });
    }

    @Test
    void testConstructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 38);
            }
        });
    }

    @Test
    void testConstructorRejectsZeroInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(0, 37);
            }
        });
    }

    @Test
    void testConstructorRejectsZeroMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 0);
            }
        });
    }

    @Test
    void testConstructorAllowsNegativeOddNumbers() {
        final HashCodeBuilder builder = new HashCodeBuilder(-17, -37);
        assertEquals(-17, builder.toHashCode());
    }

    @Test
    void testAppendBoolean() {
        assertEquals(17 * 37 + 0, new HashCodeBuilder(17, 37).append(true).toHashCode());
        assertEquals(17 * 37 + 1, new HashCodeBuilder(17, 37).append(false).toHashCode());
    }

    @Test
    void testAppendBooleanArrayNull() {
        final boolean[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendBooleanArrayMatchesElementwise() {
        final boolean[] array = {true, false, true};
        final int expected = new HashCodeBuilder(17, 37).append(true).append(false).append(true).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendByte() {
        assertEquals(17 * 37 + 5, new HashCodeBuilder(17, 37).append((byte) 5).toHashCode());
    }

    @Test
    void testAppendByteArrayNull() {
        final byte[] nullArray = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(nullArray).toHashCode());
    }

    @Test
    void testAppendChar() {
        assertEquals(17 * 37 + 'a', new HashCodeBuilder(17, 37).append('a').toHashCode());
    }

    @Test
    void testAppendDoubleMatchesDoubleToLongBits() {
        final double value = 3.14159;
        final long bits = Double.doubleToLongBits(value);
        final int expected = new HashCodeBuilder(17, 37).append(bits).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void testAppendDoubleArrayNull() {
        final double[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendFloatMatchesFloatToIntBits() {
        final float value = 2.5f;
        final int bits = Float.floatToIntBits(value);
        assertEquals(17 * 37 + bits, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void testAppendInt() {
        assertEquals(17 * 37 + 42, new HashCodeBuilder(17, 37).append(42).toHashCode());
    }

    @Test
    void testAppendIntArray() {
        final int[] array = {1, 2, 3};
        final int expected = new HashCodeBuilder(17, 37).append(1).append(2).append(3).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendLongUsesXorShift() {
        final long value = 123456789012345L;
        final int expected = 17 * 37 + (int) (value ^ value >> 32);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void testAppendObjectNull() {
        final Object nullObject = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(nullObject).toHashCode());
    }

    @Test
    void testAppendObjectUsesHashCode() {
        final String value = "test";
        assertEquals(17 * 37 + value.hashCode(), new HashCodeBuilder(17, 37).append((Object) value).toHashCode());
    }

    @Test
    void testAppendObjectThatIsArrayDelegatesToArrayAppend() {
        final int[] array = {4, 5};
        final Object asObject = array;
        final int expected = new HashCodeBuilder(17, 37).append(array).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(asObject).toHashCode());
    }

    @Test
    void testAppendObjectArrayNull() {
        final Object[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendObjectArrayWithNullElements() {
        final Object[] array = {"a", null, "b"};
        final int expected = new HashCodeBuilder(17, 37).append((Object) "a").append((Object) null).append((Object) "b").toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendShort() {
        assertEquals(17 * 37 + 9, new HashCodeBuilder(17, 37).append((short) 9).toHashCode());
    }

    @Test
    void testAppendSuper() {
        assertEquals(17 * 37 + 123, new HashCodeBuilder(17, 37).appendSuper(123).toHashCode());
    }

    @Test
    void testReflectionHashCodeWithSelfReferenceDoesNotInfiniteLoop() {
        final SelfReferencingFixture fixture = new SelfReferencingFixture(5);
        fixture.other = fixture;
        final int first = HashCodeBuilder.reflectionHashCode(fixture);
        final int second = HashCodeBuilder.reflectionHashCode(fixture);
        assertEquals(first, second);
    }

    @Test
    void testAppendDetectsCycleAndSkipsRegisteredObject() {
        final Object[] array = new Object[2];
        array[0] = "a";
        array[1] = array;
        final int expected = new HashCodeBuilder(17, 37).append((Object) "a").toHashCode() * 37;
        final int actual = new HashCodeBuilder(17, 37).append((Object) array).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testChainedAppendsAreOrderSensitive() {
        final int ab = new HashCodeBuilder(17, 37).append(1).append(2).toHashCode();
        final int ba = new HashCodeBuilder(17, 37).append(2).append(1).toHashCode();
        assertNotEquals(ab, ba);
    }

    @Test
    void testToHashCodeConsistentAcrossCalls() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(5).append("x");
        final int first = builder.toHashCode();
        final int second = builder.toHashCode();
        assertEquals(first, second);
    }

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(5);
        assertEquals(Integer.valueOf(builder.toHashCode()), builder.build());
    }

    @Test
    void testAppendReturnsSameInstanceForChaining() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        final HashCodeBuilder returned = builder.append(1);
        assertSame(builder, returned);
    }

    @Test
    void testEqualsBasedOnTotal() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1).append("x");
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(1).append("x");
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsReflexive() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        assertTrue(a.equals(a));
    }

    @Test
    void testEqualsFalseForNull() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        assertFalse(a.equals(null));
    }

    @Test
    void testEqualsFalseForDifferentType() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        assertFalse(a.equals("not a HashCodeBuilder"));
    }

    @Test
    void testEqualsFalseWhenTotalsDiffer() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(2);
        assertFalse(a.equals(b));
    }

    @Test
    void testHashCodeReturnsToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(99);
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    @Test
    void testStaticBuilderFactoryProducesWorkingInstance() {
        final HashCodeBuilder.Builder factory = HashCodeBuilder.builder();
        assertNotNull(factory);
        final HashCodeBuilder.Builder configured = factory.setInitialOddNumber(21).setMultiplierOddNumber(41);
        assertSame(factory, configured);
        final HashCodeBuilder built = configured.get();
        assertEquals(21, built.toHashCode());
        final HashCodeBuilder expected = new HashCodeBuilder(21, 41).append(5);
        built.append(5);
        assertEquals(expected.toHashCode(), built.toHashCode());
    }

    @Test
    void testReflectionHashCodeEqualInstancesMatch() {
        final ReflectionFixture one = new ReflectionFixture(1, "abc");
        final ReflectionFixture two = new ReflectionFixture(1, "abc");
        assertEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    void testReflectionHashCodeDifferentInstancesDiffer() {
        final ReflectionFixture one = new ReflectionFixture(1, "abc");
        final ReflectionFixture two = new ReflectionFixture(2, "abc");
        assertNotEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    void testReflectionHashCodeNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null);
            }
        });
    }

    @Test
    void testReflectionHashCodeWithTwoArgNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, true);
            }
        });
    }

    @Test
    void testReflectionHashCodeWithConstantsRejectsEvenInitial() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "abc");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(18, 37, fixture);
            }
        });
    }

    @Test
    void testReflectionHashCodeExcludesStaticField() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "abc");
        final int withoutExcludes = HashCodeBuilder.reflectionHashCode(fixture);
        final int excludingStatic = HashCodeBuilder.reflectionHashCode(fixture, "staticField");
        assertEquals(withoutExcludes, excludingStatic);
    }

    @Test
    void testReflectionHashCodeExcludeFieldChangesResult() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "abc");
        final int full = HashCodeBuilder.reflectionHashCode(fixture);
        final int excluded = HashCodeBuilder.reflectionHashCode(fixture, "intField");
        assertNotEquals(full, excluded);
    }

    @Test
    void testReflectionHashCodeExcludeFieldsWithCollection() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "abc");
        final List<String> excludes = Arrays.asList("intField");
        final int viaCollection = HashCodeBuilder.reflectionHashCode(fixture, excludes);
        final int viaArray = HashCodeBuilder.reflectionHashCode(fixture, "intField");
        assertEquals(viaArray, viaCollection);
    }

    @Test
    void testReflectionHashCodeHonorsHashCodeExcludeAnnotation() {
        final ExcludeFieldFixture withExcludedFive = new ExcludeFieldFixture(1, 5);
        final ExcludeFieldFixture withExcludedNine = new ExcludeFieldFixture(1, 9);
        assertEquals(HashCodeBuilder.reflectionHashCode(withExcludedFive), HashCodeBuilder.reflectionHashCode(withExcludedNine));
    }

    @Test
    void testReflectionHashCodeIgnoresTransientByDefault() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "abc");
        final int ignoringTransient = HashCodeBuilder.reflectionHashCode(fixture, false);
        final int testingTransient = HashCodeBuilder.reflectionHashCode(17, 37, fixture, true);
        assertEquals(ignoringTransient, HashCodeBuilder.reflectionHashCode(17, 37, fixture, false));
        assertNotEquals(ignoringTransient, testingTransient);
    }

    @Test
    void testReflectionHashCodeIncludesSuperclassFields() {
        final ReflectionSub a = new ReflectionSub(1, "abc", 10);
        final ReflectionSub b = new ReflectionSub(1, "abc", 20);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void testReflectionHashCodeUpToSuperclassExcludesAncestorFields() {
        final ChildFixture a = new ChildFixture(10, 2, 3);
        final ChildFixture b = new ChildFixture(20, 2, 3);
        final int hashA = HashCodeBuilder.reflectionHashCode(17, 37, a, false, ParentFixture.class);
        final int hashB = HashCodeBuilder.reflectionHashCode(17, 37, b, false, ParentFixture.class);
        assertEquals(hashA, hashB);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void testReflectionHashCodeWithVarargsExcludeFieldsNoneProvided() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "abc");
        assertEquals(HashCodeBuilder.reflectionHashCode(fixture), HashCodeBuilder.reflectionHashCode(fixture, new String[0]));
    }

    @Test
    void testReflectionHashCodeDifferentObjectsSameStateAreNotSameInstance() {
        final ReflectionFixture one = new ReflectionFixture(1, "abc");
        final ReflectionFixture two = new ReflectionFixture(1, "abc");
        assertNotSame(one, two);
        assertEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }
}
