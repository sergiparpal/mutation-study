package org.apache.commons.lang3.builder;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class RecursiveToStringStyleAgentTest {

    static class Job {
        String title = "Manager";
    }

    static class Person {
        String name = "Stephen";
        int age = 29;
        boolean smoker = false;
        Job job = new Job();
    }

    @Test
    public void testConstructorCreatesUsableInstance() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertNotNull(style);
        assertTrue(style instanceof ToStringStyle);
        assertTrue(style instanceof Serializable);
    }

    @Test
    public void testInstanceIsSerializable() throws Exception {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(style);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        Object result = ois.readObject();
        ois.close();

        assertNotNull(result);
        assertTrue(result instanceof RecursiveToStringStyle);
    }

    @Test
    public void testAcceptFiltersBoxedPrimitives() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertFalse(style.accept(Boolean.class));
        assertFalse(style.accept(Byte.class));
        assertFalse(style.accept(Character.class));
        assertFalse(style.accept(Short.class));
        assertFalse(style.accept(Integer.class));
        assertFalse(style.accept(Long.class));
        assertFalse(style.accept(Float.class));
        assertFalse(style.accept(Double.class));
    }

    @Test
    public void testAcceptFiltersString() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertFalse(style.accept(String.class));
    }

    @Test
    public void testAcceptFiltersNumberSubclasses() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertFalse(style.accept(BigDecimal.class));
        assertFalse(style.accept(AtomicInteger.class));
    }

    @Test
    public void testAcceptFiltersAtomicBoolean() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertFalse(style.accept(AtomicBoolean.class));
    }

    @Test
    public void testAcceptFiltersMutableBoolean() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertFalse(style.accept(org.apache.commons.lang3.mutable.MutableBoolean.class));
    }

    @Test
    public void testAcceptAllowsArbitraryClasses() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertTrue(style.accept(Object.class));
        assertTrue(style.accept(Job.class));
        assertTrue(style.accept(Person.class));
    }

    @Test
    public void testAcceptAllowsPrimitiveTypes() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertTrue(style.accept(int.class));
        assertTrue(style.accept(boolean.class));
    }

    @Test
    public void testAppendDetailObjectRecursesIntoAcceptedClass() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "job", new Job());

        String result = buffer.toString();
        assertTrue(result.length() > 0);
        assertTrue(result.contains("title=Manager"));
    }

    @Test
    public void testAppendDetailObjectRecursesThroughMultipleLevels() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "person", new Person());

        String result = buffer.toString();
        assertTrue(result.contains("name=Stephen"));
        assertTrue(result.contains("age=29"));
        assertTrue(result.contains("smoker=false"));
        assertTrue(result.contains("title=Manager"));
    }

    @Test
    public void testAppendDetailObjectDoesNotRecurseIntoString() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "s", "hello");

        String result = buffer.toString();
        assertTrue(result.contains("hello"));
        assertFalse(result.contains("["));
    }

    @Test
    public void testAppendDetailObjectDoesNotRecurseIntoNumber() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();

        style.appendDetail(buffer, "n", Integer.valueOf(42));

        String result = buffer.toString();
        assertTrue(result.contains("42"));
        assertFalse(result.contains("["));
    }

    @Test
    public void testAppendDetailObjectFieldNameDoesNotAffectOutput() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer bufferWithName = new StringBuffer();
        StringBuffer bufferWithNullName = new StringBuffer();

        style.appendDetail(bufferWithName, "n", Integer.valueOf(7));
        style.appendDetail(bufferWithNullName, null, Integer.valueOf(7));

        assertEquals(bufferWithName.toString(), bufferWithNullName.toString());
    }

    @Test
    public void testAppendDetailObjectNullValueThrows() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();

        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                style.appendDetail(buffer, "n", (Object) null);
            }
        });
    }

    @Test
    public void testAppendDetailObjectNullBufferThrows() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();

        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                style.appendDetail(null, "n", Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testAppendDetailCollectionWithAcceptedElement() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();
        List<Job> jobs = new ArrayList<Job>();
        jobs.add(new Job());

        style.appendDetail(buffer, "jobs", jobs);

        String result = buffer.toString();
        assertTrue(result.length() > 0);
        assertTrue(result.contains("title=Manager"));
    }

    @Test
    public void testAppendDetailCollectionWithNonAcceptedElement() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();
        List<String> values = new ArrayList<String>();
        values.add("foo");

        style.appendDetail(buffer, "values", values);

        assertTrue(buffer.toString().contains("foo"));
    }

    @Test
    public void testAppendDetailCollectionEmptyDoesNotThrow() {
        RecursiveToStringStyle style = new RecursiveToStringStyle();
        StringBuffer buffer = new StringBuffer();
        List<Object> empty = new ArrayList<Object>();

        style.appendDetail(buffer, "empty", empty);

        assertNotNull(buffer.toString());
    }

    @Test
    public void testAppendDetailCollectionNullThrows() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();

        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                style.appendDetail(buffer, "coll", (Collection<?>) null);
            }
        });
    }
}
