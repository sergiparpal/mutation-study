/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link LocaleUtils}.
 */
public class LocaleUtilsAgentTest {

    @Test
    public void testAvailableLocaleListAndSet() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(list);
        assertNotNull(set);
        assertFalse(list.isEmpty());
        assertFalse(set.isEmpty());
        assertTrue(list.contains(Locale.US));
        assertTrue(set.contains(Locale.US));
        assertEquals(list.size(), set.size());
        // Calling again must return the exact same cached instances.
        assertTrue(list == LocaleUtils.availableLocaleList());
        assertTrue(set == LocaleUtils.availableLocaleSet());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.CANADA);
            }
        });
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                set.add(Locale.CANADA);
            }
        });
    }

    @Test
    public void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("zz", "ZZ", "zzzz")));
    }

    @Test
    public void testCountriesByLanguageNullAndInvalid() {
        assertTrue(LocaleUtils.countriesByLanguage(null).isEmpty());
        // Uppercase is not a valid ISO 639 code (must be lowercase), so this short-circuits to empty.
        assertTrue(LocaleUtils.countriesByLanguage("EN").isEmpty());
        // A single character is not a valid 2- or 3-letter ISO 639 code.
        assertTrue(LocaleUtils.countriesByLanguage("e").isEmpty());
    }

    @Test
    public void testCountriesByLanguageValid() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertNotNull(result);
        for (final Locale locale : result) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                result.add(Locale.US);
            }
        });
        // Second call must be served from the cache.
        assertTrue(result == LocaleUtils.countriesByLanguage("en"));
        assertTrue(LocaleUtils.getLcToLocalesMap().containsKey("en"));
    }

    @Test
    public void testCountriesByLanguageEmptyString() {
        // An empty language code does not short-circuit; it is looked up directly.
        final List<Locale> result = LocaleUtils.countriesByLanguage("");
        assertNotNull(result);
        for (final Locale locale : result) {
            assertEquals("", locale.getLanguage());
        }
    }

    @Test
    public void testLanguagesByCountryNullAndInvalid() {
        assertTrue(LocaleUtils.languagesByCountry(null).isEmpty());
        // Lowercase is not a valid ISO 3166 alpha-2 code (must be uppercase) and is not 3 digits either.
        assertTrue(LocaleUtils.languagesByCountry("us").isEmpty());
        // A single character cannot be a 2-letter country code or a 3-digit numeric area code.
        assertTrue(LocaleUtils.languagesByCountry("U").isEmpty());
    }

    @Test
    public void testLanguagesByCountryValid() {
        final List<Locale> result = LocaleUtils.languagesByCountry("US");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        for (final Locale locale : result) {
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                result.add(Locale.US);
            }
        });
        assertTrue(result == LocaleUtils.languagesByCountry("US"));
        assertTrue(LocaleUtils.getCcToLocalesMap().containsKey("US"));
    }

    @Test
    public void testLanguagesByCountryNumericAreaCode() {
        final List<Locale> result = LocaleUtils.languagesByCountry("001");
        assertNotNull(result);
        for (final Locale locale : result) {
            assertEquals("001", locale.getCountry());
        }
    }

    @Test
    public void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("e2")));
    }

    @Test
    public void testLocaleLookupListSingleArg() {
        assertTrue(LocaleUtils.localeLookupList(null).isEmpty());

        final List<Locale> fr = LocaleUtils.localeLookupList(new Locale("fr"));
        assertEquals(1, fr.size());
        assertEquals(new Locale("fr"), fr.get(0));

        final List<Locale> frCaXxx = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertEquals(3, frCaXxx.size());
        assertEquals(new Locale("fr", "CA", "xxx"), frCaXxx.get(0));
        assertEquals(new Locale("fr", "CA"), frCaXxx.get(1));
        assertEquals(new Locale("fr"), frCaXxx.get(2));

        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                fr.add(Locale.US);
            }
        });
    }

    @Test
    public void testLocaleLookupListTwoArgs() {
        // Null starting locale always yields an empty list, regardless of the default locale.
        assertTrue(LocaleUtils.localeLookupList(null, Locale.US).isEmpty());

        final List<Locale> result = LocaleUtils.localeLookupList(new Locale("fr"), new Locale("en"));
        assertEquals(2, result.size());
        assertEquals(new Locale("fr"), result.get(0));
        assertEquals(new Locale("en"), result.get(1));

        // Default locale already present in the derived list must not be duplicated.
        final List<Locale> noDup = LocaleUtils.localeLookupList(new Locale("fr", "CA"), new Locale("fr"));
        assertEquals(2, noDup.size());
        assertEquals(new Locale("fr", "CA"), noDup.get(0));
        assertEquals(new Locale("fr"), noDup.get(1));
    }

    @Test
    public void testToLocaleFromLocale() {
        assertEquals(Locale.FRANCE, LocaleUtils.toLocale(Locale.FRANCE));
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    @Test
    public void testToLocaleStringNullAndEmpty() {
        assertNull(LocaleUtils.toLocale((String) null));
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    public void testToLocaleStringValidForms() {
        assertEquals(new Locale("en"), LocaleUtils.toLocale("en"));
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en-GB-xxx"));
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("_GB"));
        assertEquals(new Locale("", "GB", "xxx"), LocaleUtils.toLocale("_GB_xxx"));
    }

    @Test
    public void testToLocaleStringSpecialCases() {
        assertEquals(new Locale("th", "TH", "TH"), LocaleUtils.toLocale("th_TH_TH_#u-nu-thai"));
        assertEquals(new Locale("ja", "JP", "JP"), LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese"));
    }

    @Test
    public void testToLocaleStringTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingSeparatorTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingSeparatorLowerCase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingSeparatorBadVariantSeparator() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBxxx");
            }
        });
    }

    @Test
    public void testToLocaleStringEmptyVariant() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_GB_");
            }
        });
    }

    @Test
    public void testToLocaleStringUnparsable() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("!!");
            }
        });
    }

    @Test
    public void testOfCountry() {
        assertEquals(new Locale("", "US"), LocaleUtils.ofCountry("US"));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.ofCountry(null);
            }
        });
    }

    @Test
    public void testCacheMapAccessors() {
        final ConcurrentMap<String, List<Locale>> ccMap = LocaleUtils.getCcToLocalesMap();
        final ConcurrentMap<String, List<Locale>> lcMap = LocaleUtils.getLcToLocalesMap();
        assertNotNull(ccMap);
        assertNotNull(lcMap);
        LocaleUtils.languagesByCountry("GB");
        LocaleUtils.countriesByLanguage("de");
        assertTrue(ccMap.containsKey("GB"));
        assertTrue(lcMap.containsKey("de"));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructor() {
        assertNotNull(new LocaleUtils());
    }
}
