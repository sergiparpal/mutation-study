/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class FractionAgentTest {

    @Test
    public void testGetFractionDoubleBasic() {
        assertEquals(Fraction.getFraction(3, 2), Fraction.getFraction(1.5));
        assertEquals(Fraction.getFraction(1, 10), Fraction.getFraction(0.1));
        assertEquals(Fraction.getFraction(-11, 4), Fraction.getFraction(-2.75));
        assertEquals(Fraction.getFraction(5, 1), Fraction.getFraction(5.0));
        assertEquals(Fraction.ZERO, Fraction.getFraction(0.0));
    }

    @Test
    public void testGetFractionDoubleBoundaries() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE + 100.0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntIntOverflowOnNegate() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, Integer.MIN_VALUE);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom() {
        final Fraction f = Fraction.getFraction(1, 3, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 4);
        assertEquals(-7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenomErrorCases() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, 0);
            }
        });
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, -4);
            }
        });
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -3, 4);
            }
        });
    }

    @Test
    public void testGetFractionStringDoubleFormat() {
        final Fraction f = Fraction.getFraction("1.5");
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumeratorDenominatorFormat() {
        final Fraction f = Fraction.getFraction("1 3/4");
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNumeratorDenominatorFormat() {
        final Fraction f = Fraction.getFraction("7/3");
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumberFormat() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringInvalidWholeFormatThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 2");
            }
        });
    }

    @Test
    public void testGetFractionStringNonNumericThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("abc");
            }
        });
    }

    @Test
    public void testGetReducedFractionReduces() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorNormalizesToZeroInstance() {
        assertSame(Fraction.ZERO, Fraction.getReducedFraction(0, 5));
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetReducedFractionMinValueDenominatorEvenNumerator() {
        final Fraction f = Fraction.getReducedFraction(2, Integer.MIN_VALUE);
        assertEquals(-1, f.getNumerator());
        assertEquals(1073741824, f.getDenominator());
    }

    @Test
    public void testAbs() {
        assertSame(Fraction.ONE, Fraction.ONE.abs());
        final Fraction negative = Fraction.getFraction(-3, 4);
        final Fraction result = negative.abs();
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testAddSimple() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 4));
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testAddUsesBigIntegerPathWhenGcdNotOne() {
        final Fraction result = Fraction.getFraction(1, 6).add(Fraction.getFraction(1, 4));
        assertEquals(5, result.getNumerator());
        assertEquals(12, result.getDenominator());
    }

    @Test
    public void testAddZeroIsIdentity() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertEquals(f, Fraction.ZERO.add(f));
        assertEquals(f, f.add(Fraction.ZERO));
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.getFraction(1, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                a.add(b);
            }
        });
    }

    @Test
    public void testCompareToEqualValuesDifferentReducedForm() {
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareToLessAndGreater() {
        assertTrue(Fraction.getFraction(1, 4).compareTo(Fraction.getFraction(1, 2)) < 0);
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 4)) > 0);
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction f = Fraction.getFraction(1, 3);
        assertEquals(0, f.compareTo(f));
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.compareTo(null);
            }
        });
    }

    @Test
    public void testDivideBySimple() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 4));
        assertEquals(2, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testDivideByZeroFractionThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.divideBy(null);
            }
        });
    }

    @Test
    public void testDoubleValue() {
        assertEquals(1.75d, Fraction.getFraction(7, 4).doubleValue(), 0.0d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(1.75f, Fraction.getFraction(7, 4).floatValue(), 0.0f);
    }

    @Test
    public void testIntValueTruncatesTowardZero() {
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
    }

    @Test
    public void testLongValueTruncatesTowardZero() {
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
    }

    @Test
    public void testEqualsSameValuesEqual() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
    }

    @Test
    public void testEqualsDifferentReducedFormNotEqual() {
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
    }

    @Test
    public void testEqualsDifferentTypeAndNull() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertFalse(f.equals("1/2"));
        assertFalse(f.equals(null));
        assertTrue(f.equals(f));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testGetNumeratorAndDenominator() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction positive = Fraction.getFraction(7, 4);
        assertEquals(3, positive.getProperNumerator());
        assertEquals(1, positive.getProperWhole());

        final Fraction negative = Fraction.getFraction(-7, 4);
        assertEquals(3, negative.getProperNumerator());
        assertEquals(-1, negative.getProperWhole());
    }

    @Test
    public void testInvert() {
        final Fraction f = Fraction.getFraction(3, 4);
        final Fraction inverted = f.invert();
        assertEquals(4, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvertNegativeKeepsSignOnNumerator() {
        final Fraction f = Fraction.getFraction(-3, 4);
        final Fraction inverted = f.invert();
        assertEquals(-4, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    @Test
    public void testMultiplyBySimple() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 5));
        assertEquals(2, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testMultiplyByZeroReturnsZeroInstance() {
        assertSame(Fraction.ZERO, Fraction.getFraction(5, 7).multiplyBy(Fraction.ZERO));
        assertSame(Fraction.ZERO, Fraction.ZERO.multiplyBy(Fraction.getFraction(5, 7)));
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                a.multiplyBy(b);
            }
        });
    }

    @Test
    public void testNegate() {
        final Fraction result = Fraction.getFraction(3, 4).negate();
        assertEquals(-3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testNegateMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowZeroReturnsOneEvenForZero() {
        assertSame(Fraction.ONE, Fraction.getFraction(2, 3).pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowPositive() {
        final Fraction result = Fraction.getFraction(2, 3).pow(2);
        assertEquals(4, result.getNumerator());
        assertEquals(9, result.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction result = Fraction.getFraction(2, 3).pow(-1);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testPowMinValueOnIdentityDoesNotOverflow() {
        final Fraction result = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testPowMinValueOverflowsForNonUnitFraction() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE_HALF.pow(Integer.MIN_VALUE);
            }
        });
    }

    @Test
    public void testReduce() {
        final Fraction result = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduceZeroNumeratorNonCanonicalDenominator() {
        final Fraction result = Fraction.getFraction(0, 5).reduce();
        assertEquals(0, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.reduce());
    }

    @Test
    public void testSubtractSimple() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ONE.subtract(null);
            }
        });
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.getFraction(0, 5).toProperString());
    }

    @Test
    public void testToProperStringOne() {
        assertEquals("1", Fraction.getFraction(5, 5).toProperString());
    }

    @Test
    public void testToProperStringMinusOne() {
        assertEquals("-1", Fraction.getFraction(-5, 5).toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringNegativeImproperFraction() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToString() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
        assertEquals("-7/4", Fraction.getFraction(-7, 4).toString());
    }

    @Test
    public void testIsSerializable() {
        assertTrue(Fraction.ONE instanceof Serializable);
    }

    @Test
    public void testConstantsHaveExpectedValues() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }
}
