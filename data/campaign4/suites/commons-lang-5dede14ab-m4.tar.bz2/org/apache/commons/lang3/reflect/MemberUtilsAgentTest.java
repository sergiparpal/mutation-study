/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MemberUtils}.
 */
class MemberUtilsAgentTest {

    /**
     * Package-private fixture class providing overloaded methods/constructors used to exercise
     * the parameter-matching and fitness-comparison logic in {@link MemberUtils}.
     */
    static class Sample {

        Sample(final String s) {
        }

        Sample(final Object o) {
        }

        void foo(final Object o) {
        }

        void foo(final String s) {
        }

        void oneArg(final String a) {
        }

        void takeByte(final byte b) {
        }

        void takeComparable(final Comparable<?> c) {
        }

        void takeInt(final int i) {
        }

        void takeInteger(final Integer n) {
        }

        void takeLong(final long l) {
        }

        void takeNumber(final Number n) {
        }

        void takeObject(final Object o) {
        }

        void twoArgs(final String a, final String b) {
        }

        void varArgsMethod(final String first, final Object... rest) {
        }
    }

    /**
     * Package-private fixture class with a public method, simulating a public class with
     * default (package) access whose public members need the accessibility workaround.
     */
    static class DefaultAccessHelper {
        public void publicMethod() {
        }
    }

    private Method method(final String name, final Class<?>... paramTypes) throws Exception {
        return Sample.class.getDeclaredMethod(name, paramTypes);
    }

    private Constructor<?> constructor(final Class<?> paramType) throws Exception {
        return Sample.class.getDeclaredConstructor(paramType);
    }

    // isAccessible

    @Test
    void testIsAccessibleNull() {
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    void testIsAccessiblePublicMember() throws Exception {
        final Method lengthMethod = String.class.getMethod("length");
        assertTrue(MemberUtils.isAccessible(lengthMethod));
    }

    @Test
    void testIsAccessibleNonPublicMember() throws Exception {
        final Method m = method("takeObject", Object.class);
        assertFalse(MemberUtils.isAccessible(m));
    }

    // isPublic

    @Test
    void testIsPublicNull() {
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    void testIsPublicTrue() throws Exception {
        final Method lengthMethod = String.class.getMethod("length");
        assertTrue(MemberUtils.isPublic(lengthMethod));
    }

    @Test
    void testIsPublicFalse() throws Exception {
        final Method m = method("takeObject", Object.class);
        assertFalse(MemberUtils.isPublic(m));
    }

    // isStatic

    @Test
    void testIsStaticNull() {
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    void testIsStaticTrue() throws Exception {
        final Method staticMethod = Integer.class.getMethod("valueOf", int.class);
        assertTrue(MemberUtils.isStatic(staticMethod));
    }

    @Test
    void testIsStaticFalse() throws Exception {
        final Method instanceMethod = Integer.class.getMethod("intValue");
        assertFalse(MemberUtils.isStatic(instanceMethod));
    }

    // isPackage

    @Test
    void testIsPackageDefaultAccess() {
        assertTrue(MemberUtils.isPackage(0));
    }

    @Test
    void testIsPackageWithPublic() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
    }

    @Test
    void testIsPackageWithProtected() {
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
    }

    @Test
    void testIsPackageWithPrivate() {
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    void testIsPackageUnrelatedModifierBitStillPackage() {
        // STATIC is not part of the PUBLIC/PROTECTED/PRIVATE access mask.
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
    }

    // setAccessibleWorkaround

    @Test
    void testSetAccessibleWorkaroundNull() {
        final java.lang.reflect.AccessibleObject result = MemberUtils.setAccessibleWorkaround(null);
        assertSame(null, result);
    }

    @Test
    void testSetAccessibleWorkaroundAlreadyAccessible() throws Exception {
        final Method lengthMethod = String.class.getMethod("length");
        lengthMethod.setAccessible(true);
        final Method result = MemberUtils.setAccessibleWorkaround(lengthMethod);
        assertSame(lengthMethod, result);
        assertTrue(result.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaroundPublicMemberOfPackageDefaultClass() throws Exception {
        final Method m = DefaultAccessHelper.class.getDeclaredMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaroundPublicMemberOfPublicClassUnchanged() throws Exception {
        final Method lengthMethod = String.class.getMethod("length");
        assertFalse(lengthMethod.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(lengthMethod);
        assertSame(lengthMethod, result);
        assertFalse(result.isAccessible());
    }

    // isMatchingMethod

    @Test
    void testIsMatchingMethodExactMatch() throws Exception {
        final Method fooStr = method("foo", String.class);
        assertTrue(MemberUtils.isMatchingMethod(fooStr, new Class<?>[] {String.class}));
    }

    @Test
    void testIsMatchingMethodNoMatch() throws Exception {
        final Method fooStr = method("foo", String.class);
        assertFalse(MemberUtils.isMatchingMethod(fooStr, new Class<?>[] {Integer.class}));
    }

    @Test
    void testIsMatchingMethodVarArgsNoneProvided() throws Exception {
        final Method varArgsMethod = method("varArgsMethod", String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[] {String.class}));
    }

    @Test
    void testIsMatchingMethodVarArgsExplicitArray() throws Exception {
        final Method varArgsMethod = method("varArgsMethod", String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[] {String.class, Object[].class}));
    }

    @Test
    void testIsMatchingMethodVarArgsTypical() throws Exception {
        final Method varArgsMethod = method("varArgsMethod", String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[] {String.class, Integer.class, Double.class}));
    }

    @Test
    void testIsMatchingMethodVarArgsFirstArgMismatch() throws Exception {
        final Method varArgsMethod = method("varArgsMethod", String.class, Object[].class);
        assertFalse(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[] {Integer.class, Integer.class}));
    }

    @Test
    void testIsMatchingMethodTooFewVarArgsParams() throws Exception {
        final Method varArgsMethod = method("varArgsMethod", String.class, Object[].class);
        // varargs methods require at least (declared params - 1) actual arguments.
        assertFalse(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[0]));
    }

    // isMatchingConstructor

    @Test
    void testIsMatchingConstructorMatch() throws Exception {
        final Constructor<?> ctorStr = constructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(ctorStr, new Class<?>[] {String.class}));
    }

    @Test
    void testIsMatchingConstructorNoMatch() throws Exception {
        final Constructor<?> ctorStr = constructor(String.class);
        assertFalse(MemberUtils.isMatchingConstructor(ctorStr, new Class<?>[] {Integer.class}));
    }

    // compareMethodFit

    @Test
    void testCompareMethodFitExactBeatsSuperclass() throws Exception {
        final Method takeInteger = method("takeInteger", Integer.class);
        final Method takeNumber = method("takeNumber", Number.class);
        final int result = MemberUtils.compareMethodFit(takeInteger, takeNumber, new Class<?>[] {Integer.class});
        assertTrue(result < 0);
    }

    @Test
    void testCompareMethodFitSuperclassBeatsObjectFallback() throws Exception {
        final Method takeNumber = method("takeNumber", Number.class);
        final Method takeObject = method("takeObject", Object.class);
        final int result = MemberUtils.compareMethodFit(takeNumber, takeObject, new Class<?>[] {Integer.class});
        assertTrue(result < 0);
    }

    @Test
    void testCompareMethodFitInterfaceBeatsSuperclass() throws Exception {
        final Method takeComparable = method("takeComparable", Comparable.class);
        final Method takeNumber = method("takeNumber", Number.class);
        final int result = MemberUtils.compareMethodFit(takeComparable, takeNumber, new Class<?>[] {Integer.class});
        assertTrue(result < 0);
    }

    @Test
    void testCompareMethodFitIsSymmetricInverse() throws Exception {
        final Method takeInteger = method("takeInteger", Integer.class);
        final Method takeNumber = method("takeNumber", Number.class);
        final Class<?>[] actual = {Integer.class};
        final int forward = MemberUtils.compareMethodFit(takeInteger, takeNumber, actual);
        final int backward = MemberUtils.compareMethodFit(takeNumber, takeInteger, actual);
        assertTrue(forward < 0);
        assertTrue(backward > 0);
    }

    @Test
    void testCompareMethodFitEqualWhenSameMethod() throws Exception {
        final Method takeInteger = method("takeInteger", Integer.class);
        final int result = MemberUtils.compareMethodFit(takeInteger, takeInteger, new Class<?>[] {Integer.class});
        assertEquals(0, result);
    }

    @Test
    void testCompareMethodFitPrimitivePromotion() throws Exception {
        final Method takeByte = method("takeByte", byte.class);
        final Method takeLong = method("takeLong", long.class);
        final int result = MemberUtils.compareMethodFit(takeByte, takeLong, new Class<?>[] {byte.class});
        assertTrue(result < 0);
    }

    @Test
    void testCompareMethodFitUnwrappingAndWidening() throws Exception {
        final Method takeInt = method("takeInt", int.class);
        final Method takeLong = method("takeLong", long.class);
        // Boxed Integer actual argument: takeInt only needs unwrapping, takeLong needs
        // unwrapping plus widening, so takeInt must be the better fit.
        final int result = MemberUtils.compareMethodFit(takeInt, takeLong, new Class<?>[] {Integer.class});
        assertTrue(result < 0);
    }

    @Test
    void testCompareMethodFitTooFewActualArgsIsWorst() throws Exception {
        final Method twoArgs = method("twoArgs", String.class, String.class);
        final Method oneArg = method("oneArg", String.class);
        final int result = MemberUtils.compareMethodFit(twoArgs, oneArg, new Class<?>[] {String.class});
        assertTrue(result > 0);
    }

    @Test
    void testCompareMethodFitVarArgsCostlierThanExactNonVarArgs() throws Exception {
        final Method twoArgs = method("twoArgs", String.class, String.class);
        final Method varArgsMethod = method("varArgsMethod", String.class, Object[].class);
        final int result = MemberUtils.compareMethodFit(twoArgs, varArgsMethod, new Class<?>[] {String.class, String.class});
        assertTrue(result < 0);
    }

    // compareConstructorFit

    @Test
    void testCompareConstructorFitExactBeatsSuperclass() throws Exception {
        final Constructor<?> ctorStr = constructor(String.class);
        final Constructor<?> ctorObj = constructor(Object.class);
        final int result = MemberUtils.compareConstructorFit(ctorStr, ctorObj, new Class<?>[] {String.class});
        assertTrue(result < 0);
    }

    @Test
    void testCompareConstructorFitEqualWhenSameConstructor() throws Exception {
        final Constructor<?> ctorStr = constructor(String.class);
        final int result = MemberUtils.compareConstructorFit(ctorStr, ctorStr, new Class<?>[] {String.class});
        assertEquals(0, result);
    }
}
