/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    // ---- constants ----

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue());
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue());
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue());
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue());
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue());
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue());
        assertEquals(Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals(Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testConstructor() {
        // deprecated public constructor must still be usable
        assertTrue(new NumberUtils() instanceof NumberUtils);
    }

    // ---- compare ----

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 5) < 0);
        assertTrue(NumberUtils.compare((byte) 5, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 5) < 0);
        assertTrue(NumberUtils.compare(5, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 5L) < 0);
        assertTrue(NumberUtils.compare(5L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 5) < 0);
        assertTrue(NumberUtils.compare((short) 5, (short) 1) > 0);
    }

    // ---- createBigDecimal ----

    @Test
    void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    void testCreateBigDecimalEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    @Test
    void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---- createBigInteger ----

    @Test
    void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("255"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-255"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("-FF", 16), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    @Test
    void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ---- createDouble ----

    @Test
    void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // ---- createFloat ----

    @Test
    void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---- createInteger ----

    @Test
    void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    void testCreateIntegerValid() {
        assertEquals(Integer.valueOf(42), NumberUtils.createInteger("42"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    void testCreateIntegerInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // ---- createLong ----

    @Test
    void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    void testCreateLongValid() {
        assertEquals(Long.valueOf(42L), NumberUtils.createLong("42"));
    }

    @Test
    void testCreateLongInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---- createNumber ----

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("  ");
            }
        });
    }

    @Test
    void testCreateNumberInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    void testCreateNumberLongOverflowToLong() {
        final Number n = NumberUtils.createNumber("" + ((long) Integer.MAX_VALUE + 1L));
        assertTrue(n instanceof Long);
    }

    @Test
    void testCreateNumberBigIntegerOverflow() {
        final Number n = NumberUtils.createNumber("" + Long.MAX_VALUE + "0");
        assertTrue(n instanceof BigInteger);
    }

    @Test
    void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue());
    }

    @Test
    void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue());
    }

    @Test
    void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    void testCreateNumberDecimalNoSuffix() {
        final Number n = NumberUtils.createNumber("3.14");
        assertTrue(n instanceof Float || n instanceof Double);
        assertEquals(3.14d, n.doubleValue(), 0.0001d);
    }

    @Test
    void testCreateNumberInvalidLongSuffixThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    @Test
    void testCreateNumberInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("not a number");
            }
        });
    }

    // ---- isCreatable / isNumber ----

    @Test
    void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
    }

    @Test
    void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsNumberDelegatesToIsCreatable() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
    }

    // ---- isDigits ----

    @Test
    void testIsDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    // ---- isParsable ----

    @Test
    void testIsParsable() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ---- max/min array ----

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMaxThreeByte() {
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 9, (byte) 5));
        assertEquals((byte) 9, NumberUtils.max((byte) 9, (byte) 1, (byte) 5));
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 5, (byte) 9));
    }

    @Test
    void testMaxDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d));
    }

    @Test
    void testMaxThreeDouble() {
        assertEquals(9.0d, NumberUtils.max(1.0d, 9.0d, 5.0d));
    }

    @Test
    void testMaxFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMaxThreeFloat() {
        assertEquals(9.0f, NumberUtils.max(1.0f, 9.0f, 5.0f));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(1, 9, 5));
    }

    @Test
    void testMaxIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
    }

    @Test
    void testMaxIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMaxThreeInt() {
        assertEquals(9, NumberUtils.max(1, 9, 5));
        assertEquals(9, NumberUtils.max(9, 1, 5));
        assertEquals(9, NumberUtils.max(1, 5, 9));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 5L));
    }

    @Test
    void testMaxThreeLong() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 5L));
        assertEquals(9L, NumberUtils.max(9L, 1L, 5L));
        assertEquals(9L, NumberUtils.max(1L, 5L, 9L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 5));
    }

    @Test
    void testMaxThreeShort() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 5));
        assertEquals((short) 9, NumberUtils.max((short) 9, (short) 1, (short) 5));
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 5, (short) 9));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 5, (byte) 1, (byte) 3));
    }

    @Test
    void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMinThreeByte() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 9, (byte) 5));
        assertEquals((byte) 1, NumberUtils.min((byte) 9, (byte) 1, (byte) 5));
        assertEquals((byte) 1, NumberUtils.min((byte) 9, (byte) 5, (byte) 1));
    }

    @Test
    void testMinDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(5.0d, 1.0d, 3.0d));
    }

    @Test
    void testMinThreeDouble() {
        assertEquals(1.0d, NumberUtils.min(9.0d, 1.0d, 5.0d));
    }

    @Test
    void testMinFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMinThreeFloat() {
        assertEquals(1.0f, NumberUtils.min(9.0f, 1.0f, 5.0f));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(5, 1, 9));
    }

    @Test
    void testMinIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
    }

    @Test
    void testMinIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMinThreeInt() {
        assertEquals(1, NumberUtils.min(1, 9, 5));
        assertEquals(1, NumberUtils.min(9, 1, 5));
        assertEquals(1, NumberUtils.min(9, 5, 1));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(5L, 1L, 9L));
    }

    @Test
    void testMinThreeLong() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 5L));
        assertEquals(1L, NumberUtils.min(9L, 1L, 5L));
        assertEquals(1L, NumberUtils.min(9L, 5L, 1L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 5, (short) 1, (short) 9));
    }

    @Test
    void testMinThreeShort() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 5));
        assertEquals((short) 1, NumberUtils.min((short) 9, (short) 1, (short) 5));
        assertEquals((short) 1, NumberUtils.min((short) 9, (short) 5, (short) 1));
    }

    // ---- toByte/toShort/toInt/toLong/toFloat/toDouble ----

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("abc", (byte) 1));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("abc", (short) 1));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("abc", 1));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("abc", 1L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f));
        assertEquals(1.1f, NumberUtils.toFloat("abc", 1.1f));
    }

    @Test
    void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d));
        assertEquals(1.1d, NumberUtils.toDouble("abc", 1.1d));
    }

    @Test
    void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d));
    }

    // ---- toScaledBigDecimal ----

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2395")).setScale(2, RoundingMode.HALF_EVEN));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalNullRoundingMode() {
        assertEquals(new BigDecimal("2.00"), NumberUtils.toScaledBigDecimal(new BigDecimal("2"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d), 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        final float input = 1.2f;
        final BigDecimal expected = BigDecimal.valueOf(input).setScale(2, RoundingMode.CEILING);
        assertEquals(expected, NumberUtils.toScaledBigDecimal(Float.valueOf(input), 2, RoundingMode.CEILING));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235", 2, RoundingMode.HALF_UP));
    }
}
