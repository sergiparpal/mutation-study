package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class StrSubstitutorAgentTest {

    /**
     * Subclass used to verify that {@code resolveVariable} can be overridden,
     * as documented ("Writers of subclasses can override this method...").
     */
    private static class FixedValueSubstitutor extends StrSubstitutor {
        @Override
        protected String resolveVariable(String variableName, StrBuilder buf, int startPos, int endPos) {
            return "FIXED:" + variableName;
        }
    }

    /**
     * Subclass used to verify that {@code substitute} can be overridden and is
     * invoked as part of the public replace/replaceIn methods.
     */
    private static class TrackingSubstitutor extends StrSubstitutor {
        boolean called = false;

        TrackingSubstitutor(Map<String, String> valueMap) {
            super(valueMap);
        }

        @Override
        protected boolean substitute(StrBuilder buf, int offset, int length) {
            called = true;
            return super.substitute(buf, offset, length);
        }
    }

    private static Map<String, String> animalMap() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("animal", "quick brown fox");
        map.put("target", "lazy dog");
        return map;
    }

    // ---- basic replacement (happy path, from class javadoc) ----

    @Test
    public void testReplaceBasicMapSubstitution() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        String result = sub.replace("The ${animal} jumps over the ${target}.");
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    public void testReplaceWithDefaultValueDelimiter() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        String template = "The ${animal} jumps over the ${target}. ${undefined.number:-1234567890}.";
        String result = sub.replace(template);
        assertEquals("The quick brown fox jumps over the lazy dog. 1234567890.", result);
    }

    @Test
    public void testUnknownVariableLeftUnchanged() {
        StrSubstitutor sub = new StrSubstitutor(new HashMap<String, String>());
        String result = sub.replace("Hello ${nowhere}!");
        assertEquals("Hello ${nowhere}!", result);
    }

    @Test
    public void testRecursiveVariableValueSubstitution() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("x", "${y}");
        map.put("y", "finalValue");
        StrSubstitutor sub = new StrSubstitutor(map);
        assertEquals("finalValue", sub.replace("${x}"));
    }

    @Test
    public void testCyclicReplacementThrows() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("a", "${b}");
        map.put("b", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                sub.replace("${a}");
            }
        });
    }

    // ---- null-map / null-resolver boundary ----

    @Test
    public void testNullValueMapLeavesVariablesUnresolved() {
        StrSubstitutor sub = new StrSubstitutor((Map<String, String>) null);
        assertEquals("${x}", sub.replace("${x}"));
    }

    // ---- static replace(Object, Map) ----

    @Test
    public void testStaticReplaceWithMap() {
        String result = StrSubstitutor.replace("${animal}", animalMap());
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testStaticReplaceWithMapNullSourceReturnsNull() {
        assertNull(StrSubstitutor.replace((Object) null, animalMap()));
    }

    // ---- static replace(Object, Map, prefix, suffix) ----

    @Test
    public void testStaticReplaceWithMapAndCustomDelimiters() {
        String result = StrSubstitutor.replace("<%animal%>", animalMap(), "<%", "%>");
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testStaticReplaceWithMapNullPrefixThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StrSubstitutor.replace("${animal}", animalMap(), null, "}");
            }
        });
    }

    @Test
    public void testStaticReplaceWithMapNullSuffixThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                StrSubstitutor.replace("${animal}", animalMap(), "${", null);
            }
        });
    }

    @Test
    public void testStaticReplaceWithMapAndDelimitersNullSourceReturnsNull() {
        assertNull(StrSubstitutor.replace((Object) null, animalMap(), "${", "}"));
    }

    // ---- static replace(Object, Properties) ----

    @Test
    public void testStaticReplaceWithProperties() {
        Properties props = new Properties();
        props.setProperty("greeting", "hello");
        assertEquals("hello world", StrSubstitutor.replace("${greeting} world", props));
    }

    @Test
    public void testStaticReplaceWithPropertiesNullSourceReturnsNull() {
        assertNull(StrSubstitutor.replace(null, new Properties()));
    }

    // ---- static replaceSystemProperties(Object) ----

    @Test
    public void testStaticReplaceSystemProperties() {
        String javaVersion = System.getProperty("java.version");
        String result = StrSubstitutor.replaceSystemProperties("Java version is ${java.version}");
        assertEquals("Java version is " + javaVersion, result);
    }

    // ---- constructors: prefix/suffix validation ----

    @Test
    public void testConstructorMapPrefixSuffixNullPrefixThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new StrSubstitutor(animalMap(), null, "}");
            }
        });
    }

    @Test
    public void testConstructorMapPrefixSuffixNullSuffixThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                new StrSubstitutor(animalMap(), "${", null);
            }
        });
    }

    @Test
    public void testConstructorMapPrefixSuffixEscapeWorks() {
        StrSubstitutor sub = new StrSubstitutor(animalMap(), "<%", "%>", '!');
        assertEquals("quick brown fox", sub.replace("<%animal%>"));
    }

    @Test
    public void testConstructorMapPrefixSuffixEscapeValueDelimiterWorks() {
        StrSubstitutor sub = new StrSubstitutor(animalMap(), "${", "}", '$', ":-");
        assertEquals("1234567890", sub.replace("${undefined:-1234567890}"));
    }

    // ---- replace(String) / replace(String, int, int) ----

    @Test
    public void testReplaceStringNullReturnsNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNull(sub.replace((String) null));
    }

    @Test
    public void testReplaceStringOffsetLength() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        String source = "XX${animal}YY";
        // process only the "${animal}" portion; the rest is not processed nor returned.
        String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    // ---- replace(char[]) / replace(char[], int, int) ----

    @Test
    public void testReplaceCharArrayNullReturnsNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNull(sub.replace((char[]) null));
    }

    @Test
    public void testReplaceCharArrayDoesNotAlterSource() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        char[] source = "${animal}".toCharArray();
        char[] copy = source.clone();
        String result = sub.replace(source);
        assertEquals("quick brown fox", result);
        assertEquals(new String(copy), new String(source));
    }

    @Test
    public void testReplaceCharArrayOffsetLength() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        char[] source = "XX${animal}YY".toCharArray();
        String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    // ---- replace(CharSequence) / replace(CharSequence, int, int) ----

    @Test
    public void testReplaceCharSequenceNullReturnsNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNull(sub.replace((CharSequence) null));
    }

    @Test
    public void testReplaceCharSequence() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        CharSequence source = new StringBuilder("${animal}");
        assertEquals("quick brown fox", sub.replace(source));
    }

    @Test
    public void testReplaceCharSequenceOffsetLength() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        CharSequence source = new StringBuilder("XX${animal}YY");
        assertEquals("quick brown fox", sub.replace(source, 2, 9));
    }

    // ---- replace(Object) ----

    @Test
    public void testReplaceObjectNullReturnsNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNull(sub.replace((Object) null));
    }

    @Test
    public void testReplaceObjectUsesToString() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        Object source = new Object() {
            @Override
            public String toString() {
                return "${animal}";
            }
        };
        assertEquals("quick brown fox", sub.replace(source));
    }

    // ---- replace(StringBuffer) / replace(StringBuffer, int, int) ----

    @Test
    public void testReplaceStringBufferNullReturnsNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNull(sub.replace((StringBuffer) null));
    }

    @Test
    public void testReplaceStringBufferDoesNotAlterSource() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuffer source = new StringBuffer("${animal}");
        String result = sub.replace(source);
        assertEquals("quick brown fox", result);
        assertEquals("${animal}", source.toString());
    }

    @Test
    public void testReplaceStringBufferOffsetLength() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuffer source = new StringBuffer("XX${animal}YY");
        String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
        assertEquals("XX${animal}YY", source.toString());
    }

    // ---- replaceIn(StringBuffer) / replaceIn(StringBuffer, int, int) ----

    @Test
    public void testReplaceInStringBufferNullReturnsFalse() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertFalse(sub.replaceIn((StringBuffer) null));
    }

    @Test
    public void testReplaceInStringBufferAltersAndReturnsTrue() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuffer buf = new StringBuffer("${animal}");
        boolean altered = sub.replaceIn(buf);
        assertTrue(altered);
        assertEquals("quick brown fox", buf.toString());
    }

    @Test
    public void testReplaceInStringBufferNoVariablesReturnsFalse() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuffer buf = new StringBuffer("no variables here");
        boolean altered = sub.replaceIn(buf);
        assertFalse(altered);
        assertEquals("no variables here", buf.toString());
    }

    @Test
    public void testReplaceInStringBufferOffsetLengthLeavesRestUntouched() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuffer buf = new StringBuffer("XX${animal}YY");
        boolean altered = sub.replaceIn(buf, 2, 9);
        assertTrue(altered);
        assertEquals("XXquick brown foxYY", buf.toString());
    }

    // ---- replaceIn(StringBuilder) / replaceIn(StringBuilder, int, int) ----

    @Test
    public void testReplaceInStringBuilderNullReturnsFalse() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertFalse(sub.replaceIn((StringBuilder) null));
    }

    @Test
    public void testReplaceInStringBuilderAltersAndReturnsTrue() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuilder buf = new StringBuilder("${target}");
        boolean altered = sub.replaceIn(buf);
        assertTrue(altered);
        assertEquals("lazy dog", buf.toString());
    }

    @Test
    public void testReplaceInStringBuilderOffsetLengthLeavesRestUntouched() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StringBuilder buf = new StringBuilder("XX${target}YY");
        boolean altered = sub.replaceIn(buf, 2, 9);
        assertTrue(altered);
        assertEquals("XXlazy dogYY", buf.toString());
    }

    // ---- escape character behavior ----

    @Test
    public void testEscapeDefaultCharacterIsDollar() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertEquals('$', sub.getEscapeChar());
    }

    @Test
    public void testEscapedVariableIsNotReplacedByDefault() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        String result = sub.replace("$${animal}");
        assertEquals("${animal}", result);
    }

    @Test
    public void testPreserveEscapesDefaultIsFalse() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertFalse(sub.isPreserveEscapes());
    }

    @Test
    public void testPreserveEscapesTrueKeepsEscapeCharacter() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        sub.setPreserveEscapes(true);
        assertTrue(sub.isPreserveEscapes());
        String result = sub.replace("$${this-is-escaped}");
        assertEquals("$${this-is-escaped}", result);
    }

    @Test
    public void testDisablingEscapeCharacterAllowsDollarAsLiteral() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        sub.setEscapeChar((char) 0);
        assertEquals((char) 0, sub.getEscapeChar());
        String result = sub.replace("$${animal}");
        assertEquals("$quick brown fox", result);
    }

    // ---- variable prefix / suffix ----

    @Test
    public void testSetVariablePrefixSingleChar() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setVariablePrefix('<');
        assertSame(sub, returned);
        sub.setVariableSuffix('>');
        assertEquals("quick brown fox", sub.replace("<animal>"));
    }

    @Test
    public void testSetVariablePrefixStringCustom() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setVariablePrefix("<%");
        assertSame(sub, returned);
        sub.setVariableSuffix("%>");
        assertEquals("quick brown fox", sub.replace("<%animal%>"));
    }

    @Test
    public void testSetVariablePrefixStringNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                sub.setVariablePrefix((String) null);
            }
        });
    }

    @Test
    public void testSetVariableSuffixStringNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                sub.setVariableSuffix((String) null);
            }
        });
    }

    @Test
    public void testDefaultVariablePrefixMatcherIsDefaultPrefixConstant() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertSame(StrSubstitutor.DEFAULT_PREFIX, sub.getVariablePrefixMatcher());
    }

    @Test
    public void testDefaultVariableSuffixMatcherIsDefaultSuffixConstant() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertSame(StrSubstitutor.DEFAULT_SUFFIX, sub.getVariableSuffixMatcher());
    }

    @Test
    public void testSetVariablePrefixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                sub.setVariablePrefixMatcher(null);
            }
        });
    }

    @Test
    public void testSetVariableSuffixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                sub.setVariableSuffixMatcher(null);
            }
        });
    }

    @Test
    public void testSetVariablePrefixMatcherGetterReturnsSetValue() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setVariablePrefixMatcher(StrSubstitutor.DEFAULT_PREFIX);
        assertSame(sub, returned);
        assertSame(StrSubstitutor.DEFAULT_PREFIX, sub.getVariablePrefixMatcher());
    }

    @Test
    public void testSetVariableSuffixMatcherGetterReturnsSetValue() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setVariableSuffixMatcher(StrSubstitutor.DEFAULT_SUFFIX);
        assertSame(sub, returned);
        assertSame(StrSubstitutor.DEFAULT_SUFFIX, sub.getVariableSuffixMatcher());
    }

    // ---- value delimiter ----

    @Test
    public void testDefaultValueDelimiterMatcherIsNotNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNotNull(sub.getValueDelimiterMatcher());
    }

    @Test
    public void testSetValueDelimiterCharWorks() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setValueDelimiter('=');
        assertSame(sub, returned);
        assertEquals("fallback", sub.replace("${missing=fallback}"));
    }

    @Test
    public void testSetValueDelimiterStringNullDisablesDefaultValueResolution() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setValueDelimiter((String) null);
        assertSame(sub, returned);
        assertNull(sub.getValueDelimiterMatcher());
        // Without delimiter resolution, the whole "missing:-fallback" is an
        // unknown variable name, so the text is left unchanged.
        String template = "${missing:-fallback}";
        assertEquals(template, sub.replace(template));
    }

    @Test
    public void testSetValueDelimiterMatcherNullGetterReturnsNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        StrSubstitutor returned = sub.setValueDelimiterMatcher(null);
        assertSame(sub, returned);
        assertNull(sub.getValueDelimiterMatcher());
    }

    // ---- enableSubstitutionInVariables ----

    @Test
    public void testEnableSubstitutionInVariablesDefaultFalse() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertFalse(sub.isEnableSubstitutionInVariables());
    }

    @Test
    public void testEnableSubstitutionInVariablesTrueAllowsNestedNames() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("java.specification.version", "1.8");
        map.put("jre-1.8", "JAVA8");
        StrSubstitutor sub = new StrSubstitutor(map);
        sub.setEnableSubstitutionInVariables(true);
        assertTrue(sub.isEnableSubstitutionInVariables());
        String result = sub.replace("${jre-${java.specification.version}}");
        assertEquals("JAVA8", result);
    }

    // ---- variable resolver ----

    @Test
    public void testSetVariableResolverNull() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        sub.setVariableResolver(null);
        assertNull(sub.getVariableResolver());
    }

    @Test
    public void testGetVariableResolverNotNullWhenConstructedFromMap() {
        StrSubstitutor sub = new StrSubstitutor(animalMap());
        assertNotNull(sub.getVariableResolver());
    }

    // ---- protected hooks: resolveVariable / substitute can be overridden ----

    @Test
    public void testResolveVariableCanBeOverridden() {
        FixedValueSubstitutor sub = new FixedValueSubstitutor();
        String result = sub.replace("${anything}");
        assertEquals("FIXED:anything", result);
    }

    @Test
    public void testSubstituteHookIsInvoked() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("x", "Y");
        TrackingSubstitutor sub = new TrackingSubstitutor(map);
        String result = sub.replace("${x}");
        assertEquals("Y", result);
        assertTrue(sub.called);
    }
}
