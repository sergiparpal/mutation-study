/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    @Test
    public void testGetFractionIntInt() {
        Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());

        // negative denominator moves sign to numerator
        f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());

        // not reduced
        f = Fraction.getFraction(4, 8);
        assertEquals(4, f.getNumerator());
        assertEquals(8, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntOverflowOnNegate() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -5));
    }

    @Test
    public void testGetFractionWholeNumerDenom() {
        Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());

        f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomErrorCases() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, 0));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, -7));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -3, 7));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, Integer.MAX_VALUE, 1));
    }

    @Test
    public void testGetFractionDouble() {
        Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());

        f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());

        f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleErrorCases() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.POSITIVE_INFINITY));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(((double) Integer.MAX_VALUE) + 1));
    }

    @Test
    public void testGetFractionString() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction("0.5"));
        assertEquals(Fraction.getFraction(1, 3, 7), Fraction.getFraction("1 3/7"));
        assertEquals(Fraction.getFraction(3, 7), Fraction.getFraction("3/7"));
        assertEquals(Fraction.getFraction(5, 1), Fraction.getFraction("5"));
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringMalformedThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3"));
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testGetReducedFraction() {
        Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());

        f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);

        f = Fraction.getReducedFraction(-2, 4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testConstants() {
        assertEquals(Fraction.getFraction(0, 1), Fraction.ZERO);
        assertEquals(Fraction.getFraction(1, 1), Fraction.ONE);
        assertEquals(Fraction.getFraction(1, 2), Fraction.ONE_HALF);
        assertEquals(Fraction.getFraction(1, 3), Fraction.ONE_THIRD);
        assertEquals(Fraction.getFraction(2, 3), Fraction.TWO_THIRDS);
        assertEquals(Fraction.getFraction(1, 4), Fraction.ONE_QUARTER);
        assertEquals(Fraction.getFraction(2, 4), Fraction.TWO_QUARTERS);
        assertEquals(Fraction.getFraction(3, 4), Fraction.THREE_QUARTERS);
        assertEquals(Fraction.getFraction(1, 5), Fraction.ONE_FIFTH);
        assertEquals(Fraction.getFraction(2, 5), Fraction.TWO_FIFTHS);
        assertEquals(Fraction.getFraction(3, 5), Fraction.THREE_FIFTHS);
        assertEquals(Fraction.getFraction(4, 5), Fraction.FOUR_FIFTHS);
    }

    @Test
    public void testAbs() {
        assertSame(Fraction.ONE, Fraction.ONE.abs());
        final Fraction neg = Fraction.getFraction(-3, 7);
        final Fraction abs = neg.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAdd() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());

        assertEquals(Fraction.getFraction(3, 7), Fraction.ZERO.add(Fraction.getFraction(3, 7)));
        assertEquals(Fraction.getFraction(3, 7), Fraction.getFraction(3, 7).add(Fraction.ZERO));
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.add(null));
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> f.add(Fraction.ONE));
    }

    @Test
    public void testSubtract() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 3));
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.subtract(null));
    }

    @Test
    public void testMultiplyBy() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());

        assertSame(Fraction.ZERO, Fraction.ZERO.multiplyBy(Fraction.getFraction(3, 7)));
        assertSame(Fraction.ZERO, Fraction.getFraction(3, 7).multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.multiplyBy(null));
    }

    @Test
    public void testDivideBy() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 3));
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.ONE.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.divideBy(null));
    }

    @Test
    public void testInvert() {
        final Fraction f = Fraction.getFraction(3, 7).invert();
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());

        final Fraction neg = Fraction.getFraction(-3, 7).invert();
        assertEquals(-7, neg.getNumerator());
        assertEquals(3, neg.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.ZERO.invert());
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    @Test
    public void testNegate() {
        final Fraction f = Fraction.getFraction(3, 7).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    @Test
    public void testPow() {
        final Fraction threeSevenths = Fraction.getFraction(3, 7);
        assertSame(threeSevenths, threeSevenths.pow(1));
        assertSame(Fraction.ONE, Fraction.getFraction(3, 7).pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));

        final Fraction squared = Fraction.getFraction(2, 3).pow(2);
        assertEquals(4, squared.getNumerator());
        assertEquals(9, squared.getDenominator());

        final Fraction inv = Fraction.getFraction(2, 3).pow(-1);
        assertEquals(3, inv.getNumerator());
        assertEquals(2, inv.getDenominator());

        final Fraction one = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, one.getNumerator());
        assertEquals(1, one.getDenominator());
    }

    @Test
    public void testPowMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, () -> f.pow(Integer.MIN_VALUE));
    }

    @Test
    public void testReduce() {
        final Fraction f = Fraction.getFraction(4, 8).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());

        final Fraction alreadyReduced = Fraction.getFraction(3, 7);
        assertSame(alreadyReduced, alreadyReduced.reduce());

        assertSame(Fraction.ZERO, Fraction.getFraction(0, 5).reduce());
    }

    @Test
    public void testCompareTo() {
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 2)));
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 3)) > 0);
        // 1/2 == 2/4 by comparison, but not by equals
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.compareTo(null));
    }

    @Test
    public void testEqualsAndHashCode() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertEquals(a, a);
        assertNotEquals(a, null);
        assertNotEquals(a, "1/2");
        // 1/2 and 2/4 are not equal, even though they represent the same value
        assertNotEquals(a, Fraction.getFraction(2, 4));
        assertFalse(a.equals(Fraction.getFraction(1, 3)));
    }

    @Test
    public void testNumberConversions() {
        final Fraction f = Fraction.getFraction(7, 2);
        assertEquals(3, f.intValue());
        assertEquals(3L, f.longValue());
        assertEquals(3.5d, f.doubleValue(), 0.0d);
        assertEquals(3.5f, f.floatValue(), 0.0f);
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());

        final Fraction neg = Fraction.getFraction(-7, 4);
        assertEquals(3, neg.getProperNumerator());
        assertEquals(-1, neg.getProperWhole());
    }

    @Test
    public void testToString() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
        assertEquals("-3/7", Fraction.getFraction(-3, 7).toString());
        assertEquals("0/1", Fraction.ZERO.toString());
    }

    @Test
    public void testToProperString() {
        assertEquals("0", Fraction.ZERO.toProperString());
        assertEquals("1", Fraction.ONE.toProperString());
        assertEquals("-1", Fraction.getFraction(-1, 1).toProperString());
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
        assertEquals("2", Fraction.getFraction(4, 2).toProperString());
    }

    @Test
    public void testToProperStringMinValue() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertEquals(Integer.toString(Integer.MIN_VALUE), f.toProperString());
    }
}
