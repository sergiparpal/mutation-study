package org.apache.commons.lang3.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ExceptionUtils}, based on its published javadoc contract.
 */
public class ExceptionUtilsAgentTest {

    /**
     * Throwable subclass exposing a custom "cause-like" accessor method, used to exercise
     * {@code getCause(Throwable, String[])} with a non-default method name.
     */
    private static final class TargetHolder extends Exception {
        private static final long serialVersionUID = 1L;
        private final transient Throwable target;

        TargetHolder(final String message, final Throwable target) {
            super(message);
            this.target = target;
        }

        public Throwable getTargetException() {
            return target;
        }
    }

    // ---------------------------------------------------------------- constructor

    @Test
    public void testConstructor_instantiable() {
        final ExceptionUtils instance = new ExceptionUtils();
        assertNotNull(instance);
    }

    @Test
    public void testWrappedMarkerConstant() {
        assertEquals(" [wrapped] ", ExceptionUtils.WRAPPED_MARKER);
    }

    // ---------------------------------------------------------------- asRuntimeException

    @Test
    public void testAsRuntimeException_rethrowsCheckedExceptionUnchanged() {
        final IOException checked = new IOException("as-runtime-checked");
        final Throwable thrown = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.asRuntimeException(checked);
            }
        });
        assertSame(checked, thrown);
    }

    @Test
    public void testAsRuntimeException_rethrowsRuntimeExceptionUnchanged() {
        final IllegalStateException original = new IllegalStateException("as-runtime-unchecked");
        final Throwable thrown = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.asRuntimeException(original);
            }
        });
        assertSame(original, thrown);
    }

    // ---------------------------------------------------------------- forEach

    @Test
    public void testForEach_singleThrowableNoCause() {
        final List<Throwable> visited = new ArrayList<Throwable>();
        final Throwable solo = new RuntimeException("solo");
        ExceptionUtils.forEach(solo, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                visited.add(t);
            }
        });
        assertEquals(1, visited.size());
        assertSame(solo, visited.get(0));
    }

    @Test
    public void testForEach_withCauseChainVisitsInOrder() {
        final List<Throwable> visited = new ArrayList<Throwable>();
        final Throwable cause = new IllegalStateException("fe-cause");
        final Throwable wrapper = new RuntimeException("fe-wrapper", cause);
        ExceptionUtils.forEach(wrapper, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                visited.add(t);
            }
        });
        assertEquals(Arrays.asList(wrapper, cause), visited);
    }

    @Test
    public void testForEach_nullThrowableNeverInvokesConsumer() {
        final List<Throwable> visited = new ArrayList<Throwable>();
        ExceptionUtils.forEach(null, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                visited.add(t);
            }
        });
        assertTrue(visited.isEmpty());
    }

    // ---------------------------------------------------------------- getCause (deprecated)

    @Test
    public void testGetCause_findsRealCauseViaStandardMethod() {
        final Throwable cause = new IllegalStateException("gc-cause");
        final Throwable wrapper = new RuntimeException("gc-wrapper", cause);
        assertSame(cause, ExceptionUtils.getCause(wrapper));
    }

    @Test
    public void testGetCause_noCauseReturnsNull() {
        final Throwable plain = new RuntimeException("gc-plain");
        assertNull(ExceptionUtils.getCause(plain));
    }

    @Test
    public void testGetCause_nullThrowableReturnsNull() {
        assertNull(ExceptionUtils.getCause(null));
    }

    @Test
    public void testGetCauseWithMethodNames_nullUsesDefaultSet() {
        final Throwable cause = new IllegalStateException("gcmn-cause");
        final Throwable wrapper = new RuntimeException("gcmn-wrapper", cause);
        assertSame(cause, ExceptionUtils.getCause(wrapper, null));
    }

    @Test
    public void testGetCauseWithMethodNames_customNameIsUsed() {
        final Throwable target = new IOException("gcmn-target");
        final TargetHolder holder = new TargetHolder("gcmn-holder", target);
        final Throwable found = ExceptionUtils.getCause(holder, new String[] {"getTargetException"});
        assertSame(target, found);
    }

    @Test
    public void testGetCauseWithMethodNames_nullEntryIsIgnored() {
        final Throwable target = new IOException("gcmn-target2");
        final TargetHolder holder = new TargetHolder("gcmn-holder2", target);
        final Throwable found = ExceptionUtils.getCause(holder, new String[] {null, "getTargetException"});
        assertSame(target, found);
    }

    // ---------------------------------------------------------------- getDefaultCauseMethodNames (deprecated)

    @Test
    public void testGetDefaultCauseMethodNames_contentAndOrder() {
        final String[] expected = {"getCause", "getNextException", "getTargetException", "getException",
                "getSourceException", "getRootCause", "getCausedByException", "getNested"};
        assertArrayEquals(expected, ExceptionUtils.getDefaultCauseMethodNames());
    }

    @Test
    public void testGetDefaultCauseMethodNames_returnsIndependentClone() {
        final String[] first = ExceptionUtils.getDefaultCauseMethodNames();
        first[0] = "mutated";
        final String[] second = ExceptionUtils.getDefaultCauseMethodNames();
        assertNotSame(first, second);
        assertEquals("getCause", second[0]);
    }

    // ---------------------------------------------------------------- getMessage

    @Test
    public void testGetMessage_formatsClassNameAndMessage() {
        final Throwable t = new IllegalArgumentException("bad value");
        assertEquals("IllegalArgumentException: bad value", ExceptionUtils.getMessage(t));
    }

    @Test
    public void testGetMessage_nullThrowableReturnsEmptyString() {
        assertEquals("", ExceptionUtils.getMessage(null));
    }

    @Test
    public void testGetMessage_nullMessageStillIncludesClassName() {
        final Throwable t = new RuntimeException();
        assertEquals("RuntimeException: null", ExceptionUtils.getMessage(t));
    }

    // ---------------------------------------------------------------- getRootCause

    @Test
    public void testGetRootCause_nullThrowableReturnsNull() {
        assertNull(ExceptionUtils.getRootCause(null));
    }

    @Test
    public void testGetRootCause_walksToLastElementOfChain() {
        final Throwable root = new IllegalStateException("grc-root");
        final Throwable mid = new RuntimeException("grc-mid", root);
        final Throwable top = new RuntimeException("grc-top", mid);
        assertSame(root, ExceptionUtils.getRootCause(top));
    }

    @Test
    public void testGetRootCause_withoutCauseReturnsNull() {
        final Throwable alone = new RuntimeException("grc-alone");
        assertNull(ExceptionUtils.getRootCause(alone));
    }

    @Test
    public void testGetRootCause_detectsCycleAndReturnsElementBeforeLoop() {
        final Throwable a = new Throwable("grc-a");
        final Throwable b = new Throwable("grc-b", a);
        a.initCause(b);
        assertSame(b, ExceptionUtils.getRootCause(a));
    }

    // ---------------------------------------------------------------- getRootCauseMessage

    @Test
    public void testGetRootCauseMessage_nullThrowableReturnsEmptyString() {
        assertEquals("", ExceptionUtils.getRootCauseMessage(null));
    }

    @Test
    public void testGetRootCauseMessage_usesRootCauseMessage() {
        final Throwable root = new IllegalStateException("grcm-root");
        final Throwable wrapper = new RuntimeException("grcm-wrapper", root);
        assertEquals("IllegalStateException: grcm-root", ExceptionUtils.getRootCauseMessage(wrapper));
    }

    // ---------------------------------------------------------------- getRootCauseStackTrace / List

    @Test
    public void testGetRootCauseStackTrace_nullThrowableReturnsEmptyNonNullArray() {
        final String[] frames = ExceptionUtils.getRootCauseStackTrace(null);
        assertNotNull(frames);
        assertEquals(0, frames.length);
    }

    @Test
    public void testGetRootCauseStackTrace_rootComesBeforeWrapperAndMarkerPresent() {
        final Throwable root = new IllegalStateException("ROOT_STACK_TOKEN");
        final Throwable wrapper = new RuntimeException("WRAPPER_STACK_TOKEN", root);
        final String[] frames = ExceptionUtils.getRootCauseStackTrace(wrapper);
        assertTrue(frames.length > 0);
        final String joined = String.join("\n", frames);
        final int rootIdx = joined.indexOf("ROOT_STACK_TOKEN");
        final int wrapperIdx = joined.indexOf("WRAPPER_STACK_TOKEN");
        assertTrue(rootIdx >= 0);
        assertTrue(wrapperIdx >= 0);
        assertTrue(rootIdx < wrapperIdx);
        assertTrue(joined.contains("[wrapped]"));
    }

    @Test
    public void testGetRootCauseStackTraceList_nullThrowableReturnsEmptyNonNullList() {
        final List<String> frames = ExceptionUtils.getRootCauseStackTraceList(null);
        assertNotNull(frames);
        assertEquals(0, frames.size());
    }

    @Test
    public void testGetRootCauseStackTraceList_matchesArrayVersion() {
        final Throwable root = new IllegalStateException("grcstl-root");
        final Throwable wrapper = new RuntimeException("grcstl-wrapper", root);
        final String[] arr = ExceptionUtils.getRootCauseStackTrace(wrapper);
        final List<String> list = ExceptionUtils.getRootCauseStackTraceList(wrapper);
        assertEquals(Arrays.asList(arr), list);
    }

    // ---------------------------------------------------------------- getStackFrameList (package-private)

    @Test
    public void testGetStackFrameList_excludesMessageAndCausedBy() {
        final Throwable cause = new IllegalStateException("gsfl-cause");
        final Throwable wrapper = new RuntimeException("WRAPPER_FRAME_TOKEN", cause);
        final List<String> frames = ExceptionUtils.getStackFrameList(wrapper);
        assertNotNull(frames);
        assertFalse(frames.isEmpty());
        for (final String frame : frames) {
            assertFalse(frame.contains("Caused by"));
            assertFalse(frame.contains("WRAPPER_FRAME_TOKEN"));
            assertTrue(frame.trim().startsWith("at "));
        }
    }

    // ---------------------------------------------------------------- getStackFrames(String) (package-private)

    @Test
    public void testGetStackFramesFromString_splitsOnLineSeparator() {
        final String sep = System.lineSeparator();
        final String combined = "line1" + sep + "line2" + sep + "line3";
        final String[] frames = ExceptionUtils.getStackFrames(combined);
        assertArrayEquals(new String[] {"line1", "line2", "line3"}, frames);
    }

    // ---------------------------------------------------------------- getStackFrames(Throwable)

    @Test
    public void testGetStackFramesFromThrowable_nullReturnsEmptyNonNullArray() {
        final String[] frames = ExceptionUtils.getStackFrames((Throwable) null);
        assertNotNull(frames);
        assertEquals(0, frames.length);
    }

    @Test
    public void testGetStackFramesFromThrowable_includesCausedBy() {
        final Throwable cause = new IllegalStateException("gsft-cause");
        final Throwable wrapper = new RuntimeException("gsft-wrapper", cause);
        final String[] frames = ExceptionUtils.getStackFrames(wrapper);
        assertTrue(frames.length > 1);
        boolean hasCausedBy = false;
        for (final String frame : frames) {
            if (frame.contains("Caused by")) {
                hasCausedBy = true;
                break;
            }
        }
        assertTrue(hasCausedBy);
    }

    // ---------------------------------------------------------------- getStackTrace

    @Test
    public void testGetStackTrace_nullThrowableReturnsEmptyString() {
        assertEquals("", ExceptionUtils.getStackTrace(null));
    }

    @Test
    public void testGetStackTrace_includesCauseAndSuppressed() {
        final Throwable suppressed = new IllegalArgumentException("SUPPRESSED_TOKEN");
        final Throwable cause = new IllegalStateException("CAUSE_TOKEN");
        final Throwable wrapper = new RuntimeException("WRAPPER_TOKEN", cause);
        wrapper.addSuppressed(suppressed);
        final String trace = ExceptionUtils.getStackTrace(wrapper);
        assertTrue(trace.contains("WRAPPER_TOKEN"));
        assertTrue(trace.contains("Caused by"));
        assertTrue(trace.contains("Suppressed"));
    }

    // ---------------------------------------------------------------- getThrowableCount

    @Test
    public void testGetThrowableCount_nullReturnsZero() {
        assertEquals(0, ExceptionUtils.getThrowableCount(null));
    }

    @Test
    public void testGetThrowableCount_countsEachElementInChain() {
        final Throwable single = new RuntimeException("gtc-single");
        assertEquals(1, ExceptionUtils.getThrowableCount(single));

        final Throwable cause = new IllegalStateException("gtc-cause");
        final Throwable wrapper = new RuntimeException("gtc-wrapper", cause);
        assertEquals(2, ExceptionUtils.getThrowableCount(wrapper));
    }

    @Test
    public void testGetThrowableCount_detectsCycle() {
        final Throwable a = new Throwable("gtc-a");
        final Throwable b = new Throwable("gtc-b", a);
        a.initCause(b);
        assertEquals(2, ExceptionUtils.getThrowableCount(a));
    }

    // ---------------------------------------------------------------- getThrowableList

    @Test
    public void testGetThrowableList_nullReturnsEmptyList() {
        assertTrue(ExceptionUtils.getThrowableList(null).isEmpty());
    }

    @Test
    public void testGetThrowableList_containsChainInOrder() {
        final Throwable cause = new IllegalStateException("gtl-cause");
        final Throwable wrapper = new RuntimeException("gtl-wrapper", cause);
        final List<Throwable> list = ExceptionUtils.getThrowableList(wrapper);
        assertEquals(2, list.size());
        assertSame(wrapper, list.get(0));
        assertSame(cause, list.get(1));
    }

    @Test
    public void testGetThrowableList_detectsCycle() {
        final Throwable a = new Throwable("gtl-a");
        final Throwable b = new Throwable("gtl-b", a);
        a.initCause(b);
        final List<Throwable> list = ExceptionUtils.getThrowableList(a);
        assertEquals(2, list.size());
        assertSame(a, list.get(0));
        assertSame(b, list.get(1));
    }

    // ---------------------------------------------------------------- getThrowables

    @Test
    public void testGetThrowables_nullReturnsEmptyNonNullArray() {
        final Throwable[] arr = ExceptionUtils.getThrowables(null);
        assertNotNull(arr);
        assertEquals(0, arr.length);
    }

    @Test
    public void testGetThrowables_matchesThrowableList() {
        final Throwable cause = new IllegalStateException("gt-cause");
        final Throwable wrapper = new RuntimeException("gt-wrapper", cause);
        final Throwable[] arr = ExceptionUtils.getThrowables(wrapper);
        final List<Throwable> list = ExceptionUtils.getThrowableList(wrapper);
        assertEquals(list, Arrays.asList(arr));
    }

    // ---------------------------------------------------------------- hasCause

    @Test
    public void testHasCause_directInstanceMatches() {
        assertTrue(ExceptionUtils.hasCause(new IllegalStateException("hc-direct"), IllegalStateException.class));
    }

    @Test
    public void testHasCause_undeclaredThrowableExceptionWrappingMatchingType() {
        final UndeclaredThrowableException ute = new UndeclaredThrowableException(new IOException("hc-io"));
        assertTrue(ExceptionUtils.hasCause(ute, IOException.class));
    }

    @Test
    public void testHasCause_noMatchReturnsFalse() {
        assertFalse(ExceptionUtils.hasCause(new RuntimeException("hc-plain"), IOException.class));
    }

    // ---------------------------------------------------------------- indexOfThrowable

    @Test
    public void testIndexOfThrowable_exactClassMatchOnly() {
        final FileNotFoundException inner = new FileNotFoundException("iot-inner");
        final RuntimeException outer = new RuntimeException("iot-outer", inner);
        // subclass present (FileNotFoundException extends IOException) but exact match fails for IOException
        assertEquals(-1, ExceptionUtils.indexOfThrowable(outer, IOException.class));
        assertEquals(1, ExceptionUtils.indexOfThrowable(outer, FileNotFoundException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(outer, IllegalStateException.class));
    }

    @Test
    public void testIndexOfThrowable_nullInputsReturnNegativeOne() {
        assertEquals(-1, ExceptionUtils.indexOfThrowable(null, RuntimeException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(new RuntimeException("iot-x"), null));
    }

    @Test
    public void testIndexOfThrowable_fromIndexBoundaries() {
        final IllegalArgumentException level2 = new IllegalArgumentException("iot-lvl2");
        final IllegalStateException level1 = new IllegalStateException("iot-lvl1", level2);
        final RuntimeException level0 = new RuntimeException("iot-lvl0", level1);

        assertEquals(1, ExceptionUtils.indexOfThrowable(level0, IllegalStateException.class, -5));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(level0, IllegalStateException.class, 2));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(level0, IllegalStateException.class, 10));
    }

    // ---------------------------------------------------------------- indexOfType

    @Test
    public void testIndexOfType_subclassMatches() {
        final FileNotFoundException inner = new FileNotFoundException("iotype-inner");
        final RuntimeException outer = new RuntimeException("iotype-outer", inner);
        assertEquals(1, ExceptionUtils.indexOfType(outer, IOException.class));
        assertEquals(0, ExceptionUtils.indexOfType(outer, RuntimeException.class));
    }

    @Test
    public void testIndexOfType_nullInputsReturnNegativeOne() {
        assertEquals(-1, ExceptionUtils.indexOfType(null, RuntimeException.class));
        assertEquals(-1, ExceptionUtils.indexOfType(new RuntimeException("iotype-y"), null));
    }

    @Test
    public void testIndexOfType_fromIndexBoundaries() {
        final IllegalArgumentException level2 = new IllegalArgumentException("iotype-lvl2");
        final IllegalStateException level1 = new IllegalStateException("iotype-lvl1", level2);
        final RuntimeException level0 = new RuntimeException("iotype-lvl0", level1);

        assertEquals(1, ExceptionUtils.indexOfType(level0, IllegalStateException.class, -3));
        assertEquals(-1, ExceptionUtils.indexOfType(level0, IllegalStateException.class, 2));
        assertEquals(-1, ExceptionUtils.indexOfType(level0, IllegalStateException.class, 20));
    }

    // ---------------------------------------------------------------- isChecked / isUnchecked

    @Test
    public void testIsChecked() {
        assertTrue(ExceptionUtils.isChecked(new IOException("checked")));
        assertFalse(ExceptionUtils.isChecked(new RuntimeException("unchecked")));
        assertFalse(ExceptionUtils.isChecked(new Error("error")));
    }

    @Test
    public void testIsUnchecked() {
        assertTrue(ExceptionUtils.isUnchecked(new RuntimeException("unchecked")));
        assertTrue(ExceptionUtils.isUnchecked(new Error("error")));
        assertFalse(ExceptionUtils.isUnchecked(new IOException("checked")));
    }

    // ---------------------------------------------------------------- printRootCauseStackTrace

    @Test
    public void testPrintRootCauseStackTrace_toSystemErr() {
        final PrintStream originalErr = System.err;
        final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try {
            System.setErr(new PrintStream(buffer, true));
            ExceptionUtils.printRootCauseStackTrace(new IllegalStateException("PRSST_ERR_TOKEN"));
        } finally {
            System.setErr(originalErr);
        }
        assertTrue(buffer.toString().contains("PRSST_ERR_TOKEN"));
    }

    @Test
    public void testPrintRootCauseStackTrace_toPrintStream() {
        final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(buffer, true);
        ExceptionUtils.printRootCauseStackTrace(new IllegalStateException("PRSST_PS_TOKEN"), ps);
        ps.flush();
        assertTrue(buffer.toString().contains("PRSST_PS_TOKEN"));
    }

    @Test
    public void testPrintRootCauseStackTrace_nullPrintStreamThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(new RuntimeException("npe-ps"), (PrintStream) null);
            }
        });
    }

    @Test
    public void testPrintRootCauseStackTrace_toPrintWriter() {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        ExceptionUtils.printRootCauseStackTrace(new IllegalStateException("PRSST_PW_TOKEN"), pw);
        pw.flush();
        assertTrue(sw.toString().contains("PRSST_PW_TOKEN"));
    }

    @Test
    public void testPrintRootCauseStackTrace_nullPrintWriterThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(new RuntimeException("npe-pw"), (PrintWriter) null);
            }
        });
    }

    // ---------------------------------------------------------------- removeCommonFrames

    @Test
    public void testRemoveCommonFrames_removesTrailingCommonLinesFromCauseFrames() {
        final List<String> causeFrames = new ArrayList<String>(Arrays.asList(
                "at A.a(A.java:1)", "at B.b(B.java:2)", "at C.c(C.java:3)"));
        final List<String> wrapperFrames = Arrays.asList(
                "at D.d(D.java:10)", "at B.b(B.java:2)", "at C.c(C.java:3)");

        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);

        assertEquals(Arrays.asList("at A.a(A.java:1)"), causeFrames);
    }

    @Test
    public void testRemoveCommonFrames_nullArgumentsThrowNpe() {
        final List<String> frames = new ArrayList<String>(Arrays.asList("at A.a(A.java:1)"));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(null, frames);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(frames, null);
            }
        });
    }

    // ---------------------------------------------------------------- rethrow

    @Test
    public void testRethrow_rethrowsCheckedExceptionUnchanged() {
        final IOException checked = new IOException("rethrow-me");
        final Throwable thrown = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.rethrow(checked);
            }
        });
        assertSame(checked, thrown);
    }

    // ---------------------------------------------------------------- stream

    @Test
    public void testStream_matchesThrowableListContent() {
        final Throwable cause = new IllegalStateException("stream-cause");
        final Throwable wrapper = new RuntimeException("stream-wrapper", cause);
        final List<Throwable> collected = new ArrayList<Throwable>();
        final Stream<Throwable> stream = ExceptionUtils.stream(wrapper);
        stream.forEach(new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                collected.add(t);
            }
        });
        assertEquals(ExceptionUtils.getThrowableList(wrapper), collected);
    }

    @Test
    public void testStream_nullThrowableIsEmpty() {
        final long count = ExceptionUtils.stream(null).count();
        assertEquals(0L, count);
    }

    // ---------------------------------------------------------------- throwableOfThrowable

    @Test
    public void testThrowableOfThrowable_exactClassMatchOnly() {
        final FileNotFoundException inner = new FileNotFoundException("tot-inner");
        final RuntimeException outer = new RuntimeException("tot-outer", inner);
        assertSame(inner, ExceptionUtils.throwableOfThrowable(outer, FileNotFoundException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(outer, IOException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(outer, null));
    }

    @Test
    public void testThrowableOfThrowable_fromIndexBoundaries() {
        final IllegalArgumentException level2 = new IllegalArgumentException("tot-lvl2");
        final IllegalStateException level1 = new IllegalStateException("tot-lvl1", level2);
        final RuntimeException level0 = new RuntimeException("tot-lvl0", level1);

        assertSame(level1, ExceptionUtils.throwableOfThrowable(level0, IllegalStateException.class, -2));
        assertNull(ExceptionUtils.throwableOfThrowable(level0, IllegalStateException.class, 2));
        assertNull(ExceptionUtils.throwableOfThrowable(level0, IllegalStateException.class, 20));
    }

    // ---------------------------------------------------------------- throwableOfType

    @Test
    public void testThrowableOfType_subclassMatches() {
        final FileNotFoundException inner = new FileNotFoundException("totype-inner");
        final RuntimeException outer = new RuntimeException("totype-outer", inner);
        assertSame(inner, ExceptionUtils.throwableOfType(outer, IOException.class));
        assertSame(outer, ExceptionUtils.throwableOfType(outer, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfType(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfType(outer, null));
    }

    @Test
    public void testThrowableOfType_fromIndexBoundaries() {
        final IllegalArgumentException level2 = new IllegalArgumentException("totype-lvl2");
        final IllegalStateException level1 = new IllegalStateException("totype-lvl1", level2);
        final RuntimeException level0 = new RuntimeException("totype-lvl0", level1);

        assertSame(level1, ExceptionUtils.throwableOfType(level0, IllegalStateException.class, -4));
        assertNull(ExceptionUtils.throwableOfType(level0, IllegalStateException.class, 2));
        assertNull(ExceptionUtils.throwableOfType(level0, IllegalStateException.class, 50));
    }

    // ---------------------------------------------------------------- throwUnchecked

    @Test
    public void testThrowUnchecked_throwsGivenRuntimeException() {
        final RuntimeException rte = new RuntimeException("throw-unchecked-rte");
        final Throwable thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.throwUnchecked(rte);
            }
        });
        assertSame(rte, thrown);
    }

    @Test
    public void testThrowUnchecked_throwsGivenError() {
        final Error error = new Error("throw-unchecked-error");
        final Throwable thrown = assertThrows(Error.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.throwUnchecked(error);
            }
        });
        assertSame(error, thrown);
    }

    @Test
    public void testThrowUnchecked_returnsCheckedExceptionWithoutThrowing() {
        final Exception checked = new Exception("throw-unchecked-checked");
        final Throwable result = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, result);
    }

    // ---------------------------------------------------------------- wrapAndThrow

    @Test
    public void testWrapAndThrow_wrapsCheckedExceptionInUndeclaredThrowableException() {
        final IOException checked = new IOException("wrap-and-throw-checked");
        final Throwable thrown = assertThrows(UndeclaredThrowableException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.wrapAndThrow(checked);
            }
        });
        final UndeclaredThrowableException ute = (UndeclaredThrowableException) thrown;
        assertSame(checked, ute.getUndeclaredThrowable());
    }

    @Test
    public void testWrapAndThrow_rethrowsRuntimeExceptionUnchanged() {
        final RuntimeException rte = new RuntimeException("wrap-and-throw-unchecked");
        final Throwable thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.wrapAndThrow(rte);
            }
        });
        assertSame(rte, thrown);
    }
}
