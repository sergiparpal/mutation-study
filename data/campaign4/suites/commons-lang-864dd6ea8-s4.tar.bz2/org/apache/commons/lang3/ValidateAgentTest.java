package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ValidateAgentTest {

    // ---------------------------------------------------------------
    // exclusiveBetween
    // ---------------------------------------------------------------

    @Test
    public void testExclusiveBetweenDouble_inRange_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 1.1);
            }
        });
    }

    @Test
    public void testExclusiveBetweenDouble_atStartBoundary_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 0.1);
            }
        });
    }

    @Test
    public void testExclusiveBetweenDouble_atEndBoundary_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 2.1);
            }
        });
    }

    @Test
    public void testExclusiveBetweenDoubleWithMessage_outOfRange_usesMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 5.0, "Not in range");
            }
        });
        assertEquals("Not in range", ex.getMessage());
    }

    @Test
    public void testExclusiveBetweenLong_inRange_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 1L);
            }
        });
    }

    @Test
    public void testExclusiveBetweenLong_outOfRange_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 2L);
            }
        });
    }

    @Test
    public void testExclusiveBetweenLongWithMessage_outOfRange_usesMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 3L, "Not in range");
            }
        });
        assertEquals("Not in range", ex.getMessage());
    }

    @Test
    public void testExclusiveBetweenComparable_inRange_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testExclusiveBetweenComparable_outOfRange_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(2));
            }
        });
    }

    @Test
    public void testExclusiveBetweenComparableWithMessage_outOfRange_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(5),
                        "Not in boundaries: %d", Integer.valueOf(5));
            }
        });
        assertEquals("Not in boundaries: 5", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // finite
    // ---------------------------------------------------------------

    @Test
    public void testFinite_normalValue_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.finite(1.5);
            }
        });
    }

    @Test
    public void testFinite_positiveInfinity_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.finite(Double.POSITIVE_INFINITY);
            }
        });
    }

    @Test
    public void testFinite_negativeInfinity_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.finite(Double.NEGATIVE_INFINITY);
            }
        });
    }

    @Test
    public void testFinite_nan_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.finite(Double.NaN);
            }
        });
    }

    @Test
    public void testFiniteWithMessage_infinite_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.finite(Double.POSITIVE_INFINITY, "must be finite: %s", "value");
            }
        });
        assertEquals("must be finite: value", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // inclusiveBetween
    // ---------------------------------------------------------------

    @Test
    public void testInclusiveBetweenDouble_atStartBoundary_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 0.1);
            }
        });
    }

    @Test
    public void testInclusiveBetweenDouble_atEndBoundary_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 2.1);
            }
        });
    }

    @Test
    public void testInclusiveBetweenDouble_belowRange_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 0.0);
            }
        });
    }

    @Test
    public void testInclusiveBetweenDoubleWithMessage_aboveRange_usesMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 9.9, "Not in range");
            }
        });
        assertEquals("Not in range", ex.getMessage());
    }

    @Test
    public void testInclusiveBetweenLong_atBoundaries_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 0L);
                Validate.inclusiveBetween(0L, 2L, 2L);
            }
        });
    }

    @Test
    public void testInclusiveBetweenLong_outOfRange_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L);
            }
        });
    }

    @Test
    public void testInclusiveBetweenLongWithMessage_outOfRange_usesMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, -1L, "Not in range");
            }
        });
        assertEquals("Not in range", ex.getMessage());
    }

    @Test
    public void testInclusiveBetweenComparable_atBoundary_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0));
            }
        });
    }

    @Test
    public void testInclusiveBetweenComparable_outOfRange_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3));
            }
        });
    }

    @Test
    public void testInclusiveBetweenComparableWithMessage_outOfRange_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(9),
                        "Not in boundaries: %d", Integer.valueOf(9));
            }
        });
        assertEquals("Not in boundaries: 9", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // isAssignableFrom
    // ---------------------------------------------------------------

    @Test
    public void testIsAssignableFrom_assignable_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.isAssignableFrom(Number.class, Integer.class);
            }
        });
    }

    @Test
    public void testIsAssignableFrom_notAssignable_throws() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isAssignableFrom(Number.class, String.class);
            }
        });
        assertTrue(ex.getMessage().contains("String"));
        assertTrue(ex.getMessage().contains("Number"));
    }

    @Test
    public void testIsAssignableFromWithMessage_notAssignable_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isAssignableFrom(Number.class, String.class, "Bad type: %s", "String");
            }
        });
        assertEquals("Bad type: String", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // isInstanceOf
    // ---------------------------------------------------------------

    @Test
    public void testIsInstanceOf_matchingInstance_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.isInstanceOf(CharSequence.class, "hello");
            }
        });
    }

    @Test
    public void testIsInstanceOf_nonMatchingInstance_throws() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isInstanceOf(CharSequence.class, Integer.valueOf(1));
            }
        });
        assertTrue(ex.getMessage().contains("CharSequence"));
    }

    @Test
    public void testIsInstanceOf_nullObject_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isInstanceOf(CharSequence.class, null);
            }
        });
    }

    @Test
    public void testIsInstanceOfWithMessage_nonMatchingInstance_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isInstanceOf(CharSequence.class, Integer.valueOf(1), "Wrong class: %s", "Integer");
            }
        });
        assertEquals("Wrong class: Integer", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // isTrue
    // ---------------------------------------------------------------

    @Test
    public void testIsTrue_trueExpression_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.isTrue(true);
            }
        });
    }

    @Test
    public void testIsTrue_falseExpression_throwsWithDefaultMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isTrue(false);
            }
        });
        assertEquals("The validated expression is false", ex.getMessage());
    }

    @Test
    public void testIsTrueWithDoubleValue_falseExpression_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isTrue(false, "Value must be positive: %s", 1.5);
            }
        });
        assertEquals("Value must be positive: 1.5", ex.getMessage());
    }

    @Test
    public void testIsTrueWithLongValue_falseExpression_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isTrue(false, "Value must be positive: %s", 7L);
            }
        });
        assertEquals("Value must be positive: 7", ex.getMessage());
    }

    @Test
    public void testIsTrueWithObjectValues_falseExpression_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isTrue(false, "Value must be between %d and %d", Integer.valueOf(1), Integer.valueOf(10));
            }
        });
        assertEquals("Value must be between 1 and 10", ex.getMessage());
    }

    @Test
    public void testIsTrueWithSupplier_trueExpression_doesNotInvokeSupplier() {
        final boolean[] invoked = new boolean[] { false };
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.isTrue(true, new Supplier<String>() {
                    public String get() {
                        invoked[0] = true;
                        return "unused";
                    }
                });
            }
        });
        assertFalse(invoked[0]);
    }

    @Test
    public void testIsTrueWithSupplier_falseExpression_usesSuppliedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.isTrue(false, new Supplier<String>() {
                    public String get() {
                        return "Supplied message";
                    }
                });
            }
        });
        assertEquals("Supplied message", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // matchesPattern
    // ---------------------------------------------------------------

    @Test
    public void testMatchesPattern_matching_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.matchesPattern("hi", "[a-z]*");
            }
        });
    }

    @Test
    public void testMatchesPattern_notMatching_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.matchesPattern("HI", "[a-z]*");
            }
        });
    }

    @Test
    public void testMatchesPatternWithMessage_notMatching_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.matchesPattern("HI", "[a-z]*", "%s does not match %s", "HI", "[a-z]*");
            }
        });
        assertEquals("HI does not match [a-z]*", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // noNullElements (Iterable)
    // ---------------------------------------------------------------

    @Test
    public void testNoNullElementsIterable_noNulls_returnsSameInstance() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        List<String> result = Validate.noNullElements(list);
        assertSame(list, result);
    }

    @Test
    public void testNoNullElementsIterable_nullIterable_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.noNullElements((List<String>) null);
            }
        });
    }

    @Test
    public void testNoNullElementsIterable_containsNull_throwsIaeWithIndex() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add(null);
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.noNullElements(list);
            }
        });
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    public void testNoNullElementsIterableWithMessage_containsNull_appendsIndexToMessage() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add(null);
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.noNullElements(list, "Null element at position %d");
            }
        });
        assertEquals("Null element at position 1", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // noNullElements (array)
    // ---------------------------------------------------------------

    @Test
    public void testNoNullElementsArray_noNulls_returnsSameInstance() {
        String[] array = new String[] { "a", "b" };
        String[] result = Validate.noNullElements(array);
        assertSame(array, result);
    }

    @Test
    public void testNoNullElementsArray_nullArray_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.noNullElements((String[]) null);
            }
        });
    }

    @Test
    public void testNoNullElementsArray_containsNull_throwsIaeWithIndex() {
        final String[] array = new String[] { "a", null };
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.noNullElements(array);
            }
        });
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    public void testNoNullElementsArrayWithMessage_containsNull_appendsIndexToMessage() {
        final String[] array = new String[] { "a", null };
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.noNullElements(array, "Null element at position %d");
            }
        });
        assertEquals("Null element at position 1", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notBlank
    // ---------------------------------------------------------------

    @Test
    public void testNotBlank_nonBlank_returnsSameInstance() {
        String s = "hello";
        String result = Validate.notBlank(s);
        assertSame(s, result);
    }

    @Test
    public void testNotBlank_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notBlank((String) null);
            }
        });
    }

    @Test
    public void testNotBlank_empty_throwsIaeWithDefaultMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notBlank("");
            }
        });
        assertEquals("The validated character sequence is blank", ex.getMessage());
    }

    @Test
    public void testNotBlank_whitespace_throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notBlank("   ");
            }
        });
    }

    @Test
    public void testNotBlankWithMessage_blank_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notBlank("  ", "Must not be blank: %s", "value");
            }
        });
        assertEquals("Must not be blank: value", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notEmpty (Collection)
    // ---------------------------------------------------------------

    @Test
    public void testNotEmptyCollection_nonEmpty_returnsSameInstance() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        List<String> result = Validate.notEmpty(list);
        assertSame(list, result);
    }

    @Test
    public void testNotEmptyCollection_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notEmpty((List<String>) null);
            }
        });
    }

    @Test
    public void testNotEmptyCollection_empty_throwsIaeWithDefaultMessage() {
        final List<String> list = new ArrayList<String>();
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty(list);
            }
        });
        assertEquals("The validated collection is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyCollectionWithMessage_empty_usesFormattedMessage() {
        final List<String> list = new ArrayList<String>();
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty(list, "Collection must not be empty: %s", "list");
            }
        });
        assertEquals("Collection must not be empty: list", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notEmpty (Map)
    // ---------------------------------------------------------------

    @Test
    public void testNotEmptyMap_nonEmpty_returnsSameInstance() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        Map<String, String> result = Validate.notEmpty(map);
        assertSame(map, result);
    }

    @Test
    public void testNotEmptyMap_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notEmpty((Map<String, String>) null);
            }
        });
    }

    @Test
    public void testNotEmptyMap_empty_throwsIaeWithDefaultMessage() {
        final Map<String, String> map = new HashMap<String, String>();
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty(map);
            }
        });
        assertEquals("The validated map is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyMapWithMessage_empty_usesFormattedMessage() {
        final Map<String, String> map = new HashMap<String, String>();
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty(map, "Map must not be empty: %s", "map");
            }
        });
        assertEquals("Map must not be empty: map", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notEmpty (CharSequence)
    // ---------------------------------------------------------------

    @Test
    public void testNotEmptyCharSequence_nonEmpty_returnsSameInstance() {
        String s = "hello";
        String result = Validate.notEmpty(s);
        assertSame(s, result);
    }

    @Test
    public void testNotEmptyCharSequence_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notEmpty((String) null);
            }
        });
    }

    @Test
    public void testNotEmptyCharSequence_empty_throwsIaeWithDefaultMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty("");
            }
        });
        assertEquals("The validated character sequence is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyCharSequence_blankButNotEmpty_doesNotThrow() {
        String s = "   ";
        assertSame(s, Validate.notEmpty(s));
    }

    @Test
    public void testNotEmptyCharSequenceWithMessage_empty_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty("", "String must not be empty: %s", "value");
            }
        });
        assertEquals("String must not be empty: value", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notEmpty (array)
    // ---------------------------------------------------------------

    @Test
    public void testNotEmptyArray_nonEmpty_returnsSameInstance() {
        String[] array = new String[] { "a" };
        String[] result = Validate.notEmpty(array);
        assertSame(array, result);
    }

    @Test
    public void testNotEmptyArray_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notEmpty((String[]) null);
            }
        });
    }

    @Test
    public void testNotEmptyArray_empty_throwsIaeWithDefaultMessage() {
        final String[] array = new String[0];
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty(array);
            }
        });
        assertEquals("The validated array is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyArrayWithMessage_empty_usesFormattedMessage() {
        final String[] array = new String[0];
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notEmpty(array, "Array must not be empty: %s", "array");
            }
        });
        assertEquals("Array must not be empty: array", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notNaN
    // ---------------------------------------------------------------

    @Test
    public void testNotNaN_normalValue_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.notNaN(1.5);
            }
        });
    }

    @Test
    public void testNotNaN_infiniteValue_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.notNaN(Double.POSITIVE_INFINITY);
            }
        });
    }

    @Test
    public void testNotNaN_nan_throwsIaeWithDefaultMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notNaN(Double.NaN);
            }
        });
        assertEquals("The validated value is not a number", ex.getMessage());
    }

    @Test
    public void testNotNaNWithMessage_nan_usesFormattedMessage() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                Validate.notNaN(Double.NaN, "Value must be numeric: %s", "value");
            }
        });
        assertEquals("Value must be numeric: value", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // notNull
    // ---------------------------------------------------------------

    @Test
    public void testNotNull_nonNull_returnsSameInstance() {
        String s = "hello";
        String result = Validate.notNull(s);
        assertSame(s, result);
    }

    @Test
    public void testNotNull_null_throwsNpeWithDefaultMessage() {
        NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notNull((String) null);
            }
        });
        assertEquals("The validated object is null", ex.getMessage());
    }

    @Test
    public void testNotNullWithMessage_nonNull_returnsSameInstance() {
        String s = "hello";
        String result = Validate.notNull(s, "must not be null");
        assertSame(s, result);
    }

    @Test
    public void testNotNullWithMessage_null_usesFormattedMessage() {
        NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.notNull(null, "Object must not be null: %s", "value");
            }
        });
        assertEquals("Object must not be null: value", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // validIndex (Collection)
    // ---------------------------------------------------------------

    @Test
    public void testValidIndexCollection_validIndex_returnsSameInstance() {
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        List<String> result = Validate.validIndex(list, 1);
        assertSame(list, result);
    }

    @Test
    public void testValidIndexCollection_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.validIndex((List<String>) null, 0);
            }
        });
    }

    @Test
    public void testValidIndexCollection_negativeIndex_throwsIndexOutOfBounds() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex(list, -1);
            }
        });
    }

    @Test
    public void testValidIndexCollection_indexEqualToSize_throwsIndexOutOfBounds() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex(list, 1);
            }
        });
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    public void testValidIndexCollectionWithMessage_invalidIndex_usesFormattedMessage() {
        final List<String> list = new ArrayList<String>();
        IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex(list, 0, "Bad index: %d", Integer.valueOf(0));
            }
        });
        assertEquals("Bad index: 0", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // validIndex (CharSequence)
    // ---------------------------------------------------------------

    @Test
    public void testValidIndexCharSequence_validIndex_returnsSameInstance() {
        String s = "hello";
        String result = Validate.validIndex(s, 2);
        assertSame(s, result);
    }

    @Test
    public void testValidIndexCharSequence_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.validIndex((String) null, 0);
            }
        });
    }

    @Test
    public void testValidIndexCharSequence_indexEqualToLength_throwsIndexOutOfBounds() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex("hi", 2);
            }
        });
    }

    @Test
    public void testValidIndexCharSequenceWithMessage_invalidIndex_usesFormattedMessage() {
        IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex("hi", 5, "Bad string index: %d", Integer.valueOf(5));
            }
        });
        assertEquals("Bad string index: 5", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // validIndex (array)
    // ---------------------------------------------------------------

    @Test
    public void testValidIndexArray_validIndex_returnsSameInstance() {
        String[] array = new String[] { "a", "b" };
        String[] result = Validate.validIndex(array, 0);
        assertSame(array, result);
    }

    @Test
    public void testValidIndexArray_null_throwsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                Validate.validIndex((String[]) null, 0);
            }
        });
    }

    @Test
    public void testValidIndexArray_indexEqualToLength_throwsIndexOutOfBounds() {
        final String[] array = new String[] { "a" };
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex(array, 1);
            }
        });
    }

    @Test
    public void testValidIndexArrayWithMessage_invalidIndex_usesFormattedMessage() {
        final String[] array = new String[0];
        IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                Validate.validIndex(array, 0, "Bad array index: %d", Integer.valueOf(0));
            }
        });
        assertEquals("Bad array index: 0", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // validState
    // ---------------------------------------------------------------

    @Test
    public void testValidState_trueExpression_doesNotThrow() {
        assertDoesNotThrow(new Executable() {
            public void execute() {
                Validate.validState(true);
            }
        });
    }

    @Test
    public void testValidState_falseExpression_throwsWithDefaultMessage() {
        IllegalStateException ex = assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                Validate.validState(false);
            }
        });
        assertEquals("The validated state is false", ex.getMessage());
    }

    @Test
    public void testValidStateWithMessage_falseExpression_usesFormattedMessage() {
        IllegalStateException ex = assertThrows(IllegalStateException.class, new Executable() {
            public void execute() {
                Validate.validState(false, "The state is not OK: %s", "myObject");
            }
        });
        assertEquals("The state is not OK: myObject", ex.getMessage());
    }
}
