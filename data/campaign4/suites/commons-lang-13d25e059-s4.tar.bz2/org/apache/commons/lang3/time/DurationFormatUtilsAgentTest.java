package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Self-contained tests for {@link DurationFormatUtils}, based solely on the
 * javadoc contract and the constant values published in the generated API docs.
 */
public class DurationFormatUtilsAgentTest {

    private static final long ONE_SECOND = 1000L;
    private static final long ONE_MINUTE = 60L * ONE_SECOND;
    private static final long ONE_HOUR = 60L * ONE_MINUTE;
    private static final long ONE_DAY = 24L * ONE_HOUR;

    // ------------------------------------------------------------------
    // Deprecated public constructor
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    public void testPublicConstructorIsUsable() {
        DurationFormatUtils instance = new DurationFormatUtils();
        assertNotNull(instance);
    }

    // ------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------

    @Test
    public void testIsoExtendedFormatPatternConstantValue() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    @Test
    public void testPackagePrivateSingleCharacterFieldConstants() {
        assertEquals("y", DurationFormatUtils.y);
        assertEquals("M", DurationFormatUtils.M);
        assertEquals("d", DurationFormatUtils.d);
        assertEquals("H", DurationFormatUtils.H);
        assertEquals("m", DurationFormatUtils.m);
        assertEquals("s", DurationFormatUtils.s);
        assertEquals("S", DurationFormatUtils.S);
    }

    // ------------------------------------------------------------------
    // formatDurationHMS(long)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationHMSZero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
    }

    @Test
    public void testFormatDurationHMSTypicalValue() {
        // 1 hour, 1 minute, 1 second, 1 millisecond
        long millis = ONE_HOUR + ONE_MINUTE + ONE_SECOND + 1L;
        assertEquals("01:01:01.001", DurationFormatUtils.formatDurationHMS(millis));
    }

    @Test
    public void testFormatDurationHMSNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDurationHMS(-1L);
            }
        });
    }

    // ------------------------------------------------------------------
    // formatDurationISO(long)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationISODocumentedExample() {
        // javadoc: "such as P7D6TH5M4.321S" for 7 days, 6 hours, 5 minutes, 4.321 seconds
        long millis = 7L * ONE_DAY + 6L * ONE_HOUR + 5L * ONE_MINUTE + 4321L;
        assertEquals("P7D6TH5M4.321S", DurationFormatUtils.formatDurationISO(millis));
    }

    @Test
    public void testFormatDurationISOZero() {
        // Same literal template as the documented example, applied to a zero duration.
        assertEquals("P0D0TH0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    @Test
    public void testFormatDurationISONegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDurationISO(-1L);
            }
        });
    }

    // ------------------------------------------------------------------
    // formatDuration(long, String) / formatDuration(long, String, boolean)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "d");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "d", false);
            }
        });
    }

    @Test
    public void testFormatDurationTwoArgDefaultsToPadded() {
        assertEquals(
                DurationFormatUtils.formatDuration(ONE_HOUR, "HH:mm", true),
                DurationFormatUtils.formatDuration(ONE_HOUR, "HH:mm"));
    }

    @Test
    public void testFormatDurationPadWithZerosTrueVsFalse() {
        assertEquals("01", DurationFormatUtils.formatDuration(ONE_HOUR, "HH", true));
        assertEquals("1", DurationFormatUtils.formatDuration(ONE_HOUR, "HH", false));
    }

    @Test
    public void testFormatDurationZero() {
        assertEquals("0", DurationFormatUtils.formatDuration(0L, "d"));
    }

    /**
     * These cases are copied verbatim from the class-level javadoc "Example Output" table.
     */
    @Test
    public void testFormatDurationExampleTablePattern1() {
        String pattern = "d'd'H'h'm'm's's'";
        assertEquals("1d0h0m0s", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("0d1h0m0s", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("0d0h1m0s", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("0d0h0m0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTablePattern2() {
        String pattern = "d'd'[H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTablePattern3() {
        String pattern = "[d'd'H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("1h0s", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("1m0s", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTablePattern4() {
        String pattern = "[d'd'H'h'm'm's's']";
        assertEquals("1d", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("1h", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("1m", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTablePattern5() {
        String pattern = "['{'d'}']HH':'mm";
        assertEquals("{1}00:00", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("01:00", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("00:01", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("00:00", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTablePattern6() {
        String pattern = "['{'dd'}']['<'HH'>']['('mm')']";
        assertEquals("{01}", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("<01>", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("(00)", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testFormatDurationExampleTablePattern7() {
        String pattern = "[dHms]";
        assertEquals("1", DurationFormatUtils.formatDuration(ONE_DAY, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(ONE_HOUR, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(ONE_MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    // ------------------------------------------------------------------
    // formatDurationWords(long, boolean, boolean)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationWordsNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDurationWords(-1L, false, false);
            }
        });
    }

    @Test
    public void testFormatDurationWordsZeroDoesNotThrowAndIsNotNull() {
        String result = DurationFormatUtils.formatDurationWords(0L, false, false);
        assertNotNull(result);
    }

    @Test
    public void testFormatDurationWordsSuppressLeadingZeroElementsShortensResult() {
        // Only seconds is non-zero: days, hours and minutes are all leading zero elements.
        long millis = ONE_SECOND;
        String withLeadingZeros = DurationFormatUtils.formatDurationWords(millis, false, false);
        String suppressedLeadingZeros = DurationFormatUtils.formatDurationWords(millis, true, false);
        assertNotNull(withLeadingZeros);
        assertNotNull(suppressedLeadingZeros);
        assertTrue(suppressedLeadingZeros.length() < withLeadingZeros.length());
    }

    @Test
    public void testFormatDurationWordsSuppressTrailingZeroElementsShortensResult() {
        // Exactly one day: hours, minutes and seconds are all trailing zero elements.
        long millis = ONE_DAY;
        String withTrailingZeros = DurationFormatUtils.formatDurationWords(millis, false, false);
        String suppressedTrailingZeros = DurationFormatUtils.formatDurationWords(millis, false, true);
        assertNotNull(withTrailingZeros);
        assertNotNull(suppressedTrailingZeros);
        assertTrue(suppressedTrailingZeros.length() < withTrailingZeros.length());
    }

    // ------------------------------------------------------------------
    // formatPeriod(long, long, String) / formatPeriod(long, long, String, boolean, TimeZone)
    // ------------------------------------------------------------------

    @Test
    public void testFormatPeriodStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(100L, 50L, "d");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(100L, 50L, "d", true, TimeZone.getTimeZone("UTC"));
            }
        });
    }

    @Test
    public void testFormatPeriodZeroElapsedTime() {
        // start == end is the boundary: must not throw, and every field is zero.
        assertEquals("0y0M0d", DurationFormatUtils.formatPeriod(123456L, 123456L, "y'y'M'M'd'd'"));
    }

    @Test
    public void testFormatPeriodOneDayApartSameMonth() {
        // 1970-01-01T00:00:00Z to 1970-01-02T00:00:00Z: exactly one day, no month boundary.
        long start = 0L;
        long end = ONE_DAY;
        TimeZone utc = TimeZone.getTimeZone("UTC");
        assertEquals("1", DurationFormatUtils.formatPeriod(start, end, "d", true, utc));
        assertEquals("01", DurationFormatUtils.formatPeriod(start, end, "dd", true, utc));
        assertEquals("1", DurationFormatUtils.formatPeriod(start, end, "dd", false, utc));
    }

    @Test
    public void testFormatPeriodMonthsCalculatedFirst() {
        // 2020-01-01T00:00:00Z to 2020-03-01T00:00:00Z is exactly 2 months and 0 days,
        // matching the "months are calculated first" rule described in the javadoc.
        long start = 1577836800000L;
        long end = 1583020800000L;
        TimeZone utc = TimeZone.getTimeZone("UTC");
        assertEquals("2M0d", DurationFormatUtils.formatPeriod(start, end, "M'M'd'd'", true, utc));
    }

    @Test
    public void testFormatPeriodYearsCalculatedFirst() {
        // 2020-01-01T00:00:00Z to 2022-01-01T00:00:00Z is exactly 2 years, 0 months, 0 days.
        long start = 1577836800000L;
        long end = 1640995200000L;
        TimeZone utc = TimeZone.getTimeZone("UTC");
        assertEquals("2y0M0d", DurationFormatUtils.formatPeriod(start, end, "y'y'M'M'd'd'", true, utc));
        assertEquals("0002", DurationFormatUtils.formatPeriod(start, end, "yyyy", true, utc));
    }

    // ------------------------------------------------------------------
    // formatPeriodISO(long, long)
    // ------------------------------------------------------------------

    @Test
    public void testFormatPeriodISOStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriodISO(100L, 50L);
            }
        });
    }

    @Test
    public void testFormatPeriodISOZeroElapsedTimeHasIsoShape() {
        String result = DurationFormatUtils.formatPeriodISO(1000L, 1000L);
        assertNotNull(result);
        assertTrue(result.startsWith("P"));
        assertTrue(result.endsWith("S"));
    }

    // ------------------------------------------------------------------
    // lexx(String) - package-private
    // ------------------------------------------------------------------

    @Test
    public void testLexxEmptyFormatProducesNoTokens() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("");
        assertNotNull(tokens);
        assertEquals(0, tokens.length);
    }

    @Test
    public void testLexxRepeatedCharacterIsSingleTokenWithCount() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertEquals(1, tokens.length);
        assertEquals(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
    }

    @Test
    public void testLexxQuotedLiteralText() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("'hello'");
        assertEquals(1, tokens.length);
        assertEquals("hello", tokens[0].getValue().toString());
        assertEquals(1, tokens[0].getCount());
    }

    @Test
    public void testLexxMixedPatternTokenSequence() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy-MM-dd");
        assertEquals(5, tokens.length);

        assertEquals(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());

        assertEquals("-", tokens[1].getValue().toString());
        assertEquals(1, tokens[1].getCount());

        assertEquals(DurationFormatUtils.M, tokens[2].getValue());
        assertEquals(2, tokens[2].getCount());

        assertEquals("-", tokens[3].getValue().toString());
        assertEquals(1, tokens[3].getCount());

        assertEquals(DurationFormatUtils.d, tokens[4].getValue());
        assertEquals(2, tokens[4].getCount());
    }

    // ------------------------------------------------------------------
    // format(Token[], ...) - package-private internal formatting engine
    // ------------------------------------------------------------------

    @Test
    public void testFormatWithEmptyTokenArrayProducesEmptyString() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[0];
        assertEquals("", DurationFormatUtils.format(tokens, 1L, 2L, 3L, 4L, 5L, 6L, 7L, true));
    }

    @Test
    public void testFormatUsesYearsAndMonthsFields() {
        // format() exposes years/months, unlike the public formatDuration methods.
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("y'y'M'M'd'd'");
        String result = DurationFormatUtils.format(tokens, 2L, 3L, 4L, 0L, 0L, 0L, 0L, true);
        assertEquals("2y3M4d", result);
    }

    @Test
    public void testFormatPaddingFlagControlsLeadingZeros() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertEquals("0005", DurationFormatUtils.format(tokens, 5L, 0L, 0L, 0L, 0L, 0L, 0L, true));
        assertEquals("5", DurationFormatUtils.format(tokens, 5L, 0L, 0L, 0L, 0L, 0L, 0L, false));
    }

    @Test
    public void testFormatReplicatesExampleTableViaTokensDirectly() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'H'h'm'm's's'");
        String result = DurationFormatUtils.format(tokens, 0L, 0L, 1L, 0L, 0L, 0L, 0L, true);
        assertEquals("1d0h0m0s", result);
    }

    // ------------------------------------------------------------------
    // DurationFormatUtils.Token - package-private nested class
    // ------------------------------------------------------------------

    @Test
    public void testTokenGetValueAndInitialCount() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token("y", false, 0);
        assertEquals("y", token.getValue());
        assertEquals(1, token.getCount());
    }

    @Test
    public void testTokenIncrementIncreasesCount() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token("y", false, 0);
        token.increment();
        token.increment();
        assertEquals(3, token.getCount());
    }

    @Test
    public void testTokenEqualsAndHashCodeDependOnValueOnly() {
        // javadoc: "'TT' and 'TTTT' will have the same hash code", i.e. count/optional
        // flags do not participate in equality or hashing, only the wrapped value does.
        DurationFormatUtils.Token a = new DurationFormatUtils.Token("H", false, 0);
        DurationFormatUtils.Token b = new DurationFormatUtils.Token("H", true, 7);
        b.increment();
        b.increment();

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testTokenNotEqualsForDifferentValue() {
        DurationFormatUtils.Token a = new DurationFormatUtils.Token("H", false, 0);
        DurationFormatUtils.Token c = new DurationFormatUtils.Token("m", false, 0);
        assertFalse(a.equals(c));
    }

    @Test
    public void testTokenToStringIsNotNullOrEmpty() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token("H", false, 0);
        String text = token.toString();
        assertNotNull(text);
        assertTrue(text.length() > 0);
    }

    @Test
    public void testContainsTokenWithValue() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy-MM-dd");

        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.M));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.d));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, "-"));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
    }

    @Test
    public void testContainsTokenWithValueOnEmptyArray() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[0];
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
    }
}
