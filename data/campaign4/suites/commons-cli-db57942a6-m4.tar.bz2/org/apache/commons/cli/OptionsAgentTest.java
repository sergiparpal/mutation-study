/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link Options}.
 */
class OptionsAgentTest {

    @Test
    void testNewInstanceIsEmpty() {
        final Options options = new Options();
        assertTrue(options.getOptions().isEmpty());
        assertTrue(options.getRequiredOptions().isEmpty());
        assertFalse(options.hasOption("x"));
        assertFalse(options.hasShortOption("x"));
        assertFalse(options.hasLongOption("x"));
        assertNull(options.getOption("x"));
    }

    @Test
    void testAddOptionByCharsReturnsSameInstance() {
        final Options options = new Options();
        final Options returned = options.addOption("a", false, "a option");
        assertSame(options, returned);
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasShortOption("a"));
        assertFalse(options.hasLongOption("a"));
        assertEquals(1, options.getOptions().size());
    }

    @Test
    void testAddOptionShortOnlyDescription() {
        final Options options = new Options();
        options.addOption("v", "verbose mode");
        final Option opt = options.getOption("v");
        assertNotNull(opt);
        assertEquals("verbose mode", opt.getDescription());
        assertFalse(opt.hasArg());
        assertFalse(opt.hasLongOpt());
    }

    @Test
    void testAddOptionShortAndLong() {
        final Options options = new Options();
        options.addOption("f", "file", true, "file to process");
        assertTrue(options.hasShortOption("f"));
        assertTrue(options.hasLongOption("file"));
        assertSame(options.getOption("f"), options.getOption("file"));
        assertSame(options.getOption("f"), options.getOption("--file"));
        assertSame(options.getOption("f"), options.getOption("-f"));
    }

    @Test
    void testAddOptionInstance() {
        final Options options = new Options();
        final Option option = new Option("b", "bar", false, "bar option");
        final Options returned = options.addOption(option);
        assertSame(options, returned);
        assertSame(option, options.getOption("b"));
        assertSame(option, options.getOption("bar"));
    }

    @Test
    void testAddOptionWithoutLongOptDoesNotRegisterLongOpt() {
        final Options options = new Options();
        options.addOption(new Option("x", false, "x option"));
        assertFalse(options.hasLongOption("x"));
        assertTrue(options.hasShortOption("x"));
    }

    @Test
    void testAddOptionOverwritesExistingShortOption() {
        final Options options = new Options();
        final Option first = new Option("a", false, "first");
        final Option second = new Option("a", false, "second");
        options.addOption(first);
        options.addOption(second);
        assertEquals(1, options.getOptions().size());
        assertSame(second, options.getOption("a"));
    }

    @Test
    void testGetOptionStripsLeadingHyphens() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertSame(options.getOption("f"), options.getOption("-f"));
        assertSame(options.getOption("file"), options.getOption("--file"));
    }

    @Test
    void testGetOptionUnknownReturnsNull() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertNull(options.getOption("z"));
        assertNull(options.getOption("unknown"));
    }

    @Test
    void testGetOptionNullArgument() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertNull(options.getOption(null));
        assertFalse(options.hasOption(null));
    }

    @Test
    void testHasOptionMatchesEitherShortOrLong() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertTrue(options.hasOption("f"));
        assertTrue(options.hasOption("file"));
        assertTrue(options.hasOption("-f"));
        assertTrue(options.hasOption("--file"));
        assertFalse(options.hasOption("g"));
    }

    @Test
    void testAddRequiredOption() {
        final Options options = new Options();
        options.addRequiredOption("r", "required", true, "required option");
        final Option opt = options.getOption("r");
        assertNotNull(opt);
        assertTrue(opt.isRequired());
        assertTrue(opt.hasArg());
        final List<?> required = options.getRequiredOptions();
        assertEquals(1, required.size());
        assertEquals("r", required.get(0));
    }

    @Test
    void testAddOptionRequiredAddedOnlyOnceWhenReAdded() {
        final Options options = new Options();
        final Option required = new Option("r", false, "required option");
        required.setRequired(true);
        options.addOption(required);
        options.addOption(required);
        assertEquals(1, options.getRequiredOptions().size());
    }

    @Test
    void testGetRequiredOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addRequiredOption("r", "required", false, "required option");
        final List<?> required = options.getRequiredOptions();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            @SuppressWarnings("unchecked")
            public void execute() {
                ((List<Object>) required).add("x");
            }
        });
    }

    @Test
    void testGetOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addOption("a", false, "a option");
        final Collection<Option> opts = options.getOptions();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                opts.remove(opts.iterator().next());
            }
        });
    }

    @Test
    void testAddOptionGroupMarksRequiredWhenGroupRequired() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option a = new Option("a", false, "a option");
        final Option b = new Option("b", false, "b option");
        group.addOption(a);
        group.addOption(b);
        group.setRequired(true);
        options.addOptionGroup(group);
        assertEquals(1, options.getRequiredOptions().size());
        assertSame(group, options.getRequiredOptions().get(0));
        assertFalse(a.isRequired());
        assertFalse(b.isRequired());
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasOption("b"));
    }

    @Test
    void testAddOptionGroupOptionsBecomeOptionalEvenIfPreviouslyRequired() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option a = new Option("a", false, "a option");
        a.setRequired(true);
        group.addOption(a);
        options.addOptionGroup(group);
        assertFalse(a.isRequired());
        assertTrue(options.getRequiredOptions().isEmpty());
    }

    @Test
    void testGetOptionGroupReturnsGroupForMember() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option a = new Option("a", false, "a option");
        final Option b = new Option("b", false, "b option");
        group.addOption(a);
        group.addOption(b);
        options.addOptionGroup(group);
        assertSame(group, options.getOptionGroup(a));
        assertSame(group, options.getOptionGroup(b));
    }

    @Test
    void testGetOptionGroupReturnsNullForNonMember() {
        final Options options = new Options();
        options.addOption("c", false, "c option");
        final Option c = options.getOption("c");
        assertNull(options.getOptionGroup(c));
    }

    @Test
    void testAddOptionsCopiesAllOptions() {
        final Options source = new Options();
        source.addOption("a", false, "a option");
        source.addOption("b", "bar", false, "b option");
        final Options target = new Options();
        final Options returned = target.addOptions(source);
        assertSame(target, returned);
        assertTrue(target.hasOption("a"));
        assertTrue(target.hasOption("b"));
        assertTrue(target.hasLongOption("bar"));
    }

    @Test
    void testAddOptionsCopiesOptionGroups() {
        final Options source = new Options();
        final OptionGroup group = new OptionGroup();
        final Option a = new Option("a", false, "a option");
        final Option b = new Option("b", false, "b option");
        group.addOption(a);
        group.addOption(b);
        source.addOptionGroup(group);
        final Options target = new Options();
        target.addOptions(source);
        assertNotNull(target.getOptionGroup(target.getOption("a")));
        assertNotNull(target.getOptionGroup(target.getOption("b")));
    }

    @Test
    void testAddOptionsThrowsOnDuplicateKey() {
        final Options source = new Options();
        source.addOption("a", false, "a option");
        final Options target = new Options();
        target.addOption("a", false, "existing a option");
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                target.addOptions(source);
            }
        });
        assertTrue(e.getMessage().contains("a"));
    }

    @Test
    void testGetMatchingOptionsExactMatch() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        options.addOption("d", "filter", false, "filter");
        final List<String> matches = options.getMatchingOptions("file");
        assertEquals(1, matches.size());
        assertEquals("file", matches.get(0));
    }

    @Test
    void testGetMatchingOptionsPartialMatch() {
        final Options options = new Options();
        options.addOption("f", "foo", false, "foo");
        options.addOption("b", "foobar", false, "foobar");
        final List<String> matches = options.getMatchingOptions("fo");
        assertEquals(2, matches.size());
        assertTrue(matches.contains("foo"));
        assertTrue(matches.contains("foobar"));
    }

    @Test
    void testGetMatchingOptionsNoMatch() {
        final Options options = new Options();
        options.addOption("f", "foo", false, "foo");
        assertTrue(options.getMatchingOptions("xyz").isEmpty());
    }

    @Test
    void testGetMatchingOptionsNullOrEmptyReturnsEmpty() {
        final Options options = new Options();
        options.addOption("f", "foo", false, "foo");
        assertTrue(options.getMatchingOptions(null).isEmpty());
        assertTrue(options.getMatchingOptions("").isEmpty());
    }

    @Test
    void testToStringContainsShortAndLongSections() {
        final Options options = new Options();
        options.addOption("a", "alpha", false, "alpha option");
        final String str = options.toString();
        assertTrue(str.contains("[ Options:"));
        assertTrue(str.contains("short"));
        assertTrue(str.contains("long"));
    }

    @Test
    void testToStringOnEmptyOptions() {
        final Options options = new Options();
        final String str = options.toString();
        assertNotNull(str);
        assertTrue(str.startsWith("[ Options:"));
    }

    @Test
    void testOptionOrderPreserved() {
        final Options options = new Options();
        options.addOption("c", false, "c option");
        options.addOption("a", false, "a option");
        options.addOption("b", false, "b option");
        final List<Option> opts = new java.util.ArrayList<Option>(options.getOptions());
        assertEquals(3, opts.size());
        assertEquals("c", opts.get(0).getOpt());
        assertEquals("a", opts.get(1).getOpt());
        assertEquals("b", opts.get(2).getOpt());
    }
}
