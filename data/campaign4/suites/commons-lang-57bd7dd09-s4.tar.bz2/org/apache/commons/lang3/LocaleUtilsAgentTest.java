package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link LocaleUtils}, based solely on its published javadoc contract.
 */
public class LocaleUtilsAgentTest {

    private static void assertUnmodifiable(List<Locale> list) {
        try {
            list.add(Locale.US);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected: contract states the returned list is unmodifiable
        }
    }

    private static void assertUnmodifiable(Set<Locale> set) {
        try {
            set.add(Locale.US);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected: contract states the returned set is unmodifiable
        }
    }

    // --- constructor -------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructor() {
        assertNotNull(new LocaleUtils());
    }

    // --- availableLocaleList / availableLocaleSet ---------------------------

    @Test
    public void testAvailableLocaleListNotNullNotEmpty() {
        List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleListIsUnmodifiable() {
        assertUnmodifiable(LocaleUtils.availableLocaleList());
    }

    @Test
    public void testAvailableLocaleSetNotNullNotEmpty() {
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleSetIsUnmodifiable() {
        assertUnmodifiable(LocaleUtils.availableLocaleSet());
    }

    @Test
    public void testAvailableLocaleListAndSetHaveSameContent() {
        List<Locale> list = LocaleUtils.availableLocaleList();
        Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertEquals(set.size(), list.size());
        assertTrue(set.containsAll(list));
        assertTrue(list.containsAll(set));
    }

    // --- isAvailableLocale ---------------------------------------------------

    @Test
    public void testIsAvailableLocaleKnown() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
    }

    @Test
    public void testIsAvailableLocaleUnknown() {
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "YY")));
    }

    @Test
    public void testIsAvailableLocaleNull() {
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    // --- isLanguageUndetermined ----------------------------------------------

    @Test
    public void testIsLanguageUndeterminedForUnd() {
        assertTrue(LocaleUtils.isLanguageUndetermined(Locale.forLanguageTag("und")));
    }

    @Test
    public void testIsLanguageUndeterminedFalseForKnownLanguage() {
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
    }

    @Test
    public void testIsLanguageUndeterminedForEmptyLanguage() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
    }

    @Test
    public void testIsLanguageUndeterminedForNotWellFormedLanguage() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("e2")));
    }

    @Test
    public void testIsLanguageUndeterminedNullDoesNotThrow() {
        // The class-level contract promises graceful handling of null input: no exception.
        LocaleUtils.isLanguageUndetermined(null);
    }

    // --- countriesByLanguage -------------------------------------------------

    @Test
    public void testCountriesByLanguageNull() {
        List<Locale> result = LocaleUtils.countriesByLanguage(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageUnknown() {
        List<Locale> result = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageKnown() {
        List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        boolean foundUs = false;
        for (Locale locale : result) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
            if ("US".equals(locale.getCountry())) {
                foundUs = true;
            }
        }
        assertTrue(foundUs);
    }

    @Test
    public void testCountriesByLanguageIsUnmodifiable() {
        assertUnmodifiable(LocaleUtils.countriesByLanguage("en"));
    }

    // --- languagesByCountry ---------------------------------------------------

    @Test
    public void testLanguagesByCountryNull() {
        List<Locale> result = LocaleUtils.languagesByCountry(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUnknown() {
        List<Locale> result = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryKnown() {
        List<Locale> result = LocaleUtils.languagesByCountry("US");
        assertNotNull(result);
        assertFalse(result.isEmpty());
        boolean foundEnglish = false;
        for (Locale locale : result) {
            assertEquals("US", locale.getCountry());
            assertFalse(locale.getLanguage().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
            if ("en".equals(locale.getLanguage())) {
                foundEnglish = true;
            }
        }
        assertTrue(foundEnglish);
    }

    @Test
    public void testLanguagesByCountryIsUnmodifiable() {
        assertUnmodifiable(LocaleUtils.languagesByCountry("US"));
    }

    // --- localeLookupList(Locale) --------------------------------------------

    @Test
    public void testLocaleLookupListSingleArgNull() {
        List<Locale> result = LocaleUtils.localeLookupList(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListSingleArgWithVariant() {
        Locale locale = new Locale("fr", "CA", "xxx");
        List<Locale> expected = Arrays.asList(new Locale("fr", "CA", "xxx"), new Locale("fr", "CA"), new Locale("fr"));
        assertEquals(expected, LocaleUtils.localeLookupList(locale));
    }

    @Test
    public void testLocaleLookupListSingleArgLanguageOnly() {
        List<Locale> expected = Arrays.asList(new Locale("fr"));
        assertEquals(expected, LocaleUtils.localeLookupList(new Locale("fr")));
    }

    @Test
    public void testLocaleLookupListSingleArgFirstElementIsGivenLocale() {
        Locale locale = new Locale("fr", "CA", "xxx");
        List<Locale> result = LocaleUtils.localeLookupList(locale);
        assertEquals(locale, result.get(0));
    }

    @Test
    public void testLocaleLookupListSingleArgIsUnmodifiable() {
        assertUnmodifiable(LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx")));
    }

    // --- localeLookupList(Locale, Locale) ------------------------------------

    @Test
    public void testLocaleLookupListTwoArgNullLocale() {
        List<Locale> result = LocaleUtils.localeLookupList(null, Locale.ENGLISH);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListTwoArgWithVariantAndDefault() {
        Locale locale = new Locale("fr", "CA", "xxx");
        Locale defaultLocale = new Locale("en");
        List<Locale> expected = Arrays.asList(new Locale("fr", "CA", "xxx"), new Locale("fr", "CA"),
                new Locale("fr"), new Locale("en"));
        assertEquals(expected, LocaleUtils.localeLookupList(locale, defaultLocale));
    }

    @Test
    public void testLocaleLookupListTwoArgNeverDuplicatesLocale() {
        Locale locale = new Locale("fr");
        List<Locale> result = LocaleUtils.localeLookupList(locale, locale);
        assertEquals(Arrays.asList(new Locale("fr")), result);
    }

    @Test
    public void testLocaleLookupListTwoArgIsUnmodifiable() {
        assertUnmodifiable(LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"), Locale.ENGLISH));
    }

    // --- toLocale(Locale) ------------------------------------------------------

    @Test
    public void testToLocaleLocaleNonNullReturnsSameValue() {
        Locale locale = new Locale("de", "DE");
        assertEquals(locale, LocaleUtils.toLocale(locale));
    }

    @Test
    public void testToLocaleLocaleNullReturnsDefault() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    // --- toLocale(String) --------------------------------------------------------

    @Test
    public void testToLocaleStringNull() {
        assertEquals(null, LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en", ""), LocaleUtils.toLocale("en"));
    }

    @Test
    public void testToLocaleStringLanguageAndCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    public void testToLocaleStringLanguageAndCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    public void testToLocaleStringNumericArea() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    public void testToLocaleStringWithVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    public void testToLocaleStringBareIsoCountry() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    public void testToLocaleStringInvalidLowercaseCountry() {
        try {
            LocaleUtils.toLocale("en_gb");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: country code must be uppercase
        }
    }

    @Test
    public void testToLocaleStringInvalidUppercaseLanguage() {
        try {
            LocaleUtils.toLocale("EN");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: language code must be lowercase, and "EN" is not a valid ISO country
        }
    }

    @Test
    public void testToLocaleStringInvalidTrailingSeparator() {
        try {
            LocaleUtils.toLocale("en_GB_");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: malformed variant section
        }
    }

    @Test
    public void testToLocaleStringInvalidShortCountry() {
        try {
            LocaleUtils.toLocale("en_G");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: country code must be exactly 2 letters (or 3 digits)
        }
    }

    // --- package-private helpers (accessible from same package) -------------------

    @Test
    public void testOfCountryNullThrowsNullPointerException() {
        try {
            LocaleUtils.ofCountry(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // expected per documented contract
        }
    }

    @Test
    public void testOfCountryKnownCountry() {
        Locale locale = LocaleUtils.ofCountry("FR");
        assertNotNull(locale);
        assertEquals("FR", locale.getCountry());
        assertEquals("", locale.getLanguage());
    }

    @Test
    public void testGetLcToLocalesMapNotNull() {
        ConcurrentMap<String, List<Locale>> map = LocaleUtils.getLcToLocalesMap();
        assertNotNull(map);
    }

    @Test
    public void testGetLcToLocalesMapIsCachedAcrossCalls() {
        ConcurrentMap<String, List<Locale>> first = LocaleUtils.getLcToLocalesMap();
        ConcurrentMap<String, List<Locale>> second = LocaleUtils.getLcToLocalesMap();
        assertSame(first, second);
    }

    @Test
    public void testGetCcToLocalesMapNotNull() {
        ConcurrentMap<String, List<Locale>> map = LocaleUtils.getCcToLocalesMap();
        assertNotNull(map);
    }
}
