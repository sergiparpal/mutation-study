/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

public class DiffBuilderAgentTest {

    private static final class Fixture {
        private final String name;
        private final int age;

        Fixture(final String name, final int age) {
            this.name = name;
            this.age = age;
        }
    }

    @Test
    public void testAppendBooleanEqual() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("flag", true, true)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanDiffer() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("flag", true, false)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
        final Diff<?> diff = result.getDiffs().get(0);
        assertEquals("flag", diff.getFieldName());
        assertEquals(Boolean.TRUE, diff.getLeft());
        assertEquals(Boolean.FALSE, diff.getRight());
    }

    @Test
    public void testAppendBooleanArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final boolean[] lhs = {true, false};
        final boolean[] rhs = {true, true};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("flags", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanArrayEqual() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final boolean[] lhs = {true, false};
        final boolean[] rhs = {true, false};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("flags", lhs, rhs)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendByte() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("b", (byte) 1, (byte) 2)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Byte.valueOf((byte) 1), result.getDiffs().get(0).getLeft());
    }

    @Test
    public void testAppendByteArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final byte[] lhs = {1, 2};
        final byte[] rhs = {1, 3};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("bytes", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendChar() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("c", 'x', 'y')
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendCharArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final char[] lhs = {'a', 'b'};
        final char[] rhs = {'a', 'c'};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("chars", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleNaNEqual() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("d", Double.NaN, Double.NaN)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleDiffer() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("d", 1.0d, 2.0d)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final double[] lhs = {1.0d, 2.0d};
        final double[] rhs = {1.0d, 3.0d};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("doubles", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatNaNEqual() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("f", Float.NaN, Float.NaN)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final float[] lhs = {1.0f, 2.0f};
        final float[] rhs = {1.0f, 2.0f};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("floats", lhs, rhs)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendIntDiffer() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("age", left.age, right.age)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Integer.valueOf(1), result.getDiffs().get(0).getLeft());
        assertEquals(Integer.valueOf(2), result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendIntArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final int[] lhs = {1, 2, 3};
        final int[] rhs = {1, 2, 4};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("ints", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendLongDiffer() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("l", 1L, 2L)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendLongArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final long[] lhs = {1L, 2L};
        final long[] rhs = {1L, 2L};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("longs", lhs, rhs)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendShortDiffer() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("s", (short) 1, (short) 2)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendShortArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final short[] lhs = {1, 2};
        final short[] rhs = {1, 3};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("shorts", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectArray() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final String[] lhs = {"a", "b"};
        final String[] rhs = {"a", "c"};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("strs", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectEqualReference() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final Object same = new Object();
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("obj", same, same)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectEqualsValue() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("name", new String("x"), new String("x"))
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectDiffer() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("name", left.name, right.name)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals("A", result.getDiffs().get(0).getLeft());
        assertEquals("B", result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendObjectOneNull() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("name", (String) null, "value")
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectBothNull() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("name", (String) null, (String) null)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectAsPrimitiveArrayRouting() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final Object lhs = new int[] {1, 2};
        final Object rhs = new int[] {1, 3};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("arr", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(2)),
                java.util.Arrays.asList((Object[]) result.getDiffs().get(0).getLeft()));
        assertEquals(java.util.Arrays.asList(Integer.valueOf(1), Integer.valueOf(3)),
                java.util.Arrays.asList((Object[]) result.getDiffs().get(0).getRight()));
    }

    @Test
    public void testAppendObjectIncompatibleArrayTypesComparedAsObjects() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final Object lhs = new int[] {1, 2};
        final Object rhs = new long[] {1, 2};
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("arr", lhs, rhs)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
        assertSame(lhs, result.getDiffs().get(0).getLeft());
        assertSame(rhs, result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendDiffResult() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> inner = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("age", left.age, right.age)
                .build();
        final DiffResult<Fixture> outer = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("fixture", inner)
                .build();
        assertEquals(1, outer.getNumberOfDiffs());
        assertEquals("fixture.age", outer.getDiffs().get(0).getFieldName());
    }

    @Test
    public void testAppendDiffResultNullThrowsNpe() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffBuilder<Fixture> builder = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.append("x", (DiffResult<?>) null);
            }
        });
    }

    @Test
    public void testConstructorNullLeftThrowsNpe() {
        final Fixture right = new Fixture("B", 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DiffBuilder<Fixture>(null, right, ToStringStyle.SHORT_PREFIX_STYLE);
            }
        });
    }

    @Test
    public void testConstructorNullRightThrowsNpe() {
        final Fixture left = new Fixture("A", 1);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DiffBuilder<Fixture>(left, null, ToStringStyle.SHORT_PREFIX_STYLE);
            }
        });
    }

    @Test
    public void testConstructorNullStyleUsesDefault() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, null, false)
                .append("age", left.age, right.age)
                .build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    public void testTriviallyEqualSameReferenceSkipsAppends() {
        final Fixture left = new Fixture("A", 1);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, left, ToStringStyle.SHORT_PREFIX_STYLE, true)
                .append("age", 1, 2)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testTriviallyEqualUsesEqualsMethod() {
        final String left = new String("same");
        final String right = new String("same");
        assertFalse(left == right);
        final DiffResult<String> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, true)
                .append("whatever", 1, 2)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testTestObjectsEqualsFalseStillAppendsEvenIfEqual() {
        final String left = new String("same");
        final String right = new String("same");
        final DiffResult<String> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("age", 1, 2)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testBuildReflectsSubsequentAppendsToSameBuilder() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffBuilder<Fixture> builder = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false);
        builder.append("age", left.age, right.age);
        final DiffResult<Fixture> first = builder.build();
        builder.append("name", left.name, right.name);
        final DiffResult<Fixture> second = builder.build();
        assertEquals(2, first.getNumberOfDiffs());
        assertEquals(2, second.getNumberOfDiffs());
    }

    @Test
    public void testFluentBuilderApi() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffBuilder.Builder<Fixture> fluent = DiffBuilder.builder();
        final DiffResult<Fixture> result = fluent
                .setLeft(left)
                .setRight(right)
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .setTestObjectsEquals(false)
                .build()
                .append("age", left.age, right.age)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testFluentBuilderNullStyleUsesDefault() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = DiffBuilder.<Fixture>builder()
                .setLeft(left)
                .setRight(right)
                .setStyle(null)
                .build()
                .append("age", left.age, right.age)
                .build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    public void testFluentBuilderCustomToStringFormat() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = DiffBuilder.<Fixture>builder()
                .setLeft(left)
                .setRight(right)
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .setToStringFormat("%s vs %s")
                .build()
                .append("age", left.age, right.age)
                .build();
        final String str = result.toString();
        assertTrue(str.contains(" vs "));
    }

    @Test
    public void testFluentBuilderNullToStringFormatUsesDefault() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = DiffBuilder.<Fixture>builder()
                .setLeft(left)
                .setRight(right)
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE)
                .setToStringFormat(null)
                .build()
                .append("age", left.age, right.age)
                .build();
        final String str = result.toString();
        assertTrue(str.contains(" differs from "));
    }

    @Test
    public void testChainedAppendsReturnSameInstance() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffBuilder<Fixture> builder = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false);
        final DiffBuilder<Fixture> returned = builder.append("age", left.age, right.age);
        assertSame(builder, returned);
    }

    @Test
    public void testMultipleAppendsAccumulateInOrder() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("name", left.name, right.name)
                .append("age", left.age, right.age)
                .build();
        final List<Diff<?>> diffs = result.getDiffs();
        assertEquals(2, diffs.size());
        assertEquals("name", diffs.get(0).getFieldName());
        assertEquals("age", diffs.get(1).getFieldName());
    }

    @Test
    public void testBuildResultContainsLeftAndRight() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("age", left.age, right.age)
                .build();
        assertSame(left, result.getLeft());
        assertSame(right, result.getRight());
        assertNotNull(result);
    }

    @Test
    public void testDiffToStringFormat() {
        final Fixture left = new Fixture("A", 1);
        final Fixture right = new Fixture("B", 2);
        final DiffResult<Fixture> result = new DiffBuilder<>(left, right, ToStringStyle.SHORT_PREFIX_STYLE, false)
                .append("age", left.age, right.age)
                .build();
        final String diffString = result.getDiffs().get(0).toString();
        assertEquals("[age: 1, 2]", diffString);
    }
}
