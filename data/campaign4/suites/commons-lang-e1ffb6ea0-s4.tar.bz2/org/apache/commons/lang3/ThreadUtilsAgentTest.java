package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.time.Duration;
import java.util.Collection;
import java.util.concurrent.CountDownLatch;
import java.util.function.Predicate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ThreadUtilsAgentTest {

    private static Predicate<Thread> alwaysTrueThreadPredicate() {
        return new Predicate<Thread>() {
            public boolean test(Thread t) {
                return true;
            }
        };
    }

    private static Predicate<Thread> alwaysFalseThreadPredicate() {
        return new Predicate<Thread>() {
            public boolean test(Thread t) {
                return false;
            }
        };
    }

    private static Predicate<ThreadGroup> alwaysTrueGroupPredicate() {
        return new Predicate<ThreadGroup>() {
            public boolean test(ThreadGroup g) {
                return true;
            }
        };
    }

    private static Predicate<ThreadGroup> alwaysFalseGroupPredicate() {
        return new Predicate<ThreadGroup>() {
            public boolean test(ThreadGroup g) {
                return false;
            }
        };
    }

    private static void assertUnmodifiable(Collection<?> collection) {
        try {
            collection.clear();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected: the contract guarantees an unmodifiable collection
        }
    }

    @Test
    public void constructorIsPublic() {
        assertNotNull(new ThreadUtils());
    }

    @Test
    public void alwaysTruePredicateFieldIsNotNull() {
        assertNotNull(ThreadUtils.ALWAYS_TRUE_PREDICATE);
    }

    // -------------------- findThreadById(long) --------------------

    @Test
    public void findThreadByIdZeroThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadById(0L);
            }
        });
    }

    @Test
    public void findThreadByIdNegativeThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadById(-1L);
            }
        });
    }

    @Test
    public void findThreadByIdReturnsCurrentThread() {
        Thread current = Thread.currentThread();
        Thread found = ThreadUtils.findThreadById(current.getId());
        assertSame(current, found);
    }

    @Test
    public void findThreadByIdReturnsNullForUnknownId() {
        assertNull(ThreadUtils.findThreadById(Long.MAX_VALUE));
    }

    // -------------------- findThreadById(long, String) --------------------

    @Test
    public void findThreadByIdWithGroupNameNullThrowsNullPointerException() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadById(id, (String) null);
            }
        });
    }

    @Test
    public void findThreadByIdWithGroupNameZeroThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadById(0L, "any-group-name");
            }
        });
    }

    @Test
    public void findThreadByIdWithMatchingGroupNameReturnsThread() {
        Thread current = Thread.currentThread();
        String groupName = current.getThreadGroup().getName();
        Thread found = ThreadUtils.findThreadById(current.getId(), groupName);
        assertSame(current, found);
    }

    @Test
    public void findThreadByIdWithNonMatchingGroupNameReturnsNull() {
        long id = Thread.currentThread().getId();
        String bogusGroupName = "ThreadUtilsAgentTest-no-such-group-" + System.nanoTime();
        assertNull(ThreadUtils.findThreadById(id, bogusGroupName));
    }

    // -------------------- findThreadById(long, ThreadGroup) --------------------

    @Test
    public void findThreadByIdWithThreadGroupNullThrowsNullPointerException() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadById(id, (ThreadGroup) null);
            }
        });
    }

    @Test
    public void findThreadByIdWithThreadGroupZeroThrowsIllegalArgumentException() {
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadById(0L, group);
            }
        });
    }

    @Test
    public void findThreadByIdWithMatchingThreadGroupReturnsThread() {
        Thread current = Thread.currentThread();
        ThreadGroup group = current.getThreadGroup();
        Thread found = ThreadUtils.findThreadById(current.getId(), group);
        assertSame(current, found);
    }

    @Test
    public void findThreadByIdWithUnrelatedThreadGroupReturnsNull() {
        long id = Thread.currentThread().getId();
        ThreadGroup unrelated = new ThreadGroup("ThreadUtilsAgentTest-unrelated-" + System.nanoTime());
        try {
            assertNull(ThreadUtils.findThreadById(id, unrelated));
        } finally {
            unrelated.destroy();
        }
    }

    // -------------------- findThreadGroups(Predicate) --------------------

    @Test
    public void findThreadGroupsPredicateNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadGroups((Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    public void findThreadGroupsAlwaysTrueContainsCurrentGroup() {
        Collection<ThreadGroup> groups = ThreadUtils.findThreadGroups(alwaysTrueGroupPredicate());
        assertNotNull(groups);
        assertTrue(groups.contains(Thread.currentThread().getThreadGroup()));
        assertUnmodifiable(groups);
    }

    @Test
    public void findThreadGroupsAlwaysFalseIsEmpty() {
        Collection<ThreadGroup> groups = ThreadUtils.findThreadGroups(alwaysFalseGroupPredicate());
        assertNotNull(groups);
        assertTrue(groups.isEmpty());
    }

    // -------------------- findThreadGroups(ThreadGroup, boolean, Predicate) --------------------

    @Test
    public void findThreadGroupsWithGroupNullGroupThrowsNullPointerException() {
        final Predicate<ThreadGroup> predicate = alwaysTrueGroupPredicate();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadGroups((ThreadGroup) null, true, predicate);
            }
        });
    }

    @Test
    public void findThreadGroupsWithGroupNullPredicateThrowsNullPointerException() {
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadGroups(group, true, (Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    public void findThreadGroupsRecurseDistinguishesDepth() {
        ThreadGroup parent = Thread.currentThread().getThreadGroup();
        String suffix = Long.toString(System.nanoTime());
        ThreadGroup g1 = new ThreadGroup(parent, "ThreadUtilsAgentTest-g1-" + suffix);
        ThreadGroup g2 = new ThreadGroup(g1, "ThreadUtilsAgentTest-g2-" + suffix);
        try {
            Collection<ThreadGroup> shallow = ThreadUtils.findThreadGroups(g1, false, alwaysTrueGroupPredicate());
            assertFalse(shallow.contains(g2));

            Collection<ThreadGroup> deep = ThreadUtils.findThreadGroups(g1, true, alwaysTrueGroupPredicate());
            assertTrue(deep.contains(g2));
        } finally {
            g2.destroy();
            g1.destroy();
        }
    }

    // -------------------- findThreadGroupsByName(String) --------------------

    @Test
    public void findThreadGroupsByNameNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadGroupsByName(null);
            }
        });
    }

    @Test
    public void findThreadGroupsByNameUnknownReturnsEmptyUnmodifiable() {
        Collection<ThreadGroup> groups = ThreadUtils
                .findThreadGroupsByName("ThreadUtilsAgentTest-no-such-group-" + System.nanoTime());
        assertNotNull(groups);
        assertTrue(groups.isEmpty());
        assertUnmodifiable(groups);
    }

    @Test
    public void findThreadGroupsByNameKnownReturnsMatch() {
        ThreadGroup current = Thread.currentThread().getThreadGroup();
        Collection<ThreadGroup> groups = ThreadUtils.findThreadGroupsByName(current.getName());
        assertTrue(groups.contains(current));
    }

    // -------------------- findThreads(Predicate) --------------------

    @Test
    public void findThreadsPredicateNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreads((Predicate<Thread>) null);
            }
        });
    }

    @Test
    public void findThreadsAlwaysTrueContainsCurrentThread() {
        Collection<Thread> threads = ThreadUtils.findThreads(alwaysTrueThreadPredicate());
        assertNotNull(threads);
        assertTrue(threads.contains(Thread.currentThread()));
        assertUnmodifiable(threads);
    }

    @Test
    public void findThreadsAlwaysFalseIsEmpty() {
        Collection<Thread> threads = ThreadUtils.findThreads(alwaysFalseThreadPredicate());
        assertNotNull(threads);
        assertTrue(threads.isEmpty());
    }

    // -------------------- findThreads(ThreadGroup, boolean, Predicate) --------------------

    @Test
    public void findThreadsWithGroupNullGroupThrowsNullPointerException() {
        final Predicate<Thread> predicate = alwaysTrueThreadPredicate();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreads((ThreadGroup) null, true, predicate);
            }
        });
    }

    @Test
    public void findThreadsWithGroupNullPredicateThrowsNullPointerException() {
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreads(group, true, (Predicate<Thread>) null);
            }
        });
    }

    @Test
    public void findThreadsRecurseDistinguishesDepth() throws InterruptedException {
        ThreadGroup parent = Thread.currentThread().getThreadGroup();
        String suffix = Long.toString(System.nanoTime());
        ThreadGroup g1 = new ThreadGroup(parent, "ThreadUtilsAgentTest-tg1-" + suffix);
        ThreadGroup g2 = new ThreadGroup(g1, "ThreadUtilsAgentTest-tg2-" + suffix);
        final CountDownLatch latch = new CountDownLatch(1);
        Runnable waiter = new Runnable() {
            public void run() {
                try {
                    latch.await();
                } catch (InterruptedException ignored) {
                    // allow the thread to exit
                }
            }
        };
        Thread t1 = new Thread(g1, waiter, "ThreadUtilsAgentTest-t1-" + suffix);
        Thread t2 = new Thread(g2, waiter, "ThreadUtilsAgentTest-t2-" + suffix);
        t1.start();
        t2.start();
        try {
            Collection<Thread> shallow = ThreadUtils.findThreads(g1, false, alwaysTrueThreadPredicate());
            assertTrue(shallow.contains(t1));
            assertFalse(shallow.contains(t2));

            Collection<Thread> deep = ThreadUtils.findThreads(g1, true, alwaysTrueThreadPredicate());
            assertTrue(deep.contains(t1));
            assertTrue(deep.contains(t2));
        } finally {
            latch.countDown();
            t1.join();
            t2.join();
            g2.destroy();
            g1.destroy();
        }
    }

    // -------------------- findThreadsByName(String) --------------------

    @Test
    public void findThreadsByNameNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadsByName(null);
            }
        });
    }

    @Test
    public void findThreadsByNameUnknownReturnsEmptyUnmodifiable() {
        Collection<Thread> threads = ThreadUtils
                .findThreadsByName("ThreadUtilsAgentTest-no-such-thread-" + System.nanoTime());
        assertNotNull(threads);
        assertTrue(threads.isEmpty());
        assertUnmodifiable(threads);
    }

    @Test
    public void findThreadsByNameMatchesRenamedCurrentThread() {
        Thread current = Thread.currentThread();
        String originalName = current.getName();
        String uniqueName = "ThreadUtilsAgentTest-named-" + System.nanoTime();
        current.setName(uniqueName);
        try {
            Collection<Thread> threads = ThreadUtils.findThreadsByName(uniqueName);
            assertTrue(threads.contains(current));
        } finally {
            current.setName(originalName);
        }
    }

    // -------------------- findThreadsByName(String, String) --------------------

    @Test
    public void findThreadsByNameAndGroupNameNullThreadNameThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadsByName(null, "any-group");
            }
        });
    }

    @Test
    public void findThreadsByNameAndGroupNameNullGroupNameThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadsByName("any-thread", (String) null);
            }
        });
    }

    @Test
    public void findThreadsByNameAndGroupNameMatchesCurrentThread() {
        Thread current = Thread.currentThread();
        String originalName = current.getName();
        String uniqueName = "ThreadUtilsAgentTest-namedgrp-" + System.nanoTime();
        current.setName(uniqueName);
        try {
            Collection<Thread> threads = ThreadUtils.findThreadsByName(uniqueName, current.getThreadGroup().getName());
            assertTrue(threads.contains(current));
        } finally {
            current.setName(originalName);
        }
    }

    @Test
    public void findThreadsByNameAndGroupNameNoMatchIsEmpty() {
        Collection<Thread> threads = ThreadUtils.findThreadsByName(
                "ThreadUtilsAgentTest-no-such-thread-" + System.nanoTime(),
                "ThreadUtilsAgentTest-no-such-group-" + System.nanoTime());
        assertTrue(threads.isEmpty());
    }

    // -------------------- findThreadsByName(String, ThreadGroup) --------------------

    @Test
    public void findThreadsByNameAndThreadGroupNullThreadNameThrowsNullPointerException() {
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadsByName(null, group);
            }
        });
    }

    @Test
    public void findThreadsByNameAndThreadGroupNullGroupThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ThreadUtils.findThreadsByName("any-thread", (ThreadGroup) null);
            }
        });
    }

    @Test
    public void findThreadsByNameAndThreadGroupMatchesCurrentThread() {
        Thread current = Thread.currentThread();
        String originalName = current.getName();
        String uniqueName = "ThreadUtilsAgentTest-namedtg-" + System.nanoTime();
        current.setName(uniqueName);
        try {
            Collection<Thread> threads = ThreadUtils.findThreadsByName(uniqueName, current.getThreadGroup());
            assertTrue(threads.contains(current));
        } finally {
            current.setName(originalName);
        }
    }

    // -------------------- getAllThreadGroups() --------------------

    @Test
    public void getAllThreadGroupsExcludesSystemGroupAndIsUnmodifiable() {
        Collection<ThreadGroup> groups = ThreadUtils.getAllThreadGroups();
        assertNotNull(groups);
        assertFalse(groups.contains(ThreadUtils.getSystemThreadGroup()));
        assertTrue(groups.contains(Thread.currentThread().getThreadGroup()));
        assertUnmodifiable(groups);
    }

    // -------------------- getAllThreads() --------------------

    @Test
    public void getAllThreadsContainsCurrentThreadAndIsUnmodifiable() {
        Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertNotNull(threads);
        assertTrue(threads.contains(Thread.currentThread()));
        assertUnmodifiable(threads);
    }

    // -------------------- getSystemThreadGroup() --------------------

    @Test
    public void getSystemThreadGroupIsRootAncestorOfCurrentGroup() {
        ThreadGroup system = ThreadUtils.getSystemThreadGroup();
        assertNotNull(system);
        assertNull(system.getParent());

        ThreadGroup ancestor = Thread.currentThread().getThreadGroup();
        while (ancestor.getParent() != null) {
            ancestor = ancestor.getParent();
        }
        assertSame(system, ancestor);
    }

    // -------------------- join(Thread, Duration) --------------------

    @Test
    public void joinAlreadyFinishedThreadReturnsPromptly() throws InterruptedException {
        Thread finished = new Thread(new Runnable() {
            public void run() {
                // completes immediately
            }
        });
        finished.start();
        finished.join();

        long start = System.nanoTime();
        ThreadUtils.join(finished, Duration.ofSeconds(5));
        long elapsedMillis = (System.nanoTime() - start) / 1000000L;

        assertFalse(finished.isAlive());
        assertTrue(elapsedMillis < 5000L);
    }

    @Test
    public void joinTimesOutWhileThreadStillAlive() throws InterruptedException {
        final CountDownLatch latch = new CountDownLatch(1);
        Thread longRunning = new Thread(new Runnable() {
            public void run() {
                try {
                    latch.await();
                } catch (InterruptedException ignored) {
                    // allow the thread to exit
                }
            }
        });
        longRunning.start();
        try {
            ThreadUtils.join(longRunning, Duration.ofMillis(200));
            assertTrue(longRunning.isAlive());
        } finally {
            latch.countDown();
            longRunning.join();
        }
    }

    // -------------------- sleep(Duration) --------------------

    @Test
    public void sleepSleepsAtLeastGivenDuration() throws InterruptedException {
        long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ofMillis(200));
        long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 150L, "expected at least ~200ms, got " + elapsedMillis);
    }

    // -------------------- sleepQuietly(Duration) --------------------

    @Test
    public void sleepQuietlySleepsRoughlyGivenDurationWhenNotInterrupted() {
        long start = System.nanoTime();
        ThreadUtils.sleepQuietly(Duration.ofMillis(200));
        long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 150L, "expected at least ~200ms, got " + elapsedMillis);
    }

    @Test
    public void sleepQuietlyReturnsEarlyAndSwallowsInterruptedException() throws InterruptedException {
        final boolean[] threwException = {false};
        Thread sleeper = new Thread(new Runnable() {
            public void run() {
                try {
                    ThreadUtils.sleepQuietly(Duration.ofSeconds(10));
                } catch (Throwable t) {
                    threwException[0] = true;
                }
            }
        });
        long start = System.nanoTime();
        sleeper.start();
        Thread.sleep(100L);
        sleeper.interrupt();
        sleeper.join(5000L);
        long elapsedMillis = (System.nanoTime() - start) / 1000000L;

        assertFalse(sleeper.isAlive());
        assertFalse(threwException[0]);
        assertTrue(elapsedMillis < 10000L, "expected the interrupt to shorten the sleep, took " + elapsedMillis);
    }

}
