/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.AbstractMap;
import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isNotEmpty(new Object[0]));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));

        assertTrue(ArrayUtils.isEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isEmpty((byte[]) null));
        assertTrue(ArrayUtils.isEmpty((char[]) null));
        assertTrue(ArrayUtils.isEmpty((double[]) null));
        assertTrue(ArrayUtils.isEmpty((float[]) null));
        assertTrue(ArrayUtils.isEmpty((long[]) null));
        assertTrue(ArrayUtils.isEmpty((short[]) null));
    }

    @Test
    void testContains() {
        final int[] intArray = { 1, 2, 3, 4 };
        assertTrue(ArrayUtils.contains(intArray, 3));
        assertFalse(ArrayUtils.contains(intArray, 5));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final double[] doubleArray = { 1.0, 2.0, 3.0 };
        assertTrue(ArrayUtils.contains(doubleArray, 2.0, 0.1));
        assertFalse(ArrayUtils.contains(doubleArray, 2.5, 0.1));
        assertTrue(ArrayUtils.contains(doubleArray, 2.05, 0.1));

        final Object[] objArray = { "a", null, "c" };
        assertTrue(ArrayUtils.contains(objArray, null));
        assertTrue(ArrayUtils.contains(objArray, "c"));
        assertFalse(ArrayUtils.contains(objArray, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        final int[] array = { 1, 2, 3, 2, 1 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));

        // startIndex boundaries
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -10));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 2, -1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2, 100));

        final Object[] objArray = { "a", "b", "a" };
        assertEquals(0, ArrayUtils.indexOf(objArray, "a"));
        assertEquals(2, ArrayUtils.lastIndexOf(objArray, "a"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(objArray, "z"));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet bitSet = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, bitSet.cardinality());
        assertTrue(bitSet.get(0));
        assertTrue(bitSet.get(2));
        assertTrue(bitSet.get(4));
        assertFalse(bitSet.get(1));

        final BitSet empty = ArrayUtils.indexesOf((int[]) null, 1);
        assertTrue(empty.isEmpty());

        final BitSet fromStart = ArrayUtils.indexesOf(array, 1, 3);
        assertEquals(1, fromStart.cardinality());
        assertTrue(fromStart.get(4));
    }

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(null, new int[] { 1 }));

        assertTrue(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b" }));
        assertFalse(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b", "c" }));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));

        assertTrue(ArrayUtils.isSorted(new String[] { "a", "b", "c" }));
        assertFalse(ArrayUtils.isSorted(new String[] { "c", "b", "a" }));
    }

    @Test
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(new int[] { 1 }, null));
        assertTrue(ArrayUtils.isEquals(new int[][] { { 1, 2 }, { 3 } }, new int[][] { { 1, 2 }, { 3 } }));
    }

    @Test
    void testNullToEmptyPrimitives() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] ints = { 1, 2 };
        assertSame(ints, ArrayUtils.nullToEmpty(ints));

        assertSame(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        assertSame(ArrayUtils.EMPTY_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Object[]) null));
        assertSame(ArrayUtils.EMPTY_BOOLEAN_ARRAY, ArrayUtils.nullToEmpty((boolean[]) null));
        assertSame(ArrayUtils.EMPTY_LONG_ARRAY, ArrayUtils.nullToEmpty((long[]) null));
    }

    @Test
    void testNullTo() {
        final String[] fallback = { "x" };
        assertSame(fallback, ArrayUtils.nullTo(null, fallback));
        assertSame(fallback, ArrayUtils.nullTo(new String[0], fallback));
        final String[] actual = { "a" };
        assertSame(actual, ArrayUtils.nullTo(actual, fallback));
    }

    @Test
    void testRemoveElement() {
        final int[] array = { 1, 2, 3, 2 };
        assertArrayEquals(new int[] { 1, 3, 2 }, ArrayUtils.removeElement(array, 2));
        assertArrayEquals(array, ArrayUtils.removeElement(array, 9));
        assertNull(ArrayUtils.removeElement((int[]) null, 1));

        final String[] strings = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b", "a" }, ArrayUtils.removeElement(strings, "a"));
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] array = { 1, 2, 1, 3, 1 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.removeAllOccurrences(array, 1));
        assertArrayEquals(array, ArrayUtils.removeAllOccurrences(array, 9));

        final String[] strings = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b" }, ArrayUtils.removeAllOccurrences(strings, "a"));
    }

    @Test
    void testReverseFull() {
        final int[] array = { 1, 2, 3, 4 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 4, 3, 2, 1 }, array);

        // null is a no-op, must not throw
        ArrayUtils.reverse((int[]) null);

        final Object[] objects = { "a", "b", "c" };
        ArrayUtils.reverse(objects);
        assertArrayEquals(new Object[] { "c", "b", "a" }, objects);
    }

    @Test
    void testReverseRangeBoundaries() {
        int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array);

        // undervalue start is promoted to 0
        array = new int[] { 1, 2, 3 };
        ArrayUtils.reverse(array, -5, 3);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        // overvalue end is demoted to length, no exception
        array = new int[] { 1, 2, 3 };
        ArrayUtils.reverse(array, 0, 100);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        // end <= start results in no change
        array = new int[] { 1, 2, 3 };
        ArrayUtils.reverse(array, 2, 1);
        assertArrayEquals(new int[] { 1, 2, 3 }, array);
    }

    @Test
    void testShift() {
        int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);

        array = new int[] { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, -1);
        assertArrayEquals(new int[] { 2, 3, 4, 5, 1 }, array);

        // offset larger than length wraps via modulo
        array = new int[] { 1, 2, 3 };
        ArrayUtils.shift(array, 7);
        assertArrayEquals(new int[] { 3, 1, 2 }, array);

        // null and empty arrays are no-ops
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3, 4 };
        ArrayUtils.swap(array, 0, 3);
        assertArrayEquals(new int[] { 4, 2, 3, 1 }, array);

        final int[] array2 = { 1, 2, 3, 4, 5, 6 };
        ArrayUtils.swap(array2, 0, 3, 2);
        assertArrayEquals(new int[] { 4, 5, 3, 1, 2, 6 }, array2);

        // null is a no-op, must not throw
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testSubarray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 2));

        // undervalue start promoted to 0
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.subarray(array, -5, 2));
        // overvalue end demoted to array length
        assertArrayEquals(new int[] { 4, 5 }, ArrayUtils.subarray(array, 3, 100));
        // end before start produces empty array, no exception
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));

        final String[] strings = { "a", "b", "c" };
        final String[] sub = ArrayUtils.subarray(strings, 0, 2);
        assertArrayEquals(new String[] { "a", "b" }, sub);
        assertEquals(String.class, sub.getClass().getComponentType());
    }

    @Test
    void testStartsWith() {
        final byte[] data = { 1, 2, 3, 4 };
        assertTrue(ArrayUtils.startsWith(data, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(data, new byte[] { 2, 3 }));
        assertTrue(ArrayUtils.startsWith(data, data));
        assertTrue(ArrayUtils.startsWith(null, null));
        assertFalse(ArrayUtils.startsWith(data, null));
        assertFalse(ArrayUtils.startsWith(null, data));
        // expected longer than data
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, new byte[] { 1, 2 }));
        // exact length match
        assertTrue(ArrayUtils.startsWith(data, new byte[] { 1, 2, 3, 4 }));
    }

    @Test
    void testToObjectAndToPrimitive() {
        final int[] ints = { 1, 2, 3 };
        final Integer[] integers = ArrayUtils.toObject(ints);
        assertArrayEquals(new Integer[] { 1, 2, 3 }, integers);
        assertArrayEquals(ints, ArrayUtils.toPrimitive(integers));
        assertNull(ArrayUtils.toObject((int[]) null));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));

        // null element throws
        final Integer[] withNull = { 1, null };
        try {
            ArrayUtils.toPrimitive(withNull);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }

        // valueForNull overload substitutes the default instead of throwing
        assertArrayEquals(new int[] { 1, -1 }, ArrayUtils.toPrimitive(withNull, -1));

        final boolean[] booleans = { true, false };
        assertArrayEquals(new Boolean[] { Boolean.TRUE, Boolean.FALSE }, ArrayUtils.toObject(booleans));
        assertArrayEquals(booleans, ArrayUtils.toPrimitive(new Boolean[] { Boolean.TRUE, Boolean.FALSE }));
    }

    @Test
    void testToPrimitiveGeneric() {
        final Integer[] integers = { 1, 2, 3 };
        final Object result = ArrayUtils.toPrimitive(integers);
        assertTrue(result instanceof int[]);
        assertArrayEquals(new int[] { 1, 2, 3 }, (int[]) result);

        assertNull(ArrayUtils.toPrimitive((Object) null));

        // an array that is already primitive, or not a wrapper array, is returned unchanged
        final int[] already = { 1, 2 };
        assertSame(already, ArrayUtils.toPrimitive((Object) already));
        final String[] strings = { "a" };
        assertSame(strings, ArrayUtils.toPrimitive((Object) strings));
    }

    @Test
    void testToStringMethods() {
        assertEquals("{}", ArrayUtils.toString(new Object[0]));
        assertEquals("{1,2}", ArrayUtils.toString(new int[] { 1, 2 }));
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("fallback", ArrayUtils.toString(null, "fallback"));

        final Object[] mixed = { 1, "two", null };
        final String[] strings = ArrayUtils.toStringArray(mixed);
        assertArrayEquals(new String[] { "1", "two", "null" }, strings);
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    void testToMap() {
        assertNull(ArrayUtils.toMap(null));

        final Map<Object, Object> map = ArrayUtils.toMap(new Object[][] { { "RED", "#FF0000" }, { "GREEN", "#00FF00" } });
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));

        final Map.Entry<String, String> entry = new AbstractMap.SimpleEntry<String, String>("k", "v");
        final Map<Object, Object> fromEntries = ArrayUtils.toMap(new Object[] { entry });
        assertEquals("v", fromEntries.get("k"));

        // array element too short throws
        try {
            ArrayUtils.toMap(new Object[] { new Object[] { "onlyOne" } });
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        // element that is neither Map.Entry nor Array throws
        try {
            ArrayUtils.toMap(new Object[] { "notAnEntry" });
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testGetAndIsArrayIndexValid() {
        final String[] array = { "a", "b" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("default", ArrayUtils.get(null, 0, "default"));

        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
    }

    @Test
    void testGetComponentTypeAndGetLength() {
        final String[] array = { "a", "b", "c" };
        assertEquals(String.class, ArrayUtils.getComponentType(array));
        assertEquals(3, ArrayUtils.getLength(array));
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));

        try {
            ArrayUtils.getLength("not an array");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testCloneAndHashCode() {
        final int[] intArray = { 1, 2, 3 };
        final int[] clonedInts = ArrayUtils.clone(intArray);
        assertNotSame(intArray, clonedInts);
        assertArrayEquals(intArray, clonedInts);
        assertNull(ArrayUtils.clone((int[]) null));

        final String[] stringArray = { "a", "b" };
        final String[] clonedStrings = ArrayUtils.clone(stringArray);
        assertNotSame(stringArray, clonedStrings);
        assertArrayEquals(stringArray, clonedStrings);
        assertNull(ArrayUtils.clone((Object[]) null));

        assertEquals(ArrayUtils.hashCode(intArray), ArrayUtils.hashCode(new int[] { 1, 2, 3 }));
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
    }

    @Test
    void testNewInstanceAndToArray() {
        final Integer[] array = ArrayUtils.newInstance(Integer.class, 3);
        assertEquals(3, array.length);
        assertEquals(Integer.class, array.getClass().getComponentType());
        assertNull(array[0]);

        final String[] created = ArrayUtils.toArray("1", "2", "3");
        assertArrayEquals(new String[] { "1", "2", "3" }, created);
    }
}
