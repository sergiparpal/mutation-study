/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    // -----------------------------------------------------------------------
    // getFraction(int, int)
    // -----------------------------------------------------------------------

    @Test
    public void testGetFractionIntInt_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_minValueOverflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // -----------------------------------------------------------------------
    // getFraction(int, int, int)
    // -----------------------------------------------------------------------

    @Test
    public void testGetFractionWholeNumDenom_basic() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenom_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, 1, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_overflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Integer.MAX_VALUE, Integer.MAX_VALUE, 2);
            }
        });
    }

    // -----------------------------------------------------------------------
    // getFraction(String)
    // -----------------------------------------------------------------------

    @Test
    public void testGetFractionString_doubleFormat() {
        final Fraction f = Fraction.getFraction("0.25");
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionString_wholeNumeratorDenominatorFormat() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_numeratorDenominatorFormat() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_wholeNumberFormat() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_invalidWholeFormatThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction("1 3-7");
            }
        });
    }

    @Test
    public void testGetFractionString_nullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionString_garbageThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction("abc");
            }
        });
    }

    // -----------------------------------------------------------------------
    // getFraction(double)
    // -----------------------------------------------------------------------

    @Test
    public void testGetFractionDouble_basic() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_negative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction((double) Integer.MAX_VALUE + 1.0d);
            }
        });
    }

    @Test
    public void testGetFractionDouble_nanThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDouble_zero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    // -----------------------------------------------------------------------
    // getReducedFraction
    // -----------------------------------------------------------------------

    @Test
    public void testGetReducedFraction_reduces() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorNormalizesToZero() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetReducedFraction_negativeDenominatorMovesSign() {
        final Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    // -----------------------------------------------------------------------
    // Constants
    // -----------------------------------------------------------------------

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // -----------------------------------------------------------------------
    // abs()
    // -----------------------------------------------------------------------

    @Test
    public void testAbs_positiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 5);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbs_negativeBecomesPositive() {
        final Fraction f = Fraction.getFraction(-3, 5);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(5, abs.getDenominator());
    }

    // -----------------------------------------------------------------------
    // add()
    // -----------------------------------------------------------------------

    @Test
    public void testAdd_basic() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAdd_zeroIdentity() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, Fraction.ZERO.add(f));
        assertSame(f, f.add(Fraction.ZERO));
    }

    @Test
    public void testAdd_nullThrowsNpe() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.add(null);
            }
        });
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction f1 = Fraction.getFraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
        final Fraction f2 = Fraction.getFraction(Integer.MAX_VALUE - 2, Integer.MAX_VALUE - 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f1.add(f2);
            }
        });
    }

    // -----------------------------------------------------------------------
    // compareTo()
    // -----------------------------------------------------------------------

    @Test
    public void testCompareTo_less() {
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
    }

    @Test
    public void testCompareTo_greater() {
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 3)) > 0);
    }

    @Test
    public void testCompareTo_equalDifferentRepresentations() {
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareTo_sameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertEquals(0, f.compareTo(f));
    }

    @Test
    public void testCompareTo_nullThrowsNpe() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.compareTo(null);
            }
        });
    }

    // -----------------------------------------------------------------------
    // divideBy()
    // -----------------------------------------------------------------------

    @Test
    public void testDivideBy_basic() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 3));
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideBy_zeroThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideBy_nullThrowsNpe() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.divideBy(null);
            }
        });
    }

    // -----------------------------------------------------------------------
    // doubleValue/floatValue/intValue/longValue
    // -----------------------------------------------------------------------

    @Test
    public void testDoubleValue() {
        assertEquals(0.5d, Fraction.getFraction(1, 2).doubleValue(), 0.0d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.5f, Fraction.getFraction(1, 2).floatValue(), 0.0f);
    }

    @Test
    public void testIntValue_truncatesTowardZero() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue_truncatesTowardZero() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    // -----------------------------------------------------------------------
    // equals() / hashCode()
    // -----------------------------------------------------------------------

    @Test
    public void testEquals_sameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertTrue(f.equals(f));
    }

    @Test
    public void testEquals_differentType() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertFalse(f.equals("1/2"));
    }

    @Test
    public void testEquals_sameValueDifferentRepresentationNotEqual() {
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
    }

    @Test
    public void testEquals_equalNumeratorDenominator() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
    }

    @Test
    public void testHashCode_consistentWithEquals() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    // -----------------------------------------------------------------------
    // getProperNumerator()/getProperWhole()
    // -----------------------------------------------------------------------

    @Test
    public void testGetProperNumerator_positive() {
        assertEquals(3, Fraction.getFraction(7, 4).getProperNumerator());
    }

    @Test
    public void testGetProperNumerator_negativeIsPositive() {
        assertEquals(3, Fraction.getFraction(-7, 4).getProperNumerator());
    }

    @Test
    public void testGetProperWhole_positive() {
        assertEquals(1, Fraction.getFraction(7, 4).getProperWhole());
    }

    @Test
    public void testGetProperWhole_negative() {
        assertEquals(-1, Fraction.getFraction(-7, 4).getProperWhole());
    }

    // -----------------------------------------------------------------------
    // invert()
    // -----------------------------------------------------------------------

    @Test
    public void testInvert_basic() {
        final Fraction f = Fraction.getFraction(3, 7).invert();
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvert_negativeNumeratorMovesSignBack() {
        final Fraction f = Fraction.getFraction(-3, 7).invert();
        assertEquals(-7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvert_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.invert();
            }
        });
    }

    // -----------------------------------------------------------------------
    // multiplyBy()
    // -----------------------------------------------------------------------

    @Test
    public void testMultiplyBy_basic() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyBy_zero() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testMultiplyBy_nullThrowsNpe() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyBy_overflowThrows() {
        final Fraction f1 = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction f2 = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f1.multiplyBy(f2);
            }
        });
    }

    // -----------------------------------------------------------------------
    // negate()
    // -----------------------------------------------------------------------

    @Test
    public void testNegate_basic() {
        final Fraction f = Fraction.getFraction(3, 7).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testNegate_minValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.negate();
            }
        });
    }

    // -----------------------------------------------------------------------
    // pow()
    // -----------------------------------------------------------------------

    @Test
    public void testPow_one() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPow_zero() {
        assertSame(Fraction.ONE, Fraction.getFraction(2, 3).pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPow_positive() {
        final Fraction f = Fraction.getFraction(2, 3).pow(3);
        assertEquals(8, f.getNumerator());
        assertEquals(27, f.getDenominator());
    }

    @Test
    public void testPow_negative() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-2);
        assertEquals(9, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testPow_minValueDoesNotThrow() {
        final Fraction f = Fraction.getFraction(1, 1).pow(Integer.MIN_VALUE);
        assertEquals(1, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    // -----------------------------------------------------------------------
    // reduce()
    // -----------------------------------------------------------------------

    @Test
    public void testReduce_simplifies() {
        final Fraction f = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testReduce_alreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduce_zeroNumerator() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertSame(Fraction.ZERO, f.reduce());
    }

    // -----------------------------------------------------------------------
    // subtract()
    // -----------------------------------------------------------------------

    @Test
    public void testSubtract_basic() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 3));
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtract_nullThrowsNpe() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                f.subtract(null);
            }
        });
    }

    // -----------------------------------------------------------------------
    // toProperString() / toString()
    // -----------------------------------------------------------------------

    @Test
    public void testToProperString_zero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperString_one() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperString_minusOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperString_properFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperString_negativeProperFraction() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperString_simpleImproperFraction() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToString_basic() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
        assertEquals("-3/7", Fraction.getFraction(-3, 7).toString());
    }

    // -----------------------------------------------------------------------
    // Serializable
    // -----------------------------------------------------------------------

    @Test
    public void testSerialization_roundTrip() throws Exception {
        final Fraction original = Fraction.getFraction(5, 9);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final Fraction deserialized = (Fraction) ois.readObject();
        ois.close();
        assertEquals(original, deserialized);
        assertEquals(original.hashCode(), deserialized.hashCode());
    }
}
