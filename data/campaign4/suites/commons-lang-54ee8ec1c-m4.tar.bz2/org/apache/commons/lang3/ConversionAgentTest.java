/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link Conversion}.
 */
public class ConversionAgentTest {

    private static final boolean[] NIBBLE_0001 = { true, false, false, false };
    private static final boolean[] NIBBLE_0101 = { true, false, true, false };
    private static final boolean[] NIBBLE_1000 = { false, false, false, true };

    @Test
    public void testConstructorIsDeprecatedAndPublic() {
        final Conversion conversion = new Conversion();
        assertNotNull(conversion);
    }

    @Test
    public void testBinaryBeMsb0ToHexDigit() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { false, false, false, false }));
        assertEquals('f', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, true, true, true }));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitWithSrcPos() {
        final boolean[] src = { true, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false };
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(src, 2));
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }, 0));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitEmptyArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }, 4);
            }
        });
    }

    @Test
    public void testBinaryToByte() {
        final boolean[] src = { true, false, true, false, true, false, true, false };
        final byte result = Conversion.binaryToByte(src, 0, (byte) 0, 0, 8);
        assertEquals((byte) 0x55, result);
    }

    @Test
    public void testBinaryToByteZeroBoolsReturnsDstInit() {
        final boolean[] src = {};
        final byte result = Conversion.binaryToByte(src, 0, (byte) 0x7F, 0, 0);
        assertEquals((byte) 0x7F, result);
    }

    @Test
    public void testBinaryToByteWithDstInitPreservesUntouchedBits() {
        final boolean[] src = { true, true };
        final byte result = Conversion.binaryToByte(src, 0, (byte) 0xF0, 0, 2);
        assertEquals((byte) 0xF3, result);
    }

    @Test
    public void testBinaryToByteTooManyBitsThrows() {
        final boolean[] src = new boolean[9];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToByte(src, 0, (byte) 0, 1, 8);
            }
        });
    }

    @Test
    public void testBinaryToHexDigit() {
        assertEquals('1', Conversion.binaryToHexDigit(NIBBLE_0001));
        assertEquals('8', Conversion.binaryToHexDigit(NIBBLE_1000));
    }

    @Test
    public void testBinaryToHexDigitWithSrcPos() {
        final boolean[] src = { false, false, false, false, true, false, false };
        assertEquals('4', Conversion.binaryToHexDigit(src, 2));
    }

    @Test
    public void testBinaryToHexDigitEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bits() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { false, false, false, false }));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooLongThrows() {
        final boolean[] src = new boolean[9];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(src);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooShortThrows() {
        final boolean[] src = { true, false };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(src, 0);
            }
        });
    }

    @Test
    public void testBinaryToInt() {
        final boolean[] src = { true, false, true, false };
        final int result = Conversion.binaryToInt(src, 0, 0, 0, 4);
        assertEquals(0x5, result);
    }

    @Test
    public void testBinaryToIntZeroLengthReturnsDstInit() {
        assertEquals(42, Conversion.binaryToInt(new boolean[0], 0, 42, 0, 0));
    }

    @Test
    public void testBinaryToIntTooManyBitsThrows() {
        final boolean[] src = new boolean[33];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToInt(src, 0, 0, 1, 32);
            }
        });
    }

    @Test
    public void testBinaryToLong() {
        final boolean[] src = { true, true, true, true };
        final long result = Conversion.binaryToLong(src, 0, 0L, 0, 4);
        assertEquals(0xFL, result);
    }

    @Test
    public void testBinaryToLongZeroLengthReturnsDstInit() {
        assertEquals(7L, Conversion.binaryToLong(new boolean[0], 0, 7L, 0, 0));
    }

    @Test
    public void testBinaryToLongTooManyBitsThrows() {
        final boolean[] src = new boolean[65];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToLong(src, 0, 0L, 1, 64);
            }
        });
    }

    @Test
    public void testBinaryToShort() {
        final boolean[] src = { true, false, true, false };
        final short result = Conversion.binaryToShort(src, 0, (short) 0, 0, 4);
        assertEquals((short) 0x5, result);
    }

    @Test
    public void testBinaryToShortZeroLengthReturnsDstInit() {
        assertEquals((short) 9, Conversion.binaryToShort(new boolean[0], 0, (short) 9, 0, 0));
    }

    @Test
    public void testBinaryToShortTooManyBitsThrows() {
        final boolean[] src = new boolean[17];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToShort(src, 0, (short) 0, 1, 16);
            }
        });
    }

    @Test
    public void testByteArrayToInt() {
        final byte[] src = { (byte) 0x01, (byte) 0x02, (byte) 0x03, (byte) 0x04 };
        final int result = Conversion.byteArrayToInt(src, 0, 0, 0, 4);
        assertEquals(0x04030201, result);
    }

    @Test
    public void testByteArrayToIntZeroBytesReturnsDstInit() {
        assertEquals(99, Conversion.byteArrayToInt(new byte[0], 0, 99, 0, 0));
    }

    @Test
    public void testByteArrayToIntTooManyBytesThrows() {
        final byte[] src = new byte[5];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToInt(src, 0, 0, 8, 4);
            }
        });
    }

    @Test
    public void testByteArrayToLong() {
        final byte[] src = { (byte) 0x01, (byte) 0x02, (byte) 0x03, (byte) 0x04, (byte) 0x05, (byte) 0x06, (byte) 0x07, (byte) 0x08 };
        final long result = Conversion.byteArrayToLong(src, 0, 0L, 0, 8);
        assertEquals(0x0807060504030201L, result);
    }

    @Test
    public void testByteArrayToLongZeroBytesReturnsDstInit() {
        assertEquals(5L, Conversion.byteArrayToLong(new byte[0], 0, 5L, 0, 0));
    }

    @Test
    public void testByteArrayToLongTooManyBytesThrows() {
        final byte[] src = new byte[9];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToLong(src, 0, 0L, 8, 8);
            }
        });
    }

    @Test
    public void testByteArrayToShort() {
        final byte[] src = { (byte) 0x01, (byte) 0x02 };
        final short result = Conversion.byteArrayToShort(src, 0, (short) 0, 0, 2);
        assertEquals((short) 0x0201, result);
    }

    @Test
    public void testByteArrayToShortZeroBytesReturnsDstInit() {
        assertEquals((short) 5, Conversion.byteArrayToShort(new byte[0], 0, (short) 5, 0, 0));
    }

    @Test
    public void testByteArrayToShortTooManyBytesThrows() {
        final byte[] src = new byte[3];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToShort(src, 0, (short) 0, 8, 2);
            }
        });
    }

    @Test
    public void testByteArrayToUuid() {
        final byte[] src = new byte[16];
        for (int i = 0; i < 16; i++) {
            src[i] = (byte) (i + 1);
        }
        final UUID uuid = Conversion.byteArrayToUuid(src, 0);
        final byte[] roundTrip = Conversion.uuidToByteArray(uuid, new byte[16], 0, 16);
        assertArrayEquals(src, roundTrip);
    }

    @Test
    public void testByteArrayToUuidTooShortThrows() {
        final byte[] src = new byte[15];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToUuid(src, 0);
            }
        });
    }

    @Test
    public void testByteToBinary() {
        final boolean[] dst = new boolean[8];
        final boolean[] result = Conversion.byteToBinary((byte) 0x01, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, false, false, false, false, false, false }, result);
    }

    @Test
    public void testByteToBinaryZeroBoolsReturnsDstUnchanged() {
        final boolean[] dst = { true, true };
        final boolean[] result = Conversion.byteToBinary((byte) 0x5, 0, dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, true }, result);
    }

    @Test
    public void testByteToBinaryTooManyBitsThrows() {
        final boolean[] dst = new boolean[9];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteToBinary((byte) 0x1, 1, dst, 0, 8);
            }
        });
    }

    @Test
    public void testByteToHex() {
        final String result = Conversion.byteToHex((byte) 0xAB, 0, "", 0, 2);
        assertEquals("ba", result);
    }

    @Test
    public void testByteToHexZeroHexsReturnsDstInit() {
        assertEquals("abc", Conversion.byteToHex((byte) 0x1, 0, "abc", 0, 0));
    }

    @Test
    public void testByteToHexTooManyHexsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteToHex((byte) 0x1, 0, "", 0, 3);
            }
        });
    }

    @Test
    public void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] { false, false, false, true }, Conversion.hexDigitMsb0ToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('f'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('F'));
    }

    @Test
    public void testHexDigitMsb0ToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitMsb0ToBinary('g');
            }
        });
    }

    @Test
    public void testHexDigitMsb0ToInt() {
        assertEquals(0x8, Conversion.hexDigitMsb0ToInt('1'));
        assertEquals(0x0, Conversion.hexDigitMsb0ToInt('0'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('f'));
    }

    @Test
    public void testHexDigitMsb0ToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitMsb0ToInt('z');
            }
        });
    }

    @Test
    public void testHexDigitToBinary() {
        assertArrayEquals(NIBBLE_0001, Conversion.hexDigitToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('f'));
    }

    @Test
    public void testHexDigitToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitToBinary('x');
            }
        });
    }

    @Test
    public void testHexDigitToInt() {
        assertEquals(1, Conversion.hexDigitToInt('1'));
        assertEquals(10, Conversion.hexDigitToInt('a'));
        assertEquals(15, Conversion.hexDigitToInt('F'));
    }

    @Test
    public void testHexDigitToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitToInt('g');
            }
        });
    }

    @Test
    public void testHexToByte() {
        final byte result = Conversion.hexToByte("ab", 0, (byte) 0, 0, 2);
        assertEquals((byte) 0xBA, result);
    }

    @Test
    public void testHexToByteZeroHexReturnsDstInit() {
        assertEquals((byte) 5, Conversion.hexToByte("ff", 0, (byte) 5, 0, 0));
    }

    @Test
    public void testHexToByteTooManyHexThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToByte("abc", 0, (byte) 0, 0, 3);
            }
        });
    }

    @Test
    public void testHexToInt() {
        final int result = Conversion.hexToInt("1234", 0, 0, 0, 4);
        assertEquals(0x4321, result);
    }

    @Test
    public void testHexToIntZeroHexReturnsDstInit() {
        assertEquals(7, Conversion.hexToInt("ff", 0, 7, 0, 0));
    }

    @Test
    public void testHexToIntTooManyHexThrows() {
        final String src = "123456789";
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToInt(src, 0, 0, 0, 9);
            }
        });
    }

    @Test
    public void testHexToLong() {
        final long result = Conversion.hexToLong("0102030405060708", 0, 0L, 0, 16);
        assertEquals(0x8070605040302010L, result);
    }

    @Test
    public void testHexToLongZeroHexReturnsDstInit() {
        assertEquals(3L, Conversion.hexToLong("ff", 0, 3L, 0, 0));
    }

    @Test
    public void testHexToLongTooManyHexThrows() {
        final String src = "0102030405060708090";
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToLong(src, 0, 0L, 0, 17);
            }
        });
    }

    @Test
    public void testHexToShort() {
        final short result = Conversion.hexToShort("1234", 0, (short) 0, 0, 4);
        assertEquals((short) 0x4321, result);
    }

    @Test
    public void testHexToShortZeroHexReturnsDstInit() {
        assertEquals((short) 2, Conversion.hexToShort("ff", 0, (short) 2, 0, 0));
    }

    @Test
    public void testHexToShortTooManyHexThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToShort("12345", 0, (short) 0, 0, 5);
            }
        });
    }

    @Test
    public void testIntArrayToLong() {
        final int[] src = { 0x00000001, 0x00000002 };
        final long result = Conversion.intArrayToLong(src, 0, 0L, 0, 2);
        assertEquals(0x0000000200000001L, result);
    }

    @Test
    public void testIntArrayToLongZeroLengthReturnsDstInit() {
        assertEquals(11L, Conversion.intArrayToLong(new int[0], 0, 11L, 0, 0));
    }

    @Test
    public void testIntArrayToLongTooManyIntsThrows() {
        final int[] src = new int[3];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intArrayToLong(src, 0, 0L, 32, 2);
            }
        });
    }

    @Test
    public void testIntToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.intToBinary(0x5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(NIBBLE_0101, result);
    }

    @Test
    public void testIntToBinaryZeroBoolsReturnsDstUnchanged() {
        final boolean[] dst = { true };
        final boolean[] result = Conversion.intToBinary(0x5, 0, dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true }, result);
    }

    @Test
    public void testIntToBinaryTooManyBitsThrows() {
        final boolean[] dst = new boolean[33];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToBinary(0x5, 1, dst, 0, 32);
            }
        });
    }

    @Test
    public void testIntToByteArray() {
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.intToByteArray(0x04030201, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02, 0x03, 0x04 }, result);
    }

    @Test
    public void testIntToByteArrayZeroBytesReturnsDstUnchanged() {
        final byte[] dst = { 0x7F };
        final byte[] result = Conversion.intToByteArray(0xFF, 0, dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x7F }, result);
    }

    @Test
    public void testIntToByteArrayTooManyBytesThrows() {
        final byte[] dst = new byte[5];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToByteArray(0xFF, 8, dst, 0, 4);
            }
        });
    }

    @Test
    public void testIntToHex() {
        final String result = Conversion.intToHex(0x04030201, 0, "", 0, 8);
        assertEquals("10203040", result);
    }

    @Test
    public void testIntToHexZeroHexsReturnsDstInit() {
        assertEquals("xyz", Conversion.intToHex(0xFF, 0, "xyz", 0, 0));
    }

    @Test
    public void testIntToHexTooManyHexsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHex(0xFF, 0, "", 0, 9);
            }
        });
    }

    @Test
    public void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('9', Conversion.intToHexDigit(9));
        assertEquals('f', Conversion.intToHexDigit(15));
    }

    @Test
    public void testIntToHexDigitBelowRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigit(-1);
            }
        });
    }

    @Test
    public void testIntToHexDigitAboveRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigit(16);
            }
        });
    }

    @Test
    public void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0x0));
        assertEquals('8', Conversion.intToHexDigitMsb0(0x1));
        assertEquals('f', Conversion.intToHexDigitMsb0(0xF));
    }

    @Test
    public void testIntToHexDigitMsb0OutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigitMsb0(16);
            }
        });
    }

    @Test
    public void testIntToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.intToShortArray(0x00020001, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 0x0001, 0x0002 }, result);
    }

    @Test
    public void testIntToShortArrayZeroShortsReturnsDstUnchanged() {
        final short[] dst = { 5 };
        final short[] result = Conversion.intToShortArray(0xFF, 0, dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 5 }, result);
    }

    @Test
    public void testIntToShortArrayTooManyShortsThrows() {
        final short[] dst = new short[3];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToShortArray(0xFF, 16, dst, 0, 2);
            }
        });
    }

    @Test
    public void testLongToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.longToBinary(0x5L, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(NIBBLE_0101, result);
    }

    @Test
    public void testLongToBinaryZeroBoolsReturnsDstUnchanged() {
        final boolean[] dst = { true };
        final boolean[] result = Conversion.longToBinary(0x5L, 0, dst, 0, 0);
        assertSame(dst, result);
    }

    @Test
    public void testLongToBinaryTooManyBitsThrows() {
        final boolean[] dst = new boolean[65];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToBinary(0x5L, 1, dst, 0, 64);
            }
        });
    }

    @Test
    public void testLongToByteArray() {
        final byte[] dst = new byte[8];
        final byte[] result = Conversion.longToByteArray(0x0807060504030201L, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 }, result);
    }

    @Test
    public void testLongToByteArrayZeroBytesReturnsDstUnchanged() {
        final byte[] dst = { 0x1 };
        final byte[] result = Conversion.longToByteArray(0xFFL, 0, dst, 0, 0);
        assertSame(dst, result);
    }

    @Test
    public void testLongToByteArrayTooManyBytesThrows() {
        final byte[] dst = new byte[9];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToByteArray(0xFFL, 8, dst, 0, 8);
            }
        });
    }

    @Test
    public void testLongToHex() {
        final String result = Conversion.longToHex(0x0102030405060708L, 0, "", 0, 16);
        assertEquals("8070605040302010", result);
    }

    @Test
    public void testLongToHexZeroHexsReturnsDstInit() {
        assertEquals("abc", Conversion.longToHex(0xFFL, 0, "abc", 0, 0));
    }

    @Test
    public void testLongToHexTooManyHexsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToHex(0xFFL, 0, "", 0, 17);
            }
        });
    }

    @Test
    public void testLongToIntArray() {
        final int[] dst = new int[2];
        final int[] result = Conversion.longToIntArray(0x0000000200000001L, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new int[] { 1, 2 }, result);
    }

    @Test
    public void testLongToIntArrayZeroIntsReturnsDstUnchanged() {
        final int[] dst = { 7 };
        final int[] result = Conversion.longToIntArray(0xFFL, 0, dst, 0, 0);
        assertSame(dst, result);
    }

    @Test
    public void testLongToIntArrayTooManyIntsThrows() {
        final int[] dst = new int[3];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToIntArray(0xFFL, 32, dst, 0, 2);
            }
        });
    }

    @Test
    public void testLongToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.longToShortArray(0x00020001L, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 0x0001, 0x0002 }, result);
    }

    @Test
    public void testLongToShortArrayZeroShortsReturnsDstUnchanged() {
        final short[] dst = { 9 };
        final short[] result = Conversion.longToShortArray(0xFFL, 0, dst, 0, 0);
        assertSame(dst, result);
    }

    @Test
    public void testLongToShortArrayTooManyShortsThrows() {
        final short[] dst = new short[5];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToShortArray(0xFFL, 16, dst, 0, 4);
            }
        });
    }

    @Test
    public void testShortArrayToInt() {
        final short[] src = { 0x0001, 0x0002 };
        final int result = Conversion.shortArrayToInt(src, 0, 0, 0, 2);
        assertEquals(0x00020001, result);
    }

    @Test
    public void testShortArrayToIntZeroShortsReturnsDstInit() {
        assertEquals(12, Conversion.shortArrayToInt(new short[0], 0, 12, 0, 0));
    }

    @Test
    public void testShortArrayToIntTooManyShortsThrows() {
        final short[] src = new short[3];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortArrayToInt(src, 0, 0, 16, 2);
            }
        });
    }

    @Test
    public void testShortArrayToLong() {
        final short[] src = { 0x0001, 0x0002, 0x0003, 0x0004 };
        final long result = Conversion.shortArrayToLong(src, 0, 0L, 0, 4);
        assertEquals(0x0004000300020001L, result);
    }

    @Test
    public void testShortArrayToLongZeroShortsReturnsDstInit() {
        assertEquals(13L, Conversion.shortArrayToLong(new short[0], 0, 13L, 0, 0));
    }

    @Test
    public void testShortArrayToLongTooManyShortsThrows() {
        final short[] src = new short[5];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortArrayToLong(src, 0, 0L, 16, 4);
            }
        });
    }

    @Test
    public void testShortToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.shortToBinary((short) 0x5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(NIBBLE_0101, result);
    }

    @Test
    public void testShortToBinaryZeroBoolsReturnsDstUnchanged() {
        final boolean[] dst = { true };
        final boolean[] result = Conversion.shortToBinary((short) 0x5, 0, dst, 0, 0);
        assertSame(dst, result);
    }

    @Test
    public void testShortToBinaryTooManyBitsThrows() {
        final boolean[] dst = new boolean[17];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortToBinary((short) 0x5, 1, dst, 0, 16);
            }
        });
    }

    @Test
    public void testShortToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.shortToByteArray((short) 0x0201, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02 }, result);
    }

    @Test
    public void testShortToByteArrayZeroBytesReturnsDstUnchanged() {
        final byte[] dst = { 0x7 };
        final byte[] result = Conversion.shortToByteArray((short) 0xFF, 0, dst, 0, 0);
        assertSame(dst, result);
    }

    @Test
    public void testShortToByteArrayTooManyBytesThrows() {
        final byte[] dst = new byte[3];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortToByteArray((short) 0xFF, 8, dst, 0, 2);
            }
        });
    }

    @Test
    public void testShortToHex() {
        final String result = Conversion.shortToHex((short) 0x1234, 0, "", 0, 4);
        assertEquals("4321", result);
    }

    @Test
    public void testShortToHexZeroHexsReturnsDstInit() {
        assertEquals("zz", Conversion.shortToHex((short) 0xFF, 0, "zz", 0, 0));
    }

    @Test
    public void testShortToHexTooManyHexsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortToHex((short) 0xFF, 0, "", 0, 5);
            }
        });
    }

    @Test
    public void testUuidToByteArray() {
        final UUID uuid = new UUID(0x0102030405060708L, 0x0910111213141516L);
        final byte[] dst = new byte[16];
        final byte[] result = Conversion.uuidToByteArray(uuid, dst, 0, 16);
        assertSame(dst, result);
        final UUID roundTrip = Conversion.byteArrayToUuid(result, 0);
        assertEquals(uuid, roundTrip);
    }

    @Test
    public void testUuidToByteArrayZeroBytesReturnsDstUnchanged() {
        final UUID uuid = UUID.randomUUID();
        final byte[] dst = { 0x1 };
        final byte[] result = Conversion.uuidToByteArray(uuid, dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x1 }, result);
    }

    @Test
    public void testUuidToByteArrayPartial() {
        final UUID uuid = new UUID(0x0102030405060708L, 0x0910111213141516L);
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.uuidToByteArray(uuid, dst, 0, 4);
        assertArrayEquals(new byte[] { 0x08, 0x07, 0x06, 0x05 }, result);
    }

    @Test
    public void testUuidToByteArrayTooManyBytesThrows() {
        final UUID uuid = UUID.randomUUID();
        final byte[] dst = new byte[17];
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.uuidToByteArray(uuid, dst, 0, 17);
            }
        });
    }
}
