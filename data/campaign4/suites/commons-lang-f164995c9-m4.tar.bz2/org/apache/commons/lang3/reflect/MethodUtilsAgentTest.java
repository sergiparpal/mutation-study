/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface MyAnno {
        // marker annotation
    }

    public static class SampleBean {
        public int add(final int a, final int b) {
            return a + b;
        }

        public int add(final int a, final int b, final int c) {
            return a + b + c;
        }

        @MyAnno
        public void annotated() {
            // no-op
        }

        public String concat(final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (final String p : parts) {
                sb.append(p);
            }
            return sb.toString();
        }

        public String echo(final String s) {
            return "echo:" + s;
        }

        public String noArgs() {
            return "noargs";
        }

        public void notAnnotated() {
            // no-op
        }

        public String overload(final Integer n) {
            return "Integer:" + n;
        }

        public String overload(final Number n) {
            return "Number:" + n;
        }

        private String secret() {
            return "secret";
        }

        public static int staticSum(final int... nums) {
            int sum = 0;
            for (final int n : nums) {
                sum += n;
            }
            return sum;
        }

        public static String staticGreet(final String name) {
            return "Hello " + name;
        }
    }

    private static class PrivateSub extends SampleBean {
        // used to test accessible-method-from-superclass lookup
    }

    public interface PublicIface {
        String value();
    }

    private static class PackagePrivateImpl implements PublicIface {
        @Override
        public String value() {
            return "impl";
        }
    }

    public interface Greeter {
        String greet();
    }

    public static class GreeterBase implements Greeter {
        @Override
        public String greet() {
            return "base";
        }
    }

    public static class GreeterSub extends GreeterBase {
        @Override
        public String greet() {
            return "sub";
        }
    }

    static class AnnoBase {
        @MyAnno
        public void run() {
            // no-op
        }
    }

    static class AnnoSub extends AnnoBase {
        @Override
        public void run() {
            // no-op
        }
    }

    static class AnnoParent {
        @MyAnno
        private void secretAnnotated() {
            // no-op
        }
    }

    static class AnnoChild extends AnnoParent {
        // used to test searchSupers behavior
    }

    // --- getAccessibleMethod ---

    @Test
    public void testGetAccessibleMethod_nullMethod() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethod_publicClassReturnsSameMethod() throws Exception {
        final Method method = SampleBean.class.getMethod("echo", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(method);
        assertEquals(method, accessible);
    }

    @Test
    public void testGetAccessibleMethod_fromInterfaceNest() throws Exception {
        final Method method = PackagePrivateImpl.class.getMethod("value");
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, method);
        assertNotNull(accessible);
        assertEquals(PublicIface.class, accessible.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethod_fromSuperclass() {
        final Method accessible = MethodUtils.getAccessibleMethod(PrivateSub.class, "add", int.class, int.class);
        assertNotNull(accessible);
        assertEquals(SampleBean.class, accessible.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethod_byNameNotFound() {
        assertNull(MethodUtils.getAccessibleMethod(SampleBean.class, "doesNotExist"));
    }

    // --- getAnnotation ---

    @Test
    public void testGetAnnotation_nullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, MyAnno.class, false, false));
    }

    @Test
    public void testGetAnnotation_nullAnnotationClassThrows() throws Exception {
        final Method method = SampleBean.class.getMethod("annotated");
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(method, null, false, false));
    }

    @Test
    public void testGetAnnotation_presentDirectly() throws Exception {
        final Method method = SampleBean.class.getMethod("annotated");
        assertNotNull(MethodUtils.getAnnotation(method, MyAnno.class, false, false));
    }

    @Test
    public void testGetAnnotation_absent() throws Exception {
        final Method method = SampleBean.class.getMethod("notAnnotated");
        assertNull(MethodUtils.getAnnotation(method, MyAnno.class, false, false));
    }

    @Test
    public void testGetAnnotation_searchSupersFindsOverriddenAnnotation() throws Exception {
        final Method subMethod = AnnoSub.class.getMethod("run");
        assertNull(subMethod.getAnnotation(MyAnno.class));
        assertNotNull(MethodUtils.getAnnotation(subMethod, MyAnno.class, true, true));
    }

    @Test
    public void testGetAnnotation_noSearchSupersMissesOverriddenAnnotation() throws Exception {
        final Method subMethod = AnnoSub.class.getMethod("run");
        assertNull(MethodUtils.getAnnotation(subMethod, MyAnno.class, false, true));
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    public void testGetMatchingAccessibleMethod_exactMatch() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(SampleBean.class, "add", int.class, int.class);
        assertNotNull(method);
        assertEquals(2, method.getParameterTypes().length);
    }

    @Test
    public void testGetMatchingAccessibleMethod_varargs() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(SampleBean.class, "concat", String.class, String.class);
        assertNotNull(method);
        assertTrue(method.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethod_picksMostSpecificOverload() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(SampleBean.class, "overload", Integer.class);
        assertNotNull(method);
        assertEquals(Integer.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethod_noMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(SampleBean.class, "doesNotExist"));
    }

    // --- getMatchingMethod ---

    @Test
    public void testGetMatchingMethod_nullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "add"));
    }

    @Test
    public void testGetMatchingMethod_nullNameThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(SampleBean.class, null));
    }

    @Test
    public void testGetMatchingMethod_emptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(SampleBean.class, ""));
    }

    @Test
    public void testGetMatchingMethod_findsPrivateDeclaredMethod() {
        final Method method = MethodUtils.getMatchingMethod(SampleBean.class, "secret");
        assertNotNull(method);
        assertEquals("secret", method.getName());
    }

    @Test
    public void testGetMatchingMethod_exactParameterMatch() {
        final Method method = MethodUtils.getMatchingMethod(SampleBean.class, "add", int.class, int.class, int.class);
        assertNotNull(method);
        assertEquals(3, method.getParameterTypes().length);
    }

    @Test
    public void testGetMatchingMethod_notFoundReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(SampleBean.class, "doesNotExist"));
    }

    // --- getMethodObject ---

    @Test
    public void testGetMethodObject_found() {
        final Method method = MethodUtils.getMethodObject(SampleBean.class, "noArgs");
        assertNotNull(method);
        assertEquals("noArgs", method.getName());
    }

    @Test
    public void testGetMethodObject_notFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(SampleBean.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObject_nullClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "noArgs"));
    }

    @Test
    public void testGetMethodObject_nullNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(SampleBean.class, null));
    }

    // --- getMethodsListWithAnnotation / getMethodsWithAnnotation ---

    @Test
    public void testGetMethodsListWithAnnotation_nullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, MyAnno.class));
    }

    @Test
    public void testGetMethodsListWithAnnotation_nullAnnotationThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(SampleBean.class, null));
    }

    @Test
    public void testGetMethodsListWithAnnotation_findsPublicAnnotatedMethod() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(SampleBean.class, MyAnno.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsListWithAnnotation_withoutSearchSupersMissesInheritedPrivate() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AnnoChild.class, MyAnno.class, false, true);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotation_searchSupersFindsInheritedPrivate() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AnnoChild.class, MyAnno.class, true, true);
        assertEquals(1, methods.size());
        assertEquals("secretAnnotated", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsWithAnnotation_arrayMatchesList() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(SampleBean.class, MyAnno.class);
        assertEquals(1, methods.length);
        assertEquals("annotated", methods[0].getName());
    }

    // --- getOverrideHierarchy ---

    @Test
    public void testGetOverrideHierarchy_nullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE));
    }

    @Test
    public void testGetOverrideHierarchy_includeInterfaces() throws Exception {
        final Method method = GreeterSub.class.getMethod("greet");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.INCLUDE);
        assertEquals(3, hierarchy.size());
        final Iterator<Method> it = hierarchy.iterator();
        assertEquals(GreeterSub.class, it.next().getDeclaringClass());
    }

    @Test
    public void testGetOverrideHierarchy_excludeInterfaces() throws Exception {
        final Method method = GreeterSub.class.getMethod("greet");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
    }

    // --- invokeExactMethod ---

    @Test
    public void testInvokeExactMethod_noArgs() throws Exception {
        final SampleBean bean = new SampleBean();
        final Object result = MethodUtils.invokeExactMethod(bean, "noArgs");
        assertEquals("noargs", result);
    }

    @Test
    public void testInvokeExactMethod_withArg() throws Exception {
        final SampleBean bean = new SampleBean();
        final Object result = MethodUtils.invokeExactMethod(bean, "echo", "hi");
        assertEquals("echo:hi", result);
    }

    @Test
    public void testInvokeExactMethod_notFoundThrows() {
        final SampleBean bean = new SampleBean();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(bean, "doesNotExist"));
    }

    @Test
    public void testInvokeExactMethod_primitiveMismatchThrows() {
        // Integer args do not exactly match the declared int parameters.
        final SampleBean bean = new SampleBean();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(bean, "add", 1, 2));
    }

    // --- invokeExactStaticMethod ---

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(SampleBean.class, "staticGreet", "World");
        assertEquals("Hello World", result);
    }

    @Test
    public void testInvokeExactStaticMethod_notFoundThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactStaticMethod(SampleBean.class, "doesNotExist"));
    }

    // --- invokeMethod ---

    @Test
    public void testInvokeMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "noArgs"));
    }

    @Test
    public void testInvokeMethod_publicWithArgs() throws Exception {
        final SampleBean bean = new SampleBean();
        final Object result = MethodUtils.invokeMethod(bean, "add", 2, 3);
        assertEquals(5, result);
    }

    @Test
    public void testInvokeMethod_varargs() throws Exception {
        final SampleBean bean = new SampleBean();
        final Object result = MethodUtils.invokeMethod(bean, "concat", "a", "b", "c");
        assertEquals("abc", result);
    }

    @Test
    public void testInvokeMethod_privateWithoutForceAccessThrows() {
        final SampleBean bean = new SampleBean();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(bean, false, "secret"));
    }

    @Test
    public void testInvokeMethod_privateWithForceAccess() throws Exception {
        final SampleBean bean = new SampleBean();
        final Object result = MethodUtils.invokeMethod(bean, true, "secret");
        assertEquals("secret", result);
    }

    // --- invokeStaticMethod ---

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(SampleBean.class, "staticGreet", "X");
        assertEquals("Hello X", result);
    }

    @Test
    public void testInvokeStaticMethod_varargs() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(SampleBean.class, "staticSum", 1, 2, 3);
        assertEquals(6, result);
    }

    @Test
    public void testInvokeStaticMethod_notFoundThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(SampleBean.class, "doesNotExist"));
    }

    @Test
    public void testInvokeStaticMethod_instanceMethodNotFoundAsStatic() {
        // "echo" is an instance method; invoking it statically must fail.
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(SampleBean.class, "echo", "x"));
    }
}
