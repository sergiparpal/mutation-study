package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link Lexer}, based solely on the documented contract.
 */
class LexerAgentTest {

    private static Lexer newLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    // -------------------------------------------------------------------
    // close() / isClosed()
    // -------------------------------------------------------------------

    @Test
    void testIsClosedInitiallyFalse() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        assertFalse(lexer.isClosed());
    }

    @Test
    void testCloseSetsClosedFlag() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    // -------------------------------------------------------------------
    // getBytesRead() / getCharacterPosition()
    // -------------------------------------------------------------------

    @Test
    void testGetBytesReadAndCharacterPositionInitiallyZero() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        assertEquals(0L, lexer.getBytesRead());
        assertEquals(0L, lexer.getCharacterPosition());
    }

    @Test
    void testGetBytesReadAndCharacterPositionIncreaseAfterReading() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertTrue(lexer.getBytesRead() > 0L);
        assertTrue(lexer.getCharacterPosition() > 0L);
    }

    // -------------------------------------------------------------------
    // getCurrentLineNumber()
    // -------------------------------------------------------------------

    @Test
    void testGetCurrentLineNumberInitiallyZero() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c\n");
        assertEquals(0L, lexer.getCurrentLineNumber());
    }

    @Test
    void testGetCurrentLineNumberIncrementsAfterRecord() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\nc,d\n");
        final Token token = new Token();
        lexer.nextToken(token); // "a"
        lexer.nextToken(token); // "b" -> end of first record
        assertEquals(1L, lexer.getCurrentLineNumber());
    }

    // -------------------------------------------------------------------
    // getFirstEol()
    // -------------------------------------------------------------------

    @Test
    void testGetFirstEolInitiallyNull() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\n");
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testGetFirstEolAfterLineFeed() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\nc,d\n");
        final Token token = new Token();
        lexer.nextToken(token);
        lexer.nextToken(token);
        assertEquals("\n", lexer.getFirstEol());
    }

    @Test
    void testGetFirstEolAfterCrLf() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\r\nc,d\r\n");
        final Token token = new Token();
        lexer.nextToken(token);
        lexer.nextToken(token);
        assertEquals("\r\n", lexer.getFirstEol());
    }

    // -------------------------------------------------------------------
    // isEndOfFile(int)
    // -------------------------------------------------------------------

    @Test
    void testIsEndOfFileTrueForEofMarker() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(-1));
    }

    @Test
    void testIsEndOfFileFalseForOrdinaryChar() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isEndOfFile('a'));
    }

    // -------------------------------------------------------------------
    // isStartOfLine(int)
    // -------------------------------------------------------------------

    @Test
    void testIsStartOfLineTrueForCr() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine('\r'));
    }

    @Test
    void testIsStartOfLineTrueForLf() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine('\n'));
    }

    @Test
    void testIsStartOfLineFalseForOrdinaryChar() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isStartOfLine('a'));
    }

    // -------------------------------------------------------------------
    // isQuoteChar(int)
    // -------------------------------------------------------------------

    @Test
    void testIsQuoteCharTrueForConfiguredQuote() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isQuoteChar('"'));
    }

    @Test
    void testIsQuoteCharFalseForOrdinaryChar() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isQuoteChar('a'));
    }

    // -------------------------------------------------------------------
    // isEscape(int)
    // -------------------------------------------------------------------

    @Test
    void testIsEscapeFalseWhenNotConfigured() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    void testIsEscapeTrueWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        final Lexer lexer = newLexer(format, "");
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
    }

    // -------------------------------------------------------------------
    // isCommentStart(int)
    // -------------------------------------------------------------------

    @Test
    void testIsCommentStartFalseWhenNotConfigured() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    void testIsCommentStartTrueWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final Lexer lexer = newLexer(format, "");
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    // -------------------------------------------------------------------
    // isDelimiter(int)
    // -------------------------------------------------------------------

    @Test
    void testIsDelimiterTrueForDefaultComma() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isDelimiter(','));
    }

    @Test
    void testIsDelimiterFalseForOrdinaryChar() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isDelimiter('a'));
    }

    @Test
    void testIsDelimiterTrueForConfiguredSemicolon() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(';').build();
        final Lexer lexer = newLexer(format, "");
        assertTrue(lexer.isDelimiter(';'));
        assertFalse(lexer.isDelimiter(','));
    }

    // -------------------------------------------------------------------
    // isEscapeDelimiter()
    // -------------------------------------------------------------------

    @Test
    void testIsEscapeDelimiterFalseWhenEscapeNotTheCurrentChar() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('!').build();
        final Lexer lexer = newLexer(format, "x");
        assertFalse(lexer.isEscapeDelimiter());
    }

    // -------------------------------------------------------------------
    // readEndOfLine(int)
    // -------------------------------------------------------------------

    @Test
    void testReadEndOfLineTrueForLf() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.readEndOfLine('\n'));
    }

    @Test
    void testReadEndOfLineFalseForOrdinaryChar() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.readEndOfLine('a'));
    }

    @Test
    void testReadEndOfLineGreedilyConsumesPairedLineFeed() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\nX"));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertTrue(lexer.readEndOfLine('\r'));
        // The paired '\n' following the '\r' must have been silently consumed.
        assertEquals('X', reader.read());
    }

    // -------------------------------------------------------------------
    // readEscape()
    // -------------------------------------------------------------------

    @Test
    void testReadEscapeThrowsIoExceptionAtEndOfStream() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\\"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read(); // consume the escape character itself so it becomes "the current character"
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
    }

    // -------------------------------------------------------------------
    // trimTrailingSpaces(StringBuilder)
    // -------------------------------------------------------------------

    @Test
    void testTrimTrailingSpacesRemovesTrailingWhitespace() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("hello   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("hello", buffer.toString());
    }

    @Test
    void testTrimTrailingSpacesAllSpacesBecomesEmpty() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("    ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    @Test
    void testTrimTrailingSpacesNoTrailingSpacesUnchanged() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("hello");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("hello", buffer.toString());
    }

    // -------------------------------------------------------------------
    // nextToken(Token)
    // -------------------------------------------------------------------

    @Test
    void testNextTokenEmptyInputReturnsEof() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final Token token = new Token();
        final Token result = lexer.nextToken(token);
        assertEquals(Token.Type.EOF, result.type);
        assertEquals(0, result.content.length());
    }

    @Test
    void testNextTokenSimpleRecordNoTrailingNewline() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b,c");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    void testNextTokenRecordWithTrailingNewline() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a,b\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        final Token result = lexer.nextToken(token);
        assertEquals(Token.Type.EOF, result.type);
    }

    @Test
    void testNextTokenQuotedFieldPreservesEmbeddedDelimiter() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "\"a,b\",c\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
    }

    @Test
    void testNextTokenCommentLineIsReportedAsComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final Lexer lexer = newLexer(format, "#comment\na\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("comment", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());
    }

    @Test
    void testNextTokenMultipleRecords() throws IOException {
        final Lexer lexer = newLexer(CSVFormat.DEFAULT, "a\nb\n");
        final Token token = new Token();

        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        final Token result = lexer.nextToken(token);
        assertEquals(Token.Type.EOF, result.type);
    }
}
