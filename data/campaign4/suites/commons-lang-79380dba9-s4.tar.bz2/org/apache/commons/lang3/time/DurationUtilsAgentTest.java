package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DurationUtils}, based solely on its documented contract.
 */
public class DurationUtilsAgentTest {

    /**
     * A checked exception used to verify that exceptions thrown by lambdas/functions are propagated.
     */
    private static final class AgentCheckedException extends Exception {
        AgentCheckedException(final String message) {
            super(message);
        }
    }

    private static String uniqueKey() {
        return "DurationUtilsAgentTest." + UUID.randomUUID();
    }

    // ---------------------------------------------------------------
    // accept(FailableBiConsumer, Duration)
    // ---------------------------------------------------------------

    @Test
    public void testAcceptPassesMillisAndNanos() {
        final Duration duration = Duration.ofSeconds(5, 1_500_000L);
        final long[] capturedMillis = new long[1];
        final int[] capturedNanos = new int[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                capturedMillis[0] = millis.longValue();
                capturedNanos[0] = nanos.intValue();
            }
        }, duration);
        assertEquals(duration.toMillis(), capturedMillis[0]);
        assertEquals(DurationUtils.getNanosOfMilli(duration), capturedNanos[0]);
        assertEquals(500_000, capturedNanos[0]);
    }

    @Test
    public void testAcceptPropagatesException() {
        final Duration duration = Duration.ofSeconds(1);
        final AgentCheckedException thrown = assertThrows(AgentCheckedException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.accept(new FailableBiConsumer<Long, Integer, AgentCheckedException>() {
                    @Override
                    public void accept(final Long millis, final Integer nanos) throws AgentCheckedException {
                        throw new AgentCheckedException("boom");
                    }
                }, duration);
            }
        });
        assertEquals("boom", thrown.getMessage());
    }

    // ---------------------------------------------------------------
    // get(String, TemporalUnit, long) / getMillis(String, long) / getSeconds(String, long)
    // ---------------------------------------------------------------

    @Test
    public void testGetUsesDefaultWhenPropertyMissing() {
        final String key = uniqueKey();
        final Duration result = DurationUtils.get(key, ChronoUnit.SECONDS, 7L);
        assertEquals(Duration.ofSeconds(7L), result);
    }

    @Test
    public void testGetUsesPropertyValueWhenPresent() {
        final String key = uniqueKey();
        try {
            System.setProperty(key, "11");
            final Duration result = DurationUtils.get(key, ChronoUnit.SECONDS, 7L);
            assertEquals(Duration.ofSeconds(11L), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    public void testGetMillisUsesDefaultWhenPropertyMissing() {
        final String key = uniqueKey();
        final Duration result = DurationUtils.getMillis(key, 250L);
        assertEquals(Duration.ofMillis(250L), result);
    }

    @Test
    public void testGetMillisUsesPropertyValueWhenPresent() {
        final String key = uniqueKey();
        try {
            System.setProperty(key, "500");
            final Duration result = DurationUtils.getMillis(key, 250L);
            assertEquals(Duration.ofMillis(500L), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    public void testGetSecondsUsesDefaultWhenPropertyMissing() {
        final String key = uniqueKey();
        final Duration result = DurationUtils.getSeconds(key, 9L);
        assertEquals(Duration.ofSeconds(9L), result);
    }

    @Test
    public void testGetSecondsUsesPropertyValueWhenPresent() {
        final String key = uniqueKey();
        try {
            System.setProperty(key, "42");
            final Duration result = DurationUtils.getSeconds(key, 9L);
            assertEquals(Duration.ofSeconds(42L), result);
        } finally {
            System.clearProperty(key);
        }
    }

    // ---------------------------------------------------------------
    // getNanosOfMilli(Duration) / getNanosOfMiili(Duration) [deprecated alias]
    // ---------------------------------------------------------------

    @Test
    public void testGetNanosOfMilliIsBetween0And999999() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ZERO));
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofMillis(1500)));
        assertEquals(999_999, DurationUtils.getNanosOfMilli(Duration.ofNanos(999_999_999L)));
        assertEquals(250, DurationUtils.getNanosOfMilli(Duration.ofMillis(1500).plusNanos(250)));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testGetNanosOfMiiliDeprecatedAliasMatchesReplacement() {
        final Duration duration = Duration.ofMillis(2500).plusNanos(777);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    // ---------------------------------------------------------------
    // isPositive(Duration)
    // ---------------------------------------------------------------

    @Test
    public void testIsPositive() {
        assertTrue(DurationUtils.isPositive(Duration.ofNanos(1)));
        assertTrue(DurationUtils.isPositive(Duration.ofSeconds(1)));
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
        assertFalse(DurationUtils.isPositive(Duration.ofSeconds(-1)));
        assertFalse(DurationUtils.isPositive(Duration.ofNanos(-1)));
    }

    // ---------------------------------------------------------------
    // of(FailableConsumer<Instant, E>) / of(FailableRunnable<E>)
    // ---------------------------------------------------------------

    @Test
    public void testOfRunnableReturnsNonNegativeDurationAndRunsOnce() {
        final int[] runCount = new int[1];
        final Duration duration = DurationUtils.of(new FailableRunnable<RuntimeException>() {
            @Override
            public void run() {
                runCount[0]++;
            }
        });
        assertEquals(1, runCount[0]);
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    public void testOfRunnableMeasuresElapsedTime() throws InterruptedException {
        final Duration duration = DurationUtils.of(new FailableRunnable<RuntimeException>() {
            @Override
            public void run() {
                try {
                    Thread.sleep(30L);
                } catch (final InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        assertTrue(DurationUtils.isPositive(duration));
        assertTrue(duration.toMillis() >= 10L);
    }

    @Test
    public void testOfRunnablePropagatesException() {
        final AgentCheckedException thrown = assertThrows(AgentCheckedException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<AgentCheckedException>() {
                    @Override
                    public void run() throws AgentCheckedException {
                        throw new AgentCheckedException("runnable-boom");
                    }
                });
            }
        });
        assertEquals("runnable-boom", thrown.getMessage());
    }

    @Test
    public void testOfConsumerReceivesStartInstantAndReturnsNonNegativeDuration() {
        final Instant[] captured = new Instant[1];
        final Duration duration = DurationUtils.of(new FailableConsumer<Instant, RuntimeException>() {
            @Override
            public void accept(final Instant instant) {
                captured[0] = instant;
            }
        });
        assertNotNull(captured[0]);
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    public void testOfConsumerPropagatesException() {
        final AgentCheckedException thrown = assertThrows(AgentCheckedException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, AgentCheckedException>() {
                    @Override
                    public void accept(final Instant instant) throws AgentCheckedException {
                        throw new AgentCheckedException("consumer-boom");
                    }
                });
            }
        });
        assertEquals("consumer-boom", thrown.getMessage());
    }

    // ---------------------------------------------------------------
    // since(Temporal)
    // ---------------------------------------------------------------

    @Test
    public void testSincePastInstantIsPositive() {
        final Instant start = Instant.now().minusSeconds(3);
        final Duration result = DurationUtils.since(start);
        assertTrue(DurationUtils.isPositive(result));
        assertTrue(result.getSeconds() >= 2L);
        assertTrue(result.getSeconds() < 30L);
    }

    @Test
    public void testSinceFutureInstantIsNegative() {
        final Instant start = Instant.now().plusSeconds(60);
        final Duration result = DurationUtils.since(start);
        assertTrue(result.isNegative());
    }

    // ---------------------------------------------------------------
    // toChronoUnit(TimeUnit) [package-private]
    // ---------------------------------------------------------------

    @Test
    public void testToChronoUnitMapsAllTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    // ---------------------------------------------------------------
    // toDuration(long, TimeUnit)
    // ---------------------------------------------------------------

    @Test
    public void testToDurationConvertsAmountAndUnit() {
        assertEquals(Duration.ofNanos(100L), DurationUtils.toDuration(100L, TimeUnit.NANOSECONDS));
        assertEquals(Duration.ofNanos(100_000L), DurationUtils.toDuration(100L, TimeUnit.MICROSECONDS));
        assertEquals(Duration.ofMillis(500L), DurationUtils.toDuration(500L, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ofSeconds(5L), DurationUtils.toDuration(5L, TimeUnit.SECONDS));
        assertEquals(Duration.ofMinutes(2L), DurationUtils.toDuration(2L, TimeUnit.MINUTES));
        assertEquals(Duration.ofHours(3L), DurationUtils.toDuration(3L, TimeUnit.HOURS));
        assertEquals(Duration.ofDays(1L), DurationUtils.toDuration(1L, TimeUnit.DAYS));
    }

    @Test
    public void testToDurationNegativeAmount() {
        assertEquals(Duration.ofSeconds(-5L), DurationUtils.toDuration(-5L, TimeUnit.SECONDS));
    }

    @Test
    public void testToDurationZeroAmount() {
        assertEquals(Duration.ZERO, DurationUtils.toDuration(0L, TimeUnit.SECONDS));
    }

    // ---------------------------------------------------------------
    // toMillisInt(Duration)
    // ---------------------------------------------------------------

    @Test
    public void testToMillisIntWithinRangeReturnsExactValue() {
        assertEquals(1000, DurationUtils.toMillisInt(Duration.ofMillis(1000L)));
        assertEquals(0, DurationUtils.toMillisInt(Duration.ZERO));
        assertEquals(-1000, DurationUtils.toMillisInt(Duration.ofMillis(-1000L)));
    }

    @Test
    public void testToMillisIntClampsAtIntegerMaxValue() {
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(Duration.ofMillis((long) Integer.MAX_VALUE)));
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(Duration.ofMillis((long) Integer.MAX_VALUE + 1L)));
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(Duration.ofMillis(Long.MAX_VALUE / 2L)));
    }

    @Test
    public void testToMillisIntClampsAtIntegerMinValue() {
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(Duration.ofMillis((long) Integer.MIN_VALUE)));
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(Duration.ofMillis((long) Integer.MIN_VALUE - 1L)));
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(Duration.ofMillis(Long.MIN_VALUE / 2L)));
    }

    // ---------------------------------------------------------------
    // zeroIfNull(Duration)
    // ---------------------------------------------------------------

    @Test
    public void testZeroIfNullWithNullReturnsZero() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    public void testZeroIfNullWithNonNullReturnsSameValue() {
        final Duration duration = Duration.ofSeconds(42L);
        assertSame(duration, DurationUtils.zeroIfNull(duration));
    }
}
