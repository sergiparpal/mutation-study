package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StopWatch}, based solely on its documented contract.
 */
public class StopWatchAgentTest {

    private static final class AgentCheckedException extends Exception {
        AgentCheckedException(final String message) {
            super(message);
        }
    }

    private static final String TIME_PATTERN = "\\d+:\\d{2}:\\d{2}\\.\\d{3}";

    // ---------------------------------------------------------------
    // Construction / factories
    // ---------------------------------------------------------------

    @Test
    public void testDefaultConstructorIsNotStarted() {
        final StopWatch sw = new StopWatch();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    public void testMessageConstructorStoresMessage() {
        final StopWatch sw = new StopWatch("myMessage");
        assertEquals("myMessage", sw.getMessage());
    }

    @Test
    public void testCreateIsNotStarted() {
        final StopWatch sw = StopWatch.create();
        assertNotNull(sw);
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
    }

    @Test
    public void testCreateStartedIsStarted() {
        final StopWatch sw = StopWatch.createStarted();
        assertNotNull(sw);
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
    }

    // ---------------------------------------------------------------
    // start() / stop() state machine
    // ---------------------------------------------------------------

    @Test
    public void testStartThenStateIsStarted() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertFalse(sw.isSuspended());
        assertNotNull(sw.getStartInstant());
    }

    @Test
    public void testStartTwiceWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
    }

    @Test
    public void testStopWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testStopTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testStopSetsStoppedStateAndStopInstant() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertTrue(sw.isStopped());
        assertFalse(sw.isStarted());
        assertNotNull(sw.getStopInstant());
        assertTrue(sw.getTime() >= 0L);
    }

    @Test
    public void testStartCannotBeCalledAgainAfterStopWithoutReset() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
    }

    @Test
    public void testResetAllowsRestart() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        sw.reset();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        sw.start();
        assertTrue(sw.isStarted());
    }

    @Test
    public void testGetStartInstantWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartInstant();
            }
        });
    }

    @Test
    public void testGetStopInstantWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStopInstant();
            }
        });
    }

    // ---------------------------------------------------------------
    // suspend() / resume()
    // ---------------------------------------------------------------

    @Test
    public void testSuspendWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.resume();
            }
        });
    }

    @Test
    public void testSuspendThenIsSuspendedAndStillStarted() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertTrue(sw.isSuspended());
        assertTrue(sw.isStarted());
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testResumeAfterSuspendClearsSuspended() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        sw.resume();
        assertFalse(sw.isSuspended());
        assertTrue(sw.isStarted());
    }

    // ---------------------------------------------------------------
    // split() / split(String) / unsplit() / getSplits()
    // ---------------------------------------------------------------

    @Test
    public void testSplitWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testSplitTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.unsplit();
            }
        });
    }

    @Test
    public void testSplitThenGetSplitDurationAndNanoTimeAreConsistent() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        final Duration splitDuration = sw.getSplitDuration();
        assertNotNull(splitDuration);
        assertFalse(splitDuration.isNegative());
        assertEquals(splitDuration.toNanos(), sw.getSplitNanoTime());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testGetSplitTimeDeprecatedMatchesSplitDurationMillis() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertEquals(sw.getSplitDuration().toMillis(), sw.getSplitTime());
    }

    @Test
    public void testGetSplitDurationWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitDuration();
            }
        });
    }

    @Test
    public void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitNanoTime();
            }
        });
    }

    @Test
    public void testUnsplitClearsSplitState() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.unsplit();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitDuration();
            }
        });
    }

    @Test
    public void testUnsplitAllowsSplitAgain() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.unsplit();
        sw.split();
        assertNotNull(sw.getSplitDuration());
    }

    @Test
    public void testGetSplitsEmptyBeforeAnySplit() {
        final StopWatch sw = StopWatch.create();
        final List<StopWatch.Split> splits = sw.getSplits();
        assertNotNull(splits);
        assertTrue(splits.isEmpty());
    }

    @Test
    public void testSplitWithLabelAddsToSplits() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split("firstLabel");
        final List<StopWatch.Split> splits = sw.getSplits();
        assertTrue(splits.size() >= 1);
        final StopWatch.Split last = splits.get(splits.size() - 1);
        assertEquals("firstLabel", last.getLabel());
        assertNotNull(last.getDuration());
        assertFalse(last.getDuration().isNegative());
    }

    @Test
    public void testSplitWithLabelThrowsWhenNotRunning() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split("label");
            }
        });
    }

    // ---------------------------------------------------------------
    // StopWatch.Split
    // ---------------------------------------------------------------

    @Test
    public void testSplitConstructorStoresLabelAndDuration() {
        final Duration duration = Duration.ofSeconds(2);
        final StopWatch.Split split = new StopWatch.Split("myLabel", duration);
        assertEquals("myLabel", split.getLabel());
        assertEquals(duration, split.getDuration());
        assertNotNull(split.toString());
    }

    // ---------------------------------------------------------------
    // getTime() / getTime(TimeUnit) / getNanoTime() / getDuration()
    // ---------------------------------------------------------------

    @Test
    public void testGetTimeMatchesGetDurationMillis() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getDuration().toMillis(), sw.getTime());
    }

    @Test
    public void testGetTimeMillisecondsUnitMatchesGetTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getTime(), sw.getTime(TimeUnit.MILLISECONDS));
    }

    @Test
    public void testGetTimeNanosecondsUnitMatchesGetNanoTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getNanoTime(), sw.getTime(TimeUnit.NANOSECONDS));
    }

    @Test
    public void testGetTimeSecondsUnitRoundsDown() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getTime() / 1000L, sw.getTime(TimeUnit.SECONDS));
    }

    @Test
    public void testGetNanoTimeIsStableAfterStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        final long first = sw.getNanoTime();
        final long second = sw.getNanoTime();
        assertEquals(first, second);
        assertTrue(first >= 0L);
    }

    @Test
    public void testGetDurationNonNegativeAfterStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        final Duration duration = sw.getDuration();
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testGetStartTimeDeprecatedMatchesStartInstant() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertEquals(sw.getStartInstant().toEpochMilli(), sw.getStartTime());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testGetStartTimeWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartTime();
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testGetStopTimeDeprecatedMatchesStopInstant() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getStopInstant().toEpochMilli(), sw.getStopTime());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testGetStopTimeWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStopTime();
            }
        });
    }

    // ---------------------------------------------------------------
    // isStarted() / isStopped() / isSuspended()
    // ---------------------------------------------------------------

    @Test
    public void testIsStoppedTrueForNeverStartedWatch() {
        final StopWatch sw = new StopWatch();
        assertTrue(sw.isStopped());
    }

    @Test
    public void testIsStoppedTrueAfterExplicitStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertTrue(sw.isStopped());
    }

    @Test
    public void testIsStartedFalseAfterStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertFalse(sw.isStarted());
    }

    // ---------------------------------------------------------------
    // toString() / toSplitString() / formatTime() / formatSplitTime()
    // ---------------------------------------------------------------

    @Test
    public void testToStringWithoutMessageMatchesTimePattern() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertTrue(sw.toString().matches(TIME_PATTERN));
    }

    @Test
    public void testToStringWithMessageHasMessagePrefix() {
        final StopWatch sw = new StopWatch("prefixMsg");
        sw.start();
        sw.stop();
        final String result = sw.toString();
        assertTrue(result.startsWith("prefixMsg "));
        assertTrue(result.substring("prefixMsg ".length()).matches(TIME_PATTERN));
    }

    @Test
    public void testToSplitStringWithoutMessageMatchesTimePattern() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertTrue(sw.toSplitString().matches(TIME_PATTERN));
    }

    @Test
    public void testToSplitStringWithMessageHasMessagePrefix() {
        final StopWatch sw = new StopWatch("splitMsg");
        sw.start();
        sw.split();
        final String result = sw.toSplitString();
        assertTrue(result.startsWith("splitMsg "));
        assertTrue(result.substring("splitMsg ".length()).matches(TIME_PATTERN));
    }

    @Test
    public void testFormatTimeMatchesTimePattern() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertTrue(sw.formatTime().matches(TIME_PATTERN));
    }

    @Test
    public void testFormatSplitTimeMatchesTimePattern() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertTrue(sw.formatSplitTime().matches(TIME_PATTERN));
    }

    // ---------------------------------------------------------------
    // get(Supplier) / run(Runnable) / getT(FailableSupplier) / runT(FailableRunnable)
    // ---------------------------------------------------------------

    @Test
    public void testGetDelegatesToSupplierAndReturnsItsValue() {
        final StopWatch sw = new StopWatch();
        final String result = sw.get(new Supplier<String>() {
            @Override
            public String get() {
                return "supplierValue";
            }
        });
        assertEquals("supplierValue", result);
        assertTrue(sw.isStopped());
        assertTrue(sw.getTime() >= 0L);
    }

    @Test
    public void testRunDelegatesToRunnableAndExecutesIt() {
        final StopWatch sw = new StopWatch();
        final int[] runCount = new int[1];
        sw.run(new Runnable() {
            @Override
            public void run() {
                runCount[0]++;
            }
        });
        assertEquals(1, runCount[0]);
        assertTrue(sw.isStopped());
    }

    @Test
    public void testGetTDelegatesToSupplierAndReturnsItsValue() throws Throwable {
        final StopWatch sw = new StopWatch();
        final Integer result = sw.getT(new FailableSupplier<Integer, AgentCheckedException>() {
            @Override
            public Integer get() {
                return 99;
            }
        });
        assertEquals(Integer.valueOf(99), result);
        assertTrue(sw.isStopped());
    }

    @Test
    public void testGetTPropagatesException() {
        final StopWatch sw = new StopWatch();
        final Throwable thrown = assertThrows(AgentCheckedException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sw.getT(new FailableSupplier<Integer, AgentCheckedException>() {
                    @Override
                    public Integer get() throws AgentCheckedException {
                        throw new AgentCheckedException("getT-boom");
                    }
                });
            }
        });
        assertEquals("getT-boom", thrown.getMessage());
    }

    @Test
    public void testRunTDelegatesToRunnableAndExecutesIt() throws Throwable {
        final StopWatch sw = new StopWatch();
        final int[] runCount = new int[1];
        sw.runT(new FailableRunnable<AgentCheckedException>() {
            @Override
            public void run() {
                runCount[0]++;
            }
        });
        assertEquals(1, runCount[0]);
        assertTrue(sw.isStopped());
    }

    @Test
    public void testRunTPropagatesException() {
        final StopWatch sw = new StopWatch();
        final Throwable thrown = assertThrows(AgentCheckedException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sw.runT(new FailableRunnable<AgentCheckedException>() {
                    @Override
                    public void run() throws AgentCheckedException {
                        throw new AgentCheckedException("runT-boom");
                    }
                });
            }
        });
        assertEquals("runT-boom", thrown.getMessage());
    }
}
