/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum HeaderEnum {
        Name, Email, Phone
    }

    // --- Predefined format fields ---

    @Test
    void testDefaultFormatFields() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
    }

    @Test
    void testExcelFormatFields() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testTdfFormatFields() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormatFields() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
    }

    // --- newFormat / valueOf ---

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat('!');
        assertEquals("!", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
    }

    @Test
    void testValueOf() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NoSuchFormat");
            }
        });
    }

    // --- Builder basic setters/getters ---

    @Test
    void testBuilderSetDelimiterChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(";", format.getDelimiterString());
        assertEquals(';', format.getDelimiter());
    }

    @Test
    void testBuilderSetDelimiterStringRejectsEmpty() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter("");
            }
        });
    }

    @Test
    void testBuilderSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter("\r");
            }
        });
    }

    @Test
    void testBuilderMultiCharDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("||", format.getDelimiterString());
    }

    @Test
    void testBuilderSetQuoteNull() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testBuilderSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setQuote('\n');
            }
        });
    }

    @Test
    void testBuilderSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setEscape('\r');
            }
        });
    }

    @Test
    void testBuilderSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker('\n');
            }
        });
    }

    @Test
    void testBuilderSetHeaderCopiesArray() {
        final String[] headers = {"a", "b"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(headers).get();
        headers[0] = "changed";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderReturnsCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] h1 = format.getHeader();
        h1[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testBuilderSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertEquals(new String[] {"Name", "Email", "Phone"}.length, format.getHeader().length);
        assertEquals("Name", format.getHeader()[0]);
        assertEquals("Phone", format.getHeader()[2]);
    }

    @Test
    void testBuilderSetHeaderFromNullEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testBuilderSetHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("line1", "line2").get();
        assertEquals(2, format.getHeaderComments().length);
        assertEquals("line1", format.getHeaderComments()[0]);
    }

    @Test
    void testBuilderSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertEquals(5, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5));
        assertFalse(format.useRow(6));
    }

    @Test
    void testDefaultMaxRowsMeansNoLimit() {
        assertEquals(0, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        assertTrue(CSVFormat.DEFAULT.useRow(1000000));
    }

    @Test
    void testBuilderSetNullStringAlsoSetsQuotedNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testBuilderSetTrailingDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    void testBuilderSetTrim() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertTrue(format.getTrim());
    }

    @Test
    void testBuilderSetAutoFlush() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        assertTrue(format.getAutoFlush());
    }

    @Test
    void testBuilderSetAllowMissingColumnNames() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).get();
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    void testBuilderSetLenientEofAndTrailingData() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).setTrailingData(true).get();
        assertTrue(format.getLenientEof());
        assertTrue(format.getTrailingData());
    }

    @Test
    void testBuilderSetSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setSkipHeaderRecord(true).get();
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testBuilderSetIgnoreHeaderCaseAndSurroundingSpaces() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreHeaderCase(true).setIgnoreSurroundingSpaces(true).get();
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testBuilderCreateFromExistingFormatCopiesSettings() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("N/A").get();
        final CSVFormat.Builder builder = CSVFormat.Builder.create(source);
        final CSVFormat copy = builder.get();
        assertEquals(source, copy);
    }

    @Test
    void testDeprecatedBuildEqualsGet() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter('|');
        assertEquals(builder.get(), builder.build());
    }

    // --- Duplicate header mode / validate ---

    @Test
    void testDuplicateHeaderAllowedByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "a").get();
        assertEquals(2, format.getHeader().length);
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testDuplicateHeaderDisallowedThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testDuplicateEmptyHeadersAllowedWithAllowEmptyMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "").get();
        assertEquals(2, format.getHeader().length);
    }

    @Test
    void testDuplicateNonEmptyHeadersDisallowedWithAllowEmptyMode() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("x", "x");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testQuoteCharacterSameAsDelimiterThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';').setQuote(';');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testEscapeCharacterSameAsDelimiterThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';').setEscape(';');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';').setCommentMarker(';');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testQuoteCharacterSameAsCommentMarkerThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testEscapeCharacterSameAsCommentMarkerThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    // --- equals / hashCode ---

    @Test
    void testEqualsSameInstance() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    void testEqualsDistinctEquivalentFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
    }

    @Test
    void testCopyProducesEqualButDistinctInstance() {
        final CSVFormat copy = CSVFormat.copy(CSVFormat.DEFAULT);
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @Test
    void testCopyOfNullIsNull() {
        assertNull(CSVFormat.copy(null));
    }

    // --- toString ---

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringContainsHeaderWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String str = format.toString();
        assertTrue(str.contains("Header:"));
        assertTrue(str.contains("a"));
    }

    // --- format(Object...) ---

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatValueNeedingQuotes() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testFormatNoRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator(null).get();
        final String result = format.format("x", "y");
        assertEquals("x,y", result);
    }

    // --- print / printRecord / println ---

    @Test
    void testPrintRecordWritesDelimitedValuesAndSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b", "c");
        assertEquals("a,b,c\r\n", writer.toString());
    }

    @Test
    void testPrintlnWritesOnlyRecordSeparatorByDefault() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterWhenSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintNullValueWithoutNullString() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueWithNullStringSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setTrim(true).get();
        final StringWriter writer = new StringWriter();
        format.print("  hello  ", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintAppendableCreatesPrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print((Appendable) writer);
        printer.printRecord("x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    // --- parse ---

    @Test
    void testParseReturnsRecordsWithExpectedValues() throws IOException {
        final Reader reader = new StringReader("a,b,c\r\n1,2,3\r\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        try {
            final java.util.List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    // --- deprecated with* methods delegate correctly ---

    @Test
    void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testWithHeaderVarargs() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertEquals(2, format.getHeader().length);
    }

    @Test
    void testWithFirstRecordAsHeaderSetsSkipAndEmptyHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testWithAllowDuplicateHeaderNamesTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames();
        assertTrue(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithAllowDuplicateHeaderNamesFalse() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(format.getAllowDuplicateHeaderNames());
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
    }

    @Test
    void testWithQuoteCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
    }

    @Test
    void testWithQuoteNullCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
    }

    @Test
    void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testWithTrailingDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    void testWithTrim() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrim();
        assertTrue(format.getTrim());
    }

    @Test
    void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @Test
    void testWithIgnoreEmptyLinesFalse() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testWithSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord();
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testWithEscapeCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
    }

    @Test
    void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("c1");
        assertEquals("c1", format.getHeaderComments()[0]);
    }

    @Test
    void testWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testWithCommentMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
    }

    @Test
    void testWithAllowMissingColumnNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames();
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    void testWithIgnoreHeaderCase() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase();
        assertTrue(format.getIgnoreHeaderCase());
    }

    @Test
    void testWithIgnoreSurroundingSpaces() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces();
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testWithAutoFlush() {
        final CSVFormat format = CSVFormat.DEFAULT.withAutoFlush(true);
        assertTrue(format.getAutoFlush());
    }

    @Test
    void testWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @Test
    void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(HeaderEnum.class);
        assertEquals(3, format.getHeader().length);
    }

    // --- builder() round trip ---

    @Test
    void testBuilderRoundTripPreservesEquality() {
        final CSVFormat format = CSVFormat.EXCEL;
        final CSVFormat rebuilt = format.builder().get();
        assertEquals(format, rebuilt);
    }
}
