/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
public class DateUtilsAgentTest {

    private static Calendar utcCalendar() {
        final Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        return c;
    }

    private static Calendar defaultCalendar() {
        final Calendar c = Calendar.getInstance(TimeZone.getDefault());
        c.clear();
        return c;
    }

    private static Date defaultDate(final int year, final int month, final int day, final int hour,
        final int minute, final int second, final int millis) {
        final Calendar c = defaultCalendar();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c.getTime();
    }

    // --- constants ---

    @Test
    public void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    // --- add* ---

    @Test
    public void testAddDays() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 2);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(30, c.get(Calendar.DATE));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        // Original unchanged.
        final Calendar orig = defaultCalendar();
        orig.setTime(date);
        assertEquals(28, orig.get(Calendar.DATE));
    }

    @Test
    public void testAddDaysNegativeAmount() {
        final Date date = defaultDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        final Date result = DateUtils.addDays(date, -1);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(28, c.get(Calendar.DATE));
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
    }

    @Test
    public void testAddDaysNull() {
        try {
            DateUtils.addDays(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddHours() {
        final Date date = defaultDate(2002, Calendar.JANUARY, 1, 23, 0, 0, 0);
        final Date result = DateUtils.addHours(date, 2);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(2, c.get(Calendar.DATE));
    }

    @Test
    public void testAddHoursNull() {
        try {
            DateUtils.addHours(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddMilliseconds() {
        final Date date = defaultDate(2002, Calendar.JANUARY, 1, 0, 0, 0, 998);
        final Date result = DateUtils.addMilliseconds(date, 5);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(3, c.get(Calendar.MILLISECOND));
        assertEquals(1, c.get(Calendar.SECOND));
    }

    @Test
    public void testAddMillisecondsNull() {
        try {
            DateUtils.addMilliseconds(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddMinutes() {
        final Date date = defaultDate(2002, Calendar.JANUARY, 1, 0, 59, 0, 0);
        final Date result = DateUtils.addMinutes(date, 2);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.MINUTE));
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testAddMinutesNull() {
        try {
            DateUtils.addMinutes(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddMonths() {
        final Date date = defaultDate(2002, Calendar.DECEMBER, 15, 0, 0, 0, 0);
        final Date result = DateUtils.addMonths(date, 1);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(2003, c.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, c.get(Calendar.MONTH));
    }

    @Test
    public void testAddMonthsNull() {
        try {
            DateUtils.addMonths(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddSeconds() {
        final Date date = defaultDate(2002, Calendar.JANUARY, 1, 0, 0, 59, 0);
        final Date result = DateUtils.addSeconds(date, 2);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.SECOND));
        assertEquals(1, c.get(Calendar.MINUTE));
    }

    @Test
    public void testAddSecondsNull() {
        try {
            DateUtils.addSeconds(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddWeeks() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date result = DateUtils.addWeeks(date, 1);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(4, c.get(Calendar.DATE));
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
    }

    @Test
    public void testAddWeeksNull() {
        try {
            DateUtils.addWeeks(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddYears() {
        // Leap day pins to the last valid day of February on a non-leap year.
        final Date date = defaultDate(2008, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        final Date result = DateUtils.addYears(date, 1);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(2009, c.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DATE));
    }

    @Test
    public void testAddYearsNull() {
        try {
            DateUtils.addYears(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- ceiling ---

    @Test
    public void testCeilingCalendarHour() {
        final Calendar c = utcCalendar();
        c.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        c.set(Calendar.MILLISECOND, 231);
        final Calendar result = DateUtils.ceiling(c, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
        assertEquals(0, result.get(Calendar.SECOND));
        assertEquals(0, result.get(Calendar.MILLISECOND));
        assertEquals(28, result.get(Calendar.DATE));
    }

    @Test
    public void testCeilingCalendarMonth() {
        final Calendar c = utcCalendar();
        c.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        final Calendar result = DateUtils.ceiling(c, Calendar.MONTH);
        assertEquals(Calendar.APRIL, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DATE));
        assertEquals(0, result.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testCeilingCalendarNull() {
        try {
            DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testCeilingDateNull() {
        try {
            DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testCeilingObjectNull() {
        try {
            DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testCeilingObjectInvalidType() {
        try {
            DateUtils.ceiling((Object) "not a date", Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testCeilingObjectWithDateAndCalendar() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date fromDate = DateUtils.ceiling((Object) date, Calendar.HOUR_OF_DAY);
        final Calendar c = defaultCalendar();
        c.setTime(date);
        final Date fromCalendar = DateUtils.ceiling((Object) c, Calendar.HOUR_OF_DAY);
        assertEquals(fromDate, fromCalendar);
    }

    @Test
    public void testCeilingYearTooLarge() {
        final Calendar c = utcCalendar();
        c.set(280000001, Calendar.JANUARY, 1, 0, 0, 0);
        try {
            DateUtils.ceiling(c, Calendar.YEAR);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    // --- getFragmentInDays / Hours / Minutes / Seconds / Milliseconds ---

    @Test
    public void testGetFragmentInDaysMonth() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 28);
        assertEquals(28, DateUtils.getFragmentInDays(c, Calendar.MONTH));
    }

    @Test
    public void testGetFragmentInDaysYear() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.FEBRUARY, 28);
        assertEquals(59, DateUtils.getFragmentInDays(c, Calendar.YEAR));
    }

    @Test
    public void testGetFragmentInDaysMillisecondAlwaysZero() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 28);
        assertEquals(0, DateUtils.getFragmentInDays(c, Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInDaysDateOverload() {
        final Date date = defaultDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(date, Calendar.MONTH));
    }

    @Test
    public void testGetFragmentInHours() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        c.set(Calendar.MILLISECOND, 538);
        assertEquals(127, DateUtils.getFragmentInHours(c, Calendar.MONTH));
        assertEquals(7, DateUtils.getFragmentInHours(c, Calendar.DAY_OF_YEAR));
    }

    @Test
    public void testGetFragmentInMinutes() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        c.set(Calendar.MILLISECOND, 538);
        // Days are converted to minutes too, not just the hour/minute-of-day components.
        assertEquals(5 * 24 * 60 + 7 * 60 + 15, DateUtils.getFragmentInMinutes(c, Calendar.MONTH));
    }

    @Test
    public void testGetFragmentInSeconds() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        c.set(Calendar.MILLISECOND, 538);
        assertEquals(26110, DateUtils.getFragmentInSeconds(c, Calendar.DAY_OF_YEAR));
    }

    @Test
    public void testGetFragmentInMilliseconds() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        c.set(Calendar.MILLISECOND, 538);
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(c, Calendar.MINUTE));
    }

    @Test
    public void testGetFragmentUnsupportedField() {
        final Calendar c = utcCalendar();
        c.set(2008, Calendar.JANUARY, 6);
        try {
            DateUtils.getFragmentInDays(c, Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testGetFragmentNullCalendar() {
        try {
            DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetFragmentNullDate() {
        try {
            DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- isSameDay / isSameInstant / isSameLocalTime ---

    @Test
    public void testIsSameDayTrue() {
        final Date d1 = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = defaultDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    @Test
    public void testIsSameDayFalse() {
        final Date d1 = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = defaultDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(d1, d2));
    }

    @Test
    public void testIsSameDayCalendarNull() {
        final Calendar c = defaultCalendar();
        try {
            DateUtils.isSameDay(c, null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.isSameDay((Calendar) null, c);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testIsSameInstantTrue() {
        final Date d1 = new Date(123456789L);
        final Date d2 = new Date(123456789L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    public void testIsSameInstantFalse() {
        final Date d1 = new Date(123456789L);
        final Date d2 = new Date(123456790L);
        assertFalse(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    public void testIsSameInstantNull() {
        final Date d = new Date();
        try {
            DateUtils.isSameInstant(null, d);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.isSameInstant(d, null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testIsSameLocalTimeTrue() {
        final Calendar c1 = defaultCalendar();
        c1.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        c1.set(Calendar.MILLISECOND, 231);
        final Calendar c2 = (Calendar) c1.clone();
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeFalse() {
        final Calendar c1 = defaultCalendar();
        c1.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        final Calendar c2 = defaultCalendar();
        c2.set(2002, Calendar.MARCH, 28, 13, 45, 2);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeNull() {
        final Calendar c = defaultCalendar();
        try {
            DateUtils.isSameLocalTime(c, null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- iterator ---

    @Test
    public void testIteratorRangeMonthSunday() {
        final Calendar focus = utcCalendar();
        focus.set(2002, Calendar.JULY, 4);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            last = it.next();
            if (first == null) {
                first = last;
            }
            count++;
        }
        assertEquals(35, count);
        assertNotNull(first);
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DATE));
        assertEquals(2002, last.get(Calendar.YEAR));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DATE));
    }

    @Test
    public void testIteratorExhaustedThrowsNoSuchElement() {
        final Calendar focus = utcCalendar();
        focus.set(2002, Calendar.JULY, 4);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() {
        final Calendar focus = utcCalendar();
        focus.set(2002, Calendar.JULY, 4);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorInvalidRangeStyle() {
        final Calendar focus = utcCalendar();
        focus.set(2002, Calendar.JULY, 4);
        try {
            DateUtils.iterator(focus, 999);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorCalendarNull() {
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorDateOverload() {
        final Date focus = defaultDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    @Test
    public void testIteratorObjectOverloadInvalidType() {
        try {
            DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorObjectOverloadNull() {
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- parseDate / parseDateStrictly ---

    @Test
    public void testParseDateSuccess() throws ParseException {
        final Date result = DateUtils.parseDate("2002-03-28", "yyyy-MM-dd");
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DATE));
    }

    @Test
    public void testParseDateTriesMultiplePatterns() throws ParseException {
        final Date result = DateUtils.parseDate("28.03.2002", "yyyy-MM-dd", "dd.MM.yyyy");
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DATE));
    }

    @Test
    public void testParseDateNoMatchingPattern() {
        try {
            DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            fail("Expected ParseException");
        } catch (final ParseException expected) {
            // expected
        }
    }

    @Test
    public void testParseDateEmptyPatterns() {
        try {
            DateUtils.parseDate("2002-03-28");
            fail("Expected ParseException");
        } catch (final ParseException expected) {
            // expected
        }
    }

    @Test
    public void testParseDateNullString() {
        try {
            DateUtils.parseDate((String) null, "yyyy-MM-dd");
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final ParseException e) {
            fail("Expected NullPointerException, got " + e);
        }
    }

    @Test
    public void testParseDateNullPatterns() {
        try {
            DateUtils.parseDate("2002-03-28", (String[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final ParseException e) {
            fail("Expected NullPointerException, got " + e);
        }
    }

    @Test
    public void testParseDateLenientAllowsOverflow() throws ParseException {
        // "February 942" overflows the day-of-month field; lenient parsing accepts it.
        final Date result = DateUtils.parseDate("February 942, 1996", Locale.US, "MMMM d, yyyy");
        assertNotNull(result);
    }

    @Test
    public void testParseDateStrictlyRejectsOverflow() {
        try {
            DateUtils.parseDateStrictly("February 942, 1996", Locale.US, "MMMM d, yyyy");
            fail("Expected ParseException");
        } catch (final ParseException expected) {
            // expected
        }
    }

    @Test
    public void testParseDateStrictlySuccess() throws ParseException {
        final Date result = DateUtils.parseDateStrictly("2002-03-28", "yyyy-MM-dd");
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(28, c.get(Calendar.DATE));
    }

    // --- round ---

    @Test
    public void testRoundCalendarHour() {
        final Calendar c = utcCalendar();
        c.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        c.set(Calendar.MILLISECOND, 231);
        final Calendar result = DateUtils.round(c, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
    }

    @Test
    public void testRoundCalendarDownward() {
        final Calendar c = utcCalendar();
        c.set(2002, Calendar.MARCH, 28, 13, 20, 0);
        final Calendar result = DateUtils.round(c, Calendar.HOUR_OF_DAY);
        assertEquals(13, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
    }

    @Test
    public void testRoundCalendarNull() {
        try {
            DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testRoundDateNull() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testRoundObjectNull() {
        try {
            DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testRoundObjectInvalidType() {
        try {
            DateUtils.round((Object) "not a date", Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testRoundYearTooLarge() {
        final Calendar c = utcCalendar();
        c.set(280000001, Calendar.JANUARY, 1, 0, 0, 0);
        try {
            DateUtils.round(c, Calendar.YEAR);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    // --- set* ---

    @Test
    public void testSetDays() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setDays(date, 15);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(15, c.get(Calendar.DATE));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
    }

    @Test
    public void testSetDaysOutOfRange() {
        final Date date = new Date();
        try {
            DateUtils.setDays(date, 0);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setDays(date, 32);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSetDaysNull() {
        try {
            DateUtils.setDays(null, 1);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testSetHours() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setHours(date, 5);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(5, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testSetHoursOutOfRange() {
        final Date date = new Date();
        try {
            DateUtils.setHours(date, 24);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setHours(date, -1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSetMilliseconds() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setMilliseconds(date, 500);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(500, c.get(Calendar.MILLISECOND));
    }

    @Test
    public void testSetMillisecondsOutOfRange() {
        final Date date = new Date();
        try {
            DateUtils.setMilliseconds(date, 1000);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSetMinutes() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setMinutes(date, 10);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(10, c.get(Calendar.MINUTE));
    }

    @Test
    public void testSetMinutesOutOfRange() {
        final Date date = new Date();
        try {
            DateUtils.setMinutes(date, 60);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSetMonths() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setMonths(date, 0);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(Calendar.JANUARY, c.get(Calendar.MONTH));
    }

    @Test
    public void testSetMonthsOutOfRange() {
        final Date date = new Date();
        try {
            DateUtils.setMonths(date, 12);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSetSeconds() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setSeconds(date, 30);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(30, c.get(Calendar.SECOND));
    }

    @Test
    public void testSetSecondsOutOfRange() {
        final Date date = new Date();
        try {
            DateUtils.setSeconds(date, 60);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSetYears() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setYears(date, 1999);
        final Calendar c = defaultCalendar();
        c.setTime(result);
        assertEquals(1999, c.get(Calendar.YEAR));
    }

    @Test
    public void testSetYearsNull() {
        try {
            DateUtils.setYears(null, 1999);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- toCalendar ---

    @Test
    public void testToCalendar() {
        final Date date = new Date();
        final Calendar c = DateUtils.toCalendar(date);
        assertEquals(date, c.getTime());
    }

    @Test
    public void testToCalendarNullDate() {
        try {
            DateUtils.toCalendar(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testToCalendarWithTimeZone() {
        final Date date = new Date();
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar c = DateUtils.toCalendar(date, tz);
        assertEquals(date, c.getTime());
        assertEquals(tz, c.getTimeZone());
    }

    @Test
    public void testToCalendarWithTimeZoneNullDate() {
        try {
            DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testToCalendarWithTimeZoneNullTimeZone() {
        try {
            DateUtils.toCalendar(new Date(), null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- toLocalDateTime / toOffsetDateTime / toZonedDateTime ---

    @Test
    public void testToLocalDateTime() {
        final Date date = defaultDate(2002, Calendar.MARCH, 28, 13, 45, 1, 0);
        final LocalDateTime defaultLdt = DateUtils.toLocalDateTime(date);
        final LocalDateTime utcLdt = DateUtils.toLocalDateTime(date, TimeZone.getTimeZone("UTC"));
        assertNotNull(defaultLdt);
        assertNotNull(utcLdt);
        // Same instant converted with the default zone equals the default-zone computation.
        assertEquals(DateUtils.toLocalDateTime(date, TimeZone.getDefault()), defaultLdt);
    }

    @Test
    public void testToOffsetDateTime() {
        final Date date = new Date();
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, tz);
        assertNotNull(odt);
        assertEquals(date.toInstant(), odt.toInstant());
        assertNotNull(DateUtils.toOffsetDateTime(date));
    }

    @Test
    public void testToZonedDateTime() {
        final Date date = new Date();
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, tz);
        assertNotNull(zdt);
        assertEquals(date.toInstant(), zdt.toInstant());
        assertNotNull(DateUtils.toZonedDateTime(date));
    }

    // --- truncate ---

    @Test
    public void testTruncateCalendarHour() {
        final Calendar c = utcCalendar();
        c.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        c.set(Calendar.MILLISECOND, 231);
        final Calendar result = DateUtils.truncate(c, Calendar.HOUR_OF_DAY);
        assertEquals(13, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
        assertEquals(0, result.get(Calendar.SECOND));
        assertEquals(0, result.get(Calendar.MILLISECOND));
    }

    @Test
    public void testTruncateCalendarMonth() {
        final Calendar c = utcCalendar();
        c.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        final Calendar result = DateUtils.truncate(c, Calendar.MONTH);
        assertEquals(Calendar.MARCH, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DATE));
        assertEquals(0, result.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncateCalendarNull() {
        try {
            DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testTruncateDateNull() {
        try {
            DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testTruncateObjectNull() {
        try {
            DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testTruncateObjectInvalidType() {
        try {
            DateUtils.truncate((Object) Integer.valueOf(1), Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testTruncateYearTooLarge() {
        final Calendar c = utcCalendar();
        c.set(280000001, Calendar.JANUARY, 1, 0, 0, 0);
        try {
            DateUtils.truncate(c, Calendar.YEAR);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    // --- truncatedCompareTo / truncatedEquals ---

    @Test
    public void testTruncatedCompareToAndEqualsCalendars() {
        final Calendar c1 = utcCalendar();
        c1.set(2002, Calendar.MARCH, 28, 9, 0, 0);
        final Calendar c2 = utcCalendar();
        c2.set(2002, Calendar.MARCH, 28, 23, 59, 59);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));

        final Calendar c3 = utcCalendar();
        c3.set(2002, Calendar.MARCH, 29, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(c1, c3, Calendar.DATE) < 0);
        assertFalse(DateUtils.truncatedEquals(c1, c3, Calendar.DATE));
    }

    @Test
    public void testTruncatedCompareToAndEqualsDates() {
        final Date d1 = defaultDate(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        final Date d2 = defaultDate(2002, Calendar.MARCH, 28, 23, 59, 59, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));

        final Date d3 = defaultDate(2002, Calendar.MARCH, 27, 23, 59, 59, 0);
        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.DATE) > 0);
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DATE));
    }

    // --- constructor ---

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new DateUtils());
    }
}
