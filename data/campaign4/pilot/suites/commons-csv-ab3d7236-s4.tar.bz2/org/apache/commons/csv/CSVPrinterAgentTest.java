package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVPrinter} based solely on its documented contract.
 */
public class CSVPrinterAgentTest {

    // ---------------------------------------------------------------
    // Test fixtures
    // ---------------------------------------------------------------

    private static final class RecordingAppendable implements Appendable, Flushable, Closeable {
        private final StringBuilder sb = new StringBuilder();
        private int flushCount = 0;
        private int closeCount = 0;
        private final List<String> events = new ArrayList<String>();

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void flush() throws IOException {
            flushCount++;
            events.add("flush");
        }

        public void close() throws IOException {
            closeCount++;
            events.add("close");
        }

        public String toString() {
            return sb.toString();
        }
    }

    private static final class ThrowingAppendable implements Appendable {
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }

        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }
    }

    private static Object defaultValueFor(final Class<?> type) {
        if (!type.isPrimitive()) {
            return null;
        }
        if (type == boolean.class) {
            return Boolean.FALSE;
        }
        if (type == int.class) {
            return Integer.valueOf(0);
        }
        if (type == long.class) {
            return Long.valueOf(0L);
        }
        if (type == short.class) {
            return Short.valueOf((short) 0);
        }
        if (type == byte.class) {
            return Byte.valueOf((byte) 0);
        }
        if (type == char.class) {
            return Character.valueOf('\u0000');
        }
        if (type == double.class) {
            return Double.valueOf(0d);
        }
        if (type == float.class) {
            return Float.valueOf(0f);
        }
        return null;
    }

    private static ResultSetMetaData newMetaDataProxy(final int columnCount, final String[] labels) {
        final InvocationHandler handler = new InvocationHandler() {
            public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
                final String name = method.getName();
                if ("getColumnCount".equals(name)) {
                    return Integer.valueOf(columnCount);
                }
                if ("getColumnLabel".equals(name) || "getColumnName".equals(name)) {
                    final int idx = ((Integer) args[0]).intValue();
                    return labels[idx - 1];
                }
                if ("equals".equals(name)) {
                    return Boolean.valueOf(args.length > 0 && proxy == args[0]);
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(System.identityHashCode(proxy));
                }
                if ("toString".equals(name)) {
                    return "ResultSetMetaDataProxy";
                }
                return defaultValueFor(method.getReturnType());
            }
        };
        return (ResultSetMetaData) Proxy.newProxyInstance(CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSetMetaData.class }, handler);
    }

    private static ResultSet newResultSetProxy(final ResultSetMetaData metaData, final String[][] rows) {
        final int[] rowIndex = { -1 };
        final InvocationHandler handler = new InvocationHandler() {
            public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
                final String name = method.getName();
                if ("next".equals(name)) {
                    rowIndex[0]++;
                    return Boolean.valueOf(rowIndex[0] < rows.length);
                }
                if ("getMetaData".equals(name)) {
                    return metaData;
                }
                if ("getObject".equals(name) && args != null && args.length == 1 && args[0] instanceof Integer) {
                    final int col = ((Integer) args[0]).intValue();
                    return rows[rowIndex[0]][col - 1];
                }
                if ("close".equals(name)) {
                    return null;
                }
                if ("equals".equals(name)) {
                    return Boolean.valueOf(args.length > 0 && proxy == args[0]);
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(System.identityHashCode(proxy));
                }
                if ("toString".equals(name)) {
                    return "ResultSetProxy";
                }
                return defaultValueFor(method.getReturnType());
            }
        };
        return (ResultSet) Proxy.newProxyInstance(CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSet.class }, handler);
    }

    private static ResultSet newThrowingMetaDataResultSetProxy() {
        final InvocationHandler handler = new InvocationHandler() {
            public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
                if ("getMetaData".equals(method.getName())) {
                    throw new SQLException("boom");
                }
                return defaultValueFor(method.getReturnType());
            }
        };
        return (ResultSet) Proxy.newProxyInstance(CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSet.class }, handler);
    }

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------

    @Test
    public void constructorThrowsNpeForNullAppendable() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void constructorThrowsNpeForNullFormat() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVPrinter(new StringBuilder(), null);
            }
        });
    }

    @Test
    public void constructorExposesGivenAppendableViaGetOut() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertSame(sb, printer.getOut());
    }

    @Test
    public void newPrinterHasZeroRecordCount() throws IOException {
        final CSVPrinter printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        assertEquals(0L, printer.getRecordCount());
    }

    // ---------------------------------------------------------------
    // print(Object)
    // ---------------------------------------------------------------

    @Test
    public void printSingleValueWritesValueOnly() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("hello");
        assertEquals("hello", sb.toString());
    }

    @Test
    public void printSecondValueOnSameLineInsertsDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void printAfterPrintlnStartsNewLineWithoutLeadingDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        printer.println();
        printer.print("c");
        assertEquals("a,b\r\nc", sb.toString());
    }

    @Test
    public void printValueWithDelimiterIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void printValueWithQuoteCharacterIsEscapedByDoubling() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sb.toString());
    }

    @Test
    public void printValueWithEmbeddedNewlineIsQuotedPreservingNewline() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("line1\nline2");
        assertEquals("\"line1\nline2\"", sb.toString());
    }

    // ---------------------------------------------------------------
    // println()
    // ---------------------------------------------------------------

    @Test
    public void printlnWritesOnlyRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        assertEquals("\r\n", sb.toString());
    }

    // ---------------------------------------------------------------
    // printComment(String)
    // ---------------------------------------------------------------

    @Test
    public void printCommentDoesNothingWhenFormatHasNoCommentMarker() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sb.toString());
    }

    @Test
    public void printCommentWritesMarkerAndSpaceWhenEnabled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sb.toString());
    }

    @Test
    public void printCommentSplitsMultilineCommentAcrossPrefixedLines() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    public void printCommentStartsOnNewLineWhenCalledMidRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("a");
        printer.printComment("c");
        assertEquals("a\r\n# c\r\n", sb.toString());
    }

    // ---------------------------------------------------------------
    // printRecord(...)
    // ---------------------------------------------------------------

    @Test
    public void printRecordObjectArrayWritesDelimitedValuesAndSeparatorAndIncrementsCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordIterableWritesDelimitedValuesAndIncrementsCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("x", "y"));
        assertEquals("x,y\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordStreamWritesDelimitedValuesAndIncrementsCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Stream.of("a", "b", "c"));
        assertEquals("a,b,c\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordWithNullElementStillPrintsAllFields() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", null, "c");
        final String out = sb.toString();
        assertTrue(out.startsWith("a,"));
        assertTrue(out.endsWith(",c\r\n"));
        int commaCount = 0;
        for (int i = 0; i < out.length(); i++) {
            if (out.charAt(i) == ',') {
                commaCount++;
            }
        }
        assertEquals(2, commaCount);
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordEmptyArrayWritesBlankRecordAndIncrementsCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        assertEquals("\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordNullIterableThrowsNpe() {
        final CSVPrinter printer;
        try {
            printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        } catch (final IOException e) {
            throw new AssertionError(e);
        }
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printRecord((Iterable<?>) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // printRecords(...)
    // ---------------------------------------------------------------

    @Test
    public void printRecordsSimpleObjectArrayWrittenAsSingleRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords("x", "y", "z");
        assertEquals("x,y,z\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordsNestedArraysWrittenAsMultipleRecordsAndCountsEach() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final Object[] data = new Object[] { new String[] { "A", "B" }, new String[] { "1", "2" } };
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void printRecordsSimpleIterableWrittenAsSingleRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> data = Arrays.asList("x", "y", "z");
        printer.printRecords(data);
        assertEquals("x,y,z\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordsNestedIterableWrittenAsMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B", "C" });
        data.add(new String[] { "1", "2", "3" });
        printer.printRecords(data);
        assertEquals("A,B,C\r\n1,2,3\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void printRecordsStreamOfSimpleValuesWrittenAsSingleRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Stream.of("p", "q"));
        assertEquals("p,q\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    public void printRecordsStreamOfNestedArraysWrittenAsMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Stream.of(new String[] { "A", "B" }, new String[] { "1", "2" }));
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void printRecordsNullIterableThrowsNpe() {
        final CSVPrinter printer;
        try {
            printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        } catch (final IOException e) {
            throw new AssertionError(e);
        }
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printRecords((Iterable<?>) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // printHeaders(ResultSet) / printRecords(ResultSet[, boolean])
    // ---------------------------------------------------------------

    @Test
    public void printHeadersWritesColumnLabelsAsOneLineWithoutIncrementingRecordCount() throws IOException, SQLException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final ResultSetMetaData metaData = newMetaDataProxy(2, new String[] { "H1", "H2" });
        final ResultSet resultSet = newResultSetProxy(metaData, new String[0][]);
        printer.printHeaders(resultSet);
        assertEquals("H1,H2\r\n", sb.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    public void printRecordsResultSetWithHeaderPrintsHeaderThenRowsAndCountsOnlyRows() throws IOException, SQLException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final ResultSetMetaData metaData = newMetaDataProxy(2, new String[] { "H1", "H2" });
        final ResultSet resultSet = newResultSetProxy(metaData,
                new String[][] { { "r1c1", "r1c2" }, { "r2c1", "r2c2" } });
        printer.printRecords(resultSet);
        assertEquals("H1,H2\r\nr1c1,r1c2\r\nr2c1,r2c2\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void printRecordsResultSetWithoutHeaderSkipsHeaderRow() throws IOException, SQLException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final ResultSetMetaData metaData = newMetaDataProxy(2, new String[] { "H1", "H2" });
        final ResultSet resultSet = newResultSetProxy(metaData,
                new String[][] { { "r1c1", "r1c2" }, { "r2c1", "r2c2" } });
        printer.printRecords(resultSet, false);
        assertEquals("r1c1,r1c2\r\nr2c1,r2c2\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    public void printRecordsResultSetPropagatesSqlException() {
        final CSVPrinter printer;
        try {
            printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        } catch (final IOException e) {
            throw new AssertionError(e);
        }
        final ResultSet resultSet = newThrowingMetaDataResultSetProxy();
        assertThrows(SQLException.class, new Executable() {
            public void execute() throws Throwable {
                printer.printRecords(resultSet);
            }
        });
    }

    // ---------------------------------------------------------------
    // flush() / close() / close(boolean)
    // ---------------------------------------------------------------

    @Test
    public void flushDelegatesToFlushableAppendable() throws IOException {
        final RecordingAppendable rec = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(rec, CSVFormat.DEFAULT);
        printer.flush();
        assertEquals(1, rec.flushCount);
    }

    @Test
    public void flushOnNonFlushableAppendableIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.flush();
        assertEquals("a", sb.toString());
    }

    @Test
    public void closeNoArgClosesUnderlyingCloseableAppendable() throws IOException {
        final RecordingAppendable rec = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(rec, CSVFormat.DEFAULT);
        printer.close();
        assertEquals(1, rec.closeCount);
    }

    @Test
    public void closeFalseDoesNotFlushBeforeClosing() throws IOException {
        final RecordingAppendable rec = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(rec, CSVFormat.DEFAULT);
        printer.close(false);
        assertEquals(0, rec.flushCount);
        assertEquals(1, rec.closeCount);
    }

    @Test
    public void closeTrueFlushesBeforeClosing() throws IOException {
        final RecordingAppendable rec = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(rec, CSVFormat.DEFAULT);
        printer.close(true);
        assertEquals(1, rec.flushCount);
        assertEquals(1, rec.closeCount);
        assertEquals(Arrays.asList("flush", "close"), rec.events);
    }

    @Test
    public void ioExceptionFromAppendablePropagatesFromPrint() throws IOException {
        final ThrowingAppendable ta = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertThrows(IOException.class, new Executable() {
            public void execute() throws Throwable {
                printer.print("x");
            }
        });
    }
}
