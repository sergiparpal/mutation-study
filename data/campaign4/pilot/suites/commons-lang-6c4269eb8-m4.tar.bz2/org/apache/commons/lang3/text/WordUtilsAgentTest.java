/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link WordUtils}.
 */
public class WordUtilsAgentTest {

    // -----------------------------------------------------------------------
    // capitalize(String)
    // -----------------------------------------------------------------------

    @Test
    public void testCapitalize_null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    public void testCapitalize_singleWord() {
        assertEquals("Word", WordUtils.capitalize("word"));
    }

    @Test
    public void testCapitalize_withDelimiters_null() {
        assertNull(WordUtils.capitalize(null, ' ', '.'));
    }

    @Test
    public void testCapitalize_withDelimiters_empty() {
        assertEquals("", WordUtils.capitalize("", ' ', '.'));
    }

    @Test
    public void testCapitalize_withEmptyDelimiterArrayReturnsUnchanged() {
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalize(str, new char[0]));
    }

    @Test
    public void testCapitalize_withNullDelimitersUsesWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalize_withCustomDelimiters() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    // -----------------------------------------------------------------------
    // capitalizeFully(String)
    // -----------------------------------------------------------------------

    @Test
    public void testCapitalizeFully_null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    @Test
    public void testCapitalizeFully_withDelimiters_null() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
    }

    @Test
    public void testCapitalizeFully_withDelimiters_empty() {
        assertEquals("", WordUtils.capitalizeFully("", '.'));
    }

    @Test
    public void testCapitalizeFully_withNullDelimitersUsesWhitespace() {
        // null delimiters fall back to whitespace, unlike an empty delimiter array
        assertEquals("I Am.fine", WordUtils.capitalizeFully("i aM.fine", (char[]) null));
    }

    @Test
    public void testCapitalizeFully_withEmptyDelimiterArrayReturnsUnchanged() {
        final String str = "i aM.fine";
        assertSame(str, WordUtils.capitalizeFully(str, new char[0]));
    }

    @Test
    public void testCapitalizeFully_withCustomDelimiters() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    // -----------------------------------------------------------------------
    // containsAllWords(CharSequence, CharSequence...)
    // -----------------------------------------------------------------------

    @Test
    public void testContainsAllWords_nullWord() {
        assertTrue(!WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_emptyWord() {
        assertTrue(!WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_nullWordsArray() {
        assertTrue(!WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_emptyWordsArray() {
        assertTrue(!WordUtils.containsAllWords("abc def", new CharSequence[0]));
    }

    @Test
    public void testContainsAllWords_blankWordInArray() {
        assertTrue(!WordUtils.containsAllWords("abc def", "abc", " "));
    }

    @Test
    public void testContainsAllWords_substringButNotWord() {
        assertTrue(!WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_allWordsFoundAnyOrder() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    public void testContainsAllWords_missingWord() {
        assertTrue(!WordUtils.containsAllWords("abc def", "def", "xyz"));
    }

    // -----------------------------------------------------------------------
    // initials(String)
    // -----------------------------------------------------------------------

    @Test
    public void testInitials_null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_withPunctuation() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    @Test
    public void testInitials_withDelimiters_null() {
        assertNull(WordUtils.initials(null, ' ', '.'));
    }

    @Test
    public void testInitials_withDelimiters_empty() {
        assertEquals("", WordUtils.initials("", ' ', '.'));
    }

    @Test
    public void testInitials_withNullDelimitersUsesWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitials_withEmptyDelimiterArray() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    @Test
    public void testInitials_withCustomDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testInitials_surrogatePairPreserved() {
        // high surrogate 0xD800 + low surrogate 0xDC00 forms one supplementary code point
        final String str = "𐀀 abc";
        final String result = WordUtils.initials(str);
        assertEquals(3, result.length());
        assertEquals("𐀀a", result);
    }

    // -----------------------------------------------------------------------
    // swapCase(String)
    // -----------------------------------------------------------------------

    @Test
    public void testSwapCase_null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testSwapCase_nonAlphaUnchanged() {
        assertEquals("123 !@#", WordUtils.swapCase("123 !@#"));
    }

    // -----------------------------------------------------------------------
    // uncapitalize(String)
    // -----------------------------------------------------------------------

    @Test
    public void testUncapitalize_null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    @Test
    public void testUncapitalize_withDelimiters_null() {
        assertNull(WordUtils.uncapitalize(null, '.'));
    }

    @Test
    public void testUncapitalize_withDelimiters_empty() {
        assertEquals("", WordUtils.uncapitalize("", '.'));
    }

    @Test
    public void testUncapitalize_withNullDelimitersUsesWhitespace() {
        // null delimiters fall back to whitespace, unlike an empty delimiter array
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    public void testUncapitalize_withEmptyDelimiterArrayReturnsUnchanged() {
        final String str = "I AM.FINE";
        assertSame(str, WordUtils.uncapitalize(str, new char[0]));
    }

    @Test
    public void testUncapitalize_withCustomDelimiters() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    // -----------------------------------------------------------------------
    // wrap(String, int)
    // -----------------------------------------------------------------------

    @Test
    public void testWrap_null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap_empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_shortStringUnchanged() {
        assertEquals("short", WordUtils.wrap("short", 20));
    }

    @Test
    public void testWrap_wrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("ab cd", 0);
        assertNotNull(result);
        assertTrue(result.indexOf(System.lineSeparator()) >= 0);
    }

    // -----------------------------------------------------------------------
    // wrap(String, int, String, boolean)
    // -----------------------------------------------------------------------

    @Test
    public void testWrap_withNewLineStr_null() {
        assertNull(WordUtils.wrap(null, 20, "\n", false));
    }

    @Test
    public void testWrap_withNewLineStr_empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", false));
    }

    @Test
    public void testWrap_withCustomNewLineStr() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    public void testWrap_withNullNewLineUsesSystemLineSeparator() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, null, false));
    }

    @Test
    public void testWrap_longWordNotWrappedWhenWrapLongWordsFalse() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    public void testWrap_longWordWrappedWhenWrapLongWordsTrue() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    // -----------------------------------------------------------------------
    // wrap(String, int, String, boolean, String)
    // -----------------------------------------------------------------------

    @Test
    public void testWrap_withWrapOn_null() {
        assertNull(WordUtils.wrap(null, 20, "\n", false, " "));
    }

    @Test
    public void testWrap_withWrapOn_empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", false, " "));
    }

    @Test
    public void testWrap_withBlankWrapOnDefaultsToSpace() {
        final String input = "abc def ghi";
        final String resultBlankWrapOn = WordUtils.wrap(input, 3, "\n", false, "");
        final String resultSpaceWrapOn = WordUtils.wrap(input, 3, "\n", false, " ");
        assertEquals(resultSpaceWrapOn, resultBlankWrapOn);
    }

    @Test
    public void testWrap_withCustomWrapOnRegex() {
        final String input = "flammable/inflammable";
        final String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    public void testWrap_wrapOnRegexWithNoMatchAndWrapLongWords() {
        final String input = "abcdefghij";
        final String result = WordUtils.wrap(input, 3, "\n", true, " ");
        assertEquals("abc\ndef\nghi\nj", result);
    }

    // -----------------------------------------------------------------------
    // constructor
    // -----------------------------------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new WordUtils());
    }
}
