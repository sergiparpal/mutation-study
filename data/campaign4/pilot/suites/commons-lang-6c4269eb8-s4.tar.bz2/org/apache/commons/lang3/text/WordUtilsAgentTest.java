package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SuppressWarnings("deprecation")
public class WordUtilsAgentTest {

    private static final String SEP = System.getProperty("line.separator");

    // ---- constructor ----

    @Test
    public void testConstructorIsPublicallyUsable() {
        WordUtils instance = new WordUtils();
        assertNotNull(instance);
    }

    // ---- capitalize(String) ----

    @Test
    public void testCapitalize_Null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_Empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_Basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    // ---- capitalize(String, char...) ----

    @Test
    public void testCapitalizeDelimiters_Null() {
        assertNull(WordUtils.capitalize(null, ' ', '.'));
    }

    @Test
    public void testCapitalizeDelimiters_Empty() {
        assertEquals("", WordUtils.capitalize("", ' ', '.'));
    }

    @Test
    public void testCapitalizeDelimiters_EmptyArrayLeavesStringUnchanged() {
        assertEquals("i am fine", WordUtils.capitalize("i am fine", new char[0]));
    }

    @Test
    public void testCapitalizeDelimiters_NullDelimitersTreatedAsWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalizeDelimiters_CustomDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", '.'));
    }

    // ---- capitalizeFully(String) ----

    @Test
    public void testCapitalizeFully_Null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_Empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_Basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // ---- capitalizeFully(String, char...) ----

    @Test
    public void testCapitalizeFullyDelimiters_Null() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
    }

    @Test
    public void testCapitalizeFullyDelimiters_Empty() {
        assertEquals("", WordUtils.capitalizeFully("", '.'));
    }

    @Test
    public void testCapitalizeFullyDelimiters_EmptyArrayLeavesStringUnchanged() {
        assertEquals("i AM.fine", WordUtils.capitalizeFully("i AM.fine", new char[0]));
    }

    @Test
    public void testCapitalizeFullyDelimiters_CustomDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", '.'));
    }

    // ---- containsAllWords(CharSequence, CharSequence...) ----

    @Test
    public void testContainsAllWords_NullWord() {
        assertFalse(WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_EmptyWord() {
        assertFalse(WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_NullWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_EmptyWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def"));
    }

    @Test
    public void testContainsAllWords_SubstringsDoNotCount() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_AllWordsPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    // ---- initials(String) ----

    @Test
    public void testInitials_Null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_Empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_Basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_CaseNotChanged() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    // ---- initials(String, char...) ----

    @Test
    public void testInitialsDelimiters_Null() {
        assertNull(WordUtils.initials(null, ' ', '.'));
    }

    @Test
    public void testInitialsDelimiters_Empty() {
        assertEquals("", WordUtils.initials("", ' ', '.'));
    }

    @Test
    public void testInitialsDelimiters_NullDelimitersTreatedAsWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitialsDelimiters_CustomDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testInitialsDelimiters_EmptyArrayReturnsEmptyString() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    // ---- swapCase(String) ----

    @Test
    public void testSwapCase_Null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_Empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_Basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    // ---- uncapitalize(String) ----

    @Test
    public void testUncapitalize_Null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_Empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_Basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // ---- uncapitalize(String, char...) ----

    @Test
    public void testUncapitalizeDelimiters_Null() {
        assertNull(WordUtils.uncapitalize(null, '.'));
    }

    @Test
    public void testUncapitalizeDelimiters_Empty() {
        assertEquals("", WordUtils.uncapitalize("", '.'));
    }

    @Test
    public void testUncapitalizeDelimiters_EmptyArrayLeavesStringUnchanged() {
        assertEquals("I AM.FINE", WordUtils.uncapitalize("I AM.FINE", new char[0]));
    }

    @Test
    public void testUncapitalizeDelimiters_CustomDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", '.'));
    }

    // ---- wrap(String, int) ----

    @Test
    public void testWrap2_Null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap2_Empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap2_Basic() {
        String expected = "Here is one line of" + SEP + "text that is going" + SEP
                + "to be wrapped after" + SEP + "20 columns.";
        assertEquals(expected,
                WordUtils.wrap("Here is one line of text that is going to be wrapped after 20 columns.", 20));
    }

    @Test
    public void testWrap2_LongWordsAreNotWrapped() {
        String expected = "Click here to jump" + SEP + "to the commons" + SEP
                + "website -" + SEP + "https://commons.apache.org";
        assertEquals(expected,
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org", 20));
    }

    // ---- wrap(String, int, String, boolean) ----

    @Test
    public void testWrap4_Null() {
        assertNull(WordUtils.wrap(null, 20, "\n", false));
    }

    @Test
    public void testWrap4_Empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", false));
    }

    @Test
    public void testWrap4_CustomNewLineStr() {
        assertEquals("Here is one line of\ntext that is going\nto be wrapped after\n20 columns.",
                WordUtils.wrap("Here is one line of text that is going to be wrapped after 20 columns.", 20, "\n", false));
    }

    @Test
    public void testWrap4_HtmlBreakNewLineStr() {
        assertEquals("Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.",
                WordUtils.wrap("Here is one line of text that is going to be wrapped after 20 columns.", 20, "<br />", false));
    }

    @Test
    public void testWrap4_WrapLongWordsFalseKeepsUrlIntact() {
        assertEquals("Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org",
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org", 20, "\n", false));
    }

    @Test
    public void testWrap4_WrapLongWordsTrueSplitsUrl() {
        assertEquals("Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org",
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org", 20, "\n", true));
    }

    @Test
    public void testWrap4_TrailingSpaceNotStripped() {
        assertEquals("aaaaa ", WordUtils.wrap("aaaaa ", 10, "\n", false));
    }

    @Test
    public void testWrap4_LeadingSpaceOnNewLineStripped() {
        assertEquals("aaaaa\nbbbbb", WordUtils.wrap("aaaaa  bbbbb", 5, "\n", false));
    }

    @Test
    public void testWrap4_WrapLengthLessThanOneTreatedAsOne() {
        String str = "a b c";
        assertEquals(WordUtils.wrap(str, 1, "\n", false), WordUtils.wrap(str, 0, "\n", false));
        assertEquals(WordUtils.wrap(str, 1, "\n", false), WordUtils.wrap(str, -5, "\n", false));
    }

    // ---- wrap(String, int, String, boolean, String) ----

    @Test
    public void testWrap5_Null() {
        assertNull(WordUtils.wrap(null, 20, "\n", false, " "));
    }

    @Test
    public void testWrap5_Empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", false, " "));
    }

    @Test
    public void testWrap5_CustomWrapOnCharacter() {
        assertEquals("flammable\ninflammable", WordUtils.wrap("flammable/inflammable", 20, "\n", true, "/"));
    }

    @Test
    public void testWrap5_BlankWrapOnDefaultsToSpace() {
        assertEquals("Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org",
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org", 20, "\n", false, ""));
    }
}
