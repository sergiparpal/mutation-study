/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
class CSVPrinterAgentTest {

    @Test
    void testConstructorNullAppendable() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testConstructorNullFormat() {
        final StringWriter sw = new StringWriter();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(sw, null);
            }
        });
    }

    @Test
    void testGetOutReturnsGivenAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
    }

    @Test
    void testPrintSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sw.toString());
    }

    @Test
    void testPrintValueWithDelimiterGetsQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("b,c");
        assertEquals("\"b,c\"", sw.toString());
    }

    @Test
    void testPrintValueWithQuoteCharIsEscapedByDoubling() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("d\"e");
        assertEquals("\"d\"\"e\"", sw.toString());
    }

    @Test
    void testPrintNullValuePrintsEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        printer.print("x");
        assertEquals(",x", sw.toString());
    }

    @Test
    void testPrintlnWritesRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a\r\nb", sw.toString());
    }

    @Test
    void testPrintRecordVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b,c", "d\"e");
        assertEquals("a,\"b,c\",\"d\"\"e\"\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("1");
        values.add("2");
        values.add("3");
        printer.printRecord(values);
        assertEquals("1,2,3\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordEmptyVarargsStillEndsRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("x", "y", "z").stream());
        assertEquals("x,y,z\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsIterableWithNestedArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B", "C" });
        data.add(new String[] { "1", "2", "3" });
        printer.printRecords(data);
        assertEquals("A,B,C\r\n1,2,3\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsObjectVarargsEachValueIsItsOwnRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords((Object) "a", (Object) "b");
        assertEquals("a\r\nb\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "C", "D" });
        printer.printRecords(data.stream());
        assertEquals("A,B\r\nC,D\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintCommentWithoutMarkerIsNoOp() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("this is a comment");
        assertEquals("", sw.toString());
    }

    @Test
    void testPrintNullCommentIsNoOp() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    void testPrintCommentWithMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testPrintCommentWithEmbeddedNewlineSplitsIntoMultipleMarkedLines() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\r\nline2\nline3");
        assertEquals("# line1\r\n# line2\r\n# line3\r\n", sw.toString());
    }

    @Test
    void testHeaderIsPrintedOnConstruction() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("v1", "v2");
        assertEquals("col1,col2\r\nv1,v2\r\n", sw.toString());
    }

    @Test
    void testHeaderSkippedWhenSkipHeaderRecordSet() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").setSkipHeaderRecord(true).get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("v1", "v2");
        assertEquals("v1,v2\r\n", sw.toString());
    }

    @Test
    void testHeaderCommentsPrintedBeforeHeader() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("generated").setHeader("col1").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("# generated\r\ncol1\r\n", sw.toString());
    }

    @Test
    void testGetRecordCountInitiallyZero() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testGetRecordCountIncrementsPerRecordNotPerValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        printer.printRecord("d", "e");
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testFlushDelegatesToFlushableAppendable() throws IOException {
        final boolean[] flushed = { false };
        final java.io.Writer flushTrackingWriter = new java.io.Writer() {
            @Override
            public void write(final char[] cbuf, final int off, final int len) throws IOException {
                // no-op sink
            }

            @Override
            public void flush() throws IOException {
                flushed[0] = true;
            }

            @Override
            public void close() throws IOException {
                // no-op
            }
        };
        final CSVPrinter printer = new CSVPrinter(flushTrackingWriter, CSVFormat.DEFAULT);
        printer.flush();
        assertTrue(flushed[0]);
    }

    @Test
    void testCloseClosesUnderlyingCloseable() throws IOException {
        final boolean[] closed = { false };
        final java.io.Writer closeTrackingWriter = new java.io.Writer() {
            @Override
            public void write(final char[] cbuf, final int off, final int len) throws IOException {
                // no-op sink
            }

            @Override
            public void flush() throws IOException {
                // no-op
            }

            @Override
            public void close() throws IOException {
                closed[0] = true;
            }
        };
        final CSVPrinter printer = new CSVPrinter(closeTrackingWriter, CSVFormat.DEFAULT);
        printer.close();
        assertTrue(closed[0]);
    }

    @Test
    void testCloseWithFlushTrueFlushesBeforeClosing() throws IOException {
        final List<String> calls = new ArrayList<String>();
        final java.io.Writer writer = new java.io.Writer() {
            @Override
            public void write(final char[] cbuf, final int off, final int len) throws IOException {
                // no-op sink
            }

            @Override
            public void flush() throws IOException {
                calls.add("flush");
            }

            @Override
            public void close() throws IOException {
                calls.add("close");
            }
        };
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close(true);
        assertEquals(Arrays.asList("flush", "close"), calls);
    }

    @Test
    void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertEquals("a", sb.toString());
    }

    @Test
    void testPrintRecordsResultSet() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final Connection conn = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest1;DB_CLOSE_DELAY=-1");
        try {
            final Statement stmt = conn.createStatement();
            try {
                stmt.execute("CREATE TABLE T (ID INT, NAME VARCHAR(20))");
                stmt.execute("INSERT INTO T VALUES (1, 'foo')");
                stmt.execute("INSERT INTO T VALUES (2, 'bar')");
                final ResultSet rs = stmt.executeQuery("SELECT ID, NAME FROM T ORDER BY ID");
                try {
                    final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
                    printer.printRecords(rs);
                    assertEquals("1,foo\r\n2,bar\r\n", sw.toString());
                    assertEquals(2, printer.getRecordCount());
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }
        } finally {
            conn.close();
        }
    }

    @Test
    void testPrintRecordsResultSetWithHeader() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final Connection conn = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest2;DB_CLOSE_DELAY=-1");
        try {
            final Statement stmt = conn.createStatement();
            try {
                stmt.execute("CREATE TABLE T2 (ID INT, NAME VARCHAR(20))");
                stmt.execute("INSERT INTO T2 VALUES (1, 'foo')");
                final ResultSet rs = stmt.executeQuery("SELECT ID, NAME FROM T2 ORDER BY ID");
                try {
                    final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
                    printer.printRecords(rs, true);
                    assertEquals("ID,NAME\r\n1,foo\r\n", sw.toString());
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }
        } finally {
            conn.close();
        }
    }

    @Test
    void testPrintHeadersFromResultSet() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final Connection conn = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest3;DB_CLOSE_DELAY=-1");
        try {
            final Statement stmt = conn.createStatement();
            try {
                stmt.execute("CREATE TABLE T3 (A INT, B INT)");
                final ResultSet rs = stmt.executeQuery("SELECT A, B FROM T3");
                try {
                    final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
                    printer.printHeaders(rs);
                    assertEquals("A,B\r\n", sw.toString());
                    assertEquals(0, printer.getRecordCount());
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }
        } finally {
            conn.close();
        }
    }

    @Test
    void testPrintRecordsWithMaxRowsLimit() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final Connection conn = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest4;DB_CLOSE_DELAY=-1");
        try {
            final Statement stmt = conn.createStatement();
            try {
                stmt.execute("CREATE TABLE T4 (ID INT)");
                stmt.execute("INSERT INTO T4 VALUES (1)");
                stmt.execute("INSERT INTO T4 VALUES (2)");
                stmt.execute("INSERT INTO T4 VALUES (3)");
                final ResultSet rs = stmt.executeQuery("SELECT ID FROM T4 ORDER BY ID");
                try {
                    final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
                    final CSVPrinter printer = new CSVPrinter(sw, format);
                    printer.printRecords(rs);
                    assertEquals("1\r\n2\r\n", sw.toString());
                    assertEquals(2, printer.getRecordCount());
                } finally {
                    rs.close();
                }
            } finally {
                stmt.close();
            }
        } finally {
            conn.close();
        }
    }

    @Test
    void testQuoteModeAllQuotesEveryValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b");
        assertEquals("\"a\",\"b\"\r\n", sw.toString());
    }

    @Test
    void testCustomDelimiterAndRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(';').setRecordSeparator("\n").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b");
        printer.printRecord("c", "d");
        assertEquals("a;b\nc;d\n", sw.toString());
    }

    @Test
    void testPrintRecordsEmptyIterableProducesNoOutput() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testNewRecordFlagResetAfterPrintln() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        printer.print("c");
        assertEquals("a\r\nb,c", sw.toString());
    }

    @Test
    void testPrintRecordsArrayHandlingNestedObjectArray() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final Object[] data = { new String[] { "A", "B" }, new String[] { "1", "2" } };
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintNumberValueNotQuotedEvenWithDelimiterLikeString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(Integer.valueOf(42));
        assertEquals("42", sw.toString());
    }
}
