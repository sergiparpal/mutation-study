/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DateUtilsAgentTest {

    private interface ThrowingAction {
        void run() throws Throwable;
    }

    private static void expectThrows(final Class<? extends Throwable> expectedType, final ThrowingAction action) {
        try {
            action.run();
        } catch (final Throwable t) {
            if (expectedType.isInstance(t)) {
                return;
            }
            fail("Expected " + expectedType.getSimpleName() + " but caught " + t.getClass().getSimpleName() + ": " + t);
            return;
        }
        fail("Expected " + expectedType.getSimpleName() + " to be thrown, but nothing was thrown");
    }

    private TimeZone originalTimeZone;

    @BeforeEach
    public void setUp() {
        originalTimeZone = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("America/Los_Angeles"));
    }

    @AfterEach
    public void tearDown() {
        TimeZone.setDefault(originalTimeZone);
    }

    private static Calendar newCalendar(final int year, final int month, final int day, final int hour, final int minute,
            final int second, final int millis) {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date newDate(final int year, final int month, final int day, final int hour, final int minute, final int second,
            final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ----- constants -----

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    // ----- add* -----

    @Test
    void testAddDays() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 5);
        assertEquals(newDate(2002, Calendar.APRIL, 2, 10, 0, 0, 0), result);
        // original unchanged
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0), date);
        assertNotSame(date, result);
        assertEquals(date, DateUtils.addDays(date, 0));
    }

    @Test
    void testAddDaysNegative() {
        final Date date = newDate(2002, Calendar.MARCH, 1, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, -2);
        assertEquals(newDate(2002, Calendar.FEBRUARY, 27, 10, 0, 0, 0), result);
    }

    @Test
    void testAddWeeks() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.APRIL, 4, 0, 0, 0, 0), DateUtils.addWeeks(date, 1));
    }

    @Test
    void testAddMonths() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.APRIL, 28, 0, 0, 0, 0), DateUtils.addMonths(date, 1));
    }

    @Test
    void testAddYears() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertEquals(newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0), DateUtils.addYears(date, 1));
    }

    @Test
    void testAddHours() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 12, 0, 0, 0), DateUtils.addHours(date, 2));
    }

    @Test
    void testAddMinutes() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 30, 0, 0), DateUtils.addMinutes(date, 30));
    }

    @Test
    void testAddSeconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 0, 30, 0), DateUtils.addSeconds(date, 30));
    }

    @Test
    void testAddMilliseconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 500), DateUtils.addMilliseconds(date, 500));
    }

    @Test
    void testAddNullDateThrows() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addDays(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addHours(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addMinutes(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addSeconds(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addMilliseconds(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addWeeks(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addMonths(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.addYears(null, 1);
            }
        });
    }

    // ----- ceiling -----

    @Test
    void testCeilingDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling(date, Calendar.HOUR_OF_DAY));
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.ceiling(date, Calendar.MONTH));
    }

    @Test
    void testCeilingCalendarReturnsClone() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar ceiled = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertNotSame(cal, ceiled);
        // original calendar is unmodified
        assertEquals(231, cal.get(Calendar.MILLISECOND));
        assertEquals(14, ceiled.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, ceiled.get(Calendar.MINUTE));
    }

    @Test
    void testCeilingObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(DateUtils.ceiling(date, Calendar.HOUR_OF_DAY), DateUtils.ceiling((Object) date, Calendar.HOUR_OF_DAY));
        assertEquals(DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY).getTime(), DateUtils.ceiling((Object) cal, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingToMillisecondIsNoOp() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(date, DateUtils.ceiling(date, Calendar.MILLISECOND));
    }

    @Test
    void testCeilingInvalidObjectTypeThrowsClassCastException() {
        expectThrows(ClassCastException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.ceiling((Object) "not a date", Calendar.YEAR);
            }
        });
    }

    @Test
    void testCeilingNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.ceiling((Date) null, Calendar.YEAR);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.ceiling((Calendar) null, Calendar.YEAR);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.ceiling((Object) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testCeilingHugeYearThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        expectThrows(ArithmeticException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.ceiling(cal, Calendar.YEAR);
            }
        });
    }

    // ----- truncate -----

    @Test
    void testTruncateDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate(date, Calendar.HOUR_OF_DAY));
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.truncate(date, Calendar.MONTH));
    }

    @Test
    void testTruncateObjectDispatch() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(DateUtils.truncate(cal, Calendar.MONTH).getTime(), DateUtils.truncate((Object) cal, Calendar.MONTH));
    }

    @Test
    void testTruncateInvalidObjectTypeThrowsClassCastException() {
        expectThrows(ClassCastException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.truncate((Object) Integer.valueOf(1), Calendar.YEAR);
            }
        });
    }

    @Test
    void testTruncateNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.truncate((Date) null, Calendar.YEAR);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.truncate((Calendar) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testTruncateHugeYearThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000002);
        expectThrows(ArithmeticException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.truncate(cal, Calendar.MONTH);
            }
        });
    }

    @Test
    void testTruncateUnsupportedFieldThrowsIllegalArgumentException() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.truncate(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    // ----- round -----

    @Test
    void testRoundHourOfDay() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.round(date, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.round(date, Calendar.MONTH));
    }

    @Test
    void testRoundSemiMonth() {
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
        assertEquals(newDate(2002, Calendar.MARCH, 16, 0, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 10, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
        assertEquals(newDate(2002, Calendar.MARCH, 16, 0, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 20, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
    }

    @Test
    void testRoundAmPm() {
        assertEquals(newDate(2002, Calendar.MARCH, 28, 12, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 28, 11, 0, 0, 0), Calendar.AM_PM));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 12, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), Calendar.AM_PM));
        assertEquals(newDate(2002, Calendar.MARCH, 29, 0, 0, 0, 0),
                DateUtils.round(newDate(2002, Calendar.MARCH, 28, 23, 0, 0, 0), Calendar.AM_PM));
    }

    @Test
    void testRoundObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(DateUtils.round(date, Calendar.HOUR_OF_DAY), DateUtils.round((Object) date, Calendar.HOUR_OF_DAY));
        assertEquals(DateUtils.round(cal, Calendar.HOUR_OF_DAY).getTime(), DateUtils.round((Object) cal, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundInvalidObjectTypeThrowsClassCastException() {
        expectThrows(ClassCastException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.round((Object) "nope", Calendar.YEAR);
            }
        });
    }

    @Test
    void testRoundNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.round((Date) null, Calendar.YEAR);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.round((Calendar) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testRoundUnsupportedFieldThrowsIllegalArgumentException() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.round(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    // ----- getFragmentIn* -----

    @Test
    void testGetFragmentInDays() {
        final Calendar jan28 = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        final Calendar feb28 = newCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
        assertEquals(0, DateUtils.getFragmentInDays(jan28, Calendar.DATE));
        assertEquals(0, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(cal, Calendar.DAY_OF_YEAR));
        final Calendar cal6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127, DateUtils.getFragmentInHours(cal6, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInHours(cal, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testGetFragmentInMinutesAndSeconds() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(cal, Calendar.MINUTE));
        assertEquals(538, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(0, DateUtils.getFragmentInMinutes(cal, Calendar.MINUTE));
    }

    @Test
    void testGetFragmentDateVariantMatchesCalendarVariant() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        final Date date = cal.getTime();
        assertEquals(DateUtils.getFragmentInHours(cal, Calendar.MONTH), DateUtils.getFragmentInHours(date, Calendar.MONTH));
        assertEquals(DateUtils.getFragmentInDays(cal, Calendar.YEAR), DateUtils.getFragmentInDays(date, Calendar.YEAR));
    }

    @Test
    void testGetFragmentUnsupportedThrowsIllegalArgumentException() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.getFragmentInDays(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testGetFragmentNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
    }

    // ----- isSameDay / isSameInstant / isSameLocalTime -----

    @Test
    void testIsSameDay() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    @Test
    void testIsSameDayNullThrowsNullPointerException() {
        final Date date = new Date();
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.isSameDay(null, date);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.isSameDay(date, null);
            }
        });
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = new Date(10000L);
        final Date d2 = new Date(10000L);
        final Date d3 = new Date(10001L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    @Test
    void testIsSameInstantNullThrowsNullPointerException() {
        final Date date = new Date();
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.isSameInstant(null, date);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.isSameInstant(date, null);
            }
        });
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));
        cal2.set(Calendar.SECOND, 1);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal2));
    }

    @Test
    void testIsSameLocalTimeNullThrowsNullPointerException() {
        final Calendar cal = Calendar.getInstance();
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.isSameLocalTime(null, cal);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.isSameLocalTime(cal, null);
            }
        });
    }

    // ----- iterator -----

    @Test
    void testIteratorRangeWeekSunday() {
        final Calendar focus = newCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0); // Wednesday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            last = it.next();
            if (first == null) {
                first = last;
            }
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorRangeWeekRelativeStartsOnFocusDay() {
        final Calendar focus = newCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0); // Wednesday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        final Calendar first = it.next();
        assertEquals(focus.get(Calendar.DAY_OF_WEEK), first.get(Calendar.DAY_OF_WEEK));
        assertEquals(1, first.get(Calendar.DAY_OF_MONTH));
        int count = 1;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    void testIteratorRangeWeekCenter() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        final Calendar first = it.next();
        assertEquals(1, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MONDAY, first.get(Calendar.DAY_OF_WEEK));
        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(7, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SUNDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorRangeMonthSunday() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            final Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(35, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorObjectDispatch() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar cal = newCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Iterator<?> fromDate = DateUtils.iterator((Object) date, DateUtils.RANGE_WEEK_SUNDAY);
        final Iterator<?> fromCalendar = DateUtils.iterator((Object) cal, DateUtils.RANGE_WEEK_SUNDAY);
        int countDate = 0;
        while (fromDate.hasNext()) {
            fromDate.next();
            countDate++;
        }
        int countCal = 0;
        while (fromCalendar.hasNext()) {
            fromCalendar.next();
            countCal++;
        }
        assertEquals(countDate, countCal);
        assertEquals(7, countDate);
    }

    @Test
    void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.iterator(Calendar.getInstance(), 999);
            }
        });
    }

    @Test
    void testIteratorInvalidObjectTypeThrowsClassCastException() {
        expectThrows(ClassCastException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.iterator((Object) "not-a-date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorRemoveThrowsUnsupportedOperationException() {
        final Calendar focus = newCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        expectThrows(UnsupportedOperationException.class, new ThrowingAction() {
            @Override
            public void run() {
                it.remove();
            }
        });
    }

    @Test
    void testIteratorNextThrowsNoSuchElementExceptionWhenExhausted() {
        final Calendar focus = newCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        expectThrows(NoSuchElementException.class, new ThrowingAction() {
            @Override
            public void run() {
                it.next();
            }
        });
    }

    // ----- parseDate / parseDateStrictly -----

    @Test
    void testParseDateSuccess() throws ParseException {
        final Date parsed = DateUtils.parseDate("2020-01-15", "yyyy-MM-dd");
        assertEquals(newDate(2020, Calendar.JANUARY, 15, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateTriesPatternsInOrder() throws ParseException {
        final Date parsed = DateUtils.parseDate("2020-01-15", "yyyy/MM/dd", "yyyy-MM-dd");
        assertEquals(newDate(2020, Calendar.JANUARY, 15, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateNoMatchThrowsParseException() {
        expectThrows(ParseException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNoPatternsThrowsParseException() {
        expectThrows(ParseException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDate("2020-01-15");
            }
        });
    }

    @Test
    void testParseDateNullArgumentsThrowNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDate("2020-01-15", (String[]) null);
            }
        });
    }

    @Test
    void testParseDateLenientAllowsOverflow() throws ParseException {
        // 2009 is not a leap year, lenient parsing rolls Feb 29 over into March 1
        final Date parsed = DateUtils.parseDate("20090229", "yyyyMMdd");
        assertEquals(newDate(2009, Calendar.MARCH, 1, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        expectThrows(ParseException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDateStrictly("20090229", "yyyyMMdd");
            }
        });
    }

    @Test
    void testParseDateStrictlySuccess() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2020-01-15", "yyyy-MM-dd");
        assertEquals(newDate(2020, Calendar.JANUARY, 15, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateStrictlyNullArgumentsThrowNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() throws ParseException {
                DateUtils.parseDateStrictly("2020-01-15", (String[]) null);
            }
        });
    }

    // ----- set* -----

    @Test
    void testSetDays() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 15, 10, 0, 0, 0), DateUtils.setDays(date, 15));
    }

    @Test
    void testSetDaysOutOfRangeThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setDays(date, 32);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setDays(date, 0);
            }
        });
    }

    @Test
    void testSetHours() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 5, 0, 0, 0), DateUtils.setHours(date, 5));
    }

    @Test
    void testSetHoursOutOfRangeThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setHours(date, 24);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setHours(date, -1);
            }
        });
    }

    @Test
    void testSetMinutes() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 45, 0, 0), DateUtils.setMinutes(date, 45));
    }

    @Test
    void testSetMinutesOutOfRangeThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMinutes(date, 60);
            }
        });
    }

    @Test
    void testSetSeconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 0, 45, 0), DateUtils.setSeconds(date, 45));
    }

    @Test
    void testSetSecondsOutOfRangeThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setSeconds(date, 60);
            }
        });
    }

    @Test
    void testSetMilliseconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 500), DateUtils.setMilliseconds(date, 500));
    }

    @Test
    void testSetMillisecondsOutOfRangeThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMilliseconds(date, 1000);
            }
        });
    }

    @Test
    void testSetMonths() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.JUNE, 28, 10, 0, 0, 0), DateUtils.setMonths(date, Calendar.JUNE));
    }

    @Test
    void testSetMonthsOutOfRangeThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMonths(date, 12);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMonths(date, -1);
            }
        });
    }

    @Test
    void testSetYears() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        assertEquals(newDate(1999, Calendar.MARCH, 28, 10, 0, 0, 0), DateUtils.setYears(date, 1999));
    }

    @Test
    void testSetNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setDays(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setHours(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMinutes(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setSeconds(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMilliseconds(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setMonths(null, 1);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.setYears(null, 1);
            }
        });
    }

    // ----- toCalendar -----

    @Test
    void testToCalendar() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNullThrowsNullPointerException() {
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, utc);
        assertEquals(utc, cal.getTimeZone());
        assertEquals(date.getTime(), cal.getTimeInMillis());
    }

    @Test
    void testToCalendarWithTimeZoneNullThrowsNullPointerException() {
        final Date date = new Date();
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.toCalendar(null, utc);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                DateUtils.toCalendar(date, null);
            }
        });
    }

    // ----- toLocalDateTime / toOffsetDateTime / toZonedDateTime -----

    @Test
    void testToLocalDateTime() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 10, 15, 30, 0);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date);
        assertEquals(2002, ldt.getYear());
        assertEquals(3, ldt.getMonthValue());
        assertEquals(28, ldt.getDayOfMonth());
        assertEquals(10, ldt.getHour());
        assertEquals(15, ldt.getMinute());
        assertEquals(30, ldt.getSecond());
    }

    @Test
    void testToLocalDateTimeWithTimeZone() {
        final Date date = new Date(0L); // epoch
        final LocalDateTime utcLdt = DateUtils.toLocalDateTime(date, TimeZone.getTimeZone("UTC"));
        assertEquals(LocalDateTime.of(1970, 1, 1, 0, 0, 0), utcLdt);
    }

    @Test
    void testToOffsetDateTime() {
        final Date date = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, TimeZone.getTimeZone("UTC"));
        assertEquals(0L, odt.toInstant().toEpochMilli());
    }

    @Test
    void testToZonedDateTime() {
        final Date date = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, TimeZone.getTimeZone("UTC"));
        assertEquals(0L, zdt.toInstant().toEpochMilli());
    }

    // ----- truncatedCompareTo / truncatedEquals -----

    @Test
    void testTruncatedEqualsDate() {
        final Date d1 = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        final Date d2 = newDate(2020, Calendar.JANUARY, 1, 15, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncatedEqualsCalendar() {
        final Calendar c1 = newCalendar(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        final Calendar c2 = newCalendar(2020, Calendar.JANUARY, 1, 15, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncatedCompareTo() {
        final Date earlier = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        final Date later = newDate(2020, Calendar.JANUARY, 2, 10, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.DATE) > 0);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, earlier, Calendar.DATE));
    }

    // ----- constructor -----

    @Test
    void testPublicConstructorIsUsable() {
        assertNotNull(new DateUtils());
    }

    // ----- sanity: fixed Calendar type comparisons -----

    @Test
    void testIsSameDayAcrossCalendarImplementations() {
        final GregorianCalendar g1 = new GregorianCalendar(2020, Calendar.JANUARY, 1, 1, 0, 0);
        final GregorianCalendar g2 = new GregorianCalendar(2020, Calendar.JANUARY, 1, 23, 0, 0);
        assertTrue(DateUtils.isSameDay(g1, g2));
        assertNotEquals(g1.getTimeInMillis(), g2.getTimeInMillis());
    }
}
