/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    // ---- add(array, element) ----

    @Test
    void testAddBooleanElement() {
        boolean[] result = ArrayUtils.add((boolean[]) null, true);
        assertArrayEquals(new boolean[] {true}, result);
        result = ArrayUtils.add(new boolean[] {true, false}, true);
        assertArrayEquals(new boolean[] {true, false, true}, result);
    }

    @Test
    void testAddIntElement() {
        int[] result = ArrayUtils.add((int[]) null, 5);
        assertArrayEquals(new int[] {5}, result);
        result = ArrayUtils.add(new int[] {1, 2}, 3);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    void testAddObjectElement() {
        String[] result = ArrayUtils.add((String[]) null, "a");
        assertArrayEquals(new String[] {"a"}, result);
        result = ArrayUtils.add(new String[] {"a"}, "b");
        assertArrayEquals(new String[] {"a", "b"}, result);
        result = ArrayUtils.add(new String[] {"a"}, (String) null);
        assertArrayEquals(new String[] {"a", null}, result);
    }

    @Test
    void testAddObjectElementBothNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.add((Object[]) null, (Object) null);
            }
        });
    }

    // ---- add(array, index, element) ----

    @Test
    void testAddIntAtIndex() {
        int[] result = ArrayUtils.add(new int[] {1, 3}, 1, 2);
        assertArrayEquals(new int[] {1, 2, 3}, result);
        result = ArrayUtils.add((int[]) null, 0, 9);
        assertArrayEquals(new int[] {9}, result);
    }

    @Test
    void testAddIntAtIndexOutOfBounds() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.add(array, -1, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.add(array, 4, 9);
            }
        });
    }

    @Test
    void testAddObjectAtIndexBothNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.add((Object[]) null, 0, (Object) null);
            }
        });
    }

    // ---- addAll ----

    @Test
    void testAddAllIntArrays() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.addAll(new int[] {1, 2}, 3, 4));
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll((int[]) null, 1, 2));
    }

    @Test
    void testAddAllObjectArrays() {
        String[] a = {"a", "b"};
        String[] b = {"c"};
        assertArrayEquals(new String[] {"a", "b", "c"}, ArrayUtils.addAll(a, b));
        assertArrayEquals(a, ArrayUtils.addAll(a, (String[]) null));
    }

    // ---- addFirst ----

    @Test
    void testAddFirstInt() {
        assertArrayEquals(new int[] {0, 1, 2}, ArrayUtils.addFirst(new int[] {1, 2}, 0));
        assertArrayEquals(new int[] {9}, ArrayUtils.addFirst((int[]) null, 9));
    }

    @Test
    void testAddFirstObject() {
        assertArrayEquals(new String[] {"z", "a"}, ArrayUtils.addFirst(new String[] {"a"}, "z"));
    }

    // ---- clone ----

    @Test
    void testCloneNull() {
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    void testCloneIntArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    void testCloneObjectArrayPreservesComponentType() {
        final String[] original = {"a", "b"};
        final String[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
        assertEquals(String.class, cloned.getClass().getComponentType());
    }

    // ---- concat ----

    @Test
    void testConcatIntArrays() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.concat(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0]));
    }

    @Test
    void testConcatSkipsNullArrays() {
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.concat(new int[] {1, 2}, null, new int[] {3}));
    }

    // ---- contains ----

    @Test
    void testContainsInt() {
        final int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 2));
    }

    @Test
    void testContainsDoubleWithTolerance() {
        final double[] array = {1.0, 2.0, 3.0};
        assertTrue(ArrayUtils.contains(array, 2.0005, 0.001));
        assertFalse(ArrayUtils.contains(array, 2.0005, 0.0001));
    }

    @Test
    void testContainsObject() {
        final String[] array = {"a", "b", null};
        assertTrue(ArrayUtils.contains(array, "a"));
        assertTrue(ArrayUtils.contains(array, (Object) null));
        assertFalse(ArrayUtils.contains(array, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    // ---- containsAny ----

    @Test
    void testContainsAnyInt() {
        final int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.containsAny(array, 9, 2));
        assertFalse(ArrayUtils.containsAny(array, 7, 8));
    }

    @Test
    void testContainsAnyObject() {
        final String[] array = {"a", "b"};
        assertTrue(ArrayUtils.containsAny(array, "x", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
    }

    // ---- get / getComponentType / getDimensions / getLength ----

    @Test
    void testGetWithDefault() {
        final String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0, "x"));
        assertEquals("x", ArrayUtils.get(array, 5, "x"));
        assertEquals("x", ArrayUtils.get(null, 0, "x"));
    }

    @Test
    void testGetDimensionsAndLength() {
        final int[][] twoDim = {{1, 2}, {3}};
        assertEquals(2, ArrayUtils.getDimensions(twoDim));
        assertEquals(0, ArrayUtils.getDimensions((Object) null));
        assertEquals(2, ArrayUtils.getLength(twoDim));
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
    }

    @Test
    void testGetLengthNotArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    // ---- hashCode / isEquals ----

    @Test
    void testHashCodeNullIsZero() {
        assertEquals(0, ArrayUtils.hashCode(null));
    }

    @Test
    void testHashCodeMatchesForEqualContent() {
        final int[] a = {1, 2, 3};
        final int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    @Test
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    // ---- indexesOf ----

    @Test
    void testIndexesOfInt() {
        final int[] array = {1, 2, 1, 3, 1};
        final BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, bits.cardinality());
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertFalse(bits.get(1));
    }

    @Test
    void testIndexesOfNotFoundEmpty() {
        final int[] array = {1, 2, 3};
        final BitSet bits = ArrayUtils.indexesOf(array, 42);
        assertTrue(bits.isEmpty());
    }

    // ---- indexOf / lastIndexOf ----

    @Test
    void testIndexOfIntBasic() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(-1, ArrayUtils.indexOf(array, 42));
        assertEquals(-1, ArrayUtils.indexOf((int[]) null, 2));
    }

    @Test
    void testIndexOfIntWithStartIndexBoundaries() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
        assertEquals(-1, ArrayUtils.indexOf(array, 2, 10));
    }

    @Test
    void testLastIndexOfIntBasic() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 42));
    }

    @Test
    void testLastIndexOfIntStartIndexBoundaries() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 1));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 2, -1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2, 100));
    }

    @Test
    void testIndexOfObject() {
        final String[] array = {"a", "b", "a"};
        assertEquals(0, ArrayUtils.indexOf(array, "a"));
        assertEquals(2, ArrayUtils.lastIndexOf(array, "a"));
        assertEquals(-1, ArrayUtils.indexOf(array, "z"));
    }

    // ---- insert ----

    @Test
    void testInsertIntBasic() {
        assertArrayEquals(new int[] {1, 9, 2, 3}, ArrayUtils.insert(1, new int[] {1, 2, 3}, 9));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.insert(5, new int[] {1, 2, 3}, (int[]) null));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1, 2));
    }

    @Test
    void testInsertIntOutOfBoundsThrows() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.insert(-1, array, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.insert(4, array, 9);
            }
        });
    }

    @Test
    void testInsertObjectBasic() {
        final String[] array = {"a", "c"};
        assertArrayEquals(new String[] {"a", "b", "c"}, ArrayUtils.insert(1, array, "b"));
    }

    // ---- isArrayIndexValid ----

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // ---- isEmpty / isNotEmpty ----

    @Test
    void testIsEmptyPrimitiveAndObject() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
    }

    @Test
    void testIsNotEmptyGeneric() {
        assertFalse(ArrayUtils.isNotEmpty((String[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new String[0]));
        assertTrue(ArrayUtils.isNotEmpty(new String[] {"a"}));
    }

    // ---- isSameLength / isSameType ----

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, new int[] {1, 2}));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, new Object[0]));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
    }

    @Test
    void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.isSameType(new int[0], null);
            }
        });
    }

    // ---- isSorted ----

    @Test
    void testIsSortedInt() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    @Test
    void testIsSortedWithComparator() {
        final Integer[] array = {3, 2, 1};
        assertTrue(ArrayUtils.isSorted(array, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return b.compareTo(a);
            }
        }));
        assertFalse(ArrayUtils.isSorted(array, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return a.compareTo(b);
            }
        }));
    }

    // ---- newInstance ----

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertEquals(String.class, array.getClass().getComponentType());
    }

    // ---- nullTo / nullToEmpty ----

    @Test
    void testNullTo() {
        final String[] defaultArray = {"x"};
        assertSame(defaultArray, ArrayUtils.nullTo(null, defaultArray));
        final String[] array = {"a"};
        assertSame(array, ArrayUtils.nullTo(array, defaultArray));
    }

    @Test
    void testNullToEmptyPrimitive() {
        assertArrayEquals(new int[0], ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = {1, 2};
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    void testNullToEmptyObjectWithType() {
        final String[] result = ArrayUtils.nullToEmpty(null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    void testNullToEmptyNullTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.nullToEmpty((Object[]) null, null);
            }
        });
    }

    // ---- remove ----

    @Test
    void testRemoveInt() {
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.remove(new int[] {1, 2, 3}, 1));
        assertArrayEquals(new int[0], ArrayUtils.remove(new int[] {1}, 0));
    }

    @Test
    void testRemoveIntOutOfBoundsThrows() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.remove(array, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.remove(array, 3);
            }
        });
    }

    @Test
    void testRemoveNullArrayThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    void testRemoveObject() {
        final String[] array = {"a", "b", "c"};
        assertArrayEquals(new String[] {"a", "c"}, ArrayUtils.remove(array, 1));
    }

    // ---- removeAll ----

    @Test
    void testRemoveAllIndices() {
        assertArrayEquals(new int[] {6}, ArrayUtils.removeAll(new int[] {2, 6, 3}, 0, 2));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(new int[] {2, 6}, 0, 1));
    }

    @Test
    void testRemoveAllOutOfBoundsThrows() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.removeAll(array, 5);
            }
        });
    }

    // ---- removeAllOccurrences (and deprecated misspelled alias) ----

    @Test
    void testRemoveAllOccurrencesInt() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.removeAllOccurrences(new int[] {1, 2, 3}, 9));
    }

    @Test
    void testRemoveAllOccurrencesObject() {
        final String[] array = {"a", "b", "a"};
        assertArrayEquals(new String[] {"b"}, ArrayUtils.removeAllOccurrences(array, "a"));
    }

    @Test
    void testRemoveAllOccurencesDeprecatedAliasMatches() {
        final int[] array = {1, 2, 1, 3, 1};
        assertArrayEquals(ArrayUtils.removeAllOccurrences(array, 1), ArrayUtils.removeAllOccurences(array, 1));
    }

    // ---- removeElement ----

    @Test
    void testRemoveElementInt() {
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.removeElement(new int[] {1, 2, 3}, 2));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.removeElement(new int[] {1, 2, 3}, 42));
        assertArrayEquals(new int[0], ArrayUtils.removeElement((int[]) null, 1));
    }

    @Test
    void testRemoveElementOnlyFirstOccurrence() {
        assertArrayEquals(new int[] {2, 1, 3}, ArrayUtils.removeElement(new int[] {1, 2, 1, 3}, 1));
    }

    @Test
    void testRemoveElementObject() {
        final String[] array = {"a", "b", "a"};
        assertArrayEquals(new String[] {"b", "a"}, ArrayUtils.removeElement(array, "a"));
    }

    // ---- removeElements (remove each value once) ----

    @Test
    void testRemoveElementsVarargs() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.removeElements(new int[] {1, 2, 1, 3}, 1));
        assertArrayEquals(new int[] {2}, ArrayUtils.removeElements(new int[] {1, 2, 1, 3}, 1, 3, 1));
    }

    // ---- reverse ----

    @Test
    void testReverseFullArray() {
        final int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    void testReverseNullDoesNothing() {
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testReverseRangeClampsToBounds() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, -10, 100);
        assertArrayEquals(new int[] {5, 4, 3, 2, 1}, array);
    }

    @Test
    void testReverseRangePartial() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    void testReverseObjectArray() {
        final String[] array = {"a", "b", "c"};
        ArrayUtils.reverse(array);
        assertArrayEquals(new String[] {"c", "b", "a"}, array);
    }

    // ---- setAll ----

    @Test
    void testSetAllWithIntFunction() {
        final Integer[] array = new Integer[3];
        ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            public Integer apply(int i) {
                return i * i;
            }
        });
        assertArrayEquals(new Integer[] {0, 1, 4}, array);
    }

    // ---- shift ----

    @Test
    void testShiftRightByOne() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] {5, 1, 2, 3, 4}, array);
    }

    @Test
    void testShiftLeftByOne() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, -1);
        assertArrayEquals(new int[] {2, 3, 4, 5, 1}, array);
    }

    @Test
    void testShiftOffsetLargerThanLengthWraps() {
        final int[] array = {1, 2, 3};
        ArrayUtils.shift(array, 4);
        assertArrayEquals(new int[] {3, 1, 2}, array);
    }

    @Test
    void testShiftNullOrEmptyDoesNothing() {
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertArrayEquals(new int[0], empty);
    }

    @Test
    void testShiftRangePartial() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1, 4, 1);
        assertArrayEquals(new int[] {1, 4, 2, 3, 5}, array);
    }

    // ---- shuffle ----

    @Test
    void testShuffleKeepsSameElements() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shuffle(array, new Random(42));
        final int[] sorted = array.clone();
        Arrays.sort(sorted);
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, sorted);
    }

    @Test
    void testShuffleNullDoesNothing() {
        ArrayUtils.shuffle((int[]) null);
    }

    // ---- startsWith ----

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2}, new byte[] {1, 2, 3}));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1}));
        assertTrue(ArrayUtils.startsWith(new byte[] {1}, new byte[] {}));
    }

    // ---- subarray ----

    @Test
    void testSubarrayBasic() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(new int[] {1, 2, 3, 4}, 1, 3));
    }

    @Test
    void testSubarrayNull() {
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    void testSubarrayClampsOutOfBounds() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.subarray(array, -5, 100));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 5, 10));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 1));
    }

    @Test
    void testSubarrayObject() {
        final String[] array = {"a", "b", "c"};
        assertArrayEquals(new String[] {"b", "c"}, ArrayUtils.subarray(array, 1, 3));
    }

    // ---- swap ----

    @Test
    void testSwapTwoElements() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    void testSwapNegativeIndexPromotedToZero() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, -1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, array);
    }

    @Test
    void testSwapOutOfBoundsNoChange() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 10);
        assertArrayEquals(new int[] {1, 2, 3}, array);
    }

    @Test
    void testSwapWithLengthClampsAtEnd() {
        final boolean[] array = {true, false, true, false};
        ArrayUtils.swap(array, 0, 3, 3);
        assertArrayEquals(new boolean[] {false, false, true, true}, array);
    }

    @Test
    void testSwapNullDoesNothing() {
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    // ---- toArray ----

    @Test
    void testToArrayVarargs() {
        final String[] array = ArrayUtils.toArray("1", "2");
        assertArrayEquals(new String[] {"1", "2"}, array);
    }

    // ---- toMap ----

    @Test
    void testToMapFromEntryArray() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
    }

    @Test
    void testToMapNull() {
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    void testToMapEntryTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.toMap(new Object[] {new String[] {"onlyone"}});
            }
        });
    }

    @Test
    void testToMapInvalidElementTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.toMap(new Object[] {"not an entry or array"});
            }
        });
    }

    @Test
    void testToMapFromMapEntries() {
        final List<Map.Entry<String, Integer>> entries = new ArrayList<Map.Entry<String, Integer>>();
        entries.add(new java.util.AbstractMap.SimpleEntry<String, Integer>("a", 1));
        entries.add(new java.util.AbstractMap.SimpleEntry<String, Integer>("b", 2));
        final Map<Object, Object> map = ArrayUtils.toMap(entries.toArray());
        assertEquals(1, map.get("a"));
        assertEquals(2, map.get("b"));
    }

    // ---- toObject / toPrimitive ----

    @Test
    void testToObjectInt() {
        assertArrayEquals(new Integer[] {1, 2, 3}, ArrayUtils.toObject(new int[] {1, 2, 3}));
        assertNull(ArrayUtils.toObject((int[]) null));
    }

    @Test
    void testToPrimitiveInt() {
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.toPrimitive(new Integer[] {1, 2, 3}));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    void testToPrimitiveIntNullElementThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] {1, null, 3});
            }
        });
    }

    @Test
    void testToPrimitiveIntWithDefaultForNull() {
        assertArrayEquals(new int[] {1, 9, 3}, ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, 9));
    }

    // ---- toString ----

    @Test
    void testToStringObject() {
        assertEquals("{}", ArrayUtils.toString(new Object[0]));
        assertEquals("<null>", ArrayUtils.toString(null));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
    }

    // ---- toStringArray ----

    @Test
    void testToStringArrayDefaultNullHandling() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {"a", null, Integer.valueOf(1)});
        assertArrayEquals(new String[] {"a", "null", "1"}, result);
    }

    @Test
    void testToStringArrayWithCustomNullValue() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {"a", null}, "N/A");
        assertArrayEquals(new String[] {"a", "N/A"}, result);
    }

    @Test
    void testToStringArrayNull() {
        assertNull(ArrayUtils.toStringArray(null));
    }
}
