/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TimedSemaphore}.
 *
 * <p>
 * Instances are constructed with a very long period so that the real, internally created timer never fires during a
 * test. The package-private {@code endOfPeriod()} method is invoked directly instead to simulate the end of a
 * period deterministically, without depending on wall-clock timing.
 * </p>
 */
class TimedSemaphoreAgentTest {

    /** A period long enough that the internal timer will never fire during a test run. */
    private static final long LONG_PERIOD = 1;

    private static final TimeUnit LONG_UNIT = TimeUnit.HOURS;

    private TimedSemaphore semaphore;

    @AfterEach
    void tearDown() {
        if (semaphore != null && !semaphore.isShutdown()) {
            semaphore.shutdown();
        }
    }

    private TimedSemaphore newSemaphore(final int limit) {
        semaphore = TimedSemaphore.builder().setPeriod(LONG_PERIOD).setTimeUnit(LONG_UNIT).setLimit(limit).get();
        return semaphore;
    }

    @Test
    void testBuilderCreatesInstanceWithGivenParameters() {
        final ScheduledExecutorService service = new ScheduledThreadPoolExecutor(1);
        try {
            semaphore = TimedSemaphore.builder().setPeriod(5).setTimeUnit(TimeUnit.SECONDS).setLimit(3).setService(service).get();

            assertEquals(5, semaphore.getPeriod());
            assertEquals(TimeUnit.SECONDS, semaphore.getUnit());
            assertEquals(3, semaphore.getLimit());
            assertSame(service, semaphore.getExecutorService());
            assertFalse(semaphore.isShutdown());
            assertEquals(0, semaphore.getAcquireCount());
            assertEquals(0, semaphore.getLastAcquiresPerPeriod());
            assertEquals(0.0, semaphore.getAverageCallsPerPeriod(), 0.0);
        } finally {
            service.shutdownNow();
        }
    }

    @Test
    void testBuilderWithoutServiceCreatesOwnExecutor() {
        semaphore = newSemaphore(2);

        final ScheduledExecutorService executor = semaphore.getExecutorService();
        assertNotNull(executor);
        assertFalse(executor.isShutdown());

        semaphore.shutdown();
        assertTrue(executor.isShutdown());
    }

    @Test
    void testBuilderRejectsZeroPeriod() {
        final TimedSemaphore.Builder builder = TimedSemaphore.builder().setPeriod(0).setTimeUnit(TimeUnit.SECONDS).setLimit(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testBuilderRejectsNegativePeriod() {
        final TimedSemaphore.Builder builder = TimedSemaphore.builder().setPeriod(-1).setTimeUnit(TimeUnit.SECONDS).setLimit(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedConstructorWithoutServiceUsesOwnExecutor() {
        semaphore = new TimedSemaphore(LONG_PERIOD, LONG_UNIT, 4);

        assertEquals(LONG_PERIOD, semaphore.getPeriod());
        assertEquals(LONG_UNIT, semaphore.getUnit());
        assertEquals(4, semaphore.getLimit());
        assertNotNull(semaphore.getExecutorService());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedConstructorWithServiceUsesGivenExecutor() {
        final ScheduledExecutorService service = new ScheduledThreadPoolExecutor(1);
        try {
            semaphore = new TimedSemaphore(service, LONG_PERIOD, LONG_UNIT, 2);
            assertSame(service, semaphore.getExecutorService());
        } finally {
            semaphore.shutdown();
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedConstructorRejectsNonPositivePeriod() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new TimedSemaphore(0, TimeUnit.SECONDS, 1);
            }
        });
    }

    @Test
    void testTryAcquireWithoutLimitAlwaysSucceeds() {
        semaphore = newSemaphore(TimedSemaphore.NO_LIMIT);

        for (int i = 0; i < 50; i++) {
            assertTrue(semaphore.tryAcquire());
        }
        assertEquals(50, semaphore.getAcquireCount());
    }

    @Test
    void testTryAcquireRespectsLimit() {
        semaphore = newSemaphore(2);

        assertTrue(semaphore.tryAcquire());
        assertTrue(semaphore.tryAcquire());
        assertEquals(2, semaphore.getAcquireCount());
        assertEquals(0, semaphore.getAvailablePermits());

        assertFalse(semaphore.tryAcquire());
        assertEquals(2, semaphore.getAcquireCount());
    }

    @Test
    void testGetAvailablePermitsDecreasesWithEachAcquire() {
        semaphore = newSemaphore(3);

        assertEquals(3, semaphore.getAvailablePermits());
        semaphore.tryAcquire();
        assertEquals(2, semaphore.getAvailablePermits());
        semaphore.tryAcquire();
        assertEquals(1, semaphore.getAvailablePermits());
    }

    @Test
    void testSetLimitIncreaseAllowsMoreAcquiresImmediately() {
        semaphore = newSemaphore(1);

        assertTrue(semaphore.tryAcquire());
        assertFalse(semaphore.tryAcquire());

        semaphore.setLimit(2);
        assertEquals(2, semaphore.getLimit());
        assertTrue(semaphore.tryAcquire());
        assertEquals(2, semaphore.getAcquireCount());
    }

    @Test
    void testSetLimitDecreaseBlocksFurtherAcquires() {
        semaphore = newSemaphore(5);

        assertTrue(semaphore.tryAcquire());
        assertTrue(semaphore.tryAcquire());
        semaphore.setLimit(1);
        assertEquals(1, semaphore.getLimit());

        assertFalse(semaphore.tryAcquire());
    }

    @Test
    void testEndOfPeriodResetsCounterAndUpdatesStatistics() {
        semaphore = newSemaphore(3);

        semaphore.tryAcquire();
        semaphore.tryAcquire();
        assertEquals(2, semaphore.getAcquireCount());

        semaphore.endOfPeriod();

        assertEquals(0, semaphore.getAcquireCount());
        assertEquals(2, semaphore.getLastAcquiresPerPeriod());
        assertEquals(2.0, semaphore.getAverageCallsPerPeriod(), 0.0);

        semaphore.tryAcquire();
        semaphore.endOfPeriod();

        assertEquals(1, semaphore.getLastAcquiresPerPeriod());
        assertEquals(1.5, semaphore.getAverageCallsPerPeriod(), 0.0);
    }

    @Test
    void testGetAverageCallsPerPeriodIsZeroBeforeAnyPeriodEnds() {
        semaphore = newSemaphore(3);
        semaphore.tryAcquire();
        assertEquals(0.0, semaphore.getAverageCallsPerPeriod(), 0.0);
    }

    @Test
    void testTryAcquireStartsTimerTaskOnFirstInvocation() throws InterruptedException {
        semaphore = newSemaphore(1);

        assertTrue(semaphore.tryAcquire());
        semaphore.shutdown();
        assertTrue(semaphore.isShutdown());
    }

    @Test
    void testTryAcquireAfterShutdownThrows() {
        semaphore = newSemaphore(1);
        semaphore.shutdown();

        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                semaphore.tryAcquire();
            }
        });
    }

    @Test
    void testAcquireAfterShutdownThrows() {
        semaphore = newSemaphore(1);
        semaphore.shutdown();

        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws InterruptedException {
                semaphore.acquire();
            }
        });
    }

    @Test
    void testShutdownIsIdempotent() {
        semaphore = newSemaphore(1);

        semaphore.shutdown();
        assertTrue(semaphore.isShutdown());
        semaphore.shutdown();
        assertTrue(semaphore.isShutdown());
    }

    @Test
    void testIsShutdownInitiallyFalse() {
        semaphore = newSemaphore(1);
        assertFalse(semaphore.isShutdown());
    }

    @Test
    void testAcquireSucceedsImmediatelyWhenPermitAvailable() throws InterruptedException {
        semaphore = newSemaphore(2);

        semaphore.acquire();
        assertEquals(1, semaphore.getAcquireCount());
    }

    @Test
    void testAcquireBlocksUntilEndOfPeriodThenSucceeds() throws InterruptedException {
        semaphore = newSemaphore(1);
        assertTrue(semaphore.tryAcquire());

        final boolean[] finished = {false};
        final Throwable[] failure = {null};
        final Thread blockedThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    semaphore.acquire();
                    finished[0] = true;
                } catch (final Throwable t) {
                    failure[0] = t;
                }
            }
        });
        blockedThread.start();

        // Give the thread a chance to reach the blocking wait(); it must not finish yet.
        Thread.sleep(200);
        assertFalse(finished[0]);
        assertNull(failure[0]);
        assertTrue(blockedThread.isAlive());

        semaphore.endOfPeriod();
        blockedThread.join(5000);

        assertFalse(blockedThread.isAlive());
        assertNull(failure[0]);
        assertTrue(finished[0]);
        assertEquals(1, semaphore.getAcquireCount());
    }

    @Test
    void testShutdownWakesBlockedAcquireWithException() throws InterruptedException {
        semaphore = newSemaphore(1);
        assertTrue(semaphore.tryAcquire());

        final boolean[] finished = {false};
        final Throwable[] failure = {null};
        final Thread blockedThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    semaphore.acquire();
                    finished[0] = true;
                } catch (final Throwable t) {
                    failure[0] = t;
                }
            }
        });
        blockedThread.start();

        Thread.sleep(200);
        assertTrue(blockedThread.isAlive());

        semaphore.shutdown();
        blockedThread.join(5000);

        assertFalse(blockedThread.isAlive());
        assertFalse(finished[0]);
        assertNotNull(failure[0]);
        assertTrue(failure[0] instanceof IllegalStateException);
    }

    @Test
    void testGetAvailablePermitsCanGoNegativeWithoutLimit() {
        semaphore = newSemaphore(TimedSemaphore.NO_LIMIT);

        semaphore.tryAcquire();
        semaphore.tryAcquire();
        semaphore.tryAcquire();

        assertEquals(TimedSemaphore.NO_LIMIT - 3, semaphore.getAvailablePermits());
    }

    @Test
    void testStartTimerReturnsNonNullFuture() {
        semaphore = newSemaphore(1);
        assertNotNull(semaphore.startTimer());
    }

    @Test
    void testOwnExecutorAcceptsExternalServiceDoesNotShutItDown() {
        final ScheduledExecutorService service = new ScheduledThreadPoolExecutor(1);
        try {
            semaphore = TimedSemaphore.builder().setPeriod(LONG_PERIOD).setTimeUnit(LONG_UNIT).setLimit(1).setService(service).get();
            semaphore.tryAcquire();
            semaphore.shutdown();

            assertTrue(semaphore.isShutdown());
            assertFalse(service.isShutdown());
        } finally {
            service.shutdownNow();
        }
    }
}
