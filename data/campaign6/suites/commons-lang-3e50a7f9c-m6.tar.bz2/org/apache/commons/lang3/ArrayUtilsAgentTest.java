/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    // --- isEmpty / isNotEmpty ---

    @Test
    void testIsEmptyNullAndEmptyAndNonEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ArrayUtils.isNotEmpty((long[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new long[0]));
        assertTrue(ArrayUtils.isNotEmpty(new long[] { 1L }));

        assertFalse(ArrayUtils.isNotEmpty((String[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new String[] { "x" }));
    }

    // --- getLength ---

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));
        assertEquals(2, ArrayUtils.getLength(new boolean[] { true, false }));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));

        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.getLength("not an array");
            }
        });
        assertNotNull(e);
    }

    // --- isArrayIndexValid ---

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, -1));
    }

    // --- contains / indexOf / lastIndexOf ---

    @Test
    void testContainsIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 99));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
    }

    @Test
    void testContainsObjectArrayWithNullElement() {
        final Object[] array = { "a", null, "c" };
        assertTrue(ArrayUtils.contains(array, null));
        assertTrue(ArrayUtils.contains(array, "c"));
        assertFalse(ArrayUtils.contains(array, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    void testIndexOfAndLastIndexOfIntArray() {
        final int[] array = { 5, 7, 5, 9 };
        assertEquals(0, ArrayUtils.indexOf(array, 5));
        assertEquals(2, ArrayUtils.indexOf(array, 5, 1));
        assertEquals(-1, ArrayUtils.indexOf(array, 42));
        assertEquals(-1, ArrayUtils.indexOf((int[]) null, 5));

        assertEquals(2, ArrayUtils.lastIndexOf(array, 5));
        assertEquals(0, ArrayUtils.lastIndexOf(array, 5, 1));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 42));
        assertEquals(-1, ArrayUtils.lastIndexOf((int[]) null, 5));

        // startIndex beyond array length / negative
        assertEquals(-1, ArrayUtils.indexOf(array, 5, 10));
        assertEquals(0, ArrayUtils.indexOf(array, 5, -5));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 5, -1));
        assertEquals(2, ArrayUtils.lastIndexOf(array, 5, 100));
    }

    @Test
    void testIndexesOfBoolean() {
        final boolean[] array = { true, false, true, false };
        final BitSet bits = ArrayUtils.indexesOf(array, true);
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertFalse(bits.get(1));
        assertEquals(2, bits.cardinality());

        assertTrue(ArrayUtils.indexesOf((boolean[]) null, true).isEmpty());
        assertTrue(ArrayUtils.indexesOf(array, true, 50).isEmpty());
    }

    // --- subarray ---

    @Test
    void testSubarrayBoundaries() {
        final int[] array = { 0, 1, 2, 3, 4 };
        assertArrayEquals(new int[] { 1, 2, 3 }, ArrayUtils.subarray(array, 1, 4));
        assertArrayEquals(array, ArrayUtils.subarray(array, 0, 5));
        // undervalue start promoted to 0
        assertArrayEquals(new int[] { 0, 1 }, ArrayUtils.subarray(array, -10, 2));
        // overvalue end demoted to array length
        assertArrayEquals(new int[] { 3, 4 }, ArrayUtils.subarray(array, 3, 100));
        // end < start yields empty array, not null
        final int[] empty = ArrayUtils.subarray(array, 3, 1);
        assertNotNull(empty);
        assertEquals(0, empty.length);
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    // --- reverse / swap / shift ---

    @Test
    void testReverseFullAndRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 5, 4, 3, 2, 1 }, array);

        final int[] array2 = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array2, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array2);

        // null array is a no-op, not an error
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testSwapBasicAndOutOfRange() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] array2 = { 1, 2, 3 };
        // offset beyond array length -> no-op
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);

        final int[] array3 = { 1, 2, 3 };
        // negative offset promoted to 0
        ArrayUtils.swap(array3, -1, 1);
        assertArrayEquals(new int[] { 2, 1, 3 }, array3);

        // null/empty array is a no-op
        ArrayUtils.swap((int[]) null, 0, 1);
        ArrayUtils.swap(new int[0], 0, 1);
    }

    @Test
    void testShiftOffsetWrapsModuloLength() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);

        // offset equal to length is a no-op (wraps fully)
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.shift(array2, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);

        // single-element and empty and null arrays are no-ops
        final int[] single = { 42 };
        ArrayUtils.shift(single, 5);
        assertArrayEquals(new int[] { 42 }, single);
        ArrayUtils.shift(new int[0], 1);
        ArrayUtils.shift((int[]) null, 1);
    }

    // --- nullToEmpty ---

    @Test
    void testNullToEmptyIntArray() {
        final int[] result = ArrayUtils.nullToEmpty((int[]) null);
        assertNotNull(result);
        assertEquals(0, result.length);

        final int[] source = { 1, 2 };
        assertSame(source, ArrayUtils.nullToEmpty(source));
    }

    @Test
    void testNullToEmptyObjectArray() {
        final String[] result = ArrayUtils.nullToEmpty((String[]) null);
        assertNotNull(result);
        assertEquals(0, result.length);
        final String[] source = { "a" };
        assertSame(source, ArrayUtils.nullToEmpty(source));
    }

    // --- clone ---

    @Test
    void testCloneNullAndValue() {
        assertNull(ArrayUtils.clone((int[]) null));
        final int[] original = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(original);
        assertNotSame(original, cloned);
        assertArrayEquals(original, cloned);
    }

    // --- isSameLength / isSameType ---

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1 }, new int[] { 3, 4 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(null, new int[] { 1 }));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new Object[0], new String[0]));

        final IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
        assertNotNull(iae);
    }

    // --- isSorted ---

    @Test
    void testIsSortedIntArray() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 1, 2 }));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] { 7 }));
    }

    // --- insert ---

    @Test
    void testInsertIntArray() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 9, 2, 3 }, ArrayUtils.insert(1, array, 9));
        assertArrayEquals(array, ArrayUtils.insert(1, array, (int[]) null));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));

        final IndexOutOfBoundsException e1 = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.insert(-1, array, 9);
            }
        });
        assertNotNull(e1);

        final IndexOutOfBoundsException e2 = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.insert(4, array, 9);
            }
        });
        assertNotNull(e2);
    }

    // --- removeElement / removeElements / removeAll ---

    @Test
    void testRemoveElementIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertArrayEquals(new int[] { 1, 3, 2 }, ArrayUtils.removeElement(array, 2));
        // element not present: returns an equal clone, not the same reference
        final int[] result = ArrayUtils.removeElement(array, 99);
        assertArrayEquals(array, result);
        assertNotSame(array, result);
        assertNull(ArrayUtils.removeElement((int[]) null, 1));
    }

    @Test
    void testRemoveElementsIntArray() {
        final int[] array = { 1, 2, 3, 2, 4 };
        assertArrayEquals(new int[] { 1, 3, 4 }, ArrayUtils.removeElements(array, 2, 2));
        assertArrayEquals(array, ArrayUtils.removeElements(array, (int[]) null));
        assertNull(ArrayUtils.removeElements((int[]) null, 1));
    }

    @Test
    void testRemoveAllIntArray() {
        final int[] array = { 2, 6, 3 };
        assertArrayEquals(new int[] { 2 }, ArrayUtils.removeAll(array, 1, 2));
        assertArrayEquals(new int[0], ArrayUtils.removeAll(array, 0, 1, 2));
        assertNull(ArrayUtils.removeAll((int[]) null, 0));

        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.removeAll(array, 10);
            }
        });
        assertNotNull(e);
    }

    // --- toObject / toPrimitive ---

    @Test
    void testToObjectAndBackIntArray() {
        final int[] primitives = { 1, 2, 3 };
        final Integer[] objects = ArrayUtils.toObject(primitives);
        assertArrayEquals(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3) }, objects);

        final int[] roundTripped = ArrayUtils.toPrimitive(objects);
        assertArrayEquals(primitives, roundTripped);

        assertNull(ArrayUtils.toObject((int[]) null));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    void testToPrimitiveIntegerArrayWithNullElementThrows() {
        final Integer[] withNull = { Integer.valueOf(1), null };
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.toPrimitive(withNull);
            }
        });
    }

    @Test
    void testToPrimitiveWithDefaultForNull() {
        final Integer[] withNull = { Integer.valueOf(1), null };
        assertArrayEquals(new int[] { 1, -1 }, ArrayUtils.toPrimitive(withNull, -1));
    }

    @Test
    void testToPrimitiveGenericObjectDispatch() {
        final Object result = ArrayUtils.toPrimitive(new Integer[] { Integer.valueOf(5), Integer.valueOf(6) });
        assertTrue(result instanceof int[]);
        assertArrayEquals(new int[] { 5, 6 }, (int[]) result);
        assertNull(ArrayUtils.toPrimitive((Object) null));
    }

    // --- toStringArray ---

    @Test
    void testToStringArray() {
        final Object[] array = { "a", null, Integer.valueOf(1) };
        assertArrayEquals(new String[] { "a", "null", "1" }, ArrayUtils.toStringArray(array));
        assertArrayEquals(new String[] { "a", "NIL", "1" }, ArrayUtils.toStringArray(array, "NIL"));
        assertNull(ArrayUtils.toStringArray(null));
        assertArrayEquals(new String[0], ArrayUtils.toStringArray(new Object[0]));
    }

    // --- toMap ---

    @Test
    void testToMapWithArrayEntries() {
        final Object[] array = { new Object[] { "k1", "v1" }, new Object[] { "k2", "v2" } };
        final Map<Object, Object> map = ArrayUtils.toMap(array);
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    void testToMapWithTooShortEntryThrows() {
        final Object[] array = { new Object[] { "onlyKey" } };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.toMap(array);
            }
        });
    }

    @Test
    void testToMapWithInvalidElementTypeThrows() {
        final Object[] array = { "not a map entry or array" };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                ArrayUtils.toMap(array);
            }
        });
    }

    // --- hashCode ---

    @Test
    void testHashCodeNullAndArrays() {
        // HashCodeBuilder's default seed/multiplier (17, 37) applied once for a null array
        assertEquals(17 * 37, ArrayUtils.hashCode(null));
        final int[] a = { 1, 2, 3 };
        final int[] b = { 1, 2, 3 };
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    /**
     * A single-method functional-style interface used instead of a lambda, since
     * this project's test sources must compile at --release 8 without lambda syntax
     * in this self-contained test file.
     */
    private interface Executable {
        void run();
    }

    private static <T extends Throwable> T assertThrows(final Class<T> expectedType, final Executable executable) {
        try {
            executable.run();
        } catch (final Throwable actual) {
            if (expectedType.isInstance(actual)) {
                return expectedType.cast(actual);
            }
            throw new AssertionError("Unexpected exception type thrown: " + actual.getClass().getName(), actual);
        }
        fail("Expected " + expectedType.getName() + " to be thrown, but nothing was thrown.");
        return null;
    }
}
