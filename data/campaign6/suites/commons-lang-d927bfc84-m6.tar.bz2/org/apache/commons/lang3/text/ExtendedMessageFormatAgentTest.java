/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
class ExtendedMessageFormatAgentTest {

    /**
     * Simple custom {@link Format} that upper-cases its argument.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * {@link FormatFactory} that only knows the "upper" format name.
     */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return "upper".equals(name) ? new UpperCaseFormat() : null;
        }
    }

    private static Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperCaseFormatFactory());
        return registry;
    }

    @Test
    void testBasicPatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} apples");
        assertEquals("5 apples", emf.format(new Object[] {"5"}));
    }

    @Test
    void testLocaleConstructorSetsLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.FRENCH);
        assertEquals(Locale.FRENCH, emf.getLocale());
    }

    @Test
    void testDefaultLocaleConstructorMatchesExplicitDefault() {
        final ExtendedMessageFormat withDefault = new ExtendedMessageFormat("{0}");
        final ExtendedMessageFormat explicit = new ExtendedMessageFormat("{0}", Locale.getDefault());
        assertEquals(explicit.getLocale(), withDefault.getLocale());
        assertEquals(explicit.format(new Object[] {"x"}), withDefault.format(new Object[] {"x"}));
    }

    @Test
    void testNullPatternThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    void testCustomFormatRegistryAppliesCustomFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("HELLO", emf.format(new Object[] {"hello"}));
    }

    @Test
    void testUnknownCustomFormatNameFallsBackAndFailsToParse() {
        // Without a registry, an unknown format type name is rejected by the
        // underlying java.text.MessageFormat parser.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper}");
            }
        });
    }

    @Test
    void testKnownBuiltinTypeStillWorksWithRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer} widgets", upperRegistry());
        assertEquals("3 widgets", emf.format(new Object[] {Integer.valueOf(3)}));
    }

    @Test
    void testQuotedLiteralBracesAreNotSubstituted() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}'", upperRegistry());
        assertEquals("{0}", emf.format(new Object[] {"IGNORED"}));
    }

    @Test
    void testUnterminatedFormatElementThrowsWithRegistry() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0", upperRegistry());
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testUnterminatedQuotedStringThrowsWithRegistry() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("'abc", upperRegistry());
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated quoted string"));
    }

    @Test
    void testInvalidArgumentIndexThrowsWithRegistry() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{abc}", upperRegistry());
                    }
                });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", Locale.US);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
        assertEquals(emf1, emf1);
    }

    @Test
    void testEqualsReturnsFalseForDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{1} {0}", Locale.US);
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testEqualsReturnsFalseForDifferentType() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(emf1.equals("{0}"));
        assertFalse(emf1.equals(null));
    }

    @Test
    void testToPatternRoundTripsWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}");
        assertEquals("{0} and {1}", emf.toPattern());
    }

    @Test
    void testToPatternPreservesCustomFormatDescription() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1}", upperRegistry());
        assertEquals("{0,upper} and {1}", emf.toPattern());
    }

    @Test
    void testApplyPatternIsIdempotentAndUpdatesToPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertEquals("{0}", emf.toPattern());
        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("HELLO", emf.format(new Object[] {"hello"}));
    }

    @Test
    void testRegistryConstructorDefaultsToDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertNotNull(emf.toPattern());
    }
}
