/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    // ----------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0f);
        assertEquals(Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals(Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testConstructorExists() {
        assertNotNull(new NumberUtils());
    }

    // ----------------------------------------------------------------
    // compare(...)
    // ----------------------------------------------------------------

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ----------------------------------------------------------------
    // createBigDecimal
    // ----------------------------------------------------------------

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        try {
            NumberUtils.createBigDecimal("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // createBigInteger
    // ----------------------------------------------------------------

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("#FF"));
        assertEquals(BigInteger.valueOf(-255), NumberUtils.createBigInteger("-0xFF"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
        assertEquals(BigInteger.valueOf(0), NumberUtils.createBigInteger("0"));
        try {
            NumberUtils.createBigInteger("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // createDouble / createFloat
    // ----------------------------------------------------------------

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(1.5d, NumberUtils.createDouble("1.5").doubleValue(), 0d);
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(1.5f, NumberUtils.createFloat("1.5").floatValue(), 0f);
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // createInteger / createLong
    // ----------------------------------------------------------------

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(-26), NumberUtils.createInteger("-0x1A"));
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertEquals(Long.valueOf(123456789L), NumberUtils.createLong("123456789"));
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // createNumber
    // ----------------------------------------------------------------

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlank() {
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer, "Expected Integer but got " + n.getClass());
        assertEquals(123, n.intValue());
    }

    @Test
    void testCreateNumberNegativeInteger() {
        final Number n = NumberUtils.createNumber("-123");
        assertTrue(n instanceof Integer, "Expected Integer but got " + n.getClass());
        assertEquals(-123, n.intValue());
    }

    @Test
    void testCreateNumberLongRange() {
        final Number n = NumberUtils.createNumber("12345678901234");
        assertTrue(n instanceof Long, "Expected Long but got " + n.getClass());
        assertEquals(12345678901234L, n.longValue());
    }

    @Test
    void testCreateNumberBigIntegerRange() {
        final String huge = "123456789012345678901234567890";
        final Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger, "Expected BigInteger but got " + n.getClass());
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0x1A");
        assertTrue(n instanceof Integer, "Expected Integer but got " + n.getClass());
        assertEquals(26, n.intValue());
    }

    @Test
    void testCreateNumberOctal() {
        final Number n = NumberUtils.createNumber("010");
        assertTrue(n instanceof Integer, "Expected Integer but got " + n.getClass());
        assertEquals(8, n.intValue());
    }

    @Test
    void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float, "Expected Float but got " + n.getClass());
        assertEquals(1.5f, n.floatValue(), 0f);
    }

    @Test
    void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double, "Expected Double but got " + n.getClass());
        assertEquals(1.5d, n.doubleValue(), 0d);
    }

    @Test
    void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long, "Expected Long but got " + n.getClass());
        assertEquals(123L, n.longValue());
    }

    @Test
    void testCreateNumberDecimalNoSuffix() {
        final Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float || n instanceof Double, "Unexpected type " + n.getClass());
        assertEquals(1.5d, n.doubleValue(), 0.0001d);
    }

    @Test
    void testCreateNumberExponent() {
        final Number n = NumberUtils.createNumber("1.2e3");
        assertEquals(1200d, n.doubleValue(), 0.001d);
    }

    @Test
    void testCreateNumberInvalid() {
        try {
            NumberUtils.createNumber("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberBadlyFormattedLongSuffix() {
        try {
            // decimal with an 'L' type qualifier is not valid
            NumberUtils.createNumber("1.5L");
            fail("Expected NumberFormatException for '1.5L'");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberIntegerToLongBoundary() {
        final Number maxInt = NumberUtils.createNumber("2147483647");
        assertTrue(maxInt instanceof Integer, "Expected Integer but got " + maxInt.getClass());
        assertEquals(Integer.MAX_VALUE, maxInt.intValue());

        final Number overInt = NumberUtils.createNumber("2147483648");
        assertTrue(overInt instanceof Long, "Expected Long but got " + overInt.getClass());
        assertEquals(2147483648L, overInt.longValue());
    }

    @Test
    void testCreateNumberLongToBigIntegerBoundary() {
        final Number maxLong = NumberUtils.createNumber("9223372036854775807");
        assertTrue(maxLong instanceof Long, "Expected Long but got " + maxLong.getClass());
        assertEquals(Long.MAX_VALUE, maxLong.longValue());

        final Number overLong = NumberUtils.createNumber("9223372036854775808");
        assertTrue(overLong instanceof BigInteger, "Expected BigInteger but got " + overLong.getClass());
        assertEquals(new BigInteger("9223372036854775808"), overLong);
    }

    @Test
    void testCreateNumberHexIntegerToLongBoundary() {
        // 8 hex digits with first digit > 7 overflows a positive int, so it should promote to Long.
        final Number n = NumberUtils.createNumber("0x80000000");
        assertTrue(n instanceof Long, "Expected Long but got " + n.getClass());
        assertEquals(2147483648L, n.longValue());
    }

    @Test
    void testCreateNumberLongSuffixWithLeadingPlusSign() {
        // A leading '-' combined with the 'L' suffix is handled ("-123L" -> Long(-123)), so a leading
        // '+' should be handled symmetrically and also produce a Long, not a NumberFormatException.
        final Number n = NumberUtils.createNumber("+123L");
        assertTrue(n instanceof Long, "Expected Long but got " + n.getClass());
        assertEquals(123L, n.longValue());
    }

    @Test
    void testCreateNumberMalformedExponent() {
        try {
            // exponent marker appears before the decimal point
            NumberUtils.createNumber("1e2.3");
            fail("Expected NumberFormatException for '1e2.3'");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // isCreatable / isNumber
    // ----------------------------------------------------------------

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("-123"));
        assertTrue(NumberUtils.isCreatable("1.5"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertTrue(NumberUtils.isCreatable("0.123"));
    }

    @Test
    void testIsNumberMatchesIsCreatable() {
        final String[] values = { null, "", " ", "123", "-123", "1.5", "0x1A", "09", "abc", "0.123" };
        for (final String value : values) {
            assertEquals(NumberUtils.isCreatable(value), NumberUtils.isNumber(value), "mismatch for [" + value + "]");
        }
    }

    // ----------------------------------------------------------------
    // isDigits
    // ----------------------------------------------------------------

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // ----------------------------------------------------------------
    // isParsable
    // ----------------------------------------------------------------

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertFalse(NumberUtils.isParsable("123L"));
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("1.2.3"));
    }

    // ----------------------------------------------------------------
    // max / min - byte
    // ----------------------------------------------------------------

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) -1, NumberUtils.max((byte) -5, (byte) -1, (byte) -3));
        assertEquals((byte) 7, NumberUtils.max((byte) 7));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxByteThreeArgs() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max((byte) 5, (byte) 1, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 3, (byte) 5));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) -5, NumberUtils.min((byte) -5, (byte) -1, (byte) -3));
        try {
            NumberUtils.min((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinByteThreeArgs() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 5, (byte) 1, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 5, (byte) 1));
    }

    // ----------------------------------------------------------------
    // max / min - int
    // ----------------------------------------------------------------

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(-1, NumberUtils.max(-5, -1, -3));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxIntThreeArgs() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(5, NumberUtils.max(5, 1, 3));
        assertEquals(5, NumberUtils.max(1, 3, 5));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(-5, NumberUtils.min(-5, -1, -3));
        try {
            NumberUtils.min((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinIntThreeArgs() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(1, NumberUtils.min(5, 1, 3));
        assertEquals(1, NumberUtils.min(3, 5, 1));
    }

    // ----------------------------------------------------------------
    // max / min - long
    // ----------------------------------------------------------------

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        try {
            NumberUtils.max((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // max / min - short
    // ----------------------------------------------------------------

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        try {
            NumberUtils.max((short[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        try {
            NumberUtils.min((short[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------
    // max / min - double (NaN propagates, unlike IEEE754rUtils)
    // ----------------------------------------------------------------

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0001d);
        try {
            NumberUtils.max((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxDoubleArrayWithNaNPropagates() {
        final double result = NumberUtils.max(1.1d, Double.NaN, 3.3d);
        assertTrue(Double.isNaN(result), "NaN should propagate through max(double...)");
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0001d);
        try {
            NumberUtils.min((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinDoubleArrayWithNaNPropagates() {
        final double result = NumberUtils.min(1.1d, Double.NaN, 3.3d);
        assertTrue(Double.isNaN(result), "NaN should propagate through min(double...)");
    }

    @Test
    void testMaxMinDoubleThreeArgs() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0001d);
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0001d);
    }

    // ----------------------------------------------------------------
    // max / min - float (NaN propagates)
    // ----------------------------------------------------------------

    @Test
    void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0001f);
        try {
            NumberUtils.max((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxFloatArrayWithNaNPropagates() {
        final float result = NumberUtils.max(1.1f, Float.NaN, 3.3f);
        assertTrue(Float.isNaN(result), "NaN should propagate through max(float...)");
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0001f);
        try {
            NumberUtils.min((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinFloatArrayWithNaNPropagates() {
        final float result = NumberUtils.min(1.1f, Float.NaN, 3.3f);
        assertTrue(Float.isNaN(result), "NaN should propagate through min(float...)");
    }

    // ----------------------------------------------------------------
    // toByte
    // ----------------------------------------------------------------

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("not a number", (byte) 2));
        // 200 overflows a byte (max 127), so the default should be returned
        assertEquals((byte) 3, NumberUtils.toByte("200", (byte) 3));
    }

    // ----------------------------------------------------------------
    // toDouble
    // ----------------------------------------------------------------

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0d);
        assertEquals(2.2d, NumberUtils.toDouble("not a number", 2.2d), 0d);
    }

    // ----------------------------------------------------------------
    // toFloat
    // ----------------------------------------------------------------

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0f);
        assertEquals(2.2f, NumberUtils.toFloat("not a number", 2.2f), 0f);
    }

    // ----------------------------------------------------------------
    // toInt
    // ----------------------------------------------------------------

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("not a number", 2));
        // overflows an int, so the default should be returned
        assertEquals(3, NumberUtils.toInt("99999999999", 3));
    }

    // ----------------------------------------------------------------
    // toLong
    // ----------------------------------------------------------------

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("not a number", 2L));
    }

    // ----------------------------------------------------------------
    // toShort
    // ----------------------------------------------------------------

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("not a number", (short) 2));
        // 40000 overflows a short (max 32767), so the default should be returned
        assertEquals((short) 3, NumberUtils.toShort("40000", (short) 3));
    }

    // ----------------------------------------------------------------
    // toScaledBigDecimal
    // ----------------------------------------------------------------

    @Test
    void testToScaledBigDecimalNullBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(BigDecimal.valueOf(1.005d));
        assertEquals(2, result.scale());
    }

    @Test
    void testToScaledBigDecimalBigDecimalRoundingHalfEven() {
        // HALF_EVEN: 2.345 rounds to 2.34, 2.355 rounds to 2.36
        assertEquals(new BigDecimal("2.34"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.345"), 2, RoundingMode.HALF_EVEN));
        assertEquals(new BigDecimal("2.36"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.355"), 2, RoundingMode.HALF_EVEN));
    }

    @Test
    void testToScaledBigDecimalBigDecimalNullRoundingMode() {
        // a null rounding mode should fall back to HALF_EVEN
        assertEquals(new BigDecimal("2.34"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.345"), 2, null));
    }

    @Test
    void testToScaledBigDecimalNullDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(1.23456d));
        assertEquals(new BigDecimal("1.23"), result);
    }

    @Test
    void testToScaledBigDecimalNullFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.23456f));
        assertEquals(2, result.scale());
    }

    @Test
    void testToScaledBigDecimalNullString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    void testToScaledBigDecimalString() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal("1.23456");
        assertEquals(new BigDecimal("1.23"), result);
    }
}
