/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialState() throws Exception {
        final ExtendedBufferedReader br = create("abc");
        try {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getLineNumber());
            assertEquals(0, br.getPosition());
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadSingleCharUpdatesState() throws Exception {
        final ExtendedBufferedReader br = create("ab");
        try {
            assertEquals('a', br.read());
            assertEquals('a', br.getLastChar());
            assertEquals(1, br.getPosition());
            assertEquals('b', br.read());
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadReturnsEofAtEndAndSetsLastChar() throws Exception {
        final ExtendedBufferedReader br = create("a");
        try {
            assertEquals('a', br.read());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadAtEofDoesNotAdvancePosition() throws Exception {
        // Reading past EOF does not consume a character, so the character
        // position must not keep growing on every additional call.
        final ExtendedBufferedReader br = create("a");
        try {
            assertEquals('a', br.read());
            assertEquals(1, br.getPosition());
            assertEquals(EOF, br.read());
            assertEquals(1, br.getPosition());
            assertEquals(EOF, br.read());
            assertEquals(1, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadAtEofDoesNotChangePosition() throws Exception {
        // A bulk read that reports EOF (-1) must not move the character
        // position backwards.
        final ExtendedBufferedReader br = create("ab");
        try {
            final char[] buf = new char[10];
            assertEquals(2, br.read(buf, 0, 10));
            assertEquals(2, br.getPosition());
            assertEquals(EOF, br.read(buf, 0, 10));
            assertEquals(2, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadZeroLengthDoesNotConsume() throws Exception {
        final ExtendedBufferedReader br = create("xyz");
        try {
            final char[] buf = new char[5];
            assertEquals(0, br.read(buf, 0, 0));
            assertEquals(0, br.getPosition());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals('x', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadZeroLengthOnEmptyStream() throws Exception {
        final ExtendedBufferedReader br = create("");
        try {
            assertEquals(0, br.read(new char[10], 0, 0));
            assertEquals(EOF, br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadNegativeLengthThrows() throws Exception {
        final ExtendedBufferedReader br = create("abc");
        try {
            assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read(new char[5], 0, -1);
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadFillsBufferAndUpdatesState() throws Exception {
        final ExtendedBufferedReader br = create("abcdef");
        try {
            final char[] buf = new char[4];
            final int n = br.read(buf, 0, 4);
            assertEquals(4, n);
            assertEquals('a', buf[0]);
            assertEquals('d', buf[3]);
            assertEquals('d', br.getLastChar());
            assertEquals(4, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndReset() throws Exception {
        final ExtendedBufferedReader br = create("ab\ncd");
        try {
            assertEquals('a', br.read());
            br.mark(10);
            final long posAtMark = br.getPosition();
            final long lineAtMark = br.getLineNumber();
            final int lastAtMark = br.getLastChar();

            br.read();
            br.read();
            br.read();

            br.reset();
            assertEquals(posAtMark, br.getPosition());
            assertEquals(lineAtMark, br.getLineNumber());
            assertEquals(lastAtMark, br.getLastChar());
            assertEquals('b', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testResetWithoutMarkThrows() throws Exception {
        final ExtendedBufferedReader br = create("abc");
        try {
            assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.reset();
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws Exception {
        final ExtendedBufferedReader br = create("ab");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testGetLineNumberBeforeAnyEol() throws Exception {
        final ExtendedBufferedReader br = create("abc\n");
        try {
            assertEquals(0, br.getLineNumber());
            br.read(); // 'a'
            // A real character has been read but no EOL seen yet: we are on
            // (unfinished) line 1.
            assertEquals(1, br.getLineNumber());
            br.read(); // 'b'
            assertEquals(1, br.getLineNumber());
            br.read(); // 'c'
            assertEquals(1, br.getLineNumber());
            br.read(); // '\n'
            assertEquals(1, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLineNumberCountsCrLfCombinations() throws Exception {
        // a\n -> line 1, b\r -> line 2, c\r\n -> line 3, trailing
        // unterminated "d" is counted as its own line once EOF is hit.
        final ExtendedBufferedReader br = create("a\nb\rc\r\nd");
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(4, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadCountsCrLfSplitAcrossBuffers() throws Exception {
        final ExtendedBufferedReader br = create("a\r\nb\r\nc");
        try {
            final char[] one = new char[1];
            while (br.read(one, 0, 1) != EOF) {
                // consume one char at a time, splitting the CRLF sequences
            }
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadLineNumberDoesNotDropWhenEofIsReached() throws Exception {
        // The line count reported while positioned on the last, unterminated
        // line must not decrease once EOF is reached via a bulk read.
        final ExtendedBufferedReader br = create("a\r\nb\r\nc");
        try {
            final char[] one = new char[1];
            int last = 0;
            while (br.read(one, 0, 1) != EOF) {
                last = one[0];
            }
            assertEquals('c', last);
            final long lineNumberBeforeEof = 3; // "a", "b", unterminated "c"
            assertEquals(lineNumberBeforeEof, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineDropsTerminatorsAndReturnsNullAtEof() throws Exception {
        final ExtendedBufferedReader br = create("foo\r\nbar\n\nbaz");
        try {
            assertEquals("foo", br.readLine());
            assertEquals("bar", br.readLine());
            assertEquals("", br.readLine());
            assertEquals("baz", br.readLine());
            assertNull(br.readLine());
            assertEquals(EOF, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineOnEmptyStreamReturnsNull() throws Exception {
        final ExtendedBufferedReader br = create("");
        try {
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekDoesNotConsumeOrAdvancePosition() throws Exception {
        final ExtendedBufferedReader br = create("ab");
        try {
            assertEquals('a', br.peek());
            assertEquals('a', br.peek());
            assertEquals(0, br.getPosition());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals('a', br.read());
            assertEquals(1, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekAtEofReturnsEofWithoutError() throws Exception {
        final ExtendedBufferedReader br = create("");
        try {
            assertEquals(EOF, br.peek());
            assertEquals(EOF, br.peek());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadStaysZeroWithoutCharset() throws Exception {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"));
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadStaysZeroWhenTrackBytesFalse() throws Exception {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadStaysZeroWhenCharsetNull() throws Exception {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), null, true);
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadTracksAsciiCharsAsOneByteEach() throws Exception {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        try {
            assertEquals('a', br.read());
            assertEquals(1, br.getBytesRead());
            assertEquals('b', br.read());
            assertEquals(2, br.getBytesRead());
            assertEquals('c', br.read());
            assertEquals(3, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadTracksSurrogatePairAsFourUtf8Bytes() throws Exception {
        // U+1F600 GRINNING FACE, encoded as a surrogate pair in UTF-16 and as
        // 4 bytes in UTF-8.
        final String grinningFace = "😀";
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(grinningFace), StandardCharsets.UTF_8, true);
        try {
            br.read(); // high surrogate: byte count deferred
            assertEquals(0, br.getBytesRead());
            br.read(); // low surrogate: completes the pair
            assertEquals(4, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadAtEofDoesNotAddBytes() throws Exception {
        // Reading past EOF does not consume a real character, so it must not
        // contribute any bytes to the byte count.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("a"), StandardCharsets.UTF_8, true);
        try {
            assertEquals('a', br.read());
            assertEquals(1, br.getBytesRead());
            assertEquals(EOF, br.read());
            assertEquals(1, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testLoneLowSurrogateThrowsCharacterCodingException() throws Exception {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uDE00x"), StandardCharsets.UTF_8, true);
        try {
            final IOException e = assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read();
                }
            });
            assertTrue(e instanceof CharacterCodingException);
        } finally {
            br.close();
        }
    }
}
