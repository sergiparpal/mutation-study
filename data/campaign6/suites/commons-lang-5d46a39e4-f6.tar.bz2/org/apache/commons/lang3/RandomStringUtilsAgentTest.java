/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.ThrowingSupplier;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    private static boolean isAlphabetic(final String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isLetter(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isNumeric(final String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAlphanumeric(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (!Character.isLetter(c) && !Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private static boolean onlyFromSet(final String s, final char[] set) {
        for (int i = 0; i < s.length(); i++) {
            boolean found = false;
            for (final char c : set) {
                if (s.charAt(i) == c) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    // --- singleton accessors ---

    @Test
    void testSecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSecureStrongSingleton() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testInsecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSingletonsAreDistinct() {
        assertNotNull(RandomStringUtils.secure());
        assertNotNull(RandomStringUtils.secureStrong());
        assertNotNull(RandomStringUtils.insecure());
        assertFalse(RandomStringUtils.secure() == RandomStringUtils.secureStrong());
        assertFalse(RandomStringUtils.secure() == RandomStringUtils.insecure());
    }

    @Test
    void testDeprecatedConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertNotNull(instance.next(3));
    }

    @Test
    void testToString() {
        final String s = RandomStringUtils.secure().toString();
        assertNotNull(s);
        assertTrue(s.contains("RandomStringUtils"));
    }

    // --- static deprecated random(...) family ---

    @Test
    void testRandomCountLength() {
        final String s = RandomStringUtils.random(10);
        assertEquals(10, s.length());
    }

    @Test
    void testRandomZeroCount() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    // --- length and charset checks on the next*/random* family ---

    @Test
    void testNextAlphabeticLengthAndCharset() {
        final String s = RandomStringUtils.secure().nextAlphabetic(50);
        assertEquals(50, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testNextAlphabeticZeroLength() {
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0));
    }

    @Test
    void testNextAlphabeticNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().nextAlphabetic(-1);
            }
        });
    }

    @Test
    void testNextAlphabeticRangeLength() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10, "length=" + s.length());
            assertTrue(isAlphabetic(s));
        }
    }

    @Test
    void testNextAlphabeticRangeEqualBounds() {
        final String s = RandomStringUtils.secure().nextAlphabetic(5, 5);
        assertEquals(5, s.length());
    }

    @Test
    void testNextAlphabeticRangeInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().nextAlphabetic(10, 5);
            }
        });
    }

    @Test
    void testNextAlphanumericLengthAndCharset() {
        final String s = RandomStringUtils.secure().nextAlphanumeric(50);
        assertEquals(50, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testNextAlphanumericNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().nextAlphanumeric(-5);
            }
        });
    }

    @Test
    void testNextNumericLengthAndCharset() {
        final String s = RandomStringUtils.secure().nextNumeric(50);
        assertEquals(50, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    void testNextNumericNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().nextNumeric(-5);
            }
        });
    }

    @Test
    void testNextAsciiLengthAndRange() {
        final String s = RandomStringUtils.secure().nextAscii(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "char out of ASCII printable range: " + (int) c);
        }
    }

    @Test
    void testNextGraphLengthAndRange() {
        final String s = RandomStringUtils.secure().nextGraph(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126, "char out of graph range: " + (int) c);
            assertFalse(c == ' ');
        }
    }

    @Test
    void testNextPrintLengthAndRange() {
        final String s = RandomStringUtils.secure().nextPrint(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "char out of print range: " + (int) c);
        }
    }

    @Test
    void testNextWithCharsArray() {
        final char[] set = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.secure().next(30, set);
        assertEquals(30, s.length());
        assertTrue(onlyFromSet(s, set));
    }

    @Test
    void testNextWithNullCharsArray() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.secure().next(10, nullChars);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithEmptyCharsArrayThrows() {
        final char[] empty = {};
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, empty);
            }
        });
    }

    @Test
    void testNextWithStringChars() {
        final String s = RandomStringUtils.secure().next(20, "ab");
        assertEquals(20, s.length());
        assertTrue(onlyFromSet(s, new char[] { 'a', 'b' }));
    }

    @Test
    void testNextWithNullStringChars() {
        final String chars = null;
        final String s = RandomStringUtils.secure().next(10, chars);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, "");
            }
        });
    }

    @Test
    void testNextZeroCountReturnsEmpty() {
        assertEquals("", RandomStringUtils.secure().next(0));
    }

    @Test
    void testNextNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-1);
            }
        });
    }

    // --- the core random(...) method: start/end/letters/numbers/chars validation ---

    @Test
    void testRandomEndLessThanStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, 10, 5, false, false);
            }
        });
    }

    @Test
    void testRandomEndEqualsStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, 5, 5, false, false);
            }
        });
    }

    @Test
    void testRandomNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, -1, 10, false, false);
            }
        });
    }

    @Test
    void testRandomNumbersEndTooSmallThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // numbers requested but end (20) <= ASCII '0' (48)
                RandomStringUtils.secure().next(5, 1, 20, false, true);
            }
        });
    }

    @Test
    void testRandomLettersEndTooSmallThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // letters requested but end (30) <= ASCII 'A' (65)
                RandomStringUtils.secure().next(5, 1, 30, true, false);
            }
        });
    }

    @Test
    void testRandomWithCharsArrayStartEnd() {
        final char[] set = { 'p', 'q', 'r', 's', 't' };
        final String s = RandomStringUtils.secure().next(25, 0, set.length, false, false, set);
        assertEquals(25, s.length());
        assertTrue(onlyFromSet(s, set));
    }

    @Test
    void testRandomWithCharsArrayOutOfBoundsThrows() {
        final char[] set = { 'a', 'b', 'c' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                // end (10) exceeds the length of the 3-element array: should raise AIOOBE per the javadoc contract
                RandomStringUtils.secure().next(20, 0, 10, false, false, set);
            }
        });
    }

    @Test
    void testRandomAlphanumericOptimizationOnlyProducesLettersAndDigits() {
        final String s = RandomStringUtils.secure().next(200, true, true);
        assertEquals(200, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testRandomAstralOnlyRangeWithCountOneDoesNotHang() {
        // The range [0x10000, 0x10001) contains exactly one code point, which requires a
        // surrogate pair (2 chars). With count == 1 there is never room for it, and the
        // implementation keeps rejecting and retrying the only possible code point forever
        // instead of completing or raising an error.
        assertTimeoutPreemptively(Duration.ofSeconds(3), new ThrowingSupplier<String>() {
            @Override
            public String get() {
                return RandomStringUtils.secure().next(1, 0x10000, 0x10001, false, false);
            }
        });
    }

    @Test
    void testRandomZeroCountIgnoresInvalidStartEnd() {
        // count == 0 is special-cased to return "" before start/end are validated
        assertEquals("", RandomStringUtils.secure().next(0, -5, -5, false, false));
    }

    // --- range (min inclusive, max exclusive) variants ---

    @Test
    void testNextAlphanumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAlphanumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8, "length=" + s.length());
        }
    }

    @Test
    void testNextAlphanumericRangeInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().nextAlphanumeric(8, 3);
            }
        });
    }

    @Test
    void testNextNumericRangeEqualBounds() {
        final String s = RandomStringUtils.secure().nextNumeric(4, 4);
        assertEquals(4, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    void testNextAsciiRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAscii(3, 9);
            assertTrue(s.length() >= 3 && s.length() < 9, "length=" + s.length());
        }
    }

    @Test
    void testNextGraphRange() {
        final String s = RandomStringUtils.secure().nextGraph(4, 4);
        assertEquals(4, s.length());
    }

    @Test
    void testNextPrintRange() {
        final String s = RandomStringUtils.secure().nextPrint(4, 4);
        assertEquals(4, s.length());
    }

    // --- static deprecated wrappers ---

    @Test
    void testRandomAlphabeticStatic() {
        final String s = RandomStringUtils.randomAlphabetic(15);
        assertEquals(15, s.length());
        assertTrue(isAlphabetic(s));
    }

    @Test
    void testRandomAlphabeticStaticRange() {
        final String s = RandomStringUtils.randomAlphabetic(5, 5);
        assertEquals(5, s.length());
    }

    @Test
    void testRandomAlphanumericStatic() {
        final String s = RandomStringUtils.randomAlphanumeric(15);
        assertEquals(15, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testRandomAsciiStatic() {
        final String s = RandomStringUtils.randomAscii(15);
        assertEquals(15, s.length());
    }

    @Test
    void testRandomGraphStatic() {
        final String s = RandomStringUtils.randomGraph(15);
        assertEquals(15, s.length());
    }

    @Test
    void testRandomNumericStatic() {
        final String s = RandomStringUtils.randomNumeric(15);
        assertEquals(15, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    void testRandomPrintStatic() {
        final String s = RandomStringUtils.randomPrint(15);
        assertEquals(15, s.length());
    }

    @Test
    void testRandomWithCharsStatic() {
        final String s = RandomStringUtils.random(10, 'a', 'b', 'c');
        assertEquals(10, s.length());
        assertTrue(onlyFromSet(s, new char[] { 'a', 'b', 'c' }));
    }

    @Test
    void testRandomWithStringStatic() {
        final String s = RandomStringUtils.random(10, "xyz");
        assertEquals(10, s.length());
        assertTrue(onlyFromSet(s, new char[] { 'x', 'y', 'z' }));
    }

    @Test
    void testRandomFullSignatureStatic() {
        final String s = RandomStringUtils.random(10, 0, 0, true, true);
        assertEquals(10, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testRandomFullSignatureWithCharsStatic() {
        final char[] set = { 'm', 'n', 'o' };
        final String s = RandomStringUtils.random(10, 0, set.length, false, false, set);
        assertEquals(10, s.length());
        assertTrue(onlyFromSet(s, set));
    }

    @Test
    void testRandomWithExplicitJavaUtilRandom() {
        final java.util.Random random = new java.util.Random(42L);
        final String s = RandomStringUtils.random(10, 0, 0, true, true, null, random);
        assertEquals(10, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    void testRandomWithExplicitRandomEmptyCharsThrows() {
        final java.util.Random random = new java.util.Random(42L);
        final char[] empty = {};
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 0, false, false, empty, random);
            }
        });
    }

    private interface Executable {
        void execute();
    }

    private static void assertThrows(final Class<? extends Throwable> expectedType, final Executable executable) {
        try {
            executable.execute();
        } catch (final Throwable t) {
            if (expectedType.isInstance(t)) {
                return;
            }
            throw new AssertionError("Expected " + expectedType.getName() + " but got " + t.getClass().getName(), t);
        }
        throw new AssertionError("Expected " + expectedType.getName() + " to be thrown, but nothing was thrown");
    }
}
