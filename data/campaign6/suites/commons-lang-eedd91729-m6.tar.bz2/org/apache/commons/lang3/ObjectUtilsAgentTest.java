/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.exception.CloneFailedException;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link ObjectUtils}.
 */
class ObjectUtilsAgentTest {

    static final class CloneableBean implements Cloneable {
        private final int value;

        CloneableBean(final int value) {
            this.value = value;
        }

        int getValue() {
            return value;
        }

        @Override
        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

    static final class BrokenCloneableBean implements Cloneable {
        // no public clone() method -> reflective invocation fails
    }

    static final class NotCloneableBean {
        // does not implement Cloneable
    }

    @Test
    void testAllNotNull() {
        assertTrue(ObjectUtils.allNotNull());
        assertTrue(ObjectUtils.allNotNull("a"));
        assertTrue(ObjectUtils.allNotNull("a", "b"));
        assertFalse(ObjectUtils.allNotNull((Object) null));
        assertFalse(ObjectUtils.allNotNull("a", null));
        assertFalse(ObjectUtils.allNotNull((Object[]) null));
    }

    @Test
    void testAllNull() {
        assertTrue(ObjectUtils.allNull());
        assertTrue(ObjectUtils.allNull((Object) null));
        assertTrue(ObjectUtils.allNull(null, null));
        assertFalse(ObjectUtils.allNull("a"));
        assertFalse(ObjectUtils.allNull(null, "a"));
        assertTrue(ObjectUtils.allNull((Object[]) null));
    }

    @Test
    void testAnyNotNull() {
        assertFalse(ObjectUtils.anyNotNull());
        assertFalse(ObjectUtils.anyNotNull((Object) null));
        assertFalse(ObjectUtils.anyNotNull(null, null));
        assertTrue(ObjectUtils.anyNotNull("a"));
        assertTrue(ObjectUtils.anyNotNull(null, "a"));
    }

    @Test
    void testAnyNull() {
        assertTrue(ObjectUtils.anyNull((Object) null));
        assertTrue(ObjectUtils.anyNull("a", null));
        assertFalse(ObjectUtils.anyNull("a", "b"));
        assertFalse(ObjectUtils.anyNull());
        assertTrue(ObjectUtils.anyNull((Object[]) null));
    }

    @Test
    void testCloneNull() {
        assertNull(ObjectUtils.clone((Object) null));
    }

    @Test
    void testCloneNotCloneable() {
        final NotCloneableBean bean = new NotCloneableBean();
        assertNull(ObjectUtils.clone(bean));
    }

    @Test
    void testCloneCloneableObject() {
        final CloneableBean bean = new CloneableBean(42);
        final CloneableBean cloned = ObjectUtils.clone(bean);
        assertNotNull(cloned);
        assertEquals(42, cloned.getValue());
        assertFalse(bean == cloned);
    }

    @Test
    void testCloneArray() {
        final int[] array = {1, 2, 3};
        final int[] cloned = ObjectUtils.clone(array);
        assertNotNull(cloned);
        assertTrue(Arrays.equals(array, cloned));
        assertFalse(array == cloned);
    }

    @Test
    void testCloneObjectArray() {
        final String[] array = {"a", "b"};
        final String[] cloned = ObjectUtils.clone(array);
        assertNotNull(cloned);
        assertEquals("a", cloned[0]);
        assertEquals("b", cloned[1]);
        assertFalse(array == cloned);
    }

    @Test
    void testCloneFailure() {
        final BrokenCloneableBean bean = new BrokenCloneableBean();
        assertThrows(CloneFailedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.clone(bean);
            }
        });
    }

    @Test
    void testCloneIfPossibleCloneable() {
        final CloneableBean bean = new CloneableBean(7);
        final CloneableBean cloned = ObjectUtils.cloneIfPossible(bean);
        assertNotNull(cloned);
        assertFalse(bean == cloned);
        assertEquals(7, cloned.getValue());
    }

    @Test
    void testCloneIfPossibleNotCloneable() {
        final NotCloneableBean bean = new NotCloneableBean();
        final NotCloneableBean result = ObjectUtils.cloneIfPossible(bean);
        assertSame(bean, result);
    }

    @Test
    void testCompareTwoArg() {
        assertEquals(0, ObjectUtils.compare("a", "a"));
        assertTrue(ObjectUtils.compare(null, "a") < 0);
        assertTrue(ObjectUtils.compare("a", null) > 0);
        assertEquals(0, ObjectUtils.compare(null, null));
        assertTrue(ObjectUtils.compare("a", "b") < 0);
        assertTrue(ObjectUtils.compare("b", "a") > 0);
    }

    @Test
    void testCompareThreeArgNullGreater() {
        assertTrue(ObjectUtils.compare(null, "a", true) > 0);
        assertTrue(ObjectUtils.compare("a", null, true) < 0);
        assertTrue(ObjectUtils.compare(null, "a", false) < 0);
        assertTrue(ObjectUtils.compare("a", null, false) > 0);
        assertEquals(0, ObjectUtils.compare(null, null, true));
    }

    @Test
    void testConstOverloads() {
        assertTrue(ObjectUtils.CONST(true));
        assertFalse(ObjectUtils.CONST(false));
        assertEquals((byte) 5, ObjectUtils.CONST((byte) 5));
        assertEquals('a', ObjectUtils.CONST('a'));
        assertEquals(1.5d, ObjectUtils.CONST(1.5d), 0d);
        assertEquals(1.5f, ObjectUtils.CONST(1.5f), 0f);
        assertEquals(123, ObjectUtils.CONST(123));
        assertEquals(123L, ObjectUtils.CONST(123L));
        assertEquals((short) 7, ObjectUtils.CONST((short) 7));
        assertEquals("abc", ObjectUtils.CONST("abc"));
    }

    @Test
    void testConstByte() {
        assertEquals((byte) 127, ObjectUtils.CONST_BYTE(127));
        assertEquals((byte) -128, ObjectUtils.CONST_BYTE(-128));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(128);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(-129);
            }
        });
    }

    @Test
    void testConstShort() {
        assertEquals((short) 32767, ObjectUtils.CONST_SHORT(32767));
        assertEquals((short) -32768, ObjectUtils.CONST_SHORT(-32768));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(32768);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(-32769);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDefaultIfNull() {
        assertNull(ObjectUtils.defaultIfNull(null, null));
        assertEquals("zz", ObjectUtils.defaultIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.defaultIfNull("abc", "zz"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testEquals() {
        assertTrue(ObjectUtils.equals(null, null));
        assertFalse(ObjectUtils.equals(null, ""));
        assertFalse(ObjectUtils.equals("", null));
        assertTrue(ObjectUtils.equals("", ""));
        assertTrue(ObjectUtils.equals(Boolean.TRUE, Boolean.TRUE));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, Boolean.FALSE));
    }

    @Test
    void testFirstNonNull() {
        assertNull(ObjectUtils.firstNonNull());
        assertNull(ObjectUtils.firstNonNull((Object[]) null));
        assertNull(ObjectUtils.firstNonNull(null, null));
        assertEquals("zz", ObjectUtils.firstNonNull(null, "zz"));
        assertEquals("abc", ObjectUtils.firstNonNull("abc", "zz"));
    }

    @Test
    void testGetClass() {
        assertNull(ObjectUtils.getClass(null));
        assertEquals(String.class, ObjectUtils.getClass("abc"));
        assertEquals(Integer.class, ObjectUtils.getClass(Integer.valueOf(1)));
    }

    @Test
    void testGetFirstNonNullSuppliers() {
        assertNull(ObjectUtils.getFirstNonNull());
        final Supplier<String> nullSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return null;
            }
        };
        final Supplier<String> valueSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        };
        assertEquals("zz", ObjectUtils.getFirstNonNull(nullSupplier, valueSupplier));
        assertNull(ObjectUtils.getFirstNonNull(nullSupplier, nullSupplier));
    }

    @Test
    void testGetFirstNonNullShortCircuits() {
        final Supplier<String> valueSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "first";
            }
        };
        final Supplier<String> explodingSupplier = new Supplier<String>() {
            @Override
            public String get() {
                throw new IllegalStateException("should not be called");
            }
        };
        assertEquals("first", ObjectUtils.getFirstNonNull(valueSupplier, explodingSupplier));
    }

    @Test
    void testGetIfNullWithSupplier() {
        assertNull(ObjectUtils.getIfNull(null, (Supplier<String>) null));
        final Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        };
        assertEquals("zz", ObjectUtils.getIfNull(null, supplier));
        assertEquals("abc", ObjectUtils.getIfNull("abc", supplier));
    }

    @Test
    void testGetIfNullWithValue() {
        assertNull(ObjectUtils.getIfNull(null, (String) null));
        assertEquals("zz", ObjectUtils.getIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.getIfNull("abc", "zz"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testHashCode() {
        assertEquals(0, ObjectUtils.hashCode(null));
        assertEquals("abc".hashCode(), ObjectUtils.hashCode("abc"));
    }

    @Test
    void testHashCodeHex() {
        assertEquals(Integer.toHexString(0), ObjectUtils.hashCodeHex(null));
        assertEquals(Integer.toHexString("abc".hashCode()), ObjectUtils.hashCodeHex("abc"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testHashCodeMulti() {
        assertEquals(1, ObjectUtils.hashCodeMulti());
        assertEquals(1, ObjectUtils.hashCodeMulti((Object[]) null));
        assertEquals(31 + "a".hashCode(), ObjectUtils.hashCodeMulti("a"));
        assertEquals((31 + "a".hashCode()) * 31 + "b".hashCode(), ObjectUtils.hashCodeMulti("a", "b"));
    }

    @Test
    void testIdentityHashCodeHex() {
        final Object obj = new Object();
        assertEquals(Integer.toHexString(System.identityHashCode(obj)), ObjectUtils.identityHashCodeHex(obj));
    }

    @Test
    void testIdentityToStringAppendable() throws IOException {
        final StringBuilder appendableTarget = new StringBuilder();
        ObjectUtils.identityToString((Appendable) appendableTarget, "abc");
        assertEquals("java.lang.String@" + ObjectUtils.identityHashCodeHex("abc"), appendableTarget.toString());
    }

    @Test
    void testIdentityToStringAppendableNullObject() {
        final StringBuilder appendableTarget = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.identityToString((Appendable) appendableTarget, null);
            }
        });
    }

    @Test
    void testIdentityToStringObjectNull() {
        assertNull(ObjectUtils.identityToString(null));
    }

    @Test
    void testIdentityToStringObject() {
        final String result = ObjectUtils.identityToString("abc");
        assertEquals("java.lang.String@" + ObjectUtils.identityHashCodeHex("abc"), result);
    }

    @Test
    void testIdentityToStringStringBuilder() {
        final StringBuilder builder = new StringBuilder();
        ObjectUtils.identityToString(builder, "abc");
        assertEquals("java.lang.String@" + ObjectUtils.identityHashCodeHex("abc"), builder.toString());
    }

    @Test
    void testIdentityToStringStringBuilderNullObject() {
        final StringBuilder builder = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(builder, null);
            }
        });
    }

    @Test
    void testIdentityToStringStringBuffer() {
        final StringBuffer buffer = new StringBuffer();
        ObjectUtils.identityToString(buffer, "abc");
        assertEquals("java.lang.String@" + ObjectUtils.identityHashCodeHex("abc"), buffer.toString());
    }

    @Test
    void testIdentityToStringStringBufferNullObject() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(buffer, null);
            }
        });
    }

    @Test
    void testIsArray() {
        assertFalse(ObjectUtils.isArray(null));
        assertFalse(ObjectUtils.isArray(""));
        assertFalse(ObjectUtils.isArray("ab"));
        assertTrue(ObjectUtils.isArray(new int[0]));
        assertTrue(ObjectUtils.isArray(new int[] {1, 2, 3}));
        assertFalse(ObjectUtils.isArray(1234));
    }

    @Test
    void testIsEmpty() {
        assertTrue(ObjectUtils.isEmpty(null));
        assertTrue(ObjectUtils.isEmpty(""));
        assertFalse(ObjectUtils.isEmpty("ab"));
        assertTrue(ObjectUtils.isEmpty(new int[0]));
        assertFalse(ObjectUtils.isEmpty(new int[] {1, 2, 3}));
        assertFalse(ObjectUtils.isEmpty(1234));
        assertFalse(ObjectUtils.isEmpty(Optional.of("")));
        assertTrue(ObjectUtils.isEmpty(Optional.empty()));
        assertTrue(ObjectUtils.isEmpty(new ArrayList<String>()));
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertFalse(ObjectUtils.isEmpty(list));
        assertTrue(ObjectUtils.isEmpty(new HashMap<String, String>()));
        final HashMap<String, String> map = new HashMap<String, String>();
        map.put("a", "b");
        assertFalse(ObjectUtils.isEmpty(map));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ObjectUtils.isNotEmpty(null));
        assertFalse(ObjectUtils.isNotEmpty(""));
        assertTrue(ObjectUtils.isNotEmpty("ab"));
        assertFalse(ObjectUtils.isNotEmpty(new int[0]));
        assertTrue(ObjectUtils.isNotEmpty(new int[] {1, 2, 3}));
    }

    @Test
    void testMax() {
        assertNull(ObjectUtils.max());
        assertNull(ObjectUtils.max((String[]) null));
        assertNull(ObjectUtils.max((String) null, (String) null));
        assertEquals("b", ObjectUtils.max("a", "b"));
        assertEquals("b", ObjectUtils.max("a", "b", null));
        assertEquals(Integer.valueOf(3), ObjectUtils.max(Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(2)));
    }

    @Test
    void testMin() {
        assertNull(ObjectUtils.min());
        assertNull(ObjectUtils.min((String[]) null));
        assertNull(ObjectUtils.min((String) null, (String) null));
        assertEquals("a", ObjectUtils.min("a", "b"));
        assertEquals("a", ObjectUtils.min("a", "b", null));
        assertEquals(Integer.valueOf(1), ObjectUtils.min(Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(2)));
    }

    @Test
    void testMedianVarargs() {
        assertEquals("b", ObjectUtils.median("a", "b", "c"));
        assertEquals("b", ObjectUtils.median("a", "b", "c", "d"));
        assertEquals(Integer.valueOf(2), ObjectUtils.median(Integer.valueOf(3), Integer.valueOf(1), Integer.valueOf(2)));
    }

    @Test
    void testMedianVarargsEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median();
            }
        });
    }

    @Test
    void testMedianVarargsNullElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median("a", null, "c");
            }
        });
    }

    @Test
    void testMedianWithComparator() {
        final Comparator<String> byLength = new Comparator<String>() {
            @Override
            public int compare(final String s1, final String s2) {
                return Integer.compare(s1.length(), s2.length());
            }
        };
        assertEquals("bb", ObjectUtils.median(byLength, "a", "bb", "ccc"));
    }

    @Test
    void testMedianWithComparatorNullComparatorThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((Comparator<String>) null, "a", "b");
            }
        });
    }

    @Test
    void testMode() {
        assertNull(ObjectUtils.mode());
        assertNull(ObjectUtils.mode("a", "b"));
        assertEquals("a", ObjectUtils.mode("a", "b", "a"));
        assertNull(ObjectUtils.mode("a", "a", "b", "b"));
    }

    @Test
    void testNotEqual() {
        assertFalse(ObjectUtils.notEqual(null, null));
        assertTrue(ObjectUtils.notEqual(null, ""));
        assertTrue(ObjectUtils.notEqual("", null));
        assertFalse(ObjectUtils.notEqual("", ""));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, Boolean.FALSE));
    }

    @Test
    void testRequireNonEmptyOneArg() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("");
            }
        });
    }

    @Test
    void testRequireNonEmptyTwoArg() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc", "msg"));
        final NullPointerException npe = assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null, "myMessage");
            }
        });
        assertEquals("myMessage", npe.getMessage());
        final IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("", "myMessage");
            }
        });
        assertEquals("myMessage", iae.getMessage());
    }

    @Test
    void testToStringObject() {
        assertEquals("", ObjectUtils.toString(null));
        assertEquals("", ObjectUtils.toString(""));
        assertEquals("bat", ObjectUtils.toString("bat"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testToStringObjectNullStr() {
        assertNull(ObjectUtils.toString((Object) null, (String) null));
        assertEquals("null", ObjectUtils.toString(null, "null"));
        assertEquals("bat", ObjectUtils.toString("bat", "null"));
    }

    @Test
    void testToStringSupplierObjSupplierStr() {
        final Supplier<Object> objSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return null;
            }
        };
        final Supplier<String> strSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "expensive";
            }
        };
        assertEquals("expensive", ObjectUtils.toString(objSupplier, strSupplier));
        assertEquals("expensive", ObjectUtils.toString((Supplier<Object>) null, strSupplier));
        final Supplier<Object> valueSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return "bat";
            }
        };
        assertEquals("bat", ObjectUtils.toString(valueSupplier, strSupplier));
    }

    @Test
    void testToStringObjSupplierStr() {
        final Supplier<String> strSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "expensive";
            }
        };
        assertEquals("expensive", ObjectUtils.toString((Object) null, strSupplier));
        assertEquals("bat", ObjectUtils.toString("bat", strSupplier));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE, strSupplier));
    }

    @Test
    void testWaitIllegalMonitorState() {
        final Object monitor = new Object();
        assertThrows(IllegalMonitorStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.wait(monitor, Duration.ofMillis(1));
            }
        });
    }

    @Test
    void testWaitNegativeDurationThrows() {
        final Object monitor = new Object();
        synchronized (monitor) {
            assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    ObjectUtils.wait(monitor, Duration.ofMillis(-1));
                }
            });
        }
    }

    @Test
    void testWaitCompletesWithinSynchronizedBlock() throws InterruptedException {
        final Object monitor = new Object();
        synchronized (monitor) {
            ObjectUtils.wait(monitor, Duration.ofMillis(1));
        }
        // Reaching here means wait() returned normally after its short timeout.
        assertTrue(true);
    }

    @Test
    void testNullSingletonIsSerializableSingleton() throws Exception {
        assertNotNull(ObjectUtils.NULL);
        final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        final java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);
        oos.writeObject(ObjectUtils.NULL);
        oos.close();
        final java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(baos.toByteArray()));
        final Object result = ois.readObject();
        ois.close();
        assertSame(ObjectUtils.NULL, result);
    }
}
