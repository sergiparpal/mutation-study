/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class FractionAgentTest {

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    @Test
    public void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_overflowOnNegate() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenom_negativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenom_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -1, 1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumerDenom_numeratorOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, Integer.MAX_VALUE, 1);
            }
        });
    }

    @Test
    public void testGetFractionDouble() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_negative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_zero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_nanThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(((double) Integer.MAX_VALUE) + 1.0d);
            }
        });
    }

    @Test
    public void testGetFractionString_simpleWhole() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_yOverZ() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_xYOverZ() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_doubleFormat() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionString_nullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionString_missingSlashThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3 7");
            }
        });
    }

    @Test
    public void testGetFractionString_invalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("abc");
            }
        });
    }

    @Test
    public void testGetReducedFraction() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorNormalized() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFraction_negativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetReducedFraction_minValueDenominatorEvenNumerator() {
        final Fraction f = Fraction.getReducedFraction(2, Integer.MIN_VALUE);
        assertEquals(-1, f.getNumerator());
        assertEquals(1073741824, f.getDenominator());
    }

    @Test
    public void testAbs_positive() {
        final Fraction f = Fraction.getFraction(3, 5);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbs_negative() {
        final Fraction f = Fraction.getFraction(-3, 5);
        final Fraction result = f.abs();
        assertEquals(3, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testAdd() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAdd_zeroIdentity() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertEquals(a, Fraction.ZERO.add(a));
        assertEquals(a, a.add(Fraction.ZERO));
    }

    @Test
    public void testAdd_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                a.add(null);
            }
        });
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                a.add(Fraction.ONE);
            }
        });
    }

    @Test
    public void testSubtract() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtract_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                a.subtract(null);
            }
        });
    }

    @Test
    public void testMultiplyBy() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction result = a.multiplyBy(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyBy_zero() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertSame(Fraction.ZERO, a.multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyBy_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                a.multiplyBy(null);
            }
        });
    }

    @Test
    public void testDivideBy() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.divideBy(b);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideBy_zeroThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                a.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideBy_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                a.divideBy(null);
            }
        });
    }

    @Test
    public void testInvert() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction result = f.invert();
        assertEquals(7, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testInvert_negative() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction result = f.invert();
        assertEquals(-7, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvert_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    @Test
    public void testNegate() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction result = f.negate();
        assertEquals(-3, result.getNumerator());
        assertEquals(7, result.getDenominator());
    }

    @Test
    public void testNegate_minValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    @Test
    public void testPow_one() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPow_zero() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(Fraction.ONE, f.pow(0));
    }

    @Test
    public void testPow_positive() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPow_negative() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPow_minValue() {
        final Fraction result = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testReduce() {
        final Fraction f = Fraction.getFraction(2, 4);
        final Fraction result = f.reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduce_alreadyReducedReturnsSame() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduce_zeroNumerator() {
        final Fraction f = Fraction.getFraction(0, 5);
        final Fraction result = f.reduce();
        assertEquals(Fraction.ZERO, result);
    }

    @Test
    public void testCompareTo_equalValues() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareTo_sameInstance() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareTo_lessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareTo_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                a.compareTo(null);
            }
        });
    }

    @Test
    public void testEquals() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        final Fraction c = Fraction.getFraction(2, 4);
        assertTrue(a.equals(b));
        assertFalse(a.equals(c));
        assertFalse(a.equals(null));
        assertFalse(a.equals("1/2"));
        assertTrue(a.equals(a));
    }

    @Test
    public void testHashCode() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testHashCode_differentForUnequalFractions() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.5f, Fraction.getFraction(1, 2).floatValue(), 0.0f);
    }

    @Test
    public void testDoubleValue() {
        assertEquals(0.5d, Fraction.getFraction(1, 2).doubleValue(), 0.0d);
    }

    @Test
    public void testGetProperNumerator() {
        assertEquals(3, Fraction.getFraction(7, 4).getProperNumerator());
        assertEquals(3, Fraction.getFraction(-7, 4).getProperNumerator());
        assertEquals(0, Fraction.getFraction(8, 4).getProperNumerator());
    }

    @Test
    public void testGetProperWhole() {
        assertEquals(1, Fraction.getFraction(7, 4).getProperWhole());
        assertEquals(-1, Fraction.getFraction(-7, 4).getProperWhole());
    }

    @Test
    public void testToString() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toString());
        // cached value should be stable across calls
        assertSame(f.toString(), f.toString());
    }

    @Test
    public void testToProperString() {
        assertEquals("0", Fraction.getFraction(0, 5).toProperString());
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToProperString_minValueNumerator() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertEquals(String.valueOf(Integer.MIN_VALUE), f.toProperString());
    }
}
