/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            return source;
        }
    }

    private static final class UpperCaseFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new UpperCaseFormat();
        }
    }

    private static final class RepeatFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final int count;

        RepeatFormat(final int count) {
            this.count = count;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            for (int i = 0; i < count; i++) {
                toAppendTo.append(String.valueOf(obj));
            }
            return toAppendTo;
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            return source;
        }
    }

    private static final class RepeatFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new RepeatFormat(Integer.parseInt(arguments.trim()));
        }
    }

    private Map<String, FormatFactory> registryWithUpperAndRepeat() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        registry.put("repeat", new RepeatFormatFactory());
        return registry;
    }

    @Test
    void testSimplePatternWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}");
        assertEquals("{0} and {1}", emf.toPattern());
        assertEquals("a and b", emf.format(new Object[] {"a", "b"}));
    }

    @Test
    void testCustomFormatFactory() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registryWithUpperAndRepeat());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    void testCustomFormatFactoryWithStyleArgument() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,repeat,3}", registryWithUpperAndRepeat());
        assertEquals("xxx", emf.format(new Object[] {"x"}));
        assertEquals("{0,repeat,3}", emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsBackToBuiltInFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, registryWithUpperAndRepeat());
        assertEquals("1,234", emf.format(new Object[] {1234}));
        assertEquals("{0,number}", emf.toPattern());
    }

    @Test
    void testQuotedLiteralBraceIsNotTreatedAsArgument() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' {0}", registryWithUpperAndRepeat());
        assertEquals("{0} X", emf.format(new Object[] {"X"}));
    }

    @Test
    void testWhitespaceAroundArgumentIndexAndFormatNameIsTrimmed() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 ,upper}", registryWithUpperAndRepeat());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testTrailingWhitespaceAfterFormatNameIsTrimmed() {
        // Per the class Javadoc: "format-name and format-style values are trimmed
        // of surrounding whitespace in the manner of MessageFormat." With no
        // format-style section, trailing whitespace before the closing brace
        // should still be trimmed off the format name so the registered
        // factory is found.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper }", registryWithUpperAndRepeat());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testApplyPatternCanBeReapplied() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", registryWithUpperAndRepeat());
        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testNullLocaleFallsBackToDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US, new HashMap<String, FormatFactory>());
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US, new HashMap<String, FormatFactory>());
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testNotEqualsForDifferentPattern() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}");
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{1}");
        assertFalse(a.equals(b));
    }

    @Test
    void testNotEqualsForDifferentRegistryContents() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", new HashMap<String, FormatFactory>());
        final Map<String, FormatFactory> registry2 = new HashMap<String, FormatFactory>();
        registry2.put("upper", new UpperCaseFormatFactory());
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", registry2);
        assertFalse(a.equals(b));
    }

    @Test
    void testNotEqualsWithPlainMessageFormat() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}");
        final MessageFormat plain = new MessageFormat("{0}");
        assertFalse(a.equals(plain));
    }

    @Test
    void testEqualsIsReflexiveAndNullSafe() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}");
        assertTrue(a.equals(a));
        assertFalse(a.equals(null));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testUnterminatedQuotedStringThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = registryWithUpperAndRepeat();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("it's broken", registry);
            }
        });
        assertNotNull(ex.getMessage());
    }

    @Test
    void testUnterminatedArgumentIndexThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = registryWithUpperAndRepeat();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", registry);
            }
        });
    }

    @Test
    void testNonNumericArgumentIndexThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = registryWithUpperAndRepeat();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0a}", registry);
            }
        });
    }

    @Test
    void testUnterminatedFormatDescriptionThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = registryWithUpperAndRepeat();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", registry);
            }
        });
    }

    @Test
    void testNullRegistryDelegatesToMessageFormatBuiltIns() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, null);
        assertEquals("1,234", emf.format(new Object[] {1234}));
    }
}
