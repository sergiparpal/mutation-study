/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
public class NumberUtilsAgentTest {

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("12.5"), NumberUtils.createBigDecimal("12.5"));
    }

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("#FF"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerNegative() {
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongValid() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("  ");
            }
        });
    }

    @Test
    public void testCreateNumberEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
    }

    @Test
    public void testCreateNumberInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLong() {
        final Number n = NumberUtils.createNumber("1234567890123");
        assertTrue(n instanceof Long);
        assertEquals(1234567890123L, n.longValue());
    }

    @Test
    public void testCreateNumberBigInteger() {
        final String huge = "123456789012345678901234567890";
        final Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberInvalidLongSuffixThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    @Test
    public void testCreateNumberDecimal() {
        final Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float || n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    public void testCreateNumberMalformedDoubleExponentThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.2eE3");
            }
        });
    }

    @Test
    public void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    public void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("1.5"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
    }

    @Test
    public void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("1.2.3"));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
    }

    @Test
    public void testIsDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits(null));
    }

    @Test
    public void testIsParsable() {
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("123"));
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("1.5L"));
    }

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxByteThreeParam() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    public void testMaxDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMaxDoubleThreeParam() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    public void testMaxFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
    }

    @Test
    public void testMaxIntThreeParam() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxLongThreeParam() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMaxShortThreeParam() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    public void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteThreeParam() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    public void testMinDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("abc", (byte) 9));
    }

    @Test
    public void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleFromBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    public void testToDoubleFromStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("abc", 9));
    }

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("abc", 9L));
    }

    @Test
    public void testToScaledBigDecimalDefault() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
    }

    @Test
    public void testToScaledBigDecimalWithScaleAndRounding() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.255"), 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("1.26"), result);
    }

    @Test
    public void testToScaledBigDecimalNullRoundingDefaultsToHalfEven() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null);
        assertEquals(new BigDecimal("1.24"), result);
    }

    @Test
    public void testToScaledBigDecimalFromDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("8.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(8.5d)));
    }

    @Test
    public void testToScaledBigDecimalFromFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("8.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(8.5f)));
    }

    @Test
    public void testToScaledBigDecimalFromString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("8.50"), NumberUtils.toScaledBigDecimal("8.5"));
    }

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("abc", (short) 9));
    }

    @Test
    public void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testPublicConstructor() {
        assertEquals(NumberUtils.class, new NumberUtils().getClass());
    }
}
