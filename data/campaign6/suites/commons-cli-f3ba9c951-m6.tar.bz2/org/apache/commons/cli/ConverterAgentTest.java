/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class ConverterAgentTest {

    @Test
    void testDefaultReturnsInputUnchanged() {
        final Object result = Converter.DEFAULT.apply("hello");
        assertEquals("hello", result);
        assertSame("hello", result);
    }

    @Test
    void testDefaultWithNull() {
        final Object result = Converter.DEFAULT.apply(null);
        assertEquals(null, result);
    }

    @Test
    void testClassConvertsExistingClass() throws ClassNotFoundException {
        final Class<?> cls = Converter.CLASS.apply(ConverterAgentTest.class.getName());
        assertEquals(ConverterAgentTest.class, cls);
    }

    @Test
    void testClassThrowsOnUnknownName() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.Class");
            }
        });
    }

    @Test
    void testFileConvertsPathString() {
        final File file = Converter.FILE.apply("some-file.txt");
        assertEquals(new File("some-file.txt"), file);
    }

    @Test
    void testFileThrowsOnNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathConvertsString() {
        final Path path = Converter.PATH.apply("some-path.txt");
        assertEquals(new File("some-path.txt").toPath(), path);
    }

    @Test
    void testPathThrowsOnInvalidPath() {
        assertThrows(InvalidPathException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("\u0000invalid");
            }
        });
    }

    @Test
    void testNumberConvertsIntegerLikeStringToLong() {
        final Number number = Converter.NUMBER.apply("15");
        assertTrue(number instanceof Long);
        assertEquals(15L, number.longValue());
    }

    @Test
    void testNumberConvertsDecimalStringToDouble() {
        final Number number = Converter.NUMBER.apply("1.5");
        assertTrue(number instanceof Double);
        assertEquals(1.5d, number.doubleValue(), 0.0d);
    }

    @Test
    void testNumberThrowsOnNonNumericString() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not a number");
            }
        });
    }

    @Test
    void testNumberThrowsOnEmptyString() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("");
            }
        });
    }

    @Test
    void testObjectCreatesNewInstance() throws ReflectiveOperationException {
        final Object instance = Converter.OBJECT.apply(Date.class.getName());
        assertTrue(instance instanceof Date);
    }

    @Test
    void testObjectThrowsOnUninstantiableClass() {
        assertThrows(ReflectiveOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply(NotInstantiable.class.getName());
            }
        });
    }

    @Test
    void testObjectThrowsOnUnknownClassName() {
        assertThrows(ReflectiveOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.Class");
            }
        });
    }

    @Test
    void testUrlConvertsValidString() throws MalformedURLException {
        final String urlString = "https://commons.apache.org";
        final URL url = Converter.URL.apply(urlString);
        assertEquals(new URL(urlString), url);
    }

    @Test
    void testUrlThrowsOnMalformedString() {
        assertThrows(MalformedURLException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("Malformed-url");
            }
        });
    }

    @Test
    void testDateConvertsValidFormattedString() throws ParseException {
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final String dateString = new java.text.SimpleDateFormat(pattern, java.util.Locale.ENGLISH).format(new Date(0L));
        final Date date = Converter.DATE.apply(dateString);
        assertNotNull(date);
    }

    @Test
    void testDateThrowsOnInvalidString() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date");
            }
        });
    }

    @Test
    void testCustomConverterImplementation() throws Exception {
        final Converter<Integer, Exception> doubler = new Converter<Integer, Exception>() {
            @Override
            public Integer apply(final String string) throws Exception {
                return Integer.valueOf(string) * 2;
            }
        };
        assertEquals(Integer.valueOf(10), doubler.apply("5"));
    }

    @Test
    void testCustomConverterPropagatesCheckedException() {
        final Converter<String, ParseException> failing = new Converter<String, ParseException>() {
            @Override
            public String apply(final String string) throws ParseException {
                throw new ParseException("boom", 0);
            }
        };
        final ParseException thrown = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                failing.apply("x");
            }
        });
        assertEquals("boom", thrown.getMessage());
    }

    /** Has no public constructor, so instantiation via reflection must fail. */
    public static final class NotInstantiable {
        private NotInstantiable() {
        }
    }
}
