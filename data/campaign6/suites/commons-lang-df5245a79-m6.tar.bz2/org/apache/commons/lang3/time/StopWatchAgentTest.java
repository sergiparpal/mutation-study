/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link StopWatch}.
 */
class StopWatchAgentTest {

    @Test
    void testCreate() {
        final StopWatch sw = StopWatch.create();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
        assertEquals(0L, sw.getTime());
    }

    @Test
    void testCreateStarted() {
        final StopWatch sw = StopWatch.createStarted();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertNotNull(sw.getStartInstant());
    }

    @Test
    void testDefaultConstructorHasNullMessage() {
        final StopWatch sw = new StopWatch();
        assertNull(sw.getMessage());
    }

    @Test
    void testMessageConstructor() {
        final StopWatch sw = new StopWatch("myMessage");
        assertEquals("myMessage", sw.getMessage());
        sw.start();
        sw.stop();
        assertTrue(sw.toString().startsWith("myMessage "));
    }

    @Test
    void testStartStopBasic() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        assertFalse(sw.isStarted());
        sw.start();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        Thread.sleep(20);
        sw.stop();
        assertTrue(sw.isStopped());
        assertFalse(sw.isStarted());
        assertTrue(sw.getTime() >= 0L);
        assertTrue(sw.getNanoTime() > 0L);
    }

    @Test
    void testUnstartedGetTimeIsZero() {
        final StopWatch sw = new StopWatch();
        assertEquals(0L, sw.getTime());
        assertEquals(0L, sw.getNanoTime());
        assertEquals(Duration.ZERO, sw.getDuration());
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::start);
        assertEquals("Stopwatch already started.", e.getMessage());
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::start);
        assertEquals("Stopwatch must be reset before being restarted.", e.getMessage());
    }

    @Test
    void testStopBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::stop);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testStopTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, sw::stop);
    }

    @Test
    void testSuspendBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::suspend);
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, sw::suspend);
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::resume);
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    void testSuspendResume() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        sw.start();
        Thread.sleep(10);
        sw.suspend();
        assertTrue(sw.isSuspended());
        assertTrue(sw.isStarted());
        final long suspendedTime = sw.getTime();
        Thread.sleep(20);
        // Time should not advance while suspended.
        assertEquals(suspendedTime, sw.getTime());
        sw.resume();
        assertFalse(sw.isSuspended());
        assertTrue(sw.isStarted());
        Thread.sleep(10);
        sw.stop();
        assertTrue(sw.getTime() >= suspendedTime);
    }

    @Test
    void testSplitBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::split);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testSplitAfterSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, sw::split);
    }

    @Test
    void testGetSplitTimeBeforeSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::getSplitNanoTime);
        assertEquals("Stopwatch must be split to get the split time.", e.getMessage());
    }

    @Test
    void testUnsplitBeforeSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::unsplit);
        assertEquals("Stopwatch has not been split.", e.getMessage());
    }

    @Test
    void testSplitAndUnsplit() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        sw.start();
        Thread.sleep(10);
        sw.split();
        final long splitTime = sw.getSplitTime();
        assertTrue(splitTime >= 0L);
        assertEquals(1, sw.getSplits().size());
        assertEquals("0", sw.getSplits().get(0).getLabel());
        assertEquals(Duration.ofNanos(sw.getSplitNanoTime()), sw.getSplits().get(0).getDuration());
        sw.unsplit();
        assertEquals(0, sw.getSplits().size());
        // After unsplit, the watch continues running and the time keeps advancing.
        assertTrue(sw.isStarted());
        sw.stop();
        assertTrue(sw.getTime() >= splitTime);
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split("label1");
        final List<StopWatch.Split> splits = sw.getSplits();
        assertEquals(1, splits.size());
        assertEquals("label1", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
        assertTrue(splits.get(0).toString().contains("label1"));
    }

    @Test
    void testGetSplitsIsUnmodifiable() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        final List<StopWatch.Split> splits = sw.getSplits();
        assertThrows(UnsupportedOperationException.class, new Runnable() {
            @Override
            public void run() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        }::run);
    }

    @Test
    void testReset() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.stop();
        sw.reset();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertEquals(0, sw.getSplits().size());
        assertEquals(0L, sw.getTime());
        // Can start again after reset.
        sw.start();
        assertTrue(sw.isStarted());
    }

    @Test
    void testGetStartInstantBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, sw::getStartInstant);
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    void testGetStopInstantBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, sw::getStopInstant);
    }

    @Test
    void testGetStartAndStopInstant() {
        final StopWatch sw = new StopWatch();
        final Instant before = Instant.now();
        sw.start();
        sw.stop();
        final Instant after = Instant.now();
        assertNotNull(sw.getStartInstant());
        assertNotNull(sw.getStopInstant());
        assertFalse(sw.getStartInstant().isBefore(before.minusSeconds(1)));
        assertFalse(sw.getStopInstant().isAfter(after.plusSeconds(1)));
        assertEquals(sw.getStartInstant().toEpochMilli(), sw.getStartTime());
        assertEquals(sw.getStopInstant().toEpochMilli(), sw.getStopTime());
    }

    @Test
    void testGetStopInstantWhileRunningReturnsNull() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertNull(sw.getStopInstant());
    }

    @Test
    void testGetTimeTimeUnit() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        sw.start();
        Thread.sleep(5);
        sw.stop();
        final long nanos = sw.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.convert(nanos, TimeUnit.NANOSECONDS), sw.getTime(TimeUnit.NANOSECONDS));
        assertEquals(nanos / 1000000000L, sw.getTime(TimeUnit.SECONDS));
    }

    @Test
    void testGetDurationMatchesGetNanoTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(Duration.ofNanos(sw.getNanoTime()), sw.getDuration());
    }

    @Test
    void testFormatTimeAndFormatSplitTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        final String splitFormatted = sw.formatSplitTime();
        assertNotNull(splitFormatted);
        assertTrue(splitFormatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
        sw.stop();
        final String formatted = sw.formatTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    void testToStringWithoutMessage() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.formatTime(), sw.toString());
    }

    @Test
    void testToSplitStringWithoutMessage() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertEquals(sw.formatSplitTime(), sw.toSplitString());
    }

    @Test
    void testToSplitStringWithMessage() {
        final StopWatch sw = new StopWatch("msg");
        sw.start();
        sw.split();
        assertEquals("msg " + sw.formatSplitTime(), sw.toSplitString());
    }

    @Test
    void testRunRunnable() {
        final StopWatch sw = new StopWatch();
        final boolean[] called = {false};
        sw.run(new Runnable() {
            @Override
            public void run() {
                called[0] = true;
            }
        });
        assertTrue(called[0]);
        assertTrue(sw.isSuspended());
        assertTrue(sw.getTime() >= 0L);
    }

    @Test
    void testGetSupplier() {
        final StopWatch sw = new StopWatch();
        final String result = sw.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(sw.isSuspended());
    }

    @Test
    void testRunRunnablePropagatesExceptionAndStillSuspends() {
        final StopWatch sw = new StopWatch();
        final RuntimeException thrown = new RuntimeException("boom");
        final RuntimeException caught = assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sw.run(new Runnable() {
                    @Override
                    public void run() {
                        throw thrown;
                    }
                });
            }
        });
        assertSame(thrown, caught);
        assertTrue(sw.isSuspended());
    }

    @Test
    void testGetAfterStopThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        // get()/run() route through startResume(), which rejects a watch left in the STOPPED state.
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sw.get(new java.util.function.Supplier<String>() {
                    @Override
                    public String get() {
                        return "resumed";
                    }
                });
            }
        });
    }
}
