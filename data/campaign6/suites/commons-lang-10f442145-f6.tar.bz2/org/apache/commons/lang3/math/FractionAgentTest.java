/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class FractionAgentTest {

    // ---------------------------------------------------------------
    // getFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionTwoArgsBasic() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsNegativeSignMovesToNumerator() {
        final Fraction f = Fraction.getFraction(3, -4);
        assertEquals(-3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionTwoArgsMinValueNumeratorWithNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    public void testGetFractionTwoArgsMinValueDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, Integer.MIN_VALUE);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(int whole, int numerator, int denominator)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionThreeArgsBasic() {
        final Fraction f = Fraction.getFraction(1, 3, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 4);
        assertEquals(-7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -3, 4);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, -4);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, 0);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(double)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionDoubleOneHalf() {
        assertEquals(Fraction.ONE_HALF, Fraction.getFraction(0.5));
    }

    @Test
    public void testGetFractionDoubleOneThird() {
        final Fraction f = Fraction.getFraction(1.0 / 3.0);
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.5);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((double) Integer.MAX_VALUE + 10000.0);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFraction(String)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionStringWholeNumber() {
        final Fraction f = Fraction.getFraction("7");
        assertEquals(7, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringSimpleFraction() {
        final Fraction f = Fraction.getFraction("3/4");
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeAndFraction() {
        final Fraction f = Fraction.getFraction("1 3/4");
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringInvalidWholeFractionFormatThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3");
            }
        });
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1/0");
            }
        });
    }

    @Test
    public void testGetFractionStringGarbageThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // getReducedFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetReducedFractionReduces() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionNormalizesZero() {
        assertSame(Fraction.ZERO, Fraction.getReducedFraction(0, 5));
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetReducedFractionBothNegative() {
        final Fraction f = Fraction.getReducedFraction(-4, -8);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionMinValueDenominatorEvenNumerator() {
        final Fraction f = Fraction.getReducedFraction(4, Integer.MIN_VALUE);
        assertEquals(-1, f.getNumerator());
        assertEquals(536870912, f.getDenominator());
    }

    // ---------------------------------------------------------------
    // abs / negate / invert
    // ---------------------------------------------------------------

    @Test
    public void testAbsOnPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsOnNegativeFlipsNumerator() {
        final Fraction f = Fraction.getFraction(-3, 4);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(4, abs.getDenominator());
    }

    @Test
    public void testNegate() {
        final Fraction f = Fraction.getFraction(3, 4).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testNegateMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    @Test
    public void testInvert() {
        final Fraction f = Fraction.getFraction(3, 4).invert();
        assertEquals(4, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-3, 4).invert();
        assertEquals(-4, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    // ---------------------------------------------------------------
    // add / subtract
    // ---------------------------------------------------------------

    @Test
    public void testAdd() {
        final Fraction f = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(5, f.getNumerator());
        assertEquals(6, f.getDenominator());
    }

    @Test
    public void testAddNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.getFraction(1, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                a.add(b);
            }
        });
    }

    @Test
    public void testSubtract() {
        final Fraction f = Fraction.getFraction(1, 3).subtract(Fraction.getFraction(1, 2));
        assertEquals(-1, f.getNumerator());
        assertEquals(6, f.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.subtract(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // multiplyBy / divideBy
    // ---------------------------------------------------------------

    @Test
    public void testMultiplyBy() {
        final Fraction f = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        assertSame(Fraction.ZERO, Fraction.getFraction(2, 3).multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyByNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                a.multiplyBy(b);
            }
        });
    }

    @Test
    public void testDivideBy() {
        final Fraction f = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 4));
        assertEquals(2, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.divideBy(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // pow
    // ---------------------------------------------------------------

    @Test
    public void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3).pow(2);
        assertEquals(4, f.getNumerator());
        assertEquals(9, f.getDenominator());
    }

    @Test
    public void testPowNegativeBase() {
        final Fraction f = Fraction.getFraction(-2, 3).pow(3);
        assertEquals(-8, f.getNumerator());
        assertEquals(27, f.getDenominator());
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowZeroReturnsOne() {
        assertSame(Fraction.ONE, Fraction.getFraction(2, 3).pow(0));
    }

    @Test
    public void testPowNegativePower() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-1);
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testPowMinValuePowerDoesNotThrowForOne() {
        final Fraction f = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    // ---------------------------------------------------------------
    // reduce
    // ---------------------------------------------------------------

    @Test
    public void testReduceSimplifies() {
        final Fraction f = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceNonCanonicalZeroReturnsZeroConstant() {
        assertSame(Fraction.ZERO, Fraction.getFraction(0, 5).reduce());
    }

    // ---------------------------------------------------------------
    // compareTo
    // ---------------------------------------------------------------

    @Test
    public void testCompareToGreater() {
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 3)) > 0);
    }

    @Test
    public void testCompareToLess() {
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
    }

    @Test
    public void testCompareToEqualValueDifferentRepresentation() {
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareToNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.compareTo(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsSameValueSameRepresentation() {
        assertTrue(Fraction.getFraction(1, 2).equals(Fraction.getFraction(1, 2)));
    }

    @Test
    public void testEqualsEqualValueDifferentRepresentationIsFalse() {
        assertFalse(Fraction.getFraction(1, 2).equals(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(Fraction.getFraction(1, 2).equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        assertFalse(Fraction.getFraction(1, 2).equals("1/2"));
    }

    @Test
    public void testHashCodeConsistentForEqualFractions() {
        assertEquals(Fraction.getFraction(1, 2).hashCode(), Fraction.getFraction(1, 2).hashCode());
    }

    // ---------------------------------------------------------------
    // toString / toProperString
    // ---------------------------------------------------------------

    @Test
    public void testToString() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
    }

    @Test
    public void testToStringNegative() {
        assertEquals("-3/4", Fraction.getFraction(-3, 4).toString());
    }

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringNegativeImproperFraction() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperStringZeroNumerator() {
        assertEquals("0", Fraction.getFraction(0, 5).toProperString());
    }

    @Test
    public void testToProperStringWholeOne() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperStringWholeMinusOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    // ---------------------------------------------------------------
    // getProperNumerator / getProperWhole
    // ---------------------------------------------------------------

    @Test
    public void testGetProperWholeAndNumeratorPositive() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperWholeAndNumeratorNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    // ---------------------------------------------------------------
    // Number conversions
    // ---------------------------------------------------------------

    @Test
    public void testIntValueTruncatesTowardZero() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
    }

    @Test
    public void testDoubleValue() {
        assertEquals(1.0 / 3.0, Fraction.getFraction(1, 3).doubleValue(), 0.0000001);
    }

    @Test
    public void testFloatValue() {
        assertEquals(1.0f / 3.0f, Fraction.getFraction(1, 3).floatValue(), 0.0000001f);
    }

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testConstants() {
        assertNotNull(Fraction.ZERO);
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
    }
}
