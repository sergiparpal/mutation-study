/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    // ------------------------------------------------------------------
    // compare
    // ------------------------------------------------------------------

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ------------------------------------------------------------------
    // createBigDecimal
    // ------------------------------------------------------------------

    @Test
    void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ------------------------------------------------------------------
    // createBigInteger
    // ------------------------------------------------------------------

    @Test
    void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("FF", 16), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("-FF", 16), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
    }

    @Test
    void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ------------------------------------------------------------------
    // createDouble / createFloat / createInteger / createLong
    // ------------------------------------------------------------------

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createFloat("abc");
            }
        });
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(10), NumberUtils.createInteger("10"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(10L), NumberUtils.createLong("10"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createNumber
    // ------------------------------------------------------------------

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("  ");
            }
        });
    }

    @Test
    void testCreateNumberInteger() {
        assertEquals(Integer.valueOf(1), NumberUtils.createNumber("1"));
        assertTrue(NumberUtils.createNumber("1") instanceof Integer);
    }

    @Test
    void testCreateNumberLong() {
        final Number n = NumberUtils.createNumber("" + ((long) Integer.MAX_VALUE + 1L));
        assertTrue(n instanceof Long);
    }

    @Test
    void testCreateNumberBigInteger() {
        final Number n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n instanceof BigInteger);
    }

    @Test
    void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("10L");
        assertTrue(n instanceof Long);
        assertEquals(10L, n.longValue());
    }

    @Test
    void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    void testCreateNumberBigDecimal() {
        final Number n = NumberUtils.createNumber("1.23456789012345678901234");
        assertTrue(n instanceof BigDecimal);
    }

    @Test
    void testCreateNumberInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("1.2.3");
            }
        });
    }

    @Test
    void testCreateNumberInvalidLongSuffixThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    // ------------------------------------------------------------------
    // isCreatable / isNumber / isDigits / isParsable
    // ------------------------------------------------------------------

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @Test
    void testIsNumberDeprecatedMatchesIsCreatable() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.5e-5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertFalse(NumberUtils.isParsable("1.5L"));
    }

    // ------------------------------------------------------------------
    // max / min - arrays
    // ------------------------------------------------------------------

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMaxDoubleArrayWithNaN() {
        final double[] arr = { 1.0, Double.NaN, 3.0 };
        assertTrue(Double.isNaN(NumberUtils.max(arr)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    void testMinDoubleArrayWithNaN() {
        final double[] arr = { 1.0, Double.NaN, 3.0 };
        assertTrue(Double.isNaN(NumberUtils.min(arr)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    void testMaxFloatArrayWithNaN() {
        final float[] arr = { 1.0f, Float.NaN, 3.0f };
        assertTrue(Float.isNaN(NumberUtils.max(arr)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    void testMinFloatArrayWithNaN() {
        final float[] arr = { 1.0f, Float.NaN, 3.0f };
        assertTrue(Float.isNaN(NumberUtils.min(arr)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(1, 9, 5));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 9, 5));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 5L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 5L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 5));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 5));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new short[0]);
            }
        });
    }

    // ------------------------------------------------------------------
    // max / min - three param
    // ------------------------------------------------------------------

    @Test
    void testMaxMinThreeParamByte() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
    }

    @Test
    void testMaxMinThreeParamDoubleNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0, Double.NaN, 2.0)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0, Double.NaN, 2.0)));
    }

    @Test
    void testMaxMinThreeParamFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    void testMaxMinThreeParamInt() {
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(1, NumberUtils.min(1, 2, 3));
    }

    @Test
    void testMaxMinThreeParamLong() {
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
    }

    @Test
    void testMaxMinThreeParamShort() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
    }

    // ------------------------------------------------------------------
    // to<Type>(String[, default])
    // ------------------------------------------------------------------

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("abc", (byte) 1));
    }

    @Test
    void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("abc", 1.1d), 0.0d);
    }

    @Test
    void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("abc", 1.1f), 0.0f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt("abc", 1));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong("abc", 1L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort("abc", (short) 1));
    }

    // ------------------------------------------------------------------
    // toScaledBigDecimal
    // ------------------------------------------------------------------

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.230"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.23"), 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(2, NumberUtils.toScaledBigDecimal(Float.valueOf(1.235f)).scale());
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
    }

    // ------------------------------------------------------------------
    // constants
    // ------------------------------------------------------------------

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals(Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals(Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    // ------------------------------------------------------------------
    // constructor
    // ------------------------------------------------------------------

    @Test
    void testConstructorExists() {
        assertSame(NumberUtils.class, new NumberUtils().getClass());
    }
}
