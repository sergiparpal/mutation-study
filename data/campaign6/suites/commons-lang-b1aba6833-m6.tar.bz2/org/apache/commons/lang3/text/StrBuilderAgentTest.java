/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    @Test
    public void testDefaultConstructor() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructorZeroOrNegativeUsesDefault() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
        assertEquals(64, new StrBuilder(64).capacity());
    }

    @Test
    public void testStringConstructorNullTreatedAsBlank() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testStringConstructorCopiesContent() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(' ').append(false);
        assertEquals("true false", sb.toString());
    }

    @Test
    public void testAppendChar() {
        final StrBuilder sb = new StrBuilder();
        sb.append('A').append('B');
        assertEquals("AB", sb.toString());
    }

    @Test
    public void testAppendCharArrayNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'x', 'y', 'z'});
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStartIndex() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = {'a', 'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 4, 1));
    }

    @Test
    public void testAppendCharArrayRangeInvalidLength() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = {'a', 'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 1, 3));
    }

    @Test
    public void testAppendCharBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello".toCharArray()));
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendCharBufferNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharBuffer) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendCharSequenceDispatchesSubtypes() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) new StrBuilder("inner"));
        sb.append((CharSequence) new StringBuilder("sb"));
        sb.append((CharSequence) new StringBuffer("buf"));
        assertEquals("innersbbuf", sb.toString());
    }

    @Test
    public void testAppendCharSequenceNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abcdef", 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5d).append('|').append(2.5f).append('|').append(3).append('|').append(4L);
        assertEquals("1.5|2.5|3|4", sb.toString());
    }

    @Test
    public void testAppendObjectNullUsesAppendNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendObjectNonNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) Integer.valueOf(42));
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        final StrBuilder sb = new StrBuilder("foo");
        final StrBuilder other = new StrBuilder("bar");
        sb.append(other);
        assertEquals("foobar", sb.toString());
    }

    @Test
    public void testAppendStrBuilderNull() {
        final StrBuilder sb = new StrBuilder("foo");
        sb.append((StrBuilder) null);
        assertEquals("foo", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, 0, 10));
    }

    @Test
    public void testAppendStringNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendStringRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 1, 10));
    }

    @Test
    public void testAppendFormatString() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 5);
        assertEquals("x-5", sb.toString());
    }

    @Test
    public void testAppendStringBufferAndRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello"));
        sb.append(new StringBuffer("world"), 1, 3);
        assertEquals("helloorl", sb.toString());
    }

    @Test
    public void testAppendStringBuilderAndRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("hello"));
        sb.append(new StringBuilder("world"), 0, 2);
        assertEquals("hellowo", sb.toString());
    }

    @Test
    public void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = new ArrayList<>(Arrays.asList("a", "b", "c"));
        sb.appendAll(list);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterableNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("1", "2");
        sb.appendAll(list.iterator());
        assertEquals("12", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll();
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(7, 5, '0');
        assertEquals("00007", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncatesLeft() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abcdef", 3, ' ');
        assertEquals("def", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftZeroWidthNoEffect() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abc", 0, ' ');
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendFixedWidthPadLeftNullObjectUsesNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NA");
        sb.appendFixedWidthPadLeft((Object) null, 4, '*');
        assertEquals("**NA", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(7, 5, '0');
        assertEquals("70000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncatesRight() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("abcdef", 3, ' ');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendln() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln("line").appendln(1).appendln(true);
        assertEquals("line\n1\ntrue\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultsToSystemLineSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineCustom() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        assertEquals("<br>", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("<br>", sb.toString());
    }

    @Test
    public void testAppendNullNoNullTextIsNoOp() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendPaddingNegativeNoAppend() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(-3, '*');
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendPaddingPositive() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals(0, sb.length());
        sb.append("a").appendSeparator(',').append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharWithDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.append("x");
        sb.appendSeparator(',', ';');
        assertEquals(";x,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNullHasNoEffect() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator("-", i);
            sb.append(i);
        }
        assertEquals("0-1-2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardAndDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        sb.append("x=1");
        assertEquals(" wherex=1", sb.toString());
        sb.appendSeparator(" and", " where");
        assertEquals(" wherex=1 and", sb.toString());
    }

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.toString());
    }

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder target = new StringBuilder();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendToStringBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuffer target = new StringBuffer();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendToCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hi");
        final CharBuffer target = CharBuffer.allocate(10);
        sb.appendTo(target);
        target.flip();
        assertEquals("hi", target.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c").iterator(), "-");
        assertEquals("a-b-c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, "/");
        assertEquals("a/b/c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArrayEmptyIsNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[0], "/");
        assertEquals(0, sb.length());
    }

    @Test
    public void testAsReaderReadsContent() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final Reader reader = sb.asReader();
        final char[] buf = new char[10];
        final int read = reader.read(buf, 0, 10);
        assertEquals(5, read);
        assertEquals("hello", new String(buf, 0, 5));
        assertEquals(-1, reader.read(buf, 0, 10));
    }

    @Test
    public void testAsReaderSingleCharAndMarkReset() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        reader.mark(0);
        assertEquals('b', reader.read());
        assertEquals(-1, reader.read());
        reader.reset();
        assertEquals('b', reader.read());
    }

    @Test
    public void testAsReaderInvalidRangeThrows() {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        final char[] buf = new char[2];
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, -1, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, 0, 5));
    }

    @Test
    public void testAsReaderZeroLenReadReturnsZero() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        assertEquals(0, reader.read(new char[2], 0, 0));
    }

    @Test
    public void testAsReaderSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final long skipped = reader.skip(3);
        assertEquals(3, skipped);
        assertEquals('d', reader.read());
    }

    @Test
    public void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        assertEquals("a", tokenizer.next());
        assertEquals("b", tokenizer.next());
        assertEquals("c", tokenizer.next());
        assertFalse(tokenizer.hasNext());
    }

    @Test
    public void testAsWriterWritesIntoBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("hello");
        writer.write(new char[] {'!', '!'});
        writer.write('?');
        assertEquals("hello!!?", sb.toString());
    }

    @Test
    public void testBuildReturnsString() {
        final StrBuilder sb = new StrBuilder("value");
        assertEquals("value", sb.build());
    }

    @Test
    public void testCapacity() {
        final StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
    }

    @Test
    public void testCharAtBoundaries() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(3));
    }

    @Test
    public void testClearResetsSizeAndBuffer() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final int capacityBefore = sb.capacity();
        sb.clear();
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
        assertEquals(capacityBefore, sb.capacity());
    }

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.contains('e'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains("wor"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.contains(StrMatcher.charMatcher('e')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testDeleteRange() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.delete(5, 11);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testDeleteRangeEndIndexTooLargeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("hello");
        sb.delete(2, 100);
        assertEquals("he", sb.toString());
    }

    @Test
    public void testDeleteRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(4, 2));
    }

    @Test
    public void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.deleteAll('a');
        assertEquals("bnn", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("one two one two one");
        sb.deleteAll("one");
        assertEquals(" two  two ", sb.toString());
    }

    @Test
    public void testDeleteAllStringNullIsNoOp() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(10));
    }

    @Test
    public void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.deleteFirst('a');
        assertEquals("bnana", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("one two one");
        sb.deleteFirst("one");
        assertEquals(" two one", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    @Test
    public void testEndsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith("way too long to match"));
    }

    @Test
    public void testEnsureCapacityGrowsBuffer() {
        final StrBuilder sb = new StrBuilder(4);
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testEnsureCapacityNoShrink() {
        final StrBuilder sb = new StrBuilder(50);
        sb.ensureCapacity(5);
        assertEquals(50, sb.capacity());
    }

    @Test
    public void testEqualsObjectAndStrBuilder() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equals((Object) sb2));
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals((StrBuilder) null));
        assertFalse(sb1.equals("abc"));
        assertTrue(sb1.equals(sb1));
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder sb1 = new StrBuilder("ABC");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertTrue(sb1.equalsIgnoreCase(sb1));
        assertFalse(sb1.equalsIgnoreCase(new StrBuilder("abcd")));
    }

    @Test
    public void testGetCharsNoArgCreatesArray() {
        final StrBuilder sb = new StrBuilder("hello");
        final char[] result = sb.getChars((char[]) null);
        assertArrayEquals("hello".toCharArray(), result);
    }

    @Test
    public void testGetCharsNoArgReusesTooSmallArrayReplaced() {
        final StrBuilder sb = new StrBuilder("hello");
        final char[] tooSmall = new char[2];
        final char[] result = sb.getChars(tooSmall);
        assertArrayEquals("hello".toCharArray(), result);
    }

    @Test
    public void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("hello world");
        final char[] dest = new char[5];
        sb.getChars(0, 5, dest, 0);
        assertArrayEquals("hello".toCharArray(), dest);
    }

    @Test
    public void testGetCharsRangeInvalid() {
        final StrBuilder sb = new StrBuilder("hello");
        final char[] dest = new char[10];
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 3, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 100, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(3, 1, dest, 0));
    }

    @Test
    public void testGetSetNewLineText() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        sb.setNewLineText("X");
        assertEquals("X", sb.getNewLineText());
        sb.setNewLineText(null);
        assertNull(sb.getNewLineText());
    }

    @Test
    public void testGetSetNullText() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(2, sb.indexOf('l'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharFromIndex() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(3, sb.indexOf('l', 3));
        assertEquals(-1, sb.indexOf('l', 100));
        assertEquals(2, sb.indexOf('l', -5));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertEquals(6, sb.indexOf("world"));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringFromIndex() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.indexOf("abc", 1));
    }

    @Test
    public void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertEquals(3, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testIndexOfMatcherFromIndex() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertEquals(-1, sb.indexOf(StrMatcher.charSetMatcher("0123456789"), 100));
    }

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, true);
        assertEquals("atrueb", sb.toString());
        sb.insert(0, false);
        assertEquals("falseatrueb", sb.toString());
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (char[]) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("ae");
        sb.insert(1, new char[] {'w', 'b', 'c', 'x'}, 1, 2);
        assertEquals("abce", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder("ab");
        final char[] chars = {'x', 'y'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, 0, 5));
    }

    @Test
    public void testInsertDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 1L);
        sb.insert(0, 2);
        sb.insert(0, 3.0f);
        sb.insert(0, 4.0d);
        assertEquals("4.03.021", sb.toString());
    }

    @Test
    public void testInsertObjectNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("X");
        sb.insert(1, (Object) null);
        assertEquals("aXb", sb.toString());
    }

    @Test
    public void testInsertObject() {
        final StrBuilder sb = new StrBuilder("a");
        sb.insert(1, (Object) Integer.valueOf(9));
        assertEquals("a9", sb.toString());
    }

    @Test
    public void testInsertStringNullWithoutNullTextNoChange() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (String) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testInsertStringInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("ab");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, "x"));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(3, "x"));
    }

    @Test
    public void testIsEmptyAndIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append('a');
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(3, sb.lastIndexOf('l'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharFromIndex() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(2, sb.lastIndexOf('l', 2));
        assertEquals(-1, new StrBuilder("").lastIndexOf('a', 5));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("hel", sb.leftString(3));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
        assertEquals("hello", sb.leftString(100));
    }

    @Test
    public void testLength() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(5, sb.length());
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertEquals("hello", sb.midString(0, 5));
        assertEquals("world", sb.midString(6, 100));
        assertEquals("", sb.midString(0, -1));
        assertEquals("", sb.midString(100, 5));
        assertEquals("hello", sb.midString(-5, 5));
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new StringReader("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("world".toCharArray());
        final int read = sb.readFrom(cb);
        assertEquals(5, read);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testReadFromGenericReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Readable readable = new Readable() {
            private boolean done;

            @Override
            public int read(final CharBuffer cb) {
                if (done) {
                    return -1;
                }
                done = true;
                final char[] data = "abc".toCharArray();
                cb.put(data);
                return data.length;
            }
        };
        final int read = sb.readFrom(readable);
        assertEquals(3, read);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(6, 11, "there");
        assertEquals("hello there", sb.toString());
    }

    @Test
    public void testReplaceRangeShrinksAndGrows() {
        final StrBuilder sb1 = new StrBuilder("hello world");
        sb1.replace(0, 5, "hi");
        assertEquals("hi world", sb1.toString());

        final StrBuilder sb2 = new StrBuilder("hi world");
        sb2.replace(0, 2, "hello");
        assertEquals("hello world", sb2.toString());
    }

    @Test
    public void testReplaceRangeNullReplaceDeletes() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(5, 11, null);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReplaceMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, sb.length(), -1);
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceAllCharAndString() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());

        final StrBuilder sb2 = new StrBuilder("one two one");
        sb2.replaceAll("one", "1");
        assertEquals("1 two 1", sb2.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("0123456789"), "_");
        assertEquals("a_b_c_", sb.toString());
    }

    @Test
    public void testReplaceFirstCharAndString() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());

        final StrBuilder sb2 = new StrBuilder("one two one");
        sb2.replaceFirst("one", "1");
        assertEquals("1 two one", sb2.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("0123456789"), "_");
        assertEquals("a_b2c3", sb.toString());
    }

    @Test
    public void testReverseEvenAndOdd() {
        assertEquals("cba", new StrBuilder("abc").reverse().toString());
        assertEquals("dcba", new StrBuilder("abcd").reverse().toString());
        assertEquals("", new StrBuilder().reverse().toString());
    }

    @Test
    public void testReverseKeepsSurrogatePairsIntact() {
        final String supplementary = "😀"; // U+1F600 GRINNING FACE
        final StrBuilder sb = new StrBuilder("a" + supplementary + "b");
        sb.reverse();
        assertEquals("b" + supplementary + "a", sb.toString());
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("llo", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
        assertEquals("hello", sb.rightString(100));
    }

    @Test
    public void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(10, 'x'));
    }

    @Test
    public void testSetLengthShrinkAndGrow() {
        final StrBuilder sb = new StrBuilder("hello");
        sb.setLength(3);
        assertEquals("hel", sb.toString());
        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    public void testSizeMatchesLength() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(5, sb.size());
        assertEquals(sb.length(), sb.size());
    }

    @Test
    public void testStartsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith("way too long to match"));
    }

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertEquals("hello", sb.subSequence(0, 5));
    }

    @Test
    public void testSubSequenceInvalid() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 3));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(4, 1));
    }

    @Test
    public void testSubstringFromStart() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertEquals("world", sb.substring(6));
    }

    @Test
    public void testSubstringRangeTooLargeEndTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.substring(0, 1000));
    }

    @Test
    public void testSubstringInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(4, 1));
    }

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.toCharArray().length);
    }

    @Test
    public void testToCharArrayFull() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertArrayEquals("hello".toCharArray(), sb.toCharArray(0, 5));
    }

    @Test
    public void testToCharArrayRangeEmpty() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(0, sb.toCharArray(2, 2).length);
    }

    @Test
    public void testToStringIndependentCopy() {
        final StrBuilder sb = new StrBuilder("abc");
        final String str = sb.toString();
        sb.append("def");
        assertEquals("abc", str);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder other = sb.toStringBuilder();
        assertEquals("abc", other.toString());
    }

    @Test
    public void testTrim() {
        final StrBuilder sb = new StrBuilder("  hello world  ");
        sb.trim();
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testTrimAllWhitespaceBecomesEmpty() {
        final StrBuilder sb = new StrBuilder("    ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimNoChangeWhenNoWhitespace() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testChainingReturnsSameInstance() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append("a").append(1).append(true);
        assertSame(sb, result);
        assertNotNull(result);
    }
}
