/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface MarkerAnnotation {
        // empty
    }

    public interface Fixture {

        void doSomething(String s);
    }

    public static class Base {

        public String identity(final String s) {
            return "Base.identity:" + s;
        }

        public String overload(final Object o) {
            return "Base.overload(Object):" + o;
        }

        public String overload(final String s) {
            return "Base.overload(String):" + s;
        }

        public static String staticMethod(final int i) {
            return "staticMethod:" + i;
        }

        public static String staticEcho(final String s) {
            return "staticEcho:" + s;
        }

        public String varArgsMethod(final String prefix, final int... values) {
            final StringBuilder sb = new StringBuilder(prefix);
            for (int i = 0; i < values.length; i++) {
                sb.append(':').append(values[i]);
            }
            return sb.toString();
        }

        public String throwing() throws Exception {
            throw new IllegalStateException("boom");
        }

        private String privateMethod() {
            return "private!";
        }

        @MarkerAnnotation
        public void annotated() {
            // empty
        }
    }

    public static class Child extends Base implements Fixture {

        @Override
        public String identity(final String s) {
            return "Child.identity:" + s;
        }

        @Override
        public void doSomething(final String s) {
            // empty
        }
    }

    // -------------------- getMethodObject --------------------

    @Test
    public void testGetMethodObjectFound() {
        final Method m = MethodUtils.getMethodObject(Base.class, "identity", String.class);
        assertNotNull(m);
        assertEquals("identity", m.getName());
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Base.class, "noSuchMethod"));
    }

    @Test
    public void testGetMethodObjectNullClassOrNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "identity", String.class));
        assertNull(MethodUtils.getMethodObject(Base.class, null));
    }

    // -------------------- getAccessibleMethod --------------------

    @Test
    public void testGetAccessibleMethodPublic() {
        final Method m = MethodUtils.getAccessibleMethod(Base.class, "identity", String.class);
        assertNotNull(m);
        assertEquals(Base.class, m.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethodNonExistentReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(Base.class, "nope"));
    }

    @Test
    public void testGetAccessibleMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethodWithPrivateMethodReturnsNull() throws NoSuchMethodException {
        final Method privateMethod = Base.class.getDeclaredMethod("privateMethod");
        assertNull(MethodUtils.getAccessibleMethod(Base.class, privateMethod));
    }

    // -------------------- getMatchingAccessibleMethod --------------------

    @Test
    public void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Base.class, "overload", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodAssignable() {
        // Integer is assignable to Object, and there's no overload(Integer), so it should match overload(Object)
        final Method m = MethodUtils.getMatchingAccessibleMethod(Base.class, "overload", Integer.class);
        assertNotNull(m);
        assertEquals(Object.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Base.class, "overload", java.util.List.class, java.util.List.class));
    }

    @Test
    public void testGetMatchingAccessibleMethodNullParameterTypesTreatedAsEmpty() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Base.class, "throwing", (Class<?>[]) null);
        assertNotNull(m);
        assertEquals(0, m.getParameterTypes().length);
    }

    // -------------------- getMatchingMethod --------------------

    @Test
    public void testGetMatchingMethodExact() {
        final Method m = MethodUtils.getMatchingMethod(Base.class, "identity", String.class);
        assertNotNull(m);
        assertEquals("identity", m.getName());
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "identity", String.class);
            }
        });
    }

    @Test
    public void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Base.class, "");
            }
        });
    }

    @Test
    public void testGetMatchingMethodNotFoundReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(Base.class, "doesNotExist"));
    }

    @Test
    public void testGetMatchingMethodFindsPrivateMethod() {
        // getMatchingMethod searches declared methods too, so private methods should be found.
        final Method m = MethodUtils.getMatchingMethod(Base.class, "privateMethod");
        assertNotNull(m);
        assertEquals("privateMethod", m.getName());
    }

    // -------------------- invokeMethod --------------------

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        final Base base = new Base();
        final Object result = MethodUtils.invokeMethod(base, "identity", "hello");
        assertEquals("Base.identity:hello", result);
    }

    @Test
    public void testInvokeMethodDispatchesToOverride() throws Exception {
        final Child child = new Child();
        final Object result = MethodUtils.invokeMethod(child, "identity", "hi");
        assertEquals("Child.identity:hi", result);
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "identity", "x");
            }
        });
    }

    @Test
    public void testInvokeMethodNoSuchMethodThrows() {
        final Base base = new Base();
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(base, "thisMethodDoesNotExist");
            }
        });
    }

    @Test
    public void testInvokeMethodWrapsTargetException() {
        final Base base = new Base();
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(base, "throwing");
            }
        });
        assertTrue(ex.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testInvokeMethodForceAccessInvokesPrivateMethod() throws Exception {
        final Base base = new Base();
        final Object result = MethodUtils.invokeMethod(base, true, "privateMethod");
        assertEquals("private!", result);
    }

    @Test
    public void testInvokeMethodWithoutForceAccessFailsOnPrivateMethod() {
        final Base base = new Base();
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(base, false, "privateMethod");
            }
        });
    }

    @Test
    public void testInvokeMethodVarArgs() throws Exception {
        final Base base = new Base();
        final Object result = MethodUtils.invokeMethod(base, "varArgsMethod", "p", 1, 2, 3);
        assertEquals("p:1:2:3", result);
    }

    @Test
    public void testInvokeMethodVarArgsEmpty() throws Exception {
        final Base base = new Base();
        final Object result = MethodUtils.invokeMethod(base, "varArgsMethod", "p");
        assertEquals("p", result);
    }

    // -------------------- invokeExactMethod --------------------

    @Test
    public void testInvokeExactMethodMatchesExactTypeOnly() throws Exception {
        final Base base = new Base();
        final Object result = MethodUtils.invokeExactMethod(base, "overload", "str");
        assertEquals("Base.overload(String):str", result);
    }

    @Test
    public void testInvokeExactMethodNoExactMatchThrows() {
        final Base base = new Base();
        // Integer is not an exact match for overload(Object) nor overload(String)
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(base, "overload", Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        final Base base = new Base();
        assertThrows(InvocationTargetException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(base, "throwing");
            }
        });
    }

    // -------------------- invokeStaticMethod / invokeExactStaticMethod --------------------

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Base.class, "staticMethod", Integer.valueOf(42));
        assertEquals("staticMethod:42", result);
    }

    @Test
    public void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Base.class, "noSuchStaticMethod");
            }
        });
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Base.class, "staticEcho", "x");
        assertEquals("staticEcho:x", result);
    }

    // -------------------- getAnnotation --------------------

    @Test
    public void testGetAnnotationDirectlyPresent() throws NoSuchMethodException {
        final Method m = Base.class.getMethod("annotated");
        final MarkerAnnotation ann = MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false);
        assertNotNull(ann);
    }

    @Test
    public void testGetAnnotationNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, MarkerAnnotation.class, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotationNullAnnotationClassThrowsNpe() throws NoSuchMethodException {
        final Method m = Base.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(m, null, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotationNotPresentReturnsNull() throws NoSuchMethodException {
        final Method m = Base.class.getMethod("identity", String.class);
        assertNull(MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false));
    }

    // -------------------- getMethodsWithAnnotation / getMethodsListWithAnnotation --------------------

    @Test
    public void testGetMethodsWithAnnotation() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Base.class, MarkerAnnotation.class);
        assertEquals(1, methods.length);
        assertEquals("annotated", methods[0].getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationEmptyWhenNoneMatch() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(VarArgsFixture.class, MarkerAnnotation.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotationSearchSupersFindsInherited() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Child.class, MarkerAnnotation.class, true, false);
        assertFalse(methods.isEmpty());
        boolean found = false;
        for (final Method m : methods) {
            if ("annotated".equals(m.getName())) {
                found = true;
            }
        }
        assertTrue(found);
    }

    @Test
    public void testGetMethodsWithAnnotationNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsWithAnnotation(null, MarkerAnnotation.class);
            }
        });
    }

    // -------------------- getOverrideHierarchy --------------------

    @Test
    public void testGetOverrideHierarchy() throws NoSuchMethodException {
        final Method childMethod = Child.class.getMethod("identity", String.class);
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(childMethod, Interfaces.EXCLUDE);
        assertTrue(hierarchy.contains(childMethod));
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE);
            }
        });
    }

    // -------------------- distance-based ambiguity --------------------

    public static class AmbiguousBase {

        public String method(final Number n, final Object o) {
            return "Number,Object";
        }

        public String method(final Object o, final Number n) {
            return "Object,Number";
        }
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrowsIllegalStateException() {
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(AmbiguousBase.class, "method", Integer.class, Integer.class);
            }
        });
    }

    // -------------------- varargs widening --------------------

    public static class VarArgsFixture {

        public String sum(final double... values) {
            double total = 0;
            for (int i = 0; i < values.length; i++) {
                total += values[i];
            }
            return String.valueOf(total);
        }
    }

    @Test
    public void testInvokeMethodVarArgsWithPrimitiveWidening() throws Exception {
        final VarArgsFixture fixture = new VarArgsFixture();
        // ints passed where double... is expected - requires widening conversion.
        final Object result = MethodUtils.invokeMethod(fixture, "sum", Integer.valueOf(1), Integer.valueOf(2));
        assertEquals("3.0", result);
    }
}
