/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("a"));

        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("a"));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("ab c", StringUtils.strip(" ab c "));
        assertEquals("  abc", StringUtils.strip("  abcyx", "xyz"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("abc", StringUtils.stripToEmpty("  abc  "));

        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));

        assertEquals("abc  ", StringUtils.stripStart(" abc  ", null));
        assertEquals(" abc", StringUtils.stripEnd(" abc ", null));
        assertEquals("abc", StringUtils.stripStart("yxabc", "xyz"));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", null));

        assertTrue(StringUtils.equalsAny("abc", "abc", "def"));
        assertFalse(StringUtils.equalsAny("abc", "ABC", "DEF"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "ABC", "DEF"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));

        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare(null, "a", true) < 0);

        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "def"));

        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abcXYZ", "def", "XYZ"));
    }

    @Test
    void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", -1));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));

        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("aba", 'z'));

        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));

        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(-1, StringUtils.ordinalIndexOf("abc", "a", 0));
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("", 'a'));

        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("aba", 'z'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));

        assertTrue(StringUtils.containsNone("abab", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abz", 'x', 'y', 'z'));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("ab1", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly(null, 'a'));

        assertTrue(StringUtils.containsWhitespace(" ab"));
        assertFalse(StringUtils.containsWhitespace("ab"));
        assertFalse(StringUtils.containsWhitespace(null));
    }

    @Test
    void testSubstringFamily() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("c", StringUtils.substring("abc", 2));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", -2));
        assertEquals("abc", StringUtils.substring("abc", -4));

        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("b", StringUtils.substring("abc", -2, -1));

        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertNull(StringUtils.substringAfter(null, "a"));

        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));

        assertEquals("abc", StringUtils.substringBeforeLast("abc", "z"));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));

        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));

        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));

        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));

        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
    }

    @Test
    void testSplitAndJoin() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc def"));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.split("ab:cd:ef", ":", 2));

        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));

        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] { "a", "b", "c" }, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] { "a", "b", "c" }, ","));
    }

    @Test
    void testRemoveAndReplace() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("queued", StringUtils.remove("queued", 'z'));

        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("queued", StringUtils.remove("queued", "zz"));

        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "domain"));
        assertEquals("path", StringUtils.removeStart("/path", '/'));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".com."));

        assertEquals("qd", StringUtils.removeIgnoreCase("quEUed", "UE"));

        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
        assertEquals("any", StringUtils.replace("any", "", "z"));
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
        assertEquals("zbza", StringUtils.replace("abaa", "a", "z", 2));

        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("bat", StringUtils.leftPad("bat", 1));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));

        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
        assertEquals("batyz", StringUtils.rightPad("bat", 5, "yz"));

        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals(" a  ", StringUtils.center("a", 4));
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    void testRepeatReverseRotate() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat('e', -2));

        assertNull(StringUtils.repeat((String) null, 2));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));

        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));

        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("tab", StringUtils.reverse("bat"));

        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));

        assertNull(StringUtils.rotate(null, 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
    }

    @Test
    void testCaseChanges() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));

        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
        assertEquals("", StringUtils.swapCase(""));
        assertNull(StringUtils.swapCase(null));

        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("aBc"));
    }

    @Test
    void testCountMatchesAndChecks() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));
        assertEquals(0, StringUtils.countMatches("abba", "zz"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
        assertEquals(1, StringUtils.countMatches("ababa", "aba"));

        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab c"));

        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
        assertFalse(StringUtils.isAsciiPrintable("Ceki Gülcü"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace("ab2c"));
    }

    @Test
    void testDefaultsAndFirstNon() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("bat", StringUtils.defaultString("bat"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("NULL", StringUtils.defaultIfBlank(" ", "NULL"));
        assertEquals("bat", StringUtils.defaultIfBlank("bat", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals(" ", StringUtils.defaultIfEmpty(" ", "NULL"));

        assertEquals("xyz", StringUtils.firstNonBlank(null, "", " ", "xyz"));
        assertNull(StringUtils.firstNonBlank(null, null, null));

        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
        assertNull(StringUtils.firstNonEmpty(null, null, ""));

        assertTrue(StringUtils.isAnyBlank(null, "foo"));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));

        assertTrue(StringUtils.isAnyEmpty(null, "foo"));
        assertFalse(StringUtils.isAnyEmpty(" ", "bar"));
    }

    @Test
    void testAbbreviateAndTruncate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefg", 3));

        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));

        assertNull(StringUtils.truncate(null, 4));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 8));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", -1));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", 1, -1));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", -1, 1));
        assertEquals("bcdefghijk", StringUtils.truncate("abcdefghijklmno", 1, 10));
    }

    @Test
    void testWrapUnwrapChompChop() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));

        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));

        assertEquals("abc", StringUtils.unwrap("\'abc\'", '\''));
        assertEquals("A", StringUtils.unwrap("A", '#'));
        assertEquals("BabcB", StringUtils.unwrap("AABabcBAA", "AA"));

        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
        assertEquals("", StringUtils.chomp("\r\n"));

        assertNull(StringUtils.chop(null));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("abc", StringUtils.chop("abc\n"));
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    void testDifferenceAndLevenshtein() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("robot", StringUtils.difference("i am a machine", "i am a robot"));

        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance(null, "a"));

        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance("a", "b", -1));
    }

    @Test
    void testNormalizeSpaceAndLength() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c "));

        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testValueOfCharArray() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] { 'a', 'b', 'c' }));
    }

    @Test
    void testCapitalizeNullSafety() {
        assertSame(null, StringUtils.capitalize(null));
    }
}
