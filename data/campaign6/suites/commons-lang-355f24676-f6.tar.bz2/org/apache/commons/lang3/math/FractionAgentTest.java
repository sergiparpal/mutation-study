/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Fraction}.
 */
public class FractionAgentTest {

    // ---------------------------------------------------------------
    // getFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNotReduced() {
        // getFraction(int, int) does not reduce.
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntMinValueNumeratorWithNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -1));
    }

    @Test
    public void testGetFractionIntIntMinValueDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, Integer.MIN_VALUE));
    }

    // ---------------------------------------------------------------
    // getFraction(int, int, int)  (whole, numerator, denominator)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionWholeNumerDenom() {
        final Fraction f = Fraction.getFraction(1, 3, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 4);
        assertEquals(-7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 1, 0));
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 1, -1));
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -1, 2));
    }

    @Test
    public void testGetFractionWholeNumerDenomOverflowThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, 1, 2));
    }

    // ---------------------------------------------------------------
    // getFraction(double)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionDoubleHalf() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleWhole() {
        final Fraction f = Fraction.getFraction(2.0d);
        assertEquals(2, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleZero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.MAX_VALUE));
    }

    @Test
    public void testGetFractionDoubleThirds() {
        final Fraction f = Fraction.getFraction(1.0d / 3.0d);
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    // ---------------------------------------------------------------
    // getFraction(String)
    // ---------------------------------------------------------------

    @Test
    public void testGetFractionStringSimpleWhole() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringYOverZ() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixed() {
        final Fraction f = Fraction.getFraction("1 3/4");
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.25");
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrowsNumberFormatException() {
        final NumberFormatException ex = assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1/0"));
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionStringMixedMissingSlashThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3"));
    }

    @Test
    public void testGetFractionStringGarbageThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    // ---------------------------------------------------------------
    // getReducedFraction(int, int)
    // ---------------------------------------------------------------

    @Test
    public void testGetReducedFraction() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumerator() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(3, -9);
        assertEquals(-1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testGetReducedFractionAlreadyReduced() {
        final Fraction f = Fraction.getReducedFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ---------------------------------------------------------------
    // abs()
    // ---------------------------------------------------------------

    @Test
    public void testAbsPositiveReturnsSame() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-3, 4);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(4, abs.getDenominator());
    }

    @Test
    public void testAbsZero() {
        assertSame(Fraction.ZERO, Fraction.ZERO.abs());
    }

    // ---------------------------------------------------------------
    // add(Fraction) / subtract(Fraction)
    // ---------------------------------------------------------------

    @Test
    public void testAddSimple() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAddZeroIdentity() {
        final Fraction a = Fraction.getFraction(2, 4);
        final Fraction result = Fraction.ZERO.add(a);
        // zero is identity for addition: result should equal a's value, reduced.
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.add(null));
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> a.add(Fraction.ONE));
    }

    @Test
    public void testSubtractSimple() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.subtract(null));
    }

    @Test
    public void testSubtractResultingInNegative() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        final Fraction result = a.subtract(b);
        assertEquals(-1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    // ---------------------------------------------------------------
    // compareTo
    // ---------------------------------------------------------------

    @Test
    public void testCompareToEqualValueDifferentForm() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareToLessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction a = Fraction.getFraction(5, 7);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.compareTo(null));
    }

    // ---------------------------------------------------------------
    // divideBy
    // ---------------------------------------------------------------

    @Test
    public void testDivideBySimple() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.divideBy(b);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.ONE.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.divideBy(null));
    }

    // ---------------------------------------------------------------
    // doubleValue / floatValue / intValue / longValue
    // ---------------------------------------------------------------

    @Test
    public void testDoubleValue() {
        final Fraction f = Fraction.getFraction(1, 4);
        assertEquals(0.25d, f.doubleValue(), 0.0d);
    }

    @Test
    public void testFloatValue() {
        final Fraction f = Fraction.getFraction(1, 4);
        assertEquals(0.25f, f.floatValue(), 0.0f);
    }

    @Test
    public void testIntValueTruncates() {
        final Fraction f = Fraction.getFraction(7, 2);
        assertEquals(3, f.intValue());
    }

    @Test
    public void testIntValueNegativeTruncatesTowardZero() {
        final Fraction f = Fraction.getFraction(-7, 2);
        assertEquals(-3, f.intValue());
    }

    @Test
    public void testLongValue() {
        final Fraction f = Fraction.getFraction(7, 2);
        assertEquals(3L, f.longValue());
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsSameValueSameForm() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDifferentFormNotEqual() {
        // Documented: 2/4 is not equal to 1/2 (equals does not reduce).
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a, b);
    }

    @Test
    public void testEqualsNull() {
        assertFalse(Fraction.ONE.equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        assertFalse(Fraction.ONE.equals("1/1"));
    }

    @Test
    public void testEqualsSelf() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals(a, a);
    }

    // ---------------------------------------------------------------
    // getNumerator / getDenominator / getProperNumerator / getProperWhole
    // ---------------------------------------------------------------

    @Test
    public void testGetProperNumeratorAndWholePositive() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorExactWhole() {
        final Fraction f = Fraction.getFraction(8, 4);
        assertEquals(0, f.getProperNumerator());
        assertEquals(2, f.getProperWhole());
    }

    // ---------------------------------------------------------------
    // invert
    // ---------------------------------------------------------------

    @Test
    public void testInvertSimple() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction inv = f.invert();
        assertEquals(7, inv.getNumerator());
        assertEquals(3, inv.getDenominator());
    }

    @Test
    public void testInvertNegativeKeepsSignOnNumerator() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction inv = f.invert();
        assertEquals(-7, inv.getNumerator());
        assertEquals(3, inv.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.ZERO.invert());
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    // ---------------------------------------------------------------
    // multiplyBy
    // ---------------------------------------------------------------

    @Test
    public void testMultiplyBySimple() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 5);
        final Fraction result = a.multiplyBy(b);
        assertEquals(2, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.multiplyBy(null));
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> a.multiplyBy(Fraction.getFraction(2, 1)));
    }

    // ---------------------------------------------------------------
    // negate
    // ---------------------------------------------------------------

    @Test
    public void testNegateSimple() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction n = f.negate();
        assertEquals(-3, n.getNumerator());
        assertEquals(7, n.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    // ---------------------------------------------------------------
    // pow
    // ---------------------------------------------------------------

    @Test
    public void testPowZero() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(Fraction.ONE, f.pow(0));
    }

    @Test
    public void testPowZeroOnZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOne() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowTwo() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(2);
        assertEquals(4, result.getNumerator());
        assertEquals(9, result.getDenominator());
    }

    @Test
    public void testPowThree() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    // ---------------------------------------------------------------
    // reduce
    // ---------------------------------------------------------------

    @Test
    public void testReduceSimple() {
        final Fraction f = Fraction.getFraction(2, 4);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSame() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceNegativeNumerator() {
        final Fraction f = Fraction.getFraction(-4, 8);
        final Fraction reduced = f.reduce();
        assertEquals(-1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceZeroNumerator() {
        final Fraction f = Fraction.getFraction(0, 5);
        final Fraction reduced = f.reduce();
        assertEquals(0, reduced.getNumerator());
        assertEquals(1, reduced.getDenominator());
    }

    // ---------------------------------------------------------------
    // toString / toProperString
    // ---------------------------------------------------------------

    @Test
    public void testToStringFormat() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
    }

    @Test
    public void testToStringNegative() {
        assertEquals("-3/7", Fraction.getFraction(-3, 7).toString());
    }

    @Test
    public void testToProperStringProper() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToProperStringImproper() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringImproperNegative() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringOne() {
        assertEquals("1", Fraction.ONE.toProperString());
    }

    @Test
    public void testToProperStringNegativeOne() {
        final Fraction f = Fraction.getFraction(-1, 1);
        assertEquals("-1", f.toProperString());
    }

    @Test
    public void testToProperStringWholeNumberNoRemainder() {
        final Fraction f = Fraction.getFraction(8, 4);
        assertEquals("2", f.toProperString());
    }
}
