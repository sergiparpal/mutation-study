/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    static class PackagePrivateNested {
        // not public, used to test isPublic()/isInnerClass()
    }

    @Test
    public void testComparator() {
        final Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        final int expectedSign = "java.lang.Integer".compareTo("java.lang.String");
        final int actualSign = comparator.compare(Integer.class, String.class);
        assertEquals(Integer.signum(expectedSign), Integer.signum(actualSign));
        assertEquals(0, comparator.compare(String.class, String.class));
    }

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(input);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> input = new ArrayList<String>();
        input.add("java.lang.String");
        input.add("not.a.real.ClassName");
        input.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(input);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testGetAbbreviatedNameFromClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameFromStringBoundaries() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
    }

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(ArrayList.class);
        assertTrue(interfaces.contains(List.class));
        assertTrue(interfaces.contains(Collection.class));
    }

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Integer.class);
        assertEquals(Number.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(superclasses.size() - 1));
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc"));
    }

    @Test
    public void testGetClassWithClassLoader() throws ClassNotFoundException {
        final ClassLoader loader = Thread.currentThread().getContextClassLoader();
        assertEquals(int.class, ClassUtils.getClass(loader, "int"));
        assertEquals(int[].class, ClassUtils.getClass(loader, "[I"));
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, "org.apache.commons.lang3.NoSuchClassAgentTest999");
            }
        });
    }

    @Test
    public void testGetClassResolvesInnerClassDotSyntax() throws ClassNotFoundException {
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    public void testGetClassNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("org.apache.commons.lang3.TotallyMadeUpClassAgentTest");
            }
        });
    }

    @Test
    public void testGetClassArrayDimensionTooLargeCanonicalForm() {
        final StringBuilder sb = new StringBuilder("int");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    public void testGetClassArrayDimensionTooLargeEncodedForm() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.String;");
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    public void testGetClassNameTooLong() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 65536; i++) {
            sb.append('a');
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        final Class<String> componentType = ClassUtils.<String>getComponentType(String[].class);
        assertEquals(String.class, componentType);
    }

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("FALLBACK", ClassUtils.getName((Class<?>) null, "FALLBACK"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("FALLBACK", ClassUtils.getName((Object) null, "FALLBACK"));
        assertEquals("java.lang.String", ClassUtils.getName("abc"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("FALLBACK", ClassUtils.getPackageCanonicalName((Object) null, "FALLBACK"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("FALLBACK", ClassUtils.getPackageName((Object) null, "FALLBACK"));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("[I"));
        assertEquals("", ClassUtils.getPackageName("NoPackageHere"));
    }

    @Test
    public void testGetPublicMethodNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "size");
            }
        });
    }

    @Test
    public void testGetPublicMethodFindsAccessibleMethod() throws NoSuchMethodException {
        final List<String> list = Collections.unmodifiableList(new ArrayList<String>());
        final Method method = ClassUtils.getPublicMethod(list.getClass(), "isEmpty");
        assertEquals("isEmpty", method.getName());
        assertTrue(ClassUtils.isPublic(method.getDeclaringClass()));
    }

    @Test
    public void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExistAgentTest");
            }
        });
    }

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class));
    }

    @Test
    public void testGetShortCanonicalNameObject() {
        assertEquals("FALLBACK", ClassUtils.getShortCanonicalName((Object) null, "FALLBACK"));
        assertEquals("String", ClassUtils.getShortCanonicalName("abc", "FALLBACK"));
    }

    @Test
    public void testGetShortCanonicalNameString() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String", ClassUtils.getShortCanonicalName("java.lang.String"));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("int[][]", ClassUtils.getShortClassName(int[][].class));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("FALLBACK", ClassUtils.getShortClassName((Object) null, "FALLBACK"));
        assertEquals("String", ClassUtils.getShortClassName("abc", "FALLBACK"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("int[][]", ClassUtils.getShortClassName("[[I"));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("FALLBACK", ClassUtils.getSimpleName((Class<?>) null, "FALLBACK"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("FALLBACK", ClassUtils.getSimpleName((Object) null, "FALLBACK"));
        assertEquals("String", ClassUtils.getSimpleName("abc"));
    }

    @Test
    public void testHierarchyExcludingInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Integer.class);
        final List<Class<?>> collected = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            collected.add(it.next());
        }
        assertEquals(3, collected.size());
        assertEquals(Integer.class, collected.get(0));
        assertEquals(Number.class, collected.get(1));
        assertEquals(Object.class, collected.get(2));
        assertFalse(collected.contains(Comparable.class));
    }

    @Test
    public void testHierarchyIncludingInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Integer.class, ClassUtils.Interfaces.INCLUDE);
        final Set<Class<?>> collected = new HashSet<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            collected.add(it.next());
        }
        assertTrue(collected.contains(Integer.class));
        assertTrue(collected.contains(Number.class));
        assertTrue(collected.contains(Object.class));
        assertTrue(collected.contains(Comparable.class));
        assertTrue(collected.contains(java.io.Serializable.class));
    }

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, float.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertTrue(ClassUtils.isAssignable(byte.class, double.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
        assertTrue(ClassUtils.isAssignable(float.class, double.class));
        assertTrue(ClassUtils.isAssignable(char.class, int.class));
        assertTrue(ClassUtils.isAssignable(short.class, int.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
    }

    @Test
    public void testIsAssignableNullsAndEdgeCases() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {int.class, String.class}, new Class<?>[] {long.class, Object.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {int.class}, new Class<?>[] {int.class, String.class}));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertTrue(ClassUtils.isInnerClass(PackagePrivateNested.class));
        assertFalse(ClassUtils.isInnerClass(String.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PackagePrivateNested.class));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        final Class<?>[] empty = ClassUtils.primitivesToWrappers();
        assertEquals(0, empty.length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, boolean.class, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(Boolean.class, result[1]);
        assertEquals(String.class, result[2]);
        assertNull(result[3]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        final Class<?>[] empty = ClassUtils.toClass();
        assertEquals(0, empty.length);
        final Class<?>[] result = ClassUtils.toClass("abc", Integer.valueOf(1), null);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        final Class<?>[] empty = ClassUtils.wrappersToPrimitives();
        assertEquals(0, empty.length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(int.class));
    }

    @Test
    public void testInterfacesEnum() {
        assertEquals(2, ClassUtils.Interfaces.values().length);
        assertEquals(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertEquals(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    @Test
    public void testDeprecatedPublicConstructor() {
        final ClassUtils instance = new ClassUtils();
        assertNotNull(instance);
    }
}
