/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    private static final int INITIAL = 17;

    private static final int CONSTANT = 37;

    static class SimpleFixture {
        @SuppressWarnings("unused")
        private final int a;
        @SuppressWarnings("unused")
        private final int b;

        SimpleFixture(final int a, final int b) {
            this.a = a;
            this.b = b;
        }
    }

    static class FixtureWithExclude {
        @HashCodeExclude
        private final int excluded;
        private final int included;

        FixtureWithExclude(final int excluded, final int included) {
            this.excluded = excluded;
            this.included = included;
        }
    }

    static class FixtureWithTransient {
        private final int plain;
        private transient int hidden;

        FixtureWithTransient(final int plain, final int hidden) {
            this.plain = plain;
            this.hidden = hidden;
        }
    }

    static class BaseFixture {
        @SuppressWarnings("unused")
        private final int baseField;

        BaseFixture(final int baseField) {
            this.baseField = baseField;
        }
    }

    static class SubFixture extends BaseFixture {
        @SuppressWarnings("unused")
        private final int subField;

        SubFixture(final int baseField, final int subField) {
            super(baseField);
            this.subField = subField;
        }
    }

    static class Level0Fixture {
        @SuppressWarnings("unused")
        private final int zero;

        Level0Fixture(final int zero) {
            this.zero = zero;
        }
    }

    static class Level1Fixture extends Level0Fixture {
        @SuppressWarnings("unused")
        private final int one;

        Level1Fixture(final int zero, final int one) {
            super(zero);
            this.one = one;
        }
    }

    static class Level2Fixture extends Level1Fixture {
        @SuppressWarnings("unused")
        private final int two;

        Level2Fixture(final int zero, final int one, final int two) {
            super(zero, one);
            this.two = two;
        }
    }

    static class CycleA {
        CycleB b;
    }

    static class CycleB {
        CycleA a;
    }

    // --- append(primitive) ---

    @Test
    void testAppendBoolean() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append(true).toHashCode());
        assertEquals(INITIAL * CONSTANT + 1, new HashCodeBuilder(INITIAL, CONSTANT).append(false).toHashCode());
    }

    @Test
    void testAppendBooleanArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((boolean[]) null).toHashCode());
        final boolean[] array = {true, false};
        assertEquals((INITIAL * CONSTANT) * CONSTANT + 1, new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendByte() {
        assertEquals(INITIAL * CONSTANT + 42, new HashCodeBuilder(INITIAL, CONSTANT).append((byte) 42).toHashCode());
    }

    @Test
    void testAppendByteArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((byte[]) null).toHashCode());
        final byte[] array = {1, 2, 3};
        assertEquals(((INITIAL * CONSTANT + 1) * CONSTANT + 2) * CONSTANT + 3,
                new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendChar() {
        assertEquals(INITIAL * CONSTANT + 'x', new HashCodeBuilder(INITIAL, CONSTANT).append('x').toHashCode());
    }

    @Test
    void testAppendCharArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((char[]) null).toHashCode());
        final char[] array = {'a', 'b'};
        assertEquals((INITIAL * CONSTANT + 'a') * CONSTANT + 'b', new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendDouble() {
        final double d = 1234567.89;
        final long bits = Double.doubleToLongBits(d);
        final int expected = INITIAL * CONSTANT + (int) (bits ^ bits >> 32);
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(d).toHashCode());
    }

    @Test
    void testAppendDoubleArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((double[]) null).toHashCode());
        final double[] array = {1.5, 2.5};
        final HashCodeBuilder manual = new HashCodeBuilder(INITIAL, CONSTANT).append(1.5).append(2.5);
        assertEquals(manual.toHashCode(), new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendFloat() {
        final float f = 12.34f;
        final int expected = INITIAL * CONSTANT + Float.floatToIntBits(f);
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(f).toHashCode());
    }

    @Test
    void testAppendFloatArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((float[]) null).toHashCode());
        final float[] array = {1.5f, 2.5f};
        final HashCodeBuilder manual = new HashCodeBuilder(INITIAL, CONSTANT).append(1.5f).append(2.5f);
        assertEquals(manual.toHashCode(), new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendInt() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append(0).toHashCode());
        assertEquals(INITIAL * CONSTANT + 123456, new HashCodeBuilder(INITIAL, CONSTANT).append(123456).toHashCode());
        assertEquals(INITIAL * CONSTANT - 5, new HashCodeBuilder(INITIAL, CONSTANT).append(-5).toHashCode());
    }

    @Test
    void testAppendIntArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((int[]) null).toHashCode());
        final int[] array = {5, 6};
        assertEquals((INITIAL * CONSTANT + 5) * CONSTANT + 6, new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendLong() {
        final long value = 123456789L;
        final int expected = INITIAL * CONSTANT + (int) (value ^ value >> 32);
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(value).toHashCode());
    }

    @Test
    void testAppendLongArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((long[]) null).toHashCode());
        final long[] array = {5L, 6L};
        assertEquals((INITIAL * CONSTANT + 5) * CONSTANT + 6, new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendShort() {
        assertEquals(INITIAL * CONSTANT + 12345, new HashCodeBuilder(INITIAL, CONSTANT).append((short) 12345).toHashCode());
    }

    @Test
    void testAppendShortArrayIncludingNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((short[]) null).toHashCode());
        final short[] array = {5, 6};
        assertEquals((INITIAL * CONSTANT + 5) * CONSTANT + 6, new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendObjectNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((Object) null).toHashCode());
    }

    @Test
    void testAppendObjectDelegatesToHashCode() {
        final Object obj = new Object();
        assertEquals(INITIAL * CONSTANT + obj.hashCode(), new HashCodeBuilder(INITIAL, CONSTANT).append(obj).toHashCode());
    }

    @Test
    void testAppendObjectArrayDispatchesElementwise() {
        final Object[] array = {"a", "b"};
        final HashCodeBuilder manual = new HashCodeBuilder(INITIAL, CONSTANT).append("a").append("b");
        assertEquals(manual.toHashCode(), new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendObjectDetectsPrimitiveArrayDisguisedAsObject() {
        final int[] array = {1, 2};
        assertEquals(new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode(),
                new HashCodeBuilder(INITIAL, CONSTANT).append((Object) array).toHashCode());
    }

    @Test
    void testAppendObjectDetectsObjectArrayDisguisedAsObject() {
        final String[] array = {"x", "y"};
        assertEquals(new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode(),
                new HashCodeBuilder(INITIAL, CONSTANT).append((Object) array).toHashCode());
    }

    @Test
    void testAppendMultiDimensionalArray() {
        final int[][] array = {{1, 2}, {3}};
        final HashCodeBuilder manual = new HashCodeBuilder(INITIAL, CONSTANT).append(new int[]{1, 2}).append(new int[]{3});
        assertEquals(manual.toHashCode(), new HashCodeBuilder(INITIAL, CONSTANT).append(array).toHashCode());
    }

    @Test
    void testAppendReturnsThisForChaining() {
        final HashCodeBuilder builder = new HashCodeBuilder(INITIAL, CONSTANT);
        assertSame(builder, builder.append(1));
        assertSame(builder, builder.append("x"));
        assertSame(builder, builder.append(true));
    }

    // --- appendSuper ---

    @Test
    void testAppendSuper() {
        final int superHash = 99;
        assertEquals(INITIAL * CONSTANT + superHash, new HashCodeBuilder(INITIAL, CONSTANT).appendSuper(superHash).toHashCode());
    }

    // --- toHashCode / build / hashCode / equals ---

    @Test
    void testToHashCodeMatchesHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append("a");
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(INITIAL, CONSTANT).append(5);
        assertEquals(Integer.valueOf(builder.toHashCode()), builder.build());
    }

    @Test
    void testEqualsReflexive() {
        final HashCodeBuilder builder = new HashCodeBuilder(INITIAL, CONSTANT).append(1);
        assertEquals(builder, builder);
    }

    @Test
    void testEqualsBasedOnTotal() {
        final HashCodeBuilder b1 = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append('a');
        final HashCodeBuilder b2 = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append('a');
        final HashCodeBuilder b3 = new HashCodeBuilder(INITIAL, CONSTANT).append(2);
        assertEquals(b1, b2);
        assertNotEquals(b1, b3);
    }

    @Test
    void testEqualsWithNullAndOtherType() {
        final HashCodeBuilder builder = new HashCodeBuilder(INITIAL, CONSTANT);
        assertFalse(builder.equals(null));
        assertFalse(builder.equals("not a HashCodeBuilder"));
    }

    // --- constructors ---

    @Test
    void testDefaultConstructorUsesSeventeenAndThirtySeven() {
        assertEquals(17 * 37 + 5, new HashCodeBuilder().append(5).toHashCode());
    }

    @Test
    void testConstructorRejectsEvenInitial() {
        assertThrows(IllegalArgumentException.class, () -> new HashCodeBuilder(2, 3));
    }

    @Test
    void testConstructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, () -> new HashCodeBuilder(3, 2));
    }

    @Test
    void testConstructorRejectsZeroInitial() {
        assertThrows(IllegalArgumentException.class, () -> new HashCodeBuilder(0, 3));
    }

    @Test
    void testConstructorRejectsZeroMultiplier() {
        assertThrows(IllegalArgumentException.class, () -> new HashCodeBuilder(3, 0));
    }

    @Test
    void testConstructorAcceptsNegativeOddNumbers() {
        assertEquals(-3 * -5 + 2, new HashCodeBuilder(-3, -5).append(2).toHashCode());
    }

    // --- Builder nested class ---

    @Test
    void testStaticBuilderProducesEquivalentHashCodeBuilder() {
        final HashCodeBuilder built = HashCodeBuilder.builder()
                .setInitialOddNumber(INITIAL)
                .setMultiplierOddNumber(CONSTANT)
                .get()
                .append(7);
        assertEquals(new HashCodeBuilder(INITIAL, CONSTANT).append(7).toHashCode(), built.toHashCode());
    }

    @Test
    void testStaticBuilderRejectsEvenInitial() {
        assertThrows(IllegalArgumentException.class,
                () -> HashCodeBuilder.builder().setInitialOddNumber(2).setMultiplierOddNumber(3).get());
    }

    // --- reflectionHashCode ---

    @Test
    void testReflectionHashCodeNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> HashCodeBuilder.reflectionHashCode(null));
    }

    @Test
    void testReflectionHashCodeRejectsEvenInitial() {
        assertThrows(IllegalArgumentException.class,
                () -> HashCodeBuilder.reflectionHashCode(2, 2, new SimpleFixture(1, 2), true));
    }

    @Test
    void testReflectionHashCodeMatchesManualAppendInFieldNameOrder() {
        final SimpleFixture fixture = new SimpleFixture(1, 2);
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append(2).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(INITIAL, CONSTANT, fixture));
    }

    @Test
    void testReflectionHashCodeHonorsHashCodeExcludeAnnotation() {
        final FixtureWithExclude fixture = new FixtureWithExclude(100, 1);
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(1).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(INITIAL, CONSTANT, fixture, false));
    }

    @Test
    void testReflectionHashCodeExcludesTransientsByDefault() {
        final FixtureWithTransient fixture = new FixtureWithTransient(1, 999);
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(1).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(fixture));
    }

    @Test
    void testReflectionHashCodeIncludesTransientsWhenRequested() {
        final FixtureWithTransient fixture = new FixtureWithTransient(1, 2);
        // Fields are visited in alphabetical order: "hidden" (transient, value 2) before "plain" (value 1).
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(2).append(1).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(fixture, true));
    }

    @Test
    void testReflectionHashCodeExcludesNamedFields() {
        final FixtureWithTransient fixture = new FixtureWithTransient(1, 2);
        final int baseline = HashCodeBuilder.reflectionHashCode(INITIAL, CONSTANT, fixture, true, null, "hidden");
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(1).toHashCode();
        assertEquals(expected, baseline);
    }

    @Test
    void testReflectionHashCodeIncludesSuperclassFields() {
        final SubFixture fixture = new SubFixture(10, 20);
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(20).append(10).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(fixture));
    }

    @Test
    void testReflectionHashCodeUpToClassIsInclusiveAndStopsBeyondIt() {
        final Level2Fixture fixture = new Level2Fixture(100, 10, 1);
        // Level2 (two=1) and Level1 (one=10) are included; Level0 (zero=100) is beyond the given superclass and excluded.
        final int expected = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append(10).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(INITIAL, CONSTANT, fixture, false, Level1Fixture.class));
    }

    @Test
    void testReflectionHashCodeConsistentAcrossCalls() {
        final SimpleFixture fixture = new SimpleFixture(3, 4);
        assertEquals(HashCodeBuilder.reflectionHashCode(fixture), HashCodeBuilder.reflectionHashCode(fixture));
    }

    @Test
    void testReflectionHashCodeHandlesCyclesWithoutStackOverflow() {
        final CycleA a = new CycleA();
        final CycleB b = new CycleB();
        a.b = b;
        b.a = a;
        final int hashA = HashCodeBuilder.reflectionHashCode(a);
        assertNotEquals(0, hashA);
        assertTrue(HashCodeBuilder.getRegistry().isEmpty());
    }

    // --- registry helpers ---

    @Test
    void testGetRegistryReturnsNonNullSetByDefault() {
        assertNotNull(HashCodeBuilder.getRegistry());
    }

    @Test
    void testGetRegistrySameInstancePerThread() {
        final Object registry1 = HashCodeBuilder.getRegistry();
        final Object registry2 = HashCodeBuilder.getRegistry();
        assertSame(registry1, registry2);
    }
}
