/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Fraction}.
 */
public class FractionAgentTest {

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    @Test
    public void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        try {
            Fraction.getFraction(1, 0);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionIntIntOverflowOnNegate() {
        try {
            Fraction.getFraction(Integer.MIN_VALUE, -1);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionIntIntIntWholeNumerDenom() {
        final Fraction f = Fraction.getFraction(1, 2, 3);
        assertEquals(5, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntIntNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 2, 3);
        assertEquals(-5, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntIntNegativeDenominatorThrows() {
        try {
            Fraction.getFraction(1, 2, -3);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionIntIntIntNegativeNumeratorThrows() {
        try {
            Fraction.getFraction(1, -2, 3);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionIntIntIntZeroDenominatorThrows() {
        try {
            Fraction.getFraction(1, 2, 0);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionIntIntIntOverflowingNumeratorThrows() {
        try {
            Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionDouble() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleZero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        try {
            Fraction.getFraction(Double.NaN);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        try {
            Fraction.getFraction((double) Integer.MAX_VALUE + 100.0d);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionStringSimpleWhole() {
        final Fraction f = Fraction.getFraction("7");
        assertEquals(7, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringYOverZ() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringXYOverZ() {
        final Fraction f = Fraction.getFraction("1 2/3");
        assertEquals(5, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.25");
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrowsNpe() {
        try {
            Fraction.getFraction((String) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionStringInvalidThrowsNfe() {
        try {
            Fraction.getFraction("foo");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrowsNfeWithCause() {
        try {
            Fraction.getFraction("1/0");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            assertNotNull(expected.getCause());
            assertTrue(expected.getCause() instanceof ArithmeticException);
        }
    }

    @Test
    public void testGetFractionStringMissingSlashInXYZFormatThrows() {
        try {
            Fraction.getFraction("1 2");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    public void testGetReducedFractionBasic() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorNormalizesToZero() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        try {
            Fraction.getReducedFraction(1, 0);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testAbsPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-3, 4);
        final Fraction a = f.abs();
        assertEquals(3, a.getNumerator());
        assertEquals(4, a.getDenominator());
    }

    @Test
    public void testAbsMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        try {
            f.abs();
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testAddBasic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction sum = a.add(b);
        assertEquals(5, sum.getNumerator());
        assertEquals(6, sum.getDenominator());
    }

    @Test
    public void testAddZero() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction sum = a.add(Fraction.ZERO);
        assertEquals(1, sum.getNumerator());
        assertEquals(2, sum.getDenominator());
    }

    @Test
    public void testAddNullThrowsNpe() {
        try {
            Fraction.ONE.add(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE - 1, 1);
        try {
            a.add(Fraction.getFraction(2, 1));
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testSubtractBasic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction diff = a.subtract(b);
        assertEquals(1, diff.getNumerator());
        assertEquals(6, diff.getDenominator());
    }

    @Test
    public void testSubtractNullThrowsNpe() {
        try {
            Fraction.ONE.subtract(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testMultiplyByBasic() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction product = a.multiplyBy(b);
        assertEquals(1, product.getNumerator());
        assertEquals(2, product.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction product = a.multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, product);
    }

    @Test
    public void testMultiplyByNullThrowsNpe() {
        try {
            Fraction.ONE.multiplyBy(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testDivideByBasic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction quotient = a.divideBy(b);
        assertEquals(3, quotient.getNumerator());
        assertEquals(2, quotient.getDenominator());
    }

    @Test
    public void testDivideByZeroNumeratorFraction() {
        final Fraction result = Fraction.ZERO.divideBy(Fraction.getFraction(1, 2));
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testDivideByZeroThrows() {
        try {
            Fraction.ONE.divideBy(Fraction.ZERO);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testDivideByNullThrowsNpe() {
        try {
            Fraction.ONE.divideBy(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testInvertPositive() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction inv = f.invert();
        assertEquals(3, inv.getNumerator());
        assertEquals(2, inv.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-2, 3);
        final Fraction inv = f.invert();
        assertEquals(-3, inv.getNumerator());
        assertEquals(2, inv.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        try {
            Fraction.ZERO.invert();
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        try {
            f.invert();
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testNegate() {
        final Fraction f = Fraction.getFraction(3, 4);
        final Fraction n = f.negate();
        assertEquals(-3, n.getNumerator());
        assertEquals(4, n.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        try {
            f.negate();
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testPowZeroReturnsOne() {
        final Fraction f = Fraction.getFraction(5, 7);
        assertSame(Fraction.ONE, f.pow(0));
    }

    @Test
    public void testPowOneReturnsSame() {
        final Fraction f = Fraction.getFraction(5, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction p = f.pow(3);
        assertEquals(8, p.getNumerator());
        assertEquals(27, p.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction p = f.pow(-2);
        assertEquals(9, p.getNumerator());
        assertEquals(4, p.getDenominator());
    }

    @Test
    public void testPowMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(2, 1);
        try {
            f.pow(Integer.MIN_VALUE);
            fail("Expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    @Test
    public void testReduceAlreadyReduced() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceSimplifies() {
        final Fraction f = Fraction.getFraction(4, 8);
        final Fraction r = f.reduce();
        assertEquals(1, r.getNumerator());
        assertEquals(2, r.getDenominator());
    }

    @Test
    public void testReduceZeroNumeratorNotEqualToZeroConstant() {
        final Fraction f = Fraction.getFraction(0, 5);
        final Fraction r = f.reduce();
        assertSame(Fraction.ZERO, r);
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    public void testIntValueFloatValueDoubleValueLongValue() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.intValue());
        assertEquals(1L, f.longValue());
        assertEquals(1.75f, f.floatValue(), 0.0001f);
        assertEquals(1.75d, f.doubleValue(), 0.0001d);
    }

    @Test
    public void testToString() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertEquals("3/4", f.toString());
        // cached value is returned on a second call
        assertEquals("3/4", f.toString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringOne() {
        final Fraction f = Fraction.getFraction(4, 4);
        assertEquals("1", f.toProperString());
    }

    @Test
    public void testToProperStringMinusOne() {
        final Fraction f = Fraction.getFraction(-4, 4);
        assertEquals("-1", f.toProperString());
    }

    @Test
    public void testToProperStringImproper() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", f.toProperString());
    }

    @Test
    public void testToProperStringNegativeImproper() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", f.toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertEquals("3/4", f.toProperString());
    }

    @Test
    public void testToProperStringMinValue() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertNotNull(f.toProperString());
        assertEquals(Integer.toString(Integer.MIN_VALUE), f.toProperString());
    }

    @Test
    public void testEqualsAndHashCode() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        final Fraction c = Fraction.getFraction(2, 4);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        // 1/2 is not equal to 2/4, unlike compareTo which treats them as equal
        assertNotEquals(a, c);
        assertFalse(a.equals(null));
        assertFalse(a.equals("1/2"));
        assertTrue(a.equals(a));
    }

    @Test
    public void testCompareTo() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        final Fraction c = Fraction.getFraction(2, 3);
        assertEquals(0, a.compareTo(a));
        // compareTo treats 1/2 and 2/4 as equal even though equals() does not
        assertEquals(0, a.compareTo(b));
        assertTrue(a.compareTo(c) < 0);
        assertTrue(c.compareTo(a) > 0);
    }

    @Test
    public void testCompareToNullThrowsNpe() {
        try {
            Fraction.ONE.compareTo(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }
}
