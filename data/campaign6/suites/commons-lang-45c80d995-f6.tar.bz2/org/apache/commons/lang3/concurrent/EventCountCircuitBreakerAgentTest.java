/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained test class for {@link EventCountCircuitBreaker}.
 */
class EventCountCircuitBreakerAgentTest {

    /**
     * A subclass that allows the notion of "now" to be controlled by the test, so that
     * check interval logic can be exercised deterministically without sleeping.
     */
    private static final class ControllableCircuitBreaker extends EventCountCircuitBreaker {

        private long currentTime;

        ControllableCircuitBreaker(final int openingThreshold, final long openingInterval,
                final TimeUnit openingUnit, final int closingThreshold, final long closingInterval,
                final TimeUnit closingUnit) {
            super(openingThreshold, openingInterval, openingUnit, closingThreshold, closingInterval, closingUnit);
        }

        @Override
        long nanoTime() {
            return currentTime;
        }

        void setCurrentTime(final long time) {
            currentTime = time;
        }
    }

    // ----------------------------------------------------------------------
    // Constructors and getters
    // ----------------------------------------------------------------------

    @Test
    void testThreeArgConstructorUsesSameThresholdAndIntervalForBothStates() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 2, TimeUnit.SECONDS);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getClosingInterval());
    }

    @Test
    void testFourArgConstructorUsesSameIntervalForBothStates() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 2, TimeUnit.SECONDS, 3);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(3, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getClosingInterval());
    }

    @Test
    void testSixArgConstructorSetsIndependentValues() {
        final EventCountCircuitBreaker breaker =
                new EventCountCircuitBreaker(5, 2, TimeUnit.SECONDS, 3, 4, TimeUnit.MILLISECONDS);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(3, breaker.getClosingThreshold());
        assertEquals(TimeUnit.MILLISECONDS.toNanos(4), breaker.getClosingInterval());
    }

    @Test
    void testNewInstanceStartsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        assertFalse(breaker.isOpen());
        assertTrue(breaker.isClosed());
        assertTrue(breaker.checkState());
    }

    // ----------------------------------------------------------------------
    // checkState() does not count as an event
    // ----------------------------------------------------------------------

    @Test
    void testCheckStateDoesNotIncrementCounter() {
        // interval never finishes (time frozen), so checkState() calls must be no-ops.
        final ControllableCircuitBreaker breaker =
                new ControllableCircuitBreaker(1, 100, TimeUnit.NANOSECONDS, 1, 100, TimeUnit.NANOSECONDS);
        breaker.setCurrentTime(0);
        for (int i = 0; i < 5; i++) {
            assertTrue(breaker.checkState());
        }
        assertFalse(breaker.isOpen());
        // first real increment brings the count to 1 (threshold 1 -> 1 > 1 is false -> still closed)
        assertTrue(breaker.incrementAndCheckState());
        // second real increment brings the count to 2 (2 > 1 -> opens); if checkState() had
        // been incrementing the counter, the circuit would already be open at this point.
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    // ----------------------------------------------------------------------
    // Opening threshold boundary
    // ----------------------------------------------------------------------

    @Test
    void testOpeningThresholdBoundaryNotExceeded() {
        final ControllableCircuitBreaker breaker =
                new ControllableCircuitBreaker(2, 100, TimeUnit.NANOSECONDS, 2, 100, TimeUnit.NANOSECONDS);
        breaker.setCurrentTime(0);
        assertTrue(breaker.incrementAndCheckState()); // count 1
        assertTrue(breaker.incrementAndCheckState()); // count 2, not > 2
        assertFalse(breaker.isOpen());
        assertFalse(breaker.incrementAndCheckState()); // count 3, > 2, opens
        assertTrue(breaker.isOpen());
    }

    @Test
    void testIncrementAndCheckStateWithExplicitIncrement() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(4)));
        assertFalse(breaker.isOpen());
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(2)));
        assertTrue(breaker.isOpen());
    }

    @Test
    void testNegativeIncrementIsRejected() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.HOURS);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                breaker.incrementAndCheckState(Integer.valueOf(-1));
            }
        });
        // state must be unaffected: closed, and the counter must not have moved.
        assertTrue(breaker.isClosed());
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(5))); // count would be 5, not > 5
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(1))); // count 6, > 5, opens
    }

    @Test
    void testOpeningThresholdZeroOpensOnFirstEvent() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(0, 1, TimeUnit.HOURS);
        assertTrue(breaker.checkState());
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    // ----------------------------------------------------------------------
    // Check interval resets the counter once elapsed
    // ----------------------------------------------------------------------

    @Test
    void testCounterResetsWhenOpeningIntervalElapses() {
        final ControllableCircuitBreaker breaker =
                new ControllableCircuitBreaker(1, 10, TimeUnit.NANOSECONDS, 1, 10, TimeUnit.NANOSECONDS);
        breaker.setCurrentTime(0);
        assertTrue(breaker.incrementAndCheckState()); // count 1, not > 1, still closed

        // move past the opening interval: the counter for the new interval should start
        // fresh at 1 (this event), not accumulate to 2.
        breaker.setCurrentTime(20);
        assertTrue(breaker.incrementAndCheckState());
        assertFalse(breaker.isOpen());
    }

    // ----------------------------------------------------------------------
    // Automatic transition back to closed
    // ----------------------------------------------------------------------

    @Test
    void testStaysOpenWithinClosingIntervalRegardlessOfEvents() {
        final ControllableCircuitBreaker breaker =
                new ControllableCircuitBreaker(1, 10, TimeUnit.NANOSECONDS, 1, 10, TimeUnit.NANOSECONDS);
        breaker.setCurrentTime(0);
        breaker.incrementAndCheckState(); // count 1
        assertFalse(breaker.incrementAndCheckState()); // count 2, opens
        assertTrue(breaker.isOpen());

        // still within the closing interval: must remain open no matter how many checks occur.
        assertFalse(breaker.checkState());
        assertFalse(breaker.checkState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testAutomaticallyClosesAfterClosingIntervalWithFewEvents() {
        final ControllableCircuitBreaker breaker =
                new ControllableCircuitBreaker(1, 10, TimeUnit.NANOSECONDS, 1, 10, TimeUnit.NANOSECONDS);
        breaker.setCurrentTime(0);
        breaker.incrementAndCheckState(); // count 1
        assertFalse(breaker.incrementAndCheckState()); // count 2, opens
        assertTrue(breaker.isOpen());

        // let the closing interval elapse without any further events.
        breaker.setCurrentTime(20);
        assertTrue(breaker.checkState());
        assertTrue(breaker.isClosed());
    }

    @Test
    void testStaysOpenAfterClosingIntervalWhenEventsReachClosingThreshold() {
        final ControllableCircuitBreaker breaker =
                new ControllableCircuitBreaker(1, 10, TimeUnit.NANOSECONDS, 2, 10, TimeUnit.NANOSECONDS);
        breaker.setCurrentTime(0);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(2))); // opens, count 2 > 1
        assertTrue(breaker.isOpen());

        // two more events arrive before the closing interval elapses: the event count
        // (2) reaches the closing threshold (2), so the breaker must stay open.
        breaker.incrementAndCheckState(Integer.valueOf(2));
        breaker.setCurrentTime(20);
        assertFalse(breaker.checkState());
        assertTrue(breaker.isOpen());
    }

    // ----------------------------------------------------------------------
    // Manual open()/close()
    // ----------------------------------------------------------------------

    @Test
    void testManualOpenAndCloseResetTheCounter() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(2, 1, TimeUnit.HOURS);
        assertTrue(breaker.incrementAndCheckState()); // count 1
        assertTrue(breaker.incrementAndCheckState()); // count 2, not > 2
        assertFalse(breaker.incrementAndCheckState()); // count 3, opens
        assertTrue(breaker.isOpen());

        breaker.close();
        assertTrue(breaker.isClosed());

        // counter must have been reset by close(): two more events should not reopen it.
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testManualOpenWhenAlreadyClosedHasNoEffectBesidesState() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(2, 1, TimeUnit.HOURS);
        breaker.open();
        assertTrue(breaker.isOpen());
        assertFalse(breaker.checkState());
    }

    // ----------------------------------------------------------------------
    // Change listeners
    // ----------------------------------------------------------------------

    @Test
    void testChangeListenerNotifiedOnManualTransitions() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(1, 1, TimeUnit.HOURS);
        final List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();
        final PropertyChangeListener listener = new PropertyChangeListener() {
            @Override
            public void propertyChange(final PropertyChangeEvent evt) {
                events.add(evt);
            }
        };
        breaker.addChangeListener(listener);

        breaker.open();
        assertEquals(1, events.size());
        assertEquals("open", events.get(0).getPropertyName());
        assertEquals(Boolean.FALSE, events.get(0).getOldValue());
        assertEquals(Boolean.TRUE, events.get(0).getNewValue());

        // opening again while already open must not fire a spurious event.
        breaker.open();
        assertEquals(1, events.size());

        breaker.close();
        assertEquals(2, events.size());
        assertEquals(Boolean.TRUE, events.get(1).getOldValue());
        assertEquals(Boolean.FALSE, events.get(1).getNewValue());

        breaker.removeChangeListener(listener);
        breaker.open();
        assertEquals(2, events.size());
    }

    @Test
    void testChangeListenerNotifiedOnAutomaticOpening() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(1, 1, TimeUnit.HOURS);
        final List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();
        final PropertyChangeListener listener = new PropertyChangeListener() {
            @Override
            public void propertyChange(final PropertyChangeEvent evt) {
                events.add(evt);
            }
        };
        breaker.addChangeListener(listener);

        breaker.incrementAndCheckState(Integer.valueOf(2));
        assertEquals(1, events.size());
        assertEquals(Boolean.TRUE, events.get(0).getNewValue());
        assertTrue(breaker.isOpen());
    }

}
