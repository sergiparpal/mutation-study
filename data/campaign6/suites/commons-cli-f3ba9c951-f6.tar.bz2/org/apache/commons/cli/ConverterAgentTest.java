/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class ConverterAgentTest {

    @Test
    void testDefaultConverterIsIdentity() throws Exception {
        final Converter<?, RuntimeException> converter = Converter.DEFAULT;
        assertEquals("hello", converter.apply("hello"));
        assertEquals("", converter.apply(""));
        assertNull(converter.apply(null));
    }

    @Test
    void testClassConverterHappyPath() throws Exception {
        final Class<?> result = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, result);
    }

    @Test
    void testClassConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.ClassXyz123");
            }
        });
    }

    @Test
    void testFileConverterHappyPath() throws Exception {
        final File result = Converter.FILE.apply("some-test-file.txt");
        assertEquals(new File("some-test-file.txt"), result);
        assertEquals("some-test-file.txt", result.getName());
    }

    @Test
    void testFileConverterNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathConverterHappyPath() throws Exception {
        final Path result = Converter.PATH.apply("some/relative/path");
        assertEquals(Paths.get("some/relative/path"), result);
    }

    @Test
    void testPathConverterInvalidPathThrows() {
        assertThrows(InvalidPathException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("bad\u0000path");
            }
        });
    }

    @Test
    void testNumberConverterIntegerLikeReturnsLong() throws Exception {
        final Number result = Converter.NUMBER.apply("123");
        assertTrue(result instanceof Long);
        assertEquals(123L, result.longValue());
    }

    @Test
    void testNumberConverterNegativeInteger() throws Exception {
        final Number result = Converter.NUMBER.apply("-42");
        assertTrue(result instanceof Long);
        assertEquals(-42L, result.longValue());
    }

    @Test
    void testNumberConverterDecimalReturnsDouble() throws Exception {
        final Number result = Converter.NUMBER.apply("123.5");
        assertTrue(result instanceof Double);
        assertEquals(123.5, result.doubleValue(), 0.0001);
    }

    @Test
    void testNumberConverterNonNumericThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testNumberConverterEmptyStringThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("");
            }
        });
    }

    @Test
    void testObjectConverterHappyPath() throws Exception {
        final Object result = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(result);
        assertEquals(Object.class, result.getClass());
    }

    @Test
    void testObjectConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.ClassXyz123");
            }
        });
    }

    @Test
    void testObjectConverterNoNoArgConstructorThrows() {
        // java.util.List is an interface: it has no constructor to invoke.
        assertThrows(ReflectiveOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("java.util.List");
            }
        });
    }

    @Test
    void testUrlConverterHappyPath() throws Exception {
        final URL result = Converter.URL.apply("http://example.com:8080/path?query=1");
        assertEquals("http", result.getProtocol());
        assertEquals("example.com", result.getHost());
        assertEquals(8080, result.getPort());
        assertEquals("/path", result.getPath());
    }

    @Test
    void testUrlConverterMalformedThrows() {
        assertThrows(MalformedURLException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("");
            }
        });
    }

    @Test
    void testUrlConverterUnknownProtocolThrows() {
        assertThrows(MalformedURLException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("bogus-protocol://example.com");
            }
        });
    }

    @Test
    void testDateConverterRoundTrip() throws Exception {
        final SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        // truncate to whole seconds, since the pattern has no milliseconds field
        final long epochSeconds = System.currentTimeMillis() / 1000L * 1000L;
        final Date original = new Date(epochSeconds);
        final String formatted = format.format(original);

        final Date result = Converter.DATE.apply(formatted);

        assertEquals(original.getTime(), result.getTime());
    }

    @Test
    void testDateConverterInvalidStringThrows() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("this is not a date");
            }
        });
    }
}
