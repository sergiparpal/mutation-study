/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));
        assertFalse(StringUtils.isEmpty("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty(" "));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(""));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
    }

    @Test
    void testIsAnyAllNoneEmptyBlank() {
        assertTrue(StringUtils.isAnyEmpty((String) null));
        assertFalse(StringUtils.isAnyEmpty((String[]) null));
        assertTrue(StringUtils.isAnyEmpty(null, "foo"));
        assertTrue(StringUtils.isAnyEmpty("", "bar"));
        assertFalse(StringUtils.isAnyEmpty(" ", "bar"));
        assertFalse(StringUtils.isAnyEmpty("foo", "bar"));
        assertFalse(StringUtils.isAnyEmpty(new String[] {}));
        assertTrue(StringUtils.isAnyEmpty(new String[] { "" }));

        assertTrue(StringUtils.isAnyBlank((String) null));
        assertFalse(StringUtils.isAnyBlank((String[]) null));
        assertTrue(StringUtils.isAnyBlank(" ", "bar"));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));

        assertTrue(StringUtils.isAllEmpty());
        assertTrue(StringUtils.isAllEmpty((String[]) null));
        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "a"));

        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank(" ", null, ""));
        assertFalse(StringUtils.isAllBlank(" ", "bob"));

        assertFalse(StringUtils.isNoneEmpty((String) null));
        assertTrue(StringUtils.isNoneEmpty((String[]) null));
        assertTrue(StringUtils.isNoneEmpty("foo", "bar"));
        assertFalse(StringUtils.isNoneEmpty("", "bar"));

        assertFalse(StringUtils.isNoneBlank((String) null));
        assertTrue(StringUtils.isNoneBlank((String[]) null));
        assertTrue(StringUtils.isNoneBlank("foo", "bar"));
        assertFalse(StringUtils.isNoneBlank(" ", "bar"));
    }

    @Test
    void testIsAlphaFamily() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertFalse(StringUtils.isAlphanumeric("  "));
        assertTrue(StringUtils.isAlphanumeric("abc"));
        assertFalse(StringUtils.isAlphanumeric("ab c"));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));

        assertFalse(StringUtils.isAlphanumericSpace(null));
        assertTrue(StringUtils.isAlphanumericSpace(""));
        assertTrue(StringUtils.isAlphanumericSpace("  "));
        assertTrue(StringUtils.isAlphanumericSpace("ab c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab-c"));

        assertFalse(StringUtils.isAlphaSpace(null));
        assertTrue(StringUtils.isAlphaSpace(""));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2c"));
    }

    @Test
    void testIsNumericFamily() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric("  "));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("ab2c"));
        assertFalse(StringUtils.isNumeric("12-3"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertFalse(StringUtils.isNumeric("+123"));

        assertFalse(StringUtils.isNumericSpace(null));
        assertTrue(StringUtils.isNumericSpace(""));
        assertTrue(StringUtils.isNumericSpace("  "));
        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("ab2c"));
    }

    @Test
    void testIsWhitespaceAndAsciiPrintable() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace("abc"));

        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
        assertTrue(StringUtils.isAsciiPrintable("~"));
        assertFalse(StringUtils.isAsciiPrintable("\u007f"));
        assertFalse(StringUtils.isAsciiPrintable("Ceki Gülcü"));
    }

    @Test
    void testCaseChecks() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
        assertTrue(StringUtils.isMixedCase("A c"));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertFalse(StringUtils.isAllLowerCase("  "));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab c"));
        assertFalse(StringUtils.isAllLowerCase("ab1c"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));
    }

    @Test
    void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("abc"));
        assertEquals("abc", StringUtils.trim("    abc    "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("     "));
        assertEquals("abc", StringUtils.trimToEmpty("    abc    "));

        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("     "));
        assertEquals("abc", StringUtils.trimToNull("    abc    "));

        assertNull(StringUtils.trimAsciiControl(null));
        assertEquals("", StringUtils.trimAsciiControl(""));
        assertEquals("abc", StringUtils.trimAsciiControl("abc\u0000"));
        assertEquals(" abc ", StringUtils.trimAsciiControl(" abc "));
    }

    @Test
    void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertNull(StringUtils.strip(null, "xyz"));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));

        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));

        assertNull(StringUtils.stripStart(null, "*"));
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("abc  ", StringUtils.stripStart("yxabc  ", "xy "));

        assertNull(StringUtils.stripEnd(null, "*"));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertEquals("ab", StringUtils.stripEnd("abc", "c"));

        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] { "abc", "" }, StringUtils.stripAll("  abc  ", "   "));

        assertNull(StringUtils.stripAccents(null));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));

        assertFalse(StringUtils.equalsAny(null, (CharSequence[]) null));
        assertTrue(StringUtils.equalsAny(null, null, null));
        assertTrue(StringUtils.equalsAny("abc", "abc", "def"));
        assertFalse(StringUtils.equalsAny("abc", "ABC", "DEF"));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "ABC", "DEF"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", null, "def"));
    }

    @Test
    void testCompareFamily() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "B") > 0);
        assertTrue(StringUtils.compare("ab", "abc") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);

        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertFalse(StringUtils.contains(null, 'a'));
        assertFalse(StringUtils.contains("", 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));

        assertFalse(StringUtils.containsAny(null, 'z', 'a'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("aba", 'z'));

        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));
        assertFalse(StringUtils.containsAny(null, "za"));

        assertTrue(StringUtils.containsAny("abcd", "ab", null));
        assertTrue(StringUtils.containsAny("abc", "d", "abc"));
        assertFalse(StringUtils.containsAny("abc", "D", "ABC"));

        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "D", "ABC"));

        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));

        assertTrue(StringUtils.containsNone(null, 'x'));
        assertTrue(StringUtils.containsNone("ab1", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abz", 'x', 'y', 'z'));

        assertTrue(StringUtils.containsNone("ab1", "xyz"));
        assertFalse(StringUtils.containsNone("abz", "xyz"));

        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertTrue(StringUtils.containsOnly("", 'a'));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("ab1", 'a', 'b', 'c'));

        assertTrue(StringUtils.containsOnly("abab", "abc"));
        assertFalse(StringUtils.containsOnly("ab1", "abc"));

        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace(" ab"));
    }

    @Test
    void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));

        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", "b", 9));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", -1));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "", 2));
        assertEquals(3, StringUtils.indexOf("abc", "", 9));

        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(-1, StringUtils.indexOf("aaaaaaaa", 'Z'));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 'b'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a'));

        assertEquals(-1, StringUtils.indexOfAny("aba", new CharSequence[] { "z" }));
        assertEquals(0, StringUtils.indexOfAny("abcd", "ab", "cd"));

        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));
        assertEquals(-1, StringUtils.indexOfAnyBut("zzabyycdxx", ""));

        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] { "abc", "abc" }));
        assertEquals(2, StringUtils.indexOfDifference(new CharSequence[] { "abcde", "abxyz" }));
        assertEquals(0, StringUtils.indexOfDifference(new CharSequence[] { "", "abc" }));

        assertEquals(-1, StringUtils.indexOfDifference((CharSequence) null, null));
        assertEquals(2, StringUtils.indexOfDifference("abcde", "abxyz"));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));

        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "ab"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
    }

    @Test
    void testLastIndexOfFamily() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(4, StringUtils.lastIndexOf("aabaabaa", "ab", 8));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", "b", -1));

        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));
        assertEquals(-1, StringUtils.lastIndexOf("", 'a'));

        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", 'b', 4));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", 'b', 0));

        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", "mn", "op"));

        assertEquals(4, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "AB"));
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase(null, "A"));
    }

    @Test
    void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("", "", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(2, StringUtils.ordinalIndexOf("aabaabaa", "b", 1));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "b", 2));
        assertEquals(2, StringUtils.ordinalIndexOf("ababab", "aba", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("ababab", "aba", 3));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("abc", StringUtils.substring("abc", 0));
        assertEquals("c", StringUtils.substring("abc", 2));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", -2));
        assertEquals("abc", StringUtils.substring("abc", -4));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("", StringUtils.substring("abc", 4, 6));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    void testSubstringAfterBefore() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("bc", StringUtils.substringAfter("abc", 'a'));
        assertEquals("", StringUtils.substringAfter("abc", 'd'));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));
        assertEquals("abc", StringUtils.substringAfter("abc", ""));

        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("", StringUtils.substringAfterLast("a", 'a'));
        assertEquals("a", StringUtils.substringAfterLast("abcba", 'b'));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));

        assertNull(StringUtils.substringBeforeLast(null, "a"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("", StringUtils.substringBeforeLast("a", "a"));
        assertEquals("a", StringUtils.substringBeforeLast("a", "z"));
    }

    @Test
    void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));

        assertNull(StringUtils.substringBetween(null, "[", "]"));
        assertEquals("", StringUtils.substringBetween("", "", ""));
        assertNull(StringUtils.substringBetween("", "", "]"));
        assertEquals("abc", StringUtils.substringBetween("yabcz", "y", "z"));
        assertEquals("abc", StringUtils.substringBetween("yabczyabcz", "y", "z"));

        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertArrayEquals(new String[] {}, StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("", 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("", StringUtils.right("abc", 0));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("", 0, 2));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("abc", StringUtils.mid("abc", 0, 4));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("bat", StringUtils.leftPad("bat", 1));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", -1));
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("   ", StringUtils.rightPad("", 3));
        assertEquals("bat", StringUtils.rightPad("bat", 1));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
        assertEquals("batyzyzy", StringUtils.rightPad("bat", 8, "yz"));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5, (String) null));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals(" a  ", StringUtils.center("a", 4));

        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
    }

    @Test
    void testCapitalizeUncapitalizeSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("cat"));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc ", StringUtils.chomp("abc \r"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
        assertEquals("", StringUtils.chomp("\r\n"));

        assertEquals("foo", StringUtils.chomp("foobar", "bar"));
        assertEquals("foobar", StringUtils.chomp("foobar", "baz"));
        assertEquals("", StringUtils.chomp("foo", "foo"));
        assertEquals("foo ", StringUtils.chomp("foo ", "foo"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc ", StringUtils.chop("abc \r"));
        assertEquals("abc", StringUtils.chop("abc\n"));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("", StringUtils.chop("a"));
        assertEquals("", StringUtils.chop("\r\n"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("tab", StringUtils.reverse("bat"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("", StringUtils.reverseDelimited("", '.'));
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -9));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat((String) null, 2));
        assertEquals("", StringUtils.repeat("", 0));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));

        assertEquals("aaaaa", StringUtils.repeat('a', 5));
        assertEquals("", StringUtils.repeat('a', -1));

        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("xx", StringUtils.repeat("", "x", 3));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    void testReplaceFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("aba", StringUtils.replace("aba", "a", null));
        assertEquals("b", StringUtils.replace("aba", "a", ""));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));

        assertEquals("ayaxax", StringUtils.replace("axaxax", "x", "y", 1));
        assertEquals("ayayax", StringUtils.replace("axaxax", "x", "y", 2));
        assertEquals("axaxax", StringUtils.replace("axaxax", "x", "y", 0));

        assertEquals("zbz", StringUtils.replaceIgnoreCase("aba", "A", "z"));
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
        assertEquals("zba", StringUtils.replaceOnceIgnoreCase("aba", "A", "z"));

        assertEquals("dcte", StringUtils.replaceEach("abcde", new String[] { "ab", "d" }, new String[] { "d", "t" }));
        assertEquals("b", StringUtils.replaceEach("aba", new String[] { "a" }, new String[] { "" }));
        assertThrows(IllegalArgumentException.class,
                () -> StringUtils.replaceEach("abcde", new String[] { "ab" }, new String[] { "x", "y" }));

        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] { "ab", "d" }, new String[] { "d", "t" }));

        assertEquals("", StringUtils.removeAll("any", ".*"));
        assertEquals("ABC123", StringUtils.removeAll("ABCabc123abc", "[a-z]"));
        assertEquals("bc", StringUtils.removeFirst("abc", ".?"));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".COM"));
    }

    @Test
    void testReplaceCharsSimple() {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
        assertEquals("", StringUtils.replaceChars("", 'a', 'b'));
        assertEquals("yby", StringUtils.replaceChars("aba", 'a', 'y'));

        assertNull(StringUtils.replaceChars(null, "ab", "xy"));
        assertEquals("jelly", StringUtils.replaceChars("hello", "ho", "jy"));
    }

    @Test
    void testRemoveFamily() {
        assertNull(StringUtils.remove(null, 'u'));
        assertEquals("", StringUtils.remove("", 'u'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("queued", StringUtils.remove("queued", 'z'));

        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("abc", StringUtils.remove("abc", (String) null));
        assertEquals("abc", StringUtils.remove("abc", ""));
        assertEquals("qd", StringUtils.remove("queued", "ue"));

        assertNull(StringUtils.removeStart(null, "abc"));
        assertEquals("def", StringUtils.removeStart("abcdef", "abc"));
        assertEquals("abcdef", StringUtils.removeStart("abcdef", "xyz"));

        assertNull(StringUtils.removeStartIgnoreCase(null, "abc"));
        assertEquals("def", StringUtils.removeStartIgnoreCase("ABCdef", "abc"));

        assertNull(StringUtils.removeEnd(null, "abc"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".com."));

        assertNull(StringUtils.removeIgnoreCase(null, "ue"));
        assertEquals("qd", StringUtils.removeIgnoreCase("queued", "UE"));

        assertNull(StringUtils.removePattern(null, "x"));
        assertEquals("AB", StringUtils.removePattern("A<__>\n<__>B", "<.*>"));
        assertEquals("ABC123", StringUtils.removePattern("ABCabc123", "[a-z]"));
    }

    @Test
    void testAppendPrependIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, null));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", StringUtils.appendIfMissing("abcXYZ", "xyz"));

        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));

        assertNull(StringUtils.prependIfMissing(null, null));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", StringUtils.prependIfMissing("XYZabc", "xyz"));

        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefg", 3));

        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 8, 10));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefghij", 0, 3));

        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("ab..", StringUtils.abbreviate("abcdefg", "..", 4));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefg", "...", 3));

        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 0));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 8));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", -1));

        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghijklmno", 0, 10));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefghijklmno", -1, 10));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefghij", 3, -1));
    }

    @Test
    void testWrapUnwrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", '\"'));

        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", "\""));
        assertEquals("''abcd''", StringUtils.wrap("'abcd'", "'"));

        assertEquals("xabx", StringUtils.wrapIfMissing("ab", 'x'));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", '\"'));
        assertEquals("/", StringUtils.wrapIfMissing("/", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));

        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", "\""));
        assertEquals("'abcd'", StringUtils.wrapIfMissing("'abcd'", "'"));

        assertNull(StringUtils.unwrap(null, 'a'));
        assertEquals("a", StringUtils.unwrap("a", 'a'));
        assertEquals("", StringUtils.unwrap("aa", 'a'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("A", StringUtils.unwrap("A", '#'));

        assertEquals("abc", StringUtils.unwrap("'abc'", "'"));
        assertEquals("BabcB", StringUtils.unwrap("AABabcBAA", "AA"));
        assertEquals("A", StringUtils.unwrap("A", "#"));
    }

    @Test
    void testSplitBasic() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[] {}, StringUtils.split(""));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] { "abc" }, StringUtils.split(" abc "));

        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[] { "a:b:c" }, StringUtils.split("a:b:c", '.'));

        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.split("ab:cd:ef", ":"));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc def", (String) null));

        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.split("ab:cd:ef", ":", 2));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.split("ab:cd:ef", ":", 0));
    }

    @Test
    void testSplitPreserveAllTokens() {
        assertNull(StringUtils.splitPreserveAllTokens(null));
        assertArrayEquals(new String[] { "", "abc", "" }, StringUtils.splitPreserveAllTokens(" abc "));
        assertArrayEquals(new String[] { "a", "", "b", "c" }, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] { "ab", "", "cd", "ef" }, StringUtils.splitPreserveAllTokens("ab::cd:ef", ":"));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":", 2));
    }

    @Test
    void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "-!-"));
        assertArrayEquals(new String[] {}, StringUtils.splitByWholeSeparator("", "-!-"));
        assertArrayEquals(new String[] { "ab", "de", "fg" }, StringUtils.splitByWholeSeparator("ab de fg", null));
        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));

        assertArrayEquals(new String[] { "", "cd", "ef" }, StringUtils.splitByWholeSeparatorPreserveAllTokens("-!-cd-!-ef", "-!-"));
    }

    @Test
    void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[] {}, StringUtils.splitByCharacterType(""));
        assertArrayEquals(new String[] { "ab", " ", "de", " ", "fg" }, StringUtils.splitByCharacterType("ab de fg"));
        assertArrayEquals(new String[] { "number", "5" }, StringUtils.splitByCharacterType("number5"));
        assertArrayEquals(new String[] { "foo", "B", "ar" }, StringUtils.splitByCharacterType("fooBar"));
        assertArrayEquals(new String[] { "ASFR", "ules" }, StringUtils.splitByCharacterType("ASFRules"));

        assertArrayEquals(new String[] { "foo", "Bar" }, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] { "ASF", "Rules" }, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    void testJoinFamily() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[] {}, ','));
        assertEquals("a;b;c", StringUtils.join(new Object[] { "a", "b", "c" }, ';'));
        assertEquals("a-b-c", StringUtils.join(new Object[] { "a", "b", "c" }, "-"));

        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        assertEquals("a,b,c", StringUtils.join((Iterable<?>) list, ","));
        assertEquals("a,b,c", StringUtils.join(list.iterator(), ","));
        assertEquals("b,c", StringUtils.join(list, ",", 1, 3));

        assertNull(StringUtils.join((Object[]) null));
        assertEquals("abc", StringUtils.join("a", "b", "c"));

        assertEquals("a,b", StringUtils.joinWith(",", "a", "b"));
        assertEquals("a,,b", StringUtils.joinWith(",", "a", null, "b"));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.joinWith(",", (Object[]) null));

        assertEquals("1;2;3", StringUtils.join(new int[] { 1, 2, 3 }, ';'));
        assertEquals("2;3", StringUtils.join(new int[] { 1, 2, 3 }, ';', 1, 3));
    }

    @Test
    void testStartsWithEndsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertFalse(StringUtils.startsWithAny(null, "abc"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));

        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));

        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));

        assertFalse(StringUtils.endsWithAny(null, "abc"));
        assertTrue(StringUtils.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(StringUtils.endsWithAny("abcXYZ", "def", "xyz"));
    }

    @Test
    void testDefaultValueHelpers() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("bat", StringUtils.defaultString("bat"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("", StringUtils.defaultString("", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfBlank("", "NULL"));
        assertEquals(" ", StringUtils.defaultIfEmpty(" ", "NULL"));
        assertNull(StringUtils.defaultIfBlank("", (String) null));

        assertNull(StringUtils.firstNonBlank());
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("xyz", StringUtils.firstNonBlank(null, "xyz", "abc"));

        assertNull(StringUtils.firstNonEmpty());
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));

        assertEquals("NULL", StringUtils.getIfBlank("", () -> "NULL"));
        assertEquals("bat", StringUtils.getIfBlank("bat", () -> "NULL"));
        assertEquals(" ", StringUtils.getIfEmpty(" ", () -> "NULL"));
    }

    @Test
    void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("abc"));
        assertEquals("abc", StringUtils.deleteWhitespace("   ab  c  "));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("", StringUtils.normalizeSpace("    "));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
    }

    @Test
    void testDifferenceAndCommonPrefix() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "xyz"));

        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix(new String[] {}));
        assertEquals("abc", StringUtils.getCommonPrefix(new String[] { "abc" }));
        assertEquals("ab", StringUtils.getCommonPrefix(new String[] { "abcde", "abxyz" }));
        assertEquals("", StringUtils.getCommonPrefix(new String[] { "abcde", "xyz" }));
    }

    @Test
    void testCountMatchesAndGetDigits() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));
        assertEquals(0, StringUtils.countMatches("abba", 'x'));

        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
        assertEquals(1, StringUtils.countMatches("ababa", "aba"));

        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1000", StringUtils.getDigits("1000$"));
        assertEquals("5417543010", StringUtils.getDigits("(541) 754-3010"));
    }

    @Test
    void testDistanceMetrics() {
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance(null, "a"));
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(8, StringUtils.getLevenshteinDistance("hippo", "zzzzzzzz"));

        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance("a", "b", -1));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("aaapppp", "", 6));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));

        assertThrows(IllegalArgumentException.class, () -> StringUtils.getJaroWinklerDistance(null, "a"));
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("", ""), 0.01);
        assertEquals(0.93, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.01);
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("fly", "ant"), 0.01);

        assertThrows(IllegalArgumentException.class, () -> StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH));
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Room", "o", Locale.ENGLISH));
        assertEquals(3, StringUtils.getFuzzyDistance("Apache Software Foundation", "asf", Locale.ENGLISH));
    }

    @Test
    void testOverlay() {
        assertNull(StringUtils.overlay(null, "x", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    void testToCodePointsAndCaseConversion() {
        assertNull(StringUtils.toCodePoints(null));
        assertEquals(0, StringUtils.toCodePoints("").length);
        assertArrayEquals(new int[] { 'a', 'b', 'c' }, StringUtils.toCodePoints("abc"));

        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
        assertEquals("ABC", StringUtils.upperCase("aBc", Locale.ENGLISH));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ENGLISH));
    }

    @Test
    void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("", StringUtils.valueOf(new char[] {}));
        assertEquals("abc", StringUtils.valueOf(new char[] { 'a', 'b', 'c' }));
    }
}
