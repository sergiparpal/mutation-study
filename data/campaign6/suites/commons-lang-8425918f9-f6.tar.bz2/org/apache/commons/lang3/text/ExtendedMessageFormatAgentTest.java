/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
class ExtendedMessageFormatAgentTest {

    /**
     * Simple {@link FormatFactory} that upper-cases the string representation
     * of the argument it is asked to format. The optional argument string is
     * ignored unless it equals "reverse", in which case the result is reversed.
     */
    private static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new UpperFormat(arguments);
        }
    }

    private static final class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String arguments;

        UpperFormat(final String arguments) {
            this.arguments = arguments;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            String result = String.valueOf(obj).toUpperCase(Locale.ROOT);
            if ("reverse".equals(arguments)) {
                result = new StringBuilder(result).reverse().toString();
            }
            return toAppendTo.append(result);
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof UpperFormat)) {
                return false;
            }
            final UpperFormat other = (UpperFormat) obj;
            return arguments == null ? other.arguments == null : arguments.equals(other.arguments);
        }

        @Override
        public int hashCode() {
            return arguments == null ? 0 : arguments.hashCode();
        }
    }

    private static Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    // -- construction / basic formatting (no registry) ----------------

    @Test
    void testBasicPatternNoRegistryFormatsLikeMessageFormat() {
        final String pattern = "{0}, {1}!";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US);
        final MessageFormat mf = new MessageFormat(pattern, Locale.US);
        final Object[] args = {"Hello", "World"};
        assertEquals(mf.format(args), emf.format(args));
        assertEquals("Hello, World!", emf.format(args));
    }

    @Test
    void testDefaultLocaleConstructorUsesDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null, null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testToPatternNoRegistryMatchesMessageFormat() {
        final String pattern = "{0,number,00.0}-{1}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US);
        final MessageFormat mf = new MessageFormat(pattern, Locale.US);
        assertEquals(mf.toPattern(), emf.toPattern());
    }

    // -- custom format registry ----------------------------------------

    @Test
    void testCustomFormatIsUsedForFormatting() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testCustomFormatWithArguments() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,reverse}", Locale.US, upperRegistry());
        assertEquals("CBA", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testToPatternReinsertsCustomFormatDescription() {
        final String pattern = "{0,upper}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, upperRegistry());
        assertEquals(pattern, emf.toPattern());
    }

    @Test
    void testToPatternReinsertsCustomFormatDescriptionWithArguments() {
        final String pattern = "{0,upper,reverse}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, upperRegistry());
        assertEquals(pattern, emf.toPattern());
    }

    @Test
    void testMultipleArgumentsMixedCustomAndStandardFormats() {
        final String pattern = "{1,upper} and {0}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, upperRegistry());
        assertEquals("WORLD and hello", emf.format(new Object[] {"hello", "world"}));
    }

    @Test
    void testUnknownCustomFormatNameDelegatesToMessageFormatAndFails() {
        // "bogus" is not in the registry, so the description is left in the
        // pattern handed to MessageFormat, which does not know this format type.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("x", Locale.US, upperRegistry());
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.applyPattern("{0,bogus}");
            }
        });
    }

    @Test
    void testEmptyRegistryBehavesLikeNoRegistryForStandardFormats() {
        final Map<String, FormatFactory> emptyRegistry = new HashMap<String, FormatFactory>();
        final String pattern = "{0}, {1}!";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, emptyRegistry);
        assertEquals("Hello, World!", emf.format(new Object[] {"Hello", "World"}));
    }

    // -- equals / hashCode -----------------------------------------------

    @Test
    void testEqualsReflexive() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, upperRegistry());
        assertTrue(emf.equals(emf));
    }

    @Test
    void testEqualsNullIsFalse() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsDifferentClassIsFalse() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        final MessageFormat mf = new MessageFormat("{0}", Locale.US);
        assertFalse(emf.equals(mf));
    }

    @Test
    void testEqualsAndHashCodeSamePatternSameRegistry() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentPatternIsFalse() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US, registry);
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsDifferentRegistryIsFalse() {
        final ExtendedMessageFormat withRegistry = new ExtendedMessageFormat("{0}", Locale.US, upperRegistry());
        final ExtendedMessageFormat withoutRegistry = new ExtendedMessageFormat("{0}", Locale.US, (Map<String, FormatFactory>) null);
        assertNotEquals(withRegistry, withoutRegistry);
    }

    // -- unsupported mutator operations -----------------------------------

    @Test
    void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, null);
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, null);
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[0]);
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[0]);
            }
        });
    }

    // -- malformed patterns (registry present, so this class's own parser runs) --

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", Locale.US, upperRegistry());
            }
        });
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("'unterminated", Locale.US, upperRegistry());
            }
        });
    }

    @Test
    void testInvalidFormatArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{a,upper}", Locale.US, upperRegistry());
            }
        });
    }

    @Test
    void testMissingClosingBraceThrows() {
        // the format element has text after the format description but no closing brace
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper}{1", Locale.US, upperRegistry());
            }
        });
    }

    @Test
    void testNullPatternThrowsWithRegistry() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null, Locale.US, upperRegistry());
            }
        });
    }

    @Test
    void testNullPatternThrowsWithoutRegistry() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null, Locale.US);
            }
        });
    }

    // -- re-applying patterns ---------------------------------------------

    @Test
    void testApplyPatternReplacesPreviousPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        emf.applyPattern("plain {0}");
        assertEquals("plain abc", emf.format(new Object[] {"abc"}));
        assertEquals("plain {0}", emf.toPattern());
    }

    @Test
    void testQuotedBraceIsNotTreatedAsFormatElement() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{'0'}'", Locale.US, upperRegistry());
        assertEquals("{0}", emf.format(new Object[] {"ignored"}));
    }
}
