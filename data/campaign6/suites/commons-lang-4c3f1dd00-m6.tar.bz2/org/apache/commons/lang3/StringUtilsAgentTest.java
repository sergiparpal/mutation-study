/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    // --- isEmpty / isBlank family ---

    @Test
    void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty("abc"));
    }

    @Test
    void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertTrue(StringUtils.isBlank(" \t\n "));
        assertFalse(StringUtils.isBlank(" a "));
    }

    @Test
    void testIsAnyAllNoneBlankEmpty() {
        assertTrue(StringUtils.isAnyBlank("a", null));
        assertFalse(StringUtils.isAnyBlank("a", "b"));
        assertTrue(StringUtils.isAllBlank(null, "  "));
        assertFalse(StringUtils.isAllBlank("a", "  "));
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertTrue(StringUtils.isAllEmpty("", ""));
        assertFalse(StringUtils.isAllEmpty("", "b"));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", null));
        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        // empty varargs/null array edge cases
        assertTrue(StringUtils.isAllBlank((CharSequence[]) null));
        assertTrue(StringUtils.isNoneBlank((CharSequence[]) null));
    }

    // --- trim / strip family ---

    @Test
    void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    void testTrimToEmptyAndNull() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertEquals("abc", StringUtils.trimToEmpty("  abc "));

        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull(" abc "));
    }

    @Test
    void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
        assertNull(StringUtils.strip(null, "x"));
    }

    @Test
    void testStripStartEnd() {
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertNull(StringUtils.stripStart(null, "x"));
        assertNull(StringUtils.stripEnd(null, "x"));
    }

    @Test
    void testStripToEmptyAndNull() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));
        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    void testStripAll() {
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.stripAll(" a ", " b "));
        assertNull(StringUtils.stripAll((String[]) null));
    }

    // --- substring family ---

    @Test
    void testSubstringOneArg() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("", StringUtils.substring("abcde", 10));
        assertEquals("de", StringUtils.substring("abcde", -2));
    }

    @Test
    void testSubstringTwoArgs() {
        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("abc", StringUtils.substring("abc", 0, 100));
    }

    @Test
    void testSubstringBeforeAfter() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("abc", "x"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));
    }

    @Test
    void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertNull(StringUtils.substringBetween("abc", "x"));
        assertEquals("b", StringUtils.substringBetween("axbxc", "x", "x"));
        assertEquals("value", StringUtils.substringBetween("<tag>value</tag>", "<tag>", "</tag>"));
    }

    @Test
    void testSubstringsBetween() {
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
        assertNull(StringUtils.substringsBetween("abc", "[", "]"));
    }

    // --- indexOf / contains family ---

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("abc", "b"));
        assertEquals(-1, StringUtils.indexOf("abc", "z"));
    }

    @Test
    void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(2, StringUtils.lastIndexOf("abcabc".substring(0, 3), "c"));
        assertEquals(3, StringUtils.lastIndexOf("abcabc", "a"));
    }

    @Test
    void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertTrue(StringUtils.contains("abc", 'b'));
        assertFalse(StringUtils.contains(null, 'b'));
    }

    @Test
    void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("ABC", "b"));
        assertFalse(StringUtils.containsIgnoreCase("ABC", "z"));
    }

    @Test
    void testContainsAnyNoneOnly() {
        assertTrue(StringUtils.containsAny("abc", 'a', 'z'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'z'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a', 'y'));
        assertTrue(StringUtils.containsNone((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsOnly("aab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("aabc", 'a', 'b'));
        assertFalse(StringUtils.containsOnly((CharSequence) null, 'a'));
    }

    @Test
    void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(""));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("a b"));
    }

    // --- equals / compare family ---

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    void testEqualsAny() {
        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);
        // nullIsLess = false -> null is treated as greater
        assertTrue(StringUtils.compare(null, "a", false) > 0);
    }

    @Test
    void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
    }

    // --- startsWith / endsWith family ---

    @Test
    void testStartsWithEndsWith() {
        assertFalse(StringUtils.startsWith(null, "a"));
        assertTrue(StringUtils.startsWith("abc", "ab"));
        assertFalse(StringUtils.startsWith("abc", "AB"));
        assertTrue(StringUtils.startsWithIgnoreCase("abc", "AB"));

        assertFalse(StringUtils.endsWith(null, "c"));
        assertTrue(StringUtils.endsWith("abc", "bc"));
        assertFalse(StringUtils.endsWith("abc", "BC"));
        assertTrue(StringUtils.endsWithIgnoreCase("abc", "BC"));
    }

    @Test
    void testStartsWithAnyEndsWithAny() {
        assertTrue(StringUtils.startsWithAny("abc", "xy", "ab"));
        assertFalse(StringUtils.startsWithAny("abc", "xy", "zz"));
        assertTrue(StringUtils.endsWithAny("abc", "xy", "bc"));
        assertFalse(StringUtils.endsWithAny("abc", "xy", "zz"));
    }

    // --- case conversion ---

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ROOT));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));
    }

    @Test
    void testCapitalizeUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    // --- padding family ---

    @Test
    void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyxyab", StringUtils.leftPad("ab", 6, "xy"));
    }

    @Test
    void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertEquals("kkabkk", StringUtils.center("ab", 6, 'k'));
    }

    // --- repeat ---

    @Test
    void testRepeatChar() {
        assertEquals("", StringUtils.repeat('x', 0));
        assertEquals("", StringUtils.repeat('x', -2));
        assertEquals("xxx", StringUtils.repeat('x', 3));
    }

    @Test
    void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));
        assertEquals("", StringUtils.repeat("a", ",", 0));
    }

    // --- reverse ---

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    void testReverseDelimited() {
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("a", StringUtils.reverseDelimited("a", '.'));
    }

    // --- split family ---

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd  ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", "."));
    }

    @Test
    void testSplitPreserveAllTokens() {
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] {"", "a", "b"}, StringUtils.splitPreserveAllTokens(".a.b", '.'));
    }

    @Test
    void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "."));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.splitByWholeSeparator("a..b..c", ".."));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.splitByWholeSeparator("a.b.c", ".", 2));
    }

    @Test
    void testSplitByCharacterType() {
        assertArrayEquals(new String[] {"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
        assertNull(StringUtils.splitByCharacterType(null));
    }

    // --- join family ---

    @Test
    void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    void testJoinIterable() {
        assertEquals("a-b-c", StringUtils.join(Arrays.asList("a", "b", "c"), "-"));
        assertEquals("", StringUtils.join(Collections.emptyList(), "-"));
        assertNull(StringUtils.join((Iterable<?>) null, "-"));
    }

    @Test
    void testJoinWith() {
        assertEquals("a,b,c", StringUtils.joinWith(",", "a", "b", "c"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    // --- remove / replace family ---

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("bc", StringUtils.remove("abc", 'a'));
        assertEquals("", StringUtils.remove("", "a"));
        assertNull(StringUtils.remove(null, "a"));
        assertEquals("queued", StringUtils.remove("queued", "zz"));
        assertEquals("ueued", StringUtils.remove("queued", "q"));
    }

    @Test
    void testRemoveStartEnd() {
        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("bc", StringUtils.removeStart("abc", "a"));
        assertEquals("abc", StringUtils.removeStart("abc", "x"));

        assertNull(StringUtils.removeEnd(null, "a"));
        assertEquals("ab", StringUtils.removeEnd("abc", "c"));
        assertEquals("abc", StringUtils.removeEnd("abc", "x"));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
        assertEquals("xbc", StringUtils.replace("abc", "a", "x"));
        assertEquals("xbxbc", StringUtils.replace("ababc", "a", "x", -1));
        assertEquals("xbabc", StringUtils.replace("ababc", "a", "x", 1));
    }

    @Test
    void testReplaceOnce() {
        assertEquals("xbabc", StringUtils.replaceOnce("ababc", "a", "x"));
        assertEquals("abc", StringUtils.replaceOnce("abc", "z", "x"));
    }

    @Test
    void testReplaceEach() {
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abc", new String[] {"a"}, new String[] {"b", "c"});
            }
        });
    }

    @Test
    void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
        assertEquals("bbcc", StringUtils.replaceChars("aacc", 'a', 'b'));
        assertEquals("ba", StringUtils.replaceChars("ba", "z", "a"));
    }

    // --- abbreviate / truncate ---

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 3));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertEquals("cde", StringUtils.truncate("abcdefg", 2, 3));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1, 2);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", 0, -1);
            }
        });
    }

    // --- misc numeric / char classification ---

    @Test
    void testIsNumericAlpha() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2"));

        assertTrue(StringUtils.isAlphanumeric("ab2"));
        assertFalse(StringUtils.isAlphanumeric("ab 2"));
    }

    @Test
    void testIsWhitespaceAndCase() {
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace(" a "));
        assertFalse(StringUtils.isWhitespace(null));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("Abc"));
        assertFalse(StringUtils.isAllLowerCase(""));

        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));

        assertTrue(StringUtils.isMixedCase("Abc"));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
    }

    @Test
    void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("12", StringUtils.getDigits("a1b2c"));
    }

    // --- default / firstNon family ---

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NA", StringUtils.defaultString(null, "NA"));
        assertEquals("abc", StringUtils.defaultString("abc", "NA"));
    }

    @Test
    void testDefaultIfEmptyBlank() {
        assertEquals("NA", StringUtils.defaultIfEmpty("", "NA"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NA"));
        assertNull(StringUtils.defaultIfEmpty(null, null));

        assertEquals("NA", StringUtils.defaultIfBlank("  ", "NA"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NA"));
    }

    @Test
    void testFirstNonBlankEmpty() {
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "  ", "abc"));
        assertNull(StringUtils.firstNonBlank(null, "", "  "));
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty(null, ""));
    }

    // --- counting / difference / distance ---

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(0, StringUtils.countMatches("", "a"));
    }

    @Test
    void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("ty", StringUtils.difference("abcde", "abcty"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "xyz", 1));
        assertEquals(3, StringUtils.getLevenshteinDistance("abc", "xyz", 5));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    // --- wrap / unwrap ---

    @Test
    void testWrapUnwrapChar() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));
    }

    @Test
    void testWrapIfMissing() {
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
    }

    // --- left / right / mid ---

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 5));
    }

    // --- normalizeSpace / deleteWhitespace / chomp / chop ---

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab cd", StringUtils.normalizeSpace("  ab   cd  "));
    }

    @Test
    void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b c "));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
    }

    // --- length / toCodePoints / valueOf ---

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testValueOf() {
        assertNull(StringUtils.valueOf((char[]) null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
        assertEquals("", StringUtils.valueOf(new char[0]));
    }

    @Test
    void testToCodePoints() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
    }

    // --- getCommonPrefix / getFuzzyDistance / getJaroWinklerDistance ---

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abc"));
    }

    @Test
    void testGetFuzzyDistance() {
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertTrue(StringUtils.getFuzzyDistance("Workshop", "Wo", Locale.ENGLISH) > 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH);
            }
        });
    }

    @Test
    void testGetJaroWinklerDistance() {
        assertEquals(1.0d, StringUtils.getJaroWinklerDistance("abc", "abc"), 0.0001d);
        assertEquals(0.0d, StringUtils.getJaroWinklerDistance("abc", "xyz"), 0.0001d);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "a");
            }
        });
    }

    // --- toRootLowerCase / toRootUpperCase ---

    @Test
    void testToRootCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    // --- appendIfMissing / prependIfMissing ---

    @Test
    void testAppendPrependIfMissing() {
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertNull(StringUtils.appendIfMissing(null, "xyz"));

        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertNull(StringUtils.prependIfMissing(null, "xyz"));
    }
}
