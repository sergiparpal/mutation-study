/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final TimeZone IST = TimeZone.getTimeZone("GMT+05:30");

    private static FastDatePrinter newPrinter(final String pattern, final TimeZone tz, final Locale locale) {
        return new FastDatePrinter(pattern, tz, locale);
    }

    private static Calendar utcCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    // ---- Basic formatting -------------------------------------------------

    @Test
    void testFormatDateBasicPattern() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss.SSS", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 6);
        assertEquals("2023-01-02T03:04:05.006", printer.format(cal.getTime()));
    }

    @Test
    void testFormatCalendarBasicPattern() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss.SSS", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 6);
        assertEquals("2023-01-02T03:04:05.006", printer.format(cal));
    }

    @Test
    void testFormatLongMillis() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("1970-01-01", printer.format(0L));
    }

    @Test
    void testFormatMonthAndWeekdayText() {
        final FastDatePrinter printer = newPrinter("EEEE, MMMM EEE MMM", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("Monday, January Mon Jan", printer.format(cal));
    }

    @Test
    void testFormatEraAndAmPm() {
        final FastDatePrinter printer = newPrinter("G a", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 0);
        assertEquals("AD AM", printer.format(cal));
    }

    // ---- Appendable return identity ---------------------------------------

    @Test
    void testFormatDateIntoStringBuilderReturnsSameInstance() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final StringBuilder sb = new StringBuilder("prefix-");
        final StringBuilder result = printer.format(new Date(0L), sb);
        assertSame(sb, result);
        assertEquals("prefix-1970", result.toString());
    }

    @Test
    void testFormatLongIntoStringBufferReturnsSameInstance() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final StringBuffer sb = new StringBuffer("x");
        final StringBuffer result = printer.format(0L, sb);
        assertSame(sb, result);
        assertEquals("x1970", result.toString());
    }

    // ---- Calendar zone handling --------------------------------------------

    @Test
    void testFormatCalendarUsesPrinterZoneRegardlessOfCalendarZone() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss.SSS", UTC, Locale.US);
        final Calendar utcSource = utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 6);
        final long instant = utcSource.getTimeInMillis();

        final TimeZone ny = TimeZone.getTimeZone("America/New_York");
        final Calendar nyCalendar = new GregorianCalendar(ny, Locale.US);
        nyCalendar.setTimeInMillis(instant);

        assertEquals("2023-01-02T03:04:05.006", printer.format(nyCalendar));
        // the source calendar must not have been mutated
        assertEquals("America/New_York", nyCalendar.getTimeZone().getID());
        assertEquals(instant, nyCalendar.getTimeInMillis());
    }

    @Test
    void testFormatCalendarStringBufferOverloadAlsoUsesPrinterZone() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss.SSS", UTC, Locale.US);
        final Calendar utcSource = utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 6);
        final long instant = utcSource.getTimeInMillis();

        final TimeZone ny = TimeZone.getTimeZone("America/New_York");
        final Calendar nyCalendar = new GregorianCalendar(ny, Locale.US);
        nyCalendar.setTimeInMillis(instant);

        final StringBuffer buf = new StringBuffer();
        final StringBuffer result = printer.format(nyCalendar, buf);
        assertSame(buf, result);
        assertEquals("2023-01-02T03:04:05.006", result.toString());
    }

    // ---- Hour field boundary behaviour -------------------------------------

    @Test
    void testTwelveHourFieldMidnightBecomesTwelve() {
        final FastDatePrinter printer = newPrinter("hh", UTC, Locale.US);
        final Calendar midnight = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("12", printer.format(midnight));
    }

    @Test
    void testTwentyFourHourFieldMidnightBecomesTwentyFour() {
        final FastDatePrinter printer = newPrinter("kk", UTC, Locale.US);
        final Calendar midnight = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("24", printer.format(midnight));
    }

    @Test
    void testHourOfDayAndHourInAmPmAtMidnightAreZero() {
        final FastDatePrinter printer = newPrinter("HH KK", UTC, Locale.US);
        final Calendar midnight = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("00 00", printer.format(midnight));
    }

    // ---- Year field quirks (documented SimpleDateFormat exceptions) -------

    @Test
    void testTwoDigitYearTruncates() {
        final FastDatePrinter printer = newPrinter("yy", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 2005);
        assertEquals("05", printer.format(cal));
    }

    @Test
    void testSingleYearPatternStillPadsToFourDigits() {
        // Documented FastDatePrinter year-pattern exception: unlike plain
        // SimpleDateFormat, a single 'y' is still padded to a 4 digit minimum.
        final FastDatePrinter printer = newPrinter("y", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 999);
        assertEquals("0999", printer.format(cal));
    }

    @Test
    void testFourDigitYearPatternDoesNotTruncateLargeYears() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 12345);
        assertEquals("12345", printer.format(cal));
    }

    // ---- Day of week / day of year numeric fields --------------------------

    @Test
    void testNumericDayOfWeekIsoMondayIsOne() {
        final FastDatePrinter printer = newPrinter("u", UTC, Locale.US);
        final Calendar monday = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("1", printer.format(monday));
    }

    @Test
    void testNumericDayOfWeekIsoSundayIsSeven() {
        final FastDatePrinter printer = newPrinter("u", UTC, Locale.US);
        final Calendar sunday = utcCalendar(2023, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        assertEquals("7", printer.format(sunday));
    }

    @Test
    void testUnpaddedDayOfYearThreeDigitsNotTruncated() {
        final FastDatePrinter printer = newPrinter("D", UTC, Locale.US);
        final Calendar lastDay = utcCalendar(2023, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        assertEquals("365", printer.format(lastDay));
    }

    @Test
    void testWeekYearMidYearMatchesCalendarYear() {
        final FastDatePrinter weekYearPrinter = newPrinter("YYYY", UTC, Locale.US);
        final FastDatePrinter yearPrinter = newPrinter("yyyy", UTC, Locale.US);
        final Calendar midYear = utcCalendar(2005, Calendar.JULY, 15, 12, 0, 0, 0);
        assertEquals(yearPrinter.format(midYear), weekYearPrinter.format(midYear));
        assertEquals("2005", weekYearPrinter.format(midYear));
    }

    // ---- Time zone number / ISO 8601 rules ---------------------------------

    @Test
    void testTimeZoneNumberRuleSingleTokenNoColonUtc() {
        final FastDatePrinter printer = newPrinter("Z", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("+0000", printer.format(cal));
    }

    @Test
    void testTimeZoneNumberRuleSingleTokenNoColonOffset() {
        final FastDatePrinter printer = newPrinter("Z", IST, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("+0530", printer.format(cal));
    }

    @Test
    void testTimeZoneNumberRuleDoubleTokenUsesIso8601ZShortcutAtUtc() {
        final FastDatePrinter printer = newPrinter("ZZ", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("Z", printer.format(cal));
    }

    @Test
    void testTimeZoneNumberRuleDoubleTokenColonOffset() {
        final FastDatePrinter printer = newPrinter("ZZ", IST, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("+05:30", printer.format(cal));
    }

    @Test
    void testTimeZoneNumberRuleTripleTokenAlwaysNumericAtUtc() {
        final FastDatePrinter printer = newPrinter("ZZZ", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        // unlike ZZ, ZZZ never uses the "Z" shortcut for zero offset
        assertEquals("+00:00", printer.format(cal));
    }

    @Test
    void testIso8601SingleXHoursOnlyAtOffset() {
        final FastDatePrinter printer = newPrinter("X", IST, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("+05", printer.format(cal));
    }

    @Test
    void testIso8601DoubleXHoursMinutesAtOffset() {
        final FastDatePrinter printer = newPrinter("XX", IST, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("+0530", printer.format(cal));
    }

    @Test
    void testIso8601TripleXHoursColonMinutesAtOffset() {
        final FastDatePrinter printer = newPrinter("XXX", IST, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("+05:30", printer.format(cal));
    }

    @Test
    void testIso8601UsesZShortcutAtUtcForAllLengths() {
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("Z", newPrinter("X", UTC, Locale.US).format(cal));
        assertEquals("Z", newPrinter("XX", UTC, Locale.US).format(cal));
        assertEquals("Z", newPrinter("XXX", UTC, Locale.US).format(cal));
    }

    @Test
    void testIso8601FourXTokensIsInvalid() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> newPrinter("XXXX", UTC, Locale.US));
        assertTrue(ex.getMessage().contains("X"));
    }

    // ---- Invalid pattern characters -----------------------------------------

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> newPrinter("q", UTC, Locale.US));
        assertTrue(ex.getMessage().contains("q"));
    }

    // ---- Literal / quoting handling -----------------------------------------

    @Test
    void testSingleCharacterLiteralOverridesPatternLetter() {
        // quoting 'Z' makes it a literal character, not the time-zone rule
        final FastDatePrinter printer = newPrinter("'Z'", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("Z", printer.format(cal));
    }

    @Test
    void testEscapedQuoteProducesLiteralApostrophe() {
        final FastDatePrinter printer = newPrinter("''", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("'", printer.format(cal));
    }

    @Test
    void testQuotedLiteralWithEmbeddedEscapedQuote() {
        final FastDatePrinter printer = newPrinter("'don''t'", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("don't", printer.format(cal));
    }

    @Test
    void testCombinedYearLiteralQuotePattern() {
        final FastDatePrinter printer = newPrinter("yyyy''yy", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 2005);
        assertEquals("2005'05", printer.format(cal));
    }

    @Test
    void testUnterminatedQuoteIsTreatedAsLiteralText() {
        final FastDatePrinter printer = newPrinter("'abc", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("abc", printer.format(cal));
    }

    @Test
    void testEmptyPatternProducesEmptyOutput() {
        final FastDatePrinter printer = newPrinter("", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("", printer.format(cal));
        assertEquals(0, printer.getMaxLengthEstimate());
    }

    // ---- parseToken() ---------------------------------------------------------

    @Test
    void testParseTokenScansRunOfSameAlphaCharacter() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final int[] indexRef = {0};
        final String token = printer.parseToken("yyyyMM", indexRef);
        assertEquals("yyyy", token);
        assertEquals(3, indexRef[0]);
    }

    @Test
    void testParseTokenStopsAtDifferentAlphaCharacter() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final int[] indexRef = {0};
        final String token = printer.parseToken("yyMM", indexRef);
        assertEquals("yy", token);
        assertEquals(1, indexRef[0]);
    }

    // ---- Error cases: null / invalid input ------------------------------------

    @Test
    void testFormatNullDateThrowsNullPointerException() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        assertThrows(NullPointerException.class, () -> printer.format((Date) null));
    }

    @Test
    void testFormatObjectWithUnsupportedTypeThrowsIllegalArgumentException() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> printer.format("not a date"));
        assertTrue(ex.getMessage().contains("Unknown class"));
    }

    @Test
    void testDeprecatedFormatObjectDelegatesByRuntimeType() {
        final FastDatePrinter printer = newPrinter("yyyy", UTC, Locale.US);
        final FieldPosition pos = new FieldPosition(0);

        final StringBuffer dateBuf = printer.format((Object) new Date(0L), new StringBuffer(), pos);
        assertEquals("1970", dateBuf.toString());

        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(Calendar.YEAR, 1999);
        final StringBuffer calBuf = printer.format((Object) cal, new StringBuffer(), pos);
        assertEquals("1999", calBuf.toString());

        final StringBuffer longBuf = printer.format((Object) Long.valueOf(0L), new StringBuffer(), pos);
        assertEquals("1970", longBuf.toString());

        // position argument is documented as ignored
        assertEquals(0, pos.getBeginIndex());
        assertEquals(0, pos.getEndIndex());

        assertThrows(IllegalArgumentException.class,
                () -> printer.format((Object) "oops", new StringBuffer(), pos));
    }

    @Test
    void testConstructorNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> newPrinter(null, UTC, Locale.US));
    }

    @Test
    void testConstructorNullTimeZoneThrowsNullPointerExceptionPerJavadoc() {
        // Javadoc: "@throws NullPointerException if pattern, timeZone, or locale is null."
        assertThrows(NullPointerException.class, () -> newPrinter("yyyy-MM-dd", null, Locale.US));
    }

    @Test
    void testConstructorNullLocaleThrowsNullPointerExceptionPerJavadoc() {
        // Javadoc: "@throws NullPointerException if pattern, timeZone, or locale is null."
        assertThrows(NullPointerException.class, () -> newPrinter("yyyy-MM-dd", UTC, null));
    }

    // ---- Getters / equals / hashCode / toString -------------------------------

    @Test
    void testGettersReflectConstructorArguments() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertSame(UTC, printer.getTimeZone());
        assertEquals(Locale.US, printer.getLocale());
    }

    @Test
    void testGetMaxLengthEstimateExactValue() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(10, printer.getMaxLengthEstimate());
    }

    @Test
    void testFormattedLengthNeverExceedsMaxLengthEstimate() {
        final String[] patterns = {
            "yyyy-MM-dd", "EEEE, MMMM d, yyyy", "HH:mm:ss.SSS", "G yyyy a", "'literal' yyyy"
        };
        final Calendar[] cals = {
            utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 6),
            utcCalendar(2023, Calendar.DECEMBER, 31, 23, 59, 59, 999),
            utcCalendar(1, Calendar.MAY, 20, 0, 0, 0, 0),
        };
        for (final String pattern : patterns) {
            final FastDatePrinter printer = newPrinter(pattern, UTC, Locale.US);
            for (final Calendar cal : cals) {
                final String formatted = printer.format(cal);
                assertTrue(formatted.length() <= printer.getMaxLengthEstimate(),
                        "pattern=" + pattern + " formatted=" + formatted
                                + " exceeds estimate=" + printer.getMaxLengthEstimate());
            }
        }
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDatePrinter a = newPrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter b = newPrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter differentPattern = newPrinter("yyyy", UTC, Locale.US);
        final FastDatePrinter differentZone = newPrinter("yyyy-MM-dd", IST, Locale.US);
        final FastDatePrinter differentLocale = newPrinter("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());

        assertNotEquals(a, differentPattern);
        assertNotEquals(a, differentZone);
        assertNotEquals(a, differentLocale);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a FastDatePrinter");
        assertFalse(a.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZoneId() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("FastDatePrinter[yyyy-MM-dd," + Locale.US + "," + UTC.getID() + "]", printer.toString());
    }

    // ---- Serialization ----------------------------------------------------

    @Test
    void testSerializationRoundTripReinitializesRulesAndStillFormats() throws Exception {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss.SSS", UTC, Locale.US);
        final Calendar cal = utcCalendar(2023, Calendar.JANUARY, 2, 3, 4, 5, 6);
        final String expected = printer.format(cal);

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(printer);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        assertNotSame(printer, deserialized);
        assertEquals(printer, deserialized);
        assertEquals(expected, deserialized.format(cal));
        assertEquals(printer.getMaxLengthEstimate(), deserialized.getMaxLengthEstimate());
    }
}
