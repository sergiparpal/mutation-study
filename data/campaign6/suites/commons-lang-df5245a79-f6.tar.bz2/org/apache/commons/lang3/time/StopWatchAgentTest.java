/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.StopWatch.Split;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link StopWatch}.
 */
public class StopWatchAgentTest {

    private static void sleep(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Test
    public void testCreateUnstarted() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
    }

    @Test
    public void testCreateStarted() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    public void testMessageConstructor() {
        final StopWatch watch = new StopWatch("my message");
        assertEquals("my message", watch.getMessage());
        assertTrue(watch.toString().startsWith("my message "));
    }

    @Test
    public void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNotNull(watch.getMessage() == null ? "null" : watch.getMessage());
        assertEquals(null, watch.getMessage());
    }

    @Test
    public void testStartStopGetTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleep(20);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getTime() >= 0);
        assertTrue(watch.getNanoTime() >= 0);
    }

    @Test
    public void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    public void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    public void testRestartWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    public void testResetAllowsRestart() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        watch.start();
        assertTrue(watch.isStarted());
        watch.stop();
    }

    @Test
    public void testResumeBeforeSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::resume);
    }

    @Test
    public void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    public void testSuspendResumeDoesNotCountSuspendedTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleep(20);
        watch.suspend();
        final long timeAtSuspend = watch.getTime();
        sleep(50);
        assertEquals(timeAtSuspend, watch.getTime());
        watch.resume();
        sleep(20);
        watch.stop();
        assertTrue(watch.getTime() >= timeAtSuspend);
    }

    @Test
    public void testSplitBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    public void testSplitTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    public void testUnsplitBeforeSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::unsplit);
    }

    @Test
    public void testSplitAndUnsplitAllowsContinuedTiming() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleep(20);
        watch.split();
        final long splitTime = watch.getSplitTime();
        assertTrue(splitTime >= 0);
        watch.unsplit();
        assertThrows(IllegalStateException.class, watch::getSplitTime);
        sleep(20);
        watch.stop();
        assertTrue(watch.getTime() >= splitTime);
    }

    @Test
    public void testGetSplitTimeBeforeSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    public void testGetSplitDurationBeforeSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::getSplitDuration);
    }

    @Test
    public void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStartInstant);
    }

    @Test
    public void testGetStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStopInstant);
    }

    @Test
    public void testGetStartInstantAfterStart() {
        final Instant before = Instant.now();
        final StopWatch watch = new StopWatch();
        watch.start();
        final Instant after = Instant.now();
        final Instant started = watch.getStartInstant();
        assertNotNull(started);
        assertFalse(started.isBefore(before));
        assertFalse(started.isAfter(after));
    }

    @Test
    public void testGetStopTimeBeforeStopReturnsZero() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertEquals(0, watch.getStopTime());
    }

    @Test
    public void testGetTimeUnstartedIsZero() {
        final StopWatch watch = new StopWatch();
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
        assertEquals(Duration.ZERO, watch.getDuration());
    }

    @Test
    public void testGetTimeTimeUnit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleep(5);
        watch.stop();
        final long millis = watch.getTime();
        final long convertedSeconds = watch.getTime(TimeUnit.SECONDS);
        assertEquals(millis / 1000, convertedSeconds);
    }

    @Test
    public void testGetDurationMatchesGetTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleep(10);
        watch.stop();
        assertEquals(watch.getTime(), watch.getDuration().toMillis());
    }

    @Test
    public void testFormatTimeAndSplitTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String splitStr = watch.formatSplitTime();
        assertNotNull(splitStr);
        assertTrue(splitStr.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
        watch.stop();
        final String timeStr = watch.formatTime();
        assertTrue(timeStr.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    public void testToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String str = watch.toString();
        assertTrue(str.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    public void testToSplitStringWithMessage() {
        final StopWatch watch = new StopWatch("prefix");
        watch.start();
        watch.split();
        final String str = watch.toSplitString();
        assertTrue(str.startsWith("prefix "));
    }

    @Test
    public void testRunDelegatesAndSuspendsAfter() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = {false};
        watch.run(() -> ran[0] = true);
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testGetDelegatesAndReturnsValue() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(() -> "value");
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testRunTPropagatesException() {
        final StopWatch watch = new StopWatch();
        assertThrows(java.io.IOException.class, () -> watch.runT(() -> {
            throw new java.io.IOException("boom");
        }));
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testGetTPropagatesExceptionAndReturnsValueOnSuccess() throws Throwable {
        final StopWatch watch = new StopWatch();
        final Integer result = watch.getT(() -> 42);
        assertEquals(Integer.valueOf(42), result);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testSplitLabelDefaultsToIndex() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("0", splits.get(0).getLabel());
    }

    @Test
    public void testSplitWithCustomLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        final List<Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
    }

    @Test
    public void testSplitsListIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        final List<Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, () -> splits.add(new Split("b", Duration.ZERO)));
    }

    @Test
    public void testUnsplitRemovesLastSplit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
    }

    @Test
    public void testStartAfterResetClearsPreviousSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        watch.unsplit();
        watch.stop();
        watch.reset();
        watch.start();
        assertEquals(0, watch.getSplits().size());
    }

    @Test
    public void testSplitObjectToString() {
        final Split split = new Split("label", Duration.ofMillis(5));
        assertEquals("label", split.getLabel());
        assertEquals(Duration.ofMillis(5), split.getDuration());
        assertEquals("Split [label, PT0.005S])", split.toString());
    }
}
