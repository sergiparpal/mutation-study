/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Self-contained tests for {@link CSVParser}.
 */
class CSVParserAgentTest {

    @TempDir
    File tempDir;

    @Test
    void parseStringProducesRecordsWithValues() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(0).get(2));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void parseStringNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void parseFileNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void parseFileReadsRecordsFromDisk() throws IOException {
        final File file = new File(tempDir, "data.csv");
        Files.write(file.toPath(), "x,y\n10,20\n".getBytes(StandardCharsets.UTF_8));
        final CSVParser parser = CSVParser.parse(file, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("10", records.get(1).get(0));
            assertEquals("20", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void headerFromFirstLineBuildsHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nAlice,30\nBob,40\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(2, headerNames.size());
            assertEquals("name", headerNames.get(0));
            assertEquals("age", headerNames.get(1));
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("Alice", records.get(0).get("name"));
            assertEquals("40", records.get(1).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void getHeaderMapReturnsIndependentCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            final Map<String, Integer> map = parser.getHeaderMap();
            map.remove("a");
            assertTrue(parser.getHeaderMap().containsKey("a"));
        } finally {
            parser.close();
        }
    }

    @Test
    void getHeaderMapNullWhenNoHeaderDefined() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void blankHeaderNameWithoutAllowMissingThrowsIllegalArgumentException() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true)
                .setAllowMissingColumnNames(false).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,,c\n1,2,3\n", format);
            }
        });
    }

    @Test
    void blankHeaderNameWithAllowMissingIsAccepted() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true)
                .setAllowMissingColumnNames(true).get();
        final CSVParser parser = CSVParser.parse("a,,c\n1,2,3\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(3, headerNames.size());
            assertEquals("a", headerNames.get(0));
            assertEquals("", headerNames.get(1));
            assertEquals("c", headerNames.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void duplicateHeaderNameThrowsIllegalArgumentExceptionWhenDisallowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,a\n1,2\n", format);
            }
        });
    }

    @Test
    void duplicateHeaderNameAllowedWhenModeAllowAll() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        final CSVParser parser = CSVParser.parse("a,a\n1,2\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
        } finally {
            parser.close();
        }
    }

    @Test
    void iteratorYieldsRecordsInOrderThenThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertEquals("1", it.next().get(0));
            assertTrue(it.hasNext());
            assertEquals("2", it.next().get(0));
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void iteratorNextWithoutHasNextCallWorks() throws IOException {
        final CSVParser parser = CSVParser.parse("only\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertEquals("only", record.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    void iteratorRemoveThrowsUnsupportedOperationException() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void closeMakesParserClosedAndIteratorExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    void getRecordNumberIncrementsPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord first = it.next();
            assertEquals(1, first.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord second = it.next();
            assertEquals(2, second.getRecordNumber());
            assertEquals(2, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void customRecordNumberOffsetIsHonored() throws IOException {
        final CSVParser.Builder builder = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(5);
        final CSVParser parser = builder.get();
        try {
            final CSVRecord first = parser.iterator().next();
            assertEquals(5, first.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void emptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getRecords().isEmpty());
            assertFalse(parser.iterator().hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    void streamCollectsAllRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final long count = parser.stream().count();
            assertEquals(2, count);
        } finally {
            parser.close();
        }
    }

    @Test
    void getCurrentLineNumberTracksLinesConsumed() throws IOException {
        final CSVParser parser = CSVParser.parse("line1\nline2\nline3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.iterator().next();
            assertEquals(1, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void headerAndTrailerCommentsAreCaptured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();
        final String csv = "# header comment\na,b\n1,2\n# trailer comment\n";
        final CSVParser parser = CSVParser.parse(csv, format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
            parser.getRecords();
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer comment", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void noCommentsMeansHasCommentMethodsReturnFalse() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
            parser.getRecords();
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void maxRowsLimitsNumberOfRecordsReturned() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get(0));
            assertEquals("2", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void trailingDelimiterDropsFinalEmptyField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void nullStringIsMappedToNullValue() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void deprecatedConstructorWithOffsetsSetsInitialState() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("x\ny\n"), CSVFormat.DEFAULT, 100, 3);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(3, record.getRecordNumber());
            assertEquals(100, record.getCharacterPosition());
        } finally {
            parser.close();
        }
    }

    @Test
    void deprecatedSimpleConstructorStartsAtRecordOne() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("x\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(1, record.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void getRecordsOnlyReturnsRemainingRecordsAfterPartialConsumption() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            final List<CSVRecord> remaining = parser.getRecords();
            assertEquals(2, remaining.size());
            assertEquals("2", remaining.get(0).get(0));
            assertEquals("3", remaining.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void builderGetProducesWorkingParser() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a,b\n"))
                .setFormat(CSVFormat.DEFAULT)
                .get();
        try {
            assertNotNull(parser);
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void parseEmptyStringViaStringReaderYieldsNoRecordsViaStream() throws IOException {
        final CSVParser parser = CSVParser.parse(new StringReader(""), CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.stream().count());
        } finally {
            parser.close();
        }
    }
}
