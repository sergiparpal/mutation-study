/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // compare
    // ---------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("   ");
            }
        });
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
    }

    @Test
    public void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("1A", 16), NumberUtils.createBigInteger("0x1A"));
        assertEquals(new BigInteger("1A", 16), NumberUtils.createBigInteger("0X1A"));
        assertEquals(new BigInteger("1A", 16), NumberUtils.createBigInteger("#1A"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(9), NumberUtils.createBigInteger("011"));
    }

    @Test
    public void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ---------------------------------------------------------------
    // createDouble / createFloat
    // ---------------------------------------------------------------

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createInteger / createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(-123), NumberUtils.createInteger("-123"));
    }

    @Test
    public void testCreateIntegerHexAndOctal() {
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(9), NumberUtils.createInteger("011"));
    }

    @Test
    public void testCreateIntegerInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
    }

    @Test
    public void testCreateLongInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createNumber("");
            }
        });
    }

    @Test
    public void testCreateNumberLeadingSpaceThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createNumber(" 123");
            }
        });
    }

    @Test
    public void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer, "expected Integer but was " + n.getClass());
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongOverflowsInt() {
        final Number n = NumberUtils.createNumber(String.valueOf(Long.MAX_VALUE));
        assertTrue(n instanceof Long, "expected Long but was " + n.getClass());
        assertEquals(Long.MAX_VALUE, n.longValue());
    }

    @Test
    public void testCreateNumberBigIntegerOverflowsLong() {
        final String huge = "123456789012345678901234567890";
        final Number n = NumberUtils.createNumber(huge);
        assertTrue(n instanceof BigInteger, "expected BigInteger but was " + n.getClass());
        assertEquals(new BigInteger(huge), n);
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float, "expected Float but was " + n.getClass());
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double, "expected Double but was " + n.getClass());
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long, "expected Long but was " + n.getClass());
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberHexInt() {
        final Number n = NumberUtils.createNumber("0x1A");
        assertTrue(n instanceof Integer, "expected Integer but was " + n.getClass());
        assertEquals(26, n.intValue());
    }

    @Test
    public void testCreateNumberNegativeHex() {
        final Number n = NumberUtils.createNumber("-0x1A");
        assertTrue(n instanceof Integer, "expected Integer but was " + n.getClass());
        assertEquals(-26, n.intValue());
    }

    @Test
    public void testCreateNumberHexPromotesToLongWhenTooBigForInt() {
        // 8 hex digits with the first significant digit > 7 overflows a signed int.
        final Number n = NumberUtils.createNumber("0x80000000");
        assertTrue(n instanceof Long, "expected Long but was " + n.getClass());
        assertEquals(0x80000000L, n.longValue());
    }

    @Test
    public void testCreateNumberHexPromotesToBigIntegerWhenTooBigForLong() {
        // 16 hex digits with the first significant digit > 7 overflows a signed long.
        final Number n = NumberUtils.createNumber("0x8000000000000000");
        assertTrue(n instanceof BigInteger, "expected BigInteger but was " + n.getClass());
        assertEquals(new BigInteger("8000000000000000", 16), n);
    }

    @Test
    public void testCreateNumberPlainDecimal() {
        final Number n = NumberUtils.createNumber("1.23");
        assertTrue(n instanceof Float || n instanceof Double, "expected Float/Double but was " + n.getClass());
        assertEquals(1.23d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberBadTypeQualifierThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createNumber("123x");
            }
        });
    }

    @Test
    public void testCreateNumberDoubleExponentThrows() {
        // two exponent markers must not be accepted
        assertThrows(NumberFormatException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.createNumber("1e2e3");
            }
        });
    }

    // ---------------------------------------------------------------
    // isCreatable / isNumber / isDigits / isParsable
    // ---------------------------------------------------------------

    @Test
    public void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    public void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
    }

    @Test
    public void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09")); // invalid octal per javadoc
    }

    @Test
    public void testIsNumberDelegatesToIsCreatable() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber(null));
    }

    @Test
    public void testIsDigitsNullAndEmpty() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
    }

    @Test
    public void testIsDigitsValidAndInvalid() {
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12a3"));
    }

    @Test
    public void testIsParsableNullAndEmpty() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    public void testIsParsableValid() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
    }

    @Test
    public void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("1.2.3"));
    }

    // ---------------------------------------------------------------
    // max / min arrays
    // ---------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(3, 9, -2));
    }

    @Test
    public void testMaxIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(3L, 9L, -2L));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max((short) 3, (short) 9, (short) -2));
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(9.5d, NumberUtils.max(3.1d, 9.5d, -2.2d), 0.0d);
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(9.5f, NumberUtils.max(3.1f, 9.5f, -2.2f), 0.0f);
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) -2, NumberUtils.min((byte) 1, (byte) 5, (byte) -2));
    }

    @Test
    public void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    public void testMinIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(-2L, NumberUtils.min(3L, 9L, -2L));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) -2, NumberUtils.min((short) 3, (short) 9, (short) -2));
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(-2.2d, NumberUtils.min(3.1d, 9.5d, -2.2d), 0.0d);
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(-2.2f, NumberUtils.min(3.1f, 9.5f, -2.2f), 0.0f);
    }

    // ---------------------------------------------------------------
    // max / min three-arg overloads
    // ---------------------------------------------------------------

    @Test
    public void testMaxThreeByte() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max((byte) 5, (byte) 1, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 3, (byte) 5));
    }

    @Test
    public void testMaxThreeInt() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(5, NumberUtils.max(5, 1, 3));
        assertEquals(5, NumberUtils.max(1, 3, 5));
    }

    @Test
    public void testMaxThreeLong() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxThreeShort() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMaxThreeDoubleNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMaxThreeFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    public void testMinThreeByte() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 5, (byte) 1, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 5, (byte) 3, (byte) 1));
    }

    @Test
    public void testMinThreeInt() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(1, NumberUtils.min(5, 1, 3));
        assertEquals(1, NumberUtils.min(5, 3, 1));
    }

    @Test
    public void testMinThreeLong() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    public void testMinThreeShort() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMinThreeDoubleNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMinThreeFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    // ---------------------------------------------------------------
    // toByte / toShort / toInt / toLong / toFloat / toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("abc", (byte) 2));
    }

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("abc", (short) 2));
    }

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("abc", 2));
    }

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("abc", 2L));
    }

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(2.2f, NumberUtils.toFloat("abc", 2.2f), 0.0f);
    }

    @Test
    public void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(2.2d, NumberUtils.toDouble("abc", 2.2d), 0.0d);
    }

    @Test
    public void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"));
        assertEquals(new BigDecimal("1.24"), result);
        assertEquals(2, result.scale());
    }

    @Test
    public void testToScaledBigDecimalBigDecimalCustomScale() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("1.235"), result);
    }

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
    }

    @Test
    public void testToScaledBigDecimalDoubleValue() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d));
        assertEquals(new BigDecimal("1.24"), result);
    }

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
    }

    @Test
    public void testToScaledBigDecimalFloatValue() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.25f));
        assertEquals(new BigDecimal("1.25"), result);
    }

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    public void testToScaledBigDecimalStringValue() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal("1.235");
        assertEquals(new BigDecimal("1.24"), result);
    }

    @Test
    public void testToScaledBigDecimalNullRoundingModeDefaultsToHalfEven() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.005"), 2, null);
        assertEquals(new BigDecimal("1.00"), result);
    }

    // ---------------------------------------------------------------
    // constants
    // ---------------------------------------------------------------

    @Test
    public void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }
}
