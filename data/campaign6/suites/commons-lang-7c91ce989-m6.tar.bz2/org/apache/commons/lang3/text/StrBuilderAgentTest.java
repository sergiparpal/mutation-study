/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
@Deprecated
class StrBuilderAgentTest {

    @Test
    void testConstructorDefault() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    void testConstructorInitialCapacity() {
        final StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
        assertEquals(0, sb.length());

        final StrBuilder zero = new StrBuilder(0);
        assertEquals(32, zero.capacity());

        final StrBuilder negative = new StrBuilder(-5);
        assertEquals(32, negative.capacity());
    }

    @Test
    void testConstructorString() {
        final StrBuilder sb = new StrBuilder("foo");
        assertEquals("foo", sb.toString());
        assertEquals(3, sb.length());

        final StrBuilder nullStr = new StrBuilder((String) null);
        assertEquals(0, nullStr.length());
        assertEquals("", nullStr.toString());
    }

    @Test
    void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append(true);
        assertSame(sb, result);
        assertEquals("true", sb.toString());
        sb.append(false);
        assertEquals("truefalse", sb.toString());
    }

    @Test
    void testAppendCharArrayNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());

        sb.setNullText("NULL");
        sb.append((char[]) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
        sb.append(new char[0]);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a'}, -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a'}, 0, 2);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a'}, 2, 1);
            }
        });
    }

    @Test
    void testAppendCharSequenceVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abc");
        assertEquals("abc", sb.toString());

        sb.append((CharSequence) null);
        assertEquals("abc", sb.toString());

        final StringBuilder jdkSb = new StringBuilder("xyz");
        sb.append((CharSequence) jdkSb);
        assertEquals("abcxyz", sb.toString());

        final StrBuilder other = new StrBuilder("qq");
        sb.append((CharSequence) other);
        assertEquals("abcxyzqq", sb.toString());
    }

    @Test
    void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abcdef", 1, 3);
        assertEquals("bcd", sb.toString());

        sb.append((CharSequence) null, 0, 1);
        assertEquals("bcd", sb.toString());
    }

    @Test
    void testAppendPrimitives() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1).append('-').append(2L).append('-').append(3.5f).append('-').append(4.5d);
        assertEquals("1-2-3.5-4.5", sb.toString());
    }

    @Test
    void testAppendObject() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());

        sb.append((Object) Integer.valueOf(42));
        assertEquals("42", sb.toString());

        sb.append((Object) "plain");
        assertEquals("42plain", sb.toString());
    }

    @Test
    void testAppendStrBuilder() {
        final StrBuilder sb = new StrBuilder("a");
        final StrBuilder other = new StrBuilder("bc");
        sb.append(other);
        assertEquals("abc", sb.toString());

        sb.append((StrBuilder) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testAppendStrBuilderRange() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("abcdef");
        sb.append(other, 1, 3);
        assertEquals("bcd", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(other, -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(other, 0, 100);
            }
        });
    }

    @Test
    void testAppendStringRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append("abcdef", 2, 3);
        assertEquals("cde", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append("abc", -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append("abc", 1, 10);
            }
        });
    }

    @Test
    void testAppendFormatString() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "val", 7);
        assertEquals("val-7", sb.toString());
    }

    @Test
    void testAppendStringBufferAndBuilder() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("buf"));
        assertEquals("buf", sb.toString());
        sb.append(new StringBuilder("sb"));
        assertEquals("bufsb", sb.toString());

        sb.append((StringBuffer) null);
        sb.append((StringBuilder) null);
        assertEquals("bufsb", sb.toString());
    }

    @Test
    void testAppendStringBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abcdef"), 1, 2);
        assertEquals("bc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new StringBuffer("a"), 0, 5);
            }
        });
    }

    @Test
    void testAppendStringBuilderRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abcdef"), 1, 2);
        assertEquals("bc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new StringBuilder("a"), 0, 5);
            }
        });
    }

    @Test
    void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll((Iterable<?>) list);
        assertEquals("abc", sb.toString());

        sb.appendAll((Iterable<?>) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("x", "y");
        sb.appendAll(list.iterator());
        assertEquals("xy", sb.toString());

        sb.appendAll((java.util.Iterator<?>) null);
        assertEquals("xy", sb.toString());
    }

    @Test
    void testAppendAllArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());

        sb.appendAll((Object[]) null);
        assertEquals("abc", sb.toString());

        sb.appendAll();
        assertEquals("abc", sb.toString());
    }

    @Test
    void testAppendFixedWidthPadLeftInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 5, '0');
        assertEquals("00001", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadLeft(123456, 3, '0');
        assertEquals("456", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendFixedWidthPadLeft(1, 0, '0');
        assertEquals("", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendFixedWidthPadLeft(1, -5, '0');
        assertEquals("", sb4.toString());
    }

    @Test
    void testAppendFixedWidthPadLeftObject() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft((Object) null, 4, '*');
        assertEquals("****", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.setNullText("NULL");
        sb2.appendFixedWidthPadLeft((Object) null, 6, '*');
        assertEquals("**NULL", sb2.toString());
    }

    @Test
    void testAppendFixedWidthPadRightInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(1, 5, '0');
        assertEquals("10000", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadRight(123456, 3, '0');
        assertEquals("123", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendFixedWidthPadRight(1, 0, '0');
        assertEquals("", sb3.toString());
    }

    @Test
    void testAppendFixedWidthPadRightObject() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight((Object) null, 4, '*');
        assertEquals("****", sb.toString());
    }

    @Test
    void testAppendlnVariants() {
        final String sep = System.lineSeparator();
        final StrBuilder sb = new StrBuilder();
        sb.appendln(true);
        assertEquals("true" + sep, sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendln('x');
        assertEquals("x" + sep, sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendln(new char[] {'a', 'b'});
        assertEquals("ab" + sep, sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendln(new char[] {'a', 'b', 'c'}, 1, 2);
        assertEquals("bc" + sep, sb4.toString());

        final StrBuilder sb5 = new StrBuilder();
        sb5.appendln(1.5d);
        assertEquals("1.5" + sep, sb5.toString());

        final StrBuilder sb6 = new StrBuilder();
        sb6.appendln(1.5f);
        assertEquals("1.5" + sep, sb6.toString());

        final StrBuilder sb7 = new StrBuilder();
        sb7.appendln(7);
        assertEquals("7" + sep, sb7.toString());

        final StrBuilder sb8 = new StrBuilder();
        sb8.appendln(7L);
        assertEquals("7" + sep, sb8.toString());

        final StrBuilder sb9 = new StrBuilder();
        sb9.appendln((Object) "obj");
        assertEquals("obj" + sep, sb9.toString());

        final StrBuilder sb10 = new StrBuilder();
        sb10.appendln(new StrBuilder("inner"));
        assertEquals("inner" + sep, sb10.toString());

        final StrBuilder sb11 = new StrBuilder();
        sb11.appendln(new StrBuilder("innerxyz"), 1, 3);
        assertEquals("nne" + sep, sb11.toString());

        final StrBuilder sb12 = new StrBuilder();
        sb12.appendln("plain");
        assertEquals("plain" + sep, sb12.toString());

        final StrBuilder sb13 = new StrBuilder();
        sb13.appendln("plainXYZ", 1, 3);
        assertEquals("lai" + sep, sb13.toString());

        final StrBuilder sb14 = new StrBuilder();
        sb14.appendln("%s-%d", "a", 1);
        assertEquals("a-1" + sep, sb14.toString());

        final StrBuilder sb15 = new StrBuilder();
        sb15.appendln(new StringBuffer("buf"));
        assertEquals("buf" + sep, sb15.toString());

        final StrBuilder sb16 = new StrBuilder();
        sb16.appendln(new StringBuffer("bufXYZ"), 1, 3);
        assertEquals("ufX" + sep, sb16.toString());

        final StrBuilder sb17 = new StrBuilder();
        sb17.appendln(new StringBuilder("sb"));
        assertEquals("sb" + sep, sb17.toString());

        final StrBuilder sb18 = new StrBuilder();
        sb18.appendln(new StringBuilder("sbXYZ"), 1, 3);
        assertEquals("bXY" + sep, sb18.toString());
    }

    @Test
    void testAppendNewLineDefaultAndCustom() {
        final StrBuilder sb = new StrBuilder("start-");
        sb.appendNewLine();
        assertEquals("start-" + System.lineSeparator(), sb.toString());

        final StrBuilder custom = new StrBuilder("start-");
        custom.setNewLineText("\n");
        assertEquals("\n", custom.getNewLineText());
        custom.appendNewLine();
        assertEquals("start-\n", custom.toString());

        custom.setNewLineText(null);
        assertNull(custom.getNewLineText());
    }

    @Test
    void testAppendNull() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());

        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.appendNull();
        assertEquals("NULL", sb.toString());

        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    @Test
    void testAppendPadding() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());

        sb.appendPadding(-1, '*');
        assertEquals("***", sb.toString());

        sb.appendPadding(0, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(',');
        sb.append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    void testAppendSeparatorCharDefaultIfEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());

        sb.append("a");
        sb.appendSeparator(',', ';');
        assertEquals(";a,", sb.toString());
    }

    @Test
    void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    void testAppendSeparatorString() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator((String) null);
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(",");
        sb.append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(",", -1);
        sb.append("a");
        sb.appendSeparator(null, 1);
        sb.append("b");
        assertEquals("ab", sb.toString());

        sb.appendSeparator(",", 1);
        assertEquals("ab,", sb.toString());
    }

    @Test
    void testAppendSeparatorStringDefaultIfEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        assertEquals(" where", sb.toString());
        sb.append("x=1");
        sb.appendSeparator(" and", " where");
        assertEquals(" wherex=1 and", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendSeparator(null, null);
        assertEquals("", sb2.toString());
    }

    @Test
    void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb3.toString());
    }

    @Test
    void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c").iterator(), ",");
        assertEquals("a,b,c", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendWithSeparators((java.util.Iterator<?>) null, ",");
        assertEquals("", sb2.toString());
    }

    @Test
    void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendWithSeparators((Object[]) null, ",");
        assertEquals("", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendWithSeparators(new Object[0], ",");
        assertEquals("", sb3.toString());
    }

    @Test
    void testAsReader() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        reader.mark(0);
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
        reader.reset();
        assertEquals('c', reader.read());
        assertTrue(reader.markSupported());

        final char[] buf = new char[2];
        final StrBuilder sb2 = new StrBuilder("xy");
        final Reader reader2 = sb2.asReader();
        final int read = reader2.read(buf, 0, 2);
        assertEquals(2, read);
        assertArrayEquals(new char[] {'x', 'y'}, buf);
        assertEquals(-1, reader2.read(buf, 0, 2));
        assertEquals(0, reader2.read(buf, 0, 0));
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader2.read(buf, -1, 1);
            }
        });

        reader.close();
    }

    @Test
    void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        final String[] tokens = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokens);
        assertEquals("a b c", tokenizer.getContent());
    }

    @Test
    void testAsWriter() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("abc");
        writer.write('d');
        writer.write(new char[] {'e', 'f'});
        writer.write(new char[] {'g', 'h', 'i'}, 1, 2);
        writer.write("jklmn", 1, 2);
        assertEquals("abcdefhikl", sb.toString());
        writer.flush();
        writer.close();
        assertEquals("abcdefhikl", sb.toString());
    }

    @Test
    void testBuild() {
        final StrBuilder sb = new StrBuilder("hi");
        assertEquals("hi", sb.build());
        assertEquals(sb.toString(), sb.build());
    }

    @Test
    void testCapacityAndEnsureCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(2);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    void testCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.charAt(-1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.charAt(3);
            }
        });
    }

    @Test
    void testClear() {
        final StrBuilder sb = new StrBuilder("abc");
        final int capacityBefore = sb.capacity();
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
        assertEquals(capacityBefore, sb.capacity());
    }

    @Test
    void testContainsChar() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    void testContainsString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cd"));
        assertFalse(sb.contains("zz"));
    }

    @Test
    void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains(StrMatcher.charMatcher('b')));
        assertFalse(sb.contains(StrMatcher.charMatcher('z')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    void testDelete() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());

        sb.delete(2, 2);
        assertEquals("adef", sb.toString());

        sb.delete(1, 100);
        assertEquals("a", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.delete(-1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.delete(2, 1);
            }
        });
    }

    @Test
    void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("abcabcaa");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());

        final StrBuilder none = new StrBuilder("xyz");
        none.deleteAll('a');
        assertEquals("xyz", none.toString());
    }

    @Test
    void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("abXYabXYab");
        sb.deleteAll("XY");
        assertEquals("ababab", sb.toString());

        sb.deleteAll((String) null);
        assertEquals("ababab", sb.toString());

        sb.deleteAll("");
        assertEquals("ababab", sb.toString());
    }

    @Test
    void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.deleteCharAt(-1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.deleteCharAt(10);
            }
        });
    }

    @Test
    void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('b');
        assertEquals("acabc", sb.toString());
    }

    @Test
    void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("abXYabXY");
        sb.deleteFirst("XY");
        assertEquals("ababXY", sb.toString());

        sb.deleteFirst((String) null);
        assertEquals("ababXY", sb.toString());
    }

    @Test
    void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    @Test
    void testEndsWith() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("abc"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith("abcdefghij"));
    }

    @Test
    void testEqualsAndEqualsIgnoreCase() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("ABC");
        final StrBuilder sb4 = new StrBuilder("abcd");

        assertTrue(sb1.equals(sb2));
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals(sb4));
        assertFalse(sb1.equals((StrBuilder) null));
        assertFalse(sb1.equals("abc"));
        assertTrue(sb1.equals(sb1));

        assertTrue(sb1.equalsIgnoreCase(sb3));
        assertFalse(sb1.equalsIgnoreCase(sb4));
        assertTrue(sb1.equalsIgnoreCase(sb1));
    }

    @Test
    void testGetCharsNoDestination() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);

        final char[] big = new char[5];
        final char[] result2 = sb.getChars(big);
        assertSame(big, result2);
        assertEquals('a', result2[0]);
    }

    @Test
    void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[6];
        sb.getChars(1, 4, dest, 0);
        assertArrayEquals(new char[] {'b', 'c', 'd', 0, 0, 0}, dest);

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.getChars(-1, 3, dest, 0);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.getChars(0, 100, dest, 0);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.getChars(3, 1, dest, 0);
            }
        });
    }

    @Test
    void testHashCodeConsistentWithEquals() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
        assertTrue(sb1.equals(sb2));
    }

    @Test
    void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(1, sb.indexOf('b', 0));
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(-1, sb.indexOf('z'));
        assertEquals(1, sb.indexOf('b', -5));
        assertEquals(-1, sb.indexOf('b', 100));
    }

    @Test
    void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(4, sb.indexOf("bc", 2));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("ab12cd");
        assertEquals(2, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
        assertEquals(-1, sb.indexOf(StrMatcher.charSetMatcher("z"), 100));
    }

    @Test
    void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());

        final StrBuilder sb2 = new StrBuilder("ac");
        sb2.insert(1, false);
        assertEquals("afalsec", sb2.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(-1, true);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(1000, true);
            }
        });
    }

    @Test
    void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());

        sb.insert(0, (char[]) null);
        assertEquals("abcd", sb.toString());

        sb.setNullText("N");
        sb.insert(0, (char[]) null);
        assertEquals("Nabcd", sb.toString());
    }

    @Test
    void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'x', 'b', 'c', 'y'}, 1, 2);
        assertEquals("abcd", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(1, new char[] {'a'}, -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(1, new char[] {'a'}, 0, 5);
            }
        });
    }

    @Test
    void testInsertNumbers() {
        final StrBuilder sb = new StrBuilder("[]");
        sb.insert(1, 5);
        assertEquals("[5]", sb.toString());

        final StrBuilder sb2 = new StrBuilder("[]");
        sb2.insert(1, 5L);
        assertEquals("[5]", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("[]");
        sb3.insert(1, 1.5f);
        assertEquals("[1.5]", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("[]");
        sb4.insert(1, 1.5d);
        assertEquals("[1.5]", sb4.toString());
    }

    @Test
    void testInsertObject() {
        final StrBuilder sb = new StrBuilder("[]");
        sb.insert(1, (Object) null);
        assertEquals("[]", sb.toString());

        sb.insert(1, (Object) "mid");
        assertEquals("[mid]", sb.toString());
    }

    @Test
    void testInsertString() {
        final StrBuilder sb = new StrBuilder("[]");
        sb.insert(1, "abc");
        assertEquals("[abc]", sb.toString());

        sb.insert(0, (String) null);
        assertEquals("[abc]", sb.toString());

        sb.insert(0, "");
        assertEquals("[abc]", sb.toString());
    }

    @Test
    void testIsEmptyAndIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append("x");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(1, sb.lastIndexOf('b', 2));
        assertEquals(-1, sb.lastIndexOf('b', -1));
        assertEquals(4, sb.lastIndexOf('b', 100));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(1, sb.lastIndexOf("bc", 2));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    void testLeftString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
        assertEquals("abcdef", sb.leftString(100));
    }

    @Test
    void testLength() {
        final StrBuilder sb = new StrBuilder("abcde");
        assertEquals(5, sb.length());
        assertEquals(sb.size(), sb.length());
    }

    @Test
    void testMidString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cde", sb.midString(2, 3));
        assertEquals("", sb.midString(2, 0));
        assertEquals("", sb.midString(2, -1));
        assertEquals("cdef", sb.midString(2, 100));
        assertEquals("abc", sb.midString(-5, 3));
        assertEquals("", sb.midString(100, 3));
    }

    @Test
    void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("ab");
        sb.minimizeCapacity();
        assertEquals(2, sb.capacity());
        assertEquals("ab", sb.toString());
    }

    @Test
    void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Reader reader = new StringReader("hello world");
        final int read = sb.readFrom(reader);
        assertEquals(11, read);
        assertEquals("hello world", sb.toString());
    }

    @Test
    void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final java.nio.CharBuffer cb = java.nio.CharBuffer.wrap("abcdef".toCharArray());
        final int read = sb.readFrom(cb);
        assertEquals(6, read);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());

        sb.replace(0, 1, null);
        assertEquals("XYZdef", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.replace(-1, 1, "x");
            }
        });
    }

    @Test
    void testReplaceMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, sb.length(), -1);
        assertEquals("a#b#c#", sb.toString());

        final StrBuilder sb2 = new StrBuilder("a1b2c3");
        sb2.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, sb2.length(), 1);
        assertEquals("a#b2c3", sb2.toString());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.replace(StrMatcher.charMatcher('a'), "x", -1, 1, 1);
            }
        });
    }

    @Test
    void testReplaceAllCharAndString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll('a', 'z');
        assertEquals("zbczbc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("foo-bar-foo");
        sb2.replaceAll("foo", "baz");
        assertEquals("baz-bar-baz", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abc");
        sb3.replaceAll((String) null, "x");
        assertEquals("abc", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("aaa");
        sb4.replaceAll("a", null);
        assertEquals("", sb4.toString());
    }

    @Test
    void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    void testReplaceFirstCharAndString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceFirst('a', 'z');
        assertEquals("zbcabc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("foo-bar-foo");
        sb2.replaceFirst("foo", "baz");
        assertEquals("baz-bar-foo", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abc");
        sb3.replaceFirst((String) null, "x");
        assertEquals("abc", sb3.toString());
    }

    @Test
    void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    void testReverse() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.reverse();
        assertEquals("fedcba", sb.toString());

        final StrBuilder empty = new StrBuilder();
        empty.reverse();
        assertEquals("", empty.toString());

        final StrBuilder single = new StrBuilder("x");
        single.reverse();
        assertEquals("x", single.toString());

        final StrBuilder surrogate = new StrBuilder("a😀b");
        surrogate.reverse();
        assertEquals("b😀a", surrogate.toString());
    }

    @Test
    void testRightString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
        assertEquals("abcdef", sb.rightString(100));
    }

    @Test
    void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.setCharAt(-1, 'z');
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.setCharAt(10, 'z');
            }
        });
    }

    @Test
    void testSetLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
        assertEquals(3, sb.length());

        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(4));

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.setLength(-1);
            }
        });
    }

    @Test
    void testSetNullTextEmptyBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("x");
        assertEquals("x", sb.getNullText());
        sb.setNullText("");
        assertNull(sb.getNullText());
        sb.setNullText(null);
        assertNull(sb.getNullText());
    }

    @Test
    void testSizeMatchesLength() {
        final StrBuilder sb = new StrBuilder("abcd");
        assertEquals(4, sb.size());
        assertEquals(sb.length(), sb.size());
    }

    @Test
    void testStartsWith() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("bcd"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith("abcdefghij"));
    }

    @Test
    void testSubSequence() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.subSequence(1, 4));
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.subSequence(-1, 2);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.subSequence(0, 100);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.subSequence(3, 1);
            }
        });
    }

    @Test
    void testSubstring() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
        assertEquals("cd", sb.substring(2, 4));
        assertEquals("cdef", sb.substring(2, 100));
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.substring(-1, 2);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.substring(3, 1);
            }
        });
    }

    @Test
    void testToCharArray() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());

        final StrBuilder empty = new StrBuilder();
        assertArrayEquals(new char[0], empty.toCharArray());
    }

    @Test
    void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'b', 'c'}, sb.toCharArray(1, 3));
        assertArrayEquals(new char[0], sb.toCharArray(1, 1));
        assertArrayEquals(new char[] {'c', 'd', 'e', 'f'}, sb.toCharArray(2, 100));
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sb.toCharArray(-1, 2);
            }
        });
    }

    @Test
    void testToStringIndependentCopy() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
        buf.append("x");
        assertEquals("abc", sb.toString());
    }

    @Test
    void testToStringBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder jdkSb = sb.toStringBuilder();
        assertEquals("abc", jdkSb.toString());
        jdkSb.append("x");
        assertEquals("abc", sb.toString());
    }

    @Test
    void testTrim() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());

        final StrBuilder allSpaces = new StrBuilder("   ");
        allSpaces.trim();
        assertEquals("", allSpaces.toString());

        final StrBuilder empty = new StrBuilder();
        empty.trim();
        assertEquals("", empty.toString());

        final StrBuilder noTrim = new StrBuilder("abc");
        noTrim.trim();
        assertEquals("abc", noTrim.toString());
    }

    @Test
    void testAppendToAppendable() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder jdkSb = new StringBuilder();
        sb.appendTo(jdkSb);
        assertEquals("abc", jdkSb.toString());

        final StringBuffer jdkBuf = new StringBuffer();
        sb.appendTo(jdkBuf);
        assertEquals("abc", jdkBuf.toString());

        final StrBuilder target = new StrBuilder();
        sb.appendTo(target);
        assertEquals("abc", target.toString());
    }

    @Test
    void testChainedFluentApi() {
        final StrBuilder sb = new StrBuilder();
        final String result = sb.append("a").append(1).append('-').insert(0, "pre-").toString();
        assertEquals("pre-a1-", result);
    }

    @Test
    void testCharSequenceInterface() {
        final CharSequence cs = new StrBuilder("hello");
        assertEquals(5, cs.length());
        assertEquals('h', cs.charAt(0));
        assertEquals("ell", cs.subSequence(1, 4).toString());
    }

    @Test
    void testList() {
        final List<Object> list = new ArrayList<Object>();
        list.add("a");
        list.add(1);
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(list, ",");
        assertEquals("a,1", sb.toString());
    }
}
