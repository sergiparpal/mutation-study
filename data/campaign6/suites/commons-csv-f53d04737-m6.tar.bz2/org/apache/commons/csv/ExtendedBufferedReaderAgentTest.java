/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Additional tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createBufferedReader(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testGetLastCharInitiallyUndefined() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        br.close();
    }

    @Test
    void testGetLineNumberLookaheadBeforeEol() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("a\nb");
        assertEquals(0, br.getLineNumber());
        assertEquals('a', br.read());
        // Lookahead: lastChar is not an EOL char, so getLineNumber() reports lineNumber + 1.
        assertEquals(1, br.getLineNumber());
        assertEquals('\n', br.read());
        assertEquals(1, br.getLineNumber());
        br.close();
    }

    @Test
    void testGetPositionTracksCharactersRead() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abcdef");
        assertEquals(0, br.getPosition());
        br.read();
        assertEquals(1, br.getPosition());
        final char[] buf = new char[3];
        final int len = br.read(buf, 0, 3);
        assertEquals(3, len);
        assertEquals(4, br.getPosition());
        br.close();
    }

    @Test
    void testPeekDoesNotAdvancePositionOrLastChar() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("xy");
        assertEquals('x', br.peek());
        assertEquals('x', br.peek());
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('x', br.read());
        assertEquals(1, br.getPosition());
        assertEquals('x', br.getLastChar());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        br.read();
        assertEquals('a', br.getLastChar());
        br.close();
        assertEquals(EOF, br.getLastChar());
    }

    @Test
    void testReadAfterCloseThrows() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        br.close();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testReadZeroLengthReturnsZeroWithoutConsuming() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        final char[] buf = new char[10];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        // Underlying content is untouched: a normal read still begins at 'a'.
        assertEquals('a', br.read());
        br.close();
    }

    @Test
    void testReadNegativeLengthThrows() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        final char[] buf = new char[10];
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read(buf, 0, -1);
            }
        });
        br.close();
    }

    @Test
    void testReadArrayAtEofSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("ab");
        final char[] buf = new char[10];
        final int firstLen = br.read(buf, 0, 10);
        assertEquals(2, firstLen);
        assertEquals('b', br.getLastChar());
        final int secondLen = br.read(buf, 0, 10);
        assertEquals(EOF, secondLen);
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abcdef");
        assertEquals('a', br.read());
        assertEquals('b', br.read());
        br.mark(10);
        final long markedPosition = br.getPosition();
        final int markedLastChar = br.getLastChar();
        final long markedLineNumber = br.getLineNumber();
        assertEquals('c', br.read());
        assertEquals('d', br.read());
        assertEquals(4, br.getPosition());
        br.reset();
        assertEquals(markedPosition, br.getPosition());
        assertEquals(markedLastChar, br.getLastChar());
        assertEquals(markedLineNumber, br.getLineNumber());
        // Reading after reset replays from the marked point.
        assertEquals('c', br.read());
        assertEquals('d', br.read());
        br.close();
    }

    @Test
    void testReadLineReturnsNullAtEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("");
        assertNull(br.readLine());
        // readLine() returns via the peek() EOF check before any read(), so lastChar is untouched.
        assertEquals(UNDEFINED, br.getLastChar());
        br.close();
    }

    @Test
    void testReadLineWithLoneCarriageReturnAtEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("foo\r");
        assertEquals("foo", br.readLine());
        assertNull(br.readLine());
        assertEquals(1, br.getLineNumber());
        br.close();
    }

    @Test
    void testGetBytesReadWithoutTrackingStaysZero() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abcdef");
        br.read();
        br.read();
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testGetBytesReadWithTrackingDisabledForCharsetConstructorOverload() throws IOException {
        // trackBytes = false, even though a charset is supplied: no byte tracking occurs.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        br.read();
        br.read();
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testGetBytesReadAsciiOneBytePerChar() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.US_ASCII, true);
        assertEquals('a', br.read());
        assertEquals(1, br.getBytesRead());
        assertEquals('b', br.read());
        assertEquals(2, br.getBytesRead());
        final char[] buf = new char[1];
        assertEquals(1, br.read(buf, 0, 1));
        assertArrayEquals(new char[] { 'c' }, buf);
        assertEquals(3, br.getBytesRead());
        br.close();
    }

    @Test
    void testGetBytesReadMarkAndResetRestoresByteCount() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abcdef"), StandardCharsets.US_ASCII, true);
        br.read();
        br.read();
        br.mark(10);
        final long markedBytes = br.getBytesRead();
        assertEquals(2, markedBytes);
        br.read();
        br.read();
        assertEquals(4, br.getBytesRead());
        br.reset();
        assertEquals(markedBytes, br.getBytesRead());
        br.close();
    }

    @Test
    void testHighSurrogateAloneDoesNotCountBytesImmediately() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uD800"), StandardCharsets.UTF_8, true);
        final int current = br.read();
        assertEquals(0xD800, current);
        assertEquals(0, br.getBytesRead());
        assertEquals(EOF, br.read());
        br.close();
    }

    @Test
    void testUnpairedLowSurrogateThrowsCharacterCodingException() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uDC00"), StandardCharsets.UTF_8, true);
        assertThrows(CharacterCodingException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
        br.close();
    }

    @Test
    void testSurrogatePairCountsAsFourUtf8Bytes() throws IOException {
        final String emoji = "😀"; // U+1F600 GRINNING FACE
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(emoji), StandardCharsets.UTF_8, true);
        assertEquals(0xD83D, br.read());
        assertEquals(0, br.getBytesRead());
        assertEquals(0xDE00, br.read());
        assertEquals(4, br.getBytesRead());
        br.close();
    }

    @Test
    void testDefaultConstructorUsesDefaultBufferSize() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello world"));
        assertEquals("hello world", br.readLine());
        assertTrue(br.getLineNumber() >= 0);
        br.close();
    }
}
