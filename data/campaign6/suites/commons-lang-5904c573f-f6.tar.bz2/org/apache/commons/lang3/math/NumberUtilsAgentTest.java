/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    // ------------------------------------------------------------------
    // constants / constructor
    // ------------------------------------------------------------------

    @Test
    void testConstantsValues() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testConstructorExists() {
        assertNotNullInstance(new NumberUtils());
    }

    private static void assertNotNullInstance(final Object o) {
        assertTrue(o instanceof NumberUtils);
    }

    // ------------------------------------------------------------------
    // compare (deprecated numeric compare wrappers)
    // ------------------------------------------------------------------

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ------------------------------------------------------------------
    // createBigDecimal
    // ------------------------------------------------------------------

    @Test
    void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("  "));
    }

    @Test
    void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("not a number"));
    }

    @Test
    void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertEquals(new BigDecimal("-42"), NumberUtils.createBigDecimal("-42"));
    }

    // ------------------------------------------------------------------
    // createBigInteger
    // ------------------------------------------------------------------

    @Test
    void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigInteger(""));
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(10), NumberUtils.createBigInteger("10"));
        assertEquals(BigInteger.valueOf(-10), NumberUtils.createBigInteger("-10"));
        assertEquals(BigInteger.ZERO, NumberUtils.createBigInteger("0"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(16), NumberUtils.createBigInteger("0x10"));
        assertEquals(BigInteger.valueOf(16), NumberUtils.createBigInteger("0X10"));
        assertEquals(BigInteger.valueOf(16), NumberUtils.createBigInteger("#10"));
        assertEquals(BigInteger.valueOf(-16), NumberUtils.createBigInteger("-0x10"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(-8), NumberUtils.createBigInteger("-010"));
    }

    // ------------------------------------------------------------------
    // createDouble / createFloat
    // ------------------------------------------------------------------

    @Test
    void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createDouble("abc"));
    }

    @Test
    void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createFloat("abc"));
    }

    // ------------------------------------------------------------------
    // createInteger
    // ------------------------------------------------------------------

    @Test
    void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(10), NumberUtils.createInteger("10"));
        assertEquals(Integer.valueOf(-10), NumberUtils.createInteger("-10"));
    }

    @Test
    void testCreateIntegerHexAndOctal() {
        assertEquals(Integer.valueOf(16), NumberUtils.createInteger("0x10"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    void testCreateIntegerOverflowThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createInteger("2147483648"));
    }

    // ------------------------------------------------------------------
    // createLong
    // ------------------------------------------------------------------

    @Test
    void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    void testCreateLongDecimal() {
        assertEquals(Long.valueOf(10L), NumberUtils.createLong("10"));
    }

    @Test
    void testCreateLongHex() {
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createLong("0x7fffffffffffffff"));
    }

    @Test
    void testCreateLongOverflowThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createLong("9223372036854775808"));
    }

    // ------------------------------------------------------------------
    // createNumber
    // ------------------------------------------------------------------

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("  "));
    }

    @Test
    void testCreateNumberPlainInt() {
        final Number n = NumberUtils.createNumber("12345");
        assertTrue(n instanceof Integer, "expected Integer but got " + n.getClass());
        assertEquals(12345, n.intValue());
    }

    @Test
    void testCreateNumberPlainLong() {
        final Number n = NumberUtils.createNumber("1234567890123");
        assertTrue(n instanceof Long, "expected Long but got " + n.getClass());
        assertEquals(1234567890123L, n.longValue());
    }

    @Test
    void testCreateNumberPlainBigInteger() {
        final Number n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n instanceof BigInteger, "expected BigInteger but got " + n.getClass());
        assertEquals(new BigInteger("123456789012345678901234567890"), n);
    }

    @Test
    void testCreateNumberFloatByDefault() {
        final Number n = NumberUtils.createNumber("3.14");
        assertTrue(n instanceof Float, "expected Float but got " + n.getClass());
        assertEquals(3.14f, n.floatValue(), 0.0f);
    }

    @Test
    void testCreateNumberWithFloatSuffix() {
        final Number n = NumberUtils.createNumber("3.14f");
        assertTrue(n instanceof Float, "expected Float but got " + n.getClass());
        assertEquals(3.14f, n.floatValue(), 0.0f);
    }

    @Test
    void testCreateNumberWithDoubleSuffix() {
        final Number n = NumberUtils.createNumber("3.14d");
        assertTrue(n instanceof Double, "expected Double but got " + n.getClass());
        assertEquals(3.14d, n.doubleValue(), 0.0d);
    }

    @Test
    void testCreateNumberWithLongSuffix() {
        final Number n = NumberUtils.createNumber("10L");
        assertTrue(n instanceof Long, "expected Long but got " + n.getClass());
        assertEquals(10L, n.longValue());
    }

    @Test
    void testCreateNumberDecimalWithLongSuffixThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.1L"));
    }

    @Test
    void testCreateNumberHexInteger() {
        final Number n = NumberUtils.createNumber("0x7FFFFFFF");
        assertTrue(n instanceof Integer, "expected Integer but got " + n.getClass());
        assertEquals(Integer.MAX_VALUE, n.intValue());
    }

    @Test
    void testCreateNumberHexOverflowsToLong() {
        final Number n = NumberUtils.createNumber("0x80000000");
        assertTrue(n instanceof Long, "expected Long but got " + n.getClass());
        assertEquals(0x80000000L, n.longValue());
    }

    @Test
    void testCreateNumberHexOverflowsToBigInteger() {
        final Number n = NumberUtils.createNumber("0xFFFFFFFFFFFFFFFF0");
        assertTrue(n instanceof BigInteger, "expected BigInteger but got " + n.getClass());
    }

    @Test
    void testCreateNumberHex16DigitBoundary() {
        // 16 significant hex digits starting with 7 (or below) still fits in a long.
        final Number fitsLong = NumberUtils.createNumber("0x7FFFFFFFFFFFFFFF");
        assertTrue(fitsLong instanceof Long, "expected Long but got " + fitsLong.getClass());
        assertEquals(Long.MAX_VALUE, fitsLong.longValue());
        // 16 significant hex digits starting above 7 overflow a long.
        final Number overflowsLong = NumberUtils.createNumber("0x8000000000000000");
        assertTrue(overflowsLong instanceof BigInteger, "expected BigInteger but got " + overflowsLong.getClass());
        assertEquals(new BigInteger("8000000000000000", 16), overflowsLong);
    }

    @Test
    void testCreateNumberHugeExponentFallsBackToBigDecimal() {
        final Number n = NumberUtils.createNumber("1e400");
        assertTrue(n instanceof BigDecimal, "expected BigDecimal but got " + n.getClass());
    }

    @Test
    void testCreateNumberInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("ABCDEF"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.2.3"));
    }

    @Test
    void testCreateNumberLeadingZeroNonOctalThrows() {
        // "09" is not a valid octal literal per the class documentation
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("09"));
    }

    // ------------------------------------------------------------------
    // isCreatable / isNumber (deprecated alias)
    // ------------------------------------------------------------------

    @Test
    void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
    }

    @Test
    void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12.34"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
    }

    @Test
    void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("1.1L"));
    }

    @Test
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("12.3"), NumberUtils.isNumber("12.3"));
        assertEquals(NumberUtils.isCreatable("not a number"), NumberUtils.isNumber("not a number"));
    }

    // ------------------------------------------------------------------
    // isDigits
    // ------------------------------------------------------------------

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12a3"));
    }

    // ------------------------------------------------------------------
    // isParsable
    // ------------------------------------------------------------------

    @Test
    void testIsParsableNullAndEmpty() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    void testIsParsableValid() {
        assertTrue(NumberUtils.isParsable("1"));
        assertTrue(NumberUtils.isParsable("-1.5"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
    }

    @Test
    void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("1L"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ------------------------------------------------------------------
    // max / min - arrays
    // ------------------------------------------------------------------

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 3, (byte) 5, (byte) 1));
        assertEquals((byte) 5, NumberUtils.max(new byte[] { (byte) 5 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new byte[0]));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(3, 5, 1));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new int[0]));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(3L, 5L, 1L));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new long[0]));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 3, (short) 5, (short) 1));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new short[0]));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(3.0, 5.0, 1.0), 0.0d);
        assertThrows(NullPointerException.class, () -> NumberUtils.max((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new double[0]));
    }

    @Test
    void testMaxDoubleArrayWithNaNReturnsNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0, Double.NaN, 3.0)));
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.0f, NumberUtils.max(3.0f, 5.0f, 1.0f), 0.0f);
        assertThrows(NullPointerException.class, () -> NumberUtils.max((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new float[0]));
    }

    @Test
    void testMaxFloatArrayWithNaNReturnsNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 5, (byte) 1));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new byte[0]));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(3, 5, 1));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new int[0]));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(3L, 5L, 1L));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new long[0]));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 5, (short) 1));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new short[0]));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(3.0, 5.0, 1.0), 0.0d);
        assertThrows(NullPointerException.class, () -> NumberUtils.min((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new double[0]));
    }

    @Test
    void testMinDoubleArrayWithNaNReturnsNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0, Double.NaN, 3.0)));
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(3.0f, 5.0f, 1.0f), 0.0f);
        assertThrows(NullPointerException.class, () -> NumberUtils.min((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new float[0]));
    }

    @Test
    void testMinFloatArrayWithNaNReturnsNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    // ------------------------------------------------------------------
    // max / min - three-argument overloads
    // ------------------------------------------------------------------

    @Test
    void testMaxThreeArgByte() {
        assertEquals((byte) 9, NumberUtils.max((byte) 9, (byte) 2, (byte) 5));
        assertEquals((byte) 9, NumberUtils.max((byte) 2, (byte) 9, (byte) 5));
        assertEquals((byte) 9, NumberUtils.max((byte) 2, (byte) 5, (byte) 9));
    }

    @Test
    void testMaxThreeArgInt() {
        assertEquals(9, NumberUtils.max(9, 2, 5));
        assertEquals(9, NumberUtils.max(2, 9, 5));
        assertEquals(9, NumberUtils.max(2, 5, 9));
    }

    @Test
    void testMaxThreeArgLong() {
        assertEquals(9L, NumberUtils.max(9L, 2L, 5L));
        assertEquals(9L, NumberUtils.max(2L, 9L, 5L));
        assertEquals(9L, NumberUtils.max(2L, 5L, 9L));
    }

    @Test
    void testMaxThreeArgShort() {
        assertEquals((short) 9, NumberUtils.max((short) 9, (short) 2, (short) 5));
        assertEquals((short) 9, NumberUtils.max((short) 2, (short) 9, (short) 5));
        assertEquals((short) 9, NumberUtils.max((short) 2, (short) 5, (short) 9));
    }

    @Test
    void testMaxThreeArgDoubleWithNaN() {
        assertEquals(9.0d, NumberUtils.max(9.0d, 2.0d, 5.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMaxThreeArgFloatWithNaN() {
        assertEquals(9.0f, NumberUtils.max(9.0f, 2.0f, 5.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMinThreeArgByte() {
        assertEquals((byte) 2, NumberUtils.min((byte) 9, (byte) 2, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 2, (byte) 9, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 9, (byte) 5, (byte) 2));
    }

    @Test
    void testMinThreeArgInt() {
        assertEquals(2, NumberUtils.min(9, 2, 5));
        assertEquals(2, NumberUtils.min(2, 9, 5));
        assertEquals(2, NumberUtils.min(9, 5, 2));
    }

    @Test
    void testMinThreeArgLong() {
        assertEquals(2L, NumberUtils.min(9L, 2L, 5L));
        assertEquals(2L, NumberUtils.min(2L, 9L, 5L));
        assertEquals(2L, NumberUtils.min(9L, 5L, 2L));
    }

    @Test
    void testMinThreeArgShort() {
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 2, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 2, (short) 9, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 5, (short) 2));
    }

    @Test
    void testMinThreeArgDoubleWithNaN() {
        assertEquals(2.0d, NumberUtils.min(9.0d, 2.0d, 5.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMinThreeArgFloatWithNaN() {
        assertEquals(2.0f, NumberUtils.min(9.0f, 2.0f, 5.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    // ------------------------------------------------------------------
    // toByte / toShort / toInt / toLong / toDouble / toFloat
    // ------------------------------------------------------------------

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 5, NumberUtils.toByte(null, (byte) 5));
        assertEquals((byte) 5, NumberUtils.toByte("not a byte", (byte) 5));
        assertEquals((byte) 5, NumberUtils.toByte("128", (byte) 5));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 9, NumberUtils.toShort(null, (short) 9));
        assertEquals((short) 9, NumberUtils.toShort("not a short", (short) 9));
        assertEquals((short) 9, NumberUtils.toShort("40000", (short) 9));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(9, NumberUtils.toInt(null, 9));
        assertEquals(9, NumberUtils.toInt("not an int", 9));
        assertEquals(9, NumberUtils.toInt("99999999999999", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(9L, NumberUtils.toLong(null, 9L));
        assertEquals(9L, NumberUtils.toLong("not a long", 9L));
        assertEquals(9L, NumberUtils.toLong("99999999999999999999999999", 9L));
    }

    @Test
    void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("not a double", 1.1d), 0.0d);
    }

    @Test
    void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("not a float", 1.1f), 0.0f);
    }

    // ------------------------------------------------------------------
    // toScaledBigDecimal
    // ------------------------------------------------------------------

    @Test
    void testToScaledBigDecimalBigDecimalNullReturnsZero() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal((BigDecimal) null);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    void testToScaledBigDecimalBigDecimalDefaultScaleAndRounding() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.125"));
        assertEquals(new BigDecimal("1.12"), result);
        assertEquals(2, result.scale());
    }

    @Test
    void testToScaledBigDecimalHalfEvenRounding() {
        // 0.125 is exactly representable; HALF_EVEN rounds to the even neighbour 0.12
        assertEquals(new BigDecimal("0.12"), NumberUtils.toScaledBigDecimal(new BigDecimal("0.125"), 2, RoundingMode.HALF_EVEN));
        // 0.135 rounds to the even neighbour 0.14
        assertEquals(new BigDecimal("0.14"), NumberUtils.toScaledBigDecimal(new BigDecimal("0.135"), 2, RoundingMode.HALF_EVEN));
    }

    @Test
    void testToScaledBigDecimalNullRoundingModeDefaultsToHalfEven() {
        assertEquals(new BigDecimal("0.12"), NumberUtils.toScaledBigDecimal(new BigDecimal("0.125"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDoubleNullReturnsZero() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal((Double) null);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(new BigDecimal("8.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(8.5d)));
    }

    @Test
    void testToScaledBigDecimalFloatNullReturnsZero() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal((Float) null);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(new BigDecimal("8.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(8.5f)));
    }

    @Test
    void testToScaledBigDecimalFloatRoundsTheFloatsOwnDecimalValue() {
        // 0.045f's own decimal value ("0.045", per Float.toString) rounds HALF_EVEN at scale 2 to 0.04.
        // The implementation widens the float to double before converting to BigDecimal, which perturbs
        // the value just enough to round to 0.05 instead.
        assertEquals(new BigDecimal("0.04"), NumberUtils.toScaledBigDecimal(Float.valueOf(0.045f)));
    }

    @Test
    void testToScaledBigDecimalStringNullReturnsZero() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal((String) null);
        assertEquals(0, BigDecimal.ZERO.compareTo(result));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(new BigDecimal("8.50"), NumberUtils.toScaledBigDecimal("8.5"));
    }
}
