/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

class DurationUtilsAgentTest {

    private static final class RecordingBiConsumer implements FailableBiConsumer<Long, Integer, RuntimeException> {
        private Long millis;
        private Integer nanos;
        private int calls;

        @Override
        public void accept(final Long millisArg, final Integer nanosArg) {
            this.millis = millisArg;
            this.nanos = nanosArg;
            this.calls++;
        }
    }

    @Test
    void testAccept_positiveDuration() {
        final RecordingBiConsumer recorder = new RecordingBiConsumer();
        final Duration duration = Duration.ofMillis(1234).plusNanos(567000);
        DurationUtils.accept(recorder, duration);
        assertEquals(1, recorder.calls);
        assertEquals(Long.valueOf(1234), recorder.millis);
        assertEquals(Integer.valueOf(567000), recorder.nanos);
    }

    @Test
    void testAccept_negativeDuration() {
        final RecordingBiConsumer recorder = new RecordingBiConsumer();
        final Duration duration = Duration.ofMillis(-1234).minusNanos(567000);
        DurationUtils.accept(recorder, duration);
        assertEquals(1, recorder.calls);
        // Nanosecond component must be non-negative per the Javadoc contract.
        assertTrue(recorder.nanos.intValue() >= 0);
        assertTrue(recorder.nanos.intValue() < 1000000);
    }

    @Test
    void testAccept_nullConsumerDoesNothing() {
        // Must not throw when consumer is null.
        DurationUtils.accept(null, Duration.ofSeconds(1));
    }

    @Test
    void testAccept_nullDurationDoesNothing() {
        final RecordingBiConsumer recorder = new RecordingBiConsumer();
        DurationUtils.accept(recorder, null);
        assertEquals(0, recorder.calls);
    }

    @Test
    void testGet_withValue() {
        final Duration duration = DurationUtils.get("DurationUtilsAgentTest.missing.key", ChronoUnit.SECONDS, 42);
        assertEquals(Duration.ofSeconds(42), duration);
    }

    @Test
    void testGet_emptyKeyUsesDefault() {
        final Duration duration = DurationUtils.get("", ChronoUnit.MINUTES, 5);
        assertEquals(Duration.ofMinutes(5), duration);
    }

    @Test
    void testGet_nullKeyUsesDefault() {
        final Duration duration = DurationUtils.get(null, ChronoUnit.HOURS, 2);
        assertEquals(Duration.ofHours(2), duration);
    }

    @Test
    void testGetMillis_defaultValue() {
        final Duration duration = DurationUtils.getMillis("DurationUtilsAgentTest.missing.millis.key", 999);
        assertEquals(Duration.ofMillis(999), duration);
    }

    @Test
    void testGetSeconds_defaultValue() {
        final Duration duration = DurationUtils.getSeconds("DurationUtilsAgentTest.missing.seconds.key", 7);
        assertEquals(Duration.ofSeconds(7), duration);
    }

    @Test
    void testGetNanosOfMilli_zero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofMillis(5)));
    }

    @Test
    void testGetNanosOfMilli_partial() {
        final Duration duration = Duration.ofMillis(3).plusNanos(123456);
        assertEquals(123456, DurationUtils.getNanosOfMilli(duration));
    }

    @Test
    void testGetNanosOfMilli_null() {
        // zeroIfNull() makes this behave like Duration.ZERO.
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testGetNanosOfMiili_deprecatedDelegates() {
        final Duration duration = Duration.ofMillis(3).plusNanos(42);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testIsPositive_positive() {
        assertTrue(DurationUtils.isPositive(Duration.ofSeconds(1)));
    }

    @Test
    void testIsPositive_zero() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    void testIsPositive_negative() {
        assertFalse(DurationUtils.isPositive(Duration.ofSeconds(-1)));
    }

    @Test
    void testIsPositive_nullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.isPositive(null);
            }
        });
    }

    @Test
    void testOfConsumer_measuresElapsedTimeAndPassesStartInstant() throws Exception {
        final List<Instant> seenStart = new ArrayList<Instant>();
        final Duration duration = DurationUtils.of(new FailableConsumer<Instant, Exception>() {
            @Override
            public void accept(final Instant start) {
                seenStart.add(start);
            }
        });
        assertNotNull(duration);
        assertFalse(duration.isNegative());
        assertEquals(1, seenStart.size());
        assertNotNull(seenStart.get(0));
    }

    @Test
    void testOfRunnable_measuresElapsedTime() throws Exception {
        final boolean[] ran = new boolean[1];
        final Duration duration = DurationUtils.of(new FailableRunnable<Exception>() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfRunnable_propagatesException() {
        final Exception thrown = new IllegalStateException("boom");
        final Exception caught = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DurationUtils.of(new FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw thrown;
                    }
                });
            }
        });
        assertEquals(thrown, caught);
    }

    @Test
    void testSince_computesPositiveDuration() {
        final Instant past = Instant.now().minusSeconds(5);
        final Duration duration = DurationUtils.since(past);
        assertTrue(duration.toMillis() >= 5000);
    }

    @Test
    void testToDuration_seconds() {
        assertEquals(Duration.ofSeconds(10), DurationUtils.toDuration(10, TimeUnit.SECONDS));
    }

    @Test
    void testToDuration_milliseconds() {
        assertEquals(Duration.ofMillis(500), DurationUtils.toDuration(500, TimeUnit.MILLISECONDS));
    }

    @Test
    void testToDuration_negativeAmount() {
        assertEquals(Duration.ofSeconds(-3), DurationUtils.toDuration(-3, TimeUnit.SECONDS));
    }

    @Test
    void testToMillisInt_normalValue() {
        assertEquals(1500, DurationUtils.toMillisInt(Duration.ofMillis(1500)));
    }

    @Test
    void testToMillisInt_clampsAboveIntMax() {
        final Duration duration = Duration.ofMillis(Integer.MAX_VALUE).plusMillis(1000);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisInt_clampsBelowIntMin() {
        final Duration duration = Duration.ofMillis(Integer.MIN_VALUE).minusMillis(1000);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisInt_nullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testToMillisLong_normalValue() {
        assertEquals(42000L, DurationUtils.toMillisLong(Duration.ofSeconds(42)));
    }

    @Test
    void testToMillisLong_clampsAboveLongMax() {
        final Duration duration = Duration.ofSeconds(Long.MAX_VALUE / 1000L + 1L);
        assertEquals(Long.MAX_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    void testToMillisLong_clampsBelowLongMin() {
        final Duration duration = Duration.ofSeconds(Long.MIN_VALUE / 1000L - 1L);
        assertEquals(Long.MIN_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    void testToMillisLong_nullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisLong(null);
            }
        });
    }

    @Test
    void testZeroIfNull_withNull() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNull_withNonNull() {
        final Duration duration = Duration.ofSeconds(9);
        assertEquals(duration, DurationUtils.zeroIfNull(duration));
    }

    @Test
    void testConstructor_doesNotThrow() {
        assertNotNull(new DurationUtils());
    }
}
