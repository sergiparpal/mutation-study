/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private Calendar newCalendar() {
        final Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.clear();
        return cal;
    }

    @Test
    void testParseBasicDateSuccess() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date actual = parser.parse("2022-01-15");

        final Calendar expectedCal = newCalendar();
        expectedCal.set(2022, Calendar.JANUARY, 15);

        assertEquals(expectedCal.getTime(), actual);
    }

    @Test
    void testGetPatternLocaleAndTimeZoneAccessors() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(GMT, parser.getTimeZone());
        // getTimeZone() clones the internal TimeZone, so callers cannot mutate parser state through it.
        assertNotNull(parser.getTimeZone());
    }

    @Test
    void testNullLocaleDefaultsToSystemDefault() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testParseStringThrowsParseExceptionOnUnparseableInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("abcd-01-01");
            }
        });
        assertEquals(0, e.getErrorOffset());
        assertTrue(e.getMessage().contains("Unparseable date"));
    }

    @Test
    void testParseStringParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("abcd-01-01", pos);
        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
        // On failure the index is left untouched; only the error index is reported.
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParseStringParsePositionDoesNotRequireFullConsumption() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("2022trailing", pos);
        assertNotNull(result);
        assertEquals(4, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());

        final Calendar expectedCal = newCalendar();
        expectedCal.set(2022, Calendar.JANUARY, 1);
        assertEquals(expectedCal.getTime(), result);
    }

    @Test
    void testParsePositionIndexBeyondSourceLengthFails() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date result = parser.parse("2022", pos);
        assertNull(result);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseWithCalendarOverloadUpdatesCalendarAndReturnsTrue() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = newCalendar();
        final ParsePosition pos = new ParsePosition(0);

        final boolean success = parser.parse("2023-07-04", pos, cal);

        assertTrue(success);
        assertEquals(10, pos.getIndex());
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithCalendarOverloadReturnsFalseOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = newCalendar();
        final ParsePosition pos = new ParsePosition(0);

        final boolean success = parser.parse("notadate", pos, cal);

        assertFalse(success);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParseObjectStringDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object result = parser.parseObject("2022-01-15");
        assertTrue(result instanceof Date);

        final Calendar expectedCal = newCalendar();
        expectedCal.set(2022, Calendar.JANUARY, 15);
        assertEquals(expectedCal.getTime(), result);
    }

    @Test
    void testParseObjectStringParsePositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object result = parser.parseObject("2022-01-15", pos);
        assertNotNull(result);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testTwoDigitYearBelowStartYearRollsIntoNextCentury() throws ParseException {
        // centuryStart = 1950 -> century = 1900, startYear = 50
        final Calendar centuryStart = new GregorianCalendar(GMT, Locale.US);
        centuryStart.clear();
        centuryStart.set(1950, Calendar.JANUARY, 1);

        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryStart.getTime());

        final Calendar cal49 = newCalendar();
        parser.parse("49", new ParsePosition(0), cal49);
        assertEquals(2049, cal49.get(Calendar.YEAR));

        final Calendar cal50 = newCalendar();
        parser.parse("50", new ParsePosition(0), cal50);
        assertEquals(1950, cal50.get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearPatternIsNotCenturyAdjusted() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final Calendar cal = newCalendar();
        final boolean success = parser.parse("0050", new ParsePosition(0), cal);
        assertTrue(success);
        // width > 2 selects the literal year strategy: no two digit century adjustment is applied.
        assertEquals(50, cal.get(Calendar.YEAR));
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("QQ", GMT, Locale.US);
            }
        });
        assertTrue(e.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy'bad", GMT, Locale.US);
            }
        });
        assertEquals("Unterminated quote", e.getMessage());
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'T'MM", GMT, Locale.US);
        final ParsePosition posOk = new ParsePosition(0);
        final Date ok = parser.parse("2022T01", posOk);
        assertNotNull(ok);
        assertEquals(7, posOk.getIndex());

        final ParsePosition posFail = new ParsePosition(0);
        final Date fail = parser.parse("2022X01", posFail);
        assertNull(fail);
        assertEquals(4, posFail.getErrorIndex());
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser differentPattern = new FastDateParser("yyyy/MM/dd", GMT, Locale.US);
        final FastDateParser differentLocale = new FastDateParser("yyyy-MM-dd", GMT, Locale.FRANCE);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, differentPattern);
        assertNotEquals(p1, differentLocale);
        assertNotEquals(p1, "yyyy-MM-dd");
        assertNotEquals(p1, null);
    }

    @Test
    void testToStringAndToStringAllContainPatternInformation() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("GMT"));

        final String all = parser.toStringAll();
        assertTrue(all.contains("pattern=yyyy-MM-dd"));
        assertTrue(all.contains("timeZone="));
        assertTrue(all.contains("locale="));
    }

    @Test
    void testSerializationRoundTripPreservesParsingBehavior() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser restored = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, restored);
        assertEquals(parser.parse("2022-01-15"), restored.parse("2022-01-15"));
    }

    @Test
    void testWeekYearPatternResolvesThroughWeekDate() {
        final FastDateParser parser = new FastDateParser("YYYY-ww-u", GMT, Locale.US);
        final Calendar cal = newCalendar();
        cal.setMinimalDaysInFirstWeek(4);
        cal.setFirstDayOfWeek(Calendar.MONDAY);

        final boolean success = parser.parse("2021-01-01", new ParsePosition(0), cal);

        assertTrue(success);
        assertTrue(cal.isWeekDateSupported());
        assertEquals(2021, cal.getWeekYear());
        assertEquals(1, cal.get(Calendar.WEEK_OF_YEAR));
        assertEquals(Calendar.MONDAY, cal.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testJapaneseImperialLocaleFailureAddsExplanatoryMessage() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("does not support dates before 1868-01-01"));
    }

    @Test
    void testTimeZoneTextStrategyParsesAbbreviation() {
        final FastDateParser parser = new FastDateParser("z yyyy", GMT, Locale.UK);
        final Calendar cal = newCalendar();
        final boolean success = parser.parse("GMT 2010", new ParsePosition(0), cal);
        assertTrue(success);
        assertEquals(2010, cal.get(Calendar.YEAR));
    }

    @Test
    void testHourOfDayUpperBoundaryTwentyFour() {
        // 'k' is Hour in day (1-24): 24 maps to midnight (hour-of-day 0) via modify().
        final FastDateParser parser = new FastDateParser("kk", GMT, Locale.US);
        final Calendar cal = newCalendar();
        final boolean success = parser.parse("24", new ParsePosition(0), cal);
        assertTrue(success);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHour12NoonMapsToZero() {
        // 'h' is Hour in am/pm (1-12): 12 maps to 0 via modify().
        final FastDateParser parser = new FastDateParser("hh", GMT, Locale.US);
        final Calendar cal = newCalendar();
        final boolean success = parser.parse("12", new ParsePosition(0), cal);
        assertTrue(success);
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    @Test
    void testNumericOverflowFieldFailsToParse() {
        // A run of digits with no maxWidth that overflows int must be reported as a parse failure,
        // not propagate a NumberFormatException.
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("99999999999999999999", pos);
        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testGetPatternsReflectsCompiledStrategyCount() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        // "yyyy", "-", "MM", "-", "dd" -> 5 strategies
        assertEquals(5, parser.getPatterns().size());
    }
}
