/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class LocaleUtilsAgentTest {

    private Locale originalDefault;

    @BeforeEach
    public void saveDefaultLocale() {
        originalDefault = Locale.getDefault();
    }

    @AfterEach
    public void restoreDefaultLocale() {
        Locale.setDefault(originalDefault);
    }

    // --- availableLocaleList() ---

    @Test
    public void testAvailableLocaleListNotEmptyAndCached() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertSame(list, LocaleUtils.availableLocaleList());
    }

    @Test
    public void testAvailableLocaleListIsSorted() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        for (int i = 1; i < list.size(); i++) {
            final String previous = list.get(i - 1).toString();
            final String current = list.get(i).toString();
            assertTrue(previous.compareTo(current) <= 0, "not sorted at index " + i);
        }
    }

    @Test
    public void testAvailableLocaleListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    // --- availableLocaleSet() ---

    @Test
    public void testAvailableLocaleSetNotEmptyAndCached() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertSame(set, LocaleUtils.availableLocaleSet());
    }

    @Test
    public void testAvailableLocaleSetMatchesList() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertEquals(list.size(), set.size());
        assertTrue(set.containsAll(list));
    }

    @Test
    public void testAvailableLocaleSetIsUnmodifiable() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                set.add(Locale.US);
            }
        });
    }

    // --- isAvailableLocale(Locale) ---

    @Test
    public void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "ZZZZZ")));
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    // --- isLanguageUndetermined(Locale) ---

    @Test
    public void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
    }

    // --- countriesByLanguage(String) ---

    @Test
    public void testCountriesByLanguageNull() {
        final List<Locale> result = LocaleUtils.countriesByLanguage(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageEnglish() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertFalse(result.isEmpty());
        assertTrue(result.contains(Locale.US));
        for (final Locale locale : result) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testCountriesByLanguageUnknown() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageIsCachedAndUnmodifiable() {
        final List<Locale> first = LocaleUtils.countriesByLanguage("en");
        final List<Locale> second = LocaleUtils.countriesByLanguage("en");
        assertSame(first, second);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                first.add(Locale.US);
            }
        });
    }

    // --- languagesByCountry(String) ---

    @Test
    public void testLanguagesByCountryNull() {
        final List<Locale> result = LocaleUtils.languagesByCountry(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUs() {
        final List<Locale> result = LocaleUtils.languagesByCountry("US");
        assertFalse(result.isEmpty());
        assertTrue(result.contains(Locale.US));
        for (final Locale locale : result) {
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testLanguagesByCountryUnknown() {
        final List<Locale> result = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryIsCachedAndUnmodifiable() {
        final List<Locale> first = LocaleUtils.languagesByCountry("US");
        final List<Locale> second = LocaleUtils.languagesByCountry("US");
        assertSame(first, second);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                first.add(Locale.US);
            }
        });
    }

    // --- localeLookupList(Locale) / localeLookupList(Locale, Locale) ---

    @Test
    public void testLocaleLookupListNull() {
        final List<Locale> result = LocaleUtils.localeLookupList(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListNullWithDefault() {
        final List<Locale> result = LocaleUtils.localeLookupList(null, Locale.ENGLISH);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListFullVariant() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> result = LocaleUtils.localeLookupList(locale);
        assertEquals(3, result.size());
        assertEquals(new Locale("fr", "CA", "xxx"), result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
    }

    @Test
    public void testLocaleLookupListFullVariantWithDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> result = LocaleUtils.localeLookupList(locale, Locale.ENGLISH);
        assertEquals(4, result.size());
        assertEquals(new Locale("fr", "CA", "xxx"), result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
        assertEquals(Locale.ENGLISH, result.get(3));
    }

    @Test
    public void testLocaleLookupListNoDuplicateWhenDefaultAlreadyPresent() {
        final Locale locale = new Locale("fr", "CA");
        final List<Locale> result = LocaleUtils.localeLookupList(locale, new Locale("fr"));
        assertEquals(2, result.size());
        assertEquals(new Locale("fr", "CA"), result.get(0));
        assertEquals(new Locale("fr"), result.get(1));
    }

    @Test
    public void testLocaleLookupListLanguageOnly() {
        final Locale locale = new Locale("en");
        final List<Locale> result = LocaleUtils.localeLookupList(locale);
        assertEquals(1, result.size());
        assertEquals(new Locale("en"), result.get(0));
    }

    @Test
    public void testLocaleLookupListIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                result.add(Locale.US);
            }
        });
    }

    // --- toLocale(Locale) ---

    @Test
    public void testToLocaleLocaleNonNullReturnsSameInstance() {
        assertSame(Locale.JAPAN, LocaleUtils.toLocale(Locale.JAPAN));
    }

    @Test
    public void testToLocaleLocaleNullReturnsDefault() {
        Locale.setDefault(Locale.CANADA_FRENCH);
        assertEquals(Locale.CANADA_FRENCH, LocaleUtils.toLocale((Locale) null));
    }

    // --- toLocale(String) ---

    @Test
    public void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en"), LocaleUtils.toLocale("en"));
    }

    @Test
    public void testToLocaleStringLanguageCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    public void testToLocaleStringLanguageCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    public void testToLocaleStringNumericAreaCode() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    public void testToLocaleStringLanguageCountryVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    public void testToLocaleStringCountryOnlyViaIsoCountryList() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreCountry() {
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("_GB"));
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreCountryVariant() {
        assertEquals(new Locale("", "GB", "x"), LocaleUtils.toLocale("_GB_x"));
    }

    @Test
    public void testToLocaleStringEmptyCountryWithVariant() {
        assertEquals(new Locale("en", "", "POSIX"), LocaleUtils.toLocale("en__POSIX"));
    }

    @Test
    public void testToLocaleStringThailandSpecialCase() {
        assertEquals(new Locale("th", "TH", "TH"), LocaleUtils.toLocale("th_TH_TH_#u-nu-thai"));
    }

    @Test
    public void testToLocaleStringJapanSpecialCase() {
        assertEquals(new Locale("ja", "JP", "JP"), LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese"));
    }

    @Test
    public void testToLocaleStringThreeLetterLanguage() {
        assertEquals(new Locale("fil", "PH"), LocaleUtils.toLocale("fil_PH"));
    }

    @Test
    public void testToLocaleStringTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreLowerCaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreLength4Throws() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBx");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreMismatchedSeparatorThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBxx");
            }
        });
    }

    @Test
    public void testToLocaleStringLowerCaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidFormatThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("yyyyyyyyyyyy");
            }
        });
    }

    // --- ofCountry(String) (package-private) ---

    @Test
    public void testOfCountryValid() {
        assertEquals(new Locale("", "US"), LocaleUtils.ofCountry("US"));
    }

    @Test
    public void testOfCountryNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.ofCountry(null);
            }
        });
    }

    // --- constructor ---

    @Test
    public void testConstructorIsPublicAndDeprecated() {
        assertNotNull(new LocaleUtils());
    }
}
