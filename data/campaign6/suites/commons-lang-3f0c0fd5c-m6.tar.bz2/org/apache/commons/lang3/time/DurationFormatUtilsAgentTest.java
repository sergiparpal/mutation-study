/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 */
class DurationFormatUtilsAgentTest {

    private static long gmtMillis(final int year, final int month, final int day) {
        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        cal.clear();
        cal.set(year, month, day, 0, 0, 0);
        return cal.getTimeInMillis();
    }

    @Test
    void testFormatDurationHMS_zero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    @Test
    void testFormatDurationHMS_typical() {
        // 1 hour, 1 minute, 1 second, 789 ms
        final long millis = 3600000L + 60000L + 1000L + 789L;
        assertEquals("01:01:01.789", DurationFormatUtils.formatDurationHMS(millis));
    }

    @Test
    void testFormatDuration_defaultPadsWithZeros() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDuration(0L, "HH:mm:ss.SSS"));
    }

    @Test
    void testFormatDuration_noPadding_stillPadsMillisAfterSeconds() {
        // ms sub-field directly following a seconds token is always zero padded to
        // at least 3 digits, regardless of the padWithZeros flag.
        final long millis = 3600000L + 60000L + 1000L + 5L;
        assertEquals("1:1:1.005", DurationFormatUtils.formatDuration(millis, "H:m:s.S", false));
    }

    @Test
    void testFormatDuration_negativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "HH:mm:ss.SSS");
            }
        });
        assertTrue(ex.getMessage().contains("durationMillis must not be negative"));
    }

    @Test
    void testFormatDuration_optionalBlock_oneDay() {
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, "d'd'[H'h'm'm']s's'"));
    }

    @Test
    void testFormatDuration_optionalBlock_oneHour() {
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(3600000L, "d'd'[H'h'm'm']s's'"));
    }

    @Test
    void testFormatDuration_optionalBlock_oneMinute() {
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(60000L, "d'd'[H'h'm'm']s's'"));
    }

    @Test
    void testFormatDuration_optionalBlock_allZero() {
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0L, "d'd'[H'h'm'm']s's'"));
    }

    @Test
    void testFormatDuration_escapedSingleQuoteLiteral() {
        // '' inside/outside a literal renders as a single literal apostrophe.
        assertEquals("5'5 seconds", DurationFormatUtils.formatDuration(5000L, "s''s' seconds'"));
    }

    @Test
    void testLexx_nestedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "[[s]]");
            }
        });
        assertTrue(ex.getMessage().contains("Nested optional block"));
    }

    @Test
    void testLexx_unopenedOptionalCloseThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "]");
            }
        });
        assertTrue(ex.getMessage().contains("Attempting to close unopened optional block"));
    }

    @Test
    void testLexx_unmatchedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "'abc");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched quote in format"));
    }

    @Test
    void testLexx_unmatchedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "[s");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched optional in format"));
    }

    @Test
    void testFormatDurationWords_zeroNoSuppress() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0L, false, false));
    }

    @Test
    void testFormatDurationWords_zeroSuppressBoth() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0L, true, true));
    }

    @Test
    void testFormatDurationWords_pluralization() {
        final long millis = 3600000L + 60000L + 1000L;
        assertEquals("0 days 1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    @Test
    void testFormatDurationWords_suppressLeadingZero() {
        final long millis = 3600000L + 60000L + 1000L;
        assertEquals("1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(millis, true, false));
    }

    @Test
    void testFormatDurationISO_zero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    @Test
    void testFormatDurationISO_typical() {
        final long millis = 3600000L + 60000L + 1000L + 5L;
        assertEquals("P0Y0M0DT1H1M1.005S", DurationFormatUtils.formatDurationISO(millis));
    }

    @Test
    void testFormatPeriod_monthsAndDays() {
        final long start = gmtMillis(2020, Calendar.JANUARY, 15);
        final long end = gmtMillis(2020, Calendar.MARCH, 10);
        final String result = DurationFormatUtils.formatPeriod(start, end, "M' months, 'd' days'", true, TimeZone.getTimeZone("GMT"));
        assertEquals("1 months, 26 days", result);
    }

    @Test
    void testFormatPeriod_startGreaterThanEndThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(100L, 0L, "HH:mm:ss.SSS");
            }
        });
        assertTrue(ex.getMessage().contains("startMillis must not be greater than endMillis"));
    }

    @Test
    void testFormatPeriod_sameInstantIsAllZero() {
        final long now = gmtMillis(2020, Calendar.JANUARY, 15);
        assertEquals("00:00:00.000", DurationFormatUtils.formatPeriod(now, now, "HH:mm:ss.SSS"));
    }

    @Test
    void testFormatPeriodISO_sameInstant() {
        final long now = gmtMillis(2020, Calendar.JANUARY, 15);
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(now, now));
    }

    @Test
    void testFormatPeriodISO_typical() {
        final long start = gmtMillis(2020, Calendar.JANUARY, 15);
        final long end = gmtMillis(2020, Calendar.MARCH, 10);
        assertEquals("P0Y1M26DT1H0M0.000S", DurationFormatUtils.formatPeriodISO(start, end));
    }

    @Test
    void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }
}
