/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

public class NumberUtilsAgentTest {

    // ---- compare ----

    @Test
    public void testCompareByte() {
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 3, (byte) 2) > 0);
    }

    @Test
    public void testCompareInt() {
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(3, 2) > 0);
    }

    @Test
    public void testCompareLong() {
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(3L, 2L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 3, (short) 2) > 0);
    }

    // ---- createBigDecimal ----

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
    }

    @Test
    public void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("   ");
            }
        });
    }

    @Test
    public void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---- createBigInteger ----

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("255"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("#FF"));
        assertEquals(BigInteger.valueOf(-255), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    public void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ---- createDouble / createFloat ----

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---- createInteger / createLong ----

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(42), NumberUtils.createInteger("42"));
    }

    @Test
    public void testCreateIntegerHexAndOctal() {
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateIntegerInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(42L), NumberUtils.createLong("42"));
    }

    @Test
    public void testCreateLongInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---- createNumber ----

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("  ");
            }
        });
    }

    @Test
    public void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongRange() {
        final String s = String.valueOf(Long.MAX_VALUE);
        final Number n = NumberUtils.createNumber(s);
        assertTrue(n instanceof Long);
        assertEquals(Long.MAX_VALUE, n.longValue());
    }

    @Test
    public void testCreateNumberBigIntegerRange() {
        final String s = String.valueOf(Long.MAX_VALUE) + "0";
        final Number n = NumberUtils.createNumber(s);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(s), n);
    }

    @Test
    public void testCreateNumberLongTypeSuffix() {
        final Number n = NumberUtils.createNumber("10L");
        assertTrue(n instanceof Long);
        assertEquals(10L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatTypeSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleTypeSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberHexInteger() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    public void testCreateNumberHexTooBigForIntBecomesLong() {
        final Number n = NumberUtils.createNumber("0x80000000");
        assertTrue(n instanceof Long);
        assertEquals(0x80000000L, n.longValue());
    }

    @Test
    public void testCreateNumberOctal() {
        final Number n = NumberUtils.createNumber("017");
        assertTrue(n instanceof Integer);
        assertEquals(15, n.intValue());
    }

    @Test
    public void testCreateNumberLeadingZeroInvalidOctalThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("09");
            }
        });
    }

    @Test
    public void testCreateNumberMalformedThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.2.3");
            }
        });
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("--1");
            }
        });
    }

    @Test
    public void testCreateNumberDecimal() {
        final Number n = NumberUtils.createNumber("3.14");
        assertEquals(3.14d, n.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumberIntegerOverflowPromotesToLong() {
        final Number tooBigForInt = NumberUtils.createNumber(String.valueOf((long) Integer.MAX_VALUE + 1));
        assertTrue(tooBigForInt instanceof Long);
        final Number fitsInInt = NumberUtils.createNumber(String.valueOf(Integer.MAX_VALUE));
        assertTrue(fitsInInt instanceof Integer);
        final Number minFitsInInt = NumberUtils.createNumber(String.valueOf(Integer.MIN_VALUE));
        assertTrue(minFitsInInt instanceof Integer);
        final Number tooSmallForInt = NumberUtils.createNumber(String.valueOf((long) Integer.MIN_VALUE - 1));
        assertTrue(tooSmallForInt instanceof Long);
    }

    // ---- isCreatable / isNumber ----

    @Test
    public void testIsCreatableNull() {
        assertFalse(NumberUtils.isCreatable(null));
    }

    @Test
    public void testIsCreatableEmptyAndBlank() {
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
    }

    @Test
    public void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertTrue(NumberUtils.isCreatable("-123"));
    }

    @Test
    public void testIsCreatableInvalidLeadingZero() {
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    public void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("--1"));
        assertFalse(NumberUtils.isCreatable("1.2.3"));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertEquals(NumberUtils.isCreatable(null), NumberUtils.isNumber(null));
    }

    // ---- isDigits ----

    @Test
    public void testIsDigitsNullAndEmpty() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
    }

    @Test
    public void testIsDigitsValid() {
        assertTrue(NumberUtils.isDigits("12345"));
    }

    @Test
    public void testIsDigitsInvalid() {
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12a"));
    }

    // ---- isParsable ----

    @Test
    public void testIsParsableNullAndEmpty() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    public void testIsParsableValidIntegerAndDecimal() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("123.45"));
        assertTrue(NumberUtils.isParsable("1.2e5"));
    }

    @Test
    public void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("1L"));
        assertFalse(NumberUtils.isParsable("0xFF"));
    }

    @Test
    public void testIsParsableLongBoundaries() {
        assertTrue(NumberUtils.isParsable(String.valueOf(Long.MAX_VALUE)));
        assertTrue(NumberUtils.isParsable(String.valueOf(Long.MIN_VALUE)));
    }

    // ---- max/min arrays ----

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max(new byte[] {(byte) 3}));
    }

    @Test
    public void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(-1, NumberUtils.max(-5, -1, -3));
    }

    @Test
    public void testMaxIntArrayNullAndEmptyThrow() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    public void testMaxDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    public void testMaxFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(-5, NumberUtils.min(-5, -1, -3));
    }

    @Test
    public void testMinIntArrayNullAndEmptyThrow() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMinDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMinFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    // ---- 3-arg max/min ----

    @Test
    public void testMax3ArgByte() {
        assertEquals((byte) 9, NumberUtils.max((byte) 9, (byte) 2, (byte) 5));
        assertEquals((byte) 9, NumberUtils.max((byte) 2, (byte) 9, (byte) 5));
        assertEquals((byte) 9, NumberUtils.max((byte) 2, (byte) 5, (byte) 9));
    }

    @Test
    public void testMax3ArgInt() {
        assertEquals(9, NumberUtils.max(9, 2, 5));
        assertEquals(9, NumberUtils.max(2, 9, 5));
        assertEquals(9, NumberUtils.max(2, 5, 9));
    }

    @Test
    public void testMax3ArgLong() {
        assertEquals(9L, NumberUtils.max(9L, 2L, 5L));
        assertEquals(9L, NumberUtils.max(2L, 9L, 5L));
        assertEquals(9L, NumberUtils.max(2L, 5L, 9L));
    }

    @Test
    public void testMax3ArgShort() {
        assertEquals((short) 9, NumberUtils.max((short) 9, (short) 2, (short) 5));
        assertEquals((short) 9, NumberUtils.max((short) 2, (short) 9, (short) 5));
        assertEquals((short) 9, NumberUtils.max((short) 2, (short) 5, (short) 9));
    }

    @Test
    public void testMax3ArgDouble() {
        assertEquals(9.0d, NumberUtils.max(9.0d, 2.0d, 5.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(Double.NaN, 2.0d, 5.0d)));
    }

    @Test
    public void testMax3ArgFloat() {
        assertEquals(9.0f, NumberUtils.max(9.0f, 2.0f, 5.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(Float.NaN, 2.0f, 5.0f)));
    }

    @Test
    public void testMin3ArgByte() {
        assertEquals((byte) 2, NumberUtils.min((byte) 9, (byte) 2, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 2, (byte) 9, (byte) 5));
        assertEquals((byte) 2, NumberUtils.min((byte) 9, (byte) 5, (byte) 2));
    }

    @Test
    public void testMin3ArgInt() {
        assertEquals(2, NumberUtils.min(9, 2, 5));
        assertEquals(2, NumberUtils.min(2, 9, 5));
        assertEquals(2, NumberUtils.min(9, 5, 2));
    }

    @Test
    public void testMin3ArgLong() {
        assertEquals(2L, NumberUtils.min(9L, 2L, 5L));
        assertEquals(2L, NumberUtils.min(2L, 9L, 5L));
        assertEquals(2L, NumberUtils.min(9L, 5L, 2L));
    }

    @Test
    public void testMin3ArgShort() {
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 2, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 2, (short) 9, (short) 5));
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 5, (short) 2));
    }

    @Test
    public void testMin3ArgDouble() {
        assertEquals(2.0d, NumberUtils.min(9.0d, 2.0d, 5.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(Double.NaN, 2.0d, 5.0d)));
    }

    @Test
    public void testMin3ArgFloat() {
        assertEquals(2.0f, NumberUtils.min(9.0f, 2.0f, 5.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(Float.NaN, 2.0f, 5.0f)));
    }

    // ---- toByte/toShort/toInt/toLong/toDouble/toFloat ----

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("not a byte"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
    }

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("bad", (short) 9));
    }

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("bad"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("bad", 9));
    }

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("bad"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("bad", 9L));
    }

    @Test
    public void testToDouble() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("bad"), 0.0d);
    }

    @Test
    public void testToDoubleWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleFromBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("bad"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // ---- toScaledBigDecimal ----

    @Test
    public void testToScaledBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    public void testToScaledBigDecimalDefaultScaleAndRounding() {
        assertEquals(new BigDecimal("2.26"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.255")));
        assertEquals(new BigDecimal("2.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.235")));
    }

    @Test
    public void testToScaledBigDecimalCustomScaleAndRounding() {
        assertEquals(new BigDecimal("2.3"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.25"), 1, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("2.2"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.25"), 1, RoundingMode.HALF_DOWN));
    }

    @Test
    public void testToScaledBigDecimalFromDouble() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.5d)));
    }

    @Test
    public void testToScaledBigDecimalFromFloat() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.5f)));
    }

    @Test
    public void testToScaledBigDecimalFromString() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal("1.5"));
    }

    // ---- constants ----

    @Test
    public void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals(Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals(Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }
}
