/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    private interface FixtureA {
        // empty
    }

    private interface FixtureB {
        // empty
    }

    private interface FixtureC extends FixtureB {
        // empty
    }

    private static class FixtureBase implements FixtureA {
        // empty
    }

    private static class FixtureDerived extends FixtureBase implements FixtureC {
        // empty
    }

    public interface PublicIface {
        void foo();
    }

    private static class PublicIfaceImpl implements PublicIface {
        @Override
        public void foo() {
            // empty
        }
    }

    private static class Nested {
        // empty
    }

    private static class Outer {
        private static class Inner {
            // empty
        }
    }

    // --- getAbbreviatedName -------------------------------------------------

    @Test
    void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
    }

    @Test
    void testGetAbbreviatedNameClassNonPositiveLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName(String.class, -1);
            }
        });
    }

    @Test
    void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
        assertEquals("ClassUtils", ClassUtils.getAbbreviatedName("ClassUtils", 1));
    }

    // --- getAllInterfaces / getAllSuperclasses ------------------------------

    @Test
    void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfacesOrder() {
        final List<Class<?>> result = ClassUtils.getAllInterfaces(FixtureDerived.class);
        assertEquals(3, result.size());
        assertEquals(FixtureC.class, result.get(0));
        assertEquals(FixtureB.class, result.get(1));
        assertEquals(FixtureA.class, result.get(2));
    }

    @Test
    void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclassesOrder() {
        final List<Class<?>> result = ClassUtils.getAllSuperclasses(FixtureDerived.class);
        assertEquals(2, result.size());
        assertEquals(FixtureBase.class, result.get(0));
        assertEquals(Object.class, result.get(1));
    }

    // --- getCanonicalName ----------------------------------------------------

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("d", ClassUtils.getCanonicalName((Class<?>) null, "d"));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("d", ClassUtils.getCanonicalName((Object) null, "d"));
        assertEquals("java.lang.Object", ClassUtils.getCanonicalName(new Object()));
    }

    // --- getClass ------------------------------------------------------------

    @Test
    void testGetClassPrimitive() throws ClassNotFoundException {
        assertSame(int.class, ClassUtils.getClass("int"));
        assertSame(boolean.class, ClassUtils.getClass("boolean"));
    }

    @Test
    void testGetClassArrayStyles() throws ClassNotFoundException {
        assertSame(int[].class, ClassUtils.getClass("[I"));
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertSame(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertSame(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertSame(Map.Entry[].class, ClassUtils.getClass("java.util.Map.Entry[]"));
    }

    @Test
    void testGetClassNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassEmptyThrowsIllegalArgument() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("");
            }
        });
    }

    @Test
    void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("org.apache.commons.lang3.DoesNotExistReallyNotAtAll");
            }
        });
    }

    @Test
    void testGetClassTooLongNameThrowsIllegalArgument() {
        final StringBuilder sb = new StringBuilder(70000);
        for (int i = 0; i < 65536; i++) {
            sb.append('a');
        }
        final String tooLong = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(tooLong);
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensionsJavaStyleThrowsIllegalArgument() {
        final StringBuilder sb = new StringBuilder("int");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String name = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(name);
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensionsPrimitiveDescriptorThrowsIllegalArgument() {
        // "[[...I" (bare primitive array descriptor, no "L...;" wrapper) with more than
        // 255 dimensions should be rejected the same way as the "L...;" and "[]" forms are,
        // per the documented @throws IllegalArgumentException contract of getClass(String).
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append('I');
        final String name = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(name);
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensionsJvmStyleThrowsIllegalArgument() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.Object;");
        final String name = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(name);
            }
        });
    }

    // --- getComponentType ------------------------------------------------------

    @Test
    void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // --- getName ---------------------------------------------------------------

    @Test
    void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("d", ClassUtils.getName((Class<?>) null, "d"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("d", ClassUtils.getName((Object) null, "d"));
        assertEquals("java.lang.Object", ClassUtils.getName(new Object()));
    }

    // --- getPackageName / getPackageCanonicalName --------------------------------

    @Test
    void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("NoPackageHere"));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    @Test
    void testGetPackageNameObject() {
        assertEquals("d", ClassUtils.getPackageName((Object) null, "d"));
        assertEquals("java.lang", ClassUtils.getPackageName("hello", "d"));
    }

    @Test
    void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
        assertEquals("d", ClassUtils.getPackageCanonicalName((Object) null, "d"));
    }

    // --- getPublicMethod -----------------------------------------------------

    @Test
    void testGetPublicMethodFindsPublicDeclaringClass() throws Exception {
        final Method method = ClassUtils.getPublicMethod(PublicIfaceImpl.class, "foo");
        assertNotNull(method);
        assertTrue(java.lang.reflect.Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        assertEquals(PublicIface.class, method.getDeclaringClass());
    }

    @Test
    void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExist");
            }
        });
    }

    @Test
    void testGetPublicMethodNullClassThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "toString");
            }
        });
    }

    // --- getShortCanonicalName -------------------------------------------------

    @Test
    void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("d", ClassUtils.getShortCanonicalName((Object) null, "d"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
    }

    // --- getShortClassName -----------------------------------------------------

    @Test
    void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
        assertEquals("int[][]", ClassUtils.getShortClassName(int[][].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
    }

    @Test
    void testGetShortClassNameNestedStatic() {
        assertEquals("ClassUtilsAgentTest.Nested", ClassUtils.getShortClassName(Nested.class));
        assertEquals("ClassUtilsAgentTest.Outer.Inner", ClassUtils.getShortClassName(Outer.Inner.class));
    }

    @Test
    void testGetShortClassNameAnonymous() {
        final Runnable r = new Runnable() {
            @Override
            public void run() {
                // empty
            }
        };
        final String name = r.getClass().getName();
        final String afterLastDot = name.substring(name.lastIndexOf('.') + 1);
        final String expected = afterLastDot.replace('$', '.');
        assertEquals(expected, ClassUtils.getShortClassName(r.getClass()));
    }

    @Test
    void testGetShortClassNameLocal() {
        class LocalFixture {
            // empty
        }
        final LocalFixture local = new LocalFixture();
        final String name = local.getClass().getName();
        final String afterLastDot = name.substring(name.lastIndexOf('.') + 1);
        final String expected = afterLastDot.replace('$', '.');
        assertEquals(expected, ClassUtils.getShortClassName(local.getClass()));
    }

    @Test
    void testGetShortClassNameObject() {
        assertEquals("d", ClassUtils.getShortClassName((Object) null, "d"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "d"));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    // --- getSimpleName -----------------------------------------------------------

    @Test
    void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("d", ClassUtils.getSimpleName((Class<?>) null, "d"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("d", ClassUtils.getSimpleName((Object) null, "d"));
        assertEquals("Object", ClassUtils.getSimpleName(new Object()));
    }

    // --- hierarchy ---------------------------------------------------------------

    @Test
    void testHierarchyExcludeInterfaces() {
        final List<Class<?>> seen = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = ClassUtils.hierarchy(FixtureDerived.class).iterator();
        while (it.hasNext()) {
            seen.add(it.next());
        }
        assertEquals(3, seen.size());
        assertEquals(FixtureDerived.class, seen.get(0));
        assertEquals(FixtureBase.class, seen.get(1));
        assertEquals(Object.class, seen.get(2));
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final List<Class<?>> seen = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = ClassUtils.hierarchy(FixtureDerived.class, ClassUtils.Interfaces.INCLUDE).iterator();
        while (it.hasNext()) {
            seen.add(it.next());
        }
        assertEquals(6, seen.size());
        assertEquals(FixtureDerived.class, seen.get(0));
        assertEquals(FixtureC.class, seen.get(1));
        assertEquals(FixtureB.class, seen.get(2));
        assertEquals(FixtureBase.class, seen.get(3));
        assertEquals(FixtureA.class, seen.get(4));
        assertEquals(Object.class, seen.get(5));
    }

    // --- isAssignable --------------------------------------------------------------

    @Test
    void testIsAssignableNulls() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
    }

    @Test
    void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
        assertTrue(ClassUtils.isAssignable(boolean.class, boolean.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
    }

    @Test
    void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    // --- isInnerClass ----------------------------------------------------------------

    @Test
    void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(Integer.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
        assertTrue(ClassUtils.isInnerClass(Nested.class));
    }

    // --- isPrimitiveOrWrapper / isPrimitiveWrapper --------------------------------------

    @Test
    void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
    }

    // --- isPublic --------------------------------------------------------------------

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(Nested.class));
    }

    @Test
    void testIsPublicNullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    // --- primitivesToWrappers / primitiveToWrapper ------------------------------------

    @Test
    void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.primitivesToWrappers(empty));
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, (Class<?>) null);
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, null}, result);
    }

    // --- wrappersToPrimitives / wrapperToPrimitive ------------------------------------

    @Test
    void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.wrappersToPrimitives(empty));
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class);
        assertArrayEquals(new Class<?>[] {int.class, null}, result);
    }

    // --- toClass ----------------------------------------------------------------------

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        final Class<?>[] empty = ClassUtils.toClass();
        assertEquals(0, empty.length);
        final Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertArrayEquals(new Class<?>[] {String.class, Integer.class, null}, result);
    }

    // --- comparator ---------------------------------------------------------------------

    @Test
    void testComparator() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(Boolean.class);
        classes.add(Integer.class);
        Collections.sort(classes, ClassUtils.comparator());
        assertEquals(Boolean.class, classes.get(0));
        assertEquals(Integer.class, classes.get(1));
        assertEquals(String.class, classes.get(2));
    }

    // --- convertClassesToClassNames / convertClassNamesToClasses -------------------------

    @Test
    void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(null);
        final List<String> result = ClassUtils.convertClassesToClassNames(list);
        assertEquals(2, result.size());
        assertEquals("java.lang.String", result.get(0));
        assertNull(result.get(1));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void testConvertClassesToClassNamesClassCastException() {
        final List rawList = new ArrayList();
        rawList.add(Boolean.TRUE);
        final List<Class<?>> list = rawList;
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.convertClassesToClassNames(list);
            }
        });
    }

    @Test
    void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> list = new ArrayList<String>();
        list.add("java.lang.String");
        list.add("NoSuchClassReallyNotAtAll");
        list.add(null);
        final List<Class<?>> result = ClassUtils.convertClassNamesToClasses(list);
        assertEquals(3, result.size());
        assertEquals(String.class, result.get(0));
        assertNull(result.get(1));
        assertNull(result.get(2));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void testConvertClassNamesToClassesClassCastException() {
        final List rawList = new ArrayList();
        rawList.add(Boolean.TRUE);
        final List<String> list = rawList;
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.convertClassNamesToClasses(list);
            }
        });
    }

}
