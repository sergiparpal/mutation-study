/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    private ExtendedBufferedReader createTrackingBytes(final String s) {
        return new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadWithoutTrackingStaysZero() throws IOException {
        // No charset/tracking requested: bytesRead must remain 0 regardless of content.
        final ExtendedBufferedReader br = create("héllo €");
        final char[] buf = new char[20];
        final int len = br.read(buf, 0, buf.length);
        assertEquals(7, len);
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadSingleCharReadsMultiByteChars() throws IOException {
        // 'é' (e acute) is 2 bytes in UTF-8, '€' (euro sign) is 3 bytes in UTF-8.
        final ExtendedBufferedReader br = createTrackingBytes("aé€");
        assertEquals('a', br.read());
        assertEquals(1, br.getBytesRead());
        assertEquals('é', br.read());
        assertEquals(3, br.getBytesRead());
        assertEquals('€', br.read());
        assertEquals(6, br.getBytesRead());
        assertEquals(EOF, br.read());
        // EOF must not add to the byte count.
        assertEquals(6, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadSupplementaryCharacterSingleCharReads() throws IOException {
        // A single Unicode supplementary character is encoded as a high/low surrogate pair
        // and takes 4 bytes in UTF-8.
        final String input = "😀"; // 1 supplementary code point, 2 chars
        final ExtendedBufferedReader br = createTrackingBytes(input);
        assertEquals(input.charAt(0), br.read());
        // The high surrogate alone contributes 0 bytes until its pair is read.
        assertEquals(0, br.getBytesRead());
        assertEquals(input.charAt(1), br.read());
        assertEquals(4, br.getBytesRead());
        br.close();
    }

    @Test
    void testUnpairedLowSurrogateThrowsIOException() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("\udc00");
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
        br.close();
    }

    @Test
    void testUnpairedLowSurrogateInBulkReadThrowsIOException() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("\udc00abc");
        final char[] buf = new char[10];
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read(buf, 0, 4);
            }
        });
        br.close();
    }

    @Test
    void testReadZeroLengthReturnsZeroWithoutAdvancing() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        final char[] buf = new char[10];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        // The underlying stream must still be untouched.
        assertEquals('a', br.read());
        br.close();
    }

    @Test
    void testReadAtEofReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader br = create("");
        final char[] buf = new char[10];
        assertEquals(EOF, br.read(buf, 0, 5));
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testEmptyStreamLineNumberCountsFinalLineOnFirstEofRead() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertEquals(0, br.getLineNumber());
        assertEquals(EOF, br.read());
        // Reaching EOF once (without having seen any EOL) still counts as one line.
        assertEquals(1, br.getLineNumber());
        assertEquals(EOF, br.read());
        // A second EOF read must not increment the line count again.
        assertEquals(1, br.getLineNumber());
        br.close();
    }

    @Test
    void testLineNumberNotDoubleCountedAfterTrailingEol() throws IOException {
        final ExtendedBufferedReader br = create("a\n");
        assertEquals('a', br.read());
        // Mid-line: the counter (0) is not yet accurate, so getLineNumber() reports counter + 1.
        assertEquals(1, br.getLineNumber());
        assertEquals('\n', br.read());
        assertEquals(1, br.getLineNumber());
        assertEquals(EOF, br.read());
        // EOF right after an EOL must not add an extra line.
        assertEquals(1, br.getLineNumber());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreFullState() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("ab\ncd");
        assertEquals('a', br.read());
        assertEquals('b', br.read());
        br.mark(16);
        final long markedPosition = br.getPosition();
        final long markedLine = br.getLineNumber();
        final long markedBytes = br.getBytesRead();
        final int markedLastChar = br.getLastChar();

        assertEquals('\n', br.read());
        assertEquals('c', br.read());
        // Mid-line after the newline: counter is 1, but we're already into line 2.
        assertEquals(2, br.getLineNumber());
        assertTrue(br.getPosition() > markedPosition);

        br.reset();
        assertEquals(markedPosition, br.getPosition());
        assertEquals(markedLine, br.getLineNumber());
        assertEquals(markedBytes, br.getBytesRead());
        assertEquals(markedLastChar, br.getLastChar());

        // Reading again after reset must replay the same characters.
        assertEquals('\n', br.read());
        assertEquals('c', br.read());
        assertEquals('d', br.read());
        assertEquals(EOF, br.read());
        br.close();
    }

    @Test
    void testMarkSupported() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertTrue(br.markSupported());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals('a', br.read());
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testPeekDoesNotAdvancePositionOrLastChar() throws IOException {
        final ExtendedBufferedReader br = create("xy");
        assertEquals('x', br.peek());
        assertEquals('x', br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getPosition());
        assertEquals('x', br.read());
        assertEquals(1, br.getPosition());
        br.close();
    }

    @Test
    void testReadLineWithOnlyCarriageReturn() throws IOException {
        final ExtendedBufferedReader br = create("foo\rbar");
        assertEquals("foo", br.readLine());
        assertEquals(1, br.getLineNumber());
        assertEquals("bar", br.readLine());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testReadLineAtExactEof() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals("abc", br.readLine());
        assertNull(br.readLine());
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadBulkPartialFillAtEof() throws IOException {
        final ExtendedBufferedReader br = create("ab");
        final char[] buf = new char[5];
        final int len = br.read(buf, 0, 5);
        assertEquals(2, len);
        assertEquals('a', buf[0]);
        assertEquals('b', buf[1]);
        assertEquals('b', br.getLastChar());
        assertEquals(2, br.getPosition());
        assertEquals(EOF, br.read(buf, 0, 5));
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadBulkIntoOffsetPreservesUntouchedRegion() throws IOException {
        final char[] buf = new char[] { 'Z', 'Z', 'Z', 'Z' };
        final ExtendedBufferedReader br = create("ab");
        final int len = br.read(buf, 1, 2);
        assertEquals(2, len);
        assertArrayEquals(new char[] { 'Z', 'a', 'b', 'Z' }, buf);
        br.close();
    }

    @Test
    void testGetLastCharAfterEachReadMode() throws IOException {
        final ExtendedBufferedReader br = create("a\r\nb");
        assertEquals('a', br.read());
        assertEquals('a', br.getLastChar());
        assertEquals('\r', br.read());
        assertEquals('\r', br.getLastChar());
        assertEquals('\n', br.read());
        // CR immediately followed by LF counts as a single line terminator.
        assertEquals(1, br.getLineNumber());
        assertEquals('\n', br.getLastChar());
        assertEquals('b', br.read());
        assertEquals('b', br.getLastChar());
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testBulkReadTracksLineNumberAcrossCrLfSplitBetweenCalls() throws IOException {
        // "\r" ends one read() call and "\n" begins the next: it must not be double-counted.
        final char[] first = new char[2];
        final char[] second = new char[2];
        final ExtendedBufferedReader br = create("a\r\nb");
        assertEquals(2, br.read(first, 0, 2));
        assertEquals(1, br.getLineNumber());
        assertEquals(2, br.read(second, 0, 2));
        assertEquals(2, br.getLineNumber());
        br.close();
    }
}
