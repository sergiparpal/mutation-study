/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MemberUtils}.
 */
public class MemberUtilsAgentTest {

    /** Package-private declaring class, used to exercise the accessibility workaround. */
    static class PackagePrivateHelper {
        public PackagePrivateHelper() {
        }

        public void publicMethod() {
        }
    }

    public static class Sample {
        public Sample() {
        }

        public Sample(final String s) {
        }

        public Sample(final Object o, final String... extra) {
        }

        public void overload(final Integer n) {
        }

        public void overload(final Number n) {
        }

        public void publicMethod() {
        }

        public static void staticMethod() {
        }

        public void twoArgMethod(final Number n, final CharSequence c) {
        }

        public void varArgsMethod(final String s, final Integer... nums) {
        }

        void packageMethod() {
        }

        @SuppressWarnings("unused")
        private void privateMethod() {
        }
    }

    @Test
    public void testIsPublic() throws Exception {
        assertTrue(MemberUtils.isPublic(Sample.class.getMethod("publicMethod")));
        assertFalse(MemberUtils.isPublic(Sample.class.getDeclaredMethod("packageMethod")));
        assertFalse(MemberUtils.isPublic(Sample.class.getDeclaredMethod("privateMethod")));
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    public void testIsStatic() throws Exception {
        assertTrue(MemberUtils.isStatic(Sample.class.getMethod("staticMethod")));
        assertFalse(MemberUtils.isStatic(Sample.class.getMethod("publicMethod")));
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    public void testIsAccessible() throws Exception {
        assertTrue(MemberUtils.isAccessible(Sample.class.getMethod("publicMethod")));
        assertFalse(MemberUtils.isAccessible(Sample.class.getDeclaredMethod("packageMethod")));
        assertFalse(MemberUtils.isAccessible(Sample.class.getDeclaredMethod("privateMethod")));
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    public void testIsPackage() {
        assertTrue(MemberUtils.isPackage(0));
        assertTrue(MemberUtils.isPackage(Modifier.STATIC | Modifier.FINAL));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    public void testIsMatchingConstructorExact() throws Exception {
        final Constructor<?> ctor = Sample.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {String.class}));
        assertFalse(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {Integer.class}));
        assertFalse(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {String.class, String.class}));
    }

    @Test
    public void testIsMatchingConstructorNullParameterTypes() throws Exception {
        final Constructor<?> ctor = Sample.class.getConstructor();
        assertTrue(MemberUtils.isMatchingConstructor(ctor, null));
    }

    @Test
    public void testIsMatchingConstructorVarArgs() throws Exception {
        final Constructor<?> ctor = Sample.class.getConstructor(Object.class, String[].class);
        assertTrue(ctor.isVarArgs());
        assertTrue(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {Object.class}));
        assertTrue(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {Object.class, String.class}));
        assertTrue(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {Object.class, String.class, String.class}));
        assertFalse(MemberUtils.isMatchingConstructor(ctor, new Class<?>[] {Object.class, Integer.class}));
    }

    @Test
    public void testIsMatchingMethod() throws Exception {
        final Method m = Sample.class.getMethod("twoArgMethod", Number.class, CharSequence.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {Integer.class, String.class}));
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] {Integer.class}));
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] {Object.class, String.class}));
    }

    @Test
    public void testIsMatchingMethodNullParameterTypes() throws Exception {
        final Method m = Sample.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isMatchingMethod(m, null));
    }

    @Test
    public void testIsMatchingMethodVarArgs() throws Exception {
        final Method m = Sample.class.getMethod("varArgsMethod", String.class, Integer[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class}));
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class, Integer.class, Integer.class}));
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class, String.class}));
    }

    @Test
    public void testCompareConstructorFit() throws Exception {
        final Constructor<?> exact = Sample.class.getConstructor(String.class);
        final Constructor<?> varArgs = Sample.class.getConstructor(Object.class, String[].class);
        final Class<?>[] actual = {String.class};
        assertTrue(MemberUtils.compareConstructorFit(exact, varArgs, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(varArgs, exact, actual) > 0);
        assertEquals(0, MemberUtils.compareConstructorFit(exact, exact, actual));
    }

    @Test
    public void testCompareMethodFit() throws Exception {
        final Method narrow = Sample.class.getMethod("overload", Integer.class);
        final Method wide = Sample.class.getMethod("overload", Number.class);
        final Class<?>[] actual = {Integer.class};
        assertTrue(MemberUtils.compareMethodFit(narrow, wide, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(wide, narrow, actual) > 0);
        assertEquals(0, MemberUtils.compareMethodFit(narrow, narrow, actual));
    }

    @Test
    public void testSetAccessibleWorkaroundNonPublicMemberUnchanged() throws Exception {
        final Method m = Sample.class.getDeclaredMethod("privateMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertFalse(m.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundNull() {
        assertNull(MemberUtils.setAccessibleWorkaround(null));
    }

    @Test
    public void testSetAccessibleWorkaroundOnPackagePrivateDeclaringClass() throws Exception {
        final Method m = PackagePrivateHelper.class.getMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(m.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundPublicClassUnchanged() throws Exception {
        final Method m = Sample.class.getMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertFalse(m.isAccessible());
    }
}
