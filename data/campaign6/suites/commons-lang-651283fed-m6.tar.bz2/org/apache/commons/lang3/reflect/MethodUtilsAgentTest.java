/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @interface MarkerAnnotation {
    }

    public interface Greeter {
        String greet(String name);
    }

    static class PackagePrivateImpl implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hello, " + name;
        }

        public String packageOnly() {
            return "pkg";
        }
    }

    public static class Sample {
        public String noArgMethod() {
            return "noarg";
        }

        public String instanceMethod(final String s) {
            return "instance:" + s;
        }

        public String overload(final Integer n) {
            return "Integer:" + n;
        }

        public String overload(final Number n) {
            return "Number:" + n;
        }

        public static String staticMethod(final String s) {
            return "static:" + s;
        }

        public String throwingMethod() {
            throw new IllegalStateException("boom");
        }

        public String varArgsMethod(final String s, final Integer... nums) {
            return s + ":" + nums.length;
        }

        @MarkerAnnotation
        public void annotatedMethod() {
        }

        void packageMethod() {
        }

        private String privateMethod(final String s) {
            return "private:" + s;
        }
    }

    public static class SampleChild extends Sample {
        @Override
        public String instanceMethod(final String s) {
            return "child-instance:" + s;
        }
    }

    @Test
    public void testGetAccessibleMethodClassAndMethod() throws Exception {
        final Method raw = PackagePrivateImpl.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, raw);
        assertNotNull(accessible);
        assertEquals(Greeter.class, accessible.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethodNonPublicMethodReturnsNull() throws Exception {
        final Method priv = Sample.class.getDeclaredMethod("privateMethod", String.class);
        assertNull(MethodUtils.getAccessibleMethod(Sample.class, priv));
    }

    @Test
    public void testGetAccessibleMethodByNameAndParams() {
        final Method m = MethodUtils.getAccessibleMethod(Sample.class, "instanceMethod", String.class);
        assertNotNull(m);
        assertEquals(Sample.class, m.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethodByNameAndParamsNoSuchMethod() {
        assertNull(MethodUtils.getAccessibleMethod(Sample.class, "noSuchMethod"));
    }

    @Test
    public void testGetAccessibleMethodFromMethodNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "overload", Integer.class);
        assertNotNull(m);
        assertEquals(Integer.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodAssignable() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "overload", Double.class);
        assertNotNull(m);
        assertEquals(Number.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "varArgsMethod", String.class, Integer.class, Integer.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Sample.class, "noSuchMethod"));
    }

    @Test
    public void testGetMatchingMethodExactPrivate() throws Exception {
        final Method m = MethodUtils.getMatchingMethod(Sample.class, "privateMethod", String.class);
        assertNotNull(m);
        assertEquals(Sample.class, m.getDeclaringClass());
    }

    @Test
    public void testGetMatchingMethodNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "x");
            }
        });
    }

    @Test
    public void testGetMatchingMethodEmptyName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Sample.class, "");
            }
        });
    }

    @Test
    public void testGetMethodObject() {
        final Method m = MethodUtils.getMethodObject(Sample.class, "instanceMethod", String.class);
        assertNotNull(m);
        assertNull(MethodUtils.getMethodObject(Sample.class, "noSuchMethod"));
        assertNull(MethodUtils.getMethodObject(null, "instanceMethod"));
        assertNull(MethodUtils.getMethodObject(Sample.class, null));
    }

    @Test
    public void testGetMethodsListWithAnnotation() {
        final List<Method> list = MethodUtils.getMethodsListWithAnnotation(Sample.class, MarkerAnnotation.class);
        assertEquals(1, list.size());
        assertEquals("annotatedMethod", list.get(0).getName());
    }

    @Test
    public void testGetMethodsWithAnnotation() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Sample.class, MarkerAnnotation.class);
        assertEquals(1, methods.length);
        assertEquals("annotatedMethod", methods[0].getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationNullArgs() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, MarkerAnnotation.class);
            }
        });
    }

    @Test
    public void testGetOverrideHierarchy() throws Exception {
        final Method childMethod = SampleChild.class.getMethod("instanceMethod", String.class);
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(childMethod, ClassUtils.Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        final Iterator<Method> it = hierarchy.iterator();
        assertEquals(SampleChild.class, it.next().getDeclaringClass());
        assertEquals(Sample.class, it.next().getDeclaringClass());
    }

    @Test
    public void testGetOverrideHierarchyNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, ClassUtils.Interfaces.EXCLUDE);
            }
        });
    }

    @Test
    public void testGetAnnotationDirect() throws Exception {
        final Method m = Sample.class.getMethod("annotatedMethod");
        final MarkerAnnotation annotation = MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationAbsent() throws Exception {
        final Method m = Sample.class.getMethod("noArgMethod");
        assertNull(MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false));
    }

    @Test
    public void testGetAnnotationNullMethod() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, MarkerAnnotation.class, false, false);
            }
        });
    }

    @Test
    public void testInvokeExactMethodNoArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Sample(), "noArgMethod");
        assertEquals("noarg", result);
    }

    @Test
    public void testInvokeExactMethodWithArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Sample(), "instanceMethod", "x");
        assertEquals("instance:x", result);
    }

    @Test
    public void testInvokeExactMethodExplicitParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Sample(), "instanceMethod", new Object[] {"y"}, new Class<?>[] {String.class});
        assertEquals("instance:y", result);
    }

    @Test
    public void testInvokeExactMethodNoSuchMethod() {
        final Sample sample = new Sample();
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(sample, "overload", Short.valueOf((short) 1));
            }
        });
    }

    @Test
    public void testInvokeExactMethodNullObject() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(null, "noArgMethod");
            }
        });
    }

    @Test
    public void testInvokeExactMethodThrowsWraps() {
        final Sample sample = new Sample();
        final InvocationTargetException ite = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(sample, "throwingMethod");
            }
        });
        assertTrue(ite.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Sample.class, "staticMethod", "z");
        assertEquals("static:z", result);
    }

    @Test
    public void testInvokeExactStaticMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(Sample.class, "staticMethod", Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), false, "noArgMethod");
        assertEquals("noarg", result);
    }

    @Test
    public void testInvokeMethodVarArgsMultiple() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "varArgsMethod", "s", Integer.valueOf(1), Integer.valueOf(2));
        assertEquals("s:2", result);
    }

    @Test
    public void testInvokeMethodVarArgsNoneProvided() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "varArgsMethod", "s");
        assertEquals("s:0", result);
    }

    @Test
    public void testInvokeMethodForceAccessPrivate() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), true, "privateMethod", "p");
        assertEquals("private:p", result);
    }

    @Test
    public void testInvokeMethodNoForceAccessPrivateFails() {
        final Sample sample = new Sample();
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(sample, false, "privateMethod", "p");
            }
        });
    }

    @Test
    public void testInvokeMethodNullObject() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "noArgMethod");
            }
        });
    }

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Sample.class, "staticMethod", "w");
        assertEquals("static:w", result);
    }

    @Test
    public void testInvokeStaticMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Sample.class, "noSuchStatic");
            }
        });
    }

    @Test
    public void testMethodUtilsInstanceConstructible() {
        // Deprecated but public; exists only so bean-style tools can create an instance.
        assertNotNull(new MethodUtils());
    }
}
