/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ConstructorUtils}.
 */
public class ConstructorUtilsAgentTest {

    public static class PublicClass {
        public final String value;
        public final int number;

        public PublicClass() {
            this.value = "default";
            this.number = 0;
        }

        public PublicClass(final String value) {
            this.value = value;
            this.number = 0;
        }

        public PublicClass(final String value, final int number) {
            this.value = value;
            this.number = number;
        }

        public PublicClass(final Object value, final String... extra) {
            this.value = String.valueOf(value) + extra.length;
            this.number = 0;
        }
    }

    public abstract static class AbstractClass {
        public AbstractClass() {
        }
    }

    public static class ThrowingClass {
        public ThrowingClass() {
            throw new IllegalStateException("boom");
        }
    }

    static class PackagePrivateClass {
        public PackagePrivateClass() {
        }
    }

    @Test
    public void testGetAccessibleConstructorByTypes() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getAccessibleConstructor(PublicClass.class, String.class);
        assertNotNull(ctor);
        assertEquals(1, ctor.getParameterTypes().length);
    }

    @Test
    public void testGetAccessibleConstructorNoSuchConstructor() {
        assertNull(ConstructorUtils.getAccessibleConstructor(PublicClass.class, java.util.Date.class));
    }

    @Test
    public void testGetAccessibleConstructorOnPackagePrivateClass() {
        assertNull(ConstructorUtils.getAccessibleConstructor(PackagePrivateClass.class));
    }

    @Test
    public void testGetAccessibleConstructorNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getAccessibleConstructor((Class<?>) null);
            }
        });
    }

    @Test
    public void testGetAccessibleConstructorFromConstructor() throws Exception {
        final Constructor<PublicClass> raw = PublicClass.class.getConstructor();
        final Constructor<PublicClass> accessible = ConstructorUtils.getAccessibleConstructor(raw);
        assertNotNull(accessible);
        assertEquals(raw, accessible);
    }

    @Test
    public void testGetAccessibleConstructorFromConstructorNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getAccessibleConstructor((Constructor<?>) null);
            }
        });
    }

    @Test
    public void testGetMatchingAccessibleConstructorExact() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, String.class, Integer.TYPE);
        assertNotNull(ctor);
        assertEquals(2, ctor.getParameterTypes().length);
    }

    @Test
    public void testGetMatchingAccessibleConstructorAssignable() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, Integer.class);
        assertNotNull(ctor);
        // Matches the (Object) constructor by assignability, not an exact (String) match.
        assertEquals(Object.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructorVarArgs() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, Object.class, String.class, String.class);
        assertNotNull(ctor);
        assertTrue(ctor.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleConstructorNoMatch() {
        assertNull(ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, java.util.Date.class, java.util.Date.class, java.util.Date.class));
    }

    @Test
    public void testGetMatchingAccessibleConstructorNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getMatchingAccessibleConstructor(null);
            }
        });
    }

    @Test
    public void testInvokeConstructorNoArgs() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class);
        assertEquals("default", instance.value);
    }

    @Test
    public void testInvokeConstructorInferredTypes() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class, "hello", Integer.valueOf(5));
        assertEquals("hello", instance.value);
        assertEquals(5, instance.number);
    }

    @Test
    public void testInvokeConstructorNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(PublicClass.class, new Object(), new Object(), new Object());
            }
        });
    }

    @Test
    public void testInvokeConstructorAbstractClass() {
        assertThrows(InstantiationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(AbstractClass.class);
            }
        });
    }

    @Test
    public void testInvokeConstructorThrowsWraps() {
        final InvocationTargetException ite = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(ThrowingClass.class);
            }
        });
        assertTrue(ite.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testInvokeConstructorWithExplicitParameterTypes() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class, new Object[] {"a", Integer.valueOf(2)},
                new Class<?>[] {String.class, Integer.TYPE});
        assertEquals("a", instance.value);
        assertEquals(2, instance.number);
    }

    @Test
    public void testInvokeExactConstructorNoArgs() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeExactConstructor(PublicClass.class);
        assertEquals("default", instance.value);
    }

    @Test
    public void testInvokeExactConstructorExactTypes() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeExactConstructor(PublicClass.class, "x");
        assertEquals("x", instance.value);
    }

    @Test
    public void testInvokeExactConstructorNoWidening() {
        // An exact-match search for (int) must fail: there is no constructor declared with a primitive int parameter alone,
        // and invokeExactConstructor does not perform assignment-compatible widening like invokeConstructor does.
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(PublicClass.class, new Object[] {"a", Integer.valueOf(1)}, new Class<?>[] {String.class, Long.TYPE});
            }
        });
    }

    @Test
    public void testInvokeExactConstructorThrowsWraps() {
        final InvocationTargetException ite = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(ThrowingClass.class);
            }
        });
        assertTrue(ite.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testConstructorUtilsInstanceConstructible() {
        // Deprecated but public; exists only so bean-style tools can create an instance.
        assertNotNull(new ConstructorUtils());
    }
}
