/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    @Test
    void testConstructorIsPublic() {
        assertNotNull(new LocaleUtils());
        final Constructor<?>[] cons = LocaleUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(LocaleUtils.class.getModifiers()));
    }

    @Test
    void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        // Must be sorted by toString()
        for (int i = 1; i < list.size(); i++) {
            assertTrue(list.get(i - 1).toString().compareTo(list.get(i).toString()) <= 0,
                    "list must be sorted: " + list.get(i - 1) + " vs " + list.get(i));
        }
        // Must be unmodifiable
        try {
            list.add(Locale.CANADA);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // ok
        }
        // Calling again must return the same (cached) instance
        assertSame(list, LocaleUtils.availableLocaleList());
    }

    @Test
    void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
        assertEquals(LocaleUtils.availableLocaleList().size(), set.size());
        try {
            set.add(Locale.CANADA);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // ok
        }
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "XX", "made-up-variant-zzz")));
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    @Test
    void testCountriesByLanguageNull() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguage() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("zh");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (int i = 0; i < list.size(); i++) {
            final Locale locale = list.get(i);
            assertEquals("zh", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty(), "expected a country for " + locale);
            assertTrue(locale.getVariant().isEmpty(), "expected no variant for " + locale);
        }
        // cached result should be the exact same unmodifiable instance
        assertSame(list, LocaleUtils.countriesByLanguage("zh"));
        try {
            list.add(Locale.US);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // ok
        }
    }

    @Test
    void testLanguagesByCountryNull() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountry() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (int i = 0; i < list.size(); i++) {
            final Locale locale = list.get(i);
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty(), "expected no variant for " + locale);
        }
        try {
            list.add(Locale.US);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // ok
        }
    }

    @Test
    void testLocaleLookupListSingleArgNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListTwoArgNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null, Locale.US);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListFullySpecified() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(locale, list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    void testLocaleLookupListWithDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final Locale defaultLocale = Locale.ENGLISH;
        final List<Locale> list = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertEquals(4, list.size());
        assertEquals(locale, list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(defaultLocale, list.get(3));
    }

    @Test
    void testLocaleLookupListNoDuplicate() {
        final Locale locale = new Locale("fr");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, locale);
        assertEquals(1, list.size());
        assertEquals(locale, list.get(0));
    }

    @Test
    void testLocaleLookupListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.US);
        try {
            list.add(Locale.CANADA);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // ok
        }
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("fr", "CA")));
    }

    @Test
    void testToLocaleFromLocale() {
        assertSame(Locale.US, LocaleUtils.toLocale(Locale.US));
        assertSame(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en", ""), LocaleUtils.toLocale("en"));
    }

    @Test
    void testToLocaleStringUnderscoreSeparator() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    void testToLocaleStringDashSeparator() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    void testToLocaleStringNumericArea() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    void testToLocaleStringWithVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    void testToLocaleStringCountryOnlyNoPrefix() {
        // "US" is a known ISO-3166 country code, so it parses as a country-only locale
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    void testToLocaleStringCountryOnlyWithUnderscorePrefix() {
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("_GB"));
    }

    @Test
    void testToLocaleStringUnderscorePrefixWithVariant() {
        assertEquals(new Locale("", "GB", "abc"), LocaleUtils.toLocale("_GB_abc"));
    }

    @Test
    void testToLocaleStringTooShort() {
        try {
            LocaleUtils.toLocale("a");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringUnderscorePrefixTooShort() {
        try {
            LocaleUtils.toLocale("_G");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringUnderscorePrefixLowerCase() {
        try {
            LocaleUtils.toLocale("_gb");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringUnderscorePrefixBadSeparator() {
        try {
            // Length 6, but character at index 3 is not the same separator as index 0
            LocaleUtils.toLocale("_GBabc");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringLowerCaseCountry() {
        try {
            // Country must be uppercase per the documented contract
            LocaleUtils.toLocale("en_gb");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringEmptyVariant() {
        try {
            LocaleUtils.toLocale("en_GB_");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringWithHash() {
        try {
            LocaleUtils.toLocale("en#GB");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringInvalidThreeLetterCode() {
        try {
            // Not lowercase (so not a language code), not a known ISO country, not numeric
            LocaleUtils.toLocale("ENG");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    @Test
    void testToLocaleStringUppercaseLanguageWithNumericCountryMustBeRejected() {
        // The documented contract requires the language code to be lowercase.
        // "ZZ" is not a valid (lowercase) language code, so this must be rejected
        // even though "001" is a valid numeric area code.
        try {
            final Locale result = LocaleUtils.toLocale("ZZ_001");
            fail("Expected IllegalArgumentException but got: " + result);
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }
}
