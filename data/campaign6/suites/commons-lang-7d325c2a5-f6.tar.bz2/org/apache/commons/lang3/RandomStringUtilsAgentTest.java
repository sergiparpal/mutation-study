/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    private static void assertAllCharsMatch(final String s, final CharPredicate predicate) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(predicate.test(c), "Unexpected character '" + c + "' (" + (int) c + ") in: " + s);
        }
    }

    private interface CharPredicate {
        boolean test(char c);
    }

    // ----- Singletons -----

    @Test
    void testSecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testInsecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSecureStrongSingleton() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertSame(a, b);
    }

    @Test
    void testSecureAndInsecureAreDistinctInstances() {
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.insecure());
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.secureStrong());
    }

    @Test
    void testDeprecatedNoArgConstructorStillUsable() {
        final RandomStringUtils instance = new RandomStringUtils();
        final String s = instance.next(5);
        assertEquals(5, s.length());
    }

    @Test
    void testToStringContainsClassName() {
        final String s = RandomStringUtils.secure().toString();
        assertTrue(s.startsWith("RandomStringUtils ["), s);
    }

    // ----- count == 0 / count < 0 boundaries -----

    @Test
    void testRandomCountZeroReturnsEmptyString() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    void testRandomNegativeCountThrowsOnAllOverloads() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, true, true);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 'a', 'b', 'c');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, "abc");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true, 'a', 'b');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-1);
            }
        });
    }

    private interface Executable {
        void execute();
    }

    private static void assertThrows(final Class<? extends Throwable> expectedType, final Executable runnable) {
        try {
            runnable.execute();
        } catch (final Throwable t) {
            if (expectedType.isInstance(t)) {
                return;
            }
            throw new AssertionError("Expected " + expectedType.getName() + " but got " + t.getClass().getName(), t);
        }
        throw new AssertionError("Expected " + expectedType.getName() + " to be thrown, but nothing was thrown");
    }

    // ----- Basic length / content for the deprecated static facade -----

    @Test
    void testRandomCountReturnsRequestedLength() {
        final String s = RandomStringUtils.random(5);
        assertEquals(5, s.length());
    }

    @Test
    void testRandomLettersAndNumbersOnlyContainsAlphanumerics() {
        final String s = RandomStringUtils.random(200, true, true);
        assertEquals(200, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c) && c < 128;
            }
        });
    }

    @Test
    void testRandomWithCharsArrayRestrictsCharacterSet() {
        final String s = RandomStringUtils.random(20, 'x');
        assertEquals(20, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'x';
            }
        });
    }

    @Test
    void testRandomWithNullCharsArrayUsesFullCharacterSet() {
        final String s = RandomStringUtils.random(5, (char[]) null);
        assertEquals(5, s.length());
    }

    @Test
    void testRandomWithEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, new char[0]);
            }
        });
    }

    @Test
    void testRandomWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @Test
    void testRandomWithNullStringCharsUsesFullCharacterSet() {
        final String s = RandomStringUtils.random(5, (String) null);
        assertEquals(5, s.length());
    }

    @Test
    void testRandomWithStringCharsRestrictsCharacterSet() {
        final String s = RandomStringUtils.random(30, "Z");
        assertEquals(30, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'Z';
            }
        });
    }

    // ----- Documented throws contract on the core 7-arg random() method -----

    @Test
    void testRandomCountZeroWithEmptyCharsArrayShouldThrowPerJavadoc() {
        // Javadoc: "@throws IllegalArgumentException Thrown if count < 0 or the provided chars
        // array is empty." This is not conditioned on count being positive, so an empty chars
        // array should be rejected even when count == 0.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(0, 0, 0, false, false, new char[0], new Random(1));
            }
        });
    }

    @Test
    void testRandomRangeEndLessThanStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false, null, new Random(1));
            }
        });
    }

    @Test
    void testRandomRangeEndEqualToStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 10, false, false, null, new Random(1));
            }
        });
    }

    @Test
    void testRandomRangeNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false, null, new Random(1));
            }
        });
    }

    @Test
    void testRandomRangeCharsStartTooLargeThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 5, 6, false, false, chars, new Random(1));
            }
        });
    }

    @Test
    void testRandomRangeCharsEndTooLargeThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 10, false, false, chars, new Random(1));
            }
        });
    }

    @Test
    void testRandomRangeCharsSubsetIsRespected() {
        final char[] chars = "abcdef".toCharArray();
        final String s = RandomStringUtils.random(50, 2, 5, false, false, chars, new Random(42));
        assertEquals(50, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'c' || c == 'd' || c == 'e';
            }
        });
    }

    @Test
    void testRandomDigitsRequestedButNoneReachableThrows() {
        // Range [1,5) contains no digit characters, so a digits-only request cannot be honored.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, 5, false, true, null, new Random(1));
            }
        });
    }

    @Test
    void testRandomLettersRequestedButNoneReachableThrows() {
        // Range [48,57) ('0'-'8') contains no letter characters.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 48, 57, true, false, null, new Random(1));
            }
        });
    }

    @Test
    void testRandomCharsArrayWithoutRequestedCategoryThrows() {
        final char[] digitsOnly = { '1', '2', '3' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 3, true, false, digitsOnly, new Random(1));
            }
        });
    }

    @Test
    void testRandomCharsArraySymbolsOnlyWithLettersAndDigitsThrows() {
        final char[] symbols = "!@#$%".toCharArray();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 5, true, true, symbols, new Random(1));
            }
        });
    }

    @Test
    void testRandomDigitsClampedToAsciiDigitsRange() {
        // start=0, end=58 ('9'+1): digits-only generation should be clamped to '0'-'9'.
        final String s = RandomStringUtils.random(100, 0, 58, false, true, null, new Random(7));
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testRandomLettersAndDigitsAboveAsciiOptimizationThreshold() {
        // end=128 is just above the ASCII optimization cutoff (0x7f), so the alphanumeric
        // shortcut does not trigger, but filtering by letters||digits must still hold.
        final String s = RandomStringUtils.random(40, 0, 128, true, true, null, new Random(3));
        assertEquals(40, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c);
            }
        });
    }

    @Test
    void testRandomRejectionLimitThrowsInsteadOfLoopingForever() {
        // [0xD800, 0xD800+10) is entirely within the surrogate range, so every generated code
        // point is rejected; this must raise an IllegalArgumentException rather than hang.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0xD800, 0xD800 + 10, false, false, null, new Random(1));
            }
        });
    }

    @Test
    void testRandomWithFixedSeedIsRepeatable() {
        final String first = RandomStringUtils.random(100, 0, 0, true, true, null, new Random(123456789L));
        final String second = RandomStringUtils.random(100, 0, 0, true, true, null, new Random(123456789L));
        assertEquals(first, second);
    }

    @Test
    void testRandomFullUnicodeRangeKeepsSurrogatePairsIntact() {
        final String s = RandomStringUtils.random(80, 0, 0, false, false, null, new Random(99));
        assertEquals(80, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (Character.isHighSurrogate(c)) {
                assertTrue(i + 1 < s.length(), "High surrogate at end of string");
                assertTrue(Character.isLowSurrogate(s.charAt(i + 1)), "High surrogate not followed by low surrogate");
            } else if (Character.isLowSurrogate(c)) {
                assertTrue(i > 0, "Low surrogate at start of string");
                assertTrue(Character.isHighSurrogate(s.charAt(i - 1)), "Low surrogate not preceded by high surrogate");
            }
        }
    }

    // ----- Instance methods via secure()/insecure() -----

    @Test
    void testNextCountReturnsRequestedLength() {
        final String s = RandomStringUtils.insecure().next(37);
        assertEquals(37, s.length());
    }

    @Test
    void testNextWithEmptyCharArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, new char[0]);
            }
        });
    }

    @Test
    void testNextWithEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, "");
            }
        });
    }

    @Test
    void testNextRangeStartBeyondCharsLengthThrows() {
        final char[] chars = { 'a', 'b' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, 2, 3, false, false, chars);
            }
        });
    }

    @Test
    void testNextAlphabeticOnlyContainsLetters() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(150);
        assertEquals(150, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c);
            }
        });
    }

    @Test
    void testNextAlphabeticRangeLengthWithinBounds() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextAlphabetic(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8, "length=" + s.length());
        }
    }

    @Test
    void testNextAlphabeticRangeMinEqualsMaxReturnsExactLength() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(5, 5);
        assertEquals(5, s.length());
    }

    @Test
    void testNextAlphabeticRangeMinGreaterThanMaxThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAlphabetic(5, 3);
            }
        });
    }

    @Test
    void testNextAlphanumericOnlyContainsLettersOrDigits() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(150);
        assertEquals(150, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c) && c < 128;
            }
        });
    }

    @Test
    void testNextAlphanumericRangeLengthWithinBounds() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextAlphanumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8, "length=" + s.length());
        }
    }

    @Test
    void testNextAsciiOnlyContainsPrintableAsciiInRange() {
        final String s = RandomStringUtils.insecure().nextAscii(150);
        assertEquals(150, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testNextGraphExcludesSpace() {
        final String s = RandomStringUtils.insecure().nextGraph(200);
        assertEquals(200, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 33 && c <= 126;
            }
        });
    }

    @Test
    void testNextNumericOnlyContainsDigits() {
        final String s = RandomStringUtils.insecure().nextNumeric(150);
        assertEquals(150, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testNextNumericRangeMinGreaterThanMaxThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextNumeric(10, 2);
            }
        });
    }

    @Test
    void testNextPrintIncludesSpaceRange() {
        final String s = RandomStringUtils.insecure().nextPrint(200);
        assertEquals(200, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testNextZeroCountReturnsEmptyString() {
        assertEquals("", RandomStringUtils.insecure().next(0));
    }

    @Test
    void testNextNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-5);
            }
        });
    }

    @Test
    void testSecureStrongNextProducesRequestedLength() {
        final String s = RandomStringUtils.secureStrong().next(5);
        assertEquals(5, s.length());
    }

    // ----- Deprecated static wrappers delegate correctly -----

    @Test
    void testDeprecatedRandomAlphabeticOnlyContainsLetters() {
        final String s = RandomStringUtils.randomAlphabetic(100);
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomAlphanumericOnlyContainsLettersOrDigits() {
        final String s = RandomStringUtils.randomAlphanumeric(100);
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c) && c < 128;
            }
        });
    }

    @Test
    void testDeprecatedRandomAsciiOnlyContainsAsciiRange() {
        final String s = RandomStringUtils.randomAscii(100);
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testDeprecatedRandomGraphExcludesSpace() {
        final String s = RandomStringUtils.randomGraph(100);
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 33 && c <= 126;
            }
        });
    }

    @Test
    void testDeprecatedRandomNumericOnlyContainsDigits() {
        final String s = RandomStringUtils.randomNumeric(100);
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomPrintIncludesSpace() {
        final String s = RandomStringUtils.randomPrint(100);
        assertEquals(100, s.length());
        assertAllCharsMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testDeprecatedRandomAlphabeticRangeMinEqualsMax() {
        final String s = RandomStringUtils.randomAlphabetic(7, 7);
        assertEquals(7, s.length());
    }

    @Test
    void testDeprecatedRandomAlphanumericRangeMinGreaterThanMaxThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphanumeric(9, 4);
            }
        });
    }

    @Test
    void testDeprecatedRandomAsciiRangeLengthWithinBounds() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAscii(3, 9);
            assertTrue(s.length() >= 3 && s.length() < 9, "length=" + s.length());
        }
    }

    @Test
    void testDeprecatedRandomGraphRangeLengthWithinBounds() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomGraph(3, 9);
            assertTrue(s.length() >= 3 && s.length() < 9, "length=" + s.length());
        }
    }

    @Test
    void testDeprecatedRandomNumericRangeLengthWithinBounds() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomNumeric(3, 9);
            assertTrue(s.length() >= 3 && s.length() < 9, "length=" + s.length());
        }
    }

    @Test
    void testDeprecatedRandomPrintRangeLengthWithinBounds() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomPrint(3, 9);
            assertTrue(s.length() >= 3 && s.length() < 9, "length=" + s.length());
        }
    }
}
