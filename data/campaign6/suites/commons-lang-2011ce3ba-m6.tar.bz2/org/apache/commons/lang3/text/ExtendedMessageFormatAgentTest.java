/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

class ExtendedMessageFormatAgentTest {

    /**
     * Simple FormatFactory that always returns a fixed upper-casing Format,
     * used to verify that the registry is consulted during pattern parsing.
     */
    private static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new Format() {
                private static final long serialVersionUID = 1L;

                @Override
                public StringBuffer format(final Object obj, final StringBuffer toAppendTo,
                        final java.text.FieldPosition pos) {
                    return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
                }

                @Override
                public Object parseObject(final String source, final java.text.ParsePosition pos) {
                    pos.setIndex(source.length());
                    return source;
                }
            };
        }
    }

    private Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testSimplePatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    void testConstructorWithLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,number}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
        final String result = emf.format(new Object[] {Double.valueOf(1234.5d)});
        assertTrue(result.contains(","), "German locale should use comma as decimal separator: " + result);
    }

    @Test
    void testCustomFormatRegistryIsUsed() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0,upper}!", registry);
        assertEquals("Hi ABC!", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testToPatternRoundTripsCustomFormat() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final String pattern = "Hi {0,upper}!";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals(pattern, emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsBackToStandardFormat() {
        final Map<String, FormatFactory> registry = upperRegistry();
        // "number" is not in the registry, so standard MessageFormat handling applies.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", registry);
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
        assertEquals("{0,number}", emf.toPattern());
    }

    @Test
    void testNullRegistryDelegatesEntirelyToSuper() {
        // without a registry, "upper" is an unknown MessageFormat type and
        // the pattern is rejected while parsing, just like java.text.MessageFormat.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper}", (Map<String, FormatFactory>) null);
            }
        });
    }

    @Test
    void testQuotedTextIsPreservedInPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("It''s {0}!");
        assertEquals("It''s {0}!", emf.toPattern());
        assertEquals("It's World!", emf.format(new Object[] {"World"}));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("Bad '{0}", upperRegistry());
            }
        });
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", upperRegistry());
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{abc}", upperRegistry());
            }
        });
    }

    @Test
    void testEqualsAndHashCodeSamePattern() {
        // java.text.MessageFormat#equals compares embedded Format instances by
        // equality, so the registry must hand out the very same Format instance
        // to each ExtendedMessageFormat for them to be considered equal.
        final Format sharedUpper = new SimpleDateFormat("yyyy", Locale.ROOT);
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new FormatFactory() {
            @Override
            public Format getFormat(final String name, final String arguments, final Locale locale) {
                return sharedUpper;
            }
        });
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("Hi {0,upper}!", registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Hi {0,upper}!", registry);
        assertTrue(emf1.equals(emf2));
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("Hi {0}!");
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Bye {0}!");
        assertFalse(emf1.equals(emf2));
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}!");
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("Hi {0}!"));
        assertTrue(emf.equals(emf));
    }

    @Test
    void testEqualsSamePatternDifferentRegistryContent() {
        final Map<String, FormatFactory> registry1 = upperRegistry();
        final Map<String, FormatFactory> registry2 = new HashMap<>();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("Hi {0}!", registry1);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Hi {0}!", registry2);
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testMultipleArgumentsWithMixedCustomAndStandardFormats() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} has {1,number} items", registry);
        final String result = emf.format(new Object[] {"cart", Integer.valueOf(3)});
        assertEquals("CART has 3 items", result);
    }

    @Test
    void testFormatDescriptionWithArguments() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("custom", new FormatFactory() {
            @Override
            public Format getFormat(final String name, final String arguments, final Locale locale) {
                assertEquals("custom", name);
                assertEquals("myArgs", arguments);
                return new Format() {
                    private static final long serialVersionUID = 1L;

                    @Override
                    public StringBuffer format(final Object obj, final StringBuffer toAppendTo,
                            final java.text.FieldPosition pos) {
                        return toAppendTo.append("[" + obj + "]");
                    }

                    @Override
                    public Object parseObject(final String source, final java.text.ParsePosition pos) {
                        pos.setIndex(source.length());
                        return source;
                    }
                };
            }
        });
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,custom,myArgs}", registry);
        assertEquals("[x]", emf.format(new Object[] {"x"}));
    }

    @Test
    void testParseDelegatesToSuper() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        final Object[] parsed = emf.parse("Hello, World!", new java.text.ParsePosition(0));
        assertNotNull(parsed);
        assertEquals(1, parsed.length);
        assertEquals("World", parsed[0]);
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[] {}));
    }
}
