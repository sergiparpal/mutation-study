/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum HeaderEnum {
        NAME, EMAIL, PHONE
    }

    @Test
    void testDefaultFormatBasics() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
    }

    @Test
    void testExcelFormat() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testMySqlFormat() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    void testTdfFormat() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testNewFormatAllFieldsAreJavaDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NotARealFormat"));
    }

    @Test
    void testBuilderRoundTripPreservesSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDelimiter(';')
                .setQuote('\'')
                .setCommentMarker('#')
                .setEscape('\\')
                .setNullString("NULL")
                .setRecordSeparator('\n')
                .setSkipHeaderRecord(true)
                .setIgnoreSurroundingSpaces(true)
                .setIgnoreHeaderCase(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .setAllowMissingColumnNames(true)
                .setAutoFlush(true)
                .setMaxRows(5L)
                .get();
        assertEquals(';', format.getDelimiter());
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals("\n", format.getRecordSeparator());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getAutoFlush());
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    void testBuilderBuildAndGetProduceEquivalentFormats() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter('|');
        final CSVFormat fromGet = builder.get();
        @SuppressWarnings("deprecation")
        final CSVFormat fromBuild = builder.build();
        assertEquals(fromGet, fromBuild);
        assertEquals('|', fromGet.getDelimiter());
    }

    @Test
    void testSetDelimiterEmptyStringThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testSetDelimiterLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\r\nb"));
    }

    @Test
    void testSetCommentMarkerLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\r'));
    }

    @Test
    void testSetEscapeLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
    }

    @Test
    void testSetQuoteLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\r'));
    }

    @Test
    void testSetDuplicateHeaderModeNullThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(NullPointerException.class, () -> builder.setDuplicateHeaderMode(null));
    }

    @Test
    void testQuoteCharacterEqualToDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testEscapeCharacterEqualToDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testCommentMarkerEqualToDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testQuoteCharacterEqualToCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('#').setQuote('#').get());
    }

    @Test
    void testEscapeCharacterEqualToCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('#').get());
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testQuoteModeNoneWithEscapeIsValid() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderNamesDisallowedThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B", "A").get());
    }

    @Test
    void testDuplicateHeaderNamesAllowAllIsValid() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("A", "B", "A").get();
        assertArrayEqualsLocal(new String[] {"A", "B", "A"}, format.getHeader());
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowEmptyIsValid() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "B", "").get();
        assertArrayEqualsLocal(new String[] {"", "B", ""}, format.getHeader());
    }

    @Test
    void testDuplicateEmptyHeaderNamesDisallowThrowsUnlessEmpty() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "B", "A").get());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final String[] original = {"a", "b"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(original).get();
        final String[] gotten = format.getHeader();
        gotten[0] = "mutated";
        assertArrayEqualsLocal(original, format.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertArrayEqualsLocal(new String[] {"NAME", "EMAIL", "PHONE"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumYieldsNullHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testWithHeaderVariants() {
        final CSVFormat withNoArgs = CSVFormat.DEFAULT.withHeader();
        assertArrayEqualsLocal(new String[0], withNoArgs.getHeader());
        final CSVFormat withNames = CSVFormat.DEFAULT.withHeader("X", "Y");
        assertArrayEqualsLocal(new String[] {"X", "Y"}, withNames.getHeader());
    }

    @Test
    void testWithDelimiterReturnsNewInstanceAndOriginalUnchanged() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter(';');
        assertEquals(';', changed.getDelimiter());
        assertEquals(',', original.getDelimiter());
        assertNotEquals(original, changed);
    }

    @Test
    void testWithQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testWithTrailingDelimiterNoArgSetsTrue() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
    }

    @Test
    void testWithTrimNoArgSetsTrue() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
    }

    @Test
    void testWithFirstRecordAsHeaderMeansEmptyHeaderAndSkip() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEqualsLocal(new String[0], format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testWithSystemRecordSeparatorMatchesLineSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final CSVFormat a = CSVFormat.DEFAULT.withDelimiter(';');
        final CSVFormat b = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, CSVFormat.DEFAULT);
        assertFalse(a.equals(null));
        assertFalse(a.equals("not a format"));
        assertTrue(a.equals(a));
    }

    @Test
    void testBuilderCopyConstructorProducesEqualFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.withDelimiter(';').withQuote('\'').withNullString("NULL");
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotEquals(original, CSVFormat.DEFAULT);
    }

    @Test
    void testToStringContainsDelimiterAndIsStable() {
        final String str = CSVFormat.DEFAULT.toString();
        assertNotNull(str);
        assertTrue(str.contains("Delimiter=<,>"));
        assertEquals(str, CSVFormat.DEFAULT.toString());
    }

    @Test
    void testToStringReflectsCommentAndNullStringSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withNullString("NULL");
        final String str = format.toString();
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testFormatProducesDelimitedStringWithoutTrailingSeparator() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    void testFormatEscapesEmbeddedQuoteAndDelimiter() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c\"d");
        assertEquals("\"a,b\",\"c\"\"d\"", formatted);
    }

    @Test
    void testFormatWithNoRecordSeparatorKeepsFullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator((String) null).get();
        final String formatted = format.format("a", "b");
        assertEquals("a,b", formatted);
    }

    @Test
    void testPrintRecordWritesValuesAndSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintNullValueUsesEmptyStringWhenNoNullStringConfigured() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueUsesConfiguredNullString() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintlnWritesOnlyRecordSeparatorByDefault() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiterPrependsDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.withTrailingDelimiter().println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testParseReturnsNonNullParser() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader("a,b\n"));
        assertNotNull(parser);
        parser.close();
    }

    @Test
    void testIsDelimiterSetHelpersReflectState() {
        assertFalse(CSVFormat.newFormat(',').isQuoteCharacterSet());
        assertFalse(CSVFormat.newFormat(',').isEscapeCharacterSet());
        assertFalse(CSVFormat.newFormat(',').isNullStringSet());
        assertFalse(CSVFormat.newFormat(',').isCommentMarkerSet());
        final CSVFormat full = CSVFormat.newFormat(',').withQuote('"').withEscape('\\').withNullString("N").withCommentMarker('#');
        assertTrue(full.isQuoteCharacterSet());
        assertTrue(full.isEscapeCharacterSet());
        assertTrue(full.isNullStringSet());
        assertTrue(full.isCommentMarkerSet());
    }

    @Test
    void testGetMaxRowsDefaultsToZeroAndNegativeIsAccepted() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(-1L).get();
        assertEquals(-1L, format.getMaxRows());
    }

    @Test
    void testGetAllowDuplicateHeaderNamesDeprecatedMirrorsDuplicateHeaderMode() {
        @SuppressWarnings("deprecation")
        final boolean allowed = CSVFormat.DEFAULT.getAllowDuplicateHeaderNames();
        assertTrue(allowed);
        @SuppressWarnings("deprecation")
        final CSVFormat withDisallow = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(false).get();
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, withDisallow.getDuplicateHeaderMode());
    }

    private static void assertArrayEqualsLocal(final String[] expected, final String[] actual) {
        assertTrue(Arrays.equals(expected, actual), "expected=" + Arrays.toString(expected) + " actual=" + Arrays.toString(actual));
    }
}
