/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    @Test
    void testAvailableLocaleListNotEmptyAndUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
        // calling again returns the same cached instance
        assertSame(list, LocaleUtils.availableLocaleList());
    }

    @Test
    void testAvailableLocaleSetNotEmptyAndUnmodifiable() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                set.add(Locale.CANADA_FRENCH);
            }
        });
        assertSame(set, LocaleUtils.availableLocaleSet());
    }

    @Test
    void testCountriesByLanguageNull() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguageUnknown() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguageValidAndCached() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("fr");
        assertNotNull(list);
        for (final Locale locale : list) {
            assertEquals("fr", locale.getLanguage());
        }
        assertSame(list, LocaleUtils.countriesByLanguage("fr"));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.FRANCE);
            }
        });
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "XX", "myVariant")));
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
    }

    @Test
    void testLanguagesByCountryNull() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryUnknown() {
        final List<Locale> list = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryValidAndCached() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
        }
        assertSame(list, LocaleUtils.languagesByCountry("US"));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    @Test
    void testLocaleLookupListNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListLanguageOnly() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr"));
        assertEquals(1, list.size());
        assertEquals(new Locale("fr"), list.get(0));
    }

    @Test
    void testLocaleLookupListLanguageAndCountry() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA"));
        assertEquals(2, list.size());
        assertEquals(new Locale("fr", "CA"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
    }

    @Test
    void testLocaleLookupListFull() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    void testLocaleLookupListWithDefault() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"), Locale.ENGLISH);
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(Locale.ENGLISH, list.get(3));
    }

    @Test
    void testLocaleLookupListUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr"));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    @Test
    void testToLocaleLocaleOverloadNull() {
        final Locale result = LocaleUtils.toLocale((Locale) null);
        assertEquals(Locale.getDefault(), result);
    }

    @Test
    void testToLocaleLocaleOverloadNonNull() {
        assertSame(Locale.CANADA_FRENCH, LocaleUtils.toLocale(Locale.CANADA_FRENCH));
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en", ""), LocaleUtils.toLocale("en"));
    }

    @Test
    void testToLocaleStringLanguageAndCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    void testToLocaleStringLanguageAndCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    void testToLocaleStringNumericArea() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    void testToLocaleStringFull() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    void testToLocaleStringCountryOnly() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    void testToLocaleStringLeadingUnderscoreCountryOnly() {
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("_GB"));
    }

    @Test
    void testToLocaleStringLeadingUnderscoreWithVariant() {
        assertEquals(new Locale("", "GB", "P"), LocaleUtils.toLocale("_GB_P"));
    }

    @Test
    void testToLocaleStringTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreLowerCase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreVariantTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBP");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreWrongSeparator() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GB-P");
            }
        });
    }

    @Test
    void testToLocaleStringInvalidLanguageCase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("EN");
            }
        });
    }

    @Test
    void testToLocaleStringInvalidCountryCase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    void testToLocaleStringUnknownFormat() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_GB_");
            }
        });
    }

    @Test
    void testToLocaleStringSpecialCaseThai() {
        assertEquals(new Locale("th", "TH", "TH"), LocaleUtils.toLocale("th_TH_TH_#u-nu-thai"));
    }

    @Test
    void testToLocaleStringSpecialCaseJapanese() {
        assertEquals(new Locale("ja", "JP", "JP"), LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese"));
    }

    @Test
    void testConstructorPublicAndDeprecated() {
        assertNotNull(new LocaleUtils());
    }
}
