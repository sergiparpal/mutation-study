/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
class TypeHandlerAgentTest {

    @Test
    void testGetDefaultReturnsSameInstance() {
        final TypeHandler first = TypeHandler.getDefault();
        final TypeHandler second = TypeHandler.getDefault();
        assertNotNull(first);
        assertSame(first, second);
    }

    @Test
    void testDefaultConstructorUsesDefaultConverterMap() {
        final TypeHandler handler = new TypeHandler();
        assertSame(Converter.NUMBER, handler.getConverter(Number.class));
        assertSame(Converter.DATE, handler.getConverter(Date.class));
        assertSame(Converter.FILE, handler.getConverter(File.class));
    }

    @Test
    void testConstructorWithNullMapThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new TypeHandler(null);
            }
        });
    }

    @Test
    void testCreateDefaultMapContainsExpectedEntries() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        assertTrue(map.containsKey(Object.class));
        assertTrue(map.containsKey(Class.class));
        assertTrue(map.containsKey(Date.class));
        assertTrue(map.containsKey(File.class));
        assertTrue(map.containsKey(Number.class));
        assertTrue(map.containsKey(URL.class));
        assertTrue(map.containsKey(Long.class));
        assertTrue(map.containsKey(Integer.class));
        assertTrue(map.containsKey(Short.class));
        assertTrue(map.containsKey(Byte.class));
        assertTrue(map.containsKey(Character.class));
        assertTrue(map.containsKey(Double.class));
        assertTrue(map.containsKey(Float.class));
        assertTrue(map.containsKey(BigInteger.class));
        assertTrue(map.containsKey(BigDecimal.class));
        assertEquals(17, map.size());
    }

    @Test
    void testCreateDefaultMapReturnsFreshMapEachCall() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> first = TypeHandler.createDefaultMap();
        final Map<Class<?>, Converter<?, ? extends Throwable>> second = TypeHandler.createDefaultMap();
        assertNotSame(first, second);
        first.remove(Object.class);
        assertTrue(second.containsKey(Object.class));
    }

    @Test
    void testGetConverterForUnregisteredClassReturnsDefault() {
        final TypeHandler handler = new TypeHandler(new HashMap<Class<?>, Converter<?, ? extends Throwable>>());
        assertSame(Converter.DEFAULT, handler.getConverter(String.class));
    }

    @Test
    void testGetConverterForRegisteredClass() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        map.put(Integer.class, Converter.NUMBER);
        final TypeHandler handler = new TypeHandler(map);
        assertSame(Converter.NUMBER, handler.getConverter(Integer.class));
    }

    @Test
    void testCreateClassSuccess() throws ParseException {
        final Class<?> clazz = TypeHandler.createClass("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    void testCreateClassNotFoundThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createClass("does.not.Exist");
            }
        });
    }

    @Test
    void testCreateDateAlwaysReturnsNullOrThrowsForInvalidInput() {
        final Exception exception = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createDate("not a date");
            }
        });
        assertNotNull(exception.getCause());
    }

    @Test
    void testCreateFileReturnsFileForValidPath() {
        final File file = TypeHandler.createFile("some-file.txt");
        assertNotNull(file);
        assertEquals("some-file.txt", file.getName());
    }

    @Test
    void testCreateFilesThrowsUnsupportedOperationException() {
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createFiles("a,b,c");
            }
        });
    }

    @Test
    void testCreateNumberDouble() throws ParseException {
        final Number number = TypeHandler.createNumber("1.5");
        assertEquals(1.5d, number.doubleValue(), 0.0001d);
        assertTrue(number instanceof Double);
    }

    @Test
    void testCreateNumberLong() throws ParseException {
        final Number number = TypeHandler.createNumber("42");
        assertEquals(42L, number.longValue());
        assertTrue(number instanceof Long);
    }

    @Test
    void testCreateNumberInvalidThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createNumber("not-a-number");
            }
        });
    }

    @Test
    void testCreateObjectSuccess() throws ParseException {
        final Object obj = TypeHandler.createObject("java.lang.Object");
        assertNotNull(obj);
        assertEquals(Object.class, obj.getClass());
    }

    @Test
    void testCreateObjectNoDefaultConstructorThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createObject("java.lang.Integer");
            }
        });
    }

    @Test
    void testCreateURLSuccess() throws ParseException {
        final URL url = TypeHandler.createURL("https://commons.apache.org");
        assertNotNull(url);
        assertEquals("https://commons.apache.org", url.toString());
    }

    @Test
    void testCreateURLMalformedThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createURL("not a url");
            }
        });
    }

    @Test
    void testCreateValueWithClassForLong() throws ParseException {
        final Long value = TypeHandler.createValue("123", Long.class);
        assertEquals(Long.valueOf(123L), value);
    }

    @Test
    void testCreateValueWithClassForCharacter() throws ParseException {
        final Character value = TypeHandler.createValue("a", Character.class);
        assertEquals(Character.valueOf('a'), value);
    }

    @Test
    void testCreateValueWithCharacterUnicodeEscape() throws ParseException {
        final Character value = TypeHandler.createValue("\\u0041", Character.class);
        assertEquals(Character.valueOf('A'), value);
    }

    @Test
    void testCreateValueWithCharacterUnicodeEscapeOutsideBmpThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                // U+1F600 is a supplementary code point and does not fit in a char.
                TypeHandler.createValue("\\u1F600", Character.class);
            }
        });
    }

    @Test
    void testCreateValueWithUnregisteredClassReturnsStringUnchanged() throws ParseException {
        final String value = TypeHandler.createValue("hello", String.class);
        assertEquals("hello", value);
    }

    @Test
    void testCreateValueDeprecatedObjectOverload() throws ParseException {
        final Object value = TypeHandler.createValue("99", (Object) Integer.class);
        assertEquals(Integer.valueOf(99), value);
    }

    @Test
    void testCreateValueByteOutOfRangeThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createValue("1000", Byte.class);
            }
        });
    }

    @Test
    void testOpenFileSuccess() throws ParseException, IOException {
        final File tempFile = File.createTempFile("TypeHandlerAgentTest", ".txt");
        tempFile.deleteOnExit();
        final FileInputStream stream = TypeHandler.openFile(tempFile.getAbsolutePath());
        try {
            assertNotNull(stream);
        } finally {
            stream.close();
        }
    }

    @Test
    void testOpenFileMissingThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.openFile("/no/such/file/should/exist/ever.txt");
            }
        });
    }

    @Test
    void testCustomConverterOverridesInstanceCreation() throws Exception {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        map.put(Integer.class, new Converter<Integer, RuntimeException>() {
            @Override
            public Integer apply(final String string) {
                return Integer.valueOf(-1);
            }
        });
        final TypeHandler handler = new TypeHandler(map);
        final Converter<Integer, ?> converter = handler.getConverter(Integer.class);
        assertEquals(Integer.valueOf(-1), converter.apply("123"));
    }

    @Test
    void testEmptyConverterMapFallsBackToDefaultForEveryClass() {
        final TypeHandler handler = new TypeHandler(new HashMap<Class<?>, Converter<?, ? extends Throwable>>());
        assertFalse(handler.getConverter(Integer.class) == null);
        assertSame(Converter.DEFAULT, handler.getConverter(Integer.class));
        assertSame(Converter.DEFAULT, handler.getConverter(File.class));
    }
}
