/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum AgentHeader {
        Name, Email, Phone
    }

    @Test
    void testBuilderCreateDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat base = CSVFormat.DEFAULT.builder().setDelimiter(';').setCommentMarker('#').setNullString("NULL").get();
        final CSVFormat copy = CSVFormat.Builder.create(base).get();
        assertEquals(base, copy);
        assertEquals(';', copy.getDelimiterString().charAt(0));
        assertEquals(Character.valueOf('#'), copy.getCommentMarker());
        assertEquals("NULL", copy.getNullString());
    }

    @Test
    void testBuildVsGetReturnDifferentInstances() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertNotSame(builder.get(), builder.build());
    }

    @Test
    void testDelimiterCannotBeCrLineBreak() {
        try {
            CSVFormat.DEFAULT.builder().setDelimiter(Constants.CR).get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testDelimiterCannotBeLfLineBreak() {
        try {
            CSVFormat.DEFAULT.builder().setDelimiter(Constants.LF).get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testDelimiterCannotBeEmptyString() {
        try {
            CSVFormat.DEFAULT.builder().setDelimiter("").get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMultiCharacterDelimiterIsPreserved() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("||", format.getDelimiterString());
        assertArrayEquals(new char[] {'|', '|'}, format.getDelimiterCharArray());
    }

    @Test
    void testQuoteCharacterSameAsDelimiterThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setDelimiter('!').setQuote('!').get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testEscapeCharacterSameAsDelimiterThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setDelimiter('!').setEscape('!').get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setDelimiter('!').setCommentMarker('!').get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testQuoteCharacterSameAsCommentMarkerThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setCommentMarker('#').setQuote('#').get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testEscapeCharacterSameAsCommentMarkerThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('#').get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setQuote(null).setQuoteMode(QuoteMode.NONE).get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testCommentMarkerCannotBeLineBreak() {
        try {
            CSVFormat.DEFAULT.builder().setCommentMarker(Constants.LF);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testEscapeCannotBeLineBreak() {
        try {
            CSVFormat.DEFAULT.builder().setEscape(Constants.CR);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testQuoteCannotBeLineBreak() {
        try {
            CSVFormat.DEFAULT.builder().setQuote(Constants.LF);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testSetDuplicateHeaderModeNullThrowsNullPointerException() {
        try {
            CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testDuplicateHeaderDisallowThrowsOnGet() {
        try {
            CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B", "A").get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testDuplicateHeaderAllowEmptyAllowsBlankDuplicatesOnly() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "").get();
        assertArrayEquals(new String[] {"A", "", ""}, format.getHeader());
        try {
            CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("A", "A").get();
        assertArrayEquals(new String[] {"A", "A"}, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsNullWhenUnset() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", "two").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("one", comments2[0]);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(AgentHeader.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat first = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat second = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    void testEqualsRejectsNullAndOtherTypesAndSelf() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(format, format);
        assertNotEquals(null, format);
        assertNotEquals("not a format", format);
        assertFalse(format.equals(null));
    }

    @Test
    void testNotEqualsForDifferentDelimiters() {
        final CSVFormat first = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat second = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(first, second);
    }

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals("|", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        try {
            CSVFormat.valueOf("DoesNotExist");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testPredefinedFormatSettings() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());

        assertEquals(",", CSVFormat.RFC4180.getDelimiterString());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());

        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());

        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
    }

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testPrintRecordWritesDelimitedValuesAndSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "x", "y", "z");
        assertEquals("x,y,z\r\n", sb.toString());
    }

    @Test
    void testPrintObjectHandlesNullAsEmptyByDefault() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintObjectUsesNullStringWhenSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterAndRecordSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    void testParseReturnsParserThatYieldsRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n1,2,3\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testPrintToAppendableReturnsWorkingPrinter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        try {
            printer.printRecord("a", "b");
        } finally {
            printer.close();
        }
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void testToStringContainsConfiguredSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testIsSetHelpers() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());

        final CSVFormat configured = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setNullString("NULL").setQuote(null).get();
        assertTrue(configured.isCommentMarkerSet());
        assertTrue(configured.isEscapeCharacterSet());
        assertTrue(configured.isNullStringSet());
        assertFalse(configured.isQuoteCharacterSet());
    }

    @Test
    void testMaxRowsDefaultAndSetter() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithDelimiterCreatesNewInstance() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter(';');
        assertNotSame(original, changed);
        assertEquals(',', original.getDelimiter());
        assertEquals(';', changed.getDelimiter());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithNullStringSetsNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithIgnoreEmptyLinesToggles() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithFirstRecordAsHeaderSetsEmptyHeaderAndSkip() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithAllowDuplicateHeaderNamesDeprecatedApi() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithTrailingDelimiterToggles() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithSystemRecordSeparatorUsesLineSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }
}
