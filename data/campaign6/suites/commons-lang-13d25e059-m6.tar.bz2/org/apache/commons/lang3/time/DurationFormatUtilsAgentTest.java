/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationFormatUtils}.
 */
class DurationFormatUtilsAgentTest {

    private static final long MILLIS_PER_SECOND = 1000L;
    private static final long MILLIS_PER_MINUTE = 60 * MILLIS_PER_SECOND;
    private static final long MILLIS_PER_HOUR = 60 * MILLIS_PER_MINUTE;
    private static final long MILLIS_PER_DAY = 24 * MILLIS_PER_HOUR;

    @Test
    void testFormatDurationZero() {
        assertEquals("0:00:00.000", DurationFormatUtils.formatDuration(0, "H:mm:ss.SSS"));
    }

    @Test
    void testFormatDurationBasic() {
        final long millis = 2 * MILLIS_PER_DAY + 3 * MILLIS_PER_HOUR + 4 * MILLIS_PER_MINUTE + 5 * MILLIS_PER_SECOND + 6;
        assertEquals("02d03h04m05s", DurationFormatUtils.formatDuration(millis, "dd'd'HH'h'mm'm'ss's'"));
        assertEquals("2d3h4m5s", DurationFormatUtils.formatDuration(millis, "d'd'H'h'm'm's's'", false));
    }

    @Test
    void testFormatDurationNegativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> DurationFormatUtils.formatDuration(-1L, "HH:mm:ss"));
        assertTrue(ex.getMessage().contains("durationMillis"));
    }

    @Test
    void testFormatDurationMaxValueDoesNotThrow() {
        final String result = DurationFormatUtils.formatDuration(Long.MAX_VALUE, "d'd'H'h'm'm's's'", false);
        assertTrue(result.endsWith("s"));
    }

    @Test
    void testFormatDurationPaddingDisabled() {
        assertEquals("1:1:1", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR + MILLIS_PER_MINUTE + MILLIS_PER_SECOND, "H:m:s", false));
    }

    @Test
    void testFormatDurationHMS() {
        final long millis = MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 4;
        assertEquals("01:02:03.004", DurationFormatUtils.formatDurationHMS(millis));
    }

    @Test
    void testFormatDurationHMSZero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    @Test
    void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
    }

    @Test
    void testFormatDurationISO() {
        final long millis = MILLIS_PER_DAY + MILLIS_PER_HOUR + MILLIS_PER_MINUTE + MILLIS_PER_SECOND + 1;
        assertEquals("P0Y0M1DT1H1M1.001S", DurationFormatUtils.formatDurationISO(millis));
    }

    @Test
    void testFormatDurationWordsSuppressNone() {
        final long millis = 2 * MILLIS_PER_DAY + 2 * MILLIS_PER_HOUR + 3 * MILLIS_PER_MINUTE + 4 * MILLIS_PER_SECOND;
        assertEquals("2 days 2 hours 3 minutes 4 seconds", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    @Test
    void testFormatDurationWordsSuppressLeadingZero() {
        // no days, so leading "0 days" is suppressed
        final long millis = 2 * MILLIS_PER_HOUR + 3 * MILLIS_PER_MINUTE + 4 * MILLIS_PER_SECOND;
        assertEquals("2 hours 3 minutes 4 seconds", DurationFormatUtils.formatDurationWords(millis, true, false));
    }

    @Test
    void testFormatDurationWordsSuppressTrailingZero() {
        // no minutes/seconds, so trailing zeros are suppressed
        final long millis = 2 * MILLIS_PER_DAY + 2 * MILLIS_PER_HOUR;
        assertEquals("2 days 2 hours", DurationFormatUtils.formatDurationWords(millis, false, true));
    }

    @Test
    void testFormatDurationWordsSuppressBothAllZero() {
        // leading-zero suppression strips the leading space along with "0 days"/"0 hours"/"0 minutes",
        // so the remaining " 0 seconds" no longer matches the trailing-suppression pattern (which expects a leading space)
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
    }

    @Test
    void testFormatDurationWordsSingular() {
        final long millis = MILLIS_PER_DAY + MILLIS_PER_HOUR + MILLIS_PER_MINUTE + MILLIS_PER_SECOND;
        assertEquals("1 day 1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    @Test
    void testFormatPeriodSameInstant() {
        final long now = 1000000L;
        assertEquals("00:00:00", DurationFormatUtils.formatPeriod(now, now, "HH:mm:ss"));
    }

    @Test
    void testFormatPeriodStartAfterEndThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> DurationFormatUtils.formatPeriod(100L, 0L, "HH:mm:ss"));
        assertTrue(ex.getMessage().contains("startMillis"));
    }

    @Test
    void testFormatPeriodWithTimeZone() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(gmt);
        start.clear();
        start.set(2020, Calendar.JANUARY, 10, 0, 0, 0);
        final Calendar end = Calendar.getInstance(gmt);
        end.clear();
        end.set(2020, Calendar.MARCH, 15, 0, 0, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "M'M'd'D'", true, gmt);
        assertEquals("2M5D", result);
    }

    @Test
    void testFormatPeriodISOZero() {
        final long now = 123456789L;
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(now, now));
    }

    @Test
    void testFormatPeriodISO() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(gmt);
        start.clear();
        start.set(2000, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(gmt);
        end.clear();
        end.set(2003, Calendar.FEBRUARY, 1, 0, 0, 0);
        final long startMillis;
        final long endMillis;
        final TimeZone defaultZone = TimeZone.getDefault();
        TimeZone.setDefault(gmt);
        try {
            startMillis = start.getTimeInMillis();
            endMillis = end.getTimeInMillis();
            assertEquals("P3Y1M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(startMillis, endMillis));
        } finally {
            TimeZone.setDefault(defaultZone);
        }
    }

    @Test
    void testLexxSimpleTokens() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yMdHms");
        assertEquals(6, tokens.length);
        assertEquals("y", tokens[0].getValue());
        assertEquals("s", tokens[5].getValue());
    }

    @Test
    void testLexxRepeatedTokenIncrementsCount() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertEquals(1, tokens.length);
        assertEquals(4, tokens[0].getCount());
    }

    @Test
    void testLexxLiteral() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'days'");
        assertEquals(2, tokens.length);
        assertEquals("days", tokens[1].getValue().toString());
    }

    @Test
    void testLexxUnmatchedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, () -> DurationFormatUtils.lexx("d'days"));
    }

    @Test
    void testLexxUnmatchedOptionalOpenThrows() {
        assertThrows(IllegalArgumentException.class, () -> DurationFormatUtils.lexx("[d'd'"));
    }

    @Test
    void testLexxUnmatchedOptionalCloseThrows() {
        assertThrows(IllegalArgumentException.class, () -> DurationFormatUtils.lexx("d]"));
    }

    @Test
    void testLexxNestedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, () -> DurationFormatUtils.lexx("[d[H]]"));
    }

    @Test
    void testLexxEmptyFormat() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("");
        assertEquals(0, tokens.length);
    }

    @Test
    void testFormatDurationOptionalBlockSuppressedWhenZero() {
        // d'd'[H'h'm'm']s's' -> when hours and minutes are zero, the optional block is suppressed
        assertEquals("1d0s", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, "d'd'[H'h'm'm']s's'", false));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(MILLIS_PER_HOUR, "d'd'[H'h'm'm']s's'", false));
    }

    @Test
    void testFormatDurationOptionalBlockEntirelyEmpty() {
        // [dHms] produces empty string for Duration.ZERO
        assertEquals("", DurationFormatUtils.formatDuration(0, "[dHms]", false));
        assertEquals("1", DurationFormatUtils.formatDuration(MILLIS_PER_DAY, "[dHms]", false));
    }

    @Test
    void testPublicConstructor() {
        // Deprecated but public; just exercise it for coverage of observable state (non-null instance).
        assertTrue(new DurationFormatUtils() instanceof DurationFormatUtils);
    }
}
