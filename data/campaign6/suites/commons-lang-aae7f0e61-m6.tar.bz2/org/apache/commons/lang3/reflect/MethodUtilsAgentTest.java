/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface AgentAnnotation {
    }

    public interface AgentInterface {
        default String interfaceMethod() {
            return "interfaceDefault";
        }
    }

    public static class AgentParent implements AgentInterface {

        public String overloaded(final Object o) {
            return "Object";
        }

        public String overloaded(final String s) {
            return "String";
        }

        @AgentAnnotation
        public String annotated() {
            return "parentAnnotated";
        }

        public static String staticMethod(final String s) {
            return "static:" + s;
        }

        public String varArgsMethod(final String first, final String... rest) {
            return first + ":" + rest.length;
        }

        public String varArgsPrimitive(final int... values) {
            int sum = 0;
            for (final int v : values) {
                sum += v;
            }
            return "sum:" + sum;
        }

        public String throwsException() {
            throw new IllegalStateException("boom");
        }

        private String privateMethod() {
            return "private";
        }

        protected String protectedMethod() {
            return "protected";
        }
    }

    public static class AgentChild extends AgentParent {
        @Override
        public String overloaded(final Object o) {
            return "ChildObject";
        }

        @Override
        public String annotated() {
            return "childAnnotated";
        }
    }

    private static class PrivateClass {
        @SuppressWarnings("unused")
        public String publicMethodOnPrivateClass() {
            return "fromPrivateClass";
        }
    }

    public static class Boxer {
        public String take(final int i) {
            return "int:" + i;
        }
    }

    public interface AgentIfaceA {
    }

    public interface AgentIfaceB {
    }

    public static class AgentImpl implements AgentIfaceA, AgentIfaceB {
    }

    public static class Ambiguous {
        public void process(final AgentIfaceA a) {
            // no-op
        }

        public void process(final AgentIfaceB b) {
            // no-op
        }
    }

    @Test
    public void testGetAccessibleMethod_publicClass() throws NoSuchMethodException {
        final Method method = AgentParent.class.getMethod("overloaded", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(method);
        assertNotNull(accessible);
        assertEquals(method, accessible);
    }

    @Test
    public void testGetAccessibleMethod_null() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethod_onPrivateDeclaringClassReturnsNull() throws NoSuchMethodException {
        final Method method = PrivateClass.class.getMethod("publicMethodOnPrivateClass");
        final Method accessible = MethodUtils.getAccessibleMethod(PrivateClass.class, method);
        assertNull(accessible);
    }

    @Test
    public void testGetAccessibleMethod_byNameAndParams() {
        final Method method = MethodUtils.getAccessibleMethod(AgentParent.class, "overloaded", String.class);
        assertNotNull(method);
        assertEquals("overloaded", method.getName());
    }

    @Test
    public void testGetAccessibleMethod_byNameAndParams_notFound() {
        assertNull(MethodUtils.getAccessibleMethod(AgentParent.class, "doesNotExist"));
    }

    @Test
    public void testGetAnnotation_direct() throws NoSuchMethodException {
        final Method method = AgentParent.class.getMethod("annotated");
        final AgentAnnotation annotation = MethodUtils.getAnnotation(method, AgentAnnotation.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotation_searchSupersFindsParentAnnotation() throws NoSuchMethodException {
        final Method method = AgentChild.class.getMethod("annotated");
        assertNull(MethodUtils.getAnnotation(method, AgentAnnotation.class, false, false));
        final AgentAnnotation found = MethodUtils.getAnnotation(method, AgentAnnotation.class, true, true);
        assertNotNull(found);
    }

    @Test
    public void testGetAnnotation_nullMethodThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, AgentAnnotation.class, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotation_nullAnnotationClassThrows() throws NoSuchMethodException {
        final Method method = AgentParent.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(method, null, false, false);
            }
        });
    }

    @Test
    public void testGetMatchingAccessibleMethod_exact() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(AgentParent.class, "overloaded", String.class);
        assertNotNull(method);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethod_compatibleBoxedPrimitive() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(Boxer.class, "take", Integer.class);
        assertNotNull(method);
        assertEquals(int.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethod_notFound() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(AgentParent.class, "nope"));
    }

    @Test
    public void testGetMatchingMethod_exactMatch() {
        final Method method = MethodUtils.getMatchingMethod(AgentParent.class, "privateMethod");
        assertNotNull(method);
        assertEquals("privateMethod", method.getName());
    }

    @Test
    public void testGetMatchingMethod_assignableMatch() {
        final Method method = MethodUtils.getMatchingMethod(AgentParent.class, "overloaded", Integer.class);
        assertNotNull(method);
        assertEquals(Object.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingMethod_noMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(AgentParent.class, "nonexistentMethodName"));
    }

    @Test
    public void testGetMatchingMethod_nullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "foo");
            }
        });
    }

    @Test
    public void testGetMatchingMethod_emptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(AgentParent.class, "");
            }
        });
    }

    @Test
    public void testGetMatchingMethod_ambiguousOverloadsThrowsIllegalStateException() {
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Ambiguous.class, "process", AgentImpl.class);
            }
        });
    }

    @Test
    public void testGetMethodObject_found() {
        final Method method = MethodUtils.getMethodObject(AgentParent.class, "overloaded", String.class);
        assertNotNull(method);
    }

    @Test
    public void testGetMethodObject_notFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(AgentParent.class, "notAMethod"));
    }

    @Test
    public void testGetMethodObject_nullNameOrClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "foo"));
        assertNull(MethodUtils.getMethodObject(AgentParent.class, null));
    }

    @Test
    public void testGetMethodsListWithAnnotation_noSupers() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentParent.class, AgentAnnotation.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsListWithAnnotation_childWithoutSupersIsEmpty() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentChild.class, AgentAnnotation.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotation_childWithSupersFindsIt() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentChild.class, AgentAnnotation.class, true, true);
        assertFalse(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotation_nullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, AgentAnnotation.class);
            }
        });
    }

    @Test
    public void testGetMethodsListWithAnnotation_nullAnnotationThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(AgentParent.class, null);
            }
        });
    }

    @Test
    public void testGetMethodsWithAnnotation_returnsArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentParent.class, AgentAnnotation.class);
        assertEquals(1, methods.length);
    }

    @Test
    public void testGetMethodsWithAnnotation_emptyArrayWhenNoneFound() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentChild.class, AgentAnnotation.class);
        assertEquals(0, methods.length);
    }

    @Test
    public void testGetOverrideHierarchy() throws NoSuchMethodException {
        final Method childMethod = AgentChild.class.getMethod("annotated");
        final List<Method> hierarchy = new ArrayList<Method>(MethodUtils.getOverrideHierarchy(childMethod, Interfaces.EXCLUDE));
        assertTrue(hierarchy.size() >= 2);
        assertEquals(childMethod, hierarchy.get(0));
    }

    @Test
    public void testGetOverrideHierarchy_nullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE);
            }
        });
    }

    @Test
    public void testInvokeExactMethod_noArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new AgentParent(), "annotated");
        assertEquals("parentAnnotated", result);
    }

    @Test
    public void testInvokeExactMethod_withArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new AgentParent(), "overloaded", "hello");
        assertEquals("String", result);
    }

    @Test
    public void testInvokeExactMethod_noSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new AgentParent(), "overloaded", Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeExactMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(null, "foo");
            }
        });
    }

    @Test
    public void testInvokeExactMethod_wrappedException() {
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new AgentParent(), "throwsException");
            }
        });
        assertTrue(ex.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(AgentParent.class, "staticMethod", "abc");
        assertEquals("static:abc", result);
    }

    @Test
    public void testInvokeExactStaticMethod_noSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(AgentParent.class, "staticMethod", Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeMethod_noArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentParent(), "annotated");
        assertEquals("parentAnnotated", result);
    }

    @Test
    public void testInvokeMethod_withPrimitiveBoxingMatch() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Boxer(), "take", Integer.valueOf(42));
        assertEquals("int:42", result);
    }

    @Test
    public void testInvokeMethod_forceAccessOnPrivateMethod() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentParent(), true, "privateMethod");
        assertEquals("private", result);
    }

    @Test
    public void testInvokeMethod_forceAccessOnProtectedMethod() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentParent(), true, "protectedMethod");
        assertEquals("protected", result);
    }

    @Test
    public void testInvokeMethod_withoutForceAccessOnPrivateThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new AgentParent(), false, "privateMethod");
            }
        });
    }

    @Test
    public void testInvokeMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "foo");
            }
        });
    }

    @Test
    public void testInvokeMethod_dispatchesToOverride() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentChild(), "overloaded", "stringArg");
        assertEquals("String", result);
        final Object resultObj = MethodUtils.invokeMethod(new AgentChild(), "overloaded", Integer.valueOf(1));
        assertEquals("ChildObject", resultObj);
    }

    @Test
    public void testInvokeMethod_varArgsWithExtraArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentParent(), "varArgsMethod", "first", "a", "b", "c");
        assertEquals("first:3", result);
    }

    @Test
    public void testInvokeMethod_varArgsWithNoExtraArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentParent(), "varArgsMethod", "onlyFirst");
        assertEquals("onlyFirst:0", result);
    }

    @Test
    public void testInvokeMethod_varArgsPrimitive() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentParent(), "varArgsPrimitive",
                Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3));
        assertEquals("sum:6", result);
    }

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(AgentParent.class, "staticMethod", "xyz");
        assertEquals("static:xyz", result);
    }

    @Test
    public void testInvokeStaticMethod_noSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(AgentParent.class, "noSuchStatic");
            }
        });
    }

    @Test
    public void testConstructorIsPublicAndUsable() {
        final MethodUtils instance = new MethodUtils();
        assertNotNull(instance);
    }

    @Test
    public void testGetAccessibleMethod_viaInterface() throws NoSuchMethodException {
        final Method method = AgentChild.class.getMethod("interfaceMethod");
        final Method accessible = MethodUtils.getAccessibleMethod(method);
        assertNotNull(accessible);
    }

    @Test
    public void testInvokeMethod_dispatchesInterfaceDefaultMethod() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentChild(), "interfaceMethod");
        assertEquals("interfaceDefault", result);
    }
}
