/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MultilineRecursiveToStringStyle}.
 */
class MultilineRecursiveToStringStyleAgentTest {

    static class Job {
        String title;
    }

    static class Person {
        String name;
        int age;
        boolean smoker;
        Job job;
    }

    static class Pair {
        int a;
        int b;
    }

    static class Empty {
        // Intentionally no fields.
    }

    static class WithIntArray {
        int[] nums;
    }

    static class WithObjectArray {
        Object[] items;
    }

    static class SelfRef {
        String name;
        SelfRef self;
    }

    private static String identity(final Object o) {
        return o.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(o));
    }

    @Test
    void testEmptyObjectHasEmptyIndentedBody() {
        final Empty empty = new Empty();
        final String result = new ReflectionToStringBuilder(empty, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(empty) + "[\n  \n]", result);
    }

    @Test
    void testSingleFieldIsIndentedByTwoSpaces() {
        final Pair pair = new Pair();
        pair.a = 1;
        pair.b = 2;
        final String result = new ReflectionToStringBuilder(pair, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(pair) + "[\n  a=1,\n  b=2\n]", result);
    }

    @Test
    void testFieldsAreOrderedAlphabeticallyByName() {
        final Person p = new Person();
        p.name = "John Doe";
        p.age = 33;
        p.smoker = false;
        p.job = null;
        final String result = new ReflectionToStringBuilder(p, new MultilineRecursiveToStringStyle()).toString();
        // Declared order is name, age, smoker, job; rendering must be alphabetical: age, job, name, smoker.
        assertEquals(identity(p) + "[\n  age=33,\n  job=<null>,\n  name=John Doe,\n  smoker=false\n]", result);
    }

    @Test
    void testNestedObjectIsIndentedFourSpacesWithClosingBracketAtTwoSpaces() {
        final Person p = new Person();
        p.name = "John Doe";
        p.age = 33;
        p.smoker = false;
        p.job = new Job();
        p.job.title = "Manager";
        final String result = new ReflectionToStringBuilder(p, new MultilineRecursiveToStringStyle()).toString();
        final String expected = identity(p) + "[\n" + "  age=33,\n" + "  job=" + identity(p.job) + "[\n" + "    title=Manager\n" + "  ],\n"
                + "  name=John Doe,\n" + "  smoker=false\n" + "]";
        assertEquals(expected, result);
    }

    @Test
    void testPrimitiveArrayElementsAreIndentedFourSpaces() {
        final WithIntArray w = new WithIntArray();
        w.nums = new int[] {3, 6};
        final String result = new ReflectionToStringBuilder(w, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(w) + "[\n  nums={\n    3,\n    6\n  }\n]", result);
    }

    @Test
    void testEmptyPrimitiveArrayStillClosesBraceCorrectly() {
        final WithIntArray w = new WithIntArray();
        w.nums = new int[0];
        final String result = new ReflectionToStringBuilder(w, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(w) + "[\n  nums={\n    \n  }\n]", result);
    }

    @Test
    void testNullArrayFieldRendersNullTextNotBraces() {
        final WithIntArray w = new WithIntArray();
        w.nums = null;
        final String result = new ReflectionToStringBuilder(w, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(w) + "[\n  nums=<null>\n]", result);
    }

    @Test
    void testObjectArrayElementsAreRecursivelyIndentedDeeper() {
        final WithObjectArray w = new WithObjectArray();
        final Job j1 = new Job();
        j1.title = "A";
        final Job j2 = new Job();
        j2.title = "B";
        w.items = new Object[] {j1, j2};
        final String result = new ReflectionToStringBuilder(w, new MultilineRecursiveToStringStyle()).toString();
        final String expected = identity(w) + "[\n" + "  items={\n" + "    " + identity(j1) + "[\n" + "      title=A\n" + "    ],\n" + "    "
                + identity(j2) + "[\n" + "      title=B\n" + "    ]\n" + "  }\n" + "]";
        assertEquals(expected, result);
    }

    @Test
    void testNullElementInsideObjectArrayRendersNullText() {
        final WithObjectArray w = new WithObjectArray();
        w.items = new Object[] {null, "x"};
        final String result = new ReflectionToStringBuilder(w, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(w) + "[\n  items={\n    <null>,\n    x\n  }\n]", result);
    }

    /**
     * A self-referencing object must not recurse infinitely: the second (identity-equal)
     * occurrence is rendered in the abbreviated {@code Object.toString()} format, as documented
     * by the superclass {@link RecursiveToStringStyle}.
     */
    @Test
    void testSelfReferenceIsAbbreviatedNotRecursed() {
        final SelfRef s = new SelfRef();
        s.name = "n1";
        s.self = s;
        final String result = new ReflectionToStringBuilder(s, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(identity(s) + "[\n  name=n1,\n  self=" + identity(s) + "\n]", result);
    }

    /**
     * {@link MultilineRecursiveToStringStyle#appendDetail(StringBuffer, String, Object)} overrides
     * {@link RecursiveToStringStyle#appendDetail(StringBuffer, String, Object)}, which gracefully
     * renders a {@code null} value using the style's null text instead of throwing. The override
     * must honor the same contract.
     */
    @Test
    void testAppendDetailObjectHandlesNullValueLikeSuperclass() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", (Object) null);
        assertEquals(style.getNullText(), buffer.toString());
    }

    /**
     * The array-handling overrides save/restore the style's shared indentation state around a
     * delegating call to the superclass. If that delegating call fails, the indentation state must
     * still be restored so the style instance remains usable for later {@code toString} calls -
     * mirroring how any other recoverable failure during rendering must not permanently corrupt a
     * style instance that outlives a single failed call (e.g. one registered via
     * {@link ToStringBuilder#setDefaultStyle(ToStringStyle)} or otherwise reused).
     */
    @Test
    void testStyleIndentationSurvivesFailedArrayAppend() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final Pair pair = new Pair();
        pair.a = 1;
        pair.b = 2;
        final String before = new ReflectionToStringBuilder(pair, style).toString();

        try {
            style.appendDetail(new StringBuffer(), "nums", (int[]) null);
            fail("Expected a NullPointerException when appending a null int[] array detail");
        } catch (final NullPointerException expected) {
            // Expected: appending a null array fails while rendering the array content.
        }

        final String after = new ReflectionToStringBuilder(pair, style).toString();
        assertEquals(before, after, "A failed array append must not permanently corrupt the style's indentation state");
    }

    @Test
    void testConstructorInitializesTopLevelIndentToTwoSpaces() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        assertTrue(style.getContentStart().endsWith("  "), "Content start should end with 2 spaces of indentation: [" + style.getContentStart() + "]");
        assertTrue(style.getContentEnd().endsWith("]"), "Content end should close with ']': [" + style.getContentEnd() + "]");
    }
}
