/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");

    private static Calendar newCalendar() {
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.clear();
        return cal;
    }

    // --- construction / basic getters -------------------------------------------------

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(NEW_YORK, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final TimeZone returned = parser.getTimeZone();
        returned.setRawOffset(123456);
        // mutating the returned clone must not affect the parser's internal time zone
        assertEquals(NEW_YORK, parser.getTimeZone());
    }

    @Test
    void testNullPatternThrowsNpe() {
        assertThrows(NullPointerException.class, () -> new FastDateParser(null, NEW_YORK, Locale.US));
    }

    @Test
    void testNullTimeZoneThrowsNpe() {
        assertThrows(NullPointerException.class, () -> new FastDateParser("yyyy-MM-dd", null, Locale.US));
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new FastDateParser("A", NEW_YORK, Locale.US));
        assertTrue(ex.getMessage().contains("A"), "message should mention the offending letter: " + ex.getMessage());
    }

    @Test
    void testUnterminatedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, () -> new FastDateParser("yyyy'bad", NEW_YORK, Locale.US));
    }

    @Test
    void testInvalidIsoTimeZoneWidthThrows() {
        assertThrows(IllegalArgumentException.class, () -> new FastDateParser("XXXX", NEW_YORK, Locale.US));
    }

    // --- equals / hashCode --------------------------------------------------------------

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentPattern() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy/MM/dd", NEW_YORK, Locale.US);
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsDifferentType() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertNotEquals(a, "yyyy-MM-dd");
        assertNotEquals(null, a);
    }

    // --- toString -------------------------------------------------------------------

    @Test
    void testToStringContainsPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertTrue(parser.toString().contains("yyyy-MM-dd"));
        assertTrue(parser.toStringAll().contains("yyyy-MM-dd"));
    }

    @Test
    void testGetPatternsTokenCount() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        // yyyy, -, MM, -, dd => 5 strategy tokens
        assertEquals(5, parser.getPatterns().size());
    }

    // --- parse(String) happy / error paths ------------------------------------------

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Date date = parser.parse("2021-07-04");
        final Calendar cal = newCalendar();
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, () -> parser.parse("not-a-date"));
        assertTrue(ex.getMessage().contains("Unparseable date"), ex.getMessage());
        assertEquals(0, ex.getErrorOffset());
    }

    @Test
    void testJapaneseImperialLocaleAddsNoteToParseException() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, () -> parser.parse("bogus"));
        assertTrue(ex.getMessage().contains("1868-01-01"), ex.getMessage());
    }

    // --- parse(String, ParsePosition) ------------------------------------------------

    @Test
    void testParsePositionSuccessUpdatesIndex() {
        final FastDateParser parser = new FastDateParser("MM/dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("3/23/61", pos);
        assertNotNull(date);
        assertEquals(4, pos.getIndex());
        final Calendar cal = newCalendar();
        cal.setTime(date);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParsePositionFailureSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("MM-dd-yyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("03/23/1961", pos);
        assertNull(date);
        assertEquals(2, pos.getErrorIndex());
    }

    @Test
    void testParsePositionPastEndOfSourceReturnsNullAndSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(20);
        final Date date = parser.parse("2021-07-04", pos);
        assertNull(date);
        assertEquals(20, pos.getErrorIndex());
    }

    // --- parse(String, ParsePosition, Calendar) --------------------------------------

    @Test
    void testParseCalendarOverloadMergesIntoCalendar() {
        final FastDateParser parser = new FastDateParser("MM/dd", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.set(Calendar.YEAR, 1999);
        final boolean parsed = parser.parse("03/23", new ParsePosition(0), cal);
        assertTrue(parsed);
        // the pre-existing YEAR field is untouched since the pattern never sets it
        assertEquals(1999, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseCalendarOverloadReturnsFalseOnFailure() {
        final FastDateParser parser = new FastDateParser("MM/dd", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        final ParsePosition pos = new ParsePosition(0);
        final boolean parsed = parser.parse("AB/23", pos, cal);
        assertFalse(parsed);
        assertEquals(0, pos.getErrorIndex());
    }

    // --- parseObject delegation -------------------------------------------------------

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Object parsed = parser.parseObject("2021-07-04");
        assertTrue(parsed instanceof Date);
        assertEquals(parser.parse("2021-07-04"), parsed);
    }

    @Test
    void testParseObjectWithPositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object parsed = parser.parseObject("2021-07-04", pos);
        assertNotNull(parsed);
        assertEquals(10, pos.getIndex());
    }

    // --- two digit year / century adjustment ------------------------------------------

    @Test
    void testTwoDigitYearWithExplicitCenturyStart() throws ParseException {
        // centuryStart in 1950 => century = 1900, startYear = 50
        final Calendar centuryStartCal = newCalendar();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", NEW_YORK, Locale.US, centuryStartCal.getTime());

        final Calendar below = newCalendar();
        below.setTime(parser.parse("49"));
        assertEquals(2049, below.get(Calendar.YEAR));

        final Calendar atStart = newCalendar();
        atStart.setTime(parser.parse("50"));
        assertEquals(1950, atStart.get(Calendar.YEAR));

        final Calendar above = newCalendar();
        above.setTime(parser.parse("99"));
        assertEquals(1999, above.get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearIsNotCenturyAdjusted() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("0099"));
        assertEquals(99, cal.get(Calendar.YEAR));
    }

    // --- hour field boundaries ---------------------------------------------------------

    @Test
    void testHourInDay24WrapsToZero() throws ParseException {
        final FastDateParser parser = new FastDateParser("kk", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("24"));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHourInAmPm12WrapsToZero() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("12"));
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    @Test
    void testHourOfDayDoesNotWrap23() throws ParseException {
        final FastDateParser parser = new FastDateParser("HH", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("23"));
        assertEquals(23, cal.get(Calendar.HOUR_OF_DAY));
    }

    // --- adjoining numeric fields and maxWidth behaviour -------------------------------

    @Test
    void testAdjoiningNumericFieldsSplitByFixedWidth() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMdd", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("0101"));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTrailingNumericFieldConsumesRemainingDigits() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyyMM", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("20205"));
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MAY, cal.get(Calendar.MONTH));
    }

    // --- literal / quoted text ---------------------------------------------------------

    @Test
    void testLiteralMismatchFailsAtLiteralPosition() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2020/01/01", pos);
        assertNull(date);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testQuotedLiteralTextIsMatchedVerbatim() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy'T'MM", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("2020T01"));
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }

    // --- locale specific text fields ----------------------------------------------------

    @Test
    void testMonthNameTextField() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMM d, yyyy", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("Jan 5, 2020"));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(2020, cal.get(Calendar.YEAR));
    }

    @Test
    void testMonthNameTextFieldCaseInsensitive() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMM", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("JANUARY"));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }

    @Test
    void testAmPmField() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh:mm a", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("03:15 PM"));
        assertEquals(3, cal.get(Calendar.HOUR));
        assertEquals(Calendar.PM, cal.get(Calendar.AM_PM));
    }

    @Test
    void testEraField() throws ParseException {
        final FastDateParser parser = new FastDateParser("G yyyy", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse("BC 0044"));
        assertEquals(GregorianCalendar.BC, cal.get(Calendar.ERA));
    }

    @Test
    void testUnknownTextFieldFailsGracefully() {
        final FastDateParser parser = new FastDateParser("MMM", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Frobtober", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    // --- time zone fields -----------------------------------------------------------------

    @Test
    void testLiteralTimeZoneName() {
        final FastDateParser parser = new FastDateParser("mm:ss z", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        final boolean parsed = parser.parse("11:23 Pacific Standard Time", new ParsePosition(0), cal);
        assertTrue(parsed);
        final TimeZone pst = TimeZone.getTimeZone("America/Los_Angeles");
        assertEquals(pst.getRawOffset(), cal.get(Calendar.ZONE_OFFSET));
    }

    @Test
    void testIncompleteTimeZoneNameFailsGracefully() {
        final FastDateParser parser = new FastDateParser("mm:ss z", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("11:23 Pacific Standard ", pos);
        assertNull(date);
        assertEquals(6, pos.getErrorIndex());
    }

    @Test
    void testRfc822TimeZoneOffset() {
        final FastDateParser parser = new FastDateParser("Z", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        final boolean parsed = parser.parse("+0130", new ParsePosition(0), cal);
        assertTrue(parsed);
        assertEquals(90 * 60 * 1000, cal.get(Calendar.ZONE_OFFSET));
    }

    @Test
    void testDoubleZTimeZoneAcceptsColonForm() {
        final FastDateParser parser = new FastDateParser("ZZ", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        final boolean parsed = parser.parse("+01:30", new ParsePosition(0), cal);
        assertTrue(parsed);
        assertEquals(90 * 60 * 1000, cal.get(Calendar.ZONE_OFFSET));
    }

    @Test
    void testIsoTimeZoneXWidths() {
        final FastDateParser parserOne = new FastDateParser("X", NEW_YORK, Locale.US);
        final Calendar cal1 = newCalendar();
        assertTrue(parserOne.parse("+01", new ParsePosition(0), cal1));
        assertEquals(60 * 60 * 1000, cal1.get(Calendar.ZONE_OFFSET));

        final FastDateParser parserThree = new FastDateParser("XXX", NEW_YORK, Locale.US);
        final Calendar cal3 = newCalendar();
        assertTrue(parserThree.parse("+01:00", new ParsePosition(0), cal3));
        assertEquals(60 * 60 * 1000, cal3.get(Calendar.ZONE_OFFSET));
    }

    @Test
    void testIsoTimeZoneXRejectsOutOfRangeHour() {
        final FastDateParser parser = new FastDateParser("X", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("+24", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testOutOfRangeGmtOffsetFailsGracefully() {
        final FastDateParser parser = new FastDateParser("z", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        // 25 hours is out of range for a GMT offset; this must be a graceful parse
        // failure (via the ParsePosition error index), not an uncaught exception.
        final Date date = parser.parse("GMT-25:00", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    // --- overflow / numeric edge cases -----------------------------------------------------

    @Test
    void testOverflowingDigitRunFailsGracefullyInsteadOfThrowing() {
        // "yyyy" is the only (and therefore last) field, so no maxWidth limits how many
        // digits NumberStrategy will try to consume; a run long enough to overflow int
        // must be reported as an ordinary parse failure, not an uncaught exception.
        final FastDateParser parser = new FastDateParser("yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final String digits = "99999999999999999999";
        final Date date = parser.parse(digits, pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    // --- week year ('Y') field -------------------------------------------------------------

    @Test
    void testWeekYearFieldResolvesViaSetWeekDate() {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setMinimalDaysInFirstWeek(4);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.clear();

        final boolean parsed = parser.parse("2007-W01-1", new ParsePosition(0), cal);
        assertTrue(parsed);

        final Calendar expected = new GregorianCalendar(NEW_YORK, Locale.US);
        expected.clear();
        expected.set(2007, Calendar.JANUARY, 1);
        assertEquals(expected.getTime(), cal.getTime());
    }

    @Test
    void testIsoDayOfWeekMapping() throws ParseException {
        // 'u' is ISO day of week: Monday = 1 ... Sunday = 7
        final FastDateParser parser = new FastDateParser("u", NEW_YORK, Locale.US);
        final Calendar monday = newCalendar();
        monday.setTime(parser.parse("1"));
        assertEquals(Calendar.MONDAY, monday.get(Calendar.DAY_OF_WEEK));

        final Calendar sunday = newCalendar();
        sunday.setTime(parser.parse("7"));
        assertEquals(Calendar.SUNDAY, sunday.get(Calendar.DAY_OF_WEEK));
    }

    // --- whitespace / leading text handling -----------------------------------------------

    @Test
    void testLeadingWhitespaceIsStrippedWhenNoMaxWidth() throws ParseException {
        final FastDateParser parser = new FastDateParser("M/d/y", NEW_YORK, Locale.US);
        final Calendar cal = newCalendar();
        cal.setTime(parser.parse(" 3/ 23/ 1961"));
        assertEquals(1961, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testPrecedingUnmatchedCharacterFailsAtPositionZero() {
        final FastDateParser parser = new FastDateParser("MM/dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("A 3/23/61", pos);
        assertNull(date);
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }
}
