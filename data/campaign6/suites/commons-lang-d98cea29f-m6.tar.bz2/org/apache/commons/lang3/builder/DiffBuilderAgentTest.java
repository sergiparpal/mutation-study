/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained unit tests for {@link DiffBuilder}.
 */
public class DiffBuilderAgentTest {

    /**
     * Fixture type used to exercise the {@link Diff#getType()} based machinery indirectly.
     */
    private static final class Fixture {
        private final String name;
        private final int age;

        Fixture(final String name, final int age) {
            this.name = name;
            this.age = age;
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Fixture)) {
                return false;
            }
            final Fixture other = (Fixture) obj;
            return age == other.age && (name == null ? other.name == null : name.equals(other.name));
        }

        @Override
        public int hashCode() {
            return (name == null ? 0 : name.hashCode()) * 31 + age;
        }
    }

    // --- Constructor null-check behavior ---

    @Test
    public void testConstructorNullLeftThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DiffBuilder<Fixture>(null, new Fixture("a", 1), ToStringStyle.DEFAULT_STYLE);
            }
        });
    }

    @Test
    public void testConstructorNullRightThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DiffBuilder<Fixture>(new Fixture("a", 1), null, ToStringStyle.DEFAULT_STYLE);
            }
        });
    }

    // --- Trivially equal short-circuiting ---

    @Test
    public void testSameInstanceProducesNoDiffs() {
        final Fixture f = new Fixture("Alice", 30);
        final DiffBuilder<Fixture> builder = new DiffBuilder<Fixture>(f, f, ToStringStyle.DEFAULT_STYLE);
        final DiffResult<Fixture> result = builder.append("name", "x", "y").build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testEqualButDistinctInstancesProducesNoDiffs() {
        final Fixture left = new Fixture("Bob", 40);
        final Fixture right = new Fixture("Bob", 40);
        final DiffBuilder<Fixture> builder = new DiffBuilder<Fixture>(left, right, ToStringStyle.DEFAULT_STYLE);
        final DiffResult<Fixture> result = builder.append("name", "x", "y").build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testTestObjectsEqualsFalseStillAppendsDiffsEvenWhenTriviallyEqual() {
        final Fixture f = new Fixture("Carl", 50);
        final DiffBuilder<Fixture> builder = new DiffBuilder<Fixture>(f, f, ToStringStyle.DEFAULT_STYLE, false);
        final DiffResult<Fixture> result = builder.append("x", 1, 2).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    // --- Builder (static nested builder) coverage ---

    @Test
    public void testStaticBuilderDefaultStyleIsDefault() {
        final Fixture left = new Fixture("a", 1);
        final Fixture right = new Fixture("b", 2);
        final DiffBuilder<Fixture> db = DiffBuilder.<Fixture>builder().setLeft(left).setRight(right).build();
        final DiffResult<Fixture> result = db.append("name", left.name, right.name).build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testStaticBuilderNullStyleFallsBackToDefault() {
        final Fixture left = new Fixture("a", 1);
        final Fixture right = new Fixture("b", 2);
        final DiffBuilder<Fixture> db = DiffBuilder.<Fixture>builder().setLeft(left).setRight(right).setStyle(null).build();
        final DiffResult<Fixture> result = db.build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    public void testStaticBuilderCustomToStringFormat() {
        final Fixture left = new Fixture("a", 1);
        final Fixture right = new Fixture("b", 2);
        final DiffBuilder<Fixture> db = DiffBuilder.<Fixture>builder().setLeft(left).setRight(right)
                .setToStringFormat("%s vs %s").build();
        final DiffResult<Fixture> result = db.append("age", left.age, right.age).build();
        assertEquals(1, result.getNumberOfDiffs());
        final String lhsStr = new ToStringBuilder(left, ToStringStyle.DEFAULT_STYLE).append("age", left.age).build();
        final String rhsStr = new ToStringBuilder(right, ToStringStyle.DEFAULT_STYLE).append("age", right.age).build();
        assertEquals(String.format("%s vs %s", lhsStr, rhsStr), result.toString());
    }

    @Test
    public void testStaticBuilderNullToStringFormatFallsBackToDefault() {
        final Fixture left = new Fixture("a", 1);
        final Fixture right = new Fixture("b", 2);
        final DiffBuilder<Fixture> db = DiffBuilder.<Fixture>builder().setLeft(left).setRight(right)
                .setToStringFormat("%s vs %s").setToStringFormat(null).build();
        final DiffResult<Fixture> result = db.append("age", left.age, right.age).build();
        final String lhsStr = new ToStringBuilder(left, ToStringStyle.DEFAULT_STYLE).append("age", left.age).build();
        final String rhsStr = new ToStringBuilder(right, ToStringStyle.DEFAULT_STYLE).append("age", right.age).build();
        assertEquals(String.format("%s differs from %s", lhsStr, rhsStr), result.toString());
    }

    @Test
    public void testStaticBuilderTestObjectsEqualsFalse() {
        final Fixture f = new Fixture("same", 1);
        final DiffBuilder<Fixture> db = DiffBuilder.<Fixture>builder().setLeft(f).setRight(f)
                .setTestObjectsEquals(false).build();
        final DiffResult<Fixture> result = db.append("age", 1, 1).build();
        // Even an actually-equal primitive comparison yields no diff here because testObjectsEquals
        // only controls the up-front short circuit, not per-field comparisons.
        assertEquals(0, result.getNumberOfDiffs());
    }

    // --- Primitive append methods: equal case (no diff added) and differing case ---

    @Test
    public void testAppendBooleanEqualNoDiff() {
        final DiffResult<Fixture> result = newBuilder().append("b", true, true).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("b", true, false).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Boolean.TRUE, result.getDiffs().get(0).getLeft());
        assertEquals(Boolean.FALSE, result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendBooleanArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new boolean[] {true, false}, new boolean[] {true, true}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanArrayEqualNoDiff() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new boolean[] {true, false}, new boolean[] {true, false}).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendByteDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("b", (byte) 1, (byte) 2).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Byte.valueOf((byte) 1), result.getDiffs().get(0).getLeft());
    }

    @Test
    public void testAppendByteArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new byte[] {1, 2}, new byte[] {1, 3}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendCharDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("c", 'a', 'b').build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendCharArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new char[] {'a', 'b'}, new char[] {'a', 'c'}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("d", 1.0d, 2.0d).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleNaNEqualsNaN() {
        // Double.doubleToLongBits(NaN) == Double.doubleToLongBits(NaN) -> treated as equal, no diff.
        final DiffResult<Fixture> result = newBuilder().append("d", Double.NaN, Double.NaN).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new double[] {1.0, 2.0}, new double[] {1.0, 3.0}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("f", 1.0f, 2.0f).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new float[] {1.0f, 2.0f}, new float[] {1.0f, 3.0f}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendIntDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("i", 1, 2).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Integer.valueOf(1), result.getDiffs().get(0).getLeft());
        assertEquals(Integer.valueOf(2), result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendIntArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new int[] {1, 2}, new int[] {1, 3}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendLongDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("l", 1L, 2L).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendLongArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new long[] {1L, 2L}, new long[] {1L, 3L}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendShortDifferent() {
        final DiffResult<Fixture> result = newBuilder().append("s", (short) 1, (short) 2).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendShortArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new short[] {1, 2}, new short[] {1, 3}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectArrayDifferent() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new String[] {"a", "b"}, new String[] {"a", "c"}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectArrayEqualNoDiff() {
        final DiffResult<Fixture> result = newBuilder()
                .append("arr", new String[] {"a", "b"}, new String[] {"a", "b"}).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    // --- append(String, Object, Object) dispatch coverage ---

    @Test
    public void testAppendObjectSameReferenceNoDiff() {
        final String s = "shared";
        final DiffResult<Fixture> result = newBuilder().append("o", s, s).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectEqualValuesNoDiff() {
        final DiffResult<Fixture> result = newBuilder().append("o", "same", "same").build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectDifferentPlainValues() {
        final DiffResult<Fixture> result = newBuilder().append("o", "left", "right").build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals("left", result.getDiffs().get(0).getLeft());
        assertEquals("right", result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendObjectLeftNull() {
        final DiffResult<Fixture> result = newBuilder().append("o", null, "right").build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(null, result.getDiffs().get(0).getLeft());
        assertEquals("right", result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendObjectRightNull() {
        final DiffResult<Fixture> result = newBuilder().append("o", "left", null).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectBothNullNoDiff() {
        // lhs == rhs is true for two nulls.
        final DiffResult<Fixture> result = newBuilder().append("o", (Object) null, (Object) null).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectDispatchesToIntArrayOverload() {
        final int[] left = {1, 2, 3};
        final int[] right = {1, 2, 4};
        final DiffResult<Fixture> result = newBuilder().append("o", (Object) left, (Object) right).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectDispatchesToBooleanArrayOverload() {
        final boolean[] left = {true, false};
        final boolean[] right = {false, false};
        final DiffResult<Fixture> result = newBuilder().append("o", (Object) left, (Object) right).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectIncompatiblePrimitiveArrayTypesComparedAsObjects() {
        // int[] vs long[]: getClass() differs and neither is Object[], so compared as plain objects.
        final int[] left = {1, 2};
        final long[] right = {1L, 2L};
        final DiffResult<Fixture> result = newBuilder().append("o", (Object) left, (Object) right).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertSame(left, result.getDiffs().get(0).getLeft());
        assertSame(right, result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendObjectOneSideNullArrayDispatchesToArrayOverload() {
        final int[] left = {1, 2};
        final DiffResult<Fixture> result = newBuilder().append("o", (Object) left, (Object) null).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    // --- append(String, DiffResult) coverage ---

    @Test
    public void testAppendDiffResultMergesFieldNames() {
        final DiffResult<Fixture> inner = newBuilder().append("age", 1, 2).build();
        final DiffResult<Fixture> outer = newBuilder().append("fixture", inner).build();
        assertEquals(1, outer.getNumberOfDiffs());
        assertEquals("fixture.age", outer.getDiffs().get(0).getFieldName());
    }

    @Test
    public void testAppendDiffResultEmptyProducesNoDiffs() {
        final DiffResult<Fixture> inner = newBuilder().append("age", 1, 1).build();
        final DiffResult<Fixture> outer = newBuilder().append("fixture", inner).build();
        assertEquals(0, outer.getNumberOfDiffs());
    }

    @Test
    public void testAppendDiffResultNullThrows() {
        final DiffBuilder<Fixture> db = newBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                db.append("fixture", null);
            }
        });
    }

    @Test
    public void testAppendDiffResultSkippedWhenTriviallyEqual() {
        final Fixture f = new Fixture("same", 1);
        final DiffBuilder<Fixture> builder = new DiffBuilder<Fixture>(f, f, ToStringStyle.DEFAULT_STYLE);
        final DiffResult<Fixture> inner = newBuilder().append("age", 1, 2).build();
        final DiffResult<Fixture> outer = builder.append("fixture", inner).build();
        assertEquals(0, outer.getNumberOfDiffs());
    }

    // --- Fluent chaining and multi-diff accumulation ---

    @Test
    public void testAppendReturnsSameBuilderInstanceForChaining() {
        final DiffBuilder<Fixture> db = newBuilder();
        final DiffBuilder<Fixture> afterAppend = db.append("i", 1, 2);
        assertSame(db, afterAppend);
    }

    @Test
    public void testMultipleDiffsAccumulateInOrder() {
        final DiffResult<Fixture> result = newBuilder()
                .append("name", "a", "b")
                .append("age", 1, 2)
                .append("flag", true, true)
                .build();
        assertEquals(2, result.getNumberOfDiffs());
        final List<Diff<?>> diffs = result.getDiffs();
        assertEquals("name", diffs.get(0).getFieldName());
        assertEquals("age", diffs.get(1).getFieldName());
    }

    @Test
    public void testBuildResultsShareUnderlyingDiffList() {
        // build() does not snapshot the diff list, so appends made after an earlier
        // build() call are visible through results obtained before that append.
        final DiffBuilder<Fixture> db = newBuilder().append("age", 1, 2);
        final DiffResult<Fixture> first = db.build();
        db.append("name", "x", "y");
        final DiffResult<Fixture> second = db.build();
        assertEquals(2, first.getNumberOfDiffs());
        assertEquals(2, second.getNumberOfDiffs());
    }

    @Test
    public void testBuildResultCarriesLeftAndRight() {
        final Fixture left = new Fixture("a", 1);
        final Fixture right = new Fixture("b", 2);
        final DiffResult<Fixture> result = new DiffBuilder<Fixture>(left, right, ToStringStyle.DEFAULT_STYLE)
                .append("name", left.name, right.name).build();
        assertSame(left, result.getLeft());
        assertSame(right, result.getRight());
    }

    @Test
    public void testFieldNameNullThrowsNullPointerException() {
        final DiffBuilder<Fixture> db = newBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                db.append(null, 1, 2);
            }
        });
    }

    @Test
    public void testDeprecatedTwoArgConstructorDefaultsTestObjectsEqualsTrue() {
        final Fixture f = new Fixture("x", 1);
        final DiffResult<Fixture> result = new DiffBuilder<Fixture>(f, f, ToStringStyle.DEFAULT_STYLE)
                .append("age", 1, 2).build();
        assertTrue(result.getNumberOfDiffs() == 0);
        assertFalse(result.getNumberOfDiffs() > 0);
    }

    private static DiffBuilder<Fixture> newBuilder() {
        return new DiffBuilder<Fixture>(new Fixture("left", 1), new Fixture("right", 2), ToStringStyle.DEFAULT_STYLE, false);
    }
}
