/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link BackgroundInitializer}.
 */
class BackgroundInitializerAgentTest {

    /**
     * A concrete {@link BackgroundInitializer} whose {@code initialize()}
     * method can be controlled by the test: it can block until released,
     * count invocations and optionally throw.
     */
    private static class AbstractBackgroundInitializerTestImpl extends BackgroundInitializer<Object> {

        /** Latch that, when non-null, initialize() waits on before proceeding. */
        volatile CountDownLatch waitLatch;

        /** Number of times initialize() has been invoked. */
        volatile int initializeCalls;

        /** Exception to throw from initialize(), if any. */
        volatile Exception exceptionToThrow;

        /** The executor active while initialize() was running. */
        volatile ExecutorService executorDuringCall;

        AbstractBackgroundInitializerTestImpl() {
            super();
        }

        AbstractBackgroundInitializerTestImpl(final ExecutorService exec) {
            super(exec);
        }

        @Override
        protected Object initialize() throws Exception {
            initializeCalls++;
            executorDuringCall = getActiveExecutor();
            if (waitLatch != null) {
                waitLatch.await();
            }
            if (exceptionToThrow != null) {
                throw exceptionToThrow;
            }
            return "result-" + initializeCalls;
        }
    }

    // ------------------------------------------------------------------
    // Basic state before start()
    // ------------------------------------------------------------------

    @Test
    void testIsStartedFalseBeforeStart() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        assertFalse(init.isStarted());
        assertFalse(init.isInitialized());
        assertNull(init.getExternalExecutor());
        assertNull(init.getActiveExecutor());
    }

    @Test
    void testGetFutureBeforeStartThrows() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                init.getFuture();
            }
        });
    }

    @Test
    void testGetBeforeStartThrows() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
    }

    // ------------------------------------------------------------------
    // start()/get() happy path
    // ------------------------------------------------------------------

    @Test
    void testStartReturnsTrueOnceThenFalse() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        assertTrue(init.start());
        assertTrue(init.isStarted());
        assertFalse(init.start());
        assertFalse(init.start());
    }

    @Test
    void testGetReturnsInitializeResult() throws ConcurrentException {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        init.start();
        final Object result = init.get();
        assertEquals("result-1", result);
        assertEquals(1, init.initializeCalls);
        assertTrue(init.isInitialized());
    }

    @Test
    void testGetBlocksUntilInitializationComplete() throws Exception {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        final CountDownLatch latch = new CountDownLatch(1);
        init.waitLatch = latch;
        init.start();
        assertFalse(init.isInitialized());
        latch.countDown();
        final Object result = init.get();
        assertEquals("result-1", result);
        assertTrue(init.isInitialized());
    }

    // ------------------------------------------------------------------
    // Executors
    // ------------------------------------------------------------------

    @Test
    void testNoArgConstructorHasNoExternalExecutor() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        assertNull(init.getExternalExecutor());
    }

    @Test
    void testExternalExecutorIsUsedAndNotShutDown() throws Exception {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl(exec);
            assertSame(exec, init.getExternalExecutor());
            init.start();
            assertSame(exec, init.getActiveExecutor());
            init.get();
            assertFalse(exec.isShutdown(), "External executor must not be shut down by the initializer");
        } finally {
            exec.shutdown();
        }
    }

    @Test
    void testTemporaryExecutorCreatedAndShutDownAfterCompletion() throws Exception {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        init.start();
        final ExecutorService activeExec = init.getActiveExecutor();
        assertNotNull(activeExec);
        init.get();
        // Give the finally-block shutdown call a brief moment, then verify.
        final boolean terminated = activeExec.awaitTermination(2, TimeUnit.SECONDS);
        assertTrue(terminated, "Temporary executor should have been shut down after task completion");
    }

    @Test
    void testSetExternalExecutorBeforeStart() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            init.setExternalExecutor(exec);
            assertSame(exec, init.getExternalExecutor());
        } finally {
            exec.shutdown();
        }
    }

    @Test
    void testSetExternalExecutorAfterStartThrows() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        init.start();
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            assertThrows(IllegalStateException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    init.setExternalExecutor(exec);
                }
            });
        } finally {
            exec.shutdown();
        }
    }

    @Test
    void testSetExternalExecutorNullIsPermitted() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        init.setExternalExecutor(null);
        assertNull(init.getExternalExecutor());
    }

    // ------------------------------------------------------------------
    // getTaskCount()
    // ------------------------------------------------------------------

    @Test
    void testGetTaskCountDefaultIsOne() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        assertEquals(1, init.getTaskCount());
    }

    // ------------------------------------------------------------------
    // Exception handling
    // ------------------------------------------------------------------

    @Test
    void testGetWrapsCheckedExceptionInConcurrentException() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        final Exception cause = new java.io.IOException("boom");
        init.exceptionToThrow = cause;
        init.start();
        final ConcurrentException ex = assertThrows(ConcurrentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex.getCause());
    }

    @Test
    void testGetRethrowsRuntimeExceptionDirectly() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        final RuntimeException cause = new IllegalArgumentException("runtime boom");
        init.exceptionToThrow = cause;
        init.start();
        final RuntimeException thrown = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, thrown);
    }

    @Test
    void testIsInitializedFalseAfterFailure() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        init.exceptionToThrow = new java.io.IOException("boom");
        init.start();
        try {
            init.get();
            fail("Expected ConcurrentException");
        } catch (final ConcurrentException e) {
            // expected
        }
        assertFalse(init.isInitialized(), "isInitialized() must be false after a failed initialization");
    }

    // ------------------------------------------------------------------
    // Future access / cancellation
    // ------------------------------------------------------------------

    @Test
    void testGetFutureAfterStartReturnsSameInstance() {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        init.start();
        final Future<Object> future1 = init.getFuture();
        final Future<Object> future2 = init.getFuture();
        assertNotNull(future1);
        assertSame(future1, future2);
    }

    @Test
    void testCancelFutureBeforeCompletionPreventsResult() throws Exception {
        final AbstractBackgroundInitializerTestImpl init = new AbstractBackgroundInitializerTestImpl();
        final CountDownLatch latch = new CountDownLatch(1);
        init.waitLatch = latch;
        init.start();
        final boolean cancelled = init.getFuture().cancel(true);
        assertTrue(cancelled);
        assertThrows(java.util.concurrent.CancellationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertFalse(init.isInitialized());
        latch.countDown();
    }

    // ------------------------------------------------------------------
    // Builder
    // ------------------------------------------------------------------

    @Test
    void testBuilderBuildsFunctioningInitializer() throws ConcurrentException {
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new FailableSupplier<String, Exception>() {
                    @Override
                    public String get() {
                        return "builder-result";
                    }
                })
                .get();
        init.start();
        assertEquals("builder-result", init.get());
    }

    @Test
    void testBuilderWithExternalExecutor() throws ConcurrentException {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                    .setInitializer(new FailableSupplier<String, Exception>() {
                        @Override
                        public String get() {
                            return "value";
                        }
                    })
                    .setExternalExecutor(exec)
                    .get();
            assertSame(exec, init.getExternalExecutor());
            init.start();
            assertEquals("value", init.get());
            assertFalse(exec.isShutdown());
        } finally {
            exec.shutdown();
        }
    }

    @Test
    void testBuilderDefaultInitializerReturnsNull() throws ConcurrentException {
        final BackgroundInitializer<Object> init = BackgroundInitializer.builder().get();
        init.start();
        assertNull(init.get());
    }

    @Test
    void testBuilderPropagatesCheckedExceptionAsConcurrentException() {
        final Exception cause = new java.io.IOException("builder boom");
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new FailableSupplier<String, Exception>() {
                    @Override
                    public String get() throws Exception {
                        throw cause;
                    }
                })
                .get();
        init.start();
        final ConcurrentException ex = assertThrows(ConcurrentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex.getCause());
    }

    // ------------------------------------------------------------------
    // close()
    // ------------------------------------------------------------------

    @Test
    void testCloseInvokesCloserWithResultAfterInitialization() throws ConcurrentException {
        final java.util.List<String> closedWith = new java.util.ArrayList<String>();
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new FailableSupplier<String, Exception>() {
                    @Override
                    public String get() {
                        return "closable-result";
                    }
                })
                .setCloser(new org.apache.commons.lang3.function.FailableConsumer<String, Exception>() {
                    @Override
                    public void accept(final String value) {
                        closedWith.add(value);
                    }
                })
                .get();
        init.start();
        init.get();
        init.close();
        assertEquals(1, closedWith.size());
        assertEquals("closable-result", closedWith.get(0));
    }

    @Test
    void testCloseDoesNothingBeforeInitializationCompletes() throws Exception {
        final java.util.List<String> closedWith = new java.util.ArrayList<String>();
        final CountDownLatch latch = new CountDownLatch(1);
        final BackgroundInitializer<String> init = BackgroundInitializer.<String>builder()
                .setInitializer(new FailableSupplier<String, Exception>() {
                    @Override
                    public String get() throws Exception {
                        latch.await();
                        return "late-result";
                    }
                })
                .setCloser(new org.apache.commons.lang3.function.FailableConsumer<String, Exception>() {
                    @Override
                    public void accept(final String value) {
                        closedWith.add(value);
                    }
                })
                .get();
        init.start();
        init.close();
        assertTrue(closedWith.isEmpty(), "closer must not run before initialization completes");
        latch.countDown();
        init.get();
    }
}
