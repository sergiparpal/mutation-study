/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StringEscapeUtils}.
 */
class StringEscapeUtilsAgentTest {

    @Test
    void testConstructor() {
        assertNotNull(new StringEscapeUtils());
    }

    // escapeJava / unescapeJava

    @Test
    void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    @Test
    void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    @Test
    void testEscapeJavaBasic() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    @Test
    void testEscapeJavaControlChars() {
        assertEquals("\\t\\n\\r\\f\\b", StringEscapeUtils.escapeJava("\t\n\r\f\b"));
    }

    @Test
    void testEscapeJavaBackslash() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    @Test
    void testEscapeJavaDoesNotEscapeForwardSlash() {
        assertEquals("/", StringEscapeUtils.escapeJava("/"));
    }

    @Test
    void testEscapeJavaUnicodeOutsideAscii() {
        assertEquals("\\u00E9", StringEscapeUtils.escapeJava("é"));
    }

    @Test
    void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    @Test
    void testUnescapeJavaBasic() {
        assertEquals("He didn't say, \"Stop!\"", StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
    }

    @Test
    void testUnescapeJavaUnicode() {
        assertEquals("é", StringEscapeUtils.unescapeJava("\\u00e9"));
    }

    @Test
    void testUnescapeJavaOctal() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\101"));
    }

    @Test
    void testUnescapeJavaInvalidUnicodeThrows() {
        try {
            StringEscapeUtils.unescapeJava("\\uZZZZ");
            throw new AssertionError("expected RuntimeException");
        } catch (final RuntimeException expected) {
            // expected: malformed \\u escape is not valid hex
        }
    }

    @Test
    void testUnescapeJavaLoneBackslashIsRemoved() {
        assertEquals("", StringEscapeUtils.unescapeJava("\\"));
    }

    // escapeEcmaScript / unescapeEcmaScript

    @Test
    void testEscapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.escapeEcmaScript(null));
    }

    @Test
    void testEscapeEcmaScriptQuotesAndSlash() {
        assertEquals("He didn\\'t say, \\\"Stop!\\\"", StringEscapeUtils.escapeEcmaScript("He didn't say, \"Stop!\""));
        assertEquals("\\/", StringEscapeUtils.escapeEcmaScript("/"));
    }

    @Test
    void testUnescapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.unescapeEcmaScript(null));
    }

    @Test
    void testUnescapeEcmaScriptBasic() {
        assertEquals("'", StringEscapeUtils.unescapeEcmaScript("\\'"));
    }

    @Test
    void testUnescapeEcmaScriptSameTranslatorAsJava() {
        assertSame(StringEscapeUtils.UNESCAPE_JAVA, StringEscapeUtils.UNESCAPE_ECMASCRIPT);
    }

    // escapeJson / unescapeJson

    @Test
    void testEscapeJsonNull() {
        assertNull(StringEscapeUtils.escapeJson(null));
    }

    @Test
    void testEscapeJsonQuotesAndSlash() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJson("He didn't say, \"Stop!\""));
        assertEquals("\\/", StringEscapeUtils.escapeJson("/"));
    }

    @Test
    void testUnescapeJsonNull() {
        assertNull(StringEscapeUtils.unescapeJson(null));
    }

    @Test
    void testUnescapeJsonBasic() {
        assertEquals("\"", StringEscapeUtils.unescapeJson("\\\""));
    }

    @Test
    void testUnescapeJsonSameTranslatorAsJava() {
        assertSame(StringEscapeUtils.UNESCAPE_JAVA, StringEscapeUtils.UNESCAPE_JSON);
    }

    // escapeHtml3 / unescapeHtml3

    @Test
    void testEscapeHtml3Null() {
        assertNull(StringEscapeUtils.escapeHtml3(null));
    }

    @Test
    void testEscapeHtml3Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml3("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeHtml3DoesNotEscapeHtml4OnlyEntities() {
        // euro sign is only in the HTML 4.0 extended entity set, not HTML 3.0
        assertEquals("€", StringEscapeUtils.escapeHtml3("€"));
    }

    @Test
    void testUnescapeHtml3Null() {
        assertNull(StringEscapeUtils.unescapeHtml3(null));
    }

    @Test
    void testUnescapeHtml3Basic() {
        assertEquals("<", StringEscapeUtils.unescapeHtml3("&lt;"));
    }

    @Test
    void testUnescapeHtml3NumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeHtml3("&#65;"));
    }

    @Test
    void testUnescapeHtml3UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml3("&gt;&zzzz;x"));
    }

    // escapeHtml4 / unescapeHtml4

    @Test
    void testEscapeHtml4Null() {
        assertNull(StringEscapeUtils.escapeHtml4(null));
    }

    @Test
    void testEscapeHtml4Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml4("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeHtml4ExtendedEntity() {
        assertEquals("&euro;", StringEscapeUtils.escapeHtml4("€"));
    }

    @Test
    void testUnescapeHtml4Null() {
        assertNull(StringEscapeUtils.unescapeHtml4(null));
    }

    @Test
    void testUnescapeHtml4Basic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml4("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    void testUnescapeHtml4UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml4("&gt;&zzzz;x"));
    }

    // escapeXml / escapeXml10 / escapeXml11 / unescapeXml

    @Test
    void testEscapeXmlDeprecatedNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    @Test
    void testEscapeXmlDeprecatedBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeXmlDeprecatedDoesNotEscapeHighUnicode() {
        assertEquals("é", StringEscapeUtils.escapeXml("é"));
    }

    @Test
    void testEscapeXml10Null() {
        assertNull(StringEscapeUtils.escapeXml10(null));
    }

    @Test
    void testEscapeXml10BasicEntities() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeXml10("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeXml10RemovesControlChars() {
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0000b"));
    }

    @Test
    void testEscapeXml10KeepsTabNewlineCr() {
        assertEquals("a\tb\nc\rd", StringEscapeUtils.escapeXml10("a\tb\nc\rd"));
    }

    @Test
    void testEscapeXml10EscapesHighControlRange() {
        assertEquals("&#127;", StringEscapeUtils.escapeXml10("\u007f"));
    }

    @Test
    void testEscapeXml11Null() {
        assertNull(StringEscapeUtils.escapeXml11(null));
    }

    @Test
    void testEscapeXml11RemovesNullByte() {
        assertEquals("ab", StringEscapeUtils.escapeXml11("a\u0000b"));
    }

    @Test
    void testEscapeXml11EscapesLowControlChar() {
        assertEquals("&#1;", StringEscapeUtils.escapeXml11("\u0001"));
    }

    @Test
    void testEscapeXml11KeepsVerticalTabEscaped() {
        assertEquals("&#11;", StringEscapeUtils.escapeXml11("\u000b"));
    }

    @Test
    void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    void testUnescapeXmlBasic() {
        assertEquals("<&", StringEscapeUtils.unescapeXml("&lt;&amp;"));
    }

    @Test
    void testUnescapeXmlNumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeXml("&#65;"));
    }

    @Test
    void testUnescapeXmlApostrophe() {
        assertEquals("'", StringEscapeUtils.unescapeXml("&apos;"));
    }

    // escapeCsv / unescapeCsv

    @Test
    void testEscapeCsvNull() {
        assertNull(StringEscapeUtils.escapeCsv(null));
    }

    @Test
    void testEscapeCsvEmpty() {
        assertEquals("", StringEscapeUtils.escapeCsv(""));
    }

    @Test
    void testEscapeCsvNoSpecialChars() {
        assertEquals("abc", StringEscapeUtils.escapeCsv("abc"));
    }

    @Test
    void testEscapeCsvWithComma() {
        assertEquals("\"a,b\"", StringEscapeUtils.escapeCsv("a,b"));
    }

    @Test
    void testEscapeCsvWithQuote() {
        assertEquals("\"a\"\"b\"", StringEscapeUtils.escapeCsv("a\"b"));
    }

    @Test
    void testEscapeCsvWithNewline() {
        assertEquals("\"a\nb\"", StringEscapeUtils.escapeCsv("a\nb"));
    }

    @Test
    void testUnescapeCsvNull() {
        assertNull(StringEscapeUtils.unescapeCsv(null));
    }

    @Test
    void testUnescapeCsvUnquoted() {
        assertEquals("abc", StringEscapeUtils.unescapeCsv("abc"));
    }

    @Test
    void testUnescapeCsvQuotedWithEscapedQuote() {
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("\"a\"\"b\""));
    }

    @Test
    void testUnescapeCsvQuotedWithComma() {
        assertEquals("a,b", StringEscapeUtils.unescapeCsv("\"a,b\""));
    }

    @Test
    void testUnescapeCsvSingleQuoteCharLeftAlone() {
        // a single quote char is shorter than the minimum length of 2 for a quoted value
        assertEquals("\"", StringEscapeUtils.unescapeCsv("\""));
    }

    @Test
    void testRoundTripCsv() {
        final String original = "a,\"complex\"\nvalue";
        final String escaped = StringEscapeUtils.escapeCsv(original);
        assertEquals(original, StringEscapeUtils.unescapeCsv(escaped));
    }

    @Test
    void testRoundTripJava() {
        final String original = "Tab\tNewline\nQuote\"Backslash\\";
        final String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    @Test
    void testRoundTripHtml4() {
        final String original = "<a href=\"test\">O'Brien & Co</a>";
        final String escaped = StringEscapeUtils.escapeHtml4(original);
        assertEquals(original, StringEscapeUtils.unescapeHtml4(escaped));
    }
}
