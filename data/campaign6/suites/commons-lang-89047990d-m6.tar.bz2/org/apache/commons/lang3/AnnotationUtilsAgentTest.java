/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link AnnotationUtils}.
 */
class AnnotationUtilsAgentTest {

    enum SampleEnum {
        ONE, TWO
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface Nested {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface Sample {
        String str();
        int num();
        int[] arr();
        Class<?> cls();
        Nested nested();
        SampleEnum unit();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface Empty {
    }

    static class Holder {

        @Sample(str = "hello", num = 42, arr = { 1, 2, 3 }, cls = String.class, nested = @Nested("n1"), unit = SampleEnum.TWO)
        public void methodA() {
            // fixture
        }

        @Sample(str = "hello", num = 42, arr = { 1, 2, 3 }, cls = String.class, nested = @Nested("n1"), unit = SampleEnum.TWO)
        public void methodB() {
            // fixture
        }

        @Sample(str = "different", num = 42, arr = { 1, 2, 3 }, cls = String.class, nested = @Nested("n1"), unit = SampleEnum.TWO)
        public void methodDifferentStr() {
            // fixture
        }

        @Sample(str = "hello", num = 42, arr = { 9, 9, 9 }, cls = String.class, nested = @Nested("n1"), unit = SampleEnum.TWO)
        public void methodDifferentArr() {
            // fixture
        }

        @Sample(str = "hello", num = 42, arr = { 1, 2, 3 }, cls = String.class, nested = @Nested("different"), unit = SampleEnum.TWO)
        public void methodDifferentNested() {
            // fixture
        }

        @Empty
        public void methodEmpty() {
            // fixture
        }
    }

    private static Sample sampleOf(final String methodName) throws NoSuchMethodException {
        return Holder.class.getMethod(methodName).getAnnotation(Sample.class);
    }

    @Test
    void testEqualsSameInstance() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        assertTrue(AnnotationUtils.equals(a, a));
    }

    @Test
    void testEqualsBothNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    void testEqualsOneNull() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        assertFalse(AnnotationUtils.equals(a, null));
        assertFalse(AnnotationUtils.equals(null, a));
    }

    @Test
    void testEqualsEquivalentAnnotationsFromDifferentProxies() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Sample b = sampleOf("methodB");
        assertNotSame(a, b);
        assertTrue(AnnotationUtils.equals(a, b));
        assertTrue(AnnotationUtils.equals(b, a));
    }

    @Test
    void testEqualsDifferentStringMember() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Sample other = sampleOf("methodDifferentStr");
        assertFalse(AnnotationUtils.equals(a, other));
    }

    @Test
    void testEqualsDifferentArrayMember() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Sample other = sampleOf("methodDifferentArr");
        assertFalse(AnnotationUtils.equals(a, other));
    }

    @Test
    void testEqualsDifferentNestedAnnotationMember() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Sample other = sampleOf("methodDifferentNested");
        assertFalse(AnnotationUtils.equals(a, other));
    }

    @Test
    void testEqualsDifferentAnnotationTypes() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Empty empty = Holder.class.getMethod("methodEmpty").getAnnotation(Empty.class);
        assertFalse(AnnotationUtils.equals(a, empty));
    }

    @Test
    void testEqualsWithNullAnnotationTypeThrows() throws NoSuchMethodException {
        final Sample broken = newProxyWithNullAnnotationType();
        final Sample a = sampleOf("methodA");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                AnnotationUtils.equals(broken, a);
            }
        });
    }

    @Test
    void testHashCodeConsistentAcrossEquivalentProxies() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Sample b = sampleOf("methodB");
        assertEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(b));
    }

    @Test
    void testHashCodeMatchesJdkAnnotationHashCode() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        assertEquals(a.hashCode(), AnnotationUtils.hashCode(a));
    }

    @Test
    void testHashCodeDiffersForDifferentMembers() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final Sample other = sampleOf("methodDifferentStr");
        assertNotEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(other));
    }

    @Test
    void testHashCodeThrowsIllegalStateExceptionOnNullMember() {
        final Sample proxyWithNullMember = newProxyWithNullMember();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                AnnotationUtils.hashCode(proxyWithNullMember);
            }
        });
    }

    @Test
    void testToStringNotNullAndContainsMemberValues() throws NoSuchMethodException {
        final Sample a = sampleOf("methodA");
        final String s = AnnotationUtils.toString(a);
        assertNotNull(s);
        assertTrue(s.contains("hello"), s);
        assertTrue(s.contains("str"), s);
        assertTrue(s.contains("num"), s);
        assertTrue(s.contains("42"), s);
    }

    @Test
    void testToStringOnAnnotationWithoutMembers() throws NoSuchMethodException {
        final Empty empty = Holder.class.getMethod("methodEmpty").getAnnotation(Empty.class);
        final String s = AnnotationUtils.toString(empty);
        assertNotNull(s);
        assertTrue(s.contains("()"), s);
    }

    @Test
    void testIsValidAnnotationMemberTypeNull() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    void testIsValidAnnotationMemberTypePrimitives() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(boolean.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(double.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeStringAndClass() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeEnumAndAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleEnum.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Sample.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeSingleDimensionArrays() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
    }

    @Test
    void testIsValidAnnotationMemberTypeInvalidTypes() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(java.util.List.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeMultiDimensionalArrayIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(int[][].class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
    }

    @Test
    void testDeprecatedPublicConstructor() {
        final AnnotationUtils instance = new AnnotationUtils();
        assertNotNull(instance);
    }

    private static Sample newProxyWithNullAnnotationType() {
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                final String name = method.getName();
                if ("annotationType".equals(name)) {
                    return null;
                }
                if ("toString".equals(name)) {
                    return "brokenSample";
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(0);
                }
                if ("equals".equals(name)) {
                    return Boolean.FALSE;
                }
                return null;
            }
        };
        return (Sample) Proxy.newProxyInstance(AnnotationUtilsAgentTest.class.getClassLoader(),
                new Class<?>[] { Sample.class }, handler);
    }

    private static Sample newProxyWithNullMember() {
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                final String name = method.getName();
                if ("annotationType".equals(name)) {
                    return Sample.class;
                }
                if ("num".equals(name)) {
                    return Integer.valueOf(42);
                }
                if ("str".equals(name)) {
                    return "hello";
                }
                if ("arr".equals(name)) {
                    return new int[] { 1, 2, 3 };
                }
                if ("cls".equals(name)) {
                    return null;
                }
                if ("nested".equals(name)) {
                    try {
                        return sampleOf("methodA").nested();
                    } catch (final NoSuchMethodException e) {
                        throw new IllegalStateException(e);
                    }
                }
                if ("unit".equals(name)) {
                    return SampleEnum.TWO;
                }
                if ("toString".equals(name)) {
                    return "proxyWithNullMember";
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(0);
                }
                if ("equals".equals(name)) {
                    return Boolean.FALSE;
                }
                return null;
            }
        };
        return (Sample) Proxy.newProxyInstance(AnnotationUtilsAgentTest.class.getClassLoader(),
                new Class<?>[] { Sample.class }, handler);
    }
}
