/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MemberUtils}.
 */
public class MemberUtilsAgentTest {

    public static class PublicClass {
        public PublicClass() {
        }

        public PublicClass(final int i) {
        }

        public void publicMethod() {
        }

        public void publicMethod(final int i) {
        }

        public void varArgsMethod(final String first, final int... rest) {
        }

        private void privateMethod() {
        }
    }

    // --- isPublic / isStatic / isPackage / isAccessible ---

    @Test
    public void testIsPublicNullMember() {
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    public void testIsPublicTrue() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicFalse() throws Exception {
        final Method m = PublicClass.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsStaticNullMember() {
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    public void testIsStaticTrue() throws Exception {
        final Method m = StaticHolder.class.getDeclaredMethod("staticMethod");
        assertTrue(MemberUtils.isStatic(m));
    }

    @Test
    public void testIsStaticFalse() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod");
        assertFalse(MemberUtils.isStatic(m));
    }

    static class StaticHolder {
        static void staticMethod() {
        }
    }

    @Test
    public void testIsPackagePublicModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
    }

    @Test
    public void testIsPackageProtectedModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
    }

    @Test
    public void testIsPackagePrivateModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    public void testIsPackageNoAccessModifier() {
        // No access modifier set at all => package-private.
        assertTrue(MemberUtils.isPackage(Modifier.FINAL));
        assertTrue(MemberUtils.isPackage(0));
    }

    @Test
    public void testIsAccessiblePublicNonSynthetic() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isAccessible(m));
    }

    @Test
    public void testIsAccessiblePrivateIsFalse() throws Exception {
        final Method m = PublicClass.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isAccessible(m));
    }

    // --- isMatchingMethod ---

    @Test
    public void testIsMatchingMethodExactMatch() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod", int.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {Integer.TYPE}));
    }

    @Test
    public void testIsMatchingMethodNoArgsMatchesEmptyArray() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[0]));
    }

    @Test
    public void testIsMatchingMethodMismatch() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod", int.class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingMethodWrongArgCount() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod", int.class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] {Integer.TYPE, Integer.TYPE}));
    }

    @Test
    public void testIsMatchingMethodVarArgsNoneProvided() throws Exception {
        final Method m = PublicClass.class.getMethod("varArgsMethod", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {String.class}));
    }

    @Test
    public void testIsMatchingMethodVarArgsSomeProvided() throws Exception {
        final Method m = PublicClass.class.getMethod("varArgsMethod", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {String.class, Integer.TYPE, Integer.TYPE}));
    }

    @Test
    public void testIsMatchingMethodVarArgsExplicitArray() throws Exception {
        final Method m = PublicClass.class.getMethod("varArgsMethod", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] {String.class, int[].class}));
    }

    @Test
    public void testIsMatchingMethodVarArgsFixedPartMismatch() throws Exception {
        final Method m = PublicClass.class.getMethod("varArgsMethod", String.class, int[].class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] {Integer.TYPE, Integer.TYPE}));
    }

    @Test
    public void testIsMatchingMethodVarArgsTooFewArgs() throws Exception {
        final Method m = PublicClass.class.getMethod("varArgsMethod", String.class, int[].class);
        // Fewer args than required fixed parameters: not varargs-eligible, not exact match either.
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[0]));
    }

    // --- isMatchingConstructor ---

    @Test
    public void testIsMatchingConstructorExactMatch() throws Exception {
        final Constructor<?> c = PublicClass.class.getConstructor(int.class);
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class[] {Integer.TYPE}));
    }

    @Test
    public void testIsMatchingConstructorNoArgsMatchesEmpty() throws Exception {
        final Constructor<?> c = PublicClass.class.getConstructor();
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class[0]));
    }

    @Test
    public void testIsMatchingConstructorMismatch() throws Exception {
        final Constructor<?> c = PublicClass.class.getConstructor(int.class);
        assertFalse(MemberUtils.isMatchingConstructor(c, new Class[] {String.class}));
    }

    // --- compareMethodFit ---

    public static class FitClass {
        public void m(final Object o) {
        }

        public void m(final String s) {
        }

        public void m2(final Object first, final Object... rest) {
        }
    }

    @Test
    public void testCompareMethodFitMoreSpecificWins() throws Exception {
        final Method objMethod = FitClass.class.getMethod("m", Object.class);
        final Method strMethod = FitClass.class.getMethod("m", String.class);
        final int result = MemberUtils.compareMethodFit(strMethod, objMethod, new Class[] {String.class});
        assertTrue(result < 0, "more specific method should have a lower (better) cost");
    }

    @Test
    public void testCompareMethodFitReverseIsPositive() throws Exception {
        final Method objMethod = FitClass.class.getMethod("m", Object.class);
        final Method strMethod = FitClass.class.getMethod("m", String.class);
        final int result = MemberUtils.compareMethodFit(objMethod, strMethod, new Class[] {String.class});
        assertTrue(result > 0, "less specific method should have a higher (worse) cost");
    }

    @Test
    public void testCompareMethodFitEqualIsZero() throws Exception {
        final Method m1 = FitClass.class.getMethod("m", String.class);
        final Method m2 = FitClass.class.getMethod("m", String.class);
        assertEquals(0, MemberUtils.compareMethodFit(m1, m2, new Class[] {String.class}));
    }

    // --- compareConstructorFit ---

    public static class CtorFitClass {
        public CtorFitClass(final Object o) {
        }

        public CtorFitClass(final String s) {
        }
    }

    @Test
    public void testCompareConstructorFitMoreSpecificWins() throws Exception {
        final Constructor<?> objCtor = CtorFitClass.class.getConstructor(Object.class);
        final Constructor<?> strCtor = CtorFitClass.class.getConstructor(String.class);
        final int result = MemberUtils.compareConstructorFit(strCtor, objCtor, new Class[] {String.class});
        assertTrue(result < 0);
    }

    // --- setAccessibleWorkaround ---

    @Test
    public void testSetAccessibleWorkaroundNullReturnsNull() {
        assertEquals(null, MemberUtils.setAccessibleWorkaround(null));
    }

    @Test
    public void testSetAccessibleWorkaroundAlreadyAccessibleFlagIsUnchanged() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod");
        m.setAccessible(true);
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundPublicMemberOfPublicClassIsNotForced() throws Exception {
        final Method m = PublicClass.class.getMethod("publicMethod");
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        // Declaring class is public (not package-default), so the workaround does not
        // need to, and does not, force the accessible flag.
        assertFalse(result.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundPublicMemberOfPackageClassIsForced() throws Exception {
        final Method m = PackageDefaultClass.class.getMethod("publicMethodOnPackageClass");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundPrivateFieldStaysInaccessibleButReturnsObject() throws Exception {
        final Field f = PrivateFieldHolder.class.getDeclaredField("value");
        final AccessibleObject result = MemberUtils.setAccessibleWorkaround(f);
        assertNotNull(result);
        assertSame(f, result);
        // Declaring class is public (not package-default), and member is private,
        // so the workaround does not attempt to force accessibility.
        assertFalse(f.isAccessible());
    }

    public static class PrivateFieldHolder {
        private int value = 42;
    }
}

// Package-default (no access modifier) top-level class with a public method, used to
// exercise the "public member of a default-access class" workaround path.
class PackageDefaultClass {
    public void publicMethodOnPackageClass() {
    }
}
