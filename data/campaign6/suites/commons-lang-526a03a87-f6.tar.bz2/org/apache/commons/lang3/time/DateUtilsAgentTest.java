/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private static Calendar newCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Date newDate(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ----- add* methods -----

    @Test
    void testAddDays() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.addDays(date, 3);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(31, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
    }

    @Test
    void testAddDaysDoesNotMutateOriginal() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long originalMillis = date.getTime();
        DateUtils.addDays(date, 5);
        assertEquals(originalMillis, date.getTime());
    }

    @Test
    void testAddDaysNegativeAmount() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date result = DateUtils.addDays(date, -28);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddDaysNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.addDays(null, 1));
    }

    @Test
    void testAddHours() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 23, 0, 0, 0);
        final Date result = DateUtils.addHours(date, 2);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(29, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddMinutes() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 59, 0, 0);
        final Date result = DateUtils.addMinutes(date, 2);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, c.get(Calendar.MINUTE));
    }

    @Test
    void testAddSeconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 59, 0);
        final Date result = DateUtils.addSeconds(date, 2);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.MINUTE));
        assertEquals(1, c.get(Calendar.SECOND));
    }

    @Test
    void testAddMilliseconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 999);
        final Date result = DateUtils.addMilliseconds(date, 2);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(1, c.get(Calendar.SECOND));
        assertEquals(1, c.get(Calendar.MILLISECOND));
    }

    @Test
    void testAddMonths() {
        final Date date = newDate(2002, Calendar.DECEMBER, 15, 0, 0, 0, 0);
        final Date result = DateUtils.addMonths(date, 2);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(2003, c.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(15, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddWeeks() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date result = DateUtils.addWeeks(date, 1);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddYears() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date result = DateUtils.addYears(date, -2);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(2000, c.get(Calendar.YEAR));
    }

    // ----- ceiling / round / truncate -----

    @Test
    void testCeilingHour() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(date, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result);
    }

    @Test
    void testCeilingMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), result);
    }

    @Test
    void testCeilingCalendarOverload() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(cal, Calendar.HOUR);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
        // original calendar not mutated
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingObjectOverloadDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Object result = DateUtils.ceiling((Object) date, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result);
    }

    @Test
    void testCeilingObjectOverloadCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling((Object) cal, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result);
    }

    @Test
    void testCeilingObjectOverloadInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling((Object) "not a date", Calendar.HOUR));
    }

    @Test
    void testCeilingNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Date) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Calendar) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Object) null, Calendar.HOUR));
    }

    @Test
    void testCeilingInvalidFieldThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.ceiling(date, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testCeilingArithmeticExceptionForHugeYear() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(cal, Calendar.HOUR));
    }

    @Test
    void testRoundHour() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.round(date, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result);
    }

    @Test
    void testRoundMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.round(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), result);
    }

    @Test
    void testRoundDownHour() {
        // minutes < 30, should round down to the current hour
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 15, 1, 231);
        final Date result = DateUtils.round(date, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), result);
    }

    @Test
    void testRoundSemiMonth() {
        // Day 12 is in the upper half of [1,15], rounds up to the 16th
        final Date date = newDate(2002, Calendar.MARCH, 12, 0, 0, 0, 0);
        final Date result = DateUtils.round(date, DateUtils.SEMI_MONTH);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(16, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
    }

    @Test
    void testRoundAmPm() {
        // Hour 9 is in the upper half of the AM period, rounds up to noon the same day
        final Date date = newDate(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        final Date result = DateUtils.round(date, Calendar.AM_PM);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(12, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testRoundAmPmRollsIntoNextDay() {
        // Hour 18 is in the upper half of the PM period, rounds up to midnight the next day
        final Date date = newDate(2002, Calendar.MARCH, 28, 18, 0, 0, 0);
        final Date result = DateUtils.round(date, Calendar.AM_PM);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(29, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testRoundObjectOverloadInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.round((Object) Integer.valueOf(1), Calendar.HOUR));
    }

    @Test
    void testRoundNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.round((Date) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Calendar) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Object) null, Calendar.HOUR));
    }

    @Test
    void testRoundInvalidFieldThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.round(date, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testTruncateHour() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.truncate(date, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), result);
    }

    @Test
    void testTruncateMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.truncate(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), result);
    }

    @Test
    void testTruncateMilliSecondFieldIsNoOp() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.truncate(cal, Calendar.MILLISECOND);
        assertEquals(231, result.get(Calendar.MILLISECOND));
    }

    @Test
    void testTruncateObjectOverloadInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.truncate((Object) new Object(), Calendar.HOUR));
    }

    @Test
    void testTruncateNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Date) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Calendar) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Object) null, Calendar.HOUR));
    }

    @Test
    void testTruncateArithmeticExceptionForHugeYear() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.truncate(cal, Calendar.HOUR));
    }

    // ----- getFragmentInXxx -----

    @Test
    void testGetFragmentInDaysMonth() {
        final Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        final Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInDaysYear() {
        final Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));
        final Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
    }

    @Test
    void testGetFragmentInDaysMillisecondAlwaysZero() {
        final Date jan28 = newDate(2008, Calendar.JANUARY, 28, 7, 15, 10, 538);
        assertEquals(0, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(jan1, Calendar.DAY_OF_YEAR));
        assertEquals(7, DateUtils.getFragmentInHours(jan1, Calendar.MONTH));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        // Jan 1 has no days-into-month offset, so MONTH and HOUR_OF_DAY-equivalent minutes coincide
        assertEquals(435, DateUtils.getFragmentInMinutes(jan1, Calendar.MONTH));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(jan6, Calendar.HOUR_OF_DAY));
        // 5 full days plus 7h15m: (5*24*60) + (7*60+15)
        assertEquals(7635, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(jan1, Calendar.MINUTE));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110, DateUtils.getFragmentInSeconds(jan6, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(jan1, Calendar.SECOND));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MINUTE));
        assertEquals(0, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentCalendarOverload() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentUnsupportedFieldThrows() {
        final Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testGetFragmentNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR));
    }

    // ----- isSameDay / isSameInstant / isSameLocalTime -----

    @Test
    void testIsSameDayTrueForDifferentTimesSameDay() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    @Test
    void testIsSameDayFalseForDifferentDays() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(d1, d2));
    }

    @Test
    void testIsSameDayCalendarOverload() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
    }

    @Test
    void testIsSameDayNullThrowsNpe() {
        final Date d = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Date) null, d));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay(d, (Date) null));
    }

    @Test
    void testIsSameInstantTrue() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 123);
        final Date d2 = new Date(d1.getTime());
        assertTrue(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    void testIsSameInstantFalseForDifferentMillis() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 123);
        final Date d2 = new Date(d1.getTime() + 1);
        assertFalse(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    void testIsSameInstantIgnoresCalendarFields() {
        // Same millisecond instant, different calendar types/fields set differently is irrelevant;
        // isSameInstant(Calendar, Calendar) only compares getTime().getTime().
        final Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(123456789L);
        final Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c2.setTimeInMillis(123456789L);
        assertTrue(DateUtils.isSameInstant(c1, c2));
    }

    @Test
    void testIsSameInstantNullThrowsNpe() {
        final Date d = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Date) null, d));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Calendar) null, Calendar.getInstance()));
    }

    @Test
    void testIsSameLocalTimeTrue() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 123);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 123);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeRequiresSameCalendarClass() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 123);
        final Calendar c2 = new java.util.GregorianCalendar();
        c2.setTimeInMillis(c1.getTimeInMillis());
        assertEquals(c1.getClass() == c2.getClass(), DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeFalseForDifferentFields() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 123);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 124);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(null, Calendar.getInstance()));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(Calendar.getInstance(), null));
    }

    // ----- iterator -----

    @Test
    void testIteratorRangeMonthSunday() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        final Calendar first = it.next();
        assertEquals(Calendar.FEBRUARY, first.get(Calendar.MONTH));
        assertEquals(24, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(Calendar.APRIL, last.get(Calendar.MONTH));
        assertEquals(6, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(42, count);
    }

    @Test
    void testIteratorRangeMonthMonday() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_MONDAY);
        final Calendar first = it.next();
        assertEquals(Calendar.FEBRUARY, first.get(Calendar.MONTH));
        assertEquals(25, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MONDAY, first.get(Calendar.DAY_OF_WEEK));
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
        }
        assertEquals(Calendar.MARCH, last.get(Calendar.MONTH));
        assertEquals(31, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SUNDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorRangeWeekSunday() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Calendar first = it.next();
        assertEquals(17, first.get(Calendar.DAY_OF_MONTH));
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(23, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(7, count);
    }

    @Test
    void testIteratorRangeWeekMonday() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(18, it.next().get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorRangeWeekRelative() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        final Calendar first = it.next();
        assertEquals(20, first.get(Calendar.DAY_OF_MONTH));
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
        }
        assertEquals(26, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorRangeWeekCenter() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        final Calendar first = it.next();
        assertEquals(17, first.get(Calendar.DAY_OF_MONTH));
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
        }
        assertEquals(23, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorInvalidRangeStyleThrows() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(focus, -999));
    }

    @Test
    void testIteratorNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorObjectOverloadInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.iterator((Object) "nope", DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorDateOverload() {
        final Date focus = newDate(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(17, it.next().get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorExhaustionThrowsNoSuchElement() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    // ----- parseDate / parseDateStrictly -----

    @Test
    void testParseDateFirstPatternFails() throws ParseException {
        final Date result = DateUtils.parseDate("2008-10-01", "yyyy/MM/dd", "yyyy-MM-dd");
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(2008, c.get(Calendar.YEAR));
        assertEquals(Calendar.OCTOBER, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNoPatternMatchesThrowsParseException() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("garbage", "yyyy-MM-dd"));
    }

    @Test
    void testParseDatePartialMatchThrows() {
        // Whole string must be consumed by the pattern.
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2001-02-28extra", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateLenientAllowsOverflow() throws ParseException {
        final Date result = DateUtils.parseDate("2001-02-30", "yyyy-MM-dd");
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(2, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly("2001-02-30", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateStrictlyAcceptsValidDate() throws ParseException {
        final Date result = DateUtils.parseDateStrictly("2001-02-28", "yyyy-MM-dd");
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(2001, c.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNullStringThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate(null, "yyyy-MM-dd"));
    }

    @Test
    void testParseDateNullPatternsThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate("2001-02-28", (String[]) null));
    }

    @Test
    void testParseDateStrictlyNullStringThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDateStrictly(null, "yyyy-MM-dd"));
    }

    @Test
    void testParseDateEmptyPatternsThrowsParseException() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2001-02-28"));
    }

    // ----- set* methods -----

    @Test
    void testSetDays() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setDays(date, 20);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(20, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
    }

    @Test
    void testSetDaysInvalidAmountThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 0));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 32));
    }

    @Test
    void testSetHours() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setHours(date, 5);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(5, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testSetHoursInvalidAmountThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, -1));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, 24));
    }

    @Test
    void testSetMinutes() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setMinutes(date, 42);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(42, c.get(Calendar.MINUTE));
    }

    @Test
    void testSetMinutesInvalidAmountThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, 60));
    }

    @Test
    void testSetSeconds() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setSeconds(date, 42);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(42, c.get(Calendar.SECOND));
    }

    @Test
    void testSetSecondsInvalidAmountThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, 60));
    }

    @Test
    void testSetMilliseconds() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setMilliseconds(date, 42);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(42, c.get(Calendar.MILLISECOND));
    }

    @Test
    void testSetMillisecondsInvalidAmountThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, 1000));
    }

    @Test
    void testSetMonths() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setMonths(date, Calendar.DECEMBER);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(Calendar.DECEMBER, c.get(Calendar.MONTH));
    }

    @Test
    void testSetMonthsInvalidAmountThrows() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, 12));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, -1));
    }

    @Test
    void testSetYears() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Date result = DateUtils.setYears(date, 1999);
        final Calendar c = Calendar.getInstance();
        c.setTime(result);
        assertEquals(1999, c.get(Calendar.YEAR));
    }

    @Test
    void testSetNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.setYears(null, 1999));
        assertThrows(NullPointerException.class, () -> DateUtils.setDays(null, 1));
    }

    // ----- toCalendar -----

    @Test
    void testToCalendar() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final Calendar c = DateUtils.toCalendar(date);
        assertEquals(date, c.getTime());
    }

    @Test
    void testToCalendarNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null));
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar c = DateUtils.toCalendar(date, tz);
        assertEquals(tz, c.getTimeZone());
        assertEquals(date, c.getTime());
    }

    @Test
    void testToCalendarWithTimeZoneNullDateThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC")));
    }

    @Test
    void testToCalendarWithTimeZoneNullTzThrowsNpe() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(date, null));
    }

    // ----- toLocalDateTime / toOffsetDateTime / toZonedDateTime -----

    private static Date newUtcDate(final int year, final int month, final int day,
            final int hour, final int minute, final int second) {
        final Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(year, month, day, hour, minute, second);
        return c.getTime();
    }

    @Test
    void testToLocalDateTime() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Date date = newUtcDate(2002, Calendar.MARCH, 5, 10, 11, 12);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, utc);
        assertEquals(2002, ldt.getYear());
        assertEquals(3, ldt.getMonthValue());
        assertEquals(5, ldt.getDayOfMonth());
        assertEquals(10, ldt.getHour());
        assertEquals(11, ldt.getMinute());
        assertEquals(12, ldt.getSecond());
    }

    @Test
    void testToOffsetDateTime() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Date date = newUtcDate(2002, Calendar.MARCH, 5, 10, 11, 12);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, utc);
        assertEquals(2002, odt.getYear());
        assertEquals(10, odt.getHour());
        assertEquals(java.time.ZoneOffset.UTC, odt.getOffset());
    }

    @Test
    void testToZonedDateTime() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Date date = newUtcDate(2002, Calendar.MARCH, 5, 10, 11, 12);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, utc);
        assertEquals(2002, zdt.getYear());
        assertEquals(10, zdt.getHour());
    }

    @Test
    void testToLocalDateTimeDefaultTimeZoneOverload() {
        final Date date = newDate(2002, Calendar.MARCH, 5, 10, 11, 12, 13);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date);
        assertEquals(2002, ldt.getYear());
        assertEquals(5, ldt.getDayOfMonth());
    }

    @Test
    void testToLocalDateTimeNullDateThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.toLocalDateTime(null));
    }

    // ----- truncatedCompareTo / truncatedEquals -----

    @Test
    void testTruncatedCompareToDateLess() {
        final Date earlier = newDate(2002, Calendar.MARCH, 5, 10, 0, 0, 0);
        final Date later = newDate(2002, Calendar.MARCH, 5, 23, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) == 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.HOUR_OF_DAY) < 0);
    }

    @Test
    void testTruncatedCompareToCalendarOverload() {
        final Calendar earlier = newCalendar(2002, Calendar.MARCH, 5, 10, 0, 0, 0);
        final Calendar later = newCalendar(2002, Calendar.MARCH, 6, 10, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.MONTH) == 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
    }

    @Test
    void testTruncatedEqualsTrue() {
        final Date d1 = newDate(2002, Calendar.MARCH, 5, 10, 15, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 5, 23, 59, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncatedEqualsCalendarOverload() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 5, 10, 15, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 5, 10, 59, 0, 0);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.MINUTE));
    }

    @Test
    void testTruncatedCompareToNullThrowsNpe() {
        final Date d = newDate(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedCompareTo((Date) null, d, Calendar.DATE));
    }

    // ----- constants -----

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    // ----- public constructor -----

    @Test
    void testPublicConstructorDoesNotThrow() {
        assertNotNull(new DateUtils());
    }
}
