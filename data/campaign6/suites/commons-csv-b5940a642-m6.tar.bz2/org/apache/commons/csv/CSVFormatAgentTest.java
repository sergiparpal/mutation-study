/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum Header {
        Name, Email, Phone
    }

    @Test
    void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat(Constants.CR));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat(Constants.LF));
    }

    @Test
    void testDefaultFormat() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowDuplicateHeaderNames());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        final CSVFormat rebuilt = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        assertEquals(CSVFormat.RFC4180, rebuilt);
    }

    @Test
    void testPredefinedExcel() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testPredefinedMySql() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals('\t', format.getDelimiter());
        assertEquals('\\', (char) format.getEscapeCharacter());
        assertNull(format.getQuoteCharacter());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testValueOfLookupMatchesPredefined() {
        assertEquals(CSVFormat.Predefined.Default.getFormat(), CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.Predefined.MySQL.getFormat(), CSVFormat.valueOf("MySQL"));
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("DoesNotExist"));
    }

    @Test
    void testBuilderSetDelimiterEmptyThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("").get());
    }

    @Test
    void testBuilderSetDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(Constants.CR).get());
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(String.valueOf(Constants.LF)).get());
    }

    @Test
    void testBuilderSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setCommentMarker(Constants.LF).get());
    }

    @Test
    void testBuilderSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuote(Constants.CR).get());
    }

    @Test
    void testBuilderSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setEscape(Constants.LF).get());
    }

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter('!').setQuote('!').get());
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter('!').setEscape('!').get());
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter('!').setCommentMarker('!').get());
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('!').setCommentMarker('!').get());
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('!').setCommentMarker('!').get());
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.newFormat('!').builder().setQuoteMode(QuoteMode.NONE).get());
        assertEquals("Quote mode set to NONE but no escape character is set", e.getMessage());
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.newFormat('!').builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderDisallowedThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "A").get());
    }

    @Test
    void testDuplicateHeaderAllowAllSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("A", "A").get();
        assertArrayEquals(new String[] { "A", "A" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptySucceedsForBlanks() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "B", "").get();
        assertArrayEquals(new String[] { "A", "", "B", "" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyRejectsNonBlankDuplicate() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumClearsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final String[] header = { "one", "two", "three" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        final String[] copy = format.getHeader();
        copy[0] = "mutated";
        assertEquals("one", format.getHeader()[0]);
        assertNotSame(header, format.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("a", "b").get();
        final String[] comments = format.getHeaderComments();
        comments[0] = "mutated";
        assertEquals("a", format.getHeaderComments()[0]);
    }

    @Test
    void testSetHeaderCommentsAcceptsObjects() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(1, "two", null).get();
        assertArrayEquals(new String[] { "1", "two", null }, format.getHeaderComments());
    }

    @Test
    void testSetNullStringUpdatesQuotedNullString() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).setNullString("NULL").get();
        format.print(null, out, true);
        assertEquals("\"NULL\"", out.toString());
    }

    @Test
    void testSetMaxRowsNegativeMeansNoLimit() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(-5).get();
        assertEquals(-5, format.getMaxRows());
        assertFalse(format.useMaxRows());
    }

    @Test
    void testSetMaxRowsPositiveUsesLimit() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(3).get();
        assertEquals(3, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(3));
        assertFalse(format.useRow(4));
    }

    @Test
    void testBuildVsGetReturnDifferentInstances() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertNotSame(builder.get(), builder.build());
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setQuote('\'').setNullString("N/A").get();
        final CSVFormat copyFormat = Builder.create(original).get();
        assertEquals(original, copyFormat);
        assertNotSame(original, copyFormat);
    }

    @Test
    void testFormatHappyPath() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("", format.format());
        assertEquals("a,b,c", format.format("a", "b", "c"));
        assertEquals("\"x,y\",z", format.format("x,y", "z"));
    }

    @Test
    void testFormatNullValuesThrowsNpe() {
        assertThrows(NullPointerException.class, () -> CSVFormat.DEFAULT.format((Object[]) null));
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.RFC4180;
        format.printRecord(out, "a", "b", "c");
        assertEquals("a,b,c\r\n", out.toString());
    }

    @Test
    void testPrintRecordEmptyValuesOnlySeparator() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.RFC4180.printRecord(out);
        assertEquals("\r\n", out.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        format.println(out);
        assertEquals(",\n", out.toString());
    }

    @Test
    void testPrintQuotesWhenNeeded() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", out, true);
        assertEquals("\"a,b\"", out.toString());
    }

    @Test
    void testPrintNoQuoteCharUsesEscape() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setEscape('\\').get();
        format.print("a,b", out, true);
        assertEquals("a\\,b", out.toString());
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat right = CSVFormat.DEFAULT;
        final CSVFormat left = right.builder().setDelimiter(right.getDelimiter()).get();
        assertEquals(right, left);
        assertEquals(right.hashCode(), left.hashCode());
    }

    @Test
    void testEqualsRejectsNullAndOtherTypes() {
        assertNotEquals(null, CSVFormat.DEFAULT);
        assertNotEquals("not a format", CSVFormat.DEFAULT);
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsDiffersOnDelimiter() {
        final CSVFormat right = CSVFormat.newFormat('!');
        final CSVFormat left = CSVFormat.newFormat('?');
        assertNotEquals(right, left);
        assertNotEquals(left, right);
    }

    @Test
    void testEqualsDiffersOnMaxRows() {
        final CSVFormat right = CSVFormat.DEFAULT.builder().setMaxRows(10).get();
        final CSVFormat left = CSVFormat.DEFAULT.builder().setMaxRows(1000).get();
        assertNotEquals(right, left);
        assertNotEquals(right.hashCode(), left.hashCode());
    }

    @Test
    void testToStringContainsDelimiterAndSkipHeaderRecord() {
        final String string = CSVFormat.INFORMIX_UNLOAD.toString();
        assertEquals("Delimiter=<|> Escape=<\\> QuoteChar=<\"> RecordSeparator=<\n> EmptyLines:ignored SkipHeaderRecord:false", string);
    }

    @Test
    void testPredefinedEnumGetFormatMatchesConstant() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    @Test
    void testGetDelimiterCharArrayAndString() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertArrayEquals(new char[] { ',' }, format.getDelimiterCharArray());
        assertEquals(",", format.getDelimiterString());
    }

    @Test
    void testParseReturnsNonNullParser() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader("a,b\n1,2\n"));
        try {
            assertNotNull(parser);
            assertEquals(2, parser.getRecords().size());
        } finally {
            parser.close();
        }
    }
}
