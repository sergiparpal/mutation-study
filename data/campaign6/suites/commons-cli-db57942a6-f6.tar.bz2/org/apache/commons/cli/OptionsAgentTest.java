/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class OptionsAgentTest {

    @Test
    void testAddOptionInstance() {
        final Options options = new Options();
        final Option opt = new Option("f", "file", false, "file to process");
        final Options result = options.addOption(opt);
        assertSame(options, result, "addOption should return the same instance for chaining");
        assertTrue(options.hasOption("f"));
        assertTrue(options.hasOption("file"));
        assertSame(opt, options.getOption("f"));
    }

    @Test
    void testAddOptionShortOnly() {
        final Options options = new Options();
        final Options result = options.addOption("f", false, "a flag");
        assertSame(options, result);
        assertTrue(options.hasOption("f"));
        assertFalse(options.hasLongOption("f"));
        final Option opt = options.getOption("f");
        assertNotNull(opt);
        assertFalse(opt.hasArg());
        assertEquals("a flag", opt.getDescription());
    }

    @Test
    void testAddOptionShortWithDescriptionOnly() {
        final Options options = new Options();
        options.addOption("v", "verbose flag");
        final Option opt = options.getOption("v");
        assertNotNull(opt);
        assertFalse(opt.hasArg());
        assertEquals("verbose flag", opt.getDescription());
    }

    @Test
    void testAddOptionShortAndLong() {
        final Options options = new Options();
        options.addOption("o", "output", true, "output file");
        final Option opt = options.getOption("o");
        assertNotNull(opt);
        assertTrue(opt.hasArg());
        assertEquals("output", opt.getLongOpt());
        assertTrue(options.hasOption("output"));
        assertTrue(options.hasLongOption("output"));
        assertTrue(options.hasShortOption("o"));
    }

    @Test
    void testAddOptionOverwritesExistingShortOption() {
        final Options options = new Options();
        options.addOption("f", false, "first description");
        options.addOption("f", true, "second description");
        final Option opt = options.getOption("f");
        assertEquals("second description", opt.getDescription());
        assertTrue(opt.hasArg());
    }

    @Test
    void testAddRequiredOption() {
        final Options options = new Options();
        options.addRequiredOption("r", "required-opt", true, "a required option");
        final Option opt = options.getOption("r");
        assertTrue(opt.isRequired());
        assertTrue(options.getRequiredOptions().contains("r"));
    }

    @Test
    void testAddOptionRequiredNotDuplicatedWhenReAdded() {
        final Options options = new Options();
        final Option opt1 = new Option("r", "required", false, "desc");
        opt1.setRequired(true);
        options.addOption(opt1);
        final Option opt2 = new Option("r", "required", false, "desc2");
        opt2.setRequired(true);
        options.addOption(opt2);
        final List<?> required = options.getRequiredOptions();
        int count = 0;
        final Iterator<?> it = required.iterator();
        while (it.hasNext()) {
            if ("r".equals(it.next())) {
                count++;
            }
        }
        assertEquals(1, count, "the required key must not be duplicated when the option is re-added");
    }

    @Test
    void testAddOptionGroup() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option file = new Option("f", "file", false, "file to process");
        final Option dir = new Option("d", "directory", false, "directory to process");
        group.addOption(file);
        group.addOption(dir);
        final Options result = options.addOptionGroup(group);
        assertSame(options, result);
        assertTrue(options.hasOption("f"));
        assertTrue(options.hasOption("d"));
        assertSame(group, options.getOptionGroup(file));
        assertSame(group, options.getOptionGroup(dir));
    }

    @Test
    void testAddOptionGroupForcesOptionsToBeOptional() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option file = new Option("f", "file", false, "file to process");
        file.setRequired(true);
        group.addOption(file);
        options.addOptionGroup(group);
        assertFalse(file.isRequired(), "options within a group must be forced to optional");
        assertFalse(options.getRequiredOptions().contains("f"));
    }

    @Test
    void testAddOptionGroupRequired() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        group.setRequired(true);
        final Option file = new Option("f", "file", false, "file to process");
        group.addOption(file);
        options.addOptionGroup(group);
        assertTrue(options.getRequiredOptions().contains(group), "the group itself should be in the required options list");
    }

    @Test
    void testGetOptionGroupForOptionNotInAnyGroup() {
        final Options options = new Options();
        final Option opt = new Option("f", "file", false, "file to process");
        options.addOption(opt);
        assertNull(options.getOptionGroup(opt));
    }

    @Test
    void testAddOptionsMergesTwoInstances() {
        final Options options = new Options();
        options.addOption("a", false, "option a");
        final Options other = new Options();
        other.addOption("b", false, "option b");
        final Options result = options.addOptions(other);
        assertSame(options, result);
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasOption("b"));
    }

    @Test
    void testAddOptionsThrowsOnDuplicateKey() {
        final Options options = new Options();
        options.addOption("a", false, "option a");
        final Options other = new Options();
        other.addOption("a", true, "duplicate option a");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                options.addOptions(other);
            }
        });
    }

    @Test
    void testAddOptionsCarriesOptionGroups() {
        final Options options = new Options();
        final Options other = new Options();
        final OptionGroup group = new OptionGroup();
        final Option file = new Option("f", "file", false, "file to process");
        final Option dir = new Option("d", "directory", false, "directory to process");
        group.addOption(file);
        group.addOption(dir);
        other.addOptionGroup(group);
        options.addOptions(other);
        assertTrue(options.hasOption("f"));
        assertTrue(options.hasOption("d"));
        assertNotNull(options.getOptionGroup(options.getOption("f")));
    }

    @Test
    void testGetMatchingOptionsPerfectMatch() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        options.addOption(null, "filter", false, "filter");
        final List<String> matches = options.getMatchingOptions("file");
        assertEquals(1, matches.size());
        assertEquals("file", matches.get(0));
    }

    @Test
    void testGetMatchingOptionsPartialMatches() {
        final Options options = new Options();
        options.addOption(null, "filter", false, "filter");
        options.addOption(null, "filename", false, "filename");
        final List<String> matches = options.getMatchingOptions("fil");
        assertEquals(2, matches.size());
        assertTrue(matches.contains("filter"));
        assertTrue(matches.contains("filename"));
    }

    @Test
    void testGetMatchingOptionsNoMatch() {
        final Options options = new Options();
        options.addOption(null, "filter", false, "filter");
        final List<String> matches = options.getMatchingOptions("zzz");
        assertNotNull(matches);
        assertTrue(matches.isEmpty());
    }

    @Test
    void testGetMatchingOptionsStripsLeadingHyphens() {
        final Options options = new Options();
        options.addOption(null, "filter", false, "filter");
        final List<String> matches = options.getMatchingOptions("--filter");
        assertEquals(1, matches.size());
        assertEquals("filter", matches.get(0));
    }

    @Test
    void testGetOptionUnknownReturnsNull() {
        final Options options = new Options();
        assertNull(options.getOption("nope"));
    }

    @Test
    void testGetOptionStripsLeadingHyphens() {
        final Options options = new Options();
        final Option opt = new Option("f", "file", false, "file to process");
        options.addOption(opt);
        assertSame(opt, options.getOption("-f"));
        assertSame(opt, options.getOption("--file"));
        assertSame(opt, options.getOption("f"));
        assertSame(opt, options.getOption("file"));
    }

    @Test
    void testGetOptionWithNullAndEmptyDoesNotThrow() {
        final Options options = new Options();
        options.addOption("f", false, "file to process");
        assertNull(options.getOption(null));
        assertNull(options.getOption(""));
    }

    @Test
    void testHasOptionVariants() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file to process");
        assertTrue(options.hasOption("f"));
        assertTrue(options.hasOption("-f"));
        assertTrue(options.hasOption("file"));
        assertTrue(options.hasOption("--file"));
        assertFalse(options.hasOption("x"));
    }

    @Test
    void testHasLongOptionOnlyMatchesLongNames() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file to process");
        assertTrue(options.hasLongOption("file"));
        assertFalse(options.hasLongOption("f"));
    }

    @Test
    void testHasShortOptionOnlyMatchesShortNames() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file to process");
        assertTrue(options.hasShortOption("f"));
        assertFalse(options.hasShortOption("file"));
    }

    @Test
    void testHasShortOptionFalseForLongOnlyOption() {
        final Options options = new Options();
        // an option with no short name at all, only a long name
        options.addOption(new Option(null, "import", false, "section to process"));
        assertTrue(options.hasOption("import"));
        assertTrue(options.hasLongOption("import"));
        assertFalse(options.hasShortOption("import"),
                "a long-only option has no short name, so hasShortOption must be false");
    }

    @Test
    void testGetOptionsReturnsAddedOptions() {
        final Options options = new Options();
        final Option f = new Option("f", "file", false, "file to process");
        final Option d = new Option("d", "directory", false, "directory to process");
        options.addOption(f);
        options.addOption(d);
        final Collection<Option> all = options.getOptions();
        assertEquals(2, all.size());
        assertTrue(all.contains(f));
        assertTrue(all.contains(d));
    }

    @Test
    void testGetOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file to process");
        final Collection<Option> all = options.getOptions();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                all.add(new Option("z", "zebra", false, "zebra"));
            }
        });
    }

    @Test
    void testGetOptionsEmptyByDefault() {
        final Options options = new Options();
        assertNotNull(options.getOptions());
        assertTrue(options.getOptions().isEmpty());
    }

    @Test
    void testGetRequiredOptionsEmptyByDefault() {
        final Options options = new Options();
        assertNotNull(options.getRequiredOptions());
        assertTrue(options.getRequiredOptions().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void testGetRequiredOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addRequiredOption("r", "required", false, "required option");
        final List<Object> required = (List<Object>) options.getRequiredOptions();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                required.add("z");
            }
        });
    }

    @Test
    void testGetRequiredOptionsContainsKey() {
        final Options options = new Options();
        options.addRequiredOption("r", "required", false, "required option");
        options.addOption("o", "optional", false, "optional option");
        final List<?> required = options.getRequiredOptions();
        assertEquals(1, required.size());
        assertEquals("r", required.get(0));
    }

    @Test
    void testToStringContainsOptionInfo() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file to process");
        final String str = options.toString();
        assertNotNull(str);
        assertTrue(str.contains("short"));
        assertTrue(str.contains("long"));
        assertTrue(str.contains("f"));
    }

    @Test
    void testConstructorProducesEmptyOptions() {
        final Options options = new Options();
        assertTrue(options.getOptions().isEmpty());
        assertTrue(options.getRequiredOptions().isEmpty());
        assertFalse(options.hasOption("anything"));
    }
}
