/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    /** Plain fixture with a mix of field types including a static and a transient field. */
    static class Fixture {
        static int staticField = 999;
        int i;
        char c;
        String s;
        transient short t;

        Fixture(final int i, final char c, final String s, final short t) {
            this.i = i;
            this.c = c;
            this.s = s;
            this.t = t;
        }
    }

    /** Subclass adding its own fields, to test superclass field inclusion. */
    static class SubFixture extends Fixture {
        String extra;

        SubFixture(final int i, final char c, final String s, final short t, final String extra) {
            super(i, c, s, t);
            this.extra = extra;
        }
    }

    /** Fixture with one field excluded via the annotation. */
    static class AnnotatedExcludeFixture {
        int included;
        @HashCodeExclude
        int excluded;

        AnnotatedExcludeFixture(final int included, final int excluded) {
            this.included = included;
            this.excluded = excluded;
        }
    }

    /** Fixture with a direct self-reference, to test cycle protection. */
    static class SelfReferencing {
        int value;
        SelfReferencing self;

        SelfReferencing(final int value) {
            this.value = value;
        }
    }

    // --- Constructors and validation -----------------------------------------------------

    @Test
    void testDefaultConstructorUsesSeventeenAndThirtySeven() {
        final HashCodeBuilder a = new HashCodeBuilder();
        final HashCodeBuilder b = new HashCodeBuilder(17, 37);
        assertEquals(a.toHashCode(), b.toHashCode());
        assertEquals(17, a.toHashCode());
    }

    @Test
    void testConstructorRejectsEvenInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new HashCodeBuilder(18, 37);
            }
        });
    }

    @Test
    void testConstructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new HashCodeBuilder(17, 38);
            }
        });
    }

    @Test
    void testConstructorAcceptsNegativeOddNumbers() {
        final HashCodeBuilder builder = new HashCodeBuilder(-17, -37);
        assertEquals(-17, builder.toHashCode());
    }

    @Test
    void testBuilderFactoryProducesWorkingInstance() {
        final HashCodeBuilder.Builder nestedBuilder = HashCodeBuilder.builder();
        assertNotNull(nestedBuilder);
        final HashCodeBuilder hcb = nestedBuilder.setInitialOddNumber(3).setMultiplierOddNumber(5).get();
        assertEquals(3, hcb.toHashCode());
        hcb.append(2);
        assertEquals(3 * 5 + 2, hcb.toHashCode());
    }

    @Test
    void testBuilderFactoryRejectsEvenNumbersOnGet() {
        final HashCodeBuilder.Builder nestedBuilder = HashCodeBuilder.builder().setInitialOddNumber(4).setMultiplierOddNumber(5);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                nestedBuilder.get();
            }
        });
    }

    // --- append(primitive) ------------------------------------------------------------

    @Test
    void testAppendBooleanTrueAddsZero() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(true);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendBooleanFalseAddsOne() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(false);
        assertEquals(17 * 37 + 1, builder.toHashCode());
    }

    @Test
    void testAppendByte() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((byte) 5);
        assertEquals(17 * 37 + 5, builder.toHashCode());
    }

    @Test
    void testAppendChar() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append('A');
        assertEquals(17 * 37 + 'A', builder.toHashCode());
    }

    @Test
    void testAppendShort() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((short) 7);
        assertEquals(17 * 37 + 7, builder.toHashCode());
    }

    @Test
    void testAppendInt() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(5);
        assertEquals(17 * 37 + 5, builder.toHashCode());
    }

    @Test
    void testAppendLongSmallPositiveBehavesLikeInt() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(5L);
        assertEquals(17 * 37 + 5, builder.toHashCode());
    }

    @Test
    void testAppendLongNegativeOne() {
        // value ^ (value >> 32) for -1L is 0, since both are all-ones.
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(-1L);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendLongUsesHighAndLowBits() {
        final long value = 0x0000000100000000L; // high bits set, low bits zero
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(value);
        // (value ^ (value >> 32)) == 0x100000000L ^ 1L == 0x100000001L, truncated to int == 1
        assertEquals(17 * 37 + 1, builder.toHashCode());
    }

    @Test
    void testAppendFloatMatchesFloatToIntBits() {
        final HashCodeBuilder viaFloat = new HashCodeBuilder(17, 37);
        viaFloat.append(3.14f);
        final HashCodeBuilder viaInt = new HashCodeBuilder(17, 37);
        viaInt.append(Float.floatToIntBits(3.14f));
        assertEquals(viaInt.toHashCode(), viaFloat.toHashCode());
    }

    @Test
    void testAppendDoubleMatchesDoubleToLongBits() {
        final HashCodeBuilder viaDouble = new HashCodeBuilder(17, 37);
        viaDouble.append(3.14d);
        final HashCodeBuilder viaLong = new HashCodeBuilder(17, 37);
        viaLong.append(Double.doubleToLongBits(3.14d));
        assertEquals(viaLong.toHashCode(), viaDouble.toHashCode());
    }

    @Test
    void testAppendNegativeZeroDoubleDiffersFromPositiveZero() {
        // -0.0 and 0.0 have different bit patterns via doubleToLongBits.
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        a.append(0.0d);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37);
        b.append(-0.0d);
        assertNotEquals(a.toHashCode(), b.toHashCode());
    }

    // --- append(primitive array) -------------------------------------------------------

    @Test
    void testAppendNullBooleanArrayOnlyMultiplies() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        builder.append((boolean[]) null);
        assertEquals(3 * 5, builder.toHashCode());
    }

    @Test
    void testAppendNullByteArrayOnlyMultiplies() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        builder.append((byte[]) null);
        assertEquals(3 * 5, builder.toHashCode());
    }

    @Test
    void testAppendNullIntArrayOnlyMultiplies() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        builder.append((int[]) null);
        assertEquals(3 * 5, builder.toHashCode());
    }

    @Test
    void testAppendNullObjectArrayOnlyMultiplies() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        builder.append((Object[]) null);
        assertEquals(3 * 5, builder.toHashCode());
    }

    @Test
    void testAppendIntArrayEquivalentToAppendingEachElement() {
        final HashCodeBuilder viaArray = new HashCodeBuilder(17, 37);
        viaArray.append(new int[] {1, 2, 3});
        final HashCodeBuilder viaElements = new HashCodeBuilder(17, 37);
        viaElements.append(1).append(2).append(3);
        assertEquals(viaElements.toHashCode(), viaArray.toHashCode());
    }

    @Test
    void testAppendEmptyArrayLeavesOnlyMultiplication() {
        final HashCodeBuilder withEmpty = new HashCodeBuilder(3, 5);
        withEmpty.append(new int[0]);
        // No elements to append, so nothing should be added at all (not even one multiplication),
        // since the loop body never executes.
        assertEquals(3, withEmpty.toHashCode());
    }

    // --- append(Object) and Object[] ----------------------------------------------------

    @Test
    void testAppendNullObjectOnlyMultiplies() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        builder.append((Object) null);
        assertEquals(3 * 5, builder.toHashCode());
    }

    @Test
    void testAppendObjectUsesItsHashCode() {
        final Integer value = Integer.valueOf(42);
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((Object) value);
        assertEquals(17 * 37 + value.hashCode(), builder.toHashCode());
    }

    @Test
    void testAppendObjectArrayDispatchesToPrimitiveArrayHandling() {
        final Object nestedIntArray = new int[] {4, 5};
        final HashCodeBuilder viaObject = new HashCodeBuilder(17, 37);
        viaObject.append(nestedIntArray);
        final HashCodeBuilder viaDirect = new HashCodeBuilder(17, 37);
        viaDirect.append((int[]) nestedIntArray);
        assertEquals(viaDirect.toHashCode(), viaObject.toHashCode());
    }

    @Test
    void testAppendObjectArrayWithMixedElements() {
        final HashCodeBuilder viaArray = new HashCodeBuilder(17, 37);
        viaArray.append(new Object[] {"a", null, Integer.valueOf(1)});
        final HashCodeBuilder viaElements = new HashCodeBuilder(17, 37);
        viaElements.append((Object) "a").append((Object) null).append((Object) Integer.valueOf(1));
        assertEquals(viaElements.toHashCode(), viaArray.toHashCode());
    }

    @Test
    void testAppendSelfReferencingArrayDoesNotInfiniteLoop() {
        final Object[] array = new Object[1];
        array[0] = array;
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        // Must terminate: the cycle-detecting registry should skip the self-reference.
        builder.append(array);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendSelfReferencingObjectDoesNotInfiniteLoop() {
        final SelfReferencing node = new SelfReferencing(1);
        node.self = node;
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        // append(Object) does not reflect into fields, so this just uses node.hashCode()
        // (default identity hash), it must simply return without looping forever.
        builder.append((Object) node);
        assertEquals(17 * 37 + node.hashCode(), builder.toHashCode());
    }

    // --- appendSuper, toHashCode, build --------------------------------------------------

    @Test
    void testAppendSuper() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.appendSuper(99);
        assertEquals(17 * 37 + 99, builder.toHashCode());
    }

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(5);
        final Integer built = builder.build();
        assertEquals(Integer.valueOf(builder.toHashCode()), built);
    }

    @Test
    void testChainingReturnsSameInstance() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        final HashCodeBuilder result = builder.append(1).append(2L).append("x");
        assertSame(builder, result);
    }

    // --- equals/hashCode of the builder itself -------------------------------------------

    @Test
    void testEqualsSameTotalAreEqual() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        a.append(10);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37);
        b.append(10);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentTotalAreNotEqual() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        a.append(10);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37);
        b.append(11);
        assertFalse(a.equals(b));
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        assertFalse(a.equals(null));
        assertFalse(a.equals("not a HashCodeBuilder"));
    }

    @Test
    void testEqualsReflexive() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        assertEquals(a, a);
    }

    @Test
    void testBuilderHashCodeEqualsToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(123);
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    // --- reflectionHashCode ---------------------------------------------------------------

    @Test
    void testReflectionHashCodeNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                HashCodeBuilder.reflectionHashCode(null);
            }
        });
    }

    @Test
    void testReflectionHashCodeEvenInitialThrows() {
        final Fixture fixture = new Fixture(1, 'a', "s", (short) 1);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                HashCodeBuilder.reflectionHashCode(18, 37, fixture);
            }
        });
    }

    @Test
    void testReflectionHashCodeEqualObjectsHaveEqualHashCodes() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        final Fixture f2 = new Fixture(2, 'c', "Test", (short) 2);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f2));
    }

    @Test
    void testReflectionHashCodeDifferentFieldsDiffer() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        final Fixture f2 = new Fixture(3, 'c', "Test", (short) 2);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f2));
    }

    @Test
    void testReflectionHashCodeIgnoresTransientByDefault() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        final Fixture f2 = new Fixture(2, 'c', "Test", (short) 9);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1, false), HashCodeBuilder.reflectionHashCode(f2, false));
    }

    @Test
    void testReflectionHashCodeIncludesTransientWhenRequested() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        final Fixture f2 = new Fixture(2, 'c', "Test", (short) 9);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(f1, true), HashCodeBuilder.reflectionHashCode(f2, true));
    }

    @Test
    void testReflectionHashCodeIgnoresStaticFields() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        Fixture.staticField = 111;
        final int hashBefore = HashCodeBuilder.reflectionHashCode(f1, true);
        Fixture.staticField = 222;
        final int hashAfter = HashCodeBuilder.reflectionHashCode(f1, true);
        assertEquals(hashBefore, hashAfter);
    }

    @Test
    void testReflectionHashCodeIncludesSuperclassFields() {
        final SubFixture s1 = new SubFixture(2, 'c', "Test", (short) 2, "extra1");
        final SubFixture s2 = new SubFixture(2, 'c', "Test", (short) 2, "extra2");
        assertNotEquals(HashCodeBuilder.reflectionHashCode(s1), HashCodeBuilder.reflectionHashCode(s2));
    }

    @Test
    void testReflectionHashCodeExcludeFieldsByName() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        final Fixture f2 = new Fixture(5, 'c', "Test", (short) 2);
        final int h1 = HashCodeBuilder.reflectionHashCode(f1, "i");
        final int h2 = HashCodeBuilder.reflectionHashCode(f2, "i");
        assertEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeExcludeFieldsByCollection() {
        final Fixture f1 = new Fixture(2, 'c', "Test", (short) 2);
        final Fixture f2 = new Fixture(5, 'c', "Test", (short) 2);
        final int h1 = HashCodeBuilder.reflectionHashCode(f1, Collections.singletonList("i"));
        final int h2 = HashCodeBuilder.reflectionHashCode(f2, Collections.singletonList("i"));
        assertEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeAnnotationExcludesField() {
        final AnnotatedExcludeFixture a1 = new AnnotatedExcludeFixture(1, 100);
        final AnnotatedExcludeFixture a2 = new AnnotatedExcludeFixture(1, 200);
        assertEquals(HashCodeBuilder.reflectionHashCode(a1), HashCodeBuilder.reflectionHashCode(a2));
    }

    @Test
    void testReflectionHashCodeAnnotationDoesNotExcludeOtherField() {
        final AnnotatedExcludeFixture a1 = new AnnotatedExcludeFixture(1, 100);
        final AnnotatedExcludeFixture a2 = new AnnotatedExcludeFixture(2, 100);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a1), HashCodeBuilder.reflectionHashCode(a2));
    }

    @Test
    void testReflectionHashCodeUpToSuperclassExcludesFieldsAboveIt() {
        final SubFixture s1 = new SubFixture(2, 'c', "Test", (short) 2, "extra1");
        final SubFixture s2 = new SubFixture(9, 'z', "Other", (short) 9, "extra1");
        // Reflect only up to (and including) Fixture: since SubFixture itself is always
        // reflected first, and the loop stops once it reaches Fixture, only SubFixture's own
        // fields ("extra") remain relevant; Fixture's fields are also included because the
        // loop includes reflectUpToClass itself before stopping.
        final int h1 = HashCodeBuilder.reflectionHashCode(17, 37, s1, false, Fixture.class);
        final int h2 = HashCodeBuilder.reflectionHashCode(17, 37, s2, false, Fixture.class);
        // Fixture's fields differ (2 vs 9, 'c' vs 'z', Test vs Other, short differs is transient-ignored),
        // so even reflecting up to and including Fixture, the hash codes must differ.
        assertNotEquals(h1, h2);
    }

    @Test
    void testReflectionHashCodeNoFieldsReturnsInitialValue() {
        final class Empty {
            // no fields
        }
        assertEquals(17, HashCodeBuilder.reflectionHashCode(new Empty(), false));
    }

    @Test
    void testReflectionHashCodeConsistentAcrossMultipleCalls() {
        final Fixture f = new Fixture(2, 'c', "Test", (short) 2);
        final int h1 = HashCodeBuilder.reflectionHashCode(f);
        final int h2 = HashCodeBuilder.reflectionHashCode(f);
        final int h3 = HashCodeBuilder.reflectionHashCode(f);
        assertEquals(h1, h2);
        assertEquals(h2, h3);
    }

    @Test
    void testReflectionHashCodeFieldOrderIndependentOfDeclarationOrder() {
        // Fields are sorted by name before being appended, so reflection hash code must not
        // depend on the order fields were declared/assigned.
        final Fixture f1 = new Fixture(1, 'a', "x", (short) 1);
        final Fixture f2 = new Fixture(1, 'a', "x", (short) 1);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1, true), HashCodeBuilder.reflectionHashCode(f2, true));
    }

    @Test
    void testArraysAsListNotTreatedAsRawArray() {
        // Sanity: a non-array Object still hits the plain hashCode() branch.
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        final Object list = Arrays.asList("a", "b");
        builder.append(list);
        assertEquals(17 * 37 + list.hashCode(), builder.toHashCode());
    }
}
