/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    @Test
    public void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntOverflowOnNegate() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -1));
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNegative() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -3, 7));
    }

    @Test
    public void testGetFractionWholeNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, -7));
    }

    @Test
    public void testGetFractionWholeZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, 0));
    }

    @Test
    public void testGetFractionWholeNumeratorOverflowThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, Integer.MAX_VALUE, 2));
    }

    @Test
    public void testGetFractionDouble() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(((double) Integer.MAX_VALUE) + 1000d));
    }

    @Test
    public void testGetFractionDoubleZero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleWholeNumber() {
        final Fraction f = Fraction.getFraction(5.0d);
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixed() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringInvalidMixedFormatThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3-7"));
    }

    @Test
    public void testGetFractionStringGarbageThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testGetReducedFraction() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorNormalizesDenominator() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testAbsPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAbsOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::abs);
    }

    @Test
    public void testAdd() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAddZeroIdentity() {
        final Fraction a = Fraction.getFraction(2, 5);
        assertSame(a, Fraction.ZERO.add(a));
        assertSame(a, a.add(Fraction.ZERO));
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.add(null));
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE - 1, 1);
        assertThrows(ArithmeticException.class, () -> a.add(Fraction.getFraction(2, 1)));
    }

    @Test
    public void testSubtract() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.subtract(null));
    }

    @Test
    public void testSubtractFromZero() {
        final Fraction a = Fraction.getFraction(2, 5);
        final Fraction result = Fraction.ZERO.subtract(a);
        assertEquals(-2, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testMultiplyBy() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction result = a.multiplyBy(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertSame(Fraction.ZERO, a.multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.multiplyBy(null));
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> a.multiplyBy(Fraction.getFraction(2, 1)));
    }

    @Test
    public void testDivideBy() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.divideBy(b);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, () -> a.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.divideBy(null));
    }

    @Test
    public void testInvert() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction inverted = a.invert();
        assertEquals(3, inverted.getNumerator());
        assertEquals(2, inverted.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction a = Fraction.getFraction(-2, 3);
        final Fraction inverted = a.invert();
        assertEquals(-3, inverted.getNumerator());
        assertEquals(2, inverted.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, Fraction.ZERO::invert);
    }

    @Test
    public void testInvertMinValueThrows() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, a::invert);
    }

    @Test
    public void testNegate() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction negated = a.negate();
        assertEquals(-3, negated.getNumerator());
        assertEquals(7, negated.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, a::negate);
    }

    @Test
    public void testPowZeroReturnsOne() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(Fraction.ONE, a.pow(0));
    }

    @Test
    public void testPowZeroOfZeroReturnsOne() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOneReturnsSame() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(a, a.pow(1));
    }

    @Test
    public void testPowPositive() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPowMinValue() {
        final Fraction a = Fraction.getFraction(1, 1);
        final Fraction result = a.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testReduce() {
        final Fraction a = Fraction.getFraction(4, 8);
        final Fraction reduced = a.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSame() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertSame(a, a.reduce());
    }

    @Test
    public void testReduceZeroNumerator() {
        final Fraction a = Fraction.getFraction(0, 5);
        final Fraction reduced = a.reduce();
        assertEquals(Fraction.ZERO, reduced);
    }

    @Test
    public void testCompareToEqualInstances() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareToEqualDifferentForm() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareToLessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.compareTo(null));
    }

    @Test
    public void testEqualsSameValues() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDifferentFormNotEqual() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsNull() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals("1/2"));
    }

    @Test
    public void testEqualsSameInstance() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertTrue(a.equals(a));
    }

    @Test
    public void testNotEquals() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        assertNotEquals(a, b);
    }

    @Test
    public void testNumberConversions() {
        final Fraction a = Fraction.getFraction(7, 2);
        assertEquals(3, a.intValue());
        assertEquals(3L, a.longValue());
        assertEquals(3.5f, a.floatValue(), 0.0f);
        assertEquals(3.5d, a.doubleValue(), 0.0d);
    }

    @Test
    public void testNumberConversionsNegative() {
        final Fraction a = Fraction.getFraction(-7, 2);
        assertEquals(-3, a.intValue());
        assertEquals(-3L, a.longValue());
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals(3, a.getProperNumerator());
        assertEquals(1, a.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals(3, a.getProperNumerator());
        assertEquals(-1, a.getProperWhole());
    }

    @Test
    public void testToString() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals("3/7", a.toString());
    }

    @Test
    public void testToStringCached() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(a.toString(), a.toString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringOne() {
        final Fraction a = Fraction.getFraction(4, 4);
        assertEquals("1", a.toProperString());
    }

    @Test
    public void testToProperStringNegativeOne() {
        final Fraction a = Fraction.getFraction(-4, 4);
        assertEquals("-1", a.toProperString());
    }

    @Test
    public void testToProperStringImproperFraction() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", a.toProperString());
    }

    @Test
    public void testToProperStringImproperFractionNegative() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", a.toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals("3/7", a.toProperString());
    }

    @Test
    public void testToProperStringMinValueNumerator() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertEquals(Integer.toString(Integer.MIN_VALUE), a.toProperString());
    }

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }
}
