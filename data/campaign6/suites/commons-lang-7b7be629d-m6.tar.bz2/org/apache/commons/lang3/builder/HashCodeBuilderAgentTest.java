/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class HashCodeBuilderAgentTest {

    static class SortedFieldsPojo {
        int zebra = 5;
        int apple = 9;
    }

    static class ExcludablePojo {
        int a = 1;
        int b = 2;
    }

    static class AnnotatedExcludePojo {
        int a = 1;
        @HashCodeExclude
        int b = 2;
    }

    static class TransientPojo {
        int a = 1;
        transient int b = 2;
    }

    static class StaticFieldPojo {
        static int s = 100;
        int a = 1;
    }

    static class GrandParent {
        int gpField = 1;
    }

    static class Parent extends GrandParent {
        int pField = 2;
    }

    static class Child extends Parent {
        int cField = 3;
    }

    // --- Constructors ---

    @Test
    void defaultConstructorStartsAtSeventeen() {
        assertEquals(17, new HashCodeBuilder().toHashCode());
    }

    @Test
    void twoArgConstructorUsesGivenConstants() {
        final int result = new HashCodeBuilder(7, 3).append(5).toHashCode();
        assertEquals(7 * 3 + 5, result);
    }

    @Test
    void constructorRejectsEvenInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(4, 3);
            }
        });
    }

    @Test
    void constructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(3, 4);
            }
        });
    }

    // --- builder() / Builder ---

    @Test
    void builderWithoutConstantsFailsBecauseDefaultsAreEven() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.builder().get();
            }
        });
    }

    @Test
    void builderProducesConfiguredHashCodeBuilder() {
        final HashCodeBuilder builder = HashCodeBuilder.builder()
                .setInitialOddNumber(5)
                .setMultiplierOddNumber(9)
                .get();
        assertEquals(5 * 9 + 2, builder.append(2).toHashCode());
    }

    @Test
    void builderRejectsEvenInitialNumber() {
        final HashCodeBuilder.Builder b = HashCodeBuilder.builder().setInitialOddNumber(4).setMultiplierOddNumber(9);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                b.get();
            }
        });
    }

    @Test
    void builderRejectsEvenMultiplierNumber() {
        final HashCodeBuilder.Builder b = HashCodeBuilder.builder().setInitialOddNumber(5).setMultiplierOddNumber(8);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                b.get();
            }
        });
    }

    @Test
    void builderSetForceAccessibleReturnsSameBuilderInstance() {
        final HashCodeBuilder.Builder b = HashCodeBuilder.builder().setInitialOddNumber(3).setMultiplierOddNumber(5);
        assertSame(b, b.setForceAccessible(false));
        assertEquals(3, b.get().toHashCode());
    }

    // --- append(boolean) / append(boolean[]) ---

    @Test
    void appendBooleanTrueAddsZero() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(true).toHashCode());
    }

    @Test
    void appendBooleanFalseAddsOne() {
        assertEquals(17 * 37 + 1, new HashCodeBuilder(17, 37).append(false).toHashCode());
    }

    @Test
    void appendNullBooleanArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((boolean[]) null).toHashCode());
    }

    @Test
    void appendBooleanArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append(true).append(false).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new boolean[] {true, false}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(byte) / append(byte[]) ---

    @Test
    void appendByteAddsValue() {
        assertEquals(17 * 37 + 9, new HashCodeBuilder(17, 37).append((byte) 9).toHashCode());
    }

    @Test
    void appendNullByteArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((byte[]) null).toHashCode());
    }

    @Test
    void appendByteArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append((byte) 1).append((byte) 2).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new byte[] {1, 2}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(char) / append(char[]) ---

    @Test
    void appendCharAddsValue() {
        assertEquals(17 * 37 + 'x', new HashCodeBuilder(17, 37).append('x').toHashCode());
    }

    @Test
    void appendNullCharArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((char[]) null).toHashCode());
    }

    @Test
    void appendCharArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append('a').append('b').toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new char[] {'a', 'b'}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(double) / append(double[]) ---

    @Test
    void appendDoubleUsesDoubleToLongBits() {
        final long bits = Double.doubleToLongBits(3.5d);
        final int expected = new HashCodeBuilder(17, 37).append(bits).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(3.5d).toHashCode());
    }

    @Test
    void appendNullDoubleArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((double[]) null).toHashCode());
    }

    @Test
    void appendDoubleArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append(1.1d).append(2.2d).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new double[] {1.1d, 2.2d}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(float) / append(float[]) ---

    @Test
    void appendFloatUsesFloatToIntBits() {
        final int bits = Float.floatToIntBits(2.5f);
        assertEquals(17 * 37 + bits, new HashCodeBuilder(17, 37).append(2.5f).toHashCode());
    }

    @Test
    void appendNullFloatArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((float[]) null).toHashCode());
    }

    @Test
    void appendFloatArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append(1.1f).append(2.2f).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new float[] {1.1f, 2.2f}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(int) / append(int[]) ---

    @Test
    void appendIntAddsValue() {
        assertEquals(17 * 37 + 42, new HashCodeBuilder(17, 37).append(42).toHashCode());
    }

    @Test
    void appendNullIntArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((int[]) null).toHashCode());
    }

    @Test
    void appendIntArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append(1).append(2).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new int[] {1, 2}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(long) / append(long[]) ---

    @Test
    void appendLongUsesXorOfHighAndLowBits() {
        final long value = 123456789012345L;
        final int expected = 17 * 37 + (int) (value ^ value >> 32);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendNullLongArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((long[]) null).toHashCode());
    }

    @Test
    void appendLongArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append(1L).append(2L).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new long[] {1L, 2L}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(short) / append(short[]) ---

    @Test
    void appendShortAddsValue() {
        assertEquals(17 * 37 + 7, new HashCodeBuilder(17, 37).append((short) 7).toHashCode());
    }

    @Test
    void appendNullShortArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((short[]) null).toHashCode());
    }

    @Test
    void appendShortArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append((short) 1).append((short) 2).toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new short[] {1, 2}).toHashCode();
        assertEquals(expected, actual);
    }

    // --- append(Object) / append(Object[]) ---

    @Test
    void appendNullObjectMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((Object) null).toHashCode());
    }

    @Test
    void appendObjectUsesItsHashCode() {
        final String s = "abc";
        assertEquals(17 * 37 + s.hashCode(), new HashCodeBuilder(17, 37).append((Object) s).toHashCode());
    }

    @Test
    void appendNullObjectArrayMultipliesOnly() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((Object[]) null).toHashCode());
    }

    @Test
    void appendObjectArrayAppendsEachElement() {
        final int expected = new HashCodeBuilder(17, 37).append((Object) "a").append((Object) "b").toHashCode();
        final int actual = new HashCodeBuilder(17, 37).append(new Object[] {"a", "b"}).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void appendObjectDispatchesPrimitiveArraysSameAsTypedOverloads() {
        assertEquals(new HashCodeBuilder(17, 37).append(new int[] {1, 2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new int[] {1, 2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new long[] {1L, 2L}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new long[] {1L, 2L}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new short[] {1, 2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new short[] {1, 2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new char[] {'a', 'b'}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new char[] {'a', 'b'}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new byte[] {1, 2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new byte[] {1, 2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new double[] {1.1, 2.2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new double[] {1.1, 2.2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new float[] {1.1f, 2.2f}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new float[] {1.1f, 2.2f}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new boolean[] {true, false}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new boolean[] {true, false}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new Object[] {"a", "b"}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new Object[] {"a", "b"}).toHashCode());
    }

    // --- appendSuper ---

    @Test
    void appendSuperAddsGivenValue() {
        assertEquals(17 * 37 + 99, new HashCodeBuilder(17, 37).appendSuper(99).toHashCode());
    }

    // --- build() ---

    @Test
    void buildReturnsBoxedToHashCode() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37).append(5);
        assertEquals(Integer.valueOf(hcb.toHashCode()), hcb.build());
    }

    // --- equals() / hashCode() of HashCodeBuilder itself ---

    @Test
    void equalsIsReflexive() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37).append(5);
        assertTrue(hcb.equals(hcb));
    }

    @Test
    void equalsReturnsTrueForSameTotal() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(5);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(5);
        assertNotSame(a, b);
        assertTrue(a.equals(b));
    }

    @Test
    void equalsReturnsFalseForDifferentTotal() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(5);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(6);
        assertFalse(a.equals(b));
    }

    @Test
    void equalsReturnsFalseForNull() {
        assertFalse(new HashCodeBuilder().equals(null));
    }

    @Test
    void equalsReturnsFalseForDifferentType() {
        assertFalse(new HashCodeBuilder().equals("not a HashCodeBuilder"));
    }

    @Test
    void hashCodeDelegatesToToHashCode() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37).append(5);
        assertEquals(hcb.toHashCode(), hcb.hashCode());
    }

    // --- reflectionHashCode ---

    @Test
    void reflectionHashCodeSortsFieldsAlphabetically() {
        final SortedFieldsPojo pojo = new SortedFieldsPojo();
        final int expected = new HashCodeBuilder(17, 37).append(pojo.apple).append(pojo.zebra).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(17, 37, pojo));
    }

    @Test
    void reflectionHashCodeTwoArgOverloadDelegatesToDefaultsConstants() {
        final SortedFieldsPojo pojo = new SortedFieldsPojo();
        assertEquals(HashCodeBuilder.reflectionHashCode(17, 37, pojo),
                HashCodeBuilder.reflectionHashCode(17, 37, pojo, false));
    }

    @Test
    void reflectionHashCodeExcludesNamedFields() {
        final ExcludablePojo pojo = new ExcludablePojo();
        final int withoutExclusion = HashCodeBuilder.reflectionHashCode(pojo);
        final int withExclusion = HashCodeBuilder.reflectionHashCode(pojo, "b");
        assertNotEquals(withoutExclusion, withExclusion);
        assertEquals(new HashCodeBuilder().append(pojo.a).toHashCode(), withExclusion);
    }

    @Test
    void reflectionHashCodeCollectionOverloadExcludesNamedFields() {
        final ExcludablePojo pojo = new ExcludablePojo();
        final int excluded = HashCodeBuilder.reflectionHashCode(pojo, Collections.singletonList("b"));
        assertEquals(new HashCodeBuilder().append(pojo.a).toHashCode(), excluded);
    }

    @Test
    void reflectionHashCodeHonorsHashCodeExcludeAnnotation() {
        final AnnotatedExcludePojo pojo = new AnnotatedExcludePojo();
        assertEquals(new HashCodeBuilder().append(pojo.a).toHashCode(), HashCodeBuilder.reflectionHashCode(pojo));
    }

    @Test
    void reflectionHashCodeIgnoresTransientFieldsByDefault() {
        final TransientPojo pojo = new TransientPojo();
        assertEquals(new HashCodeBuilder().append(pojo.a).toHashCode(), HashCodeBuilder.reflectionHashCode(pojo, false));
    }

    @Test
    void reflectionHashCodeIncludesTransientFieldsWhenRequested() {
        final TransientPojo pojo = new TransientPojo();
        final int expected = new HashCodeBuilder().append(pojo.a).append(pojo.b).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(pojo, true));
    }

    @Test
    void reflectionHashCodeAlwaysIgnoresStaticFields() {
        final StaticFieldPojo pojo = new StaticFieldPojo();
        assertEquals(new HashCodeBuilder().append(pojo.a).toHashCode(), HashCodeBuilder.reflectionHashCode(pojo, true));
    }

    @Test
    void reflectionHashCodeIncludesAllSuperclassFieldsWhenBoundaryIsNull() {
        final Child child = new Child();
        final int expected = new HashCodeBuilder(17, 37).append(child.cField).append(child.pField).append(child.gpField).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(17, 37, child, false, null));
    }

    @Test
    void reflectionHashCodeStopsAtGivenSuperclassBoundary() {
        final Child child = new Child();
        final int expected = new HashCodeBuilder(17, 37).append(child.cField).append(child.pField).toHashCode();
        assertEquals(expected, HashCodeBuilder.reflectionHashCode(17, 37, child, false, Parent.class));
    }

    @Test
    void reflectionHashCodeThreeArgOverloadThrowsOnNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(17, 37, null);
            }
        });
    }

    @Test
    void reflectionHashCodeObjectBooleanOverloadThrowsOnNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, false);
            }
        });
    }

    @Test
    void reflectionHashCodeVarargsOverloadThrowsOnNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, "field");
            }
        });
    }

    @Test
    void reflectionHashCodeCollectionOverloadThrowsOnNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null, Arrays.asList("field"));
            }
        });
    }

    @Test
    void reflectionHashCodeRejectsEvenInitialNumber() {
        final ExcludablePojo pojo = new ExcludablePojo();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(4, 37, pojo);
            }
        });
    }

    @Test
    void reflectionHashCodeRejectsEvenMultiplierNumber() {
        final ExcludablePojo pojo = new ExcludablePojo();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(17, 4, pojo);
            }
        });
    }

    @Test
    void reflectionHashCodeOfObjectWithNoFieldsEqualsInitialValue() {
        final Object plain = new Object() {
            // no declared fields
        };
        assertEquals(17, HashCodeBuilder.reflectionHashCode(17, 37, plain));
    }

    @Test
    void reflectionHashCodeDefaultConstantsAreSeventeenAndThirtySeven() {
        final ExcludablePojo pojo = new ExcludablePojo();
        final int viaDefaults = HashCodeBuilder.reflectionHashCode(pojo);
        final int viaExplicit = HashCodeBuilder.reflectionHashCode(17, 37, pojo);
        assertEquals(viaExplicit, viaDefaults);
    }

    @Test
    void reflectionHashCodeIsConsistentAcrossCalls() {
        final ExcludablePojo pojo = new ExcludablePojo();
        assertEquals(HashCodeBuilder.reflectionHashCode(pojo), HashCodeBuilder.reflectionHashCode(pojo));
    }

    @Test
    void appendChainingReturnsSameInstance() {
        final HashCodeBuilder hcb = new HashCodeBuilder(17, 37);
        assertSame(hcb, hcb.append(1));
        assertSame(hcb, hcb.append(1L));
        assertSame(hcb, hcb.appendSuper(1));
        assertNotNull(hcb.build());
    }
}
