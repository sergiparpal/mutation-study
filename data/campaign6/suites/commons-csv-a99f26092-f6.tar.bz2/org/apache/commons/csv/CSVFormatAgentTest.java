/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum SampleHeader {
        A, B, C
    }

    private enum EmptyHeader {
        // intentionally empty
    }

    /** Minimal ResultSetMetaData stub that reports two columns. */
    private static final class StubResultSetMetaData implements ResultSetMetaData {

        @Override
        public <T> T unwrap(final Class<T> iface) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public boolean isAutoIncrement(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isCaseSensitive(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isSearchable(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isCurrency(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int isNullable(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isSigned(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getColumnDisplaySize(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getColumnLabel(final int column) {
            return column == 1 ? "First" : "Second";
        }

        @Override
        public String getColumnName(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getSchemaName(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getPrecision(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getScale(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getTableName(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getCatalogName(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getColumnType(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getColumnTypeName(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isReadOnly(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isWritable(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isDefinitelyWritable(final int column) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getColumnClassName(final int column) {
            throw new UnsupportedOperationException();
        }
    }

    private static void assertIllegalArgument(final String failureMessage, final Runnable2 action) {
        try {
            action.run();
            fail(failureMessage);
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    /** Local stand-in for a throwing Runnable, avoids relying on java.util.function here. */
    private interface Runnable2 {
        void run();
    }

    // --- newFormat() / validate() ---

    @Test
    void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat('X');
        assertEquals('X', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    void testNewFormatLineBreakDelimiterThrows() {
        assertIllegalArgument("CR delimiter should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.newFormat(Constants.CR);
            }
        });
        assertIllegalArgument("LF delimiter should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.newFormat(Constants.LF);
            }
        });
    }

    @Test
    void testBuilderSetDelimiterEmptyStringThrows() {
        assertIllegalArgument("empty delimiter should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter("").get();
            }
        });
    }

    @Test
    void testBuilderSetDelimiterMultiChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
        assertArrayEquals(new char[] { ':', ':' }, format.getDelimiterCharArray());
        // Deprecated single-char accessor returns only the first character.
        assertEquals(':', format.getDelimiter());
    }

    @Test
    void testQuoteCharSameAsDelimiterThrows() {
        assertIllegalArgument("quote char equal to delimiter should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setQuote('!').get();
            }
        });
    }

    @Test
    void testEscapeSameAsDelimiterThrows() {
        assertIllegalArgument("escape char equal to delimiter should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setEscape('!').get();
            }
        });
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        assertIllegalArgument("comment marker equal to delimiter should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setCommentMarker('!').get();
            }
        });
    }

    @Test
    void testQuoteCharSameAsCommentMarkerThrows() {
        assertIllegalArgument("quote char equal to comment marker should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setQuote('!').setCommentMarker('!').get();
            }
        });
    }

    @Test
    void testEscapeSameAsCommentMarkerThrows() {
        assertIllegalArgument("escape char equal to comment marker should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setEscape('!').setCommentMarker('!').get();
            }
        });
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertIllegalArgument("QuoteMode.NONE without an escape char should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testCommentMarkerLineBreakThrows() {
        assertIllegalArgument("line break comment marker should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setCommentMarker(Constants.CR).get();
            }
        });
    }

    @Test
    void testEscapeLineBreakThrows() {
        assertIllegalArgument("line break escape char should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setEscape(Constants.LF).get();
            }
        });
    }

    @Test
    void testQuoteLineBreakThrows() {
        assertIllegalArgument("line break quote char should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setQuote(Constants.LF).get();
            }
        });
    }

    @Test
    void testDelimiterContainingLineBreakThrows() {
        assertIllegalArgument("delimiter string containing a line break should be rejected", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter("a\nb").get();
            }
        });
    }

    // --- Header handling ---

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final String[] header = { "one", "two" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        header[0] = "mutated";
        // Builder#setHeader must have copied the input array.
        assertEquals("one", format.getHeader()[0]);
        final String[] got = format.getHeader();
        got[0] = "also mutated";
        // getHeader() must return a fresh copy each time.
        assertEquals("one", format.getHeader()[0]);
        assertNotSame(format.getHeader(), format.getHeader());
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderEmptyMeansAutoDetect() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(new String[0]).get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(SampleHeader.class).get();
        assertArrayEquals(new String[] { "A", "B", "C" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromEmptyEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(EmptyHeader.class).get();
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testSetHeaderFromNullEnum() {
        final Class<? extends Enum<?>> nullEnum = null;
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(nullEnum).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromNullResultSet() throws SQLException {
        final ResultSet nullResultSet = null;
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(nullResultSet).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSetMetaData() throws SQLException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(new StubResultSetMetaData()).get();
        assertArrayEquals(new String[] { "First", "Second" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderNamesDisallowedByDefault() {
        assertIllegalArgument("duplicate header names should be rejected by DISALLOW mode", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "A").get();
            }
        });
    }

    @Test
    void testDuplicateHeaderNamesAllowedByDefaultBuilder() {
        // Builder.create() defaults to ALLOW_ALL.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "A").get();
        assertArrayEquals(new String[] { "A", "A" }, format.getHeader());
        assertTrue(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testDuplicateHeaderNamesAllowEmptyPermitsBlankDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "B", "").get();
        assertArrayEquals(new String[] { "A", "", "B", "" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderNamesAllowEmptyRejectsNonBlankDuplicates() {
        assertIllegalArgument("non-blank duplicate headers should be rejected under ALLOW_EMPTY", new Runnable2() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get();
            }
        });
    }

    @Test
    void testGetAllowDuplicateHeaderNamesReflectsMode() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertTrue(builder.get().getAllowDuplicateHeaderNames());
        assertTrue(builder.setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get().getAllowDuplicateHeaderNames());
        assertFalse(builder.setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get().getAllowDuplicateHeaderNames());
        assertFalse(builder.setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get().getAllowDuplicateHeaderNames());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("a", "b").get();
        final String[] comments = format.getHeaderComments();
        comments[0] = "mutated";
        assertEquals("a", format.getHeaderComments()[0]);
    }

    // --- Simple getters / predicates ---

    @Test
    void testIsSetPredicates() {
        final CSVFormat none = CSVFormat.newFormat(',');
        assertFalse(none.isQuoteCharacterSet());
        assertFalse(none.isEscapeCharacterSet());
        assertFalse(none.isCommentMarkerSet());
        assertFalse(none.isNullStringSet());

        final CSVFormat all = none.builder().setQuote('"').setEscape('\\').setCommentMarker('#').setNullString("NULL").get();
        assertTrue(all.isQuoteCharacterSet());
        assertTrue(all.isEscapeCharacterSet());
        assertTrue(all.isCommentMarkerSet());
        assertTrue(all.isNullStringSet());
    }

    @Test
    void testGetEscapeCharDefaultsToZero() {
        final CSVFormat format = CSVFormat.newFormat(',');
        assertEquals((char) 0, format.getEscapeChar());
        assertNull(format.getEscapeCharacter());
    }

    @Test
    void testMaxRowsDefaultsToUnlimited() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(1000000L));
    }

    @Test
    void testMaxRowsLimitsRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertEquals(2L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    @Test
    void testMaxRowsNonPositiveMeansUnlimited() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(0).get();
        assertFalse(format.useMaxRows());
        final CSVFormat negative = CSVFormat.DEFAULT.builder().setMaxRows(-5).get();
        assertFalse(negative.useMaxRows());
        assertTrue(negative.useRow(1000));
    }

    // --- equals() / hashCode() ---

    @Test
    void testEqualsReflexiveAndNullSafe() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(format, format);
        assertNotEquals(null, format);
        assertNotEquals("not a CSVFormat", format);
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat left = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat right = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotSame(left, right);
        assertEquals(left, right);
        assertEquals(right, left);
        assertEquals(left.hashCode(), right.hashCode());
    }

    @Test
    void testEqualsDiffersOnDelimiter() {
        final CSVFormat left = CSVFormat.newFormat('!');
        final CSVFormat right = CSVFormat.newFormat('?');
        assertNotEquals(left, right);
        assertNotEquals(right, left);
    }

    @Test
    void testEqualsDiffersOnMaxRows() {
        final CSVFormat left = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        final CSVFormat right = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertNotEquals(left, right);
    }

    // --- builder() / copy semantics ---

    @Test
    void testBuilderGetProducesIndependentInstance() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat first = builder.get();
        assertNotSame(builder.get(), builder.build());
        builder.setDelimiter(';');
        final CSVFormat second = builder.get();
        // The already-built instance must not be affected by later builder mutations.
        assertEquals(',', first.getDelimiter());
        assertEquals(';', second.getDelimiter());
    }

    @Test
    void testFormatIsImmutableAcrossWithMethods() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter('|');
        assertEquals(',', original.getDelimiter());
        assertEquals('|', changed.getDelimiter());
        assertNotSame(original, changed);
    }

    // --- valueOf() / Predefined ---

    @Test
    void testValueOfKnownPredefinedFormat() {
        final CSVFormat format = CSVFormat.valueOf("Default");
        assertEquals(CSVFormat.DEFAULT, format);
    }

    @Test
    void testValueOfUnknownNameThrows() {
        try {
            CSVFormat.valueOf("ThisIsNotARealPredefinedFormat");
            fail("Expected IllegalArgumentException for an unknown predefined format name");
        } catch (final IllegalArgumentException expected) {
            // expected: java.lang.Enum#valueOf throws IllegalArgumentException for unknown constants
        }
    }

    @Test
    void testPredefinedGetFormatMatchesStaticConstant() {
        assertSame(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertSame(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
    }

    // --- format() ---

    @Test
    void testFormatEmptyArgs() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"x,y\",z", CSVFormat.DEFAULT.format("x,y", "z"));
    }

    @Test
    void testFormatWithNullElement() {
        assertEquals("a,,c", CSVFormat.DEFAULT.format("a", null, "c"));
    }

    // --- print() ---

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.RFC4180;
        format.printRecord(out, "a", "b", "c");
        assertEquals("a,b,c" + format.getRecordSeparator(), out.toString());
    }

    @Test
    void testPrintlnUsesRecordSeparator() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.DEFAULT.println(out);
        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), out.toString());
    }

    @Test
    void testPrintNullValueUnquotedByDefault() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.DEFAULT.print(null, out, true);
        assertEquals("", out.toString());
    }

    @Test
    void testPrintNullValueWithNullStringSubstitution() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        format.print(null, out, true);
        assertEquals("NULL", out.toString());
    }

    @Test
    void testPrintTrimsSurroundingSpacesWhenConfigured() throws IOException {
        final StringBuilder out = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.withTrim().withQuote(null);
        format.print(" value ", out, true);
        assertEquals("value", out.toString());
    }

    @Test
    void testPrintDoesNotTrimByDefault() throws IOException {
        final StringBuilder out = new StringBuilder();
        // DEFAULT has a quote character, and MINIMAL quote mode quotes any value that starts
        // with a space (or other char <= '#') since that confused some other parsers historically.
        CSVFormat.DEFAULT.print(" value ", out, true);
        assertEquals("\" value \"", out.toString());
    }

    @Test
    void testPrintDoesNotTrimWithoutQuoting() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.DEFAULT.withQuote(null).print(" value ", out, true);
        assertEquals(" value ", out.toString());
    }

    // --- toString() ---

    @Test
    void testToStringContainsConfiguredAttributes() {
        final CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals("Delimiter=<|> Escape=<\\> QuoteChar=<\"> RecordSeparator=<\n> EmptyLines:ignored SkipHeaderRecord:false", format.toString());
    }

    @Test
    void testToStringWithHeaderAndComments() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("c1").setHeader("h1", "h2").get();
        final String string = format.toString();
        assertTrue(string.contains("HeaderComments:[c1]"));
        assertTrue(string.contains("Header:[h1, h2]"));
    }

    // --- with* deprecated mutator methods (still part of the public API) ---

    @Test
    void testWithHeaderCopiesInputArray() {
        final String[] header = { "one", "two", "three" };
        final CSVFormat formatWithHeader = CSVFormat.DEFAULT.withHeader(header);
        assertArrayEquals(header, formatWithHeader.getHeader());
        assertNotSame(header, formatWithHeader.getHeader());
    }

    @Test
    void testWithFirstRecordAsHeaderEnablesAutoDetectAndSkip() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testWithNullQuoteCharacterDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }
}
