/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link BitField}.
 */
class BitFieldAgentTest {

    private static final BitField ZERO_MASK_INT = new BitField(0);
    private static final BitField ZERO_MASK_LONG = new BitField(0L);
    private static final BitField SINGLE_BIT = new BitField(0x40); // bit 6
    private static final BitField MULTI_BIT = new BitField(0x3F80); // bits 7-13
    private static final BitField HIGH_INT_BIT = new BitField(0x8000_0000); // sign bit as int mask
    private static final BitField HIGH_LONG_BIT = new BitField(0x8000_0000_0000_0000L); // sign bit as long mask

    @Test
    void testConstructorIntMaskComputesShiftCount() {
        // mask 0x3F80 has its lowest set bit at position 7
        final BitField field = new BitField(0x3F80);
        assertEquals(0x3F80, field.getRawValue(-1));
        assertEquals(0x7F, field.getValue(-1));
    }

    @Test
    void testConstructorLongMaskComputesShiftCount() {
        // mask 0x3F80_0000_0000_0000L has its lowest set bit at position 54
        final BitField field = new BitField(0x3F80_0000_0000_0000L);
        assertEquals(0x3F80_0000_0000_0000L, field.getRawValue(-1L));
        assertEquals(0x7FL, field.getValue(-1L));
    }

    @Test
    void testZeroMaskIntBehavesAsNoOp() {
        assertEquals(0, ZERO_MASK_INT.getRawValue(-1));
        assertEquals(0, ZERO_MASK_INT.getValue(-1));
        assertFalse(ZERO_MASK_INT.isSet(-1));
        assertTrue(ZERO_MASK_INT.isAllSet(-1)); // (holder & 0) == 0 is always true
        assertEquals(-1, ZERO_MASK_INT.clear(-1));
        assertEquals(-1, ZERO_MASK_INT.set(-1));
        assertEquals(0, ZERO_MASK_INT.set(0));
    }

    @Test
    void testZeroMaskLongBehavesAsNoOp() {
        assertEquals(0L, ZERO_MASK_LONG.getRawValue(-1L));
        assertEquals(0L, ZERO_MASK_LONG.getValue(-1L));
        assertFalse(ZERO_MASK_LONG.isSet(-1L));
        assertTrue(ZERO_MASK_LONG.isAllSet(-1L));
        assertEquals(-1L, ZERO_MASK_LONG.clear(-1L));
        assertEquals(-1L, ZERO_MASK_LONG.set(-1L));
        assertEquals(0L, ZERO_MASK_LONG.set(0L));
    }

    @Test
    void testClearInt() {
        assertEquals(0xFFFF_C07F, MULTI_BIT.clear(-1));
        assertEquals(0, MULTI_BIT.clear(0x3F80));
        assertEquals(~0x40, SINGLE_BIT.clear(-1));
    }

    @Test
    void testClearLong() {
        assertEquals(0xFFFF_FFFF_FFFF_C07FL, MULTI_BIT.clear(-1L));
        assertEquals(0L, MULTI_BIT.clear(0x3F80L));
        assertEquals(~0x40L, SINGLE_BIT.clear(-1L));
    }

    @Test
    void testClearByte() {
        final BitField field = new BitField(0x40); // bit 6, fits a byte
        assertEquals((byte) 0, field.clearByte((byte) 0x40));
        assertEquals((byte) 0x01, field.clearByte((byte) 0x41));
        assertEquals((byte) -1, new BitField(0).clearByte((byte) -1));
    }

    @Test
    void testClearShort() {
        assertEquals((short) 0xC07F, MULTI_BIT.clearShort((short) -1));
        assertEquals((short) 0xBFFF, new BitField(0x4000).clearShort((short) -1));
    }

    @Test
    void testGetRawValueInt() {
        assertEquals(0x3F80, MULTI_BIT.getRawValue(-1));
        assertEquals(0, MULTI_BIT.getRawValue(0));
        assertEquals(0x40, SINGLE_BIT.getRawValue(0x40));
        assertEquals(0, SINGLE_BIT.getRawValue(~0x40));
    }

    @Test
    void testGetRawValueLong() {
        assertEquals(0x3F80L, MULTI_BIT.getRawValue(-1L));
        assertEquals(0L, MULTI_BIT.getRawValue(0L));
        // a mask whose bits exceed the 32-bit int range only yields a nonzero raw value from a long holder
        assertEquals(0x8000_0000_0000_0000L, HIGH_LONG_BIT.getRawValue(-1L));
        assertEquals(0, HIGH_LONG_BIT.getRawValue(-1)); // int holder widened, high bit never set
    }

    @Test
    void testGetShortRawValue() {
        assertEquals((short) 0x3F80, MULTI_BIT.getShortRawValue((short) -1));
        assertEquals((short) 0, MULTI_BIT.getShortRawValue((short) 0));
    }

    @Test
    void testGetShortValue() {
        final BitField field = new BitField(0xFF00); // bits 8-15
        assertEquals((short) 0x12, field.getShortValue((short) 0x1234));
    }

    @Test
    void testGetValueIntShiftsRight() {
        final BitField field = new BitField(0xFF00); // bits 8-15
        assertEquals(0x12, field.getValue(0x1234));
        assertEquals(0, field.getValue(0x00FF));
    }

    @Test
    void testGetValueLongShiftsRight() {
        final BitField field = new BitField(0xFF00L); // bits 8-15
        assertEquals(0x12L, field.getValue(0x1234L));
    }

    @Test
    void testGetValueWithNegativeRawValuePreservesSignExtension() {
        // mask occupies the top bits of an int; raw value is negative, and the right shift is arithmetic
        assertEquals(-1, HIGH_INT_BIT.getValue(-1));
    }

    @Test
    void testIsSetAndIsAllSetInt() {
        assertTrue(MULTI_BIT.isSet(0x3F80));
        assertTrue(MULTI_BIT.isAllSet(0x3F80));
        assertTrue(MULTI_BIT.isSet(0x1000));
        assertFalse(MULTI_BIT.isAllSet(0x1000));
        assertFalse(MULTI_BIT.isSet(0));
        assertFalse(MULTI_BIT.isAllSet(0));
    }

    @Test
    void testIsSetAndIsAllSetLong() {
        final BitField field = new BitField(0x3000L);
        assertTrue(field.isSet(0x3000L));
        assertTrue(field.isAllSet(0x3000L));
        assertTrue(field.isSet(0x1000L));
        assertFalse(field.isAllSet(0x1000L));
        assertFalse(field.isSet(0L));
    }

    @Test
    void testSetInt() {
        assertEquals(0x3F80, MULTI_BIT.set(0));
        assertEquals(-1, MULTI_BIT.set(-1));
    }

    @Test
    void testSetLong() {
        final BitField field = new BitField(0x1000L);
        assertEquals(0x1000L, field.set(0L));
        assertEquals(-1L, new BitField(-1L).set(0L));
    }

    @Test
    void testSetBooleanInt() {
        final BitField field = new BitField(0x1000);
        assertEquals(0x1000, field.setBoolean(0, true));
        assertEquals(0, field.setBoolean(0x1000, false));
    }

    @Test
    void testSetBooleanLong() {
        final BitField field = new BitField(0x1000L);
        final long setTrue = field.setBoolean(0L, true);
        assertEquals(0x1000L, setTrue);
        assertEquals(0L, field.setBoolean(setTrue, false));
    }

    @Test
    void testSetByte() {
        final BitField field = new BitField(0x40);
        assertEquals((byte) 0x40, field.setByte((byte) 0));
        assertEquals((byte) -0x40, field.setByte((byte) -0x80));
    }

    @Test
    void testSetByteBoolean() {
        final BitField field = new BitField(0x40);
        assertEquals((byte) 0x40, field.setByteBoolean((byte) 0, true));
        assertEquals((byte) 0, field.setByteBoolean((byte) 0x40, false));
    }

    @Test
    void testSetShort() {
        final BitField field = new BitField(0x4000);
        assertEquals((short) 0x4000, field.setShort((short) 0));
    }

    @Test
    void testSetShortBoolean() {
        final BitField field = new BitField(0x4000);
        assertEquals((short) 0x4000, field.setShortBoolean((short) 0, true));
        assertEquals((short) 0, field.setShortBoolean((short) 0x4000, false));
    }

    @Test
    void testSetShortValue() {
        final BitField field = new BitField(0xFF00); // bits 8-15
        assertEquals((short) 0x3434, field.setShortValue((short) 0x1234, (short) 0x34));
    }

    @Test
    void testSetValueIntReplacesOnlyMaskedBits() {
        final BitField field = new BitField(0xFF00); // bits 8-15
        assertEquals(0x3400, field.setValue(0x1200, 0x34));
        // bits of the value that fall outside the mask (after shifting) are discarded
        assertEquals(0x3400, field.setValue(0x1200, 0x1234));
    }

    @Test
    void testSetValueLongReplacesOnlyMaskedBits() {
        final BitField field = new BitField(0xFF00L); // bits 8-15
        assertEquals(0x3400L, field.setValue(0x1200L, 0x34L));
    }

    @Test
    void testSetValuePreservesBitsOutsideMask() {
        final BitField field = new BitField(0x00FF); // bits 0-7
        final int holder = 0xAB00;
        final int result = field.setValue(holder, 0xCD);
        assertEquals(0xABCD, result);
    }

    @Test
    void testMaskSpanningFullLongRangeViaNegativeOne() {
        final BitField allBits = new BitField(-1L); // every bit set, shiftCount 0
        assertEquals(0L, allBits.clear(-1L));
        assertEquals(-1L, allBits.set(0L));
        assertTrue(allBits.isAllSet(-1L));
        assertEquals(-1L, allBits.getValue(-1L));
    }
}
