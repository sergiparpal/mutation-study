/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link StopWatch}.
 */
class StopWatchAgentTest {

    private static void sleepMillis(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (final InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    // --- construction / factories ---

    @Test
    void testCreateReturnsUnstartedWatch() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0L, watch.getTime());
    }

    @Test
    void testCreateStartedReturnsStartedWatch() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
    }

    @Test
    void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    void testMessageConstructorStoresMessage() {
        final StopWatch watch = new StopWatch("hello");
        assertEquals("hello", watch.getMessage());
    }

    // --- start/stop lifecycle ---

    @Test
    void testStartThenStopRecordsElapsedTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertTrue(watch.isStarted());
        sleepMillis(20);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getTime() >= 15, "expected >= 15ms, got " + watch.getTime());
    }

    @Test
    void testStartTwiceWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testStopTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testStartAfterResetWorks() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    void testResetWhileRunningClearsState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepMillis(5);
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertEquals(0L, watch.getTime());
    }

    // --- suspend/resume ---

    @Test
    void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testSuspendThenResume() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepMillis(15);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedTime = watch.getTime();
        sleepMillis(20);
        // Time must not advance while suspended.
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStarted());
        sleepMillis(10);
        assertTrue(watch.getTime() > suspendedTime);
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testStopAfterSuspendWorks() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        watch.stop();
        assertTrue(watch.isStopped());
    }

    // --- split/unsplit ---

    @Test
    void testSplitBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testSplitWhileSuspendedThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @Test
    void testGetSplitDurationWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitDuration();
            }
        });
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.unsplit();
            }
        });
    }

    @Test
    void testSplitRecordsSplitTimeAndContinuesRunning() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepMillis(15);
        watch.split();
        assertTrue(watch.isStarted());
        assertTrue(watch.getSplitDuration().toMillis() >= 10);
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertEquals(watch.getSplitDuration(), splits.get(0).getDuration());
    }

    @Test
    void testSplitWithLabelStoresLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        assertEquals("first", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testUnsplitRemovesLastSplitAndAllowsContinuing() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitDuration();
            }
        });
        // Watch must still be running and continue timing after unsplit.
        assertTrue(watch.isStarted());
        sleepMillis(5);
        watch.stop();
        assertTrue(watch.getTime() >= 0);
    }

    @Test
    void testSplitTwiceWithoutUnsplitThrows() {
        // Per the class Javadoc: "split(), suspend(), or stop() cannot be invoked twice".
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testGetSplitsReturnsUnmodifiableList() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testStartClearsPriorSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.stop();
        watch.reset();
        watch.start();
        assertEquals(0, watch.getSplits().size());
    }

    // --- Split inner class ---

    @Test
    void testSplitClassAccessors() {
        final Duration duration = Duration.ofMillis(123);
        final StopWatch.Split split = new StopWatch.Split("label1", duration);
        assertEquals("label1", split.getLabel());
        assertEquals(duration, split.getDuration());
        assertNotNull(split.toString());
        assertTrue(split.toString().contains("label1"));
    }

    // --- timing accessors ---

    @Test
    void testGetNanoTimeUnstartedIsZero() {
        final StopWatch watch = new StopWatch();
        assertEquals(0L, watch.getNanoTime());
    }

    @Test
    void testGetDurationReflectsNanoTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepMillis(10);
        watch.stop();
        assertEquals(watch.getNanoTime(), watch.getDuration().toNanos());
    }

    @Test
    void testGetTimeInSpecifiedTimeUnit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepMillis(5);
        watch.stop();
        final long millis = watch.getTime();
        assertEquals(millis, watch.getTime(TimeUnit.MILLISECONDS));
        assertEquals(TimeUnit.MILLISECONDS.toSeconds(millis), watch.getTime(TimeUnit.SECONDS));
    }

    @Test
    void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStartInstant();
            }
        });
    }

    @Test
    void testGetStartInstantAfterStartIsNotNull() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertNotNull(watch.getStartInstant());
    }

    @Test
    void testGetStopInstantBeforeStopIsNull() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertNull(watch.getStopInstant());
    }

    @Test
    void testGetStopInstantAfterStopIsNotNull() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertNotNull(watch.getStopInstant());
    }

    @Test
    void testGetStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStopInstant();
            }
        });
    }

    @Test
    void testDeprecatedGetStartTimeMatchesInstant() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
    }

    @Test
    void testDeprecatedGetStopTimeBeforeStopIsZero() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertEquals(0L, watch.getStopTime());
    }

    @Test
    void testDeprecatedGetSplitTimeMatchesDuration() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(watch.getSplitDuration().toMillis(), watch.getSplitTime());
    }

    // --- isStarted / isStopped / isSuspended matrix ---

    @Test
    void testStateQueriesForUnstartedWatch() {
        final StopWatch watch = new StopWatch();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testStateQueriesForRunningWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testStateQueriesForSuspendedWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertTrue(watch.isSuspended());
    }

    @Test
    void testStateQueriesForStoppedWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    // --- formatting / toString ---

    @Test
    void testToStringWithoutMessageHasNoPrefix() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String s = watch.toString();
        assertFalse(s.startsWith(" "));
        assertEquals(watch.formatTime(), s);
    }

    @Test
    void testToStringWithMessageHasPrefix() {
        final StopWatch watch = new StopWatch("MyTask");
        watch.start();
        watch.stop();
        assertEquals("MyTask " + watch.formatTime(), watch.toString());
    }

    @Test
    void testToSplitStringWithMessageHasPrefix() {
        final StopWatch watch = new StopWatch("MyTask");
        watch.start();
        watch.split();
        assertEquals("MyTask " + watch.formatSplitTime(), watch.toSplitString());
    }

    @Test
    void testFormatTimeHasExpectedShape() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        // HH:mm:ss.SSS
        assertTrue(watch.formatTime().matches("\\d{2}:\\d{2}:\\d{2}\\.\\d{3}"), watch.formatTime());
    }

    // --- get/run/getT/runT delegation ---

    @Test
    void testGetDelegatesAndTimesSupplier() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                sleepMillis(10);
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getTime() >= 5);
    }

    @Test
    void testRunDelegatesAndTimesRunnable() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = {false};
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
                sleepMillis(10);
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getTime() >= 5);
    }

    @Test
    void testGetTPropagatesException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getT(new org.apache.commons.lang3.function.FailableSupplier<String, IllegalStateException>() {
                    @Override
                    public String get() {
                        throw new IllegalStateException("boom");
                    }
                });
            }
        });
        // The watch must still end up suspended (not left running) after the failure.
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesException() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new org.apache.commons.lang3.function.FailableRunnable<IllegalStateException>() {
                    @Override
                    public void run() {
                        throw new IllegalStateException("boom");
                    }
                });
            }
        });
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetOnAlreadyStoppedWatchThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.get(new java.util.function.Supplier<String>() {
                    @Override
                    public String get() {
                        return "value";
                    }
                });
            }
        });
    }
}
