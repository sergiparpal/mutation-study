/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    private static final String PROP_KEY = "DurationUtilsAgentTest.prop";

    @AfterEach
    void clearProperty() {
        System.clearProperty(PROP_KEY);
    }

    // --- accept ---

    @Test
    void testAcceptInvokesConsumerWithMillisAndNanos() throws Throwable {
        final Duration duration = Duration.ofSeconds(1).plusNanos(2500000);
        final List<Long> millisSeen = new ArrayList<>();
        final List<Integer> nanosSeen = new ArrayList<>();
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                millisSeen.add(millis);
                nanosSeen.add(nanos);
            }
        }, duration);
        assertEquals(1, millisSeen.size());
        assertEquals(duration.toMillis(), millisSeen.get(0).longValue());
        assertEquals(DurationUtils.getNanosOfMilli(duration), nanosSeen.get(0).intValue());
    }

    @Test
    void testAcceptWithNullConsumerDoesNothing() throws Throwable {
        // Should not throw.
        DurationUtils.accept(null, Duration.ofSeconds(1));
    }

    @Test
    void testAcceptWithNullDurationDoesNothing() throws Throwable {
        final List<Object> calls = new ArrayList<>();
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                calls.add(millis);
            }
        }, null);
        assertTrue(calls.isEmpty());
    }

    @Test
    void testAcceptPropagatesException() {
        final Duration duration = Duration.ofSeconds(1);
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.accept(new FailableBiConsumer<Long, Integer, IllegalStateException>() {
                    @Override
                    public void accept(final Long millis, final Integer nanos) {
                        throw new IllegalStateException("boom");
                    }
                }, duration);
            }
        });
    }

    // --- get / getMillis / getSeconds (system property backed) ---

    @Test
    void testGetReturnsDefaultWhenPropertyMissing() {
        final Duration result = DurationUtils.get(PROP_KEY, ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(42), result);
    }

    @Test
    void testGetReturnsDefaultWhenKeyNullOrEmpty() {
        assertEquals(Duration.ofSeconds(7), DurationUtils.get(null, ChronoUnit.SECONDS, 7L));
        assertEquals(Duration.ofSeconds(7), DurationUtils.get("", ChronoUnit.SECONDS, 7L));
    }

    @Test
    void testGetReadsSystemProperty() {
        System.setProperty(PROP_KEY, "5");
        final Duration result = DurationUtils.get(PROP_KEY, ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(5), result);
    }

    @Test
    void testGetMillisDefault() {
        assertEquals(Duration.ofMillis(100), DurationUtils.getMillis(PROP_KEY, 100L));
    }

    @Test
    void testGetMillisFromProperty() {
        System.setProperty(PROP_KEY, "250");
        assertEquals(Duration.ofMillis(250), DurationUtils.getMillis(PROP_KEY, 100L));
    }

    @Test
    void testGetSecondsDefault() {
        assertEquals(Duration.ofSeconds(9), DurationUtils.getSeconds(PROP_KEY, 9L));
    }

    @Test
    void testGetSecondsFromProperty() {
        System.setProperty(PROP_KEY, "3");
        assertEquals(Duration.ofSeconds(3), DurationUtils.getSeconds(PROP_KEY, 9L));
    }

    @Test
    void testGetWithUnparsablePropertyFallsBackToDefault() {
        System.setProperty(PROP_KEY, "not-a-number");
        // Long.getLong() returns the default when the property can't be parsed.
        assertEquals(Duration.ofSeconds(11), DurationUtils.getSeconds(PROP_KEY, 11L));
    }

    // --- getNanosOfMilli / getNanosOfMiili ---

    @Test
    void testGetNanosOfMilliTypicalValue() {
        final Duration duration = Duration.ofSeconds(1).plusNanos(123456789L);
        assertEquals(456789, DurationUtils.getNanosOfMilli(duration));
    }

    @Test
    void testGetNanosOfMilliZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ZERO));
    }

    @Test
    void testGetNanosOfMilliUpperBound() {
        final Duration duration = Duration.ofNanos(999999999L);
        assertEquals(999999, DurationUtils.getNanosOfMilli(duration));
    }

    @Test
    void testGetNanosOfMilliNullTreatedAsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testDeprecatedGetNanosOfMiiliDelegates() {
        final Duration duration = Duration.ofSeconds(1).plusNanos(123456789L);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    // --- isPositive ---

    @Test
    void testIsPositiveTrueForPositiveDuration() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
    }

    @Test
    void testIsPositiveFalseForZero() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    void testIsPositiveFalseForNegativeDuration() {
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    @Test
    void testIsPositiveNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.isPositive(null);
            }
        });
    }

    // --- of(FailableConsumer) / of(FailableRunnable) ---

    @Test
    void testOfConsumerMeasuresElapsedTimeAndReceivesStart() throws Throwable {
        final List<Instant> seenStart = new ArrayList<>();
        final Duration duration = DurationUtils.of(new FailableConsumer<Instant, RuntimeException>() {
            @Override
            public void accept(final Instant start) {
                seenStart.add(start);
                try {
                    Thread.sleep(20);
                } catch (final InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        assertEquals(1, seenStart.size());
        assertNotNull(seenStart.get(0));
        assertTrue(duration.toMillis() >= 15, "expected at least ~20ms, got " + duration.toMillis());
    }

    @Test
    void testOfRunnableMeasuresElapsedTime() throws Throwable {
        final Duration duration = DurationUtils.of(new FailableRunnable<RuntimeException>() {
            @Override
            public void run() {
                try {
                    Thread.sleep(20);
                } catch (final InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        assertTrue(duration.toMillis() >= 15, "expected at least ~20ms, got " + duration.toMillis());
    }

    @Test
    void testOfPropagatesException() {
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<IllegalStateException>() {
                    @Override
                    public void run() {
                        throw new IllegalStateException("boom");
                    }
                });
            }
        });
    }

    // --- since ---

    @Test
    void testSinceComputesElapsedDuration() {
        final Instant start = Instant.now().minusSeconds(5);
        final Duration duration = DurationUtils.since(start);
        assertTrue(duration.toMillis() >= 4900, "expected ~5000ms, got " + duration.toMillis());
        assertTrue(duration.toMillis() < 60000);
    }

    @Test
    void testSinceWithFutureInstantIsNegative() {
        final Instant future = Instant.now().plusSeconds(10);
        final Duration duration = DurationUtils.since(future);
        assertTrue(duration.isNegative());
    }

    // --- toChronoUnit ---

    @Test
    void testToChronoUnitMapsAllTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnitNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    // --- toDuration ---

    @Test
    void testToDurationConvertsAmountAndUnit() {
        assertEquals(Duration.ofSeconds(90), DurationUtils.toDuration(90, TimeUnit.SECONDS));
        assertEquals(Duration.ofMinutes(3), DurationUtils.toDuration(3, TimeUnit.MINUTES));
        assertEquals(Duration.ofMillis(500), DurationUtils.toDuration(500, TimeUnit.MILLISECONDS));
    }

    @Test
    void testToDurationNegativeAmount() {
        assertEquals(Duration.ofSeconds(-30), DurationUtils.toDuration(-30, TimeUnit.SECONDS));
    }

    // --- toMillisInt ---

    @Test
    void testToMillisIntTypicalValue() {
        assertEquals(1000, DurationUtils.toMillisInt(Duration.ofSeconds(1)));
    }

    @Test
    void testToMillisIntClampsToIntMax() {
        final Duration huge = Duration.ofMillis((long) Integer.MAX_VALUE + 1000L);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntClampsToIntMin() {
        final Duration huge = Duration.ofMillis((long) Integer.MIN_VALUE - 1000L);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntAtExactBoundaries() {
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(Duration.ofMillis(Integer.MAX_VALUE)));
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(Duration.ofMillis(Integer.MIN_VALUE)));
    }

    @Test
    void testToMillisIntNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    // --- zeroIfNull ---

    @Test
    void testZeroIfNullWithNullReturnsZero() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNullWithNonNullReturnsSameInstance() {
        final Duration duration = Duration.ofMinutes(2);
        assertSame(duration, DurationUtils.zeroIfNull(duration));
    }

    // --- constructor (deprecated no-arg) ---

    @Test
    void testDefaultConstructorIsUsable() {
        assertNotNull(new DurationUtils());
    }
}
