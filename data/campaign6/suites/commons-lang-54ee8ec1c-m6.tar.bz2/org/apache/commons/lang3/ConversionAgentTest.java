/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.UUID;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Conversion}.
 */
public class ConversionAgentTest {

    @Test
    public void testBinaryBeMsb0ToHexDigit() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { false, false, false, false }));
        assertEquals('f', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, true, true, true }));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitWithSrcPos() {
        final boolean[] src = { true, false, false, false, false, false, false, true, false, true, false, false };
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(src, 2));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitEmptyArrayThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryBeMsb0ToHexDigit(new boolean[0]));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitNullThrows() {
        assertThrows(NullPointerException.class, () -> Conversion.binaryBeMsb0ToHexDigit(null));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitOutOfBoundsThrows() {
        final boolean[] src = { true, false, false, false };
        assertThrows(IndexOutOfBoundsException.class, () -> Conversion.binaryBeMsb0ToHexDigit(src, 4));
    }

    @Test
    public void testBinaryToByte() {
        final boolean[] src = { true, false, true, false };
        final byte result = Conversion.binaryToByte(src, 0, (byte) 0, 0, 4);
        assertEquals((byte) 0x5, result);
    }

    @Test
    public void testBinaryToByteZeroBoolsReturnsInit() {
        assertEquals((byte) 0x7F, Conversion.binaryToByte(new boolean[0], 0, (byte) 0x7F, 0, 0));
    }

    @Test
    public void testBinaryToByteEmptySrcAndSrcPosZeroReturnsInit() {
        assertEquals((byte) 0x12, Conversion.binaryToByte(new boolean[0], 0, (byte) 0x12, 0, 0));
    }

    @Test
    public void testBinaryToByteOutOfRangeThrows() {
        final boolean[] src = { true, true, true, true, true, true, true, true, true };
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToByte(src, 0, (byte) 0, 2, 7));
    }

    @Test
    public void testBinaryToByteNullSrcThrows() {
        assertThrows(NullPointerException.class, () -> Conversion.binaryToByte(null, 1, (byte) 0, 0, 2));
    }

    @Test
    public void testBinaryToHexDigit() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryToHexDigit(new boolean[] { false, false, false, false }));
        assertEquals('f', Conversion.binaryToHexDigit(new boolean[] { true, true, true, true }));
    }

    @Test
    public void testBinaryToHexDigitWithSrcPos() {
        final boolean[] src = { false, false, true, false, false, false, false };
        assertEquals('1', Conversion.binaryToHexDigit(src, 2));
    }

    @Test
    public void testBinaryToHexDigitEmptyThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToHexDigit(new boolean[0]));
    }

    @Test
    public void testBinaryToHexDigitNullThrows() {
        assertThrows(NullPointerException.class, () -> Conversion.binaryToHexDigit(null));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bits() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { false, false, false, false }));
        assertEquals('f', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, true, true, true }));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooLongThrows() {
        final boolean[] src = new boolean[9];
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToHexDigitMsb0_4bits(src));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooShortThrows() {
        final boolean[] src = { true, false, false };
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToHexDigitMsb0_4bits(src, 0));
    }

    @Test
    public void testBinaryToInt() {
        final boolean[] src = { true, false, true, false };
        assertEquals(0x5, Conversion.binaryToInt(src, 0, 0, 0, 4));
    }

    @Test
    public void testBinaryToIntZeroBoolsReturnsInit() {
        assertEquals(42, Conversion.binaryToInt(new boolean[0], 0, 42, 0, 0));
    }

    @Test
    public void testBinaryToIntOutOfRangeThrows() {
        final boolean[] src = new boolean[33];
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToInt(src, 0, 0, 1, 32));
    }

    @Test
    public void testBinaryToLong() {
        final boolean[] src = { true, false, true, false };
        assertEquals(0x5L, Conversion.binaryToLong(src, 0, 0L, 0, 4));
    }

    @Test
    public void testBinaryToLongZeroBoolsReturnsInit() {
        assertEquals(123L, Conversion.binaryToLong(new boolean[0], 0, 123L, 0, 0));
    }

    @Test
    public void testBinaryToLongOutOfRangeThrows() {
        final boolean[] src = new boolean[65];
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToLong(src, 0, 0L, 1, 64));
    }

    @Test
    public void testBinaryToShort() {
        final boolean[] src = { true, false, true, false };
        assertEquals((short) 0x5, Conversion.binaryToShort(src, 0, (short) 0, 0, 4));
    }

    @Test
    public void testBinaryToShortZeroBoolsReturnsInit() {
        assertEquals((short) 7, Conversion.binaryToShort(new boolean[0], 0, (short) 7, 0, 0));
    }

    @Test
    public void testBinaryToShortOutOfRangeThrows() {
        final boolean[] src = new boolean[17];
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToShort(src, 0, (short) 0, 1, 16));
    }

    @Test
    public void testByteArrayToInt() {
        final byte[] src = { (byte) 0x01, (byte) 0x02 };
        assertEquals(0x0201, Conversion.byteArrayToInt(src, 0, 0, 0, 2));
    }

    @Test
    public void testByteArrayToIntZeroBytesReturnsInit() {
        assertEquals(99, Conversion.byteArrayToInt(new byte[0], 0, 99, 0, 0));
    }

    @Test
    public void testByteArrayToIntOutOfRangeThrows() {
        final byte[] src = { 1, 2, 3, 4, 5 };
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteArrayToInt(src, 0, 0, 8, 5));
    }

    @Test
    public void testByteArrayToIntArrayIndexOutOfBoundsThrows() {
        final byte[] src = { 1, 2 };
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> Conversion.byteArrayToInt(src, 0, 0, 0, 4));
    }

    @Test
    public void testByteArrayToLong() {
        final byte[] src = { (byte) 0x01, (byte) 0x02 };
        assertEquals(0x0201L, Conversion.byteArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    public void testByteArrayToLongZeroBytesReturnsInit() {
        assertEquals(55L, Conversion.byteArrayToLong(new byte[0], 0, 55L, 0, 0));
    }

    @Test
    public void testByteArrayToLongOutOfRangeThrows() {
        final byte[] src = new byte[9];
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteArrayToLong(src, 0, 0L, 8, 9));
    }

    @Test
    public void testByteArrayToShort() {
        final byte[] src = { (byte) 0x01, (byte) 0x02 };
        assertEquals((short) 0x0201, Conversion.byteArrayToShort(src, 0, (short) 0, 0, 2));
    }

    @Test
    public void testByteArrayToShortZeroBytesReturnsInit() {
        assertEquals((short) 11, Conversion.byteArrayToShort(new byte[0], 0, (short) 11, 0, 0));
    }

    @Test
    public void testByteArrayToShortOutOfRangeThrows() {
        final byte[] src = { 1, 2, 3 };
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteArrayToShort(src, 0, (short) 0, 8, 3));
    }

    @Test
    public void testByteArrayToUuid() {
        final byte[] src = new byte[16];
        for (int i = 0; i < 16; i++) {
            src[i] = (byte) (i + 1);
        }
        final UUID uuid = Conversion.byteArrayToUuid(src, 0);
        final byte[] roundTrip = Conversion.uuidToByteArray(uuid, new byte[16], 0, 16);
        assertArrayEquals(src, roundTrip);
    }

    @Test
    public void testByteArrayToUuidTooShortThrows() {
        final byte[] src = new byte[15];
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteArrayToUuid(src, 0));
    }

    @Test
    public void testByteArrayToUuidNullThrows() {
        assertThrows(NullPointerException.class, () -> Conversion.byteArrayToUuid(null, 0));
    }

    @Test
    public void testByteToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.byteToBinary((byte) 0x5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);
    }

    @Test
    public void testByteToBinaryZeroBoolsReturnsDstUnchanged() {
        final boolean[] dst = new boolean[2];
        assertSame(dst, Conversion.byteToBinary((byte) 0xFF, 0, dst, 0, 0));
        assertArrayEquals(new boolean[] { false, false }, dst);
    }

    @Test
    public void testByteToBinaryNullDstThrows() {
        assertThrows(NullPointerException.class, () -> Conversion.byteToBinary((byte) 1, 0, null, 0, 1));
    }

    @Test
    public void testByteToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteToBinary((byte) 1, 4, new boolean[8], 0, 5));
    }

    @Test
    public void testByteToHex() {
        final String result = Conversion.byteToHex((byte) 0xAB, 0, "", 0, 2);
        assertEquals("ba", result);
    }

    @Test
    public void testByteToHexZeroHexsReturnsInit() {
        assertEquals("init", Conversion.byteToHex((byte) 1, 0, "init", 0, 0));
    }

    @Test
    public void testByteToHexOverwritesExistingChars() {
        final String result = Conversion.byteToHex((byte) 0x0F, 0, "xx", 0, 1);
        assertEquals("fx", result);
    }

    @Test
    public void testByteToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteToHex((byte) 1, 4, "", 0, 2));
    }

    @Test
    public void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] { false, false, false, true }, Conversion.hexDigitMsb0ToBinary('1'));
        assertArrayEquals(new boolean[] { true, false, false, false }, Conversion.hexDigitMsb0ToBinary('8'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('f'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('F'));
    }

    @Test
    public void testHexDigitMsb0ToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitMsb0ToBinary('g'));
    }

    @Test
    public void testHexDigitMsb0ToInt() {
        assertEquals(0x0, Conversion.hexDigitMsb0ToInt('0'));
        assertEquals(0x8, Conversion.hexDigitMsb0ToInt('1'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('f'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('F'));
    }

    @Test
    public void testHexDigitMsb0ToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitMsb0ToInt('z'));
    }

    @Test
    public void testHexDigitToBinary() {
        assertArrayEquals(new boolean[] { true, false, false, false }, Conversion.hexDigitToBinary('1'));
        assertArrayEquals(new boolean[] { false, false, false, false }, Conversion.hexDigitToBinary('0'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('f'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('F'));
    }

    @Test
    public void testHexDigitToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitToBinary('g'));
    }

    @Test
    public void testHexDigitToInt() {
        assertEquals(1, Conversion.hexDigitToInt('1'));
        assertEquals(0, Conversion.hexDigitToInt('0'));
        assertEquals(15, Conversion.hexDigitToInt('f'));
        assertEquals(15, Conversion.hexDigitToInt('F'));
    }

    @Test
    public void testHexDigitToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitToInt('g'));
    }

    @Test
    public void testHexToByte() {
        assertEquals((byte) 0xBA, Conversion.hexToByte("ab", 0, (byte) 0, 0, 2));
    }

    @Test
    public void testHexToByteZeroHexReturnsInit() {
        assertEquals((byte) 5, Conversion.hexToByte("ab", 0, (byte) 5, 0, 0));
    }

    @Test
    public void testHexToByteOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToByte("abc", 0, (byte) 0, 0, 3));
    }

    @Test
    public void testHexToByteInvalidCharThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToByte("ag", 0, (byte) 0, 0, 2));
    }

    @Test
    public void testHexToInt() {
        assertEquals(0xCAFE, Conversion.hexToInt("efac", 0, 0, 0, 4));
    }

    @Test
    public void testHexToIntZeroHexReturnsInit() {
        assertEquals(7, Conversion.hexToInt("ab", 0, 7, 0, 0));
    }

    @Test
    public void testHexToIntOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToInt("123456789", 0, 0, 0, 9));
    }

    @Test
    public void testHexToLong() {
        assertEquals(0xCAFEL, Conversion.hexToLong("efac", 0, 0L, 0, 4));
    }

    @Test
    public void testHexToLongZeroHexReturnsInit() {
        assertEquals(3L, Conversion.hexToLong("ab", 0, 3L, 0, 0));
    }

    @Test
    public void testHexToLongOutOfRangeThrows() {
        final String src = "123456789012345678";
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToLong(src, 0, 0L, 0, 17));
    }

    @Test
    public void testHexToShort() {
        assertEquals((short) 0xCAFE, Conversion.hexToShort("efac", 0, (short) 0, 0, 4));
    }

    @Test
    public void testHexToShortZeroHexReturnsInit() {
        assertEquals((short) 9, Conversion.hexToShort("ab", 0, (short) 9, 0, 0));
    }

    @Test
    public void testHexToShortOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToShort("12345", 0, (short) 0, 0, 5));
    }

    @Test
    public void testIntArrayToLong() {
        final int[] src = { 0x00000001, 0x00000002 };
        assertEquals(0x0000000200000001L, Conversion.intArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    public void testIntArrayToLongZeroIntsReturnsInit() {
        assertEquals(13L, Conversion.intArrayToLong(new int[0], 0, 13L, 0, 0));
    }

    @Test
    public void testIntArrayToLongOutOfRangeThrows() {
        final int[] src = { 1, 2, 3 };
        assertThrows(IllegalArgumentException.class, () -> Conversion.intArrayToLong(src, 0, 0L, 32, 3));
    }

    @Test
    public void testIntArrayToLongArrayIndexOutOfBoundsThrows() {
        final int[] src = { 1 };
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> Conversion.intArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    public void testIntToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.intToBinary(0x5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);
    }

    @Test
    public void testIntToBinaryZeroBoolsReturnsDst() {
        final boolean[] dst = new boolean[1];
        assertSame(dst, Conversion.intToBinary(1, 0, dst, 0, 0));
    }

    @Test
    public void testIntToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToBinary(1, 31, new boolean[32], 0, 2));
    }

    @Test
    public void testIntToByteArray() {
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.intToByteArray(0x04030201, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02, 0x03, 0x04 }, result);
    }

    @Test
    public void testIntToByteArrayZeroBytesReturnsDst() {
        final byte[] dst = new byte[1];
        assertSame(dst, Conversion.intToByteArray(1, 0, dst, 0, 0));
    }

    @Test
    public void testIntToByteArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToByteArray(1, 25, new byte[4], 0, 2));
    }

    @Test
    public void testIntToHex() {
        final String result = Conversion.intToHex(0x1234ABCD, 0, "", 0, 8);
        assertEquals("dcba4321", result);
    }

    @Test
    public void testIntToHexZeroHexsReturnsInit() {
        assertEquals("init", Conversion.intToHex(1, 0, "init", 0, 0));
    }

    @Test
    public void testIntToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHex(1, 29, "", 0, 2));
    }

    @Test
    public void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('1', Conversion.intToHexDigit(1));
        assertEquals('a', Conversion.intToHexDigit(10));
        assertEquals('f', Conversion.intToHexDigit(15));
    }

    @Test
    public void testIntToHexDigitBelowRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigit(-1));
    }

    @Test
    public void testIntToHexDigitAboveRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigit(16));
    }

    @Test
    public void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0x0));
        assertEquals('8', Conversion.intToHexDigitMsb0(0x1));
        assertEquals('f', Conversion.intToHexDigitMsb0(0xF));
    }

    @Test
    public void testIntToHexDigitMsb0BelowRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigitMsb0(-1));
    }

    @Test
    public void testIntToHexDigitMsb0AboveRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigitMsb0(16));
    }

    @Test
    public void testIntToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.intToShortArray(0x00020001, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 0x0001, 0x0002 }, result);
    }

    @Test
    public void testIntToShortArrayZeroShortsReturnsDst() {
        final short[] dst = new short[1];
        assertSame(dst, Conversion.intToShortArray(1, 0, dst, 0, 0));
    }

    @Test
    public void testIntToShortArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToShortArray(1, 17, new short[2], 0, 2));
    }

    @Test
    public void testLongToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.longToBinary(0x5L, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);
    }

    @Test
    public void testLongToBinaryZeroBoolsReturnsDst() {
        final boolean[] dst = new boolean[1];
        assertSame(dst, Conversion.longToBinary(1L, 0, dst, 0, 0));
    }

    @Test
    public void testLongToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToBinary(1L, 63, new boolean[64], 0, 2));
    }

    @Test
    public void testLongToByteArray() {
        final byte[] dst = new byte[8];
        final byte[] result = Conversion.longToByteArray(0x0807060504030201L, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 }, result);
    }

    @Test
    public void testLongToByteArrayZeroBytesReturnsDst() {
        final byte[] dst = new byte[1];
        assertSame(dst, Conversion.longToByteArray(1L, 0, dst, 0, 0));
    }

    @Test
    public void testLongToByteArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToByteArray(1L, 57, new byte[8], 0, 2));
    }

    @Test
    public void testLongToHex() {
        final String result = Conversion.longToHex(0x1234ABCDL, 0, "", 0, 8);
        assertEquals("dcba4321", result);
    }

    @Test
    public void testLongToHexZeroHexsReturnsInit() {
        assertEquals("init", Conversion.longToHex(1L, 0, "init", 0, 0));
    }

    @Test
    public void testLongToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToHex(1L, 61, "", 0, 2));
    }

    @Test
    public void testLongToIntArray() {
        final int[] dst = new int[2];
        final int[] result = Conversion.longToIntArray(0x0000000200000001L, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new int[] { 1, 2 }, result);
    }

    @Test
    public void testLongToIntArrayZeroIntsReturnsDst() {
        final int[] dst = new int[1];
        assertSame(dst, Conversion.longToIntArray(1L, 0, dst, 0, 0));
    }

    @Test
    public void testLongToIntArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToIntArray(1L, 33, new int[2], 0, 2));
    }

    @Test
    public void testLongToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.longToShortArray(0x0002000000000001L, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 1, 0 }, result);
    }

    @Test
    public void testLongToShortArrayZeroShortsReturnsDst() {
        final short[] dst = new short[1];
        assertSame(dst, Conversion.longToShortArray(1L, 0, dst, 0, 0));
    }

    @Test
    public void testLongToShortArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToShortArray(1L, 49, new short[4], 0, 2));
    }

    @Test
    public void testShortArrayToInt() {
        final short[] src = { 0x0001, 0x0002 };
        assertEquals(0x00020001, Conversion.shortArrayToInt(src, 0, 0, 0, 2));
    }

    @Test
    public void testShortArrayToIntZeroShortsReturnsInit() {
        assertEquals(44, Conversion.shortArrayToInt(new short[0], 0, 44, 0, 0));
    }

    @Test
    public void testShortArrayToIntOutOfRangeThrows() {
        final short[] src = { 1, 2 };
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortArrayToInt(src, 0, 0, 16, 2));
    }

    @Test
    public void testShortArrayToLong() {
        final short[] src = { 0x0001, 0x0002 };
        assertEquals(0x00020001L, Conversion.shortArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    public void testShortArrayToLongZeroShortsReturnsInit() {
        assertEquals(88L, Conversion.shortArrayToLong(new short[0], 0, 88L, 0, 0));
    }

    @Test
    public void testShortArrayToLongOutOfRangeThrows() {
        final short[] src = { 1, 2 };
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortArrayToLong(src, 0, 0L, 56, 2));
    }

    @Test
    public void testShortToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.shortToBinary((short) 0x5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);
    }

    @Test
    public void testShortToBinaryZeroBoolsReturnsDst() {
        final boolean[] dst = new boolean[1];
        assertSame(dst, Conversion.shortToBinary((short) 1, 0, dst, 0, 0));
    }

    @Test
    public void testShortToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortToBinary((short) 1, 15, new boolean[16], 0, 2));
    }

    @Test
    public void testShortToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.shortToByteArray((short) 0x0201, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02 }, result);
    }

    @Test
    public void testShortToByteArrayZeroBytesReturnsDst() {
        final byte[] dst = new byte[1];
        assertSame(dst, Conversion.shortToByteArray((short) 1, 0, dst, 0, 0));
    }

    @Test
    public void testShortToByteArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortToByteArray((short) 1, 9, new byte[2], 0, 2));
    }

    @Test
    public void testShortToHex() {
        final String result = Conversion.shortToHex((short) 0x1234, 0, "", 0, 4);
        assertEquals("4321", result);
    }

    @Test
    public void testShortToHexZeroHexsReturnsInit() {
        assertEquals("init", Conversion.shortToHex((short) 1, 0, "init", 0, 0));
    }

    @Test
    public void testShortToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortToHex((short) 1, 13, "", 0, 2));
    }

    @Test
    public void testUuidToByteArray() {
        final UUID uuid = new UUID(0x0102030405060708L, 0x090A0B0C0D0E0F10L);
        final byte[] dst = new byte[16];
        final byte[] result = Conversion.uuidToByteArray(uuid, dst, 0, 16);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 8, 7, 6, 5, 4, 3, 2, 1, 0x10, 0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09 }, result);
    }

    @Test
    public void testUuidToByteArrayZeroBytesReturnsDst() {
        final UUID uuid = new UUID(1L, 2L);
        final byte[] dst = new byte[1];
        assertSame(dst, Conversion.uuidToByteArray(uuid, dst, 0, 0));
    }

    @Test
    public void testUuidToByteArrayTooManyBytesThrows() {
        final UUID uuid = new UUID(1L, 2L);
        assertThrows(IllegalArgumentException.class, () -> Conversion.uuidToByteArray(uuid, new byte[20], 0, 17));
    }

    @Test
    public void testUuidToByteArrayNullSrcThrows() {
        assertThrows(NullPointerException.class, () -> Conversion.uuidToByteArray(null, new byte[16], 0, 16));
    }

    @Test
    public void testConstructorDeprecatedButUsable() {
        final Conversion conversion = new Conversion();
        assertEquals(Conversion.class, conversion.getClass());
    }
}
