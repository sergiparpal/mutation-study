/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained JUnit tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    // --- abbreviate ---

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 10));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    // --- abbreviateMiddle ---

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, ".", 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 10));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    // --- appendIfMissing / prependIfMissing ---

    @Test
    public void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "a"));
        assertEquals("abc", StringUtils.appendIfMissing("abc", "c"));
        assertEquals("abccc", StringUtils.appendIfMissing("abc", "cc"));
        assertEquals("a", StringUtils.appendIfMissing("", "a"));
    }

    @Test
    public void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, "a"));
        assertEquals("abc", StringUtils.prependIfMissing("abc", "a"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
    }

    // --- capitalize / uncapitalize ---

    @Test
    public void testCapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAT", StringUtils.capitalize("CAT"));
        assertEquals("'cat'", StringUtils.capitalize("'cat'"));
    }

    @Test
    public void testUncapitalize() {
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    // --- center ---

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertEquals("  ab  ", StringUtils.center("ab", 6));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
    }

    // --- chomp / chop ---

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc\r"));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    // --- compare ---

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
    }

    @Test
    public void testCompareNullIsLess() {
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare(null, "a", true) < 0);
    }

    // --- contains family ---

    @Test
    public void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsChar() {
        assertFalse(StringUtils.contains(null, 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContainsAny() {
        assertFalse(StringUtils.containsAny(null, 'a', 'b'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", 'z', 'y'));
    }

    @Test
    public void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "z"));
    }

    @Test
    public void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace(" "));
        assertTrue(StringUtils.containsWhitespace("ab c"));
        assertFalse(StringUtils.containsWhitespace("abc"));
    }

    // --- countMatches ---

    @Test
    public void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", null));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(3, StringUtils.countMatches("aaa", "a"));
        assertEquals(2, StringUtils.countMatches("abcabc", "abc"));
    }

    // --- defaultIfBlank / defaultIfEmpty / defaultString ---

    @Test
    public void testDefaultIfBlank() {
        assertEquals("d", StringUtils.defaultIfBlank(null, "d"));
        assertEquals("d", StringUtils.defaultIfBlank("  ", "d"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "d"));
        assertNull(StringUtils.defaultIfBlank(" ", null));
    }

    @Test
    public void testDefaultIfEmpty() {
        assertEquals("d", StringUtils.defaultIfEmpty(null, "d"));
        assertEquals("d", StringUtils.defaultIfEmpty("", "d"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "d"));
    }

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
    }

    // --- deleteWhitespace ---

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("a b  c\t\n"));
    }

    // --- difference ---

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("ty", StringUtils.difference("ab", "aty"));
    }

    // --- endsWith / startsWith family ---

    @Test
    public void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "a"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
    }

    @Test
    public void testEndsWithIgnoreCase() {
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
    }

    @Test
    public void testEndsWithAny() {
        assertFalse(StringUtils.endsWithAny(null, "a"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "abc"));
    }

    @Test
    public void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "a"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithIgnoreCase() {
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAny() {
        assertFalse(StringUtils.startsWithAny(null, "a"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
    }

    // --- equals family ---

    @Test
    public void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    public void testEqualsAny() {
        assertFalse(StringUtils.equalsAny("abc"));
        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
    }

    // --- firstNonBlank / firstNonEmpty ---

    @Test
    public void testFirstNonBlank() {
        assertNull(StringUtils.firstNonBlank());
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));
    }

    @Test
    public void testFirstNonEmpty() {
        assertNull(StringUtils.firstNonEmpty());
        assertNull(StringUtils.firstNonEmpty(null, ""));
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
    }

    // --- getCommonPrefix ---

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("abc", StringUtils.getCommonPrefix("abc"));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
    }

    // --- getDigits ---

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("123", StringUtils.getDigits("a1b2c3"));
    }

    // --- getLevenshteinDistance ---

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });
    }

    @Test
    public void testGetLevenshteinDistanceWithThreshold() {
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd", 2));
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "xyz", 1));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("abc", "abd", -1);
            }
        });
    }

    // --- indexOf family ---

    @Test
    public void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
    }

    @Test
    public void testIndexOfChar() {
        assertEquals(-1, StringUtils.indexOf(null, 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
    }

    @Test
    public void testIndexOfAny() {
        assertEquals(-1, StringUtils.indexOfAny(null, 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", (char[]) null));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", 'm'));
    }

    @Test
    public void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
    }

    @Test
    public void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("abc", "abd"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
    }

    // --- isXxx family ---

    @Test
    public void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("abc"));
    }

    @Test
    public void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
    }

    @Test
    public void testIsNotBlank() {
        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank("  "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    public void testIsAllBlank() {
        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank((String) null, " "));
        assertFalse(StringUtils.isAllBlank(null, "abc"));
    }

    @Test
    public void testIsAnyBlank() {
        assertFalse(StringUtils.isAnyBlank());
        assertTrue(StringUtils.isAnyBlank("abc", null));
        assertFalse(StringUtils.isAnyBlank("abc", "def"));
    }

    @Test
    public void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));
    }

    @Test
    public void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    public void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));
    }

    @Test
    public void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace("ab2c"));
    }

    @Test
    public void testIsAllLowerCase() {
        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab c"));
    }

    @Test
    public void testIsAllUpperCase() {
        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));
    }

    @Test
    public void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    @Test
    public void testIsAsciiPrintable() {
        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable(""));
        assertTrue(StringUtils.isAsciiPrintable("abc123 !"));
        assertFalse(StringUtils.isAsciiPrintable("ab\u0000c"));
    }

    // --- join ---

    @Test
    public void testJoinObjectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    public void testJoinWithStartEnd() {
        final Object[] array = {"a", "b", "c", "d"};
        assertEquals("b,c", StringUtils.join(array, ',', 1, 3));
        assertEquals("", StringUtils.join(array, ',', 2, 2));
    }

    @Test
    public void testJoinIterable() {
        assertNull(StringUtils.join((Iterable<?>) null, ','));
        assertEquals("a;b", StringUtils.join(Arrays.asList("a", "b"), ';'));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a-b-c", StringUtils.joinWith("-", "a", "b", "c"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    // --- lastIndexOf ---

    @Test
    public void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(-1, StringUtils.lastIndexOf("abc", null));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));
    }

    @Test
    public void testLastIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.lastIndexOfIgnoreCase(null, "A"));
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B"));
    }

    // --- left / right / mid ---

    @Test
    public void testLeft() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("", 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testRight() {
        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testMid() {
        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("abc", StringUtils.mid("abc", -1, 4));
    }

    // --- leftPad / rightPad ---

    @Test
    public void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", 1));
        assertEquals("xxbat", StringUtils.leftPad("bat", 5, 'x'));
    }

    @Test
    public void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("bat", StringUtils.rightPad("bat", 1));
        assertEquals("batxx", StringUtils.rightPad("bat", 5, 'x'));
    }

    // --- length ---

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    // --- lowerCase / upperCase ---

    @Test
    public void testLowerCaseUpperCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ENGLISH));
    }

    // --- normalizeSpace ---

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    // --- ordinalIndexOf ---

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
    }

    // --- overlay ---

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, null, 2, -1));
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
    }

    // --- remove family ---

    @Test
    public void testRemoveChar() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("abc", StringUtils.remove("abc", 'z'));
    }

    @Test
    public void testRemoveString() {
        assertNull(StringUtils.remove((String) null, "a"));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("abc", StringUtils.remove("abc", ""));
        assertEquals("abc", StringUtils.remove("abc", (String) null));
    }

    @Test
    public void testRemoveStart() {
        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
    }

    @Test
    public void testRemoveEnd() {
        assertNull(StringUtils.removeEnd(null, ".com"));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("abc", StringUtils.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveIgnoreCase() {
        assertNull(StringUtils.removeIgnoreCase(null, "ue"));
        assertEquals("qd", StringUtils.removeIgnoreCase("queued", "UE"));
    }

    // --- repeat ---

    @Test
    public void testRepeatChar() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("", StringUtils.repeat('e', -2));
        assertEquals("eee", StringUtils.repeat('e', 3));
    }

    @Test
    public void testRepeatString() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("", 3));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
    }

    @Test
    public void testRepeatStringSeparator() {
        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("", StringUtils.repeat("ab", "-", 0));
        assertEquals("ab-ab-ab", StringUtils.repeat("ab", "-", 3));
    }

    // --- replace family ---

    @Test
    public void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("any", StringUtils.replace("any", "a", null));
        assertEquals("zzz", StringUtils.replace("aaa", "a", "z"));
    }

    @Test
    public void testReplaceWithMax() {
        assertEquals("zzaa", StringUtils.replace("aaaa", "a", "z", 2));
        assertEquals("aaaa", StringUtils.replace("aaaa", "a", "z", 0));
        assertEquals("zzzz", StringUtils.replace("aaaa", "a", "z", -1));
    }

    @Test
    public void testReplaceOnce() {
        assertEquals("zaa", StringUtils.replaceOnce("aaa", "a", "z"));
    }

    @Test
    public void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
        assertEquals("bbbb", StringUtils.replaceChars("aaaa", 'a', 'b'));
    }

    @Test
    public void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abc", new String[] {"a"}, new String[] {"b", "c"});
            }
        });
    }

    // --- reverse ---

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    // --- split family ---

    @Test
    public void testSplit() {
        assertNull(StringUtils.split(null));
        assertEquals(0, StringUtils.split("").length);
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
    }

    @Test
    public void testSplitMaxArg() {
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));
    }

    @Test
    public void testSplitPreserveAllTokens() {
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
    }

    @Test
    public void testSplitByWholeSeparator() {
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertNull(StringUtils.splitByWholeSeparator(null, "-"));
    }

    // --- strip / trim family ---

    @Test
    public void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
    }

    @Test
    public void testStripStripChars() {
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
        assertNull(StringUtils.strip(null, "x"));
    }

    @Test
    public void testStripToEmpty() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("abc", StringUtils.stripToEmpty(" abc "));
    }

    @Test
    public void testStripToNull() {
        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull(" abc "));
    }

    @Test
    public void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    public void testTrimToEmpty() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));
    }

    @Test
    public void testTrimToNull() {
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull(" abc "));
    }

    // --- substring family ---

    @Test
    public void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 10));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cd", StringUtils.substring("abcde", 2, 4));
        assertEquals("abc", StringUtils.substring("abcde", 0, -2));
        assertEquals("", StringUtils.substring("abcde", 10, 20));
    }

    @Test
    public void testSubstringAfter() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
        assertEquals("", StringUtils.substringAfter("abc", "x"));
    }

    @Test
    public void testSubstringBefore() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));
    }

    @Test
    public void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("bar", StringUtils.substringBetween("<foo>bar</foo>", "<foo>", "</foo>"));
        assertNull(StringUtils.substringBetween("abc", "1", "2"));
    }

    @Test
    public void testSubstringsBetween() {
        assertArrayEquals(new String[] {"bar", "baz"},
                StringUtils.substringsBetween("[bar][baz]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    // --- swapCase ---

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("aC", StringUtils.swapCase("Ac"));
    }

    // --- truncate ---

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abc", StringUtils.truncate("abcdefgh", 3));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });
    }

    @Test
    public void testTruncateWithOffset() {
        assertEquals("cde", StringUtils.truncate("abcdefgh", 2, 3));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1, 2);
            }
        });
    }

    // --- unwrap / wrap ---

    @Test
    public void testWrapChar() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("'abc'", StringUtils.wrap("abc", '\''));
    }

    @Test
    public void testWrapIfMissing() {
        assertEquals("'abc'", StringUtils.wrapIfMissing("abc", '\''));
        assertEquals("'abc'", StringUtils.wrapIfMissing("'abc'", '\''));
    }

    @Test
    public void testUnwrap() {
        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("abc", StringUtils.unwrap("abc", '\''));
    }

    // --- getBytes ---

    @Test
    public void testGetBytes() {
        assertArrayEquals(new byte[0], StringUtils.getBytes(null, java.nio.charset.StandardCharsets.UTF_8));
        assertArrayEquals("abc".getBytes(java.nio.charset.StandardCharsets.UTF_8),
                StringUtils.getBytes("abc", java.nio.charset.StandardCharsets.UTF_8));
    }

    // --- toRootLowerCase / toRootUpperCase ---

    @Test
    public void testToRootLowerUpperCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    // --- valueOf ---

    @Test
    public void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    // --- rotate ---

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    // --- constants / constructor ---

    @Test
    public void testConstants() {
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("", StringUtils.EMPTY);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }

    @Test
    public void testConstructorIsPublicForBeanCompliance() {
        final StringUtils instance = new StringUtils();
        assertSame(StringUtils.class, instance.getClass());
    }
}
