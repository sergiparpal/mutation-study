/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link SystemProperties}.
 */
class SystemPropertiesAgentTest {

    private static final String ABSENT_KEY = "org.apache.commons.lang3.SystemPropertiesAgentTest.absent";

    private String savedValue;
    private String savedKey;

    @AfterEach
    void restoreProperty() {
        if (savedKey != null) {
            if (savedValue == null) {
                System.clearProperty(savedKey);
            } else {
                System.setProperty(savedKey, savedValue);
            }
            savedKey = null;
            savedValue = null;
        }
    }

    private void setTempProperty(final String key, final String value) {
        savedKey = key;
        savedValue = System.getProperty(key);
        System.setProperty(key, value);
    }

    private void clearTempProperty(final String key) {
        savedKey = key;
        savedValue = System.getProperty(key);
        System.clearProperty(key);
    }

    @Test
    void testConstantsMatchJavaSystemPropertyNames() {
        assertEquals("file.encoding", SystemProperties.FILE_ENCODING);
        assertEquals("file.separator", SystemProperties.FILE_SEPARATOR);
        assertEquals("line.separator", SystemProperties.LINE_SEPARATOR);
        assertEquals("java.version", SystemProperties.JAVA_VERSION);
        assertEquals("user.home", SystemProperties.USER_HOME);
        assertEquals("user.name", SystemProperties.USER_NAME);
        assertEquals("path.separator", SystemProperties.PATH_SEPARATOR);
    }

    @Test
    void testDeprecatedConstructorIsUsable() {
        assertNotNull(new SystemProperties());
    }

    @Test
    void testGetPropertyReturnsNullForAbsentProperty() {
        assertNull(SystemProperties.getProperty(ABSENT_KEY));
    }

    @Test
    void testGetPropertyReturnsNullForEmptyPropertyName() {
        assertNull(SystemProperties.getProperty(""));
    }

    @Test
    void testGetPropertyReturnsNullForNullPropertyName() {
        assertNull(SystemProperties.getProperty((String) null));
    }

    @Test
    void testGetPropertyReturnsSetValue() {
        setTempProperty(ABSENT_KEY, "myValue");
        assertEquals("myValue", SystemProperties.getProperty(ABSENT_KEY));
    }

    @Test
    void testGetFileEncodingMatchesSystemProperty() {
        assertEquals(System.getProperty("file.encoding"), SystemProperties.getFileEncoding());
    }

    @Test
    void testGetLineSeparatorMatchesSystemProperty() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator());
    }

    @Test
    void testGetUserHomeMatchesSystemProperty() {
        assertEquals(System.getProperty("user.home"), SystemProperties.getUserHome());
    }

    @Test
    void testGetJavaVersionMatchesSystemProperty() {
        assertEquals(System.getProperty("java.version"), SystemProperties.getJavaVersion());
    }

    @Test
    void testIsPropertySetTrueForKnownProperty() {
        assertTrue(SystemProperties.isPropertySet("java.version"));
    }

    @Test
    void testIsPropertySetFalseForUnknownProperty() {
        assertFalse(SystemProperties.isPropertySet(ABSENT_KEY));
    }

    @Test
    void testIsPropertySetFalseForNullProperty() {
        assertFalse(SystemProperties.isPropertySet(null));
    }

    @Test
    void testGetBooleanUsesDefaultSupplierWhenAbsentTrue() {
        assertTrue(SystemProperties.getBoolean(ABSENT_KEY, () -> true));
    }

    @Test
    void testGetBooleanUsesDefaultSupplierWhenAbsentFalse() {
        assertFalse(SystemProperties.getBoolean(ABSENT_KEY, () -> false));
    }

    @Test
    void testGetBooleanReturnsFalseWhenAbsentAndDefaultSupplierIsNull() {
        assertFalse(SystemProperties.getBoolean(ABSENT_KEY, null));
    }

    @Test
    void testGetBooleanParsesTrueIgnoringCase() {
        setTempProperty(ABSENT_KEY, "TRUE");
        assertTrue(SystemProperties.getBoolean(ABSENT_KEY, () -> false));
    }

    @Test
    void testGetBooleanParsesNonTrueStringAsFalse() {
        setTempProperty(ABSENT_KEY, "yes");
        assertFalse(SystemProperties.getBoolean(ABSENT_KEY, () -> true));
    }

    @Test
    void testGetBooleanWithClassKeyUsesSimpleClassNamePrefix() {
        final String key = "SystemPropertiesAgentTest.flag";
        setTempProperty(key, "true");
        assertTrue(SystemProperties.getBoolean(SystemPropertiesAgentTest.class, "flag", () -> false));
    }

    @Test
    void testGetIntUsesDefaultSupplierWhenAbsent() {
        assertEquals(42, SystemProperties.getInt(ABSENT_KEY, () -> 42));
    }

    @Test
    void testGetIntReturnsZeroWhenAbsentAndDefaultSupplierIsNull() {
        assertEquals(0, SystemProperties.getInt(ABSENT_KEY, null));
    }

    @Test
    void testGetIntParsesValidInteger() {
        setTempProperty(ABSENT_KEY, "123");
        assertEquals(123, SystemProperties.getInt(ABSENT_KEY, () -> 0));
    }

    @Test
    void testGetIntThrowsNumberFormatExceptionForInvalidValue() {
        setTempProperty(ABSENT_KEY, "notANumber");
        assertThrows(NumberFormatException.class, () -> SystemProperties.getInt(ABSENT_KEY, () -> 0));
    }

    @Test
    void testGetIntWithClassKeyUsesSimpleClassNamePrefix() {
        final String key = "SystemPropertiesAgentTest.intFlag";
        setTempProperty(key, "7");
        assertEquals(7, SystemProperties.getInt(SystemPropertiesAgentTest.class, "intFlag", () -> 0));
    }

    @Test
    void testGetLongUsesDefaultSupplierWhenAbsent() {
        assertEquals(42L, SystemProperties.getLong(ABSENT_KEY, () -> 42L));
    }

    @Test
    void testGetLongReturnsZeroWhenAbsentAndDefaultSupplierIsNull() {
        assertEquals(0L, SystemProperties.getLong(ABSENT_KEY, null));
    }

    @Test
    void testGetLongParsesValidLong() {
        setTempProperty(ABSENT_KEY, "123456789012");
        assertEquals(123456789012L, SystemProperties.getLong(ABSENT_KEY, () -> 0L));
    }

    @Test
    void testGetLongThrowsNumberFormatExceptionForInvalidValue() {
        setTempProperty(ABSENT_KEY, "notANumber");
        assertThrows(NumberFormatException.class, () -> SystemProperties.getLong(ABSENT_KEY, () -> 0L));
    }

    @Test
    void testGetLongWithClassKeyUsesSimpleClassNamePrefix() {
        final String key = "SystemPropertiesAgentTest.longFlag";
        setTempProperty(key, "9");
        assertEquals(9L, SystemProperties.getLong(SystemPropertiesAgentTest.class, "longFlag", () -> 0L));
    }

    @Test
    void testGetPathUsesDefaultSupplierWhenAbsent() {
        final Path defaultPath = Paths.get("default");
        assertEquals(defaultPath, SystemProperties.getPath(ABSENT_KEY, () -> defaultPath));
    }

    @Test
    void testGetPathReturnsNullWhenAbsentAndDefaultSupplierIsNull() {
        assertNull(SystemProperties.getPath(ABSENT_KEY, null));
    }

    @Test
    void testGetPathParsesValidPath() {
        setTempProperty(ABSENT_KEY, "foo/bar");
        assertEquals(Paths.get("foo/bar"), SystemProperties.getPath(ABSENT_KEY, () -> null));
    }

    @Test
    void testGetLineSeparatorWithDefaultSupplierReturnsActualValueWhenSet() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator(() -> "fallback"));
    }

    @Test
    void testGetLineSeparatorWithDefaultSupplierUsedWhenAbsent() {
        clearTempProperty("line.separator");
        assertEquals("fallback", SystemProperties.getLineSeparator(() -> "fallback"));
    }

    @Test
    void testGetUserNameWithDefaultReturnsActualValueWhenSet() {
        assertEquals(System.getProperty("user.name"), SystemProperties.getUserName("fallback"));
    }

    @Test
    void testGetUserNameWithDefaultUsedWhenAbsent() {
        clearTempProperty("user.name");
        assertEquals("fallback", SystemProperties.getUserName("fallback"));
    }

    @Test
    void testGetJavaSpecificationVersionWithDefaultReturnsActualValueWhenSet() {
        assertEquals(System.getProperty("java.specification.version"), SystemProperties.getJavaSpecificationVersion("fallback"));
    }

    @Test
    void testGetJavaSpecificationVersionWithDefaultUsedWhenAbsent() {
        clearTempProperty("java.specification.version");
        assertEquals("fallback", SystemProperties.getJavaSpecificationVersion("fallback"));
    }
}
