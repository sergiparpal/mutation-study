/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Strings}.
 */
class StringsAgentTest {

    // -------------------- isCaseSensitive --------------------

    @Test
    void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // -------------------- builder --------------------

    @Test
    void testBuilderDefaultsToCaseSensitive() {
        final Strings s = Strings.builder().get();
        assertTrue(s.isCaseSensitive());
    }

    @Test
    void testBuilderIgnoreCaseTrueProducesCaseInsensitive() {
        final Strings s = Strings.builder().setIgnoreCase(true).get();
        assertFalse(s.isCaseSensitive());
        assertTrue(s.equals("ABC", "abc"));
    }

    @Test
    void testBuilderIgnoreCaseFalseProducesCaseSensitive() {
        final Strings s = Strings.builder().setIgnoreCase(false).get();
        assertTrue(s.isCaseSensitive());
        assertFalse(s.equals("ABC", "abc"));
    }

    @Test
    void testBuilderNullIsLessDefaultFalse() {
        // default nullIsLess is false: null sorts as greater than non-null
        final Strings s = Strings.builder().get();
        assertTrue(s.compare(null, "a") > 0);
        assertTrue(s.compare("a", null) < 0);
    }

    @Test
    void testBuilderNullIsLessTrue() {
        final Strings s = Strings.builder().setNullIsLess(true).get();
        assertTrue(s.compare(null, "a") < 0);
        assertTrue(s.compare("a", null) > 0);
    }

    // -------------------- compare --------------------

    @Test
    void testCompareCsBasics() {
        assertEquals(0, Strings.CS.compare(null, null));
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "b") < 0);
        assertTrue(Strings.CS.compare("b", "a") > 0);
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    void testCompareCiBasics() {
        assertEquals(0, Strings.CI.compare(null, null));
        assertTrue(Strings.CI.compare(null, "a") < 0);
        assertTrue(Strings.CI.compare("a", null) > 0);
        assertEquals(0, Strings.CI.compare("abc", "abc"));
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "b") < 0);
        assertTrue(Strings.CI.compare("b", "a") > 0);
        assertTrue(Strings.CI.compare("a", "B") < 0);
        assertTrue(Strings.CI.compare("A", "b") < 0);
        assertTrue(Strings.CI.compare("ab", "ABC") < 0);
    }

    // -------------------- contains --------------------

    @Test
    void testContainsCs() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    @Test
    void testContainsCi() {
        assertFalse(Strings.CI.contains(null, "a"));
        assertFalse(Strings.CI.contains("a", null));
        assertTrue(Strings.CI.contains("", ""));
        assertTrue(Strings.CI.contains("abc", ""));
        assertTrue(Strings.CI.contains("abc", "a"));
        assertFalse(Strings.CI.contains("abc", "z"));
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
    }

    @Test
    void testContainsSearchLongerThanTarget() {
        assertFalse(Strings.CS.contains("ab", "abc"));
        assertFalse(Strings.CI.contains("ab", "ABC"));
    }

    // -------------------- containsAny --------------------

    @Test
    void testContainsAnyCs() {
        assertFalse(Strings.CS.containsAny(null, "a"));
        assertFalse(Strings.CS.containsAny(""));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc"));
        assertTrue(Strings.CS.containsAny("abcd", "ab", null));
        assertTrue(Strings.CS.containsAny("abcd", "ab", "cd"));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
        assertFalse(Strings.CS.containsAny("abc", "D", "ABC"));
    }

    @Test
    void testContainsAnyCi() {
        assertTrue(Strings.CI.containsAny("abc", "D", "ABC"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
        assertFalse(Strings.CI.containsAny("abc", "d", "z"));
    }

    // -------------------- endsWith / endsWithAny --------------------

    @Test
    void testEndsWithCs() {
        assertTrue(Strings.CS.endsWith(null, null));
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "cde"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    void testEndsWithCi() {
        assertTrue(Strings.CI.endsWith(null, null));
        assertFalse(Strings.CI.endsWith(null, "def"));
        assertFalse(Strings.CI.endsWith("abcdef", null));
        assertTrue(Strings.CI.endsWith("abcdef", "def"));
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    @Test
    void testEndsWithSuffixLongerThanTarget() {
        assertFalse(Strings.CS.endsWith("ab", "xab"));
    }

    @Test
    void testEndsWithAnyCs() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // -------------------- equals(CharSequence, CharSequence) --------------------

    @Test
    void testEqualsCharSequenceCs() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) null));
        assertTrue(Strings.CS.equals((CharSequence) "abc", (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    void testEqualsCharSequenceCi() {
        assertTrue(Strings.CI.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CI.equals((CharSequence) null, (CharSequence) "abc"));
        assertFalse(Strings.CI.equals((CharSequence) "abc", (CharSequence) null));
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "abc"));
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    void testEqualsCharSequenceNonStringCs() {
        // exercises the step-wise, non-String comparison branch
        final StringBuilder sb1 = new StringBuilder("abc");
        final StringBuilder sb2 = new StringBuilder("abc");
        assertTrue(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb2));
        final StringBuilder sb3 = new StringBuilder("abd");
        assertFalse(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb3));
    }

    @Test
    void testEqualsCharSequenceNonStringCi() {
        final StringBuilder sb1 = new StringBuilder("ABC");
        final StringBuilder sb2 = new StringBuilder("abc");
        assertTrue(Strings.CI.equals((CharSequence) sb1, (CharSequence) sb2));
    }

    @Test
    void testEqualsCharSequenceDifferentLengths() {
        assertFalse(Strings.CS.equals((CharSequence) "ab", (CharSequence) "abc"));
        assertFalse(Strings.CI.equals((CharSequence) "ab", (CharSequence) "abc"));
    }

    // -------------------- equals(String, String) --------------------

    @Test
    void testEqualsStringCs() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    void testEqualsStringCi() {
        assertTrue(Strings.CI.equals((String) null, (String) null));
        assertFalse(Strings.CI.equals((String) null, "abc"));
        assertFalse(Strings.CI.equals("abc", (String) null));
        assertTrue(Strings.CI.equals("abc", "abc"));
        assertTrue(Strings.CI.equals("abc", "ABC"));
    }

    // -------------------- equalsAny --------------------

    @Test
    void testEqualsAnyCs() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CS.equalsAny(null, null, null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    void testEqualsAnyCi() {
        assertFalse(Strings.CI.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CI.equalsAny(null, null, null));
        assertFalse(Strings.CI.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CI.equalsAny("abc", null, "def"));
        assertTrue(Strings.CI.equalsAny("abc", "abc", "def"));
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // -------------------- indexOf(seq, search) and indexOf(seq, search, startPos) --------------------

    @Test
    void testIndexOf2ArgCs() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(-1, Strings.CS.indexOf("", "a"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", ""));
    }

    @Test
    void testIndexOf3ArgCs() {
        assertEquals(-1, Strings.CS.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", null, 0));
        assertEquals(0, Strings.CS.indexOf("", "", 0));
        assertEquals(-1, Strings.CS.indexOf("", "a", 0));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a", 0));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", 0));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    void testIndexOf3ArgCi() {
        assertEquals(-1, Strings.CI.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CI.indexOf("a", null, 0));
        assertEquals(0, Strings.CI.indexOf("", "", 0));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
    }

    // -------------------- lastIndexOf(seq, search) and lastIndexOf(seq, search, startPos) --------------------

    @Test
    void testLastIndexOf2ArgCs() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    void testLastIndexOf2ArgCi() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CI.lastIndexOf("a", null));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B"));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB"));
    }

    @Test
    void testLastIndexOf3ArgCs() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a", 8));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null, 8));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    void testLastIndexOf3ArgCi() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a", 8));
        assertEquals(-1, Strings.CI.lastIndexOf("a", null, 8));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 8));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // -------------------- appendIfMissing --------------------

    @Test
    void testAppendIfMissingCs() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    void testAppendIfMissingCsWithMultipleSuffixes() {
        assertNull(Strings.CS.appendIfMissing(null, null, (CharSequence[]) null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null, (CharSequence[]) null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz", (CharSequence[]) null));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", new CharSequence[] {null}));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz", "mno"));
        assertEquals("abcMNOxyz", Strings.CS.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    @Test
    void testAppendIfMissingCi() {
        assertNull(Strings.CI.appendIfMissing(null, null));
        assertEquals("abc", Strings.CI.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CI.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CI.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
    }

    // -------------------- prependIfMissing --------------------

    @Test
    void testPrependIfMissingCs() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    void testPrependIfMissingCi() {
        assertNull(Strings.CI.prependIfMissing(null, null));
        assertEquals("abc", Strings.CI.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CI.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CI.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    void testPrependIfMissingCsWithMultiplePrefixes() {
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
        assertEquals("xyzMNOabc", Strings.CS.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    // -------------------- remove --------------------

    @Test
    void testRemoveCs() {
        assertNull(Strings.CS.remove(null, "a"));
        assertEquals("", Strings.CS.remove("", "a"));
        assertEquals("abc", Strings.CS.remove("abc", null));
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    void testRemoveCi() {
        assertNull(Strings.CI.remove(null, "a"));
        assertEquals("", Strings.CI.remove("", "a"));
        assertEquals("abc", Strings.CI.remove("abc", null));
        assertEquals("qd", Strings.CI.remove("queued", "ue"));
        assertEquals("queued", Strings.CI.remove("queued", "zz"));
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    // -------------------- removeEnd --------------------

    @Test
    void testRemoveEndCs() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    void testRemoveEndCi() {
        assertNull(Strings.CI.removeEnd(null, "x"));
        assertEquals("", Strings.CI.removeEnd("", "x"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // -------------------- removeStart --------------------

    @Test
    void testRemoveStartCs() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    void testRemoveStartCi() {
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
        assertEquals("domain.com", Strings.CI.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CI.removeStart("www.domain.com", "domain"));
    }

    // -------------------- replace(3-arg) --------------------

    @Test
    void testReplace3ArgCs() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    void testReplace3ArgCi() {
        assertNull(Strings.CI.replace(null, "a", "b"));
        assertEquals("", Strings.CI.replace("", "a", "b"));
        assertEquals("any", Strings.CI.replace("any", null, "b"));
        assertEquals("any", Strings.CI.replace("any", "a", null));
        assertEquals("any", Strings.CI.replace("any", "", "b"));
        assertEquals("aba", Strings.CI.replace("aba", "a", null));
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    // -------------------- replace(4-arg, max) --------------------

    @Test
    void testReplace4ArgCs() {
        assertNull(Strings.CS.replace(null, "a", "b", 1));
        assertEquals("", Strings.CS.replace("", "a", "b", 1));
        assertEquals("any", Strings.CS.replace("any", null, "b", 1));
        assertEquals("any", Strings.CS.replace("any", "a", null, 1));
        assertEquals("any", Strings.CS.replace("any", "", "b", 1));
        assertEquals("any", Strings.CS.replace("any", "a", "b", 0));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CS.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    void testReplace4ArgCi() {
        assertNull(Strings.CI.replace(null, "a", "b", 1));
        assertEquals("", Strings.CI.replace("", "a", "b", 1));
        assertEquals("any", Strings.CI.replace("any", null, "b", 1));
        assertEquals("any", Strings.CI.replace("any", "a", null, 1));
        assertEquals("any", Strings.CI.replace("any", "", "b", 1));
        assertEquals("any", Strings.CI.replace("any", "a", "b", 0));
        assertEquals("abaa", Strings.CI.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CI.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CI.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CI.replace("abaa", "A", "z", 1));
        assertEquals("zbza", Strings.CI.replace("abAa", "a", "z", 2));
        assertEquals("zbzz", Strings.CI.replace("abAa", "a", "z", -1));
    }

    @Test
    void testReplaceGrowsReplacementLongerThanSearch() {
        // replacement longer than search, many matches: verify correctness beyond the
        // internal capacity estimate (not just that no exception is thrown)
        final String text = "a-a-a-a-a-a-a-a-a-a";
        final String result = Strings.CS.replace(text, "a", "LONGREPLACEMENT", -1);
        assertEquals(10, countOccurrences(result, "LONGREPLACEMENT"));
        assertFalse(result.contains("a-"));
    }

    private static int countOccurrences(final String str, final String sub) {
        int count = 0;
        int idx = 0;
        while ((idx = str.indexOf(sub, idx)) != -1) {
            count++;
            idx += sub.length();
        }
        return count;
    }

    // -------------------- replaceOnce --------------------

    @Test
    void testReplaceOnceCs() {
        assertNull(Strings.CS.replaceOnce(null, "a", "b"));
        assertEquals("", Strings.CS.replaceOnce("", "a", "b"));
        assertEquals("any", Strings.CS.replaceOnce("any", null, "b"));
        assertEquals("any", Strings.CS.replaceOnce("any", "a", null));
        assertEquals("any", Strings.CS.replaceOnce("any", "", "b"));
        assertEquals("aba", Strings.CS.replaceOnce("aba", "a", null));
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    void testReplaceOnceCi() {
        assertEquals("ba", Strings.CI.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CI.replaceOnce("aba", "a", "z"));
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // -------------------- startsWith / startsWithAny --------------------

    @Test
    void testStartsWithCs() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    void testStartsWithCi() {
        assertTrue(Strings.CI.startsWith(null, null));
        assertFalse(Strings.CI.startsWith(null, "abc"));
        assertFalse(Strings.CI.startsWith("abcdef", null));
        assertTrue(Strings.CI.startsWith("abcdef", "abc"));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    @Test
    void testStartsWithPrefixLongerThanTarget() {
        assertFalse(Strings.CS.startsWith("ab", "abc"));
    }

    @Test
    void testStartsWithAnyCs() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertFalse(Strings.CS.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    @Test
    void testStartsWithAnyCi() {
        assertFalse(Strings.CI.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CI.startsWithAny(null, "aBc"));
        assertFalse(Strings.CI.startsWithAny("AbCxYz", (CharSequence[]) null));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", ""));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", "aBc"));
        assertTrue(Strings.CI.startsWithAny("AbCxYz", null, "XyZ", "aBc"));
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    // -------------------- initialCapacity (package-private helper) --------------------

    @Test
    void testInitialCapacityUnboundedUsesSixteenMultiplier() {
        // max < 0: estimated growth multiplier is 16
        final int capacity = Strings.initialCapacity(10, 1, 3, -1);
        assertEquals(10 + (3 - 1) * 16, capacity);
    }

    @Test
    void testInitialCapacityClampsMultiplierToSixtyFour() {
        // max > 64: multiplier is clamped to 64
        final int capacity = Strings.initialCapacity(10, 1, 3, 1000);
        assertEquals(10 + (3 - 1) * 64, capacity);
    }

    @Test
    void testInitialCapacityUsesMaxDirectlyWhenBelowSixtyFour() {
        final int capacity = Strings.initialCapacity(10, 1, 3, 5);
        assertEquals(10 + (3 - 1) * 5, capacity);
    }

    @Test
    void testInitialCapacityNeverNegativeWhenReplacementShorter() {
        // replacement shorter than search: no negative growth contribution
        final int capacity = Strings.initialCapacity(10, 5, 1, -1);
        assertEquals(10, capacity);
    }

    @Test
    void testInitialCapacityClampedToSafeMaxArrayLength() {
        final int capacity = Strings.initialCapacity(Integer.MAX_VALUE, 1, Integer.MAX_VALUE, -1);
        assertEquals(ArrayUtils.SAFE_MAX_ARRAY_LENGTH, capacity);
    }

}
