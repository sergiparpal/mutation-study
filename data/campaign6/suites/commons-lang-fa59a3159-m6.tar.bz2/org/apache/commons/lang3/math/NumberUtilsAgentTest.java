/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructorExists() {
        assertNotNull(new NumberUtils());
    }

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0f);
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testCompare() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 5, (byte) 6) < 0);
        assertTrue(NumberUtils.compare((byte) 6, (byte) 5) > 0);

        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(5, 6) < 0);
        assertTrue(NumberUtils.compare(6, 5) > 0);

        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(5L, 6L) < 0);
        assertTrue(NumberUtils.compare(6L, 5L) > 0);

        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 5, (short) 6) < 0);
        assertTrue(NumberUtils.compare((short) 6, (short) 5) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("   ");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
        assertEquals(new BigInteger("26"), NumberUtils.createBigInteger("0x1A"));
        assertEquals(new BigInteger("26"), NumberUtils.createBigInteger("#1A"));
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
        assertEquals(new BigInteger("-8"), NumberUtils.createBigInteger("-010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("abc");
            }
        });
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    @Test
    void testCreateNumber() throws Exception {
        assertNull(NumberUtils.createNumber(null));

        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("   ");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("not a number");
            }
        });

        // plain decimal, fits in Integer
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());

        // too big for int, fits in Long
        n = NumberUtils.createNumber("12345678901");
        assertTrue(n instanceof Long);
        assertEquals(12345678901L, n.longValue());

        // too big for long, BigInteger
        n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger("123456789012345678901234567890"), n);

        // explicit long type qualifier
        n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());

        // float type qualifier
        n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0f);

        // double type qualifier
        n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0d);

        // decimal with no qualifier, small enough for Float/Double
        n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float || n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0001d);

        // hex
        n = NumberUtils.createNumber("0x1A");
        assertTrue(n instanceof Integer);
        assertEquals(26, n.intValue());

        // large hex -> BigInteger
        n = NumberUtils.createNumber("0xFFFFFFFFFFFFFFFFFFFF");
        assertTrue(n instanceof BigInteger);

        // invalid trailing type char
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("123X");
            }
        });

        // bad long qualifier value
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
        assertFalse(NumberUtils.isCreatable("not a number"));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("123.45"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("-123"));
        assertFalse(NumberUtils.isCreatable("09")); // invalid octal
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    @Test
    void testIsNumberDeprecated() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber(null));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("-1.5e10"));
        assertFalse(NumberUtils.isParsable("1.5L"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMax3Params() {
        assertEquals((byte) 7, NumberUtils.max((byte) 3, (byte) 7, (byte) 1));
        assertEquals(7, NumberUtils.max(3, 7, 1));
        assertEquals(7L, NumberUtils.max(3L, 7L, 1L));
        assertEquals((short) 7, NumberUtils.max((short) 3, (short) 7, (short) 1));
        assertEquals(7.0d, NumberUtils.max(3.0d, 7.0d, 1.0d), 0d);
        assertEquals(7.0f, NumberUtils.max(3.0f, 7.0f, 1.0f), 0f);
    }

    @Test
    void testMaxDoubleArrayWithNaN() {
        final double[] a = { 1.0, Double.NaN, 3.0 };
        assertTrue(Double.isNaN(NumberUtils.max(a)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    void testMaxFloatArrayWithNaN() {
        final float[] a = { 1.0f, Float.NaN, 3.0f };
        assertTrue(Float.isNaN(NumberUtils.max(a)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(new int[] { 1, 9, 4 }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(new long[] { 1L, 9L, 4L }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max(new short[] { 1, 9, 4 }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 1, (byte) 5));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMin3Params() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 7, (byte) 1));
        assertEquals(1, NumberUtils.min(3, 7, 1));
        assertEquals(1L, NumberUtils.min(3L, 7L, 1L));
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 7, (short) 1));
        assertEquals(1.0d, NumberUtils.min(3.0d, 7.0d, 1.0d), 0d);
        assertEquals(1.0f, NumberUtils.min(3.0f, 7.0f, 1.0f), 0f);
    }

    @Test
    void testMinDoubleArrayWithNaN() {
        final double[] a = { 1.0, Double.NaN, 3.0 };
        assertTrue(Double.isNaN(NumberUtils.min(a)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    void testMinFloatArrayWithNaN() {
        final float[] a = { 1.0f, Float.NaN, 3.0f };
        assertTrue(Float.isNaN(NumberUtils.min(a)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(new int[] { 5, 1, 9 }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(new long[] { 5L, 1L, 9L }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min(new short[] { 5, 1, 9 }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0d);
        assertEquals(9.9d, NumberUtils.toDouble("not a number", 9.9d), 0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0f);
        assertEquals(9.9f, NumberUtils.toFloat("not a number", 9.9f), 0f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.25"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.25")));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
        // null rounding mode defaults to HALF_EVEN
        assertEquals(new BigDecimal("2.5"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 1, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d), 2, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_DOWN));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.23f)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal("1.23"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP));
    }
}
