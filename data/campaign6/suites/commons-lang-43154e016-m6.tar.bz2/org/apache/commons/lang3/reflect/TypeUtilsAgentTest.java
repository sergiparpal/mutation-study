/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    private interface AgentFixtureIterable<T> {
    }

    private interface AgentFixtureCollection<T> extends AgentFixtureIterable<T> {
    }

    @SuppressWarnings("serial")
    private static class AgentFixtureStringList extends ArrayList<String> implements AgentFixtureCollection<String> {
    }

    private static class AgentFixtureHolder<T> {
        public T field;
        public List<T> listField;
    }

    private static class AgentFixtureStringHolder extends AgentFixtureHolder<String> {
    }

    private static class AgentFixtureBoundedHolder<T extends Number & Comparable<T>> {
    }

    private static class AgentFixtureCyclic<T extends AgentFixtureCyclic<T>> {
    }

    private static class AgentFixtureOuter<K> {
        static class AgentFixtureInner<V> {
        }
    }

    private static class AgentFixtureFields {
        public List<String> stringList;
        public List<? extends Number> upperWildcardList;
        public List<? super Integer> lowerWildcardList;
        public List<String>[] listArray;
    }

    static <T> T agentGenericMethod(final T t) {
        return t;
    }

    /**
     * A {@link Type} implementation that is deliberately none of the known subtypes, to exercise the
     * "unhandled type" branches of {@link TypeUtils}.
     */
    private static final class AgentUnknownType implements Type {
    }

    private static Field field(final String name) throws NoSuchFieldException {
        return AgentFixtureFields.class.getField(name);
    }

    @Test
    void testContainsTypeVariables() {
        final TypeVariable<?> t = AgentFixtureHolder.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(t));
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertTrue(TypeUtils.containsTypeVariables(AgentFixtureHolder.class));
        final ParameterizedType withVar = TypeUtils.parameterize(AgentFixtureHolder.class, t);
        assertTrue(TypeUtils.containsTypeVariables(withVar));
        final ParameterizedType withoutVar = TypeUtils.parameterize(AgentFixtureHolder.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(withoutVar));
        assertTrue(TypeUtils.containsTypeVariables(TypeUtils.genericArrayType(t)));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.genericArrayType(String.class)));
        final WildcardType wildcardWithVar = TypeUtils.wildcardType().withUpperBounds(t).build();
        assertTrue(TypeUtils.containsTypeVariables(wildcardWithVar));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testDetermineTypeArguments() {
        final ParameterizedType targetType = TypeUtils.parameterize(AgentFixtureIterable.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(AgentFixtureStringList.class, targetType);
        assertNotNull(result);
        final TypeVariable<?> iterableVar = AgentFixtureIterable.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(iterableVar));

        assertNull(TypeUtils.determineTypeArguments(String.class, TypeUtils.parameterize(List.class, String.class)));

        try {
            TypeUtils.determineTypeArguments(null, targetType);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            TypeUtils.determineTypeArguments(AgentFixtureStringList.class, null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testEquals() {
        assertTrue(TypeUtils.equals(null, null));
        assertFalse(TypeUtils.equals(String.class, null));
        assertFalse(TypeUtils.equals(null, String.class));
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));

        final ParameterizedType p1 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType p2 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType p3 = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.equals(p1, p2));
        assertFalse(TypeUtils.equals(p1, p3));
        assertFalse(TypeUtils.equals(p1, String.class));

        final GenericArrayType a1 = TypeUtils.genericArrayType(String.class);
        final GenericArrayType a2 = TypeUtils.genericArrayType(String.class);
        final GenericArrayType a3 = TypeUtils.genericArrayType(Integer.class);
        assertTrue(TypeUtils.equals(a1, a2));
        assertFalse(TypeUtils.equals(a1, a3));

        final WildcardType w1 = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType w2 = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType w3 = TypeUtils.wildcardType().withUpperBounds(Integer.class).build();
        assertTrue(TypeUtils.equals(w1, w2));
        assertFalse(TypeUtils.equals(w1, w3));
    }

    @Test
    void testGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, arrayType.getGenericComponentType());
        assertEquals("java.lang.String[]", arrayType.toString());
        try {
            TypeUtils.genericArrayType(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testGetArrayComponentType() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertEquals(int[].class, TypeUtils.getArrayComponentType(int[][].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(arrayType));
        assertNull(TypeUtils.getArrayComponentType(TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testGetImplicitBounds() {
        final TypeVariable<?> unbounded = AgentFixtureHolder.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(unbounded);
        assertEquals(1, bounds.length);
        assertEquals(Object.class, bounds[0]);

        final TypeVariable<?> bounded = AgentFixtureBoundedHolder.class.getTypeParameters()[0];
        final Type[] boundedBounds = TypeUtils.getImplicitBounds(bounded);
        assertEquals(2, boundedBounds.length);
        boolean foundNumber = false;
        for (final Type t : boundedBounds) {
            if (Number.class.equals(t)) {
                foundNumber = true;
            }
        }
        assertTrue(foundNumber);

        try {
            TypeUtils.getImplicitBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testGetImplicitLowerBounds() {
        final Type[] none = TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, none.length);
        assertNull(none[0]);

        final WildcardType withLower = TypeUtils.wildcardType().withLowerBounds(Integer.class).build();
        final Type[] lower = TypeUtils.getImplicitLowerBounds(withLower);
        assertEquals(1, lower.length);
        assertEquals(Integer.class, lower[0]);

        try {
            TypeUtils.getImplicitLowerBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testGetImplicitUpperBounds() {
        final Type[] defaultUpper = TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, defaultUpper.length);
        assertEquals(Object.class, defaultUpper[0]);

        final WildcardType withUpper = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final Type[] upper = TypeUtils.getImplicitUpperBounds(withUpper);
        assertEquals(1, upper.length);
        assertEquals(Number.class, upper[0]);

        try {
            TypeUtils.getImplicitUpperBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testGetRawTypeClass() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    void testGetRawTypeParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(pt, null));
    }

    @Test
    void testGetRawTypeTypeVariable() {
        final TypeVariable<?> t = AgentFixtureHolder.class.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(t, null));
        final ParameterizedType assigning = TypeUtils.parameterize(AgentFixtureHolder.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(t, assigning));

        final Method method = getAgentGenericMethod();
        final TypeVariable<?> methodVar = method.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(methodVar, assigning));
    }

    @Test
    void testGetRawTypeGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String[].class, TypeUtils.getRawType(arrayType, null));

        final TypeVariable<?> methodVar = getAgentGenericMethod().getTypeParameters()[0];
        final GenericArrayType unresolved = TypeUtils.genericArrayType(methodVar);
        assertNull(TypeUtils.getRawType(unresolved, null));
    }

    @Test
    void testGetRawTypeWildcardType() {
        assertNull(TypeUtils.getRawType(TypeUtils.WILDCARD_ALL, null));
    }

    @Test
    void testGetRawTypeUnknownType() {
        try {
            TypeUtils.getRawType(new AgentUnknownType(), null);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    private static Method getAgentGenericMethod() {
        try {
            return TypeUtilsAgentTest.class.getDeclaredMethod("agentGenericMethod", Object.class);
        } catch (final NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    @Test
    void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(pt);
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(listVar));
    }

    @Test
    void testGetTypeArgumentsTypeClass() {
        final Map<TypeVariable<?>, Type> fromClass = TypeUtils.getTypeArguments(AgentFixtureStringList.class, AgentFixtureCollection.class);
        final TypeVariable<?> collectionVar = AgentFixtureCollection.class.getTypeParameters()[0];
        assertEquals(String.class, fromClass.get(collectionVar));

        assertNull(TypeUtils.getTypeArguments(String.class, List.class));

        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        final Map<TypeVariable<?>, Type> fromArray = TypeUtils.getTypeArguments(arrayType, Object[].class);
        assertNotNull(fromArray);
        assertTrue(fromArray.isEmpty());

        final WildcardType matchingWildcard = TypeUtils.wildcardType().withUpperBounds(Integer.class).build();
        assertNotNull(TypeUtils.getTypeArguments(matchingWildcard, Number.class));
        final WildcardType nonMatchingWildcard = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertNull(TypeUtils.getTypeArguments(nonMatchingWildcard, Number.class));

        final TypeVariable<?> boundedVar = AgentFixtureBoundedHolder.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> fromVar = TypeUtils.getTypeArguments(boundedVar, Number.class);
        assertNotNull(fromVar);
    }

    @Test
    void testGetTypeArgumentsUnknownType() {
        try {
            TypeUtils.getTypeArguments(new AgentUnknownType(), Object.class);
            fail("expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testIsAssignableBasics() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(null, Object.class));
        assertFalse(TypeUtils.isAssignable(null, int.class));
        assertFalse(TypeUtils.isAssignable(String.class, (Type) null));
        assertTrue(TypeUtils.isAssignable((Type) null, (Type) null));
    }

    @Test
    void testIsAssignableGenerics() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(ArrayList.class, String.class), listOfString));
        assertFalse(TypeUtils.isAssignable(TypeUtils.parameterize(ArrayList.class, String.class), listOfInteger));
        // a raw List is assignable to a parameterized List
        assertTrue(TypeUtils.isAssignable(List.class, listOfString));
    }

    @Test
    void testIsAssignableArrays() {
        assertTrue(TypeUtils.isAssignable(String[].class, Object[].class));
        assertFalse(TypeUtils.isAssignable(Object[].class, String[].class));
        final GenericArrayType arrayOfString = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.isAssignable(String[].class, arrayOfString));
    }

    @Test
    void testIsAssignableWildcardsAndVariables() {
        final WildcardType upperNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.isAssignable(Integer.class, upperNumber));
        assertFalse(TypeUtils.isAssignable(String.class, upperNumber));
        final TypeVariable<?> boundedVar = AgentFixtureBoundedHolder.class.getTypeParameters()[0];
        assertTrue(TypeUtils.isAssignable(boundedVar, Number.class));
    }

    @Test
    void testIsAssignableUnknownType() {
        try {
            TypeUtils.isAssignable(String.class, new AgentUnknownType());
            fail("expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertFalse(TypeUtils.isInstance(5, String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("hello", null));
        assertTrue(TypeUtils.isInstance(new ArrayList<String>(), TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testNormalizeUpperBounds() {
        final Type[] single = {Number.class};
        assertSame(single, TypeUtils.normalizeUpperBounds(single));

        final Type[] redundant = {Number.class, Integer.class};
        final Type[] normalized = TypeUtils.normalizeUpperBounds(redundant);
        assertEquals(1, normalized.length);
        assertEquals(Integer.class, normalized[0]);

        try {
            TypeUtils.normalizeUpperBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeWithMap() {
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(AgentFixtureHolder.class.getTypeParameters()[0], String.class);
        final ParameterizedType pt = TypeUtils.parameterize(AgentFixtureHolder.class, map);
        assertEquals(AgentFixtureHolder.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);

        try {
            TypeUtils.parameterize(AgentFixtureHolder.class, new HashMap<TypeVariable<?>, Type>());
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        try {
            TypeUtils.parameterize(null, map);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeWithTypeArguments() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertNull(pt.getOwnerType());
        assertEquals(String.class, pt.getActualTypeArguments()[0]);

        try {
            TypeUtils.parameterize(List.class, String.class, Integer.class);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        try {
            TypeUtils.parameterize(List.class, (Type) null);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeWithOwner() {
        final ParameterizedType owner = TypeUtils.parameterize(AgentFixtureOuter.class, String.class);
        final ParameterizedType inner = TypeUtils.parameterizeWithOwner(owner, AgentFixtureOuter.AgentFixtureInner.class, Integer.class);
        assertEquals(AgentFixtureOuter.AgentFixtureInner.class, inner.getRawType());
        assertEquals(owner, inner.getOwnerType());
        assertEquals(Integer.class, inner.getActualTypeArguments()[0]);

        // top-level class must not have an owner
        try {
            TypeUtils.parameterizeWithOwner(owner, List.class, String.class);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        // owner must be assignable to the enclosing class
        try {
            TypeUtils.parameterizeWithOwner(TypeUtils.parameterize(List.class, String.class), AgentFixtureOuter.AgentFixtureInner.class, Integer.class);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testToLongString() {
        final TypeVariable<?> classVar = AgentFixtureHolder.class.getTypeParameters()[0];
        final String expected = TypeUtilsAgentTest.class.getName() + "." + AgentFixtureHolder.class.getSimpleName() + ":T";
        assertEquals(expected, TypeUtils.toLongString(classVar));

        final TypeVariable<?> methodVar = getAgentGenericMethod().getTypeParameters()[0];
        final String methodLongString = TypeUtils.toLongString(methodVar);
        assertTrue(methodLongString.endsWith(":T"));
        assertTrue(methodLongString.contains("agentGenericMethod"));

        try {
            TypeUtils.toLongString(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expectedException) {
            // expected
        }
    }

    @Test
    void testToStringClassAndCycle() {
        assertEquals(String.class.getName(), TypeUtils.toString(String.class));
        assertEquals("int[]", TypeUtils.toString(int[].class));
        assertEquals("AgentFixtureCyclic(cycle)", TypeUtils.toString(AgentFixtureCyclic.class));

        try {
            TypeUtils.toString(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testToStringParameterizedAndArray() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(pt));

        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals("java.lang.String[]", TypeUtils.toString(arrayType));
    }

    @Test
    void testToStringWildcard() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
        final WildcardType extendsNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals("? extends java.lang.Number", TypeUtils.toString(extendsNumber));
        final WildcardType superInteger = TypeUtils.wildcardType().withLowerBounds(Integer.class).build();
        assertEquals("? super java.lang.Integer", TypeUtils.toString(superInteger));
    }

    @Test
    void testTypesSatisfyVariables() {
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(AgentFixtureHolder.class.getTypeParameters()[0], String.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));

        final Map<TypeVariable<?>, Type> badMap = new HashMap<TypeVariable<?>, Type>();
        badMap.put(AgentFixtureBoundedHolder.class.getTypeParameters()[0], String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(badMap));

        final Map<TypeVariable<?>, Type> goodBoundedMap = new HashMap<TypeVariable<?>, Type>();
        goodBoundedMap.put(AgentFixtureBoundedHolder.class.getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(goodBoundedMap));

        try {
            TypeUtils.typesSatisfyVariables(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testUnrollVariables() throws NoSuchFieldException {
        final TypeVariable<?> t = AgentFixtureHolder.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(t, String.class);

        assertEquals(String.class, TypeUtils.unrollVariables(map, t));
        assertNull(TypeUtils.unrollVariables(new HashMap<TypeVariable<?>, Type>(), t));

        final Type listOfT = AgentFixtureHolder.class.getDeclaredField("listField").getGenericType();
        final Type unrolledList = TypeUtils.unrollVariables(map, listOfT);
        assertEquals(TypeUtils.parameterize(List.class, String.class), unrolledList);

        final WildcardType wildcardOfT = TypeUtils.wildcardType().withUpperBounds(t).build();
        final Type unrolledWildcard = TypeUtils.unrollVariables(map, wildcardOfT);
        assertEquals(TypeUtils.wildcardType().withUpperBounds(String.class).build(), unrolledWildcard);

        assertEquals(String.class, TypeUtils.unrollVariables(null, String.class));
    }

    @Test
    void testWildcardTypeBuilder() {
        final WildcardType defaultBuilt = TypeUtils.wildcardType().build();
        assertEquals(1, defaultBuilt.getUpperBounds().length);
        assertEquals(Object.class, defaultBuilt.getUpperBounds()[0]);
        assertEquals(0, defaultBuilt.getLowerBounds().length);

        final WildcardType withBounds = TypeUtils.wildcardType().withUpperBounds(Number.class).withLowerBounds(Integer.class).build();
        assertEquals(Number.class, withBounds.getUpperBounds()[0]);
        assertEquals(Integer.class, withBounds.getLowerBounds()[0]);
    }

    @Test
    void testWildcardAllConstant() {
        assertEquals(Object.class, TypeUtils.WILDCARD_ALL.getUpperBounds()[0]);
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);
    }

    @Test
    void testWrapClass() {
        final Typed<String> typed = TypeUtils.wrap(String.class);
        assertEquals(String.class, typed.getType());
    }

    @Test
    void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> typed = TypeUtils.wrap((Type) pt);
        assertSame(pt, typed.getType());
    }

    @Test
    void testFieldReflectionFixturesUsable() throws NoSuchFieldException {
        // Sanity-check the test fixtures compile and expose the expected generic shapes.
        assertTrue(field("stringList").getGenericType() instanceof ParameterizedType);
        assertTrue(field("upperWildcardList").getGenericType() instanceof ParameterizedType);
        final ParameterizedType upperWildcardListType = (ParameterizedType) field("upperWildcardList").getGenericType();
        assertTrue(upperWildcardListType.getActualTypeArguments()[0] instanceof WildcardType);
        assertTrue(field("listArray").getGenericType() instanceof GenericArrayType);
        assertNotNull(AgentFixtureStringHolder.class.getGenericSuperclass());
    }
}
