/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testSimpleTokensSeparatedByDefaultDelimiter() throws IOException {
        final Lexer lexer = createLexer("a,b,c\n", CSVFormat.DEFAULT);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("b", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("c", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEmptyInputYieldsEofWithoutReadyFlag() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertFalse(token.isReady);
            assertEquals(0, token.content.length());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testFinalTokenWithoutTrailingNewlineIsReadyAtEof() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrailingDelimiterAtEofYieldsReadyEofWithEmptyContent() throws IOException {
        final Lexer lexer = createLexer("a,", CSVFormat.DEFAULT);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            // CSVParser treats a ready EOF token with empty content as the final, empty field of the record.
            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEmptyLineIsIgnoredWhenIgnoreEmptyLinesIsEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("a\n\nb\n", format);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("b", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEmptyLineIsRecordWhenIgnoreEmptyLinesIsDisabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer("a\n\nb\n", format);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testQuotedTokenWithEmbeddedDelimiterAndNewline() throws IOException {
        final Lexer lexer = createLexer("\"a,b\nc\",d\n", CSVFormat.DEFAULT);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a,b\nc", token.content.toString());
            assertTrue(token.isQuoted);

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("d", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testQuotedTokenWithDoubledQuoteBecomesSingleQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"\"b\"\n", CSVFormat.DEFAULT);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a\"b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testUnterminatedQuotedTokenThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("\"unterminated", CSVFormat.DEFAULT);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(new Token());
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testUnterminatedQuotedTokenIsLenientWhenLenientEofIsEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"unterminated", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("unterminated", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testInvalidCharacterAfterEncapsulatedTokenThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("\"a\"b,c\n", CSVFormat.DEFAULT);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(new Token());
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrailingDataAfterEncapsulatedTokenIsAppendedWhenEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"a\"bc,d\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("abc", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCommentLineIsRecognizedAndTrimmed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("# a comment \na,b\n", format);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.COMMENT, token.type);
            assertEquals("a comment", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEscapedCharactersAreUnescapedInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote((Character) null).get();
        final Lexer lexer = createLexer("a\\,b,c\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            // Escaped delimiter must be treated as literal content, not a field separator.
            assertEquals("a,b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEscapeAtEndOfStreamThrowsCsvException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote((Character) null).get();
        final Lexer lexer = createLexer("a\\", format);
        try {
            // Per Lexer#readEscape javadoc, the escape character is not allowed at end of stream.
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(new Token());
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsLeadingAndTrailingWhitespace() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer("  a  , b \n", format);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterWithMultiCharacterDelimiterConsumesAllCharacters() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a::b\n", format);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterFalseWhenOnlyPartialMultiCharacterDelimiterPresent() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a:b\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            // ":" alone is not the full "::" delimiter, so it belongs to the token content.
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a:b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.isEndOfFile(EOF));
            assertFalse(lexer.isEndOfFile('a'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.isStartOfLine(Constants.LF));
            assertTrue(lexer.isStartOfLine(Constants.CR));
            assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
            assertFalse(lexer.isStartOfLine('a'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsQuoteCharAndIsCommentStartReflectConfiguredFormat() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("", format);
        try {
            assertTrue(lexer.isQuoteChar('"'));
            assertFalse(lexer.isQuoteChar('#'));
            assertTrue(lexer.isCommentStart('#'));
            assertFalse(lexer.isCommentStart('"'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsEscapeDisabledByDefault() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            assertFalse(lexer.isEscape('\\'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testFirstEolIsNullBeforeAnyLineEndingIsRead() throws IOException {
        final Lexer lexer = createLexer("a,b\n", CSVFormat.DEFAULT);
        try {
            assertEquals(null, lexer.getFirstEol());
            lexer.nextToken(new Token());
            lexer.nextToken(new Token());
            assertEquals("\n", lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCrLfRecognizedAsSingleEndOfRecord() throws IOException {
        final Lexer lexer = createLexer("a\r\nb\r\n", CSVFormat.DEFAULT);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("a", token.content.toString());
            assertEquals(Constants.CRLF, lexer.getFirstEol());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testGetCurrentLineNumberAdvancesPerRecord() throws IOException {
        final Lexer lexer = createLexer("a\nb\nc", CSVFormat.DEFAULT);
        try {
            assertEquals(0, lexer.getCurrentLineNumber());
            lexer.nextToken(new Token());
            assertEquals(1, lexer.getCurrentLineNumber());
            lexer.nextToken(new Token());
            assertEquals(2, lexer.getCurrentLineNumber());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCloseClosesUnderlyingReader() throws IOException {
        final Lexer lexer = createLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testReadEscapeTranslatesStandardEscapeSequences() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("n", format);
        try {
            assertEquals(Constants.LF, lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeAtEndOfStreamThrowsCsvException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("", format);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.readEscape();
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeReturnsEofForUnrecognizedCharacter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("z", format);
        try {
            assertEquals(EOF, lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrimTrailingSpacesRemovesOnlyTrailingWhitespace() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            final StringBuilder sb = new StringBuilder("  a b  ");
            lexer.trimTrailingSpaces(sb);
            assertEquals("  a b", sb.toString());
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testTrimTrailingSpacesOnAllWhitespaceEmptiesBuffer() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            final StringBuilder sb = new StringBuilder("    ");
            lexer.trimTrailingSpaces(sb);
            assertEquals(0, sb.length());
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testGetBytesReadIsZeroWhenByteTrackingDisabled() throws IOException {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        try {
            lexer.nextToken(new Token());
            assertEquals(0, lexer.getBytesRead());
        } finally {
            lexer.close();
        }
    }

    private static void closeQuietly(final Lexer lexer) {
        try {
            lexer.close();
        } catch (final IOException e) {
            // ignore for tests that do not exercise stream state
        }
    }
}
