/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    /** Minimal Appendable that is none of the special-cased types in appendTo(). */
    static final class PlainAppendable implements Appendable {
        final StringBuilder sb = new StringBuilder();

        @Override
        public Appendable append(final CharSequence csq) {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public Appendable append(final char c) {
            sb.append(c);
            return this;
        }
    }

    /** Minimal Readable that is not a Reader nor a CharBuffer. */
    static final class PlainReadable implements Readable {
        private final CharBuffer source;

        PlainReadable(final String s) {
            source = CharBuffer.wrap(s.toCharArray());
        }

        @Override
        public int read(final CharBuffer cb) {
            if (!source.hasRemaining()) {
                return -1;
            }
            final int n = Math.min(cb.remaining(), source.remaining());
            for (int i = 0; i < n; i++) {
                cb.put(source.get());
            }
            return n;
        }
    }

    // ---- constructors ----

    @Test
    public void testDefaultConstructorCapacity() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
    }

    @Test
    public void testCapacityConstructorNonPositiveDefaultsTo32() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
        assertEquals(50, new StrBuilder(50).capacity());
    }

    @Test
    public void testStringConstructorNullIsBlank() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testStringConstructorCopiesContent() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    // ---- append variants ----

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(' ').append(false);
        assertEquals("true false", sb.toString());
    }

    @Test
    public void testAppendPrimitives() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1).append(',').append(2L).append(',').append(3.5f).append(',').append(4.5d);
        assertEquals("1,2,3.5,4.5", sb.toString());
    }

    @Test
    public void testAppendCharArrayNullCallsAppendNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((char[]) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStartIndexThrows() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, 3, 1));
    }

    @Test
    public void testAppendCharArrayRangeInvalidLengthThrows() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a', 'b'}, 1, 2));
    }

    @Test
    public void testAppendStringRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 4, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 1, 3));
    }

    @Test
    public void testAppendStringRangeValid() {
        final StrBuilder sb = new StrBuilder();
        sb.append("hello world", 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendObjectNullUsesNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
        sb.setNullText("N");
        sb.append((Object) null);
        assertEquals("N", sb.toString());
    }

    @Test
    public void testAppendCharSequenceDispatch() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) new StringBuilder("sb"));
        sb.append((CharSequence) new StringBuffer("buf"));
        sb.append((CharSequence) CharBuffer.wrap("cb".toCharArray()));
        sb.append((CharSequence) new StrBuilder("strb"));
        assertEquals("sbbufcbstrb", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abcdef", 2, 3);
        assertEquals("cde", sb.toString());
    }

    @Test
    public void testAppendCharBuffer() {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("hello".toCharArray());
        sb.append(cb);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("hello world".toCharArray());
        sb.append(cb, 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendStringBuilderAndBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("sbuild"));
        sb.append(new StringBuffer("sbuf"));
        assertEquals("sbuildsbuf", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRange() {
        final StrBuilder source = new StrBuilder("0123456789");
        final StrBuilder sb = new StrBuilder();
        sb.append(source, 3, 4);
        assertEquals("3456", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(source, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(source, 0, 100));
    }

    @Test
    public void testAppendFormat() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 5);
        assertEquals("x-5", sb.toString());
    }

    @Test
    public void testAppendAllIterableIteratorArray() {
        final List<String> list = Arrays.asList("a", "b", "c");
        final StrBuilder sb1 = new StrBuilder();
        sb1.appendAll((Iterable<?>) list);
        assertEquals("abc", sb1.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendAll(list.iterator());
        assertEquals("abc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendAll("x", "y", "z");
        assertEquals("xyz", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendAll((Iterable<?>) null);
        sb4.appendAll((java.util.Iterator<?>) null);
        assertEquals("", sb4.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncatesFromLeft() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("123456", 3, '0');
        assertEquals("456", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftPads() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(42, 5, '0');
        assertEquals("00042", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftNonPositiveWidthNoEffect() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendFixedWidthPadLeft("abc", 0, '0');
        sb.appendFixedWidthPadLeft("abc", -1, '0');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftNullObjectUsesEmptyWhenNoNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft((Object) null, 4, '*');
        assertEquals("****", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncatesFromRight() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("123456", 3, '0');
        assertEquals("123", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightPads() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(42, 5, '0');
        assertEquals("42000", sb.toString());
    }

    @Test
    public void testAppendPaddingNegativeNoEffect() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendPadding(-3, '*');
        assertEquals("x", sb.toString());
        sb.appendPadding(0, '*');
        assertEquals("x", sb.toString());
        sb.appendPadding(3, '*');
        assertEquals("x***", sb.toString());
    }

    @Test
    public void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        sb.append("a");
        sb.appendSeparator(',');
        sb.append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharDefaultIfEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.appendSeparator(',', ';');
        assertEquals(";,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNullHasNoEffect() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        sb.append("x=1");
        assertEquals(" wherex=1", sb.toString());
        sb.appendSeparator(" and", " where");
        assertEquals(" wherex=1 and", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, "-");
        assertEquals("a-b-c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsNullSeparatorUsesEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendlnAddsNewLine() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln("x");
        assertEquals("x\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultsToSystemLineSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testSetNewLineTextNullRestoresSystemDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        assertEquals("\n", sb.getNewLineText());
        sb.setNewLineText(null);
        assertEquals(null, sb.getNewLineText());
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    // ---- charAt / setCharAt / deleteCharAt ----

    @Test
    public void testCharAtBounds() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(3));
    }

    @Test
    public void testSetCharAtBounds() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'z'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(3, 'z'));
    }

    @Test
    public void testDeleteCharAtBounds() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(2));
    }

    // ---- delete / deleteAll / deleteFirst ----

    @Test
    public void testDeleteRangeClampsLargeEndIndex() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(2, 1000);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testDeleteRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(4, 2));
    }

    @Test
    public void testDeleteAllCharRemovesEveryOccurrenceIncludingConsecutive() {
        final StrBuilder sb = new StrBuilder("aabcaadcaa");
        sb.deleteAll('a');
        assertEquals("bcdc", sb.toString());
    }

    @Test
    public void testDeleteFirstCharOnlyRemovesFirstOccurrence() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.deleteFirst('a');
        assertEquals("bnana", sb.toString());
    }

    @Test
    public void testDeleteAllStringAndNullNoAction() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteAll((String) null);
        assertEquals("ababab", sb.toString());
        sb.deleteAll("ab");
        assertEquals("", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteFirst("ab");
        assertEquals("abab", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    // ---- contains / startsWith / endsWith ----

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.contains('e'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains("wor"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.contains(StrMatcher.charMatcher('l')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testStartsWithEndsWith() {
        final StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.startsWith("he"));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith(null));
        assertFalse(sb.startsWith("hello world"));
        assertTrue(sb.endsWith("lo"));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith(null));
        assertFalse(sb.endsWith("hello world"));
    }

    // ---- equals / equalsIgnoreCase / hashCode ----

    @Test
    public void testEqualsObjectWithNonStrBuilderIsFalse() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.equals("abc"));
        assertFalse(sb.equals(null));
    }

    @Test
    public void testEqualsStrBuilderSameContent() {
        final StrBuilder a = new StrBuilder("abc");
        final StrBuilder b = new StrBuilder("abc");
        assertTrue(a.equals(b));
        assertTrue(a.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsStrBuilderNullIsFalse() {
        final StrBuilder a = new StrBuilder("abc");
        assertFalse(a.equals((StrBuilder) null));
    }

    @Test
    public void testEqualsStrBuilderDifferentContent() {
        final StrBuilder a = new StrBuilder("abc");
        final StrBuilder b = new StrBuilder("abd");
        assertFalse(a.equals(b));
        final StrBuilder c = new StrBuilder("ab");
        assertFalse(a.equals(c));
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder a = new StrBuilder("ABC");
        final StrBuilder b = new StrBuilder("abc");
        assertTrue(a.equalsIgnoreCase(b));
        assertTrue(a.equalsIgnoreCase(a));
        assertFalse(a.equalsIgnoreCase(new StrBuilder("abd")));
    }

    @Test
    public void testEqualsIgnoreCaseNullIsDocumentedAsFalse() {
        final StrBuilder a = new StrBuilder("abc");
        // Javadoc: "other - the object to check, null returns false."
        assertFalse(a.equalsIgnoreCase(null));
    }

    // ---- indexOf / lastIndexOf ----

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharNegativeStartRoundsToZero() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(0, sb.indexOf('a', -5));
    }

    @Test
    public void testIndexOfCharStartBeyondSize() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf('a', 10));
    }

    @Test
    public void testIndexOfStringNullReturnsNegativeOne() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf("abc"));
        assertEquals(3, sb.indexOf("abc", 1));
        assertEquals(-1, sb.indexOf("xyz"));
    }

    @Test
    public void testIndexOfMatcherNullReturnsNegativeOne() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf('a'));
        assertEquals(0, sb.lastIndexOf('a', 2));
        assertEquals(-1, sb.lastIndexOf('a', -1));
    }

    @Test
    public void testLastIndexOfCharStartBeyondSizeClamps() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(2, sb.lastIndexOf('c', 100));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2");
        assertEquals(3, sb.lastIndexOf(StrMatcher.charSetMatcher("12")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    // ---- insert ----

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("[]");
        sb.insert(1, true);
        assertEquals("[true]", sb.toString());
        sb.setLength(0);
        sb.append("[]").insert(1, false);
        assertEquals("[false]", sb.toString());
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertAtEndEqualsAppend() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(sb.length(), 'c');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertIndexOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("ab");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(3, 'x'));
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (char[]) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'x', 'b', 'c', 'y'}, 1, 2);
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder("ad");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, new char[] {'a', 'b'}, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, new char[] {'a', 'b'}, 0, 5));
    }

    @Test
    public void testInsertPrimitivesAndObject() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 123);
        assertEquals("123", sb.toString());
        sb.insert(0, 1L);
        assertEquals("1123", sb.toString());
        final StrBuilder sb2 = new StrBuilder();
        sb2.insert(0, 1.5d);
        assertEquals("1.5", sb2.toString());
        final StrBuilder sb3 = new StrBuilder();
        sb3.insert(0, 1.5f);
        assertEquals("1.5", sb3.toString());
        final StrBuilder sb4 = new StrBuilder();
        sb4.insert(0, (Object) "obj");
        assertEquals("obj", sb4.toString());
        final StrBuilder sb5 = new StrBuilder();
        sb5.insert(0, (Object) null);
        assertEquals("", sb5.toString());
    }

    @Test
    public void testInsertStringNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (String) null);
        assertEquals("ab", sb.toString());
        sb.setNullText("N");
        sb.insert(1, (String) null);
        assertEquals("aNb", sb.toString());
    }

    // ---- left/mid/right String ----

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("he", sb.leftString(2));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
        assertEquals("hello", sb.leftString(100));
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("lo", sb.rightString(2));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
        assertEquals("hello", sb.rightString(100));
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("ell", sb.midString(1, 3));
        assertEquals("hello", sb.midString(-5, 100));
        assertEquals("", sb.midString(100, 5));
        assertEquals("", sb.midString(1, -1));
        assertEquals("llo", sb.midString(2, 10));
    }

    // ---- replace / replaceAll / replaceFirst ----

    @Test
    public void testReplaceRangeShrinkAndGrow() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(0, 5, "HI");
        assertEquals("HI world", sb.toString());
        final StrBuilder sb2 = new StrBuilder("hi");
        sb2.replace(0, 2, "hello");
        assertEquals("hello", sb2.toString());
    }

    @Test
    public void testReplaceRangeNullDeletesRange() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(5, 11, null);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReplaceRangeEndClampedToSize() {
        final StrBuilder sb = new StrBuilder("hello");
        sb.replace(2, 1000, "X");
        assertEquals("heX", sb.toString());
    }

    @Test
    public void testReplaceAllChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());
    }

    @Test
    public void testReplaceAllStringGrowingReplacement() {
        final StrBuilder sb = new StrBuilder("a-a-a");
        sb.replaceAll("a", "bb");
        assertEquals("bb-bb-bb", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullSearchNoAction() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.replaceAll((String) null, "x");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        final StrBuilder sb = new StrBuilder("a-a-a");
        sb.replaceFirst("a", "bb");
        assertEquals("bb-a-a", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReplaceMatcherWithReplaceCountLimit() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("123"), "#", 0, sb.length(), 2);
        assertEquals("a#b#c3", sb.toString());
    }

    // ---- reverse ----

    @Test
    public void testReverseSimple() {
        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    @Test
    public void testReverseEmptyAndSingle() {
        final StrBuilder empty = new StrBuilder();
        empty.reverse();
        assertEquals("", empty.toString());
        final StrBuilder single = new StrBuilder("a");
        single.reverse();
        assertEquals("a", single.toString());
    }

    @Test
    public void testReverseMatchesJdkForSupplementaryCodePoints() {
        final String withSurrogatePair = "AB😀CD";
        final String expected = new StringBuilder(withSurrogatePair).reverse().toString();
        final StrBuilder sb = new StrBuilder(withSurrogatePair);
        sb.reverse();
        assertEquals(expected, sb.toString());
    }

    // ---- setLength / size / isEmpty ----

    @Test
    public void testSetLengthGrowFillsNulChar() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('\u0000', sb.charAt(2));
        assertEquals('\u0000', sb.charAt(3));
    }

    @Test
    public void testSetLengthShrink() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    public void testIsEmptyIsNotEmptySizeLength() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        assertEquals(0, sb.size());
        assertEquals(0, sb.length());
        sb.append("x");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
        assertEquals(1, sb.size());
        assertEquals(1, sb.length());
    }

    // ---- capacity / ensureCapacity / minimizeCapacity ----

    @Test
    public void testCapacityGrowsOnDemand() {
        final StrBuilder sb = new StrBuilder(2);
        assertEquals(2, sb.capacity());
        sb.append("abcdef");
        assertTrue(sb.capacity() >= 6);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testEnsureCapacityNoShrink() {
        final StrBuilder sb = new StrBuilder(50);
        sb.append("abc");
        sb.ensureCapacity(10);
        assertEquals(50, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(50);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    // ---- subSequence / substring / toCharArray ----

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertEquals("hello", sb.subSequence(0, 5));
        assertEquals("world", sb.subSequence(6, 11));
    }

    @Test
    public void testSubSequenceInvalidThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(3, 1));
    }

    @Test
    public void testSubstringOneArg() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertEquals("world", sb.substring(6));
    }

    @Test
    public void testSubstringEndIndexClampedToSize() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.substring(0, 1000));
    }

    @Test
    public void testSubstringInvalidThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(-1, 3));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(4, 2));
    }

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.toCharArray().length);
    }

    @Test
    public void testToCharArrayFull() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'c', 'd'}, sb.toCharArray(2, 4));
        assertArrayEquals(new char[0], sb.toCharArray(2, 2));
    }

    @Test
    public void testToCharArrayRangeEndClampedToSize() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'b', 'c'}, sb.toCharArray(1, 1000));
    }

    @Test
    public void testGetCharsIntoDestination() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[6];
        sb.getChars(1, 4, dest, 0);
        assertArrayEquals(new char[] {'b', 'c', 'd', '\u0000', '\u0000', '\u0000'}, dest);
    }

    @Test
    public void testGetCharsDestinationNullOrTooSmallCreatesNew() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
        final char[] tooSmall = new char[1];
        final char[] result2 = sb.getChars(tooSmall);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result2);
    }

    @Test
    public void testGetCharsRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] dest = new char[5];
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 2, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 100, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(2, 1, dest, 0));
    }

    // ---- toString / toStringBuffer / toStringBuilder / build ----

    @Test
    public void testToStringIndependentCopy() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s = sb.toString();
        sb.append("d");
        assertEquals("abc", s);
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder jsb = sb.toStringBuilder();
        assertEquals("abc", jsb.toString());
    }

    @Test
    public void testBuildMatchesToString() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(sb.toString(), sb.build());
    }

    // ---- trim ----

    @Test
    public void testTrimRemovesLeadingAndTrailingWhitespace() {
        final StrBuilder sb = new StrBuilder("  hello world  \t");
        sb.trim();
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testTrimAllWhitespaceBecomesEmpty() {
        final StrBuilder sb = new StrBuilder("   \t  ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimEmptyNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    // ---- null text ----

    @Test
    public void testNullTextDefaultIsNull() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(null, sb.getNullText());
    }

    @Test
    public void testSetNullTextEmptyStringBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertEquals(null, sb.getNullText());
    }

    @Test
    public void testSetNullTextNonEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
    }

    // ---- asReader ----

    @Test
    public void testAsReaderReadsContent() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
    }

    @Test
    public void testAsReaderReadIntoArray() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final char[] buf = new char[4];
        final int n = reader.read(buf, 0, 4);
        assertEquals(4, n);
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd'}, buf);
    }

    @Test
    public void testAsReaderMarkReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        reader.read();
        reader.mark(10);
        reader.read();
        reader.read();
        reader.reset();
        assertEquals('b', reader.read());
    }

    @Test
    public void testAsReaderReadyAndSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        assertTrue(reader.ready());
        reader.skip(3);
        assertEquals('d', reader.read());
    }

    @Test
    public void testAsReaderSharesBufferWithBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        reader.read();
        sb.append("cd");
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals('d', reader.read());
        assertEquals(-1, reader.read());
    }

    // ---- asWriter ----

    @Test
    public void testAsWriterWritesIntoBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("hello");
        writer.write(' ');
        writer.write(new char[] {'w', 'o', 'r', 'l', 'd'});
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testAsWriterWriteRanges() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("abcdef", 1, 3);
        writer.write(new char[] {'w', 'x', 'y', 'z'}, 1, 2);
        assertEquals("bcdxy", sb.toString());
    }

    // ---- asTokenizer ----

    @Test
    public void testAsTokenizerTokenizesContent() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        final String[] tokens = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokens);
    }

    @Test
    public void testAsTokenizerNeedsResetToPickUpChanges() {
        final StrBuilder sb = new StrBuilder("a b");
        final StrTokenizer tokenizer = sb.asTokenizer();
        tokenizer.getTokenArray();
        sb.append(" c");
        final String[] tokensBeforeReset = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b"}, tokensBeforeReset);
        tokenizer.reset();
        final String[] tokensAfterReset = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokensAfterReset);
    }

    // ---- appendTo ----

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder target = new StringBuilder();
        sb.appendTo(target);
        assertEquals("abc", target.toString());
    }

    @Test
    public void testAppendToStringBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer target = new StringBuffer();
        sb.appendTo(target);
        assertEquals("abc", target.toString());
    }

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final StringWriter target = new StringWriter();
        sb.appendTo(target);
        assertEquals("abc", target.toString());
    }

    @Test
    public void testAppendToCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final CharBuffer target = CharBuffer.allocate(10);
        sb.appendTo(target);
        target.flip();
        assertEquals("abc", target.toString());
    }

    @Test
    public void testAppendToPlainAppendable() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final PlainAppendable target = new PlainAppendable();
        sb.appendTo(target);
        assertEquals("abc", target.sb.toString());
    }

    // ---- readFrom ----

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new StringReader("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("hello".toCharArray());
        final int read = sb.readFrom(cb);
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromPlainReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new PlainReadable("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromAppendsAfterExistingContent() throws IOException {
        final StrBuilder sb = new StrBuilder("start-");
        sb.readFrom(new StringReader("end"));
        assertEquals("start-end", sb.toString());
    }

    // ---- CharSequence interface basics ----

    @Test
    public void testLengthAndCharSequenceContract() {
        final CharSequence cs = new StrBuilder("abc");
        assertEquals(3, cs.length());
        assertEquals('b', cs.charAt(1));
    }

    @Test
    public void testGetBufferReturnsSameArrayInstance() {
        final StrBuilder sb = new StrBuilder("abc");
        assertSame(sb.getBuffer(), sb.getBuffer());
        assertNotNull(sb.getBuffer());
    }

    // ---- misc list helper not needed beyond these tests ----

    @Test
    public void testAppendAllArrayNullNoEffect() {
        final StrBuilder sb = new StrBuilder();
        final String[] nullArray = null;
        sb.appendAll(nullArray);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendAllIteratorWithList() {
        final List<Integer> values = new ArrayList<>();
        values.add(1);
        values.add(2);
        values.add(3);
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) values);
        assertEquals("123", sb.toString());
    }
}
