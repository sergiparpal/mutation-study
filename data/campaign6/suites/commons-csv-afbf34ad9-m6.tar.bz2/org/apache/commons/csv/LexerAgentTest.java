/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    private Lexer createLexer(final String input) {
        return createLexer(input, CSVFormat.DEFAULT);
    }

    @Test
    void testSimpleTokensAndEof() throws IOException {
        final Lexer lexer = createLexer("a,b,c");
        try {
            final Token t1 = new Token();
            lexer.nextToken(t1);
            assertEquals(Token.Type.TOKEN, t1.type);
            assertEquals("a", t1.content.toString());

            final Token t2 = new Token();
            lexer.nextToken(t2);
            assertEquals(Token.Type.TOKEN, t2.type);
            assertEquals("b", t2.content.toString());

            // No trailing newline: the last field is reported directly as EOF with data ready.
            final Token t3 = new Token();
            lexer.nextToken(t3);
            assertEquals(Token.Type.EOF, t3.type);
            assertTrue(t3.isReady);
            assertEquals("c", t3.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEmptyInputYieldsImmediateEof() throws IOException {
        final Lexer lexer = createLexer("");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
    }

    @Test
    void testTrailingDelimiterProducesEmptyFinalToken() throws IOException {
        final Lexer lexer = createLexer("a,");
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        // There is data (empty string) at EOF after a trailing delimiter.
        assertEquals(Token.Type.EOF, t2.type);
        assertTrue(t2.isReady);
        assertEquals("", t2.content.toString());
    }

    @Test
    void testEncapsulatedTokenWithEscapedQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"\"b\",c");
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertTrue(t1.isQuoted);
        assertEquals("a\"b", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("c", t2.content.toString());
    }

    @Test
    void testEncapsulatedTokenUnclosedThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("\"unterminated");
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(e.getMessage().contains("EOF reached before encapsulated token finished"));
    }

    @Test
    void testEncapsulatedTokenUnclosedWithLenientEofReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"unterminated", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("unterminated", token.content.toString());
    }

    @Test
    void testInvalidCharAfterEncapsulatedTokenThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("\"a\"b,c");
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(e.getMessage().contains("Invalid character between encapsulated token and delimiter"));
    }

    @Test
    void testTrailingDataAppendsCharsInsteadOfThrowing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"a\"bc,d", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("abc", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("d", t2.content.toString());
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("# a comment \nfield", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.COMMENT, t1.type);
        assertEquals("a comment", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("field", t2.content.toString());
    }

    @Test
    void testEmptyCommentLineAtEofYieldsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\na\n\nb", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("b", t2.content.toString());
    }

    @Test
    void testIgnoreEmptyLinesAtEndOfFileYieldsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("a\n\n\n", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertFalse(t2.isReady);
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsWhitespace() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer("  a  , b ,c  ", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals("a", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals("b", t2.content.toString());

        final Token t3 = new Token();
        lexer.nextToken(t3);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("c", t3.content.toString());
    }

    @Test
    void testEscapeHandlingWithinSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote(null).get();
        final Lexer lexer = createLexer("a\\,b,c", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.TOKEN, t1.type);
        // The escaped comma is content, not a delimiter.
        assertEquals("a,b", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("c", t2.content.toString());
    }

    @Test
    void testEscapeOfUnexpectedCharacterIsPreservedLiterally() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote(null).get();
        final Lexer lexer = createLexer("a\\zb", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a\\zb", token.content.toString());
    }

    @Test
    void testMultiCharDelimiterTokenizing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a::b::c", format);
        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("b", t2.content.toString());

        final Token t3 = new Token();
        lexer.nextToken(t3);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("c", t3.content.toString());
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer("xy");
        assertFalse(lexer.isDelimiter('x'));
        assertTrue(lexer.isDelimiter(','));
    }

    @Test
    void testIsDelimiterMultiCharPartialMatchFails() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        // The ch argument represents the char already consumed by the caller; the
        // remaining unread stream ("x") does not continue the delimiter.
        final Lexer lexer = createLexer("x", format);
        assertFalse(lexer.isDelimiter(':'));
    }

    @Test
    void testIsDelimiterMultiCharFullMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        // The remaining unread stream continues the 2-char delimiter, then more data.
        final Lexer lexer = createLexer(":rest", format);
        assertTrue(lexer.isDelimiter(':'));
    }

    @Test
    void testIsEscapeDelimiterTrueAndFalse() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("|").setEscape('!').setQuote(null).get();
        // isEscapeDelimiter() is called right after the escape char has already been
        // consumed by the caller, so the unread stream starts with the delimiter itself.
        final Lexer matching = createLexer("|rest", format);
        assertTrue(matching.isEscapeDelimiter());

        final Lexer nonMatching = createLexer("ab", format);
        assertFalse(nonMatching.isEscapeDelimiter());
    }

    @Test
    void testIsEscapeDelimiterMultiCharDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').setQuote(null).get();
        // Pattern after the leading escape has been consumed: delim[0], escape, delim[1].
        final Lexer lexer = createLexer(":!:rest", format);
        assertTrue(lexer.isEscapeDelimiter());
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer("x");
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('x'));
    }

    @Test
    void testIsCommentStartQuoteAndEscapePredicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setQuote('"').get();
        final Lexer lexer = createLexer("x", format);
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('x'));
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('x'));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('x'));
    }

    @Test
    void testIsCommentStartDisabledWhenNoMarkerConfigured() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    void testIsEscapeDisabledWhenNoEscapeConfigured() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer("x");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        assertFalse(lexer.isStartOfLine(EOF));
    }

    @Test
    void testReadEndOfLineLfOnly() throws IOException {
        final Lexer lexer = createLexer("\nrest");
        assertTrue(lexer.readEndOfLine(Constants.LF));
        assertEquals("\n", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrOnly() throws IOException {
        final Lexer lexer = createLexer("\rrest");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrLfSwallowsLf() throws IOException {
        final Lexer lexer = createLexer("\nrest");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r\n", lexer.getFirstEol());
        // the LF should have been consumed as part of the CRLF sequence
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals("rest", token.content.toString());
    }

    @Test
    void testReadEndOfLineNonEolReturnsFalse() throws IOException {
        final Lexer lexer = createLexer("abc");
        assertFalse(lexer.readEndOfLine('a'));
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testGetFirstEolInitiallyNull() {
        final Lexer lexer = createLexer("abc");
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testReadEscapeStandardSequences() throws IOException {
        final Lexer lexerR = createLexer("r");
        assertEquals(Constants.CR, lexerR.readEscape());

        final Lexer lexerN = createLexer("n");
        assertEquals(Constants.LF, lexerN.readEscape());

        final Lexer lexerT = createLexer("t");
        assertEquals(Constants.TAB, lexerT.readEscape());

        final Lexer lexerB = createLexer("b");
        assertEquals(Constants.BACKSPACE, lexerB.readEscape());

        final Lexer lexerF = createLexer("f");
        assertEquals(Constants.FF, lexerF.readEscape());
    }

    @Test
    void testReadEscapeLiteralControlCharsPassThrough() throws IOException {
        final Lexer lexer = createLexer("\r");
        assertEquals(Constants.CR, lexer.readEscape());
    }

    @Test
    void testReadEscapeMetaCharacterPassesThrough() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote('"').get();
        final Lexer lexer = createLexer("\"", format);
        assertEquals('"', lexer.readEscape());
    }

    @Test
    void testReadEscapeUnexpectedCharacterReturnsEof() throws IOException {
        final Lexer lexer = createLexer("z");
        assertEquals(EOF, lexer.readEscape());
    }

    @Test
    void testReadEscapeAtEofThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("");
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        assertTrue(e.getMessage().contains("EOF while processing escape sequence"));
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer("x");
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());

        final StringBuilder allSpaces = new StringBuilder("    ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals("", allSpaces.toString());

        final StringBuilder noSpaces = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noSpaces);
        assertEquals("abc", noSpaces.toString());

        final StringBuilder empty = new StringBuilder("");
        lexer.trimTrailingSpaces(empty);
        assertEquals("", empty.toString());
    }

    @Test
    void testCloseMarksReaderClosedAndIsIdempotentlyQueryable() throws IOException {
        final Lexer lexer = createLexer("abc");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testGetCurrentLineNumberAdvancesAcrossRecords() throws IOException {
        final Lexer lexer = createLexer("a\nb\nc");
        assertEquals(0, lexer.getCurrentLineNumber());

        final Token t1 = new Token();
        lexer.nextToken(t1);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals(1, lexer.getCurrentLineNumber());

        final Token t2 = new Token();
        lexer.nextToken(t2);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals(2, lexer.getCurrentLineNumber());

        final Token t3 = new Token();
        lexer.nextToken(t3);
        assertEquals(Token.Type.EOF, t3.type);
    }

    @Test
    void testGetCharacterPositionAdvancesWithReads() throws IOException {
        final Lexer lexer = createLexer("abc");
        assertEquals(0, lexer.getCharacterPosition());
        final Token token = new Token();
        lexer.nextToken(token);
        // 3 content chars plus the trailing EOF read that terminates the token.
        assertEquals(4, lexer.getCharacterPosition());
    }

    @Test
    void testGetBytesReadWithoutEncoderIsZero() throws IOException {
        final Lexer lexer = createLexer("abc");
        final Token token = new Token();
        lexer.nextToken(token);
        // No charset/byte tracking was configured on the underlying reader.
        assertEquals(0, lexer.getBytesRead());
    }
}
