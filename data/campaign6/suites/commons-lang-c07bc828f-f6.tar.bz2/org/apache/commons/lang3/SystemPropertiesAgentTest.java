/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link SystemProperties}.
 */
class SystemPropertiesAgentTest {

    private static final String UNSET_KEY = "org.apache.commons.lang3.SystemPropertiesAgentTest.unset.key";

    /**
     * Runs the given action while a system property is temporarily set (or cleared), restoring the
     * original value (or absence of one) afterwards.
     */
    private void withProperty(final String key, final String value, final Runnable action) {
        final String original = System.getProperty(key);
        try {
            if (value == null) {
                System.clearProperty(key);
            } else {
                System.setProperty(key, value);
            }
            action.run();
        } finally {
            if (original == null) {
                System.clearProperty(key);
            } else {
                System.setProperty(key, original);
            }
        }
    }

    @Test
    void testConstructorDoesNotThrow() {
        assertNotNull(new SystemProperties());
    }

    @Test
    void testGetPropertyKnown() {
        assertEquals(System.getProperty("java.version"), SystemProperties.getProperty("java.version"));
        assertEquals(System.getProperty("java.version"), SystemProperties.getJavaVersion());
    }

    @Test
    void testGetPropertyUnset() {
        System.clearProperty(UNSET_KEY);
        assertNull(SystemProperties.getProperty(UNSET_KEY));
    }

    @Test
    void testGetPropertyNullKey() {
        assertNull(SystemProperties.getProperty(null));
    }

    @Test
    void testGetPropertyEmptyKey() {
        assertNull(SystemProperties.getProperty(""));
    }

    @Test
    void testIsPropertySetTrue() {
        assertTrue(SystemProperties.isPropertySet("java.version"));
    }

    @Test
    void testIsPropertySetFalse() {
        System.clearProperty(UNSET_KEY);
        assertFalse(SystemProperties.isPropertySet(UNSET_KEY));
    }

    @Test
    void testIsPropertySetNullKey() {
        assertFalse(SystemProperties.isPropertySet(null));
    }

    @Test
    void testGetBooleanDefaultWhenAbsentTrue() {
        System.clearProperty(UNSET_KEY);
        assertTrue(SystemProperties.getBoolean(UNSET_KEY, () -> true));
    }

    @Test
    void testGetBooleanDefaultWhenAbsentFalse() {
        System.clearProperty(UNSET_KEY);
        assertFalse(SystemProperties.getBoolean(UNSET_KEY, () -> false));
    }

    @Test
    void testGetBooleanNullSupplierWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        assertFalse(SystemProperties.getBoolean(UNSET_KEY, null));
    }

    @Test
    void testGetBooleanParsesTrue() {
        withProperty(UNSET_KEY, "true", () -> assertTrue(SystemProperties.getBoolean(UNSET_KEY, () -> false)));
    }

    @Test
    void testGetBooleanParsesCaseInsensitiveTrue() {
        withProperty(UNSET_KEY, "TrUe", () -> assertTrue(SystemProperties.getBoolean(UNSET_KEY, () -> false)));
    }

    @Test
    void testGetBooleanParsesNonTrueStringAsFalse() {
        withProperty(UNSET_KEY, "notabool", () -> assertFalse(SystemProperties.getBoolean(UNSET_KEY, () -> true)));
    }

    @Test
    void testGetBooleanWithClassBuildsKey() {
        final String key = String.class.getSimpleName() + ".someFlag";
        withProperty(key, "true", () -> assertTrue(SystemProperties.getBoolean(String.class, "someFlag", () -> false)));
    }

    @Test
    void testGetIntDefaultWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        assertEquals(42, SystemProperties.getInt(UNSET_KEY, () -> 42));
    }

    @Test
    void testGetIntNullSupplierWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        assertEquals(0, SystemProperties.getInt(UNSET_KEY, null));
    }

    @Test
    void testGetIntParsesValue() {
        withProperty(UNSET_KEY, "123", () -> assertEquals(123, SystemProperties.getInt(UNSET_KEY, () -> 0)));
    }

    @Test
    void testGetIntParsesNegativeValue() {
        withProperty(UNSET_KEY, "-5", () -> assertEquals(-5, SystemProperties.getInt(UNSET_KEY, () -> 0)));
    }

    @Test
    void testGetIntInvalidValueThrows() {
        withProperty(UNSET_KEY, "notanumber", () -> assertThrows(NumberFormatException.class, () -> SystemProperties.getInt(UNSET_KEY, () -> 0)));
    }

    @Test
    void testGetIntWithClassBuildsKey() {
        final String key = String.class.getSimpleName() + ".someInt";
        withProperty(key, "7", () -> assertEquals(7, SystemProperties.getInt(String.class, "someInt", () -> 0)));
    }

    @Test
    void testGetLongDefaultWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        assertEquals(42L, SystemProperties.getLong(UNSET_KEY, () -> 42L));
    }

    @Test
    void testGetLongNullSupplierWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        assertEquals(0L, SystemProperties.getLong(UNSET_KEY, null));
    }

    @Test
    void testGetLongParsesValue() {
        withProperty(UNSET_KEY, "1234567890123", () -> assertEquals(1234567890123L, SystemProperties.getLong(UNSET_KEY, () -> 0L)));
    }

    @Test
    void testGetLongInvalidValueThrows() {
        withProperty(UNSET_KEY, "notanumber", () -> assertThrows(NumberFormatException.class, () -> SystemProperties.getLong(UNSET_KEY, () -> 0L)));
    }

    @Test
    void testGetLongWithClassBuildsKey() {
        final String key = String.class.getSimpleName() + ".someLong";
        withProperty(key, "9", () -> assertEquals(9L, SystemProperties.getLong(String.class, "someLong", () -> 0L)));
    }

    @Test
    void testGetPathDefaultWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        final Path fallback = Paths.get("fallback");
        assertEquals(fallback, SystemProperties.getPath(UNSET_KEY, () -> fallback));
    }

    @Test
    void testGetPathNullSupplierWhenAbsent() {
        System.clearProperty(UNSET_KEY);
        assertNull(SystemProperties.getPath(UNSET_KEY, null));
    }

    @Test
    void testGetPathParsesValue() {
        withProperty(UNSET_KEY, "some/dir", () -> assertEquals(Paths.get("some/dir"), SystemProperties.getPath(UNSET_KEY, () -> null)));
    }

    @Test
    void testGetJavaVersionMatchesSystem() {
        assertEquals(System.getProperty("java.version"), SystemProperties.getJavaVersion());
    }

    @Test
    void testGetOsNameMatchesSystem() {
        assertEquals(System.getProperty("os.name"), SystemProperties.getOsName());
    }

    @Test
    void testGetFileSeparatorMatchesSystem() {
        assertEquals(System.getProperty("file.separator"), SystemProperties.getFileSeparator());
    }

    @Test
    void testGetPathSeparatorMatchesSystem() {
        assertEquals(System.getProperty("path.separator"), SystemProperties.getPathSeparator());
    }

    @Test
    void testGetUserHomeMatchesSystem() {
        assertEquals(System.getProperty("user.home"), SystemProperties.getUserHome());
    }

    @Test
    void testGetLineSeparatorMatchesSystem() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator());
    }

    @Test
    void testGetLineSeparatorDefaultWhenAbsent() {
        withProperty("line.separator", null, () -> assertEquals("fallback", SystemProperties.getLineSeparator(() -> "fallback")));
    }

    @Test
    void testGetUserNameDefaultWhenAbsent() {
        withProperty("user.name", null, () -> assertEquals("fallback", SystemProperties.getUserName("fallback")));
    }

    @Test
    void testGetUserNameReturnsSetValue() {
        withProperty("user.name", "someone", () -> assertEquals("someone", SystemProperties.getUserName("fallback")));
    }

    @Test
    void testGetJavaSpecificationVersionDefaultWhenAbsent() {
        withProperty("java.specification.version", null, () -> assertEquals("fallback", SystemProperties.getJavaSpecificationVersion("fallback")));
    }

    @Test
    void testGetJavaSpecificationVersionReturnsSetValue() {
        withProperty("java.specification.version", "99", () -> assertEquals("99", SystemProperties.getJavaSpecificationVersion("fallback")));
    }

    @Test
    void testJdkXmlEntityReplacementLimitConstantIsSpelledCorrectly() {
        assertEquals("jdk.xml.entityReplacementLimit", SystemProperties.JDK_XML_ENTITY_REPLACEMENT_LIMIT);
    }

    @Test
    void testPropertyNameConstantsMatchJavadocValue() {
        assertEquals("java.version", SystemProperties.JAVA_VERSION);
        assertEquals("os.name", SystemProperties.OS_NAME);
        assertEquals("file.separator", SystemProperties.FILE_SEPARATOR);
        assertEquals("path.separator", SystemProperties.PATH_SEPARATOR);
        assertEquals("line.separator", SystemProperties.LINE_SEPARATOR);
        assertEquals("user.name", SystemProperties.USER_NAME);
        assertEquals("user.home", SystemProperties.USER_HOME);
    }
}
