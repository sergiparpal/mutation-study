/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultRequiresSemiColonDecimal() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#65;", 0, sw);
        assertEquals(5, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testDefaultWithoutSemiColonReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#65", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testSemiColonOptionalWithoutSemiColon() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#65", 0, sw);
        assertEquals(4, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testSemiColonOptionalWithSemiColon() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#65;", 0, sw);
        assertEquals(5, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testErrorIfNoSemiColonThrows() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final StringWriter sw = new StringWriter();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("&#65", 0, sw);
            }
        });
        assertEquals("Semi-colon required at end of numeric entity", ex.getMessage());
    }

    @Test
    void testErrorIfNoSemiColonDoesNotThrowWhenPresent() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#65;", 0, sw);
        assertEquals(5, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testHexLowerCaseWithSemiColon() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#x41;", 0, sw);
        assertEquals(6, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testHexUpperCaseWithSemiColon() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#X41;", 0, sw);
        assertEquals(6, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testHexOnlyXNoDigitsReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#x", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testNoAmpHashPrefixReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("hello", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testTooShortInputReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        // "&" alone: index(0) is not < seqEnd(1) - 2 = -1, so no match attempted.
        final int consumed = unescaper.translate("&", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testNonDigitAfterHashReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#abc;", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testOutOfRangeCodePointReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#1234567890;", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testNegativeOverflowNumberFormatExceptionReturnsZero() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        // 20 decimal digits overflow Integer parsing and trigger NumberFormatException internally.
        final int consumed = unescaper.translate("&#99999999999999999999;", 0, sw);
        assertEquals(0, consumed);
        assertEquals("", sw.toString());
    }

    @Test
    void testSupplementaryCodePoint() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#68642;", 0, sw);
        assertEquals(8, consumed);
        assertEquals("𐰢", sw.toString());
    }

    @Test
    void testTranslateFromNonZeroIndex() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final String input = "---&#65;---";
        final int consumed = unescaper.translate(input, 3, sw);
        assertEquals(5, consumed);
        assertEquals("A", sw.toString());
    }

    @Test
    void testFullTranslateOfCompleteString() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final String result = unescaper.translate("ABC&#65;&#66;&#67;DEF");
        assertEquals("ABCABCDEF", result);
    }

    @Test
    void testFullTranslateWithTrailingTextAfterNonMatchingEntity() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final String result = unescaper.translate("&#65 is A");
        assertEquals("&#65 is A", result);
    }

    @Test
    void testIsSetDefaultOption() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetExplicitOptions() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonOptional, NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testZeroCodePoint() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#0;", 0, sw);
        assertEquals(4, consumed);
        assertEquals("\u0000", sw.toString());
    }

    @Test
    void testMaxCodePoint() throws Exception {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter sw = new StringWriter();
        final int consumed = unescaper.translate("&#1114111;", 0, sw);
        assertEquals(10, consumed);
        assertEquals(Character.toChars(Character.MAX_CODE_POINT)[0], sw.toString().charAt(0));
        assertEquals(2, sw.toString().length());
    }
}
