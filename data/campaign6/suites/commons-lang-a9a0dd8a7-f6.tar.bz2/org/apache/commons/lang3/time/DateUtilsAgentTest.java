/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private static Calendar newCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Date newDate(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    private static void assertDateEquals(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis, final Date actual) {
        final Calendar c = Calendar.getInstance();
        c.setTime(actual);
        assertEquals(year, c.get(Calendar.YEAR), "year");
        assertEquals(month, c.get(Calendar.MONTH), "month");
        assertEquals(day, c.get(Calendar.DAY_OF_MONTH), "day");
        assertEquals(hour, c.get(Calendar.HOUR_OF_DAY), "hour");
        assertEquals(minute, c.get(Calendar.MINUTE), "minute");
        assertEquals(second, c.get(Calendar.SECOND), "second");
        assertEquals(millis, c.get(Calendar.MILLISECOND), "millis");
    }

    // ---------------------------------------------------------------- add*

    @Test
    void testAddDays() {
        final Date date = newDate(2022, Calendar.JANUARY, 31, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.FEBRUARY, 1, 10, 0, 0, 0, DateUtils.addDays(date, 1));
        assertDateEquals(2022, Calendar.JANUARY, 30, 10, 0, 0, 0, DateUtils.addDays(date, -1));
        // original unchanged
        assertDateEquals(2022, Calendar.JANUARY, 31, 10, 0, 0, 0, date);
    }

    @Test
    void testAddDaysNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
    }

    @Test
    void testAddHours() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 2, 1, 0, 0, 0, DateUtils.addHours(date, 2));
    }

    @Test
    void testAddHoursNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addHours(null, 1);
            }
        });
    }

    @Test
    void testAddMinutes() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 59, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 1, 11, 1, 0, 0, DateUtils.addMinutes(date, 2));
    }

    @Test
    void testAddMinutesNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMinutes(null, 1);
            }
        });
    }

    @Test
    void testAddSeconds() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 59, 0);
        assertDateEquals(2022, Calendar.JANUARY, 1, 10, 1, 1, 0, DateUtils.addSeconds(date, 2));
    }

    @Test
    void testAddSecondsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addSeconds(null, 1);
            }
        });
    }

    @Test
    void testAddMilliseconds() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 999);
        assertDateEquals(2022, Calendar.JANUARY, 1, 10, 0, 1, 1, DateUtils.addMilliseconds(date, 2));
    }

    @Test
    void testAddMillisecondsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMilliseconds(null, 1);
            }
        });
    }

    @Test
    void testAddWeeks() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 8, 0, 0, 0, 0, DateUtils.addWeeks(date, 1));
    }

    @Test
    void testAddWeeksNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addWeeks(null, 1);
            }
        });
    }

    @Test
    void testAddMonthsEndOfMonthClamps() {
        final Date date = newDate(2022, Calendar.JANUARY, 31, 0, 0, 0, 0);
        // Calendar semantics: Jan 31 + 1 month -> Feb 28 (2022 is not a leap year)
        assertDateEquals(2022, Calendar.FEBRUARY, 28, 0, 0, 0, 0, DateUtils.addMonths(date, 1));
    }

    @Test
    void testAddMonthsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addMonths(null, 1);
            }
        });
    }

    @Test
    void testAddYears() {
        final Date date = newDate(2020, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        // leap day + 1 year -> Feb 28 2021 per Calendar semantics
        assertDateEquals(2021, Calendar.FEBRUARY, 28, 0, 0, 0, 0, DateUtils.addYears(date, 1));
    }

    @Test
    void testAddYearsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addYears(null, 1);
            }
        });
    }

    // ------------------------------------------------------------- ceiling

    @Test
    void testCeilingDateHour() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 14, 0, 0, 0, DateUtils.ceiling(date, Calendar.HOUR));
    }

    @Test
    void testCeilingDateMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.APRIL, 1, 0, 0, 0, 0, DateUtils.ceiling(date, Calendar.MONTH));
    }

    @Test
    void testCeilingCalendarReturnsNewInstance() {
        final Calendar original = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar ceiled = DateUtils.ceiling(original, Calendar.HOUR);
        assertEquals(13, original.get(Calendar.HOUR_OF_DAY), "original calendar must not be mutated");
        assertEquals(14, ceiled.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingMillisecondFieldIsNoOp() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 13, 45, 1, 231, DateUtils.ceiling(date, Calendar.MILLISECOND));
    }

    @Test
    void testCeilingObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 14, 0, 0, 0, DateUtils.ceiling((Object) date, Calendar.HOUR));
        assertDateEquals(2002, Calendar.MARCH, 28, 14, 0, 0, 0, DateUtils.ceiling((Object) cal, Calendar.HOUR));
    }

    @Test
    void testCeilingObjectInvalidTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) "not a date", Calendar.HOUR);
            }
        });
    }

    @Test
    void testCeilingNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) null, Calendar.HOUR);
            }
        });
    }

    @Test
    void testCeilingYearTooLargeThrowsArithmeticException() {
        final Calendar huge = new GregorianCalendar();
        huge.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(huge, Calendar.MONTH);
            }
        });
    }

    @Test
    void testCeilingYearAtBoundaryDoesNotThrow() {
        final Calendar boundary = new GregorianCalendar();
        boundary.set(Calendar.YEAR, 280000000);
        final Calendar result = DateUtils.ceiling(boundary, Calendar.MONTH);
        assertNotNull(result);
    }

    @Test
    void testCeilingSemiMonthFirstHalf() {
        final Date date = newDate(2008, Calendar.JANUARY, 5, 10, 0, 0, 0);
        assertDateEquals(2008, Calendar.JANUARY, 16, 0, 0, 0, 0, DateUtils.ceiling(date, DateUtils.SEMI_MONTH));
    }

    @Test
    void testCeilingSemiMonthSecondHalf() {
        final Date date = newDate(2008, Calendar.JANUARY, 20, 10, 0, 0, 0);
        assertDateEquals(2008, Calendar.FEBRUARY, 1, 0, 0, 0, 0, DateUtils.ceiling(date, DateUtils.SEMI_MONTH));
    }

    // ------------------------------------------------------------ truncate

    @Test
    void testTruncateDateHour() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 13, 0, 0, 0, DateUtils.truncate(date, Calendar.HOUR));
    }

    @Test
    void testTruncateDateMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 1, 0, 0, 0, 0, DateUtils.truncate(date, Calendar.MONTH));
    }

    @Test
    void testTruncateObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 1, 0, 0, 0, 0, DateUtils.truncate((Object) date, Calendar.MONTH));
        assertDateEquals(2002, Calendar.MARCH, 1, 0, 0, 0, 0, DateUtils.truncate((Object) cal, Calendar.MONTH));
    }

    @Test
    void testTruncateObjectInvalidTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) Integer.valueOf(123), Calendar.HOUR);
            }
        });
    }

    @Test
    void testTruncateNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Calendar) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) null, Calendar.HOUR);
            }
        });
    }

    @Test
    void testTruncateUnsupportedFieldThrows() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    // --------------------------------------------------------------- round

    @Test
    void testRoundHourRoundsUpWhenMinutesPastHalf() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 14, 0, 0, 0, DateUtils.round(date, Calendar.HOUR));
    }

    @Test
    void testRoundHourRoundsDownWhenMinutesBeforeHalf() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 10, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 13, 0, 0, 0, DateUtils.round(date, Calendar.HOUR));
    }

    @Test
    void testRoundObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateEquals(2002, Calendar.MARCH, 28, 14, 0, 0, 0, DateUtils.round((Object) date, Calendar.HOUR));
        assertDateEquals(2002, Calendar.MARCH, 28, 14, 0, 0, 0, DateUtils.round((Object) cal, Calendar.HOUR));
    }

    @Test
    void testRoundObjectInvalidTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) new Object(), Calendar.HOUR);
            }
        });
    }

    @Test
    void testRoundNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Date) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Calendar) null, Calendar.HOUR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) null, Calendar.HOUR);
            }
        });
    }

    @Test
    void testRoundSemiMonthLowerHalfRoundsDown() {
        final Date date = newDate(2008, Calendar.JANUARY, 8, 0, 0, 0, 0);
        assertDateEquals(2008, Calendar.JANUARY, 1, 0, 0, 0, 0, DateUtils.round(date, DateUtils.SEMI_MONTH));
    }

    @Test
    void testRoundSemiMonthLowerHalfRoundsUp() {
        final Date date = newDate(2008, Calendar.JANUARY, 9, 0, 0, 0, 0);
        assertDateEquals(2008, Calendar.JANUARY, 16, 0, 0, 0, 0, DateUtils.round(date, DateUtils.SEMI_MONTH));
    }

    @Test
    void testRoundSemiMonthUpperHalfRoundsDown() {
        final Date date = newDate(2008, Calendar.JANUARY, 23, 0, 0, 0, 0);
        assertDateEquals(2008, Calendar.JANUARY, 16, 0, 0, 0, 0, DateUtils.round(date, DateUtils.SEMI_MONTH));
    }

    @Test
    void testRoundSemiMonthUpperHalfRoundsUp() {
        final Date date = newDate(2008, Calendar.JANUARY, 24, 0, 0, 0, 0);
        assertDateEquals(2008, Calendar.FEBRUARY, 1, 0, 0, 0, 0, DateUtils.round(date, DateUtils.SEMI_MONTH));
    }

    // ------------------------------------------------------- getFragmentIn*

    @Test
    void testGetFragmentInDaysMonth() {
        final Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        final Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInDaysYear() {
        final Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
    }

    @Test
    void testGetFragmentInDaysMillisecondIsZero() {
        final Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(0, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(jan1, Calendar.DAY_OF_YEAR));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        // The javadoc example of 435 (7*60+15) omits the whole days already elapsed in the
        // month, which contradicts its own prose ("all minutes of the past day(s) and hour(s)")
        // and the analogous Hours/Seconds/Milliseconds examples, which do include full days.
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(5 * 24 * 60 + 7 * 60 + 15, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(jan1, Calendar.MINUTE));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110, DateUtils.getFragmentInSeconds(jan6, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(jan1, Calendar.SECOND));
        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MINUTE));
    }

    @Test
    void testGetFragmentUnsupportedThrows() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(cal, Calendar.AM_PM);
            }
        });
    }

    @Test
    void testGetFragmentNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
    }

    // -------------------------------------------------------------- isSame*

    @Test
    void testIsSameDayTrueAndFalse() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    @Test
    void testIsSameDayNullThrows() {
        final Date d1 = new Date();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Date) null, d1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay(d1, (Date) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Calendar) null, Calendar.getInstance());
            }
        });
    }

    @Test
    void testIsSameInstantTrueAndFalse() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 1);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    @Test
    void testIsSameInstantNullThrows() {
        final Date d1 = new Date();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Date) null, d1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant(d1, (Date) null);
            }
        });
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));
        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 13, 46, 0, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal3));
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarClassIsFalse() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        // Use a genuinely different runtime Calendar subclass to exercise the getClass() check.
        final Calendar differentClass = new GregorianCalendar() {
            // anonymous subclass => different runtime class than GregorianCalendar
        };
        differentClass.setTimeInMillis(cal1.getTimeInMillis());
        differentClass.setTimeZone(cal1.getTimeZone());
        assertFalse(DateUtils.isSameLocalTime(cal1, differentClass));
    }

    @Test
    void testIsSameLocalTimeNullThrows() {
        final Calendar cal1 = Calendar.getInstance();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(null, cal1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(cal1, null);
            }
        });
    }

    // -------------------------------------------------------------- iterator

    @Test
    void testIteratorRangeMonthSunday() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 10, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            final Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertNotNull(first);
        assertNotNull(last);
        assertEquals(35, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(2002, last.get(Calendar.YEAR));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorRangeWeekCenter() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 10, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        int count = 0;
        Calendar last = null;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertNotNull(last);
    }

    @Test
    void testIteratorObjectDispatch() {
        final Date focusDate = newDate(2002, Calendar.JULY, 4, 10, 0, 0, 0);
        final Calendar focusCal = newCalendar(2002, Calendar.JULY, 4, 10, 0, 0, 0);
        assertTrue(DateUtils.iterator((Object) focusDate, DateUtils.RANGE_WEEK_SUNDAY).hasNext());
        assertTrue(DateUtils.iterator((Object) focusCal, DateUtils.RANGE_WEEK_SUNDAY).hasNext());
    }

    @Test
    void testIteratorObjectInvalidTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorInvalidRangeStyleThrows() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator(focus, 999);
            }
        });
    }

    @Test
    void testIteratorExhaustionThrowsNoSuchElement() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 10, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertThrows(NoSuchElementException.class, new Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIteratorRemoveThrowsUnsupported() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 10, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    // -------------------------------------------------------------- parseDate

    @Test
    void testParseDateValid() throws ParseException {
        final Date parsed = DateUtils.parseDate("2008-01-05", "yyyy-MM-dd");
        assertDateEquals(2008, Calendar.JANUARY, 5, 0, 0, 0, 0, parsed);
    }

    @Test
    void testParseDateTriesPatternsInOrder() throws ParseException {
        // The first pattern cannot match (no '/' in the input), so parseDate must fall
        // through to the second pattern.
        final Date parsed = DateUtils.parseDate("05-01-2008", "yyyy/MM/dd", "dd-MM-yyyy");
        assertDateEquals(2008, Calendar.JANUARY, 5, 0, 0, 0, 0, parsed);
    }

    @Test
    void testParseDateNoMatchingPatternThrows() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate((String) null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2008-01-05", (String[]) null);
            }
        });
    }

    @Test
    void testParseDateIsLenientAboutOverflow() throws ParseException {
        // Day-of-month 32 overflows into February under lenient parsing.
        final Date parsed = DateUtils.parseDate("20080132", "yyyyMMdd");
        assertDateEquals(2008, Calendar.FEBRUARY, 1, 0, 0, 0, 0, parsed);
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("20080132", "yyyyMMdd");
            }
        });
    }

    @Test
    void testParseDateStrictlyValid() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2008-01-05", "yyyy-MM-dd");
        assertDateEquals(2008, Calendar.JANUARY, 5, 0, 0, 0, 0, parsed);
    }

    @Test
    void testParseDateStrictlyNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly((String) null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2008-01-05", (String[]) null);
            }
        });
    }

    // ------------------------------------------------------------------ set*

    @Test
    void testSetDaysValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 15, 10, 0, 0, 0, DateUtils.setDays(date, 15));
    }

    @Test
    void testSetDaysInvalidForMonthThrows() {
        final Date feb1 = newDate(2023, Calendar.FEBRUARY, 1, 0, 0, 0, 0); // 2023 is not a leap year
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(feb1, 30);
            }
        });
    }

    @Test
    void testSetDaysZeroThrows() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(date, 0);
            }
        });
    }

    @Test
    void testSetDaysNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(null, 1);
            }
        });
    }

    @Test
    void testSetHoursValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 1, 23, 0, 0, 0, DateUtils.setHours(date, 23));
    }

    @Test
    void testSetHoursOutOfRangeThrows() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(date, 24);
            }
        });
    }

    @Test
    void testSetHoursNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(null, 1);
            }
        });
    }

    @Test
    void testSetMinutesValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 1, 10, 59, 0, 0, DateUtils.setMinutes(date, 59));
    }

    @Test
    void testSetMinutesOutOfRangeThrows() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(date, 60);
            }
        });
    }

    @Test
    void testSetSecondsValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 1, 10, 0, 59, 0, DateUtils.setSeconds(date, 59));
    }

    @Test
    void testSetSecondsOutOfRangeThrows() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(date, 60);
            }
        });
    }

    @Test
    void testSetMillisecondsValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.JANUARY, 1, 10, 0, 0, 999, DateUtils.setMilliseconds(date, 999));
    }

    @Test
    void testSetMillisecondsOutOfRangeThrows() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(date, 1000);
            }
        });
    }

    @Test
    void testSetMonthsValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(2022, Calendar.DECEMBER, 1, 10, 0, 0, 0, DateUtils.setMonths(date, Calendar.DECEMBER));
    }

    @Test
    void testSetMonthsOutOfRangeThrows() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(date, 12);
            }
        });
    }

    @Test
    void testSetYearsValid() {
        final Date date = newDate(2022, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertDateEquals(1999, Calendar.JANUARY, 1, 10, 0, 0, 0, DateUtils.setYears(date, 1999));
    }

    @Test
    void testSetYearsNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setYears(null, 1999);
            }
        });
    }

    // -------------------------------------------------------------- toCalendar

    @Test
    void testToCalendar() {
        final Date date = new Date();
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date.getTime(), cal.getTimeInMillis());
    }

    @Test
    void testToCalendarNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = new Date();
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date.getTime(), cal.getTimeInMillis());
        assertEquals(tz, cal.getTimeZone());
    }

    @Test
    void testToCalendarWithTimeZoneNullThrows() {
        final Date date = new Date();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null, TimeZone.getDefault());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(date, null);
            }
        });
    }

    // -------------------------------------------------------- to*DateTime

    @Test
    void testToLocalDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final LocalDateTime expected = LocalDateTime.ofInstant(date.toInstant(), tz.toZoneId());
        assertEquals(expected, DateUtils.toLocalDateTime(date, tz));
    }

    @Test
    void testToOffsetDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final OffsetDateTime expected = OffsetDateTime.ofInstant(date.toInstant(), tz.toZoneId());
        assertEquals(expected, DateUtils.toOffsetDateTime(date, tz));
    }

    @Test
    void testToZonedDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final ZonedDateTime expected = ZonedDateTime.ofInstant(date.toInstant(), tz.toZoneId());
        assertEquals(expected, DateUtils.toZonedDateTime(date, tz));
    }

    // ------------------------------------------------------- truncatedCompareTo / truncatedEquals

    @Test
    void testTruncatedCompareToAndEquals() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 29, 6, 1, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DAY_OF_MONTH));
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DAY_OF_MONTH));
        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.DAY_OF_MONTH) < 0);
    }

    @Test
    void testTruncatedCompareToCalendarVariant() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DAY_OF_MONTH));
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DAY_OF_MONTH));
    }

    // ------------------------------------------------------------- constants

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }
}
