/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;

class ConverterAgentTest {

    @Test
    void testDefaultConverterReturnsInputUnchanged() throws Exception {
        final Object result = Converter.DEFAULT.apply("hello");
        assertEquals("hello", result);
    }

    @Test
    void testDefaultConverterWithEmptyString() throws Exception {
        final Object result = Converter.DEFAULT.apply("");
        assertEquals("", result);
    }

    @Test
    void testClassConverterFindsClass() throws Exception {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    void testClassConverterThrowsForUnknownClass() {
        final ClassNotFoundException e = assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.Class");
            }
        });
        assertNotNull(e);
    }

    @Test
    void testFileConverterCreatesFile() throws Exception {
        final File file = Converter.FILE.apply("test.txt");
        assertEquals("test.txt", file.getName());
    }

    @Test
    void testFileConverterThrowsOnNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathConverterCreatesPath() throws Exception {
        final Path path = Converter.PATH.apply("foo/bar");
        assertEquals("foo/bar", path.toString().replace('\\', '/'));
    }

    @Test
    void testPathConverterThrowsOnInvalidPath() {
        final String invalid = "\u0000invalid";
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply(invalid);
            }
        });
    }

    @Test
    void testNumberConverterParsesLongWithoutDecimalPoint() throws Exception {
        final Number number = Converter.NUMBER.apply("42");
        assertTrue(number instanceof Long);
        assertEquals(42L, number.longValue());
    }

    @Test
    void testNumberConverterParsesDoubleWithDecimalPoint() throws Exception {
        final Number number = Converter.NUMBER.apply("3.14");
        assertTrue(number instanceof Double);
        assertEquals(3.14d, number.doubleValue(), 0.0001d);
    }

    @Test
    void testNumberConverterThrowsOnGarbage() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testObjectConverterCreatesInstance() throws Exception {
        final Object obj = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(obj);
        assertEquals(Object.class, obj.getClass());
    }

    @Test
    void testObjectConverterThrowsForUnknownClass() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.Class");
            }
        });
    }

    @Test
    void testUrlConverterCreatesUrl() throws Exception {
        final URL url = Converter.URL.apply("https://example.com");
        assertEquals("https://example.com", url.toString());
    }

    @Test
    void testUrlConverterThrowsOnMalformedUrl() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    void testDateConverterParsesValidDate() throws Exception {
        final Date date = Converter.DATE.apply("Wed Apr 04 00:00:00 GMT 2018");
        assertNotNull(date);
    }

    @Test
    void testDateConverterThrowsOnInvalidDayOfMonth() {
        // February 30th does not exist; lenient parsing is disabled so this must fail.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Fri Feb 30 00:00:00 GMT 2018");
            }
        });
    }

    @Test
    void testDateConverterThrowsOnTrailingGarbage() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Wed Apr 04 00:00:00 GMT 2018 garbage");
            }
        });
    }

    @Test
    void testDateConverterThrowsOnEmptyString() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("");
            }
        });
    }

    @Test
    void testCustomConverterImplementation() throws Exception {
        final Converter<Integer, RuntimeException> lengthConverter = new Converter<Integer, RuntimeException>() {
            @Override
            public Integer apply(final String string) {
                return string.length();
            }
        };
        assertEquals(5, lengthConverter.apply("hello").intValue());
    }

    @Test
    void testCustomConverterPropagatesCheckedException() {
        final Converter<String, ParseException> failing = new Converter<String, ParseException>() {
            @Override
            public String apply(final String string) throws ParseException {
                throw new ParseException("boom", 0);
            }
        };
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                failing.apply("x");
            }
        });
        assertEquals("boom", e.getMessage());
    }
}
