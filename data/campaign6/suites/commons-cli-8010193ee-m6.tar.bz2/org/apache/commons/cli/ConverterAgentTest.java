/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.junit.jupiter.api.Test;

public class ConverterAgentTest {

    @Test
    public void testDefaultConverterIsIdentity() {
        assertEquals("hello", Converter.DEFAULT.apply("hello"));
        assertEquals("", Converter.DEFAULT.apply(""));
        assertNull(Converter.DEFAULT.apply(null));
    }

    @Test
    public void testClassConverterHappyPath() throws ClassNotFoundException {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    public void testClassConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("does.not.Exist");
            }
        });
    }

    @Test
    public void testFileConverterHappyPath() {
        final File file = Converter.FILE.apply("foo.txt");
        assertEquals(new File("foo.txt"), file);
        assertEquals("foo.txt", file.getName());
    }

    @Test
    public void testFileConverterNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    public void testPathConverterHappyPath() {
        final Path path = Converter.PATH.apply("foo/bar");
        assertEquals(java.nio.file.Paths.get("foo/bar"), path);
    }

    @Test
    public void testPathConverterInvalidPathThrows() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("foo\u0000bar");
            }
        });
    }

    @Test
    public void testNumberConverterIntegerLikeReturnsLong() {
        final Number number = Converter.NUMBER.apply("123");
        assertTrue(number instanceof Long);
        assertEquals(123L, number.longValue());
    }

    @Test
    public void testNumberConverterDecimalReturnsDouble() {
        final Number number = Converter.NUMBER.apply("123.45");
        assertTrue(number instanceof Double);
        assertEquals(123.45d, number.doubleValue(), 0.0001d);
    }

    @Test
    public void testNumberConverterInvalidStringThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    public void testNumberConverterDotOnlyThrows() {
        // contains a '.' so it is routed to Double.valueOf(), which rejects a lone dot.
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply(".");
            }
        });
    }

    @Test
    public void testObjectConverterHappyPath() throws ReflectiveOperationException {
        final Object obj = Converter.OBJECT.apply("java.util.ArrayList");
        assertTrue(obj instanceof ArrayList);
    }

    @Test
    public void testObjectConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("does.not.Exist");
            }
        });
    }

    @Test
    public void testObjectConverterNoPublicNoArgConstructorThrows() {
        // java.lang.Math has only a private constructor, so getConstructor() finds none public.
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("java.lang.Math");
            }
        });
    }

    @Test
    public void testUrlConverterHappyPath() throws MalformedURLException {
        final URL url = Converter.URL.apply("https://example.com/path");
        assertEquals("https", url.getProtocol());
        assertEquals("example.com", url.getHost());
        assertEquals("/path", url.getPath());
    }

    @Test
    public void testUrlConverterInvalidUrlThrows() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    public void testDateConverterHappyPath() throws ParseException {
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        final Date expected = format.parse("Tue Jan 20 12:00:00 GMT 2015");
        final Date actual = Converter.DATE.apply("Tue Jan 20 12:00:00 GMT 2015");
        assertEquals(expected, actual);
    }

    @Test
    public void testDateConverterOutOfRangeFieldThrows() {
        // February never has a 30th; setLenient(false) must reject it rather than rolling over.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Mon Feb 30 12:00:00 GMT 2015");
            }
        });
    }

    @Test
    public void testDateConverterGarbageStringThrows() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date");
            }
        });
    }

    /**
     * A custom checked exception used to verify that the generic exception type parameter
     * of the functional interface is actually propagated by implementations.
     */
    private static final class CustomCheckedException extends Exception {
        private static final long serialVersionUID = 1L;

        CustomCheckedException(final String message) {
            super(message);
        }
    }

    @Test
    public void testCustomConverterImplementationPropagatesDeclaredException() {
        final Converter<Integer, CustomCheckedException> doubler = new Converter<Integer, CustomCheckedException>() {
            @Override
            public Integer apply(final String string) throws CustomCheckedException {
                if (string == null) {
                    throw new CustomCheckedException("null input");
                }
                return Integer.parseInt(string) * 2;
            }
        };

        try {
            assertEquals(Integer.valueOf(10), doubler.apply("5"));
        } catch (final CustomCheckedException e) {
            throw new AssertionError(e);
        }

        final CustomCheckedException thrown = assertThrows(CustomCheckedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                doubler.apply(null);
            }
        });
        assertEquals("null input", thrown.getMessage());
    }

    @Test
    public void testConverterIsFunctionalInterface() {
        assertTrue(Converter.class.isInterface());
        assertTrue(Converter.class.isAnnotationPresent(FunctionalInterface.class));
        assertFalse(Converter.class.isAnnotationPresent(Deprecated.class));
    }
}
