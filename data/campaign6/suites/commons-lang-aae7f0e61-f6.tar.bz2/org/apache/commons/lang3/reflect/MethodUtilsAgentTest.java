/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    private @interface Marker {
    }

    public interface PublicIface {
        void ifaceMethod();
    }

    static class PkgPrivateImpl implements PublicIface {
        @Override
        public void ifaceMethod() {
            // no-op
        }
    }

    static class BaseWithAnnotation {
        @Marker
        public void annotated() {
            // no-op
        }

        public void plain() {
            // no-op
        }
    }

    static class SubWithoutAnnotation extends BaseWithAnnotation {
        @Override
        public void annotated() {
            // no-op, annotation not repeated here
        }
    }

    static class AnnotatedHolder {
        @Marker
        public void one() {
            // no-op
        }

        @Marker
        public void two() {
            // no-op
        }

        public void three() {
            // no-op
        }
    }

    public interface Shape {
        void draw();
    }

    static class Base2 implements Shape {
        @Override
        public void draw() {
            // no-op
        }
    }

    static class Mid extends Base2 {
        @Override
        public void draw() {
            // no-op
        }
    }

    static class Leaf extends Mid {
        @Override
        public void draw() {
            // no-op
        }
    }

    static class Calculator {
        @SuppressWarnings("unused")
        int add(final int a, final int b) {
            return a + b;
        }

        @SuppressWarnings("unused")
        int compute(final Number n) {
            return n.intValue();
        }

        @SuppressWarnings("unused")
        int compute(final Integer n) {
            return n.intValue() * 10;
        }
    }

    static class Ambiguous {
        @SuppressWarnings("unused")
        public void m(final Number n) {
            // no-op
        }

        @SuppressWarnings("unused")
        public void m(final Comparable<?> c) {
            // no-op
        }
    }

    public static class Sample {
        public int noArgMethod() {
            return 42;
        }

        public int addInt(final int a, final int b) {
            return a + b;
        }

        public int addInteger(final Integer a, final Integer b) {
            return a.intValue() + b.intValue();
        }

        public String concatVarArgs(final String prefix, final String... parts) {
            final StringBuilder sb = new StringBuilder(prefix);
            for (int i = 0; i < parts.length; i++) {
                sb.append(parts[i]);
            }
            return sb.toString();
        }

        public int sumVarArgsInts(final int first, final int... rest) {
            int total = first;
            for (int i = 0; i < rest.length; i++) {
                total += rest[i];
            }
            return total;
        }

        @SuppressWarnings("unused")
        private int privateDouble(final int x) {
            return x * 2;
        }

        public static int staticAdd(final int a, final int b) {
            return a + b;
        }

        @SuppressWarnings("unused")
        private static int privateStaticValue() {
            return 99;
        }

        public int throwingMethod() {
            throw new IllegalStateException("boom");
        }
    }

    // --- getAccessibleMethod ---

    @Test
    public void testGetAccessibleMethodViaInterfaceNest() throws Exception {
        final Method declared = PkgPrivateImpl.class.getMethod("ifaceMethod");
        final Method accessible = MethodUtils.getAccessibleMethod(PkgPrivateImpl.class, declared);
        assertNotNull(accessible);
        assertEquals(PublicIface.class, accessible.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethodByNameAndParams() {
        final Method accessible = MethodUtils.getAccessibleMethod(PkgPrivateImpl.class, "ifaceMethod");
        assertNotNull(accessible);
        assertEquals(PublicIface.class, accessible.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethodNonPublicReturnsNull() throws Exception {
        final Method priv = Sample.class.getDeclaredMethod("privateDouble", int.class);
        assertNull(MethodUtils.getAccessibleMethod(Sample.class, priv));
    }

    @Test
    public void testGetAccessibleMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethodPublicClassReturnsSame() throws Exception {
        final Method m = Sample.class.getMethod("noArgMethod");
        assertEquals(m, MethodUtils.getAccessibleMethod(Sample.class, m));
    }

    // --- getMethodObject ---

    @Test
    public void testGetMethodObjectFound() {
        final Method m = MethodUtils.getMethodObject(Sample.class, "noArgMethod");
        assertNotNull(m);
        assertEquals("noArgMethod", m.getName());
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Sample.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObjectNullClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "noArgMethod"));
    }

    @Test
    public void testGetMethodObjectNullNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Sample.class, null));
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    public void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "addInt", int.class, int.class);
        assertNotNull(m);
        assertEquals("addInt", m.getName());
    }

    @Test
    public void testGetMatchingAccessibleMethodWithWrapperMatchesPrimitive() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "addInt", Integer.class, Integer.class);
        assertNotNull(m);
        assertArrayEquals(new Class<?>[] {int.class, int.class}, m.getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleMethodVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Sample.class, "sumVarArgsInts", Integer.class, Integer.class, Integer.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Sample.class, "doesNotExist", int.class));
    }

    // --- getMatchingMethod ---

    @Test
    public void testGetMatchingMethodExactDeclared() {
        final Method m = MethodUtils.getMatchingMethod(Calculator.class, "add", int.class, int.class);
        assertNotNull(m);
        assertEquals("add", m.getName());
    }

    @Test
    public void testGetMatchingMethodExactOverloadPrecedence() {
        final Method m = MethodUtils.getMatchingMethod(Calculator.class, "compute", Integer.class);
        assertNotNull(m);
        assertArrayEquals(new Class<?>[] {Integer.class}, m.getParameterTypes());
    }

    @Test
    public void testGetMatchingMethodClosestCandidate() {
        final Method m = MethodUtils.getMatchingMethod(Calculator.class, "compute", Short.class);
        assertNotNull(m);
        assertArrayEquals(new Class<?>[] {Number.class}, m.getParameterTypes());
    }

    @Test
    public void testGetMatchingMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(Calculator.class, "noSuchMethod", int.class));
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "add", int.class);
            }
        });
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrowsIllegalStateException() {
        // Integer is assignable to both Number and Comparable at equal "distance", and both
        // overloads are declared on the very same class, so the match is genuinely ambiguous.
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Ambiguous.class, "m", Integer.class);
            }
        });
    }

    // --- getAnnotation ---

    @Test
    public void testGetAnnotationDirectlyPresent() throws Exception {
        final Method m = BaseWithAnnotation.class.getMethod("annotated");
        final Marker marker = MethodUtils.getAnnotation(m, Marker.class, false, false);
        assertNotNull(marker);
    }

    @Test
    public void testGetAnnotationAbsentWithoutSearchSupers() throws Exception {
        final Method m = SubWithoutAnnotation.class.getMethod("annotated");
        final Marker marker = MethodUtils.getAnnotation(m, Marker.class, false, false);
        assertNull(marker);
    }

    @Test
    public void testGetAnnotationFoundViaSearchSupers() throws Exception {
        final Method m = SubWithoutAnnotation.class.getMethod("annotated");
        final Marker marker = MethodUtils.getAnnotation(m, Marker.class, true, false);
        assertNotNull(marker);
    }

    @Test
    public void testGetAnnotationNullMethodThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, Marker.class, true, true);
            }
        });
    }

    @Test
    public void testGetAnnotationNullAnnotationClassThrowsNPE() throws Exception {
        final Method m = BaseWithAnnotation.class.getMethod("plain");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(m, null, true, true);
            }
        });
    }

    // --- getMethodsListWithAnnotation / getMethodsWithAnnotation ---

    @Test
    public void testGetMethodsListWithAnnotation() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AnnotatedHolder.class, Marker.class);
        assertEquals(2, methods.size());
        final List<String> names = new ArrayList<String>();
        for (final Method m : methods) {
            names.add(m.getName());
        }
        assertTrue(names.contains("one"));
        assertTrue(names.contains("two"));
        assertFalse(names.contains("three"));
    }

    @Test
    public void testGetMethodsWithAnnotationArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AnnotatedHolder.class, Marker.class);
        assertEquals(2, methods.length);
    }

    @Test
    public void testGetMethodsListWithAnnotationNoneFound() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Sample.class, Marker.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotationNullClassThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, Marker.class);
            }
        });
    }

    @Test
    public void testGetMethodsListWithAnnotationNullAnnotationThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(Sample.class, (Class<? extends Annotation>) null);
            }
        });
    }

    // --- getOverrideHierarchy ---

    @Test
    public void testGetOverrideHierarchyExcludeInterfaces() throws Exception {
        final Method leafMethod = Leaf.class.getMethod("draw");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(leafMethod, Interfaces.EXCLUDE);
        final List<Class<?>> declaringClasses = new ArrayList<Class<?>>();
        final Iterator<Method> it = hierarchy.iterator();
        while (it.hasNext()) {
            declaringClasses.add(it.next().getDeclaringClass());
        }
        assertEquals(java.util.Arrays.asList(Leaf.class, Mid.class, Base2.class), declaringClasses);
    }

    @Test
    public void testGetOverrideHierarchyIncludeInterfaces() throws Exception {
        final Method leafMethod = Leaf.class.getMethod("draw");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(leafMethod, Interfaces.INCLUDE);
        final List<Class<?>> declaringClasses = new ArrayList<Class<?>>();
        final Iterator<Method> it = hierarchy.iterator();
        while (it.hasNext()) {
            declaringClasses.add(it.next().getDeclaringClass());
        }
        assertTrue(declaringClasses.contains(Shape.class));
        assertEquals(Leaf.class, declaringClasses.get(0));
    }

    @Test
    public void testGetOverrideHierarchyNullMethodThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE);
            }
        });
    }

    // --- invokeMethod ---

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "noArgMethod");
        assertEquals(Integer.valueOf(42), result);
    }

    @Test
    public void testInvokeMethodWithArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "addInt", 3, 4);
        assertEquals(Integer.valueOf(7), result);
    }

    @Test
    public void testInvokeMethodVarArgsMultiple() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "sumVarArgsInts", 1, 2, 3, 4);
        assertEquals(Integer.valueOf(10), result);
    }

    @Test
    public void testInvokeMethodVarArgsNoExtra() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "sumVarArgsInts", 5);
        assertEquals(Integer.valueOf(5), result);
    }

    @Test
    public void testInvokeMethodVarArgsStringConcat() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), "concatVarArgs", "a", "b", "c");
        assertEquals("abc", result);
    }

    @Test
    public void testInvokeMethodPrivateWithForceAccess() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Sample(), true, "privateDouble", 21);
        assertEquals(Integer.valueOf(42), result);
    }

    @Test
    public void testInvokeMethodPrivateWithoutForceAccessThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Sample(), false, "privateDouble", 21);
            }
        });
    }

    @Test
    public void testInvokeMethodNotFoundThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Sample(), "doesNotExist");
            }
        });
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "noArgMethod");
            }
        });
    }

    @Test
    public void testInvokeMethodPropagatesTargetException() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Sample(), "throwingMethod");
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    // --- invokeExactMethod ---

    @Test
    public void testInvokeExactMethodMatchesExactType() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Sample(), "addInteger", Integer.valueOf(2), Integer.valueOf(5));
        assertEquals(Integer.valueOf(7), result);
    }

    @Test
    public void testInvokeExactMethodNoWideningThrowsNoSuchMethod() {
        // addInt declares (int, int); Integer args are not an *exact* match, so invokeExactMethod must fail
        // even though invokeMethod would succeed via widening/boxing.
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new Sample(), "addInt", Integer.valueOf(2), Integer.valueOf(5));
            }
        });
    }

    // --- invokeStaticMethod / invokeExactStaticMethod ---

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Sample.class, "staticAdd", 10, 20);
        assertEquals(Integer.valueOf(30), result);
    }

    @Test
    public void testInvokeStaticMethodNotFoundThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Sample.class, "doesNotExist");
            }
        });
    }

    @Test
    public void testInvokeExactStaticMethodNoWideningThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(Sample.class, "staticAdd", Integer.valueOf(1), Integer.valueOf(2));
            }
        });
    }
}
