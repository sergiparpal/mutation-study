/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    private static void assertIllegalArgument(String str, int maxWidth) {
        try {
            StringUtils.abbreviate(str, maxWidth);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" \t\n"));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank("  abc  "));

        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    void testIsAllAnyNoneBlankEmpty() {
        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank((String[]) null));
        assertTrue(StringUtils.isAllBlank(null, " ", ""));
        assertFalse(StringUtils.isAllBlank(null, "foo"));

        assertTrue(StringUtils.isAllEmpty());
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "foo"));

        assertFalse(StringUtils.isAnyBlank((String[]) null));
        assertFalse(StringUtils.isAnyBlank());
        assertTrue(StringUtils.isAnyBlank("foo", null));
        assertTrue(StringUtils.isAnyBlank("foo", " "));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));

        assertFalse(StringUtils.isAnyEmpty((String[]) null));
        assertTrue(StringUtils.isAnyEmpty("foo", ""));
        assertFalse(StringUtils.isAnyEmpty("foo", "bar"));

        assertTrue(StringUtils.isNoneBlank());
        assertTrue(StringUtils.isNoneBlank("foo", "bar"));
        assertFalse(StringUtils.isNoneBlank("foo", null));

        assertTrue(StringUtils.isNoneEmpty());
        assertTrue(StringUtils.isNoneEmpty("foo", "bar"));
        assertFalse(StringUtils.isNoneEmpty("foo", ""));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull("  "));
        assertNull(StringUtils.trimToNull(null));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcyy", "xy"));

        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("ab c", StringUtils.stripToNull(" ab c "));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("    "));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertEquals("abc", StringUtils.stripStart("yxabc", "xy"));
        assertEquals("abc", StringUtils.stripEnd("abcxy", "xy"));

        assertArrayEquals(new String[] { "abc", "" }, StringUtils.stripAll(" abc ", "  "));
        assertArrayEquals(new String[] { "abc", "123" }, StringUtils.stripAll(new String[] { " abc ", " 123 " }));
        assertNull(StringUtils.stripAll((String[]) null));

        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
        assertNull(StringUtils.stripAccents(null));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
        assertTrue(StringUtils.equals(new StringBuilder("abc"), "abc"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abd"));

        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
        assertFalse(StringUtils.equalsAny("abc"));
        assertTrue(StringUtils.equalsAny("abc", "foo", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "foo", "bar"));
        assertTrue(StringUtils.equalsAny(null, (CharSequence) null));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "foo", "ABC"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", "foo", "bar"));
    }

    @Test
    void testCompareFamily() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertEquals(0, StringUtils.compare(null, null, true));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);

        assertEquals(0, StringUtils.compareIgnoreCase(null, null));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));

        assertEquals(0, StringUtils.compareIgnoreCase(null, null, true));
        assertTrue(StringUtils.compareIgnoreCase(null, "a", false) > 0);
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("", ""));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertFalse(StringUtils.contains(null, 'a'));
        assertFalse(StringUtils.contains("", 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase(null, "A"));

        assertFalse(StringUtils.containsAny(null, 'a'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", 'z', 'a'));
        assertFalse(StringUtils.containsAny("zzabyycdxx", 'm', 'n'));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));
        assertTrue(StringUtils.containsAny("abc", "ab", "xyz"));

        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "XYZ", "ABC"));

        assertTrue(StringUtils.containsNone(null, 'a'));
        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'x', 'a'));
        assertTrue(StringUtils.containsNone("abc", "xy"));
        assertFalse(StringUtils.containsNone("abc", "xa"));

        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertTrue(StringUtils.containsOnly("aaa", 'a'));
        assertFalse(StringUtils.containsOnly("aba", 'a'));
        assertTrue(StringUtils.containsOnly("", 'a'));
        assertTrue(StringUtils.containsOnly("abab", "ab"));

        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace("ab c"));
    }

    @Test
    void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 2));
        assertEquals(-1, StringUtils.indexOf(null, 'a'));
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', 2));

        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a', 'b'));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", 'a', 'b'));
        assertEquals(-1, StringUtils.indexOfAny("zzabyycdxx", 'm', 'n'));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new CharSequence[] { "ab", "cd" }));

        assertEquals(-1, StringUtils.indexOfAnyBut(null, 'a', 'b'));
        assertEquals(2, StringUtils.indexOfAnyBut("zzabyycdxx", 'z', 'y'));

        assertEquals(1, StringUtils.indexOfDifference("abc", "aXc"));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));

        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));
        assertEquals(5, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 3));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b", 4));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", 'b', 4));

        assertEquals(-1, StringUtils.lastIndexOfAny(null, "a"));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", "mn", "op"));

        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B"));

        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 2));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "", 2));

        assertEquals(1, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
    }

    @Test
    void testSubstringFamily() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", 1));
        assertEquals("bc", StringUtils.substring("abc", -2));

        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));

        assertEquals("bc", StringUtils.substringAfter("abc", 'a'));
        assertEquals("", StringUtils.substringAfter("abc", 'd'));
        assertNull(StringUtils.substringAfter(null, 'a'));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));

        assertEquals("", StringUtils.substringAfterLast("abc", 'c'));
        assertEquals("ba", StringUtils.substringAfterLast("abcba", 'c'));
        assertEquals("cba", StringUtils.substringAfterLast("abcbcba", "bc"));

        assertEquals("", StringUtils.substringBefore("abc", 'a'));
        assertEquals("a", StringUtils.substringBefore("abc", 'b'));
        assertEquals("abc", StringUtils.substringBefore("abc", 'd'));
        assertEquals("a", StringUtils.substringBefore("abc", "b"));

        assertEquals("a", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("abc", StringUtils.substringBeforeLast("abc", "d"));

        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));

        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertNull(StringUtils.substringBetween(null, "[", "]"));

        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[0], StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    void testSplitFamily() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] { "abc", "def" }, StringUtils.split("abc def"));
        assertArrayEquals(new String[] { "a", "b", "c" }, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] { "a:b:c" }, StringUtils.split("a:b:c", '.'));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.split("ab:cd:ef", ":", 2));

        assertArrayEquals(new String[] { "", "ab", "", "cd", "" }, StringUtils.splitPreserveAllTokens(" ab  cd ", " "));

        assertArrayEquals(new String[] { "ab", "cd", "ef" }, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] { "ab", "cd:ef" }, StringUtils.splitByWholeSeparator("ab:cd:ef", ":", 2));
        assertArrayEquals(new String[] { "", "ab", "", "cd", "" }, StringUtils.splitByWholeSeparatorPreserveAllTokens(" ab  cd ", " "));

        assertArrayEquals(new String[] { "number", "5" }, StringUtils.splitByCharacterType("number5"));
        assertArrayEquals(new String[] { "foo", "B", "ar" }, StringUtils.splitByCharacterType("fooBar"));
        assertArrayEquals(new String[] { "foo", "Bar" }, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] { "ASF", "Rules" }, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    void testJoinFamily() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a:b:c", StringUtils.join(new Object[] { "a", "b", "c" }, ':'));
        assertEquals("a:null:c", StringUtils.join(new Object[] { "a", null, "c" }, ':'));

        assertEquals("a-b-c", StringUtils.join(new Object[] { "a", "b", "c" }, "-"));
        assertEquals("b-c", StringUtils.join(new Object[] { "a", "b", "c" }, "-", 1, 3));

        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertEquals("a,b", StringUtils.join((Iterable<?>) list, ','));
        assertEquals("a,b", StringUtils.join(list.iterator(), ','));
        assertEquals("a-b", StringUtils.join(list, "-", 0, 2));

        assertEquals("1,2,3", StringUtils.join(new int[] { 1, 2, 3 }, ','));
        assertEquals("2,3", StringUtils.join(new int[] { 1, 2, 3 }, ',', 1, 3));
        assertEquals("true,false", StringUtils.join(new boolean[] { true, false }, ','));
        assertEquals("a,b", StringUtils.join(new char[] { 'a', 'b' }, ','));

        assertEquals("a-b-c", StringUtils.joinWith("-", "a", "b", "c"));
        assertEquals("a--c", StringUtils.joinWith("-", "a", null, "c"));
    }

    @Test
    void testReplaceAndRemoveFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
        assertEquals("b", StringUtils.replace("aba", "a", ""));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z", -1));
        assertEquals("zba", StringUtils.replace("aba", "a", "z", 1));

        assertEquals("foo", StringUtils.replaceIgnoreCase("fOo", "O", "o", -1));
        assertEquals("zbz", StringUtils.replaceIgnoreCase("aba", "A", "z"));
        assertEquals("zbz", StringUtils.replaceIgnoreCase("aBa", "a", "z"));

        assertEquals("zbz", StringUtils.replaceOnce("zbz", "x", "y"));
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
        assertEquals("zba", StringUtils.replaceOnceIgnoreCase("Aba", "a", "z"));

        assertEquals("ABC123", StringUtils.removeAll("ABCabc123abc", "[a-z]"));
        assertEquals("abab", StringUtils.remove("abcabc", "c"));
        assertEquals("abab", StringUtils.remove("abcabc", 'c'));
        assertEquals("abcabc", StringUtils.remove("abcabc", "x"));
        assertNull(StringUtils.remove((String) null, "c"));
        assertEquals("qd", StringUtils.removeIgnoreCase("quEUed", "UE"));

        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com.", "."));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));

        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("WWW.domain.com", "www."));
        assertEquals("path", StringUtils.removeStart("/path", '/'));

        assertEquals("trfieef", StringUtils.replaceEach("tzrzfzizezezf", new String[] { "z" }, new String[] { "" }));
        assertEquals("wcte", StringUtils.replaceEachRepeatedly("abcde", new String[] { "ab", "d" }, new String[] { "w", "t" }));
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] { "ab", "d" }, new String[] { "d", "t" }));

        assertEquals("ABB", StringUtils.replaceChars("ABA", "A", "B"));
        assertEquals("belly", StringUtils.replaceChars("hello", "ho", "by"));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", ""));
    }

    @Test
    void testRemoveRegexFamily() {
        assertEquals("AB", StringUtils.removeAll("A<__>\n<__>B", "(?s)<.*>"));
        assertEquals("A\nB", StringUtils.removeAll("A<__>\n<__>B", "<.*>"));
        assertEquals("ABCbc123", StringUtils.removeFirst("ABCabc123", "[a-z]"));
        assertEquals("AB", StringUtils.removePattern("A<__>\n<__>B", "<.*>"));
        assertEquals("ABC123", StringUtils.removePattern("ABCabc123", "[a-z]"));
        assertEquals("z", StringUtils.replacePattern("<__>\n<__>", "<.*>", "z"));
        assertEquals("ABC_123", StringUtils.replacePattern("ABCabc123", "[^A-Z0-9]+", "_"));
    }

    @Test
    void testCaseFamily() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("cAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));

        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("aBc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ENGLISH));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ENGLISH));

        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    @Test
    void testPaddingFamily() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", 1));
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
        assertEquals("xyxybat", StringUtils.leftPad("bat", 7, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
        assertEquals("batxyx", StringUtils.rightPad("bat", 6, "xy"));

        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
        assertEquals("  abc  ", StringUtils.center("abc", 7, (String) null));
    }

    @Test
    void testAbbreviateFamily() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertIllegalArgument("abcdefg", 3);

        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 0, 10));
        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 8, 10));

        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", (String) null, 10));

        assertEquals("::efghij::", StringUtils.abbreviate("abcdefghijklmno", "::", 4, 10));
        assertEquals("*ghijklmno", StringUtils.abbreviate("abcdefghijklmno", "*", 9, 10));

        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc ", StringUtils.chomp("abc \r"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
        assertEquals("", StringUtils.chomp("\r\n"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(2, StringUtils.countMatches("abbccabc", 'a'));
        assertEquals(0, StringUtils.countMatches("abbccabc", 'z'));

        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
    }

    @Test
    void testDefaultsAndFirstNon() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));

        assertNull(StringUtils.firstNonBlank());
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("abc", StringUtils.firstNonBlank(null, "abc"));

        assertNull(StringUtils.firstNonEmpty());
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
    }

    @Test
    void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b  c  "));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c "));
    }

    @Test
    void testDifferenceAndCommonPrefixAndDigits() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));

        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("ab", StringUtils.getCommonPrefix("ab", "abxyz"));
        assertEquals("", StringUtils.getCommonPrefix("abcde", "xyz"));

        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1000", StringUtils.getDigits("1000$"));
        assertEquals("5417543010", StringUtils.getDigits("(541) 754-3010"));
    }

    @Test
    void testDistanceMetrics() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
        try {
            StringUtils.getLevenshteinDistance(null, "a");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        assertEquals(0.0, StringUtils.getJaroWinklerDistance("", ""), 0.0001);
        assertEquals(0.93, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.0001);
        try {
            StringUtils.getJaroWinklerDistance(null, "a");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(0, StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH));
        assertEquals(3, StringUtils.getFuzzyDistance("Apache Software Foundation", "asf", Locale.ENGLISH));
        try {
            StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testCharacterTypeChecks() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));

        assertFalse(StringUtils.isAlphanumericSpace(null));
        assertTrue(StringUtils.isAlphanumericSpace("ab c"));

        assertFalse(StringUtils.isAlphaSpace(null));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2c"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isNumericSpace(null));
        assertTrue(StringUtils.isNumericSpace(""));
        assertTrue(StringUtils.isNumericSpace("12 3"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  "));
        assertFalse(StringUtils.isWhitespace("ab"));

        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable("abc "));
        assertFalse(StringUtils.isAsciiPrintable("ab\u0000c"));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("aBC"));

        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    @Test
    void testLeftRightMidLength() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("abc", StringUtils.left("abc", 4));
        assertEquals("ab", StringUtils.left("abc", 2));

        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("", StringUtils.mid("abc", 4, 2));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));

        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testAppendPrependIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, null));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", StringUtils.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));

        assertNull(StringUtils.prependIfMissing(null, null));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }

    @Test
    void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    void testRepeatReverseRotate() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("zzz", StringUtils.repeat('z', 3));
        assertEquals("", StringUtils.repeat('z', -1));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));

        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));

        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
    }

    @Test
    void testStartsEndsWithFamily() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "qqq"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertTrue(StringUtils.endsWith(null, null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));

        assertTrue(StringUtils.endsWithAny("abcxyz", "mno", "xyz"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 0));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 7));
        try {
            StringUtils.truncate("abcdefg", -1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));
        try {
            StringUtils.truncate("abcdefghij", -2, 4);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            StringUtils.truncate("abcdefghij", 3, -1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testWrapUnwrap() {
        assertNull(StringUtils.unwrap(null, 'a'));
        assertEquals("a", StringUtils.unwrap("a", 'a'));
        assertEquals("", StringUtils.unwrap("aa", 'a'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("A", StringUtils.unwrap("A", '#'));

        assertNull(StringUtils.unwrap(null, "a"));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", "\""));
        assertEquals("BabcB", StringUtils.unwrap("AABabcBAA", "AA"));

        assertNull(StringUtils.wrap(null, "x"));
        assertEquals("", StringUtils.wrap("", "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", "\""));

        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", 'x'));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", '\"'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));

        assertNull(StringUtils.wrapIfMissing(null, "x"));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", "x"));
        assertEquals("'abcd'", StringUtils.wrapIfMissing("'abcd'", "'"));
    }

    @Test
    void testValueOfAndCodePointsAndBytes() {
        assertNull(StringUtils.valueOf((char[]) null));
        assertEquals("abc", StringUtils.valueOf(new char[] { 'a', 'b', 'c' }));

        assertArrayEquals(new int[] { 'a', 'b', 'c' }, StringUtils.toCodePoints("abc"));

        final byte[] bytes = StringUtils.getBytes("abc", java.nio.charset.StandardCharsets.UTF_8);
        assertArrayEquals(new byte[] { 'a', 'b', 'c' }, bytes);
    }

    @Test
    void testGetIfBlankGetIfEmpty() {
        assertEquals("NULL", StringUtils.getIfBlank("", new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "NULL";
            }
        }));
        assertEquals("bat", StringUtils.getIfBlank("bat", new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "NULL";
            }
        }));
        assertEquals(" ", StringUtils.getIfEmpty(" ", new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "NULL";
            }
        }));
    }

    @Test
    void testIdentitySameInstanceWhenUnchanged() {
        final String s = "Already";
        assertSame(s, StringUtils.capitalize(s));

        final String noWhitespace = "abc";
        assertSame(noWhitespace, StringUtils.deleteWhitespace(noWhitespace));
    }
}
