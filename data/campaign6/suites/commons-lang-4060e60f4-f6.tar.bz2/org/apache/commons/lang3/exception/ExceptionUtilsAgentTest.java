/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExceptionUtils}.
 */
class ExceptionUtilsAgentTest {

    /** Checked exception that exposes its wrapped cause only through a legacy accessor method. */
    static final class LegacyWrapperException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable target;

        LegacyWrapperException(final String message, final Throwable target) {
            super(message);
            this.target = target;
        }

        public Throwable getTargetException() {
            return target;
        }
    }

    /** Checked exception that exposes its wrapped cause through a custom-named accessor method. */
    static final class CustomNamedCauseException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable wrapped;

        CustomNamedCauseException(final String message, final Throwable wrapped) {
            super(message);
            this.wrapped = wrapped;
        }

        public Throwable getWrapped() {
            return wrapped;
        }
    }

    // --- asRuntimeException -------------------------------------------------

    @Test
    void testAsRuntimeExceptionPreservesCheckedTypeAndMessage() {
        final IOException original = new IOException("boom");
        final Throwable caught = assertThrows(Throwable.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                throw ExceptionUtils.<RuntimeException>asRuntimeException(original);
            }
        });
        assertSame(original, caught);
        assertTrue(caught instanceof IOException);
        assertFalse(caught instanceof RuntimeException);
        assertEquals("boom", caught.getMessage());
    }

    // --- getCause / getCause(methodNames) / getDefaultCauseMethodNames -----

    @Test
    void testGetCauseNull() {
        assertNull(ExceptionUtils.getCause(null));
    }

    @Test
    void testGetCauseUsesRealCauseFirst() {
        final Throwable cause = new IllegalStateException("cause");
        final Throwable wrapper = new RuntimeException("wrapper", cause);
        assertSame(cause, ExceptionUtils.getCause(wrapper));
    }

    @Test
    void testGetCauseFallsBackToReflection() {
        final Throwable target = new IllegalArgumentException("target");
        final LegacyWrapperException ex = new LegacyWrapperException("msg", target);
        assertNull(ex.getCause());
        assertSame(target, ExceptionUtils.getCause(ex));
    }

    @Test
    void testGetCauseWithMethodNamesIgnoresRealCause() {
        final Throwable realCause = new IllegalStateException("real");
        final Throwable wrapped = new IllegalArgumentException("wrapped");
        final CustomNamedCauseException ex = new CustomNamedCauseException("msg", wrapped);
        ex.initCause(realCause);
        assertSame(realCause, ex.getCause());
        assertSame(wrapped, ExceptionUtils.getCause(ex, new String[] {"getWrapped"}));
    }

    @Test
    void testGetCauseWithMethodNamesIgnoresNullEntries() {
        final Throwable wrapped = new IllegalArgumentException("wrapped");
        final CustomNamedCauseException ex = new CustomNamedCauseException("msg", wrapped);
        assertSame(wrapped, ExceptionUtils.getCause(ex, new String[] {null, "getWrapped"}));
    }

    @Test
    void testGetCauseWithUnknownMethodNamesReturnsNull() {
        final CustomNamedCauseException ex = new CustomNamedCauseException("msg", new IllegalArgumentException());
        assertNull(ExceptionUtils.getCause(ex, new String[] {"noSuchMethod"}));
    }

    @Test
    void testGetDefaultCauseMethodNames() {
        final String[] expected = {
            "getCause", "getNextException", "getTargetException", "getException", "getSourceException",
            "getRootCause", "getCausedByException", "getNested", "getLinkedException", "getNestedException",
            "getLinkedCause", "getThrowable"
        };
        assertArrayEquals(expected, ExceptionUtils.getDefaultCauseMethodNames());
    }

    @Test
    void testGetDefaultCauseMethodNamesReturnsClone() {
        final String[] first = ExceptionUtils.getDefaultCauseMethodNames();
        first[0] = "mutated";
        final String[] second = ExceptionUtils.getDefaultCauseMethodNames();
        assertEquals("getCause", second[0]);
    }

    // --- getMessage ----------------------------------------------------------

    @Test
    void testGetMessageNull() {
        assertEquals("", ExceptionUtils.getMessage(null));
    }

    @Test
    void testGetMessageWithMessage() {
        assertEquals("IllegalStateException: boom", ExceptionUtils.getMessage(new IllegalStateException("boom")));
    }

    @Test
    void testGetMessageWithoutMessage() {
        assertEquals("IllegalStateException: ", ExceptionUtils.getMessage(new IllegalStateException()));
    }

    // --- getRootCause / getRootCauseMessage ----------------------------------

    @Test
    void testGetRootCauseNull() {
        assertNull(ExceptionUtils.getRootCause(null));
    }

    @Test
    void testGetRootCauseNoCauseReturnsSelf() {
        final Throwable only = new RuntimeException("only");
        assertSame(only, ExceptionUtils.getRootCause(only));
    }

    @Test
    void testGetRootCauseWalksChain() {
        final Throwable root = new IllegalStateException("root");
        final Throwable middle = new IllegalArgumentException("middle", root);
        final Throwable outer = new RuntimeException("outer", middle);
        assertSame(root, ExceptionUtils.getRootCause(outer));
    }

    @Test
    void testGetRootCauseHandlesCycle() {
        final Throwable a = new Throwable("a");
        final Throwable b = new Throwable("b");
        a.initCause(b);
        b.initCause(a);
        assertSame(b, ExceptionUtils.getRootCause(a));
    }

    @Test
    void testGetRootCauseMessageNull() {
        assertEquals("", ExceptionUtils.getRootCauseMessage(null));
    }

    @Test
    void testGetRootCauseMessageUsesRootCause() {
        final Throwable root = new IllegalStateException("root");
        final Throwable outer = new RuntimeException("outer", root);
        assertEquals(ExceptionUtils.getMessage(root), ExceptionUtils.getRootCauseMessage(outer));
    }

    // --- getRootCauseStackTrace / getRootCauseStackTraceList -----------------

    @Test
    void testGetRootCauseStackTraceNull() {
        assertEquals(0, ExceptionUtils.getRootCauseStackTrace(null).length);
        assertTrue(ExceptionUtils.getRootCauseStackTraceList(null).isEmpty());
    }

    @Test
    void testGetRootCauseStackTraceStructure() {
        Throwable rootCause = null;
        Throwable wrapper = null;
        try {
            try {
                throw new IllegalStateException("root");
            } catch (final IllegalStateException e) {
                rootCause = e;
                throw new RuntimeException("wrapper", e);
            }
        } catch (final RuntimeException e) {
            wrapper = e;
        }
        final List<String> frames = ExceptionUtils.getRootCauseStackTraceList(wrapper);
        assertFalse(frames.isEmpty());
        assertEquals(rootCause.toString(), frames.get(0));
        assertTrue(frames.contains(ExceptionUtils.WRAPPED_MARKER + wrapper.toString()));
        boolean sawFrame = false;
        for (final String frame : frames) {
            if (frame.startsWith("\tat ")) {
                sawFrame = true;
                break;
            }
        }
        assertTrue(sawFrame, "expected at least one real stack frame line");
    }

    // --- getStackFrameList (package-private) ----------------------------------

    @Test
    void testGetStackFrameListNoCause() {
        final Throwable t = new RuntimeException("boom");
        final List<String> frames = ExceptionUtils.getStackFrameList(t);
        assertFalse(frames.isEmpty());
        for (final String frame : frames) {
            assertTrue(frame.trim().startsWith("at "), "unexpected non-frame line: " + frame);
        }
    }

    @Test
    void testGetStackFrameListStopsBeforeCausedBy() {
        final Throwable cause = new IllegalStateException("cause");
        final Throwable outer = new RuntimeException("outer", cause);
        final List<String> frames = ExceptionUtils.getStackFrameList(outer);
        for (final String frame : frames) {
            assertFalse(frame.contains("Caused by"), "cause frames leaked into outer frame list: " + frame);
        }
    }

    // --- getStackFrames(String) / getStackFrames(Throwable) --------------------

    @Test
    void testGetStackFramesFromStringSplitsOnLineSeparator() {
        final String sep = System.lineSeparator();
        final String combined = "a" + sep + "b" + sep + "c";
        assertArrayEquals(new String[] {"a", "b", "c"}, ExceptionUtils.getStackFrames(combined));
    }

    @Test
    void testGetStackFramesFromEmptyString() {
        assertEquals(0, ExceptionUtils.getStackFrames("").length);
    }

    @Test
    void testGetStackFramesFromNullThrowable() {
        assertEquals(0, ExceptionUtils.getStackFrames((Throwable) null).length);
    }

    @Test
    void testGetStackFramesFromThrowable() {
        final Throwable t = new RuntimeException("boom");
        final String[] frames = ExceptionUtils.getStackFrames(t);
        assertTrue(frames.length > 1);
        assertEquals(t.toString(), frames[0]);
    }

    // --- getStackTrace ---------------------------------------------------------

    @Test
    void testGetStackTraceNull() {
        assertEquals("", ExceptionUtils.getStackTrace(null));
    }

    @Test
    void testGetStackTraceStartsWithToString() {
        final Throwable t = new RuntimeException("boom");
        final String trace = ExceptionUtils.getStackTrace(t);
        assertTrue(trace.startsWith(t.toString()));
        assertTrue(trace.contains("\tat "));
    }

    @Test
    void testGetStackTraceIncludesSuppressed() {
        final Throwable main = new RuntimeException("main");
        final Throwable suppressed = new IllegalStateException("suppressed1");
        main.addSuppressed(suppressed);
        final String trace = ExceptionUtils.getStackTrace(main);
        assertTrue(trace.contains("Suppressed:"));
        assertTrue(trace.contains(suppressed.toString()));
    }

    // --- getThrowableCount / getThrowableList / getThrowables ------------------

    @Test
    void testGetThrowableCountNull() {
        assertEquals(0, ExceptionUtils.getThrowableCount(null));
    }

    @Test
    void testGetThrowableCountChain() {
        final Throwable root = new IllegalStateException("root");
        final Throwable middle = new IllegalArgumentException("middle", root);
        final Throwable outer = new RuntimeException("outer", middle);
        assertEquals(3, ExceptionUtils.getThrowableCount(outer));
    }

    @Test
    void testGetThrowableCountHandlesCycle() {
        final Throwable a = new Throwable("a");
        final Throwable b = new Throwable("b");
        a.initCause(b);
        b.initCause(a);
        assertEquals(2, ExceptionUtils.getThrowableCount(a));
    }

    @Test
    void testGetThrowableListNullReturnsEmptyNotNull() {
        final List<Throwable> list = ExceptionUtils.getThrowableList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testGetThrowableListOrder() {
        final Throwable root = new IllegalStateException("root");
        final Throwable outer = new RuntimeException("outer", root);
        final List<Throwable> list = ExceptionUtils.getThrowableList(outer);
        assertEquals(2, list.size());
        assertSame(outer, list.get(0));
        assertSame(root, list.get(1));
    }

    @Test
    void testGetThrowablesArrayNull() {
        final Throwable[] array = ExceptionUtils.getThrowables(null);
        assertNotNull(array);
        assertEquals(0, array.length);
    }

    @Test
    void testGetThrowablesArrayMatchesList() {
        final Throwable root = new IllegalStateException("root");
        final Throwable outer = new RuntimeException("outer", root);
        final Throwable[] array = ExceptionUtils.getThrowables(outer);
        assertEquals(2, array.length);
        assertSame(outer, array[0]);
        assertSame(root, array[1]);
    }

    // --- hasCause ----------------------------------------------------------------

    @Test
    void testHasCauseDirectInstance() {
        final RuntimeException e = new RuntimeException("x");
        assertTrue(ExceptionUtils.hasCause(e, RuntimeException.class));
        assertFalse(ExceptionUtils.hasCause(e, IllegalStateException.class));
    }

    @Test
    void testHasCauseUnwrapsUndeclaredThrowableException() {
        final IOException checked = new IOException("checked");
        final UndeclaredThrowableException ute = new UndeclaredThrowableException(checked);
        assertTrue(ExceptionUtils.hasCause(ute, IOException.class));
        assertFalse(ExceptionUtils.hasCause(ute, IllegalStateException.class));
    }

    @Test
    void testHasCauseNullChain() {
        assertFalse(ExceptionUtils.hasCause(null, RuntimeException.class));
    }

    @Test
    void testHasCauseNullTypeThrowsNpe() {
        final RuntimeException e = new RuntimeException("x");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.hasCause(e, null);
            }
        });
    }

    // --- indexOfThrowable / indexOfType -------------------------------------------

    @Test
    void testIndexOfThrowableNullInputs() {
        final Throwable outer = new RuntimeException("outer");
        assertEquals(-1, ExceptionUtils.indexOfThrowable(null, RuntimeException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(outer, null));
    }

    @Test
    void testIndexOfThrowableExactClassOnly() {
        final Throwable inner = new NumberFormatException("inner");
        final Throwable outer = new RuntimeException("outer", inner);
        assertEquals(0, ExceptionUtils.indexOfThrowable(outer, RuntimeException.class));
        assertEquals(1, ExceptionUtils.indexOfThrowable(outer, NumberFormatException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(outer, IllegalArgumentException.class));
    }

    @Test
    void testIndexOfTypeMatchesSubclasses() {
        final Throwable inner = new NumberFormatException("inner");
        final Throwable outer = new RuntimeException("outer", inner);
        assertEquals(1, ExceptionUtils.indexOfType(outer, IllegalArgumentException.class));
    }

    @Test
    void testIndexOfThrowableFromIndexBoundaries() {
        final Throwable inner = new NumberFormatException("inner");
        final Throwable outer = new RuntimeException("outer", inner);
        assertEquals(1, ExceptionUtils.indexOfThrowable(outer, NumberFormatException.class, -5));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(outer, NumberFormatException.class, 2));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(outer, NumberFormatException.class, 10));
    }

    // --- isChecked / isUnchecked --------------------------------------------------

    @Test
    void testIsCheckedAndUncheckedNull() {
        assertFalse(ExceptionUtils.isChecked(null));
        assertFalse(ExceptionUtils.isUnchecked(null));
    }

    @Test
    void testIsCheckedForCheckedException() {
        final Throwable checked = new IOException("io");
        assertTrue(ExceptionUtils.isChecked(checked));
        assertFalse(ExceptionUtils.isUnchecked(checked));
    }

    @Test
    void testIsUncheckedForRuntimeExceptionAndError() {
        assertTrue(ExceptionUtils.isUnchecked(new RuntimeException("r")));
        assertFalse(ExceptionUtils.isChecked(new RuntimeException("r")));
        assertTrue(ExceptionUtils.isUnchecked(new OutOfMemoryError("e")));
        assertFalse(ExceptionUtils.isChecked(new OutOfMemoryError("e")));
    }

    // --- printRootCauseStackTrace -------------------------------------------------

    @Test
    void testPrintRootCauseStackTraceToSystemErr() {
        final PrintStream original = System.err;
        final ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setErr(new PrintStream(captured));
        try {
            final Throwable t = new RuntimeException("boom");
            ExceptionUtils.printRootCauseStackTrace(t);
        } finally {
            System.setErr(original);
        }
        assertTrue(captured.toString().contains("RuntimeException: boom"));
    }

    @Test
    void testPrintRootCauseStackTraceNullThrowableIsNoop() {
        final PrintStream original = System.err;
        final ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setErr(new PrintStream(captured));
        try {
            ExceptionUtils.printRootCauseStackTrace(null);
        } finally {
            System.setErr(original);
        }
        assertEquals(0, captured.toByteArray().length);
    }

    @Test
    void testPrintRootCauseStackTracePrintStreamWritesExpectedContent() {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final Throwable t = new RuntimeException("boom");
        ExceptionUtils.printRootCauseStackTrace(t, new PrintStream(out));
        final String printed = out.toString();
        assertTrue(printed.contains(t.toString()));
    }

    @Test
    void testPrintRootCauseStackTracePrintStreamNullWithNonNullThrowableThrowsNpe() {
        final Throwable t = new RuntimeException("boom");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(t, (PrintStream) null);
            }
        });
    }

    @Test
    void testPrintRootCauseStackTracePrintStreamNullThrowableAndNullStreamIsNoop() {
        ExceptionUtils.printRootCauseStackTrace(null, (PrintStream) null);
    }

    @Test
    void testPrintRootCauseStackTracePrintWriterWritesExpectedContent() {
        final StringWriter sw = new StringWriter();
        final Throwable t = new RuntimeException("boom");
        ExceptionUtils.printRootCauseStackTrace(t, new PrintWriter(sw));
        assertTrue(sw.toString().contains(t.toString()));
    }

    @Test
    void testPrintRootCauseStackTracePrintWriterNullWithNonNullThrowableThrowsNpe() {
        final Throwable t = new RuntimeException("boom");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(t, (PrintWriter) null);
            }
        });
    }

    // --- removeCommonFrames ---------------------------------------------------------

    @Test
    void testRemoveCommonFramesNullArguments() {
        final List<String> empty = new ArrayList<>();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(null, empty);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(empty, null);
            }
        });
    }

    @Test
    void testRemoveCommonFramesStripsSharedSuffix() {
        final List<String> causeFrames = new ArrayList<>();
        causeFrames.add("f1");
        causeFrames.add("f2");
        causeFrames.add("f3");
        final List<String> wrapperFrames = new ArrayList<>();
        wrapperFrames.add("g1");
        wrapperFrames.add("f2");
        wrapperFrames.add("f3");
        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);
        assertEquals(1, causeFrames.size());
        assertEquals("f1", causeFrames.get(0));
    }

    @Test
    void testRemoveCommonFramesNoSharedFramesLeavesListUnchanged() {
        final List<String> causeFrames = new ArrayList<>();
        causeFrames.add("a1");
        causeFrames.add("a2");
        final List<String> wrapperFrames = new ArrayList<>();
        wrapperFrames.add("b1");
        wrapperFrames.add("b2");
        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);
        assertEquals(2, causeFrames.size());
    }

    // --- rethrow -----------------------------------------------------------------------

    @Test
    void testRethrowPreservesCheckedTypeAndMessage() {
        final IOException original = new IOException("boom");
        final Throwable caught = assertThrows(Throwable.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                throw ExceptionUtils.<RuntimeException>rethrow(original);
            }
        });
        assertSame(original, caught);
        assertFalse(caught instanceof RuntimeException);
    }

    // --- stream / forEach ----------------------------------------------------------------

    @Test
    void testStreamNullIsEmpty() {
        assertEquals(0, ExceptionUtils.stream(null).count());
    }

    @Test
    void testStreamMatchesThrowableList() {
        final Throwable root = new IllegalStateException("root");
        final Throwable outer = new RuntimeException("outer", root);
        final List<Throwable> collected = ExceptionUtils.stream(outer).collect(java.util.stream.Collectors.<Throwable>toList());
        assertEquals(ExceptionUtils.getThrowableList(outer), collected);
    }

    @Test
    void testForEachVisitsEachThrowableInOrder() {
        final Throwable root = new IllegalStateException("root");
        final Throwable outer = new RuntimeException("outer", root);
        final List<Throwable> visited = new ArrayList<>();
        ExceptionUtils.forEach(outer, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable throwable) {
                visited.add(throwable);
            }
        });
        assertEquals(2, visited.size());
        assertSame(outer, visited.get(0));
        assertSame(root, visited.get(1));
    }

    @Test
    void testForEachNullThrowableNeverInvokesConsumer() {
        final List<Throwable> visited = new ArrayList<>();
        ExceptionUtils.forEach(null, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable throwable) {
                visited.add(throwable);
            }
        });
        assertTrue(visited.isEmpty());
    }

    // --- throwableOfThrowable / throwableOfType -----------------------------------------

    @Test
    void testThrowableOfThrowableExactClassOnly() {
        final Throwable inner = new NumberFormatException("inner");
        final Throwable outer = new RuntimeException("outer", inner);
        assertSame(inner, ExceptionUtils.throwableOfThrowable(outer, NumberFormatException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(outer, IllegalArgumentException.class));
    }

    @Test
    void testThrowableOfTypeMatchesSubclass() {
        final Throwable inner = new NumberFormatException("inner");
        final Throwable outer = new RuntimeException("outer", inner);
        assertSame(inner, ExceptionUtils.throwableOfType(outer, IllegalArgumentException.class));
    }

    @Test
    void testThrowableOfThrowableNullInputs() {
        final Throwable outer = new RuntimeException("outer");
        assertNull(ExceptionUtils.throwableOfThrowable(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(outer, null));
    }

    @Test
    void testThrowableOfThrowableFromIndexBoundaries() {
        final Throwable inner = new NumberFormatException("inner");
        final Throwable outer = new RuntimeException("outer", inner);
        assertSame(inner, ExceptionUtils.throwableOfThrowable(outer, NumberFormatException.class, -5));
        assertNull(ExceptionUtils.throwableOfThrowable(outer, NumberFormatException.class, 2));
        assertNull(ExceptionUtils.throwableOfThrowable(outer, NumberFormatException.class, 10));
    }

    // --- throwUnchecked ---------------------------------------------------------------------

    @Test
    void testThrowUncheckedRethrowsRuntimeException() {
        final RuntimeException original = new IllegalStateException("boom");
        final Throwable caught = assertThrows(Throwable.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.throwUnchecked(original);
            }
        });
        assertSame(original, caught);
    }

    @Test
    void testThrowUncheckedRethrowsError() {
        final Error original = new OutOfMemoryError("boom");
        final Throwable caught = assertThrows(Throwable.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.throwUnchecked(original);
            }
        });
        assertSame(original, caught);
    }

    @Test
    void testThrowUncheckedReturnsCheckedExceptionUnchanged() {
        final Exception checked = new IOException("boom");
        final Exception result = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, result);
    }

    @Test
    void testThrowUncheckedNullReturnsNull() {
        assertNull(ExceptionUtils.throwUnchecked((Throwable) null));
    }

    // --- wrapAndThrow ------------------------------------------------------------------------

    @Test
    void testWrapAndThrowWithCheckedExceptionWrapsInUndeclaredThrowableException() {
        final IOException checked = new IOException("boom");
        final Throwable caught = assertThrows(UndeclaredThrowableException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.wrapAndThrow(checked);
            }
        });
        assertSame(checked, caught.getCause());
    }

    @Test
    void testWrapAndThrowWithRuntimeExceptionRethrowsOriginal() {
        final RuntimeException original = new IllegalStateException("boom");
        final Throwable caught = assertThrows(Throwable.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.wrapAndThrow(original);
            }
        });
        assertSame(original, caught);
        assertFalse(caught instanceof UndeclaredThrowableException);
    }

    @Test
    void testWrapAndThrowWithErrorRethrowsOriginal() {
        final Error original = new OutOfMemoryError("boom");
        final Throwable caught = assertThrows(Throwable.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.wrapAndThrow(original);
            }
        });
        assertSame(original, caught);
    }
}
