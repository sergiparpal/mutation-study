/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum HeaderEnum {
        NAME, EMAIL, PHONE
    }

    // --- newFormat / basic accessors ---

    @Test
    void testNewFormatBasicDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertEquals(';', format.getDelimiter());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isNullStringSet());
        assertNull(format.getHeader());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getTrim());
        assertEquals(0, format.getMaxRows());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\n'));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\r'));
    }

    // --- DEFAULT / predefined formats ---

    @Test
    void testDefaultFormatSettings() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        final CSVFormat rfc = CSVFormat.RFC4180;
        assertFalse(rfc.getIgnoreEmptyLines());
        assertEquals(CSVFormat.DEFAULT.getDelimiterString(), rfc.getDelimiterString());
        assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), rfc.getQuoteCharacter());
        assertNotEquals(CSVFormat.DEFAULT, rfc);
    }

    @Test
    void testExcelFormatSettings() {
        final CSVFormat excel = CSVFormat.EXCEL;
        assertFalse(excel.getIgnoreEmptyLines());
        assertTrue(excel.getAllowMissingColumnNames());
        assertTrue(excel.getTrailingData());
        assertTrue(excel.getLenientEof());
    }

    @Test
    void testTdfFormatSettings() {
        final CSVFormat tdf = CSVFormat.TDF;
        assertEquals("\t", tdf.getDelimiterString());
        assertTrue(tdf.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormatSettings() {
        final CSVFormat mysql = CSVFormat.MYSQL;
        assertEquals("\t", mysql.getDelimiterString());
        assertEquals(Character.valueOf('\\'), mysql.getEscapeCharacter());
        assertNull(mysql.getQuoteCharacter());
        assertEquals("\n", mysql.getRecordSeparator());
        assertEquals("\\N", mysql.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, mysql.getQuoteMode());
    }

    @Test
    void testValueOfAndPredefinedAgree() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.valueOf("Excel").getFormat());
    }

    @Test
    void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NotARealFormat"));
    }

    // --- Builder validation ---

    @Test
    void testBuilderSetDelimiterEmptyThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter("").get());
    }

    @Test
    void testBuilderSetDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter("a\nb").get());
    }

    @Test
    void testBuilderSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('\r').get());
    }

    @Test
    void testBuilderSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('\n').get());
    }

    @Test
    void testBuilderSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('\n').get());
    }

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote(null).setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape(null).setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeIsOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeadersDisallowed() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setHeader("a", "b", "a").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get());
    }

    @Test
    void testValidateDuplicateHeadersAllowedByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b", "a").get();
        assertArrayEquals(new String[] { "a", "b", "a" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateEmptyHeadersAllowedWithAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] { "a", "", "" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateNonEmptyHeadersDisallowedWithAllowEmpty() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setHeader("a", "a").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get());
    }

    // --- header handling ---

    @Test
    void testSetHeaderCopiesArray() {
        final String[] header = { "a", "b" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        header[0] = "changed";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderReturnsCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header = format.getHeader();
        header[0] = "mutated";
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderNoArgsMeansEmptyArray() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testSetHeaderCommentsCopiesArray() {
        final String[] comments = { "c1", "c2" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(comments).get();
        comments[0] = "changed";
        assertEquals("c1", format.getHeaderComments()[0]);
    }

    // --- quote / escape / null string accessors ---

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.builder().setQuote(null).get().isQuoteCharacterSet());
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertTrue(CSVFormat.DEFAULT.builder().setEscape('\\').get().isEscapeCharacterSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertTrue(CSVFormat.DEFAULT.builder().setCommentMarker('#').get().isCommentMarkerSet());
    }

    @Test
    void testGetAllowDuplicateHeaderNamesDeprecated() {
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
        final CSVFormat disallow = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    // --- maxRows / useMaxRows / useRow ---

    @Test
    void testMaxRowsDefaultIsZeroMeaningUnlimited() {
        assertEquals(0, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        assertTrue(CSVFormat.DEFAULT.useRow(1000000L));
    }

    @Test
    void testMaxRowsLimitsRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertEquals(2, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    // --- equals / hashCode ---

    @Test
    void testEqualsAndHashCodeForEqualFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferingDelimiterNotEqual() {
        final CSVFormat a = CSVFormat.newFormat(',');
        final CSVFormat b = CSVFormat.newFormat(';');
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        assertNotEquals(null, CSVFormat.DEFAULT);
        assertNotEquals("not a format", CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsReflexive() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
    }

    // --- toString ---

    @Test
    void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringIncludesQuoteCharWhenSet() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("QuoteChar=<\">"));
    }

    @Test
    void testToStringOmitsQuoteCharWhenNotSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).get();
        assertFalse(format.toString().contains("QuoteChar"));
    }

    // --- builder() / copy semantics ---

    @Test
    void testBuilderProducesIndependentCopy() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
    }

    // --- format(Object...) ---

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testFormatNullValueWithoutNullStringIsEmpty() {
        final String result = CSVFormat.DEFAULT.format((Object) null, "b");
        assertEquals(",b", result);
    }

    @Test
    void testFormatNullValueWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final String result = format.format((Object) null, "b");
        assertEquals("NULL,b", result);
    }

    @Test
    void testFormatNullValueWithNullStringAndQuoteModeAllIsQuoted() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final String result = format.format((Object) null, "b");
        assertEquals("\"NULL\",\"b\"", result);
    }

    @Test
    void testMultiCharDelimiterContainingQuoteCharThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter("::").setQuote(':').get());
    }

    @Test
    void testMultiCharDelimiterNotContainingQuoteCharIsOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setQuote('"').get();
        assertEquals("::", format.getDelimiterString());
    }

    @Test
    void testDeprecatedGetDelimiterOnMultiCharDelimiterReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
    }

    // --- print(Object, Appendable, boolean) ---

    @Test
    void testPrintSimpleValueNoQuotingNeeded() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintAppendsDelimiterWhenNotNewRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, false);
        assertEquals(",hello", writer.toString());
    }

    @Test
    void testPrintValueWithQuoteCharacterEscapesQuotes() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("a\"b", writer, true);
        assertEquals("\"a\"\"b\"", writer.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).setQuote(null).get();
        final StringWriter writer = new StringWriter();
        format.print("  hello  ", writer, true);
        assertEquals("hello", writer.toString());
    }

    // --- printRecord / println ---

    @Test
    void testPrintRecordWritesValuesAndSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b");
        assertEquals("a,b\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithoutTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    // --- deprecated with* methods basic sanity ---

    @Test
    void testWithDelimiterDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testWithHeaderDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    void testWithFirstRecordAsHeaderDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testWithNullStringDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @Test
    void testWithQuoteModeDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testWithTrailingDelimiterDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
    }

    @Test
    void testWithTrimDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
    }
}
