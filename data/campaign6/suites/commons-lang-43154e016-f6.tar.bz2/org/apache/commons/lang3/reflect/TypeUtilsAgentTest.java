/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link TypeUtils}.
 */
public class TypeUtilsAgentTest {

    private interface Iface<T> {
        // marker interface with a type parameter
    }

    private static class GenericClass<T> implements Iface<T> {
        // used to test type argument resolution through an interface
    }

    private static class StringClass extends GenericClass<String> {
        // used to test type argument resolution through a superclass
    }

    private static class Fixture<T> {
        public List<String> stringList;
        public Map<String, Integer> mapField;
        public T genericField;
        public List<T> genericListField;
    }

    private static class BoundedFixture<T extends Number> {
        // used to test bounded type variables
    }

    private static Field field(final Class<?> cls, final String name) {
        try {
            return cls.getField(name);
        } catch (final NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }

    // --- containsTypeVariables ---

    @Test
    public void testContainsTypeVariables() {
        final TypeVariable<?> typeVar = Fixture.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(typeVar));
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertTrue(TypeUtils.containsTypeVariables(List.class));
        final Type genericListFieldType = field(Fixture.class, "genericListField").getGenericType();
        assertTrue(TypeUtils.containsTypeVariables(genericListFieldType));
        final Type stringListFieldType = field(Fixture.class, "stringList").getGenericType();
        assertFalse(TypeUtils.containsTypeVariables(stringListFieldType));
    }

    // --- determineTypeArguments ---

    @Test
    public void testDetermineTypeArgumentsEqualClass() {
        final ParameterizedType superType = (ParameterizedType) StringClass.class.getGenericSuperclass();
        final Map<TypeVariable<?>, Type> args = TypeUtils.determineTypeArguments(GenericClass.class, superType);
        final TypeVariable<?> genericClassVar = GenericClass.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(genericClassVar));
    }

    @Test
    public void testDetermineTypeArgumentsIncompatible() {
        final ParameterizedType superType = (ParameterizedType) StringClass.class.getGenericSuperclass();
        assertNull(TypeUtils.determineTypeArguments(Integer.class, superType));
    }

    @Test
    public void testDetermineTypeArgumentsNullArgs() {
        final ParameterizedType superType = (ParameterizedType) StringClass.class.getGenericSuperclass();
        assertThrows(NullPointerException.class, () -> TypeUtils.determineTypeArguments(null, superType));
        assertThrows(NullPointerException.class, () -> TypeUtils.determineTypeArguments(StringClass.class, null));
    }

    // --- equals ---

    @Test
    public void testEqualsParameterizedType() {
        final ParameterizedType real = (ParameterizedType) field(Fixture.class, "stringList").getGenericType();
        final ParameterizedType built = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.equals(real, built));
        assertTrue(TypeUtils.equals(built, real));
        final ParameterizedType other = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.equals(built, other));
    }

    @Test
    public void testEqualsGenericArrayType() {
        final GenericArrayType a = TypeUtils.genericArrayType(String.class);
        final GenericArrayType b = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(a, b));
        final GenericArrayType c = TypeUtils.genericArrayType(Integer.class);
        assertFalse(TypeUtils.equals(a, c));
    }

    @Test
    public void testEqualsPlainClasses() {
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
    }

    // --- genericArrayType ---

    @Test
    public void testGenericArrayType() {
        final GenericArrayType type = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, type.getGenericComponentType());
        assertEquals("java.lang.String[]", TypeUtils.toString(type));
    }

    @Test
    public void testGenericArrayTypeNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.genericArrayType(null));
    }

    // --- getArrayComponentType ---

    @Test
    public void testGetArrayComponentType() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertEquals(String.class, TypeUtils.getArrayComponentType(TypeUtils.genericArrayType(String.class)));
        assertNull(TypeUtils.getArrayComponentType(String.class));
    }

    // --- getImplicitBounds / getImplicitLowerBounds / getImplicitUpperBounds ---

    @Test
    public void testGetImplicitBoundsNoBounds() {
        final TypeVariable<?> typeVar = Fixture.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.getImplicitBounds(typeVar));
    }

    @Test
    public void testGetImplicitBoundsWithBound() {
        final TypeVariable<?> typeVar = BoundedFixture.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] { Number.class }, TypeUtils.getImplicitBounds(typeVar));
    }

    @Test
    public void testGetImplicitBoundsNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.getImplicitBounds(null));
    }

    @Test
    public void testGetImplicitLowerBoundsEmpty() {
        final WildcardType w = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertArrayEquals(new Type[] { null }, TypeUtils.getImplicitLowerBounds(w));
    }

    @Test
    public void testGetImplicitLowerBoundsPresent() {
        final WildcardType w = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        assertArrayEquals(new Type[] { String.class }, TypeUtils.getImplicitLowerBounds(w));
    }

    @Test
    public void testGetImplicitLowerBoundsNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.getImplicitLowerBounds(null));
    }

    @Test
    public void testGetImplicitUpperBoundsEmpty() {
        final WildcardType w = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.getImplicitUpperBounds(w));
    }

    @Test
    public void testGetImplicitUpperBoundsNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.getImplicitUpperBounds(null));
    }

    // --- getRawType(Type, Type) ---

    @Test
    public void testGetRawTypeClass() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    public void testGetRawTypeParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(pt, null));
    }

    @Test
    public void testGetRawTypeTypeVariableNoAssigningType() {
        final TypeVariable<?> typeVar = Fixture.class.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(typeVar, null));
    }

    @Test
    public void testGetRawTypeTypeVariableWithAssigningType() {
        final TypeVariable<?> typeVar = Fixture.class.getTypeParameters()[0];
        final ParameterizedType assigning = TypeUtils.parameterize(Fixture.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(typeVar, assigning));
    }

    @Test
    public void testGetRawTypeGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String[].class, TypeUtils.getRawType(arrayType, null));
    }

    @Test
    public void testGetRawTypeWildcard() {
        final WildcardType w = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertNull(TypeUtils.getRawType(w, null));
    }

    // --- getTypeArguments ---

    @Test
    public void testGetTypeArgumentsThroughInterface() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringClass.class, Iface.class);
        final TypeVariable<?> ifaceVar = Iface.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(ifaceVar));
    }

    @Test
    public void testGetTypeArgumentsIncompatible() {
        assertNull(TypeUtils.getTypeArguments(String.class, List.class));
    }

    @Test
    public void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType pt = (ParameterizedType) field(Fixture.class, "mapField").getGenericType();
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(pt);
        final TypeVariable<?>[] mapParams = Map.class.getTypeParameters();
        assertEquals(String.class, args.get(mapParams[0]));
        assertEquals(Integer.class, args.get(mapParams[1]));
    }

    // --- isArrayType ---

    @Test
    public void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
    }

    // --- isAssignable ---

    @Test
    public void testIsAssignableClasses() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(String.class, String.class));
    }

    @Test
    public void testIsAssignableNullType() {
        assertTrue(TypeUtils.isAssignable(null, String.class));
        assertFalse(TypeUtils.isAssignable(null, int.class));
    }

    @Test
    public void testIsAssignableNullToType() {
        assertFalse(TypeUtils.isAssignable(String.class, (Type) null));
        assertTrue(TypeUtils.isAssignable((Type) null, (Type) null));
    }

    @Test
    public void testIsAssignableGenericArrayType() {
        final GenericArrayType arr = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.isAssignable(arr, Object.class));
        assertTrue(TypeUtils.isAssignable(arr, String[].class));
        assertFalse(TypeUtils.isAssignable(arr, Integer[].class));
    }

    @Test
    public void testIsAssignableWildcardToClassAlwaysFalse() {
        final WildcardType w = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertFalse(TypeUtils.isAssignable(w, String.class));
    }

    @Test
    public void testIsAssignableParameterizedTypes() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.isAssignable(listOfString, listOfString));
        assertFalse(TypeUtils.isAssignable(listOfString, listOfInteger));
    }

    // --- isInstance ---

    @Test
    public void testIsInstance() {
        assertTrue(TypeUtils.isInstance("foo", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(1), String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("foo", null));
    }

    // --- normalizeUpperBounds ---

    @Test
    public void testNormalizeUpperBoundsRemovesRedundant() {
        final Type[] result = TypeUtils.normalizeUpperBounds(new Type[] { Number.class, Integer.class });
        assertArrayEquals(new Type[] { Integer.class }, result);
    }

    @Test
    public void testNormalizeUpperBoundsSingle() {
        final Type[] bounds = new Type[] { String.class };
        assertArrayEquals(bounds, TypeUtils.normalizeUpperBounds(bounds));
    }

    @Test
    public void testNormalizeUpperBoundsNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.normalizeUpperBounds(null));
    }

    // --- parameterize / parameterizeWithOwner ---

    @Test
    public void testParameterize() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertArrayEquals(new Type[] { String.class }, pt.getActualTypeArguments());
    }

    @Test
    public void testParameterizeWithMap() {
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(listVar, Integer.class);
        final ParameterizedType pt = TypeUtils.parameterize(List.class, map);
        assertArrayEquals(new Type[] { Integer.class }, pt.getActualTypeArguments());
    }

    @Test
    public void testParameterizeNulls() {
        assertThrows(NullPointerException.class, () -> TypeUtils.parameterize(null, String.class));
        assertThrows(NullPointerException.class, () -> TypeUtils.parameterize(List.class, (Map<TypeVariable<?>, Type>) null));
    }

    @Test
    public void testParameterizeWrongArgumentCount() {
        assertThrows(IllegalArgumentException.class, () -> TypeUtils.parameterize(List.class, String.class, Integer.class));
    }

    @Test
    public void testParameterizeNullElement() {
        assertThrows(IllegalArgumentException.class, () -> TypeUtils.parameterize(List.class, (Type) null));
    }

    @Test
    public void testParameterizeWithOwnerInvalidOwner() {
        assertThrows(IllegalArgumentException.class, () -> TypeUtils.parameterizeWithOwner(Integer.class, Fixture.class, String.class));
    }

    @Test
    public void testParameterizeWithOwnerTopLevelDisallowsOwner() {
        assertThrows(IllegalArgumentException.class, () -> TypeUtils.parameterizeWithOwner(String.class, List.class, String.class));
    }

    // --- toLongString ---

    @Test
    public void testToLongString() {
        final TypeVariable<?> typeVar = BoundedFixture.class.getTypeParameters()[0];
        final String longString = TypeUtils.toLongString(typeVar);
        assertTrue(longString.contains(TypeUtilsAgentTest.class.getName() + ".BoundedFixture"));
        assertTrue(longString.contains("T extends"));
    }

    @Test
    public void testToLongStringNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.toLongString(null));
    }

    // --- toString ---

    @Test
    public void testToStringClassWithTypeParameters() {
        assertEquals("java.util.List<E>", TypeUtils.toString(List.class));
    }

    @Test
    public void testToStringParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(pt));
    }

    @Test
    public void testToStringWildcardAll() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
    }

    @Test
    public void testToStringWildcardWithUpperBound() {
        final WildcardType w = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals("? extends java.lang.Number", TypeUtils.toString(w));
    }

    @Test
    public void testToStringWildcardWithLowerBound() {
        final WildcardType w = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        assertEquals("? super java.lang.String", TypeUtils.toString(w));
    }

    @Test
    public void testToStringNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.toString(null));
    }

    // --- typesSatisfyVariables ---

    @Test
    public void testTypesSatisfyVariablesTrue() {
        final TypeVariable<?> typeVar = BoundedFixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(typeVar, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesFalse() {
        final TypeVariable<?> typeVar = BoundedFixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(typeVar, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesNull() {
        assertThrows(NullPointerException.class, () -> TypeUtils.typesSatisfyVariables(null));
    }

    // --- unrollVariables ---

    @Test
    public void testUnrollVariablesTypeVariable() {
        final TypeVariable<?> typeVar = Fixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(typeVar, String.class);
        final Type genericFieldType = field(Fixture.class, "genericField").getGenericType();
        assertEquals(String.class, TypeUtils.unrollVariables(map, genericFieldType));
    }

    @Test
    public void testUnrollVariablesParameterizedType() {
        final TypeVariable<?> typeVar = Fixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(typeVar, String.class);
        final Type genericListFieldType = field(Fixture.class, "genericListField").getGenericType();
        final Type unrolled = TypeUtils.unrollVariables(map, genericListFieldType);
        assertTrue(TypeUtils.equals(unrolled, TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    public void testUnrollVariablesNullMap() {
        final Type unrolled = TypeUtils.unrollVariables(null, String.class);
        assertEquals(String.class, unrolled);
    }

    // --- wildcardType builder ---

    @Test
    public void testWildcardTypeBuilderNoBounds() {
        final WildcardType w = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[0], w.getUpperBounds());
        assertArrayEquals(new Type[0], w.getLowerBounds());
    }

    @Test
    public void testWildcardTypeBuilderWithBounds() {
        final WildcardType w = TypeUtils.wildcardType().withUpperBounds(Number.class).withLowerBounds(Integer.class).build();
        assertArrayEquals(new Type[] { Number.class }, w.getUpperBounds());
        assertArrayEquals(new Type[] { Integer.class }, w.getLowerBounds());
    }

    @Test
    public void testWildcardAllConstant() {
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.WILDCARD_ALL.getUpperBounds());
        assertArrayEquals(new Type[0], TypeUtils.WILDCARD_ALL.getLowerBounds());
    }

    // --- wrap ---

    @Test
    public void testWrapClass() {
        final Typed<String> typed = TypeUtils.wrap(String.class);
        assertEquals(String.class, typed.getType());
    }

    @Test
    public void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> typed = TypeUtils.wrap((Type) pt);
        assertNotNull(typed.getType());
        assertEquals(pt, typed.getType());
    }
}
