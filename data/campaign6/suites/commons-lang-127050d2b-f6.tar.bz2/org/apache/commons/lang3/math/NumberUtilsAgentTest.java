/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructorExists() {
        assertEquals(NumberUtils.class, new NumberUtils().getClass());
    }

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    // ---------------------------------------------------------------
    // compare
    // ---------------------------------------------------------------

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("   "));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("not a number"));
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("12345"), NumberUtils.createBigInteger("12345"));
        assertEquals(new BigInteger("-12345"), NumberUtils.createBigInteger("-12345"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigInteger(""));
    }

    // ---------------------------------------------------------------
    // createDouble / createFloat
    // ---------------------------------------------------------------

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createDouble("not a number"));
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createFloat("not a number"));
    }

    // ---------------------------------------------------------------
    // createInteger / createLong
    // ---------------------------------------------------------------

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12345), NumberUtils.createInteger("12345"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createInteger("not a number"));
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12345L), NumberUtils.createLong("12345"));
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createLong("not a number"));
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("   "));
    }

    @Test
    void testCreateNumberIntegral() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertEquals(Integer.valueOf(-12345), NumberUtils.createNumber("-12345"));
        // Larger than int range, should become Long
        assertEquals(Long.valueOf(12345678901L), NumberUtils.createNumber("12345678901"));
        // Larger than long range, should become BigInteger
        assertEquals(new BigInteger("123456789012345678901234567890"), NumberUtils.createNumber("123456789012345678901234567890"));
    }

    @Test
    void testCreateNumberDecimal() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5"));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createNumber("1.5d"));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5f"));
        assertEquals(Long.valueOf(100L), NumberUtils.createNumber("100L"));
    }

    @Test
    void testCreateNumberHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("0xFF"));
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("#FF"));
        assertEquals(Integer.valueOf(-255), NumberUtils.createNumber("-0xFF"));
    }

    @Test
    void testCreateNumberMalformed() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1ee2"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.2.3"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("0x"));
    }

    @Test
    void testCreateNumberLeadingZeroOctal() {
        // Leading zero means octal per the documented behaviour.
        assertEquals(Integer.valueOf(8), NumberUtils.createNumber("010"));
    }

    // ---------------------------------------------------------------
    // isCreatable / isNumber
    // ---------------------------------------------------------------

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12345"));
        assertTrue(NumberUtils.isCreatable("+12345"));
        assertTrue(NumberUtils.isCreatable("1.5"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertTrue(NumberUtils.isCreatable("1.5E-10"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertFalse(NumberUtils.isCreatable("0x"));
        assertFalse(NumberUtils.isCreatable("09")); // invalid octal
        assertTrue(NumberUtils.isCreatable("012")); // valid octal
        assertTrue(NumberUtils.isCreatable("0.1")); // leading 0 + decimal is fine
        assertFalse(NumberUtils.isCreatable("1.2.3"));
        assertFalse(NumberUtils.isCreatable("--1"));
        assertFalse(NumberUtils.isCreatable("1e"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertTrue(NumberUtils.isCreatable("100L"));
        assertTrue(NumberUtils.isCreatable("1.5F"));
        assertTrue(NumberUtils.isCreatable("1.5D"));
        assertFalse(NumberUtils.isCreatable("1.5L")); // L not allowed with decimal
    }

    @Test
    void testIsCreatableEveryTrueProducesNumber() {
        final String[] candidates = { "12345", "-12345", "1.5", "1.5e10", "0xFF", "012", "100L", "1.5F" };
        for (final String candidate : candidates) {
            assertTrue(NumberUtils.isCreatable(candidate), candidate);
            // Documented contract: isCreatable(str) == true implies createNumber(str) succeeds.
            NumberUtils.createNumber(candidate);
        }
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("12345"), NumberUtils.isNumber("12345"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertEquals(NumberUtils.isCreatable(null), NumberUtils.isNumber(null));
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // ---------------------------------------------------------------
    // isParsable
    // ---------------------------------------------------------------

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("1"));
        assertTrue(NumberUtils.isParsable("-1.5"));
        assertTrue(NumberUtils.isParsable("1.5e10"));
        assertFalse(NumberUtils.isParsable("1L")); // Long.parseLong rejects the 'L' suffix
        assertFalse(NumberUtils.isParsable("0x1"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ---------------------------------------------------------------
    // max/min arrays and varargs
    // ---------------------------------------------------------------

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 3, (byte) 5, (byte) -2));
        assertEquals((byte) 5, NumberUtils.max(new byte[] { 3, 5, -2 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new byte[0]));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) -2, NumberUtils.min((byte) 3, (byte) 5, (byte) -2));
        assertEquals((byte) -2, NumberUtils.min(new byte[] { 3, 5, -2 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new byte[0]));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 3, (short) 5, (short) -2));
        assertEquals((short) 5, NumberUtils.max(new short[] { 3, 5, -2 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new short[0]));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) -2, NumberUtils.min((short) 3, (short) 5, (short) -2));
        assertEquals((short) -2, NumberUtils.min(new short[] { 3, 5, -2 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new short[0]));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(3, 5, -2));
        assertEquals(5, NumberUtils.max(new int[] { 3, 5, -2 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new int[0]));
    }

    @Test
    void testMinIntArray() {
        assertEquals(-2, NumberUtils.min(3, 5, -2));
        assertEquals(-2, NumberUtils.min(new int[] { 3, 5, -2 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new int[0]));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(3L, 5L, -2L));
        assertEquals(5L, NumberUtils.max(new long[] { 3L, 5L, -2L }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new long[0]));
    }

    @Test
    void testMinLongArray() {
        assertEquals(-2L, NumberUtils.min(3L, 5L, -2L));
        assertEquals(-2L, NumberUtils.min(new long[] { 3L, 5L, -2L }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new long[0]));
    }

    @Test
    void testMaxFloatArrayAndNaN() {
        assertEquals(5.5f, NumberUtils.max(3.1f, 5.5f, -2.2f));
        assertEquals(5.5f, NumberUtils.max(new float[] { 3.1f, 5.5f, -2.2f }));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.max(new float[] { 1.0f, Float.NaN, 2.0f })));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new float[0]));
    }

    @Test
    void testMinFloatArrayAndNaN() {
        assertEquals(-2.2f, NumberUtils.min(3.1f, 5.5f, -2.2f));
        assertEquals(-2.2f, NumberUtils.min(new float[] { 3.1f, 5.5f, -2.2f }));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(new float[] { 1.0f, Float.NaN, 2.0f })));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new float[0]));
    }

    @Test
    void testMaxDoubleArrayAndNaN() {
        assertEquals(5.5d, NumberUtils.max(3.1d, 5.5d, -2.2d));
        assertEquals(5.5d, NumberUtils.max(new double[] { 3.1d, 5.5d, -2.2d }));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.max(new double[] { 1.0d, Double.NaN, 2.0d })));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new double[0]));
    }

    @Test
    void testMinDoubleArrayAndNaN() {
        assertEquals(-2.2d, NumberUtils.min(3.1d, 5.5d, -2.2d));
        assertEquals(-2.2d, NumberUtils.min(new double[] { 3.1d, 5.5d, -2.2d }));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(new double[] { 1.0d, Double.NaN, 2.0d })));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new double[0]));
    }

    @Test
    void testMaxMinSingleElementArray() {
        assertEquals(7, NumberUtils.max(new int[] { 7 }));
        assertEquals(7, NumberUtils.min(new int[] { 7 }));
    }

    // ---------------------------------------------------------------
    // toByte / toShort / toInt / toLong / toFloat / toDouble
    // ---------------------------------------------------------------

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("not a number", (byte) 2));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("not a number", (short) 2));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("not a number", 2));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("not a number", 2L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f));
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f));
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f));
        assertEquals(2.2f, NumberUtils.toFloat("not a number", 2.2f));
    }

    @Test
    void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d));
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d));
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d));
        assertEquals(2.2d, NumberUtils.toDouble("not a number", 2.2d));
    }

    @Test
    void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d));
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, RoundingMode.HALF_EVEN));
        // 1.225 is exactly halfway between 1.22 and 1.23; HALF_EVEN rounds to the even neighbor 1.22.
        assertEquals(new BigDecimal("1.22"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.225"), 2, RoundingMode.HALF_EVEN));
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.5")));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 2, RoundingMode.HALF_EVEN));
        // Null RoundingMode falls back to HALF_EVEN.
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.5d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_EVEN));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.5f)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_EVEN));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal("1.5"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_EVEN));
    }
}
