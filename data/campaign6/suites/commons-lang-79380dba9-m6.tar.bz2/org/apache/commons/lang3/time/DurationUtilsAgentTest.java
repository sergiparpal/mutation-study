/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    @Test
    void testAcceptCallsConsumerWithMillisAndNanos() throws Exception {
        final Duration duration = Duration.ofSeconds(1, 2_000_123);
        final AtomicLong millis = new AtomicLong(-1);
        final AtomicInteger nanos = new AtomicInteger(-1);
        final FailableBiConsumer<Long, Integer, Exception> consumer = (m, n) -> {
            millis.set(m);
            nanos.set(n);
        };
        DurationUtils.accept(consumer, duration);
        assertEquals(duration.toMillis(), millis.get());
        assertEquals(2_000_123 % 1_000_000, nanos.get());
    }

    @Test
    void testAcceptNullConsumerDoesNothing() throws Exception {
        final AtomicBoolean called = new AtomicBoolean(false);
        final FailableBiConsumer<Long, Integer, Exception> consumer = (m, n) -> called.set(true);
        DurationUtils.accept(null, Duration.ofSeconds(1));
        assertFalse(called.get());
    }

    @Test
    void testAcceptNullDurationDoesNothing() throws Exception {
        final AtomicBoolean called = new AtomicBoolean(false);
        final FailableBiConsumer<Long, Integer, Exception> consumer = (m, n) -> called.set(true);
        DurationUtils.accept(consumer, null);
        assertFalse(called.get());
    }

    @Test
    void testAcceptPropagatesException() {
        final FailableBiConsumer<Long, Integer, IllegalStateException> consumer = (m, n) -> {
            throw new IllegalStateException("boom");
        };
        assertThrows(IllegalStateException.class, () -> DurationUtils.accept(consumer, Duration.ofMillis(1)));
    }

    @Test
    void testGetWithMissingPropertyReturnsDefault() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.missing." + System.nanoTime();
        final Duration duration = DurationUtils.get(key, ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(42), duration);
    }

    @Test
    void testGetWithEmptyKeyReturnsDefault() {
        final Duration duration = DurationUtils.get("", ChronoUnit.SECONDS, 7L);
        assertEquals(Duration.ofSeconds(7), duration);
    }

    @Test
    void testGetWithNullKeyReturnsDefault() {
        final Duration duration = DurationUtils.get(null, ChronoUnit.MINUTES, 3L);
        assertEquals(Duration.ofMinutes(3), duration);
    }

    @Test
    void testGetMillisWithMissingPropertyReturnsDefault() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.missingMillis." + System.nanoTime();
        assertEquals(Duration.ofMillis(123), DurationUtils.getMillis(key, 123L));
    }

    @Test
    void testGetSecondsWithMissingPropertyReturnsDefault() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.missingSeconds." + System.nanoTime();
        assertEquals(Duration.ofSeconds(99), DurationUtils.getSeconds(key, 99L));
    }

    @Test
    void testGetNanosOfMilliZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofMillis(5)));
    }

    @Test
    void testGetNanosOfMilliNonZero() {
        // 1,500,000 nanos == 1 millisecond + 500,000 remaining nanos
        assertEquals(500_000, DurationUtils.getNanosOfMilli(Duration.ofNanos(1_500_000)));
    }

    @Test
    void testGetNanosOfMilliNullDurationTreatedAsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testGetNanosOfMiiliDelegatesToGetNanosOfMilli() {
        final Duration duration = Duration.ofNanos(1_250_000);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testIsPositiveTrue() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
    }

    @Test
    void testIsPositiveFalseForZero() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    void testIsPositiveFalseForNegative() {
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    @Test
    void testIsPositiveNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DurationUtils.isPositive(null));
    }

    @Test
    void testOfConsumerReturnsNonNegativeDurationAndPassesStart() throws Exception {
        final AtomicReference<Instant> seen = new AtomicReference<>();
        final Duration duration = DurationUtils.of(start -> {
            seen.set(start);
            Thread.sleep(1);
        });
        assertNotNull(seen.get());
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfConsumerPropagatesException() {
        assertThrows(IllegalStateException.class, () -> DurationUtils.of(start -> {
            throw new IllegalStateException("fail");
        }));
    }

    @Test
    void testOfRunnableReturnsNonNegativeDuration() throws Exception {
        final AtomicBoolean ran = new AtomicBoolean(false);
        final Duration duration = DurationUtils.of(() -> {
            ran.set(true);
            Thread.sleep(1);
        });
        assertTrue(ran.get());
        assertFalse(duration.isNegative());
    }

    @Test
    void testSinceReturnsNonNegativeDurationFromPastInstant() {
        final Instant past = Instant.now().minusSeconds(1);
        final Duration duration = DurationUtils.since(past);
        assertFalse(duration.isNegative());
        assertTrue(duration.toMillis() >= 900);
    }

    @Test
    void testToChronoUnitMapsAllTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnitNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DurationUtils.toChronoUnit(null));
    }

    @Test
    void testToDurationPositive() {
        assertEquals(Duration.ofSeconds(5), DurationUtils.toDuration(5, TimeUnit.SECONDS));
    }

    @Test
    void testToDurationNegative() {
        assertEquals(Duration.ofMinutes(-3), DurationUtils.toDuration(-3, TimeUnit.MINUTES));
    }

    @Test
    void testToMillisIntNormalValue() {
        assertEquals(5_000, DurationUtils.toMillisInt(Duration.ofMillis(5_000)));
    }

    @Test
    void testToMillisIntAtIntegerMaxBoundary() {
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(Duration.ofMillis(Integer.MAX_VALUE)));
    }

    @Test
    void testToMillisIntBeyondIntegerMaxClampsToIntegerMax() {
        final Duration duration = Duration.ofMillis((long) Integer.MAX_VALUE + 1);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisIntAtIntegerMinBoundary() {
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(Duration.ofMillis(Integer.MIN_VALUE)));
    }

    @Test
    void testToMillisIntBeyondIntegerMinClampsToIntegerMin() {
        final Duration duration = Duration.ofMillis((long) Integer.MIN_VALUE - 1);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisIntOverflowPositiveReturnsIntegerMax() {
        // Duration.toMillis() overflows for a duration this large, and it is not negative.
        final Duration duration = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisIntOverflowNegativeReturnsIntegerMin() {
        // Duration.toMillis() overflows for a duration this large in magnitude, and it is negative.
        final Duration duration = Duration.ofSeconds(Long.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisIntNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DurationUtils.toMillisInt(null));
    }

    @Test
    void testZeroIfNullWithNullReturnsZero() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNullWithValueReturnsSameValue() {
        final Duration duration = Duration.ofMinutes(5);
        assertEquals(duration, DurationUtils.zeroIfNull(duration));
    }

    @Test
    void testConstructorCreatesInstance() {
        assertNotNull(new DurationUtils());
    }
}
