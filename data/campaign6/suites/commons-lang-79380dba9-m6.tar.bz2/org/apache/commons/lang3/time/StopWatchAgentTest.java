/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link StopWatch}.
 */
class StopWatchAgentTest {

    @Test
    void testInitialState() {
        final StopWatch watch = new StopWatch();
        assertFalse(watch.isStarted());
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStopped());
        assertEquals(0L, watch.getNanoTime());
        assertEquals(0L, watch.getTime());
        assertEquals(Duration.ZERO, watch.getDuration());
        assertNull(watch.getMessage());
        assertEquals("00:00:00.000", watch.toString());
        assertTrue(watch.getSplits().isEmpty());
    }

    @Test
    void testCreateFactoryMethod() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
    }

    @Test
    void testCreateStartedFactoryMethod() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testMessageConstructor() {
        final StopWatch watch = new StopWatch("my-task");
        assertEquals("my-task", watch.getMessage());
        assertTrue(watch.toString().startsWith("my-task "));
    }

    @Test
    void testStartSetsRunningState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    void testStopWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    void testSuspendWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = StopWatch.createStarted();
        watch.suspend();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::resume);
        watch.start();
        assertThrows(IllegalStateException.class, watch::resume);
    }

    @Test
    void testSplitWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = StopWatch.createStarted();
        assertThrows(IllegalStateException.class, watch::unsplit);
    }

    @Test
    void testGetSplitDurationWithoutSplitThrows() {
        final StopWatch watch = StopWatch.createStarted();
        assertThrows(IllegalStateException.class, watch::getSplitDuration);
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
    }

    @Test
    @SuppressWarnings("deprecation")
    void testGetSplitTimeDeprecatedWithoutSplitThrows() {
        final StopWatch watch = StopWatch.createStarted();
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    void testStopAndReset() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        watch.reset();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        // allowed again after reset
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    void testSuspendAndResume() {
        final StopWatch watch = StopWatch.createStarted();
        watch.suspend();
        assertTrue(watch.isStarted());
        assertTrue(watch.isSuspended());
        assertFalse(watch.isStopped());
        final long suspendedNanos = watch.getNanoTime();
        watch.resume();
        assertTrue(watch.isStarted());
        assertFalse(watch.isSuspended());
        assertTrue(watch.getNanoTime() >= suspendedNanos);
    }

    @Test
    void testSplitAndGetSplits() throws InterruptedException {
        final StopWatch watch = StopWatch.createStarted();
        Thread.sleep(2);
        watch.split();
        final Duration splitDuration = watch.getSplitDuration();
        assertFalse(splitDuration.isNegative());
        assertEquals(splitDuration.toNanos(), watch.getSplitNanoTime());

        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertEquals(splitDuration, splits.get(0).getDuration());
    }

    @Test
    void testSplitsAreUnmodifiable() {
        final StopWatch watch = StopWatch.createStarted();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, () -> splits.add(new StopWatch.Split("x", Duration.ZERO)));
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch watch = StopWatch.createStarted();
        watch.split("first");
        assertEquals(1, watch.getSplits().size());
        assertEquals("first", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testMultipleSplitsDefaultLabelsIncrement() {
        final StopWatch watch = StopWatch.createStarted();
        watch.split();
        watch.split();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(3, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertEquals("1", splits.get(1).getLabel());
        assertEquals("2", splits.get(2).getLabel());
    }

    @Test
    void testUnsplitRemovesLastSplitAndContinuesFromOriginalStart() throws InterruptedException {
        final StopWatch watch = StopWatch.createStarted();
        Thread.sleep(2);
        watch.split();
        final Duration firstSplit = watch.getSplitDuration();
        watch.unsplit();
        assertTrue(watch.getSplits().isEmpty());
        assertThrows(IllegalStateException.class, watch::getSplitDuration);

        Thread.sleep(2);
        watch.split();
        final Duration secondSplit = watch.getSplitDuration();
        // measured from the same original start point, so later split is at least as long
        assertTrue(secondSplit.compareTo(firstSplit) >= 0);
    }

    @Test
    void testSplitTwiceDoesNotThrowWhileRunning() {
        final StopWatch watch = StopWatch.createStarted();
        watch.split();
        // runningState stays RUNNING across a split, so a second split is permitted
        watch.split();
        assertEquals(2, watch.getSplits().size());
    }

    @Test
    void testStopAfterSplitStopsWatch() {
        final StopWatch watch = StopWatch.createStarted();
        watch.split();
        watch.stop();
        assertTrue(watch.isStopped());
    }

    @Test
    void testGetTimeAfterStop() throws InterruptedException {
        final StopWatch watch = StopWatch.createStarted();
        Thread.sleep(2);
        watch.stop();
        final long stoppedTime = watch.getTime();
        assertTrue(stoppedTime >= 0);
        // time is frozen once stopped
        assertEquals(stoppedTime, watch.getTime());
    }

    @Test
    void testGetTimeWithTimeUnit() {
        final StopWatch watch = new StopWatch();
        assertEquals(0L, watch.getTime(TimeUnit.SECONDS));
        assertEquals(0L, watch.getTime(TimeUnit.MILLISECONDS));
    }

    @Test
    void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStartInstant);
    }

    @Test
    void testGetStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStopInstant);
    }

    @Test
    void testGetStopInstantIsNullWhenNotYetStopped() {
        final StopWatch watch = StopWatch.createStarted();
        assertNull(watch.getStopInstant());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testGetStopTimeIsZeroWhenNotYetStopped() {
        final StopWatch watch = StopWatch.createStarted();
        assertEquals(0L, watch.getStopTime());
    }

    @Test
    void testGetStartInstantAfterStart() {
        final Instant before = Instant.now();
        final StopWatch watch = StopWatch.createStarted();
        final Instant after = Instant.now();
        final Instant started = watch.getStartInstant();
        assertFalse(started.isBefore(before.minusSeconds(1)));
        assertFalse(started.isAfter(after.plusSeconds(1)));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testGetStartTimeDeprecatedMatchesStartInstant() {
        final StopWatch watch = StopWatch.createStarted();
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
    }

    @Test
    void testRunStartsSuspendsAndReturnsToSuspendedState() {
        final StopWatch watch = new StopWatch();
        final AtomicInteger counter = new AtomicInteger();
        final boolean[] wasStartedDuringRun = {false};
        watch.run(() -> {
            wasStartedDuringRun[0] = watch.isStarted();
            counter.incrementAndGet();
        });
        assertTrue(wasStartedDuringRun[0]);
        assertEquals(1, counter.get());
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        final FailableRunnable<Exception> runnable = () -> {
            throw new java.io.IOException("boom");
        };
        assertThrows(java.io.IOException.class, () -> watch.runT(runnable));
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetSupplierReturnsValueAndSuspends() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(() -> "value");
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTPropagatesThrowable() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, () -> watch.getT(() -> {
            throw new IllegalStateException("bad");
        }));
        assertTrue(watch.isSuspended());
    }

    @Test
    void testFormatTimeZero() {
        final StopWatch watch = StopWatch.create();
        assertEquals("00:00:00.000", watch.formatTime());
    }

    @Test
    void testToSplitStringWithMessage() throws InterruptedException {
        final StopWatch watch = new StopWatch("task");
        watch.start();
        Thread.sleep(2);
        watch.split();
        assertTrue(watch.toSplitString().startsWith("task "));
    }

    @Test
    void testSplitClassAccessors() {
        final Duration duration = Duration.ofSeconds(3);
        final StopWatch.Split split = new StopWatch.Split("label", duration);
        assertEquals("label", split.getLabel());
        assertEquals(duration, split.getDuration());
        assertTrue(split.toString().startsWith("Split ["));
        assertTrue(split.toString().contains("label"));
    }

    @Test
    void testGetDurationNonNegativeWhileRunning() {
        final StopWatch watch = StopWatch.createStarted();
        assertFalse(watch.getDuration().isNegative());
    }
}
