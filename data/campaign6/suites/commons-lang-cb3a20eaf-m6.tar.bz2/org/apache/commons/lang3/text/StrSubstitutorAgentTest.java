/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrSubstitutor}.
 */
@SuppressWarnings("deprecation")
public class StrSubstitutorAgentTest {

    private Map<String, String> newMap() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("animal", "quick brown fox");
        map.put("target", "lazy dog");
        return map;
    }

    @Test
    public void testReplaceStaticMap() {
        final String result = StrSubstitutor.replace("The ${animal} jumps over the ${target}.", newMap());
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    public void testReplaceStaticMapWithCustomPrefixSuffix() {
        final String result = StrSubstitutor.replace("The <animal> jumps.", newMap(), "<", ">");
        assertEquals("The quick brown fox jumps.", result);
    }

    @Test
    public void testReplaceStaticMapPrefixSuffixNullPrefixThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StrSubstitutor.replace("abc", newMap(), null, ">");
            }
        });
    }

    @Test
    public void testReplaceStaticProperties() {
        final Properties props = new Properties();
        props.setProperty("name", "world");
        final String result = StrSubstitutor.replace("Hello ${name}!", props);
        assertEquals("Hello world!", result);
    }

    @Test
    public void testReplaceStaticPropertiesNullReturnsToString() {
        final String result = StrSubstitutor.replace("Hello ${name}!", (Properties) null);
        assertEquals("Hello ${name}!", result);
    }

    @Test
    public void testReplaceStaticPropertiesNullSourceAndNullPropertiesThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StrSubstitutor.replace(null, (Properties) null);
            }
        });
    }

    @Test
    public void testReplaceSystemProperties() {
        System.setProperty("StrSubstitutorAgentTest.prop", "theValue");
        try {
            final String result = StrSubstitutor.replaceSystemProperties("value=${StrSubstitutorAgentTest.prop}");
            assertEquals("value=theValue", result);
        } finally {
            System.clearProperty("StrSubstitutorAgentTest.prop");
        }
    }

    @Test
    public void testDefaultConstructorNoResolverLeavesVariablesUnresolved() {
        final StrSubstitutor sub = new StrSubstitutor();
        final String result = sub.replace("Hello ${name}!");
        assertEquals("Hello ${name}!", result);
        assertNull(sub.getVariableResolver());
    }

    @Test
    public void testMapConstructorNullMapLeavesVariablesUnresolved() {
        final StrSubstitutor sub = new StrSubstitutor((Map<String, String>) null);
        final String result = sub.replace("Hello ${name}!");
        assertEquals("Hello ${name}!", result);
    }

    @Test
    public void testReplaceNullSourceReturnsNull() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertNull(sub.replace((String) null));
        assertNull(sub.replace((Object) null));
        assertNull(sub.replace((char[]) null));
        assertNull(sub.replace((CharSequence) null));
        assertNull(sub.replace((StrBuilder) null));
        assertNull(sub.replace((StringBuffer) null));
    }

    @Test
    public void testReplaceInNullSourceReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StrBuilder) null));
        assertFalse(sub.replaceIn((StringBuffer) null));
        assertFalse(sub.replaceIn((StringBuilder) null));
    }

    @Test
    public void testReplaceStringReturnsSameInstanceWhenUnchanged() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "no variables here";
        final String result = sub.replace(source);
        assertSame(source, result);
    }

    @Test
    public void testReplaceStringReturnsNewInstanceWhenChanged() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "${animal}";
        final String result = sub.replace(source);
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testReplaceCharArray() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final char[] source = "The ${animal} ran.".toCharArray();
        final String result = sub.replace(source);
        assertEquals("The quick brown fox ran.", result);
        assertEquals("The ${animal} ran.", new String(source));
    }

    @Test
    public void testReplaceCharArrayOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final char[] source = "XX${animal}YY".toCharArray();
        final String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testReplaceCharSequenceOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final CharSequence source = "XX${animal}YY";
        final String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testReplaceStringOffsetLengthReturnsSubstring() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "XXunchangedYY";
        final String result = sub.replace(source, 2, 9);
        assertEquals("unchanged", result);
    }

    @Test
    public void testReplaceStrBuilder() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("${animal}");
        final String result = sub.replace(source);
        assertEquals("quick brown fox", result);
        assertEquals("${animal}", source.toString());
    }

    @Test
    public void testReplaceStrBuilderOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("XX${animal}YY");
        final String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testReplaceStringBuffer() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("${animal}");
        final String result = sub.replace(source);
        assertEquals("quick brown fox", result);
        assertEquals("${animal}", source.toString());
    }

    @Test
    public void testReplaceStringBufferOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("XX${animal}YY");
        final String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    public void testReplaceInStrBuilder() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("${animal}");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("quick brown fox", source.toString());
    }

    @Test
    public void testReplaceInStrBuilderNoChange() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("no variables");
        final boolean altered = sub.replaceIn(source);
        assertFalse(altered);
        assertEquals("no variables", source.toString());
    }

    @Test
    public void testReplaceInStringBuffer() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("${animal}");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("quick brown fox", source.toString());
    }

    @Test
    public void testReplaceInStringBufferOffsetLengthNoChangeKeepsBuffer() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("XXunchangedYY");
        final boolean altered = sub.replaceIn(source, 2, 9);
        assertFalse(altered);
        assertEquals("XXunchangedYY", source.toString());
    }

    @Test
    public void testReplaceInStringBuilder() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuilder source = new StringBuilder("${animal}");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("quick brown fox", source.toString());
    }

    @Test
    public void testReplaceInStringBuilderOffsetLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuilder source = new StringBuilder("XX${animal}YY");
        final boolean altered = sub.replaceIn(source, 2, 9);
        assertTrue(altered);
        assertEquals("XXquick brown foxYY", source.toString());
    }

    @Test
    public void testUnknownVariableLeftUnresolved() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("Hi ${unknown}!");
        assertEquals("Hi ${unknown}!", result);
    }

    @Test
    public void testDefaultValueDelimiter() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("${undefined.number:-1234567890}.");
        assertEquals("1234567890.", result);
    }

    @Test
    public void testSetValueDelimiterChar() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter('=');
        assertNotNull(sub.getValueDelimiterMatcher());
        final String result = sub.replace("${missing=fallback}");
        assertEquals("fallback", result);
    }

    @Test
    public void testSetValueDelimiterStringEmptyDisables() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter("");
        assertNull(sub.getValueDelimiterMatcher());
        final String result = sub.replace("${missing:-fallback}");
        assertEquals("${missing:-fallback}", result);
    }

    @Test
    public void testSetValueDelimiterStringNullDisables() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter((String) null);
        assertNull(sub.getValueDelimiterMatcher());
    }

    @Test
    public void testEscapeCharacterDefaultRemovesEscape() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals('$', sub.getEscapeChar());
        final String result = sub.replace("$${animal}");
        assertEquals("${animal}", result);
    }

    @Test
    public void testPreserveEscapesKeepsEscapeCharacter() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.isPreserveEscapes());
        sub.setPreserveEscapes(true);
        assertTrue(sub.isPreserveEscapes());
        final String result = sub.replace("$${animal}");
        assertEquals("$${animal}", result);
    }

    @Test
    public void testSetEscapeCharCustom() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setEscapeChar('~');
        assertEquals('~', sub.getEscapeChar());
        final String result = sub.replace("~${animal}");
        assertEquals("${animal}", result);
    }

    @Test
    public void testSubstitutionInVariableNamesDisabledByDefault() {
        final Map<String, String> map = newMap();
        map.put("jre-1.8", "java8");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertFalse(sub.isEnableSubstitutionInVariables());
        map.put("java.specification.version", "1.8");
        final String result = sub.replace("${jre-${java.specification.version}}");
        assertEquals("${jre-${java.specification.version}}", result);
    }

    @Test
    public void testSubstitutionInVariableNamesEnabled() {
        final Map<String, String> map = newMap();
        map.put("jre-1.8", "java8");
        map.put("java.specification.version", "1.8");
        final StrSubstitutor sub = new StrSubstitutor(map);
        sub.setEnableSubstitutionInVariables(true);
        assertTrue(sub.isEnableSubstitutionInVariables());
        final String result = sub.replace("${jre-${java.specification.version}}");
        assertEquals("java8", result);
    }

    @Test
    public void testRecursiveVariableValue() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("a", "${b}");
        map.put("b", "finalValue");
        final StrSubstitutor sub = new StrSubstitutor(map);
        final String result = sub.replace("${a}");
        assertEquals("finalValue", result);
    }

    @Test
    public void testCyclicSubstitutionThrows() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("a", "${b}");
        map.put("b", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${a}");
            }
        });
    }

    @Test
    public void testExcessiveNestingDepthThrows() {
        final Map<String, String> map = new HashMap<String, String>();
        final int chainLength = 300;
        for (int i = 0; i < chainLength; i++) {
            map.put("v" + i, "${v" + (i + 1) + "}");
        }
        map.put("v" + chainLength, "end");
        final StrSubstitutor sub = new StrSubstitutor(map);
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${v0}");
            }
        });
        assertTrue(ex.getMessage().contains("Maximum interpolation depth"));
    }

    @Test
    public void testVariablePrefixAndSuffixCharacters() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setVariablePrefix('<');
        sub.setVariableSuffix('>');
        assertNotNull(sub.getVariablePrefixMatcher());
        assertNotNull(sub.getVariableSuffixMatcher());
        final String result = sub.replace("The <animal> ran.");
        assertEquals("The quick brown fox ran.", result);
    }

    @Test
    public void testSetVariablePrefixStringNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefix((String) null);
            }
        });
    }

    @Test
    public void testSetVariableSuffixStringNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffix((String) null);
            }
        });
    }

    @Test
    public void testSetVariablePrefixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefixMatcher(null);
            }
        });
    }

    @Test
    public void testSetVariableSuffixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffixMatcher(null);
            }
        });
    }

    @Test
    public void testSetVariableResolver() {
        final StrSubstitutor sub = new StrSubstitutor();
        final StrLookup<String> resolver = StrLookup.mapLookup(newMap());
        sub.setVariableResolver(resolver);
        assertSame(resolver, sub.getVariableResolver());
        assertEquals("quick brown fox", sub.replace("${animal}"));
    }

    @Test
    public void testConstructorWithPrefixSuffixEscape() {
        final StrSubstitutor sub = new StrSubstitutor(newMap(), "<", ">", '~');
        assertEquals('~', sub.getEscapeChar());
        final String result = sub.replace("The <animal> ran. ~<target>");
        assertEquals("The quick brown fox ran. <target>", result);
    }

    @Test
    public void testConstructorWithPrefixSuffixEscapeValueDelimiter() {
        final StrSubstitutor sub = new StrSubstitutor(newMap(), "${", "}", '$', "=");
        final String result = sub.replace("${missing=fallback}");
        assertEquals("fallback", result);
    }

    @Test
    public void testCustomResolveVariableOverride() {
        final StrSubstitutor sub = new StrSubstitutor() {
            @Override
            protected String resolveVariable(final String variableName, final StrBuilder buf, final int startPos, final int endPos) {
                return variableName.toUpperCase();
            }
        };
        final String result = sub.replace("hello ${world}");
        assertEquals("hello WORLD", result);
    }

    @Test
    public void testStaticConstantsHaveExpectedDefaults() {
        assertEquals('$', StrSubstitutor.DEFAULT_ESCAPE);
        assertNotNull(StrSubstitutor.DEFAULT_PREFIX);
        assertNotNull(StrSubstitutor.DEFAULT_SUFFIX);
        assertNotNull(StrSubstitutor.DEFAULT_VALUE_DELIMITER);
    }
}
