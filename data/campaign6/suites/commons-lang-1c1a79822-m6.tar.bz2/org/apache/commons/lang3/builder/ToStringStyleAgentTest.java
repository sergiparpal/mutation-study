/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ToStringStyle}.
 */
class ToStringStyleAgentTest {

    /** Minimal concrete fixture so a fresh, independently-mutable instance can be created. */
    private static final class Fixture extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    @Test
    void testIsFullDetailHonorsNullAndDefaultFlag() {
        final Fixture style = new Fixture();
        assertTrue(style.isFullDetail(null));
        assertTrue(style.isFullDetail(Boolean.TRUE));
        assertFalse(style.isFullDetail(Boolean.FALSE));

        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
        assertTrue(style.isFullDetail(Boolean.TRUE));
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    @Test
    void testAppendBooleanValue() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "flag", true);
        assertEquals("flag=true,", buffer.toString());
    }

    @Test
    void testAppendBooleanArrayNull() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "arr", (boolean[]) null, null);
        assertEquals("arr=<null>,", buffer.toString());
    }

    @Test
    void testAppendByteArraySummaryAndDetail() {
        final byte[] array = {1, 2, 3};

        final StringBuffer summary = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(summary, "b", array, Boolean.FALSE);
        assertEquals("b=<size=3>,", summary.toString());

        final StringBuffer detail = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(detail, "b", array, Boolean.TRUE);
        assertEquals("b={1,2,3},", detail.toString());

        final StringBuffer empty = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(empty, "b", new byte[0], Boolean.TRUE);
        assertEquals("b={},", empty.toString());
    }

    @Test
    void testAppendObjectNullAndValue() {
        final StringBuffer nullBuf = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(nullBuf, "o", (Object) null, Boolean.TRUE);
        assertEquals("o=<null>,", nullBuf.toString());

        final StringBuffer valueBuf = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(valueBuf, "o", "hello", Boolean.TRUE);
        assertEquals("o=hello,", valueBuf.toString());
    }

    @Test
    void testAppendObjectArrayDetailAndSummary() {
        final Object[] array = {"a", "b"};

        final StringBuffer detail = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(detail, "arr", array, Boolean.TRUE);
        assertEquals("arr={a,b},", detail.toString());

        final StringBuffer summary = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(summary, "arr", array, Boolean.FALSE);
        assertEquals("arr=<size=2>,", summary.toString());

        final StringBuffer nullArr = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(nullArr, "arr", (Object[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", nullArr.toString());
    }

    @Test
    void testAppendStartAndEndDefaultStyle() {
        final Object target = new Object();
        final String expectedHash = Integer.toHexString(System.identityHashCode(target));
        final StringBuffer buffer = new StringBuffer();

        assertFalse(ToStringStyle.isRegistered(target));
        ToStringStyle.DEFAULT_STYLE.appendStart(buffer, target);
        assertTrue(ToStringStyle.isRegistered(target));
        assertEquals(target.getClass().getName() + "@" + expectedHash + "[", buffer.toString());

        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", 1);
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, target);

        assertEquals(target.getClass().getName() + "@" + expectedHash + "[a=1]", buffer.toString());
        assertFalse(ToStringStyle.isRegistered(target));
    }

    @Test
    void testAppendStartNullObjectLeavesBufferEmpty() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    @Test
    void testAppendEndUnregistersEvenWhenNothingWasAppended() {
        final Object target = new Object();
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.register(target);
        assertTrue(ToStringStyle.isRegistered(target));
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, target);
        assertFalse(ToStringStyle.isRegistered(target));
        assertEquals("]", buffer.toString());
    }

    @Test
    void testShortPrefixStyleUsesShortClassNameAndNoIdentityHashCode() {
        final Object target = new Object();
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.SHORT_PREFIX_STYLE.appendStart(buffer, target);
        assertEquals("Object[", buffer.toString());
        ToStringStyle.SHORT_PREFIX_STYLE.appendEnd(buffer, target);
        assertEquals("Object[]", buffer.toString());
    }

    @Test
    void testNoClassNameStyleOmitsClassNameButKeepsContent() {
        final Object target = new Object();
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.NO_CLASS_NAME_STYLE.appendStart(buffer, target);
        assertEquals("[", buffer.toString());
        ToStringStyle.NO_CLASS_NAME_STYLE.append(buffer, "a", 1);
        ToStringStyle.NO_CLASS_NAME_STYLE.appendEnd(buffer, target);
        assertEquals("[a=1]", buffer.toString());
    }

    @Test
    void testSimpleStyleOmitsEverythingButValues() {
        final Object target = new Object();
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.SIMPLE_STYLE.appendStart(buffer, target);
        assertEquals("", buffer.toString());
        ToStringStyle.SIMPLE_STYLE.append(buffer, "a", 1);
        ToStringStyle.SIMPLE_STYLE.append(buffer, "b", 2);
        ToStringStyle.SIMPLE_STYLE.appendEnd(buffer, target);
        assertEquals("1,2", buffer.toString());
    }

    @Test
    void testNoFieldNamesStyleOmitsFieldName() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.NO_FIELD_NAMES_STYLE.append(buffer, "flag", true);
        assertEquals("true,", buffer.toString());
    }

    @Test
    void testMultiLineStyleUsesLineSeparatorAndLeadingSeparator() {
        final Object target = new Object();
        final String expectedHash = Integer.toHexString(System.identityHashCode(target));
        final StringBuffer buffer = new StringBuffer();
        final String lineSep = System.lineSeparator();

        ToStringStyle.MULTI_LINE_STYLE.appendStart(buffer, target);
        ToStringStyle.MULTI_LINE_STYLE.append(buffer, "a", 1);
        ToStringStyle.MULTI_LINE_STYLE.appendEnd(buffer, target);

        final String expected = target.getClass().getName() + "@" + expectedHash + "[" + lineSep + "  a=1" + lineSep + "]";
        assertEquals(expected, buffer.toString());
    }

    @Test
    void testJsonStyleRejectsMissingFieldName() {
        final StringBuffer buffer = new StringBuffer();
        final UnsupportedOperationException ex = assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                ToStringStyle.JSON_STYLE.append(buffer, null, "value", Boolean.TRUE);
            }
        });
        assertTrue(ex.getMessage().contains("Field names are mandatory"));
    }

    @Test
    void testJsonStyleRejectsNonFullDetail() {
        final StringBuffer buffer = new StringBuffer();
        final UnsupportedOperationException ex = assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                ToStringStyle.JSON_STYLE.append(buffer, "a", "value", Boolean.FALSE);
            }
        });
        assertTrue(ex.getMessage().contains("FullDetail must be true"));
    }

    @Test
    void testJsonStyleQuotesStringsButNotNumbersOrBooleans() {
        final StringBuffer stringBuf = new StringBuffer();
        ToStringStyle.JSON_STYLE.append(stringBuf, "name", "John", Boolean.TRUE);
        assertEquals("\"name\":\"John\",", stringBuf.toString());

        final StringBuffer numberBuf = new StringBuffer();
        ToStringStyle.JSON_STYLE.append(numberBuf, "age", Integer.valueOf(33), Boolean.TRUE);
        assertEquals("\"age\":33,", numberBuf.toString());

        final StringBuffer boolBuf = new StringBuffer();
        ToStringStyle.JSON_STYLE.append(boolBuf, "smoker", Boolean.FALSE, Boolean.TRUE);
        assertEquals("\"smoker\":false,", boolBuf.toString());
    }

    @Test
    void testJsonStyleMapDetail() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("k1", "v1");
        map.put("k2", "v2");
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.JSON_STYLE.appendDetail(buffer, "m", map);
        assertEquals("{\"k1\":\"v1\",\"k2\":\"v2\"}", buffer.toString());
    }

    @Test
    void testJsonStyleEmptyMapAndCollectionFallBackToToString() {
        final StringBuffer mapBuf = new StringBuffer();
        ToStringStyle.JSON_STYLE.appendDetail(mapBuf, "m", Collections.emptyMap());
        assertEquals(Collections.emptyMap().toString(), mapBuf.toString());

        final StringBuffer collBuf = new StringBuffer();
        ToStringStyle.JSON_STYLE.appendDetail(collBuf, "c", Collections.emptyList());
        assertEquals(Collections.emptyList().toString(), collBuf.toString());
    }

    @Test
    void testAppendSuperAndAppendToString() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendSuper(buffer, "Integer@8888[]");
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", "hello", Boolean.TRUE);
        assertEquals("a=hello,", buffer.toString());

        final StringBuffer nullSuper = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendToString(nullSuper, null);
        ToStringStyle.DEFAULT_STYLE.append(nullSuper, "a", "hello", Boolean.TRUE);
        assertEquals("a=hello,", nullSuper.toString());

        final StringBuffer noContent = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendToString(noContent, "Integer@8888");
        ToStringStyle.DEFAULT_STYLE.append(noContent, "a", "hello", Boolean.TRUE);
        assertEquals("a=hello,", noContent.toString());
    }

    @Test
    void testRegistryAndVisitedLifecycle() {
        final Object value = new Object();
        assertFalse(ToStringStyle.isRegistered(value));
        assertFalse(ToStringStyle.isVisited(value));
        assertTrue(ToStringStyle.getRegistry().isEmpty());

        ToStringStyle.register(value);
        try {
            assertTrue(ToStringStyle.isRegistered(value));
            assertSame(value, ToStringStyle.getRegistry().containsKey(value) ? value : null);

            ToStringStyle.markVisited(value);
            assertTrue(ToStringStyle.isVisited(value));
            ToStringStyle.markVisited(null);
        } finally {
            ToStringStyle.unregister(value);
        }

        assertFalse(ToStringStyle.isRegistered(value));
        assertFalse(ToStringStyle.isVisited(value));
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }

    @Test
    void testUnregisterNullIsNoOp() {
        assertTrue(ToStringStyle.getRegistry().isEmpty());
        ToStringStyle.unregister(null);
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }

    @Test
    void testAppendDetectsCycleAndRendersIdentityString() {
        final Object self = new Object();
        final String expected = self.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(self));
        ToStringStyle.register(self);
        try {
            final StringBuffer buffer = new StringBuffer();
            ToStringStyle.DEFAULT_STYLE.append(buffer, "self", self, Boolean.TRUE);
            assertEquals("self=" + expected + ",", buffer.toString());
        } finally {
            ToStringStyle.unregister(self);
        }
        assertFalse(ToStringStyle.isRegistered(self));
    }

    @Test
    void testAppendDoesNotTreatNumbersAsCycles() {
        final Integer number = Integer.valueOf(42);
        ToStringStyle.register(number);
        try {
            final StringBuffer buffer = new StringBuffer();
            ToStringStyle.DEFAULT_STYLE.append(buffer, "n", number, Boolean.TRUE);
            assertEquals("n=42,", buffer.toString());
        } finally {
            ToStringStyle.unregister(number);
        }
    }

    @Test
    void testSetArrayTextAcceptsNullAndConvertsToEmptyString() {
        final Fixture style = new Fixture();
        style.setArrayStart(null);
        style.setArrayEnd(null);
        style.setArraySeparator(null);

        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[] {1, 2}, Boolean.TRUE);
        assertEquals("arr=12,", buffer.toString());
    }

    @Test
    void testRemoveLastFieldSeparatorOnlyRemovesWhenPresent() {
        final Fixture style = new Fixture();

        final StringBuffer withSeparator = new StringBuffer("abc,");
        style.removeLastFieldSeparator(withSeparator);
        assertEquals("abc", withSeparator.toString());

        final StringBuffer withoutSeparator = new StringBuffer("abc");
        style.removeLastFieldSeparator(withoutSeparator);
        assertEquals("abc", withoutSeparator.toString());
    }

    @Test
    void testDefaultGettersAndSetters() {
        final Fixture style = new Fixture();
        assertTrue(style.isUseClassName());
        assertTrue(style.isUseFieldNames());
        assertFalse(style.isUseShortClassName());
        assertTrue(style.isUseIdentityHashCode());
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
        assertTrue(style.isArrayContentDetail());
        assertTrue(style.isDefaultFullDetail());

        style.setUseClassName(false);
        style.setUseFieldNames(false);
        style.setUseShortClassName(true);
        style.setUseIdentityHashCode(false);
        style.setFieldSeparatorAtStart(true);
        style.setFieldSeparatorAtEnd(true);
        style.setArrayContentDetail(false);

        assertFalse(style.isUseClassName());
        assertFalse(style.isUseFieldNames());
        assertTrue(style.isUseShortClassName());
        assertFalse(style.isUseIdentityHashCode());
        assertTrue(style.isFieldSeparatorAtStart());
        assertTrue(style.isFieldSeparatorAtEnd());
        assertFalse(style.isArrayContentDetail());
    }
}
