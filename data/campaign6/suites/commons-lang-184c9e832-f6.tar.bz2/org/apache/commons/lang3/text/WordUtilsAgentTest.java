/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link WordUtils}.
 */
public class WordUtilsAgentTest {

    // ---------------------------------------------------------------------
    // capitalize(String)
    // ---------------------------------------------------------------------

    @Test
    public void testCapitalize_null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    public void testCapitalize_singleWord() {
        assertEquals("Hello", WordUtils.capitalize("hello"));
    }

    @Test
    public void testCapitalize_multipleSpaces() {
        assertEquals("  Hello   World  ", WordUtils.capitalize("  hello   world  "));
    }

    // ---------------------------------------------------------------------
    // capitalize(String, char...)
    // ---------------------------------------------------------------------

    @Test
    public void testCapitalizeWithDelimiters_null() {
        assertNull(WordUtils.capitalize(null, '.'));
    }

    @Test
    public void testCapitalizeWithDelimiters_empty() {
        assertEquals("", WordUtils.capitalize("", '.'));
    }

    @Test
    public void testCapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalizeWithDelimiters_emptyArrayLeavesUnchanged() {
        final String input = "i am fine";
        assertSame(input, WordUtils.capitalize(input, new char[0]));
    }

    @Test
    public void testCapitalizeWithDelimiters_dotDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    // ---------------------------------------------------------------------
    // capitalizeFully(String)
    // ---------------------------------------------------------------------

    @Test
    public void testCapitalizeFully_null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // ---------------------------------------------------------------------
    // capitalizeFully(String, char...)
    // ---------------------------------------------------------------------

    @Test
    public void testCapitalizeFullyWithDelimiters_null() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_emptyArrayLeavesUnchanged() {
        final String input = "i aM.fine";
        assertSame(input, WordUtils.capitalizeFully(input, new char[0]));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am.fine", WordUtils.capitalizeFully("I AM.FINE", (char[]) null));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_dotDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    // ---------------------------------------------------------------------
    // containsAllWords
    // ---------------------------------------------------------------------

    @Test
    public void testContainsAllWords_nullWord() {
        assertEquals(false, WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_emptyWord() {
        assertEquals(false, WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_nullWords() {
        assertEquals(false, WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_emptyWordsArray() {
        assertEquals(false, WordUtils.containsAllWords("abc def"));
    }

    @Test
    public void testContainsAllWords_substringButNotWholeWordIsFalse() {
        assertEquals(false, WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_allWordsPresent() {
        assertEquals(true, WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    public void testContainsAllWords_oneWordMissing() {
        assertEquals(false, WordUtils.containsAllWords("abc def", "abc", "xyz"));
    }

    @Test
    public void testContainsAllWords_blankSearchWordIsFalse() {
        assertEquals(false, WordUtils.containsAllWords("abc def", "abc", " "));
    }

    // ---------------------------------------------------------------------
    // initials(String)
    // ---------------------------------------------------------------------

    @Test
    public void testInitials_null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_withDot() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    // ---------------------------------------------------------------------
    // initials(String, char...)
    // ---------------------------------------------------------------------

    @Test
    public void testInitialsWithDelimiters_null() {
        assertNull(WordUtils.initials(null, ' '));
    }

    @Test
    public void testInitialsWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitialsWithDelimiters_customDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testInitialsWithDelimiters_emptyArrayReturnsEmpty() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    // ---------------------------------------------------------------------
    // swapCase
    // ---------------------------------------------------------------------

    @Test
    public void testSwapCase_null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    // ---------------------------------------------------------------------
    // uncapitalize(String)
    // ---------------------------------------------------------------------

    @Test
    public void testUncapitalize_null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // ---------------------------------------------------------------------
    // uncapitalize(String, char...)
    // ---------------------------------------------------------------------

    @Test
    public void testUncapitalizeWithDelimiters_null() {
        assertNull(WordUtils.uncapitalize(null, '.'));
    }

    @Test
    public void testUncapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    public void testUncapitalizeWithDelimiters_emptyArrayLeavesUnchanged() {
        final String input = "I AM.FINE";
        assertSame(input, WordUtils.uncapitalize(input, new char[0]));
    }

    @Test
    public void testUncapitalizeWithDelimiters_dotDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    // ---------------------------------------------------------------------
    // wrap(String, int)
    // ---------------------------------------------------------------------

    @Test
    public void testWrap_null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap_empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_longWordNotWrappedByDefault() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump" + System.lineSeparator()
                + "to the commons" + System.lineSeparator()
                + "website -" + System.lineSeparator()
                + "https://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_wrapLengthLessThanOneTreatedAsOne() {
        // wrapLength 0 is treated as 1; words themselves are not split since
        // wrapLongWords defaults to false, so wrapping only occurs at the space.
        final String result = WordUtils.wrap("ab cd", 0);
        assertEquals("ab" + System.lineSeparator() + "cd", result);
    }

    // ---------------------------------------------------------------------
    // wrap(String, int, String, boolean)
    // ---------------------------------------------------------------------

    @Test
    public void testWrapFull_null() {
        assertNull(WordUtils.wrap(null, 20, "\n", true));
    }

    @Test
    public void testWrapFull_customNewLine() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    public void testWrapFull_wrapLongWordsTrue() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    public void testWrapFull_nullNewLineUsesSystemLineSeparator() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, null, false));
    }

    // ---------------------------------------------------------------------
    // wrap(String, int, String, boolean, String)
    // ---------------------------------------------------------------------

    @Test
    public void testWrapOn_null() {
        assertNull(WordUtils.wrap(null, 20, "\n", true, " "));
    }

    @Test
    public void testWrapOn_empty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true, " "));
    }

    @Test
    public void testWrapOn_customWrapOnCharacter() {
        final String input = "flammable/inflammable";
        final String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    public void testWrapOn_blankWrapOnDefaultsToSpace() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of\ntext that is going\nto be wrapped after\n20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false, ""));
    }

    // ---------------------------------------------------------------------
    // constructor
    // ---------------------------------------------------------------------

    @Test
    public void testConstructor() {
        assertEquals(WordUtils.class, new WordUtils().getClass());
    }
}
