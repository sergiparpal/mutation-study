/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link AnnotationUtils}.
 */
public class AnnotationUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @interface Marker {
        String name();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface Sample {
        int[] arr();
        Marker marker();
        int num();
        String str();
        String[] tags();
        Class<?> type();
    }

    @Sample(str = "a", num = 1, arr = {1, 2, 3}, tags = {"x", "y"}, type = String.class, marker = @Marker(name = "m1"))
    static class WithA {
    }

    @Sample(str = "a", num = 1, arr = {1, 2, 3}, tags = {"x", "y"}, type = String.class, marker = @Marker(name = "m1"))
    static class WithA2 {
    }

    @Sample(str = "b", num = 1, arr = {1, 2, 3}, tags = {"x", "y"}, type = String.class, marker = @Marker(name = "m1"))
    static class WithDiffStr {
    }

    @Sample(str = "a", num = 2, arr = {1, 2, 3}, tags = {"x", "y"}, type = String.class, marker = @Marker(name = "m1"))
    static class WithDiffNum {
    }

    @Sample(str = "a", num = 1, arr = {1, 2, 4}, tags = {"x", "y"}, type = String.class, marker = @Marker(name = "m1"))
    static class WithDiffArr {
    }

    @Sample(str = "a", num = 1, arr = {1, 2, 3}, tags = {"x", "z"}, type = String.class, marker = @Marker(name = "m1"))
    static class WithDiffTags {
    }

    @Sample(str = "a", num = 1, arr = {1, 2, 3}, tags = {"x", "y"}, type = Integer.class, marker = @Marker(name = "m1"))
    static class WithDiffType {
    }

    @Sample(str = "a", num = 1, arr = {1, 2, 3}, tags = {"x", "y"}, type = String.class, marker = @Marker(name = "m2"))
    static class WithDiffMarker {
    }

    private static Sample sampleOf(final Class<?> c) {
        return c.getAnnotation(Sample.class);
    }

    // --- equals ---

    @Test
    public void testEqualsBothNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    public void testEqualsFirstNull() {
        assertFalse(AnnotationUtils.equals(null, sampleOf(WithA.class)));
    }

    @Test
    public void testEqualsSecondNull() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), null));
    }

    @Test
    public void testEqualsSameInstance() {
        final Sample a = sampleOf(WithA.class);
        assertTrue(AnnotationUtils.equals(a, a));
    }

    @Test
    public void testEqualsEqualValuesDifferentInstances() {
        assertTrue(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithA2.class)));
    }

    @Test
    public void testEqualsIsSymmetric() {
        final Sample a = sampleOf(WithA.class);
        final Sample a2 = sampleOf(WithA2.class);
        assertEquals(AnnotationUtils.equals(a, a2), AnnotationUtils.equals(a2, a));
    }

    @Test
    public void testEqualsDifferentAnnotationTypes() {
        final Sample sample = sampleOf(WithA.class);
        final Marker marker = sample.marker();
        assertFalse(AnnotationUtils.equals(sample, marker));
    }

    @Test
    public void testEqualsDifferentStringMember() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithDiffStr.class)));
    }

    @Test
    public void testEqualsDifferentIntMember() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithDiffNum.class)));
    }

    @Test
    public void testEqualsDifferentPrimitiveArrayMember() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithDiffArr.class)));
    }

    @Test
    public void testEqualsDifferentObjectArrayMember() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithDiffTags.class)));
    }

    @Test
    public void testEqualsDifferentClassMember() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithDiffType.class)));
    }

    @Test
    public void testEqualsDifferentNestedAnnotationMember() {
        assertFalse(AnnotationUtils.equals(sampleOf(WithA.class), sampleOf(WithDiffMarker.class)));
    }

    @Test
    public void testEqualsNullAnnotationTypeThrowsNpe() {
        final Marker brokenTypeMarker = (Marker) Proxy.newProxyInstance(
                AnnotationUtilsAgentTest.class.getClassLoader(), new Class<?>[] {Marker.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(final Object proxy, final Method method, final Object[] args) {
                        if ("annotationType".equals(method.getName())) {
                            return null;
                        }
                        if ("name".equals(method.getName())) {
                            return "broken";
                        }
                        if ("hashCode".equals(method.getName())) {
                            return Integer.valueOf(System.identityHashCode(proxy));
                        }
                        if ("equals".equals(method.getName())) {
                            return Boolean.valueOf(proxy == args[0]);
                        }
                        return "brokenProxy";
                    }
                });
        final Marker realMarker = sampleOf(WithA.class).marker();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                AnnotationUtils.equals(brokenTypeMarker, realMarker);
            }
        });
    }

    // --- hashCode ---

    @Test
    public void testHashCodeMatchesRealAnnotationHashCode() {
        final Sample a = sampleOf(WithA.class);
        assertEquals(a.hashCode(), AnnotationUtils.hashCode(a));
    }

    @Test
    public void testHashCodeConsistentForEqualAnnotations() {
        final Sample a = sampleOf(WithA.class);
        final Sample a2 = sampleOf(WithA2.class);
        assertEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(a2));
    }

    @Test
    public void testHashCodeDiffersForDifferentValues() {
        final Sample a = sampleOf(WithA.class);
        final Sample diff = sampleOf(WithDiffStr.class);
        assertFalse(AnnotationUtils.hashCode(a) == AnnotationUtils.hashCode(diff));
    }

    @Test
    public void testHashCodeNullMemberThrowsIllegalState() {
        final Marker nullMemberMarker = (Marker) Proxy.newProxyInstance(
                AnnotationUtilsAgentTest.class.getClassLoader(), new Class<?>[] {Marker.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(final Object proxy, final Method method, final Object[] args) {
                        if ("annotationType".equals(method.getName())) {
                            return Marker.class;
                        }
                        if ("name".equals(method.getName())) {
                            return null;
                        }
                        if ("hashCode".equals(method.getName())) {
                            return Integer.valueOf(System.identityHashCode(proxy));
                        }
                        if ("equals".equals(method.getName())) {
                            return Boolean.valueOf(proxy == args[0]);
                        }
                        return "nullMemberProxy";
                    }
                });
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                AnnotationUtils.hashCode(nullMemberMarker);
            }
        });
    }

    // --- isValidAnnotationMemberType ---

    @Test
    public void testIsValidAnnotationMemberTypeNull() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    public void testIsValidAnnotationMemberTypePrimitive() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(boolean.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeWrapperIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Integer.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeString() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeClass() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeEnum() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(RetentionPolicy.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Sample.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypePrimitiveArray() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeStringArray() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeArbitraryObjectIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeArbitraryObjectArrayIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypePlainInterfaceIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Annotation.class));
    }

    // --- toString ---

    @Test
    public void testToStringContainsInterfaceNameAndMembers() {
        final String s = AnnotationUtils.toString(sampleOf(WithA.class));
        assertNotNull(s);
        assertTrue(s.startsWith("@" + Sample.class.getName() + "("));
        assertTrue(s.endsWith(")"));
        assertTrue(s.contains("str=a"));
        assertTrue(s.contains("num=1"));
    }

    @Test
    public void testToStringEqualForEqualAnnotations() {
        final String s1 = AnnotationUtils.toString(sampleOf(WithA.class));
        final String s2 = AnnotationUtils.toString(sampleOf(WithA2.class));
        assertEquals(s1, s2);
    }

    @Test
    public void testToStringDiffersForDifferentValues() {
        final String s1 = AnnotationUtils.toString(sampleOf(WithA.class));
        final String s2 = AnnotationUtils.toString(sampleOf(WithDiffStr.class));
        assertFalse(s1.equals(s2));
    }

    // --- constructor ---

    @Test
    public void testPublicConstructor() {
        assertNotNull(new AnnotationUtils());
    }
}
