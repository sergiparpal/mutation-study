/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Converter}.
 */
class ConverterAgentTest {

    /** A public class with a public no-arg constructor, for use with {@link Converter#OBJECT}. */
    public static final class Instantiable {
        // Intentionally empty.
    }

    /** A public class with only a private constructor, to trigger a reflective failure. */
    public static final class NotInstantiable {
        private NotInstantiable() {
        }
    }

    @Test
    void testApplyIsFunctionalInterfaceAllowingCheckedException() throws Exception {
        final Converter<Integer, ParseException> lengthOrFail = s -> {
            if (s.isEmpty()) {
                throw new ParseException("empty", 0);
            }
            return s.length();
        };
        assertEquals(3, lengthOrFail.apply("abc").intValue());
        assertThrows(ParseException.class, () -> lengthOrFail.apply(""));
    }

    @Test
    void testDefault() throws Exception {
        assertEquals("abc", Converter.DEFAULT.apply("abc"));
        assertEquals("", Converter.DEFAULT.apply(""));
        assertNull(Converter.DEFAULT.apply(null));
    }

    @Test
    void testClassValid() throws Exception {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    void testClassInvalidThrowsClassNotFoundException() {
        assertThrows(ClassNotFoundException.class, () -> Converter.CLASS.apply("org.apache.commons.cli.NoSuchClassAbcXyz"));
    }

    @Test
    void testFileValid() throws Exception {
        final File file = Converter.FILE.apply("foo.txt");
        assertEquals("foo.txt", file.getName());
    }

    @Test
    void testFileNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> Converter.FILE.apply(null));
    }

    @Test
    void testPathValid() throws Exception {
        final Path path = Converter.PATH.apply("foo/bar.txt");
        assertEquals("bar.txt", path.getFileName().toString());
    }

    @Test
    void testPathInvalidThrowsInvalidPathException() {
        assertThrows(InvalidPathException.class, () -> Converter.PATH.apply("foo\u0000bar"));
    }

    @Test
    void testNumberWithDecimalPointReturnsDouble() throws Exception {
        final Number number = Converter.NUMBER.apply("3.14");
        assertTrue(number instanceof Double);
        assertEquals(3.14d, number.doubleValue(), 0.0001d);
    }

    @Test
    void testNumberWithoutDecimalPointReturnsLong() throws Exception {
        final Number number = Converter.NUMBER.apply("42");
        assertTrue(number instanceof Long);
        assertEquals(42L, number.longValue());
    }

    @Test
    void testNumberNegativeLong() throws Exception {
        final Number number = Converter.NUMBER.apply("-7");
        assertTrue(number instanceof Long);
        assertEquals(-7L, number.longValue());
    }

    @Test
    void testNumberInvalidThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, () -> Converter.NUMBER.apply("not-a-number"));
    }

    @Test
    void testNumberMultipleDecimalPointsThrowsNumberFormatException() {
        // Contains a '.' so it is routed to Double.valueOf, which rejects the malformed value.
        assertThrows(NumberFormatException.class, () -> Converter.NUMBER.apply("1.2.3"));
    }

    @Test
    void testObjectValid() throws Exception {
        final Object obj = Converter.OBJECT.apply(Instantiable.class.getName());
        assertTrue(obj instanceof Instantiable);
    }

    @Test
    void testObjectUnknownClassThrowsReflectiveOperationException() {
        assertThrows(ReflectiveOperationException.class, () -> Converter.OBJECT.apply("org.apache.commons.cli.NoSuchClassAbcXyz"));
    }

    @Test
    void testObjectNoPublicConstructorThrowsReflectiveOperationException() {
        assertThrows(ReflectiveOperationException.class, () -> Converter.OBJECT.apply(NotInstantiable.class.getName()));
    }

    @Test
    void testUrlValid() throws Exception {
        final URL url = Converter.URL.apply("https://example.com/path");
        assertEquals("https", url.getProtocol());
        assertEquals("example.com", url.getHost());
        assertEquals("/path", url.getPath());
    }

    @Test
    void testUrlInvalidThrowsMalformedURLException() {
        assertThrows(MalformedURLException.class, () -> Converter.URL.apply("bogusproto://example.com"));
    }

    @Test
    void testDateValid() throws Exception {
        final Date date = Converter.DATE.apply("Thu Jan 01 00:00:00 UTC 1970");
        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.setTime(date);
        assertEquals(1970, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0L, date.getTime());
    }

    @Test
    void testDateInvalidThrowsParseException() {
        assertThrows(ParseException.class, () -> Converter.DATE.apply("not a date"));
    }

    @Test
    void testDateEmptyStringThrowsParseException() {
        assertThrows(ParseException.class, () -> Converter.DATE.apply(""));
    }

    @Test
    void testDistinctConvertersAreNotEqualToEachOther() {
        assertFalse(Converter.CLASS.equals(Converter.FILE));
    }
}
