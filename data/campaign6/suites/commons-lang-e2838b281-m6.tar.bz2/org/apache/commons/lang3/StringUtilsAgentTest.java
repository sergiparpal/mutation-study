/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    @Test
    public void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("abc"));

        assertFalse(StringUtils.isNotBlank("  "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    public void testIsAnyAllNoneEmptyBlank() {
        assertTrue(StringUtils.isAnyEmpty("abc", ""));
        assertFalse(StringUtils.isAnyEmpty("abc", "def"));
        assertFalse(StringUtils.isAnyEmpty());

        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "x"));
        assertTrue(StringUtils.isAllEmpty());

        assertTrue(StringUtils.isAnyBlank("abc", " "));
        assertFalse(StringUtils.isAnyBlank("abc", "def"));

        assertTrue(StringUtils.isAllBlank("", " ", null));
        assertFalse(StringUtils.isAllBlank("", "x"));

        assertTrue(StringUtils.isNoneEmpty("abc", "def"));
        assertFalse(StringUtils.isNoneEmpty("abc", ""));

        assertTrue(StringUtils.isNoneBlank("abc", "def"));
        assertFalse(StringUtils.isNoneBlank("abc", " "));
    }

    @Test
    public void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
    }

    @Test
    public void testEqualsAndCompare() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));

        assertTrue(StringUtils.equalsAny("abc", "def", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "def", "ghi"));

        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("a", "a"));

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compareIgnoreCase("a", "A") == 0);
    }

    @Test
    public void testIndexOfAndContains() {
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", "d"));
        assertEquals(1, StringUtils.indexOf("abc", "b"));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a", -1));

        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));

        assertFalse(StringUtils.contains(null, "a"));
        assertTrue(StringUtils.contains("abc", "a"));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase(null, "A"));

        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", 'z', 'y'));
        assertFalse(StringUtils.containsAny((String) null, 'a'));

        assertTrue(StringUtils.containsNone("abc", 'z', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly(null, 'a'));

        assertTrue(StringUtils.containsWhitespace("a b"));
        assertFalse(StringUtils.containsWhitespace("ab"));
    }

    @Test
    public void testSubstringBoundaries() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("bc", StringUtils.substring("abc", 1));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("", StringUtils.substring("abc", 10));
        assertEquals("a", StringUtils.substring("abc", -4, 1));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));

        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "x"));
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("abc", null));

        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));
        assertNull(StringUtils.substringBefore(null, "a"));

        assertEquals("aba", StringUtils.substringBetween("yabaz", "y", "z"));
        assertNull(StringUtils.substringBetween("abc", "x"));
    }

    @Test
    public void testLeftRightMid() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("abc", StringUtils.mid("abc", 0, 10));
        assertEquals("b", StringUtils.mid("abc", 1, 1));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    @Test
    public void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", -1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", -1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));

        assertNull(StringUtils.center(null, 4));
        assertEquals("  ab  ", StringUtils.center("ab", 6));
        assertEquals("ab", StringUtils.center("ab", -5));
    }

    @Test
    public void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new String[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new String[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertNull(StringUtils.join((Object[]) null, "-"));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));

        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c").iterator(), ','));
        assertEquals("", StringUtils.join(Arrays.asList().iterator(), ','));
    }

    @Test
    public void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));

        assertArrayEquals(new String[] {"a", "", "b"}, StringUtils.splitPreserveAllTokens("a..b", '.'));
        assertArrayEquals(new String[0], StringUtils.splitPreserveAllTokens(""));
        assertNull(StringUtils.splitPreserveAllTokens(null));

        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.splitByWholeSeparator("ab--cd", "--"));
        assertNull(StringUtils.splitByWholeSeparator(null, "-"));
    }

    @Test
    public void testReplaceAndRemove() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("zbcz", StringUtils.replace("abca", "a", "z"));
        assertEquals("zbca", StringUtils.replace("abca", "a", "z", 1));
        assertEquals("abca", StringUtils.replace("abca", "a", "z", 0));

        assertEquals("bc", StringUtils.remove("abca", 'a'));
        assertEquals("bc", StringUtils.remove("abca", "a"));
        assertNull(StringUtils.remove(null, 'a'));

        assertEquals("abc", StringUtils.removeStart("xxabc", "xx"));
        assertEquals("abc", StringUtils.removeStart("abc", "xx"));
        assertNull(StringUtils.removeStart(null, "xx"));

        assertEquals("abc", StringUtils.removeEnd("abcxx", "xx"));
        assertNull(StringUtils.removeEnd(null, "xx"));

        assertEquals("", StringUtils.replaceEach("", new String[] {"a"}, new String[] {"b"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
    }

    @Test
    public void testReplaceEachThrowsOnMismatchedArrayLengths() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEach("abc", new String[] {"a"}, new String[] {"b", "c"});
            }
        });
    }

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc", StringUtils.abbreviate("abc", 4));
        assertEquals("ab...", StringUtils.abbreviate("abcdefg", 5));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
    }

    @Test
    public void testAbbreviateThrowsOnTooSmallWidth() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testCapitalizeAndSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
    }

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    public void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("aaa", StringUtils.repeat('a', 3));
        assertEquals("", StringUtils.repeat('a', 0));
        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));
    }

    @Test
    public void testStartsWithEndsWith() {
        assertTrue(StringUtils.startsWith("abc", "ab"));
        assertFalse(StringUtils.startsWith("abc", "bc"));
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "a"));

        assertTrue(StringUtils.startsWithIgnoreCase("abc", "AB"));
        assertTrue(StringUtils.startsWithAny("abc", "xx", "ab"));
        assertFalse(StringUtils.startsWithAny("abc", "xx", "yy"));

        assertTrue(StringUtils.endsWith("abc", "bc"));
        assertFalse(StringUtils.endsWith("abc", "ab"));
        assertTrue(StringUtils.endsWithIgnoreCase("abc", "BC"));
        assertTrue(StringUtils.endsWithAny("abc", "xx", "bc"));
    }

    @Test
    public void testDefaultStringAndIfEmptyBlank() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("def", StringUtils.defaultIfEmpty("", "def"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "def"));

        assertEquals("def", StringUtils.defaultIfBlank("  ", "def"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "def"));
    }

    @Test
    public void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abcabc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(2, StringUtils.countMatches("abcabc", 'a'));
    }

    @Test
    public void testIsNumericAlphaAscii() {
        assertFalse(StringUtils.isNumeric(null));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric(""));

        assertFalse(StringUtils.isAlpha(null));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab1"));

        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("abc 123"));

        assertTrue(StringUtils.isAsciiPrintable("abc123!@#"));
        assertFalse(StringUtils.isAsciiPrintable("ab\nc"));
        assertFalse(StringUtils.isAsciiPrintable(null));
    }

    @Test
    public void testIsAllUpperLowerMixedCase() {
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));
        assertFalse(StringUtils.isAllUpperCase(null));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertTrue(StringUtils.isMixedCase("aBc"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "abcdef", 1));
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc", 1));
    }

    @Test
    public void testGetLevenshteinDistanceThrowsOnNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });
    }

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 4));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertEquals("", StringUtils.truncate("abcdefg", 0));
        assertEquals("cde", StringUtils.truncate("abcdefg", 2, 3));
    }

    @Test
    public void testTruncateThrowsOnNegativeMaxWidth() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });
    }

    @Test
    public void testTruncateThrowsOnNegativeOffset() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1, 2);
            }
        });
    }

    @Test
    public void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("xabcx", StringUtils.wrap("abc", 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));

        assertEquals("xabcx", StringUtils.wrapIfMissing("abc", 'x'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("xabcx", 'x'));

        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("abc", StringUtils.unwrap("xabcx", 'x'));
        assertEquals("abc", StringUtils.unwrap("abc", 'x'));
    }

    @Test
    public void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b  c "));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String) null));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd"));
        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abc"));
    }

    @Test
    public void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\n", StringUtils.chomp("abc\n\n"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    public void testOverlay() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertNull(StringUtils.overlay(null, "x", 0, 0));
    }

    @Test
    public void testDifference() {
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("c", StringUtils.difference("ab", "abc"));
        assertNull(StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference(null, "abc"));
    }

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    public void testFirstNonBlankEmpty() {
        assertNull(StringUtils.firstNonBlank());
        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));
        assertNull(StringUtils.firstNonEmpty((String[]) null));
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    public void testSameInstanceReturnedWhenUnchanged() {
        final String original = "no-op";
        assertSame(original, StringUtils.trim(original));
        assertSame(original, StringUtils.defaultString(original));
    }
}
