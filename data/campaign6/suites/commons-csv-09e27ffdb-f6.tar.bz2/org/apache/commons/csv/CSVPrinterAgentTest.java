/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVPrinter}.
 */
public class CSVPrinterAgentTest {

    /** An Appendable that is neither Flushable nor Closeable, to check CSVPrinter does not assume either. */
    private static final class PlainAppendable implements Appendable {
        private final StringBuilder sb = new StringBuilder();

        @Override
        public Appendable append(final char c) {
            sb.append(c);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq) {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    private static final class CountingWriter extends StringWriter {
        private int flushCount;
        private boolean closed;

        @Override
        public void flush() {
            flushCount++;
            super.flush();
        }

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }
    }

    @Test
    public void testConstructorRejectsNullAppendable() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testConstructorRejectsNullFormat() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringWriter(), null);
            }
        });
    }

    @Test
    public void testGetOutReturnsGivenAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
    }

    @Test
    public void testPrintSimpleValueNoQuotingNeeded() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("abc");
        assertEquals("abc", sw.toString());
    }

    @Test
    public void testPrintNullValueIsEmptyByDefault() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        printer.print("x");
        assertEquals(",x", sw.toString());
    }

    @Test
    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
    }

    @Test
    public void testPrintlnWritesRecordSeparatorAndResetsNewRecordFlagButNotCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.println();
        assertEquals("\r\n", sw.toString());
        // println() alone does not count as a printed record.
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordObjectArrayIncrementsRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordEmptyArrayStillTerminatesRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsIterableOfArraysPrintsOneRecordPerElement() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B", "C" });
        data.add(new String[] { "1", "2", "3" });
        printer.printRecords(data);
        assertEquals("A,B,C\r\n1,2,3\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsObjectArrayOfArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords((Object[]) new String[][] { { "A", "B" }, { "1", "2" } });
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsFlatIterablePrintsSingleRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(Arrays.asList("a", "b", "c"));
        assertEquals("a,b,c\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentDoesNothingWhenCommentMarkerNotSet() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentDoesNothingWhenCommentIsNull() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentSingleLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sw.toString());
        // A comment is not a record.
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentMultiLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("a\nb");
        assertEquals("# a\r\n# b\r\n", sw.toString());
    }

    @Test
    public void testPrintCommentAfterPartialRecordStartsOnNewLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("value");
        printer.printComment("note");
        assertEquals("value\r\n# note\r\n", sw.toString());
    }

    @Test
    public void testHeaderIsPrintedOnConstruction() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("h1", "h2").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("h1,h2\r\n", sw.toString());
        printer.printRecord("v1", "v2");
        assertEquals("h1,h2\r\nv1,v2\r\n", sw.toString());
    }

    @Test
    public void testSkipHeaderRecordSuppressesHeaderOutput() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("h1", "h2").setSkipHeaderRecord(true).get();
        new CSVPrinter(sw, format);
        assertEquals("", sw.toString());
    }

    @Test
    public void testHeaderCommentsArePrintedOnConstructionAndNotCountedAsRecords() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("top comment").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("# top comment\r\n", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    /**
     * {@link CSVPrinter#getRecordCount()} is documented to not include the header record. The constructor
     * prints the header via {@link CSVPrinter#printRecord(Object...)}, which increments the record count,
     * so the count wrongly includes the header record.
     */
    @Test
    public void testRecordCountExcludesHeaderRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("h1", "h2").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        // Only the header has been printed so far; per the getRecordCount() Javadoc this must not count.
        assertEquals(0, printer.getRecordCount());
        printer.printRecord("v1", "v2");
        // Exactly one real record has been printed.
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testCloseWithoutFlushDoesNotFlushUnderlyingFlushable() throws IOException {
        final CountingWriter writer = new CountingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close(false);
        assertEquals(0, writer.flushCount);
        assertTrue(writer.closed);
    }

    @Test
    public void testCloseWithFlushFlushesUnderlyingFlushable() throws IOException {
        final CountingWriter writer = new CountingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close(true);
        assertEquals(1, writer.flushCount);
        assertTrue(writer.closed);
    }

    @Test
    public void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final PlainAppendable appendable = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.print("x");
        printer.close();
        assertEquals("x", appendable.toString());
    }

    @Test
    public void testFlushOnNonFlushableAppendableDoesNotThrow() throws IOException {
        final PlainAppendable appendable = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.flush();
        assertEquals("", appendable.toString());
    }

    @Test
    public void testPrintRecordResultSet() throws IOException, SQLException, ClassNotFoundException {
        Class.forName("org.h2.Driver", false, CSVPrinterAgentTest.class.getClassLoader());
        final Connection connection = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest1");
        try {
            final Statement stmt = connection.createStatement();
            try {
                stmt.execute("CREATE TABLE T (ID INT, NAME VARCHAR(20))");
                stmt.execute("INSERT INTO T VALUES (1, 'Alice')");
                stmt.execute("INSERT INTO T VALUES (2, 'Bob')");
            } finally {
                stmt.close();
            }
            final Statement queryStmt = connection.createStatement();
            try {
                final ResultSet rs = queryStmt.executeQuery("SELECT ID, NAME FROM T ORDER BY ID");
                try {
                    final StringWriter sw = new StringWriter();
                    final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
                    printer.printRecords(rs);
                    assertEquals("1,Alice\r\n2,Bob\r\n", sw.toString());
                    assertEquals(2, printer.getRecordCount());
                } finally {
                    rs.close();
                }
            } finally {
                queryStmt.close();
            }
        } finally {
            connection.close();
        }
    }

    @Test
    public void testPrintRecordsResultSetWithHeader() throws IOException, SQLException, ClassNotFoundException {
        Class.forName("org.h2.Driver", false, CSVPrinterAgentTest.class.getClassLoader());
        final Connection connection = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest2");
        try {
            final Statement stmt = connection.createStatement();
            try {
                stmt.execute("CREATE TABLE T (ID INT, NAME VARCHAR(20))");
                stmt.execute("INSERT INTO T VALUES (1, 'Alice')");
            } finally {
                stmt.close();
            }
            final Statement queryStmt = connection.createStatement();
            try {
                final ResultSet rs = queryStmt.executeQuery("SELECT ID, NAME FROM T");
                try {
                    final StringWriter sw = new StringWriter();
                    final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
                    printer.printRecords(rs, true);
                    assertEquals("ID,NAME\r\n1,Alice\r\n", sw.toString());
                } finally {
                    rs.close();
                }
            } finally {
                queryStmt.close();
            }
        } finally {
            connection.close();
        }
    }

    @Test
    public void testPrintQuoteModeAllQuotesEveryValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b");
        assertEquals("\"a\",\"b\"\r\n", sw.toString());
    }

    @Test
    public void testPrintEscapesEmbeddedQuoteCharacter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sw.toString());
    }

    @Test
    public void testMultipleRecordsAccumulateRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a");
        printer.printRecord("b");
        printer.printRecord("c");
        assertEquals(3, printer.getRecordCount());
        assertFalse(sw.toString().isEmpty());
    }
}
