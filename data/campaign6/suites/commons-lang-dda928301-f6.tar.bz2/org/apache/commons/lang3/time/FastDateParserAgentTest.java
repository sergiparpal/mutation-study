/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.lang3.SerializationUtils;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static FastDateParser newParser(final String pattern) {
        return new FastDateParser(pattern, GMT, Locale.US);
    }

    private static FastDateParser newParser(final String pattern, final Locale locale) {
        return new FastDateParser(pattern, GMT, locale);
    }

    private static Calendar newCalendar() {
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        return cal;
    }

    // --- basic parsing -----------------------------------------------------

    @Test
    void testParseBasicIsoDate() throws ParseException {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        final Date actual = fdp.parse("2017-06-23");
        final Calendar expected = newCalendar();
        expected.set(2017, Calendar.JUNE, 23);
        assertEquals(expected.getTime(), actual);
    }

    @Test
    void testParseWithParsePositionReturnsNullAndSetsErrorIndexOnMismatch() {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date actual = fdp.parse("2017/06/23", pos);
        assertNull(actual);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testParseThrowsParseExceptionWithUnparseableMessage() {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        final ParseException ex = assertThrows(ParseException.class, () -> fdp.parse("not a date"));
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertTrue(ex.getMessage().contains("not a date"));
    }

    @Test
    void testParseWithParsePositionDoesNotRequireFullConsumption() throws ParseException {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date actual = fdp.parse("2017-06-23 and then some extra text", pos);
        assertNotNull(actual);
        assertEquals(10, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());
        final Date expected = fdp.parse("2017-06-23");
        assertEquals(expected, actual);
    }

    @Test
    void testCalendarParseStopsAtFailedFieldAndLeavesPartialState() {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        final Calendar calendar = newCalendar();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = fdp.parse("2024-AA-01", pos, calendar);
        assertFalse(success);
        // error index should point at (or before) the failed MM field, not after it
        assertEquals(5, pos.getErrorIndex());
        // the YEAR field, parsed successfully before the failure, remains set on the calendar
        assertEquals(2024, calendar.get(Calendar.YEAR));
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        final Object viaParseObject = fdp.parseObject("2017-06-23");
        final Object viaParse = fdp.parse("2017-06-23");
        assertEquals(viaParse, viaParseObject);
        final ParsePosition pos1 = new ParsePosition(0);
        final ParsePosition pos2 = new ParsePosition(0);
        assertEquals(fdp.parse("2017-06-23", pos1), fdp.parseObject("2017-06-23", pos2));
        assertEquals(pos1.getIndex(), pos2.getIndex());
    }

    // --- getters / equals / hashCode / toString -----------------------------

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDateParser fdp = new FastDateParser("yyyy-MM-dd", GMT, Locale.UK);
        assertEquals("yyyy-MM-dd", fdp.getPattern());
        assertEquals(Locale.UK, fdp.getLocale());
        assertEquals(GMT, fdp.getTimeZone());
    }

    @Test
    void testNullLocaleDefaultsToSystemLocale() {
        final FastDateParser fdp = new FastDateParser("yyyy-MM-dd", GMT, null);
        assertEquals(Locale.getDefault(), fdp.getLocale());
    }

    @Test
    void testEqualsReflexiveAndSymmetric() {
        final FastDateParser a = newParser("yyyy-MM-dd");
        final FastDateParser b = newParser("yyyy-MM-dd");
        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(b, a);
    }

    @Test
    void testEqualsDifferingInPatternTimeZoneOrLocaleAreNotEqual() {
        final FastDateParser base = newParser("yyyy-MM-dd");
        assertNotEquals(base, newParser("yyyy/MM/dd"));
        assertNotEquals(base, new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/Los_Angeles"), Locale.US));
        assertNotEquals(base, newParser("yyyy-MM-dd", Locale.FRANCE));
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final FastDateParser fdp = newParser("yyyy-MM-dd");
        assertNotEquals(null, fdp);
        assertNotEquals("yyyy-MM-dd", fdp);
    }

    @Test
    void testHashCodeConsistentWithEquals() {
        final FastDateParser a = newParser("yyyy-MM-dd");
        final FastDateParser b = newParser("yyyy-MM-dd");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testToString() {
        final FastDateParser fdp = new FastDateParser("yyyy-MM-dd", GMT, Locale.UK);
        final String str = fdp.toString();
        assertEquals("FastDateParser[yyyy-MM-dd, en_GB, GMT]", str);
    }

    // --- pattern compilation errors -----------------------------------------

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> newParser("yyyy-qq"));
        assertTrue(ex.getMessage().contains("'q'"));
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> newParser("yyyy'MM"));
        assertTrue(ex.getMessage().contains("Unterminated quote"));
    }

    @Test
    void testInvalidIsoTimeZoneWidthThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> newParser("yyyy-MM-dd'T'HH:mm:ssXXXX"));
        assertTrue(ex.getMessage().contains("Invalid number of X"));
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> new FastDateParser(null, GMT, Locale.US));
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> new FastDateParser("yyyy-MM-dd", null, Locale.US));
    }

    // --- two digit year handling --------------------------------------------

    @Test
    void testTwoDigitYearCenturyAdjustment() throws ParseException {
        // centuryStart = 1950-01-01 -> century window is [1950, 2050)
        final Calendar centuryStartCal = newCalendar();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final FastDateParser fdp = new FastDateParser("yy-MM-dd", GMT, Locale.US, centuryStartCal.getTime());

        final Calendar expected49 = newCalendar();
        expected49.set(2049, Calendar.JANUARY, 1);
        assertEquals(expected49.getTime(), fdp.parse("49-01-01"));

        final Calendar expected50 = newCalendar();
        expected50.set(1950, Calendar.JANUARY, 1);
        assertEquals(expected50.getTime(), fdp.parse("50-01-01"));

        final Calendar expected99 = newCalendar();
        expected99.set(1999, Calendar.JANUARY, 1);
        assertEquals(expected99.getTime(), fdp.parse("99-01-01"));
    }

    @Test
    void testThreeOrMoreDigitYearIsNotCenturyAdjusted() throws ParseException {
        final FastDateParser fdp = newParser("yyy-MM-dd");
        final Date actual = fdp.parse("020-01-01");
        final Calendar expected = newCalendar();
        expected.set(20, Calendar.JANUARY, 1);
        assertEquals(expected.getTime(), actual);
    }

    // --- numeric field width handling ---------------------------------------

    @Test
    void testAdjacentNumericFieldsRespectDeclaredWidth() throws ParseException {
        final FastDateParser fdp = newParser("yyyyMMdd");
        final Date actual = fdp.parse("20240115");
        final Calendar expected = newCalendar();
        expected.set(2024, Calendar.JANUARY, 15);
        assertEquals(expected.getTime(), actual);
    }

    @Test
    void testLeadingWhitespaceAllowedWhenFieldIsUnconstrained() {
        final FastDateParser fdp = newParser("dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date actual = fdp.parse(" 5", pos);
        assertNotNull(actual);
        assertEquals(2, pos.getIndex());
        final Calendar cal = newCalendar();
        cal.setTime(actual);
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testLeadingWhitespaceRejectedWhenFieldWidthIsConstrained() {
        final FastDateParser fdp = newParser("yyyyMM");
        final ParsePosition pos = new ParsePosition(0);
        final Date actual = fdp.parse(" 202401", pos);
        assertNull(actual);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testOverflowingDigitRunFailsParseInsteadOfThrowing() {
        final FastDateParser fdp = newParser("yyyy");
        final ParsePosition pos = new ParsePosition(0);
        final Date actual = fdp.parse("999999999999999999990", pos);
        assertNull(actual);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    // --- literal / quoted text -----------------------------------------------

    @Test
    void testEscapedQuoteLiteralIsMatched() throws ParseException {
        final FastDateParser fdp = newParser("yyyy''MM");
        final Date actual = fdp.parse("2024'01");
        final Calendar expected = newCalendar();
        expected.set(2024, Calendar.JANUARY, 1);
        assertEquals(expected.getTime(), actual);
    }

    // --- locale specific text fields -----------------------------------------

    @Test
    void testCaseInsensitiveMonthNameMatchesRegardlessOfCase() throws ParseException {
        final FastDateParser fdp = newParser("MMMM yyyy", Locale.UK);
        final Date lower = fdp.parse("january 2020");
        final Date upper = fdp.parse("JANUARY 2020");
        final Date mixed = fdp.parse("January 2020");
        final Calendar expected = newCalendar();
        expected.set(2020, Calendar.JANUARY, 1);
        assertEquals(expected.getTime(), lower);
        assertEquals(expected.getTime(), upper);
        assertEquals(expected.getTime(), mixed);
    }

    @Test
    void testTrailingPeriodIsOptionalForAbbreviatedTextField() throws ParseException {
        final FastDateParser fdp = newParser("MMM yyyy", new Locale("es"));
        // Spanish short month names have a trailing period, e.g. "ene.", but FastDateParser should
        // also accept the name without the trailing period.
        final Date withoutPeriod = fdp.parse("ene 2020");
        final Date withPeriod = fdp.parse("ene. 2020");
        final Calendar expected = newCalendar();
        expected.set(2020, Calendar.JANUARY, 1);
        assertEquals(expected.getTime(), withoutPeriod);
        assertEquals(expected.getTime(), withPeriod);
    }

    // --- hour strategies and their boundary modifications --------------------

    @Test
    void testHour12StrategyMapsTwelveToZero() throws ParseException {
        final FastDateParser fdp = newParser("hh:mm a");
        final Date midnight = fdp.parse("12:00 AM");
        final Date noon = fdp.parse("12:00 PM");
        final Calendar cal = newCalendar();
        cal.setTime(midnight);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
        cal.setTime(noon);
        assertEquals(12, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHour24StrategyMapsTwentyFourToZero() throws ParseException {
        final FastDateParser fdp = newParser("kk:mm");
        final Date actual = fdp.parse("24:00");
        final Calendar cal = newCalendar();
        cal.setTime(actual);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    // --- ISO-8601 time zone offsets -------------------------------------------

    @Test
    void testIso8601SingleHourOffsetAdjustsInstant() throws ParseException {
        final FastDateParser fdp = newParser("yyyy-MM-dd'T'HH:mm:ssX");
        final Date actual = fdp.parse("2020-01-01T10:00:00+05");
        final Calendar expected = new GregorianCalendar(TimeZone.getTimeZone("GMT+05:00"), Locale.US);
        expected.clear();
        expected.set(2020, Calendar.JANUARY, 1, 10, 0, 0);
        assertEquals(expected.getTime(), actual);
    }

    @Test
    void testTwoLetterZPatternAcceptsRfc822FormatLikeSimpleDateFormat() throws ParseException {
        // Per the class javadoc, "all patterns are compatible with SimpleDateFormat". SimpleDateFormat
        // treats 1, 2 and 3 'Z' letters identically: RFC 822 format, e.g. "-0800" (no colon).
        final String pattern = "yyyy-MM-dd'T'HH:mm:ssZZ";
        final String input = "2020-01-01T10:00:00-0800";
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(GMT);
        final Date expected = sdf.parse(input);
        final FastDateParser fdp = newParser(pattern);
        final Date actual = fdp.parse(input);
        assertEquals(expected, actual);
    }

    // --- 'u' ISO day-of-week strategy boundaries ------------------------------

    @Test
    void testIsoDayOfWeekStrategyMapsMondayAndSunday() throws ParseException {
        final FastDateParser fdp = newParser("yyyy-'W'ww-u");

        final Calendar expectedMonday = newCalendar();
        expectedMonday.set(Calendar.YEAR, 2024);
        expectedMonday.set(Calendar.WEEK_OF_YEAR, 1);
        expectedMonday.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

        final Calendar expectedSunday = newCalendar();
        expectedSunday.set(Calendar.YEAR, 2024);
        expectedSunday.set(Calendar.WEEK_OF_YEAR, 1);
        expectedSunday.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

        assertEquals(expectedMonday.getTime(), fdp.parse("2024-W01-1"));
        assertEquals(expectedSunday.getTime(), fdp.parse("2024-W01-7"));
    }

    // --- named time zone text (locale specific zone strategy) ----------------

    @Test
    void testNamedTimeZoneStandardTimeMatchesSimpleDateFormat() throws ParseException {
        final String pattern = "zzzz yyyy-MM-dd HH:mm";
        final String input = "Pacific Standard Time 2020-01-15 10:00";
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(GMT);
        final FastDateParser fdp = newParser(pattern);
        assertEquals(sdf.parse(input), fdp.parse(input));
    }

    @Test
    void testNamedTimeZoneDaylightTimeMatchesSimpleDateFormat() throws ParseException {
        final String pattern = "zzzz yyyy-MM-dd HH:mm";
        final String input = "Pacific Daylight Time 2020-07-15 10:00";
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(GMT);
        final FastDateParser fdp = newParser(pattern);
        assertEquals(sdf.parse(input), fdp.parse(input));
    }

    // --- JAPANESE_IMPERIAL locale specific error message ----------------------

    @Test
    void testJapaneseImperialLocaleProducesSpecificErrorMessage() {
        final FastDateParser fdp = new FastDateParser("yyyy-MM-dd", GMT, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, () -> fdp.parse("not a date"));
        assertTrue(ex.getMessage().contains("does not support dates before 1868-01-01"));
    }

    // --- serialization ---------------------------------------------------------

    @Test
    void testSerializationRoundTripPreservesStateAndBehaviour() throws ParseException {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", GMT, Locale.UK);
        final FastDateParser copy = SerializationUtils.roundtrip(original);
        assertEquals(original, copy);
        assertEquals(original.getPattern(), copy.getPattern());
        assertEquals(original.getTimeZone(), copy.getTimeZone());
        assertEquals(original.getLocale(), copy.getLocale());
        assertEquals(original.parse("2017-06-23"), copy.parse("2017-06-23"));
    }

    // --- package-private helper on the nested TimeZoneStrategy class -----------

    @Test
    void testSkipTimeZoneHelperIdentifiesOnlyGmt() {
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("GMT"));
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("gmt"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("PST"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("UTC"));
    }
}
