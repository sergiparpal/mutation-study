/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    interface Interface1 {
        // empty
    }

    interface Interface2 extends Interface1 {
        // empty
    }

    interface Interface3 {
        // empty
    }

    static class Parent implements Interface2 {
        // empty
    }

    static class Child extends Parent implements Interface3 {
        // empty
    }

    public interface PubInterface {
        String foo();
    }

    private static class PrivateImpl implements PubInterface {
        @Override
        public String foo() {
            return "foo";
        }
    }

    static class StaticNested {
        // empty
    }

    // ----- getAbbreviatedName -----

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameNonPositiveLengthHintThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", 0));
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", -1));
    }

    @Test
    public void testGetAbbreviatedNameExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameExactLengthUnchanged() {
        final String name = "java.lang.String";
        assertEquals(name, ClassUtils.getAbbreviatedName(name, name.length()));
    }

    @Test
    public void testGetAbbreviatedNameClassDelegates() {
        assertEquals(ClassUtils.getAbbreviatedName(String.class.getName(), 5), ClassUtils.getAbbreviatedName(String.class, 5));
    }

    // ----- getAllInterfaces / getAllSuperclasses -----

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfacesOrderAndDeduplication() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Child.class);
        assertEquals(Arrays.asList(Interface3.class, Interface2.class, Interface1.class), interfaces);
    }

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclassesOrder() {
        assertEquals(Arrays.asList(Parent.class, Object.class), ClassUtils.getAllSuperclasses(Child.class));
    }

    @Test
    public void testGetAllSuperclassesOfObject() {
        assertEquals(new ArrayList<Class<?>>(), ClassUtils.getAllSuperclasses(Object.class));
    }

    // ----- getCanonicalName -----

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
    }

    // ----- getClass -----

    @Test
    public void testGetClassPrimitive() throws ClassNotFoundException {
        assertSame(int.class, ClassUtils.getClass("int"));
        assertSame(void.class, ClassUtils.getClass("void"));
    }

    @Test
    public void testGetClassArraySyntaxes() throws ClassNotFoundException {
        assertSame(int[].class, ClassUtils.getClass("[I"));
        assertSame(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
    }

    @Test
    public void testGetClassInnerClassSyntaxes() throws ClassNotFoundException {
        assertSame(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertSame(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    public void testGetClassNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getClass((String) null));
    }

    @Test
    public void testGetClassEmptyThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getClass(""));
    }

    @Test
    public void testGetClassNotFoundThrowsClassNotFoundException() {
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass("com.example.DoesNotExistReallyNotAtAll"));
    }

    @Test
    public void testGetClassNameTooLongThrowsIllegalArgumentException() {
        final StringBuilder sb = new StringBuilder(65536);
        for (int i = 0; i < 65536; i++) {
            sb.append('a');
        }
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getClass(sb.toString()));
    }

    @Test
    public void testGetClassArrayDimensionTooManyThrowsIllegalArgumentException() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.String;");
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getClass(sb.toString()));
    }

    @Test
    public void testGetClassArrayDimensionAtMaxDoesNotThrowIllegalArgument() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 255; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.String;");
        try {
            ClassUtils.getClass(sb.toString());
        } catch (final IllegalArgumentException e) {
            throw new AssertionError("255 array dimensions should not be rejected as invalid", e);
        } catch (final ClassNotFoundException e) {
            // acceptable: the JVM itself may still refuse to load such a deeply nested array type
        }
    }

    // ----- getComponentType -----

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertSame(String.class, ClassUtils.getComponentType(String[].class));
    }

    // ----- getName -----

    @Test
    public void testGetNameClass() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
        assertEquals("[Ljava.lang.String;", ClassUtils.getName(String[].class));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
    }

    // ----- getPackageName / getPackageCanonicalName -----

    @Test
    public void testGetPackageNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
        assertEquals("java.lang", ClassUtils.getPackageName("[[Ljava.lang.String;"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
    }

    // ----- getPublicMethod -----

    @Test
    public void testGetPublicMethodFromPrivateImplResolvesToInterface() throws NoSuchMethodException {
        final Method method = ClassUtils.getPublicMethod(PrivateImpl.class, "foo");
        assertEquals(PubInterface.class, method.getDeclaringClass());
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
    }

    @Test
    public void testGetPublicMethodNotFoundThrows() {
        assertThrows(NoSuchMethodException.class, () -> ClassUtils.getPublicMethod(String.class, "noSuchMethodHere"));
    }

    @Test
    public void testGetPublicMethodNullClassThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getPublicMethod(null, "toString"));
    }

    // ----- getShortCanonicalName -----

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
    }

    // ----- getShortClassName -----

    @Test
    public void testGetShortClassNameExamples() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(java.util.Map.Entry.class.getName()));
        assertEquals("Entry", ClassUtils.getShortClassName(java.util.Map.Entry.class.getCanonicalName()));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortClassName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortClassName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[]", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils[]"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class.getCanonicalName()));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class.getName()));
        assertEquals("int[][]", ClassUtils.getShortClassName("[[I"));
    }

    @Test
    public void testGetShortClassNameClassAndObject() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "NULL"));
    }

    // ----- getSimpleName -----

    @Test
    public void testGetSimpleName() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
    }

    // ----- hierarchy -----

    @Test
    public void testHierarchyExcludeInterfaces() {
        final List<Class<?>> list = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(Child.class)) {
            list.add(c);
        }
        assertEquals(Arrays.asList(Child.class, Parent.class, Object.class), list);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> list = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(Child.class, ClassUtils.Interfaces.INCLUDE)) {
            list.add(c);
        }
        assertEquals(Arrays.asList(Child.class, Interface3.class, Parent.class, Interface2.class, Interface1.class, Object.class), list);
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class).iterator();
        it.next();
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    // ----- isAssignable -----

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, float.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertFalse(ClassUtils.isAssignable(short.class, byte.class));
        assertFalse(ClassUtils.isAssignable(char.class, byte.class));
        assertTrue(ClassUtils.isAssignable(char.class, int.class));
    }

    @Test
    public void testIsAssignableNulls() {
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, (Class<?>) null));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
        assertFalse(ClassUtils.isAssignable(int.class, Long.class, true));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { int.class, String.class }, new Class<?>[] { long.class, Object.class }));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { int.class }, new Class<?>[] { int.class, int.class }));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    // ----- isInnerClass -----

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(Object.class));
        assertTrue(ClassUtils.isInnerClass(StaticNested.class));
        class Local {
            // empty
        }
        assertTrue(ClassUtils.isInnerClass(Local.class));
    }

    // ----- isPrimitiveOrWrapper / isPrimitiveWrapper -----

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    // ----- isPublic -----

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateImpl.class));
        assertThrows(NullPointerException.class, () -> ClassUtils.isPublic(null));
    }

    // ----- primitiveToWrapper / primitivesToWrappers -----

    @Test
    public void testPrimitiveToWrapper() {
        assertSame(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertSame(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(3, result.length);
        assertSame(Integer.class, result[0]);
        assertSame(String.class, result[1]);
        assertNull(result[2]);
    }

    // ----- wrapperToPrimitive / wrappersToPrimitives -----

    @Test
    public void testWrapperToPrimitive() {
        assertSame(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(3, result.length);
        assertSame(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    // ----- toClass -----

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("foo", null, 123);
        assertEquals(3, result.length);
        assertSame(String.class, result[0]);
        assertNull(result[1]);
        assertSame(Integer.class, result[2]);
    }

    // ----- convertClassesToClassNames / convertClassNamesToClasses -----

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> classes = new ArrayList<>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(Arrays.asList("java.lang.String", null), names);
    }

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = Arrays.asList("java.lang.String", null, "not.a.real.ClassName");
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(Arrays.asList(String.class, null, null), classes);
    }

    @Test
    public void testConvertClassNamesToClassesDoesNotResolvePrimitives() {
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(Arrays.asList("int"));
        assertEquals(1, classes.size());
        assertNull(classes.get(0));
    }

    // ----- comparator -----

    @Test
    public void testComparator() {
        assertTrue(ClassUtils.comparator().compare(Integer.class, String.class) < 0);
        assertEquals(0, ClassUtils.comparator().compare(String.class, String.class));
        assertTrue(ClassUtils.comparator().compare(null, String.class) < 0);
    }

    // ----- getPrimitiveClass (package-private) -----

    @Test
    public void testGetPrimitiveClass() {
        assertSame(int.class, ClassUtils.getPrimitiveClass("int"));
        assertSame(void.class, ClassUtils.getPrimitiveClass("void"));
        assertNull(ClassUtils.getPrimitiveClass("notAPrimitive"));
        assertNull(ClassUtils.getPrimitiveClass(null));
    }

    // ----- constants -----

    @Test
    public void testConstants() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    // ----- constructor -----

    @Test
    public void testConstructorIsUsable() {
        assertNotNull(new ClassUtils());
    }
}
