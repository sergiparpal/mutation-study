/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;

class OptionsAgentTest {

    @Test
    void testAddOptionWithShortNameOnly() {
        final Options options = new Options();
        final Options result = options.addOption("a", false, "a description");
        assertTrue(result == options);
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasShortOption("a"));
        assertFalse(options.hasLongOption("a"));
        final Option option = options.getOption("a");
        assertEquals("a", option.getOpt());
        assertFalse(option.hasArg());
        assertEquals("a description", option.getDescription());
    }

    @Test
    void testAddOptionShortNameAndDescriptionOnly() {
        final Options options = new Options();
        options.addOption("b", "b description");
        final Option option = options.getOption("b");
        assertFalse(option.hasArg());
        assertEquals("b description", option.getDescription());
    }

    @Test
    void testAddOptionWithLongName() {
        final Options options = new Options();
        options.addOption("c", "cat", true, "cat description");
        assertTrue(options.hasShortOption("c"));
        assertTrue(options.hasLongOption("cat"));
        // the same Option should be returned for either lookup
        assertTrue(options.getOption("c") == options.getOption("cat"));
        assertTrue(options.getOption("--cat").hasArg());
    }

    @Test
    void testAddOptionInstance() {
        final Options options = new Options();
        final Option opt = new Option("d", "dog", false, "dog description");
        final Options result = options.addOption(opt);
        assertTrue(result == options);
        assertTrue(options.getOptions().contains(opt));
    }

    @Test
    void testAddOptionOverwritesExistingShortOption() {
        final Options options = new Options();
        options.addOption("e", false, "first");
        options.addOption("e", true, "second");
        final Option option = options.getOption("e");
        assertEquals("second", option.getDescription());
        assertTrue(option.hasArg());
        // the collection of options should still only contain one "e" option
        assertEquals(1, options.getOptions().size());
    }

    @Test
    void testAddRequiredOption() {
        final Options options = new Options();
        options.addRequiredOption("f", "foo", true, "foo description");
        final Option option = options.getOption("f");
        assertTrue(option.isRequired());
        assertEquals(1, options.getRequiredOptions().size());
        assertEquals("f", options.getRequiredOptions().get(0));
    }

    @Test
    void testRequiredOptionIsNotDuplicatedWhenReAdded() {
        final Options options = new Options();
        options.addRequiredOption("g", null, false, "g description");
        options.addOption(new Option("g", null, false, "g description again") {
            private static final long serialVersionUID = 1L;
        });
        // re-adding "g" (now not required) should remove the old required entry, not duplicate it
        final Option replacement = options.getOption("g");
        replacement.setRequired(true);
        options.addOption(replacement);
        assertEquals(1, options.getRequiredOptions().size());
    }

    @Test
    void testGetOptionReturnsNullWhenAbsent() {
        final Options options = new Options();
        assertNull(options.getOption("zzz"));
    }

    @Test
    void testGetOptionStripsLeadingHyphens() {
        final Options options = new Options();
        options.addOption("h", "hat", false, "hat description");
        assertTrue(options.getOption("-h") == options.getOption("h"));
        assertTrue(options.getOption("--hat") == options.getOption("hat"));
    }

    @Test
    void testHasOptionFalseForUnknown() {
        final Options options = new Options();
        assertFalse(options.hasOption("nope"));
        assertFalse(options.hasShortOption("nope"));
        assertFalse(options.hasLongOption("nope"));
    }

    @Test
    void testGetMatchingOptionsNullOrEmptyReturnsEmptyList() {
        final Options options = new Options();
        options.addOption("i", "item", false, "item description");
        assertTrue(options.getMatchingOptions(null).isEmpty());
        assertTrue(options.getMatchingOptions("").isEmpty());
    }

    @Test
    void testGetMatchingOptionsExactMatchReturnsSingleEntry() {
        final Options options = new Options();
        options.addOption("i", "item", false, "item description");
        options.addOption("j", "itemize", false, "itemize description");
        final List<String> matches = options.getMatchingOptions("item");
        assertEquals(1, matches.size());
        assertEquals("item", matches.get(0));
    }

    @Test
    void testGetMatchingOptionsPartialMatchReturnsAllPrefixed() {
        final Options options = new Options();
        options.addOption("i", "item", false, "item description");
        options.addOption("j", "itemize", false, "itemize description");
        options.addOption("k", "other", false, "other description");
        final List<String> matches = options.getMatchingOptions("ite");
        assertEquals(2, matches.size());
        assertTrue(matches.contains("item"));
        assertTrue(matches.contains("itemize"));
    }

    @Test
    void testGetMatchingOptionsNoMatchReturnsEmptyList() {
        final Options options = new Options();
        options.addOption("k", "other", false, "other description");
        assertTrue(options.getMatchingOptions("zzz").isEmpty());
    }

    @Test
    void testAddOptionGroupMarksOptionsOptionalAndTracksGroup() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option opt1 = new Option("l", null, false, "l description");
        opt1.setRequired(true);
        final Option opt2 = new Option("m", null, false, "m description");
        group.addOption(opt1);
        group.addOption(opt2);
        group.setRequired(true);

        final Options result = options.addOptionGroup(group);
        assertTrue(result == options);

        // options in a group must never be required individually
        assertFalse(options.getOption("l").isRequired());
        assertFalse(options.getOption("m").isRequired());

        // the group itself is tracked as a required entry
        assertTrue(options.getRequiredOptions().contains(group));

        assertTrue(options.getOptionGroup(options.getOption("l")) == group);
        assertTrue(options.getOptionGroups().contains(group));
    }

    @Test
    void testAddOptionGroupRemovesPriorRequiredFlagForMember() {
        final Options options = new Options();
        options.addRequiredOption("n", null, false, "n description");
        assertTrue(options.getRequiredOptions().contains("n"));

        final OptionGroup group = new OptionGroup();
        group.addOption(options.getOption("n"));
        options.addOptionGroup(group);

        // the plain "n" required marker must be gone, replaced by nothing (group isn't required here)
        assertFalse(options.getRequiredOptions().contains("n"));
        assertFalse(options.getOption("n").isRequired());
    }

    @Test
    void testAddOptionsCopiesOptionsAndGroups() {
        final Options source = new Options();
        source.addOption("o", "oscar", false, "oscar description");
        final OptionGroup group = new OptionGroup();
        final Option p = new Option("p", null, false, "p description");
        group.addOption(p);
        source.addOptionGroup(group);

        final Options target = new Options();
        final Options result = target.addOptions(source);
        assertTrue(result == target);
        assertTrue(target.hasOption("o"));
        assertTrue(target.hasOption("p"));
        assertTrue(target.getOptionGroup(target.getOption("p")) != null);
    }

    @Test
    void testAddOptionsThrowsOnDuplicateKey() {
        final Options source = new Options();
        source.addOption("q", false, "q description");
        final Options target = new Options();
        target.addOption("q", true, "already here");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                target.addOptions(source);
            }
        });
    }

    @Test
    void testGetOptionsReturnsUnmodifiableCollection() {
        final Options options = new Options();
        options.addOption("r", false, "r description");
        final Collection<Option> all = options.getOptions();
        assertEquals(1, all.size());
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                all.add(new Option("s", false, "s description"));
            }
        });
    }

    @Test
    void testGetOptionsEmptyForFreshInstance() {
        final Options options = new Options();
        assertTrue(options.getOptions().isEmpty());
        assertTrue(options.getRequiredOptions().isEmpty());
    }

    @Test
    void testGetRequiredOptionsReturnsUnmodifiableList() {
        final Options options = new Options();
        options.addRequiredOption("t", null, false, "t description");
        final List<?> required = options.getRequiredOptions();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ((List<Object>) required).add("u");
            }
        });
    }

    @Test
    void testToStringContainsShortAndLongSections() {
        final Options options = new Options();
        options.addOption("v", "victor", false, "victor description");
        final String str = options.toString();
        assertTrue(str.contains("[ Options: [ short "));
        assertTrue(str.contains("[ long "));
        assertTrue(str.contains("victor"));
    }

    @Test
    void testHasOptionWithNullArgument() {
        final Options options = new Options();
        options.addOption("w", false, "w description");
        assertFalse(options.hasOption((String) null));
        assertNull(options.getOption(null));
    }
}
