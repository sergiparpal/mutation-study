/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link UnicodeUnescaper}.
 */
@Deprecated
class UnicodeUnescaperAgentTest {

    @Test
    void testTranslateSimple() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0041");
        assertEquals("A", result);
    }

    @Test
    void testTranslateLowerAndUpperHex() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("A", uu.translate("\\u0041"));
        assertEquals("a", uu.translate("\\u0061"));
        assertEquals("ÿ", uu.translate("\\u00ff"));
        assertEquals("ÿ", uu.translate("\\u00FF"));
    }

    @Test
    void testTranslateWithinLargerString() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("Hello World", uu.translate("Hello\\u0020World"));
    }

    @Test
    void testTranslateMultipleUChars() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("A", uu.translate("\\uu0041"));
        assertEquals("A", uu.translate("\\uuuu0041"));
    }

    @Test
    void testTranslateWithPlusSeparator() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("A", uu.translate("\\u+0041"));
        assertEquals("A", uu.translate("\\uu+0041"));
    }

    @Test
    void testTranslateReturnsZeroWhenNoBackslash() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("u0041", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateReturnsZeroWhenNotFollowedByU() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("\\n0041", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateReturnsZeroWhenBackslashIsLastChar() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("\\", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateUnpairedBackslashAtEnd() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("ab\\", 2, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateThrowsWhenNotEnoughHexDigits() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        uu.translate("\\u004");
                    }
                });
        assertEquals("Less than 4 hex digits in unicode value: '\\u004' due to end of CharSequence", ex.getMessage());
    }

    @Test
    void testTranslateThrowsWhenNoHexDigitsAtAll() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        uu.translate("\\u");
                    }
                });
        assertEquals("Less than 4 hex digits in unicode value: '\\u' due to end of CharSequence", ex.getMessage());
    }

    @Test
    void testTranslateThrowsOnInvalidHexDigits() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        uu.translate("\\uZZZZ");
                    }
                });
        assertEquals("Unable to parse unicode value: ZZZZ", ex.getMessage());
    }

    @Test
    void testTranslateThrowsOnLeadingPlusSign() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        uu.translate("\\u++0041");
                    }
                });
        assertEquals("Sign character in unicode value: '+004'", ex.getMessage());
    }

    @Test
    void testTranslateThrowsOnLeadingMinusSign() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        uu.translate("\\u-0041");
                    }
                });
        assertEquals("Sign character in unicode value: '-004'", ex.getMessage());
    }

    @Test
    void testTranslateConsumedLengthSimple() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("\\u0041rest", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateConsumedLengthWithExtraUAndPlus() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final int consumed = uu.translate("\\uu+0041rest", 0, writer);
        assertEquals(8, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateAtNonZeroIndex() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final Writer writer = new StringWriter();
        final String input = "xx\\u0041";
        final int consumed = uu.translate(input, 2, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateZeroValue() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0000");
        assertEquals(1, result.length());
        assertEquals('\u0000', result.charAt(0));
    }

    @Test
    void testTranslateMaxFourHexDigitValue() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uffff");
        assertEquals(1, result.length());
        assertEquals('￿', result.charAt(0));
    }

    @Test
    void testTranslateEmptyString() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("", uu.translate(""));
    }

    @Test
    void testTranslateNoEscapesPassesThrough() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertEquals("plain text", uu.translate("plain text"));
    }
}
