/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.exception.CloneFailedException;
import org.apache.commons.lang3.text.StrBuilder;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ObjectUtils}.
 */
class ObjectUtilsAgentTest {

    /** Cloneable with a public clone() override. */
    static class PublicCloneable implements Cloneable {
        int value;

        PublicCloneable(final int value) {
            this.value = value;
        }

        @Override
        public PublicCloneable clone() {
            return new PublicCloneable(value);
        }
    }

    /** Cloneable without a public clone() override; only Object's protected clone() is inherited. */
    static class NoPublicCloneMethod implements Cloneable {
    }

    /** Not Cloneable at all. */
    static class NotCloneable {
    }

    @Test
    void testAllNotNull() {
        assertTrue(ObjectUtils.allNotNull());
        assertTrue(ObjectUtils.allNotNull("a"));
        assertTrue(ObjectUtils.allNotNull("a", "b"));
        assertFalse(ObjectUtils.allNotNull((Object) null));
        assertFalse(ObjectUtils.allNotNull(null, null));
        assertFalse(ObjectUtils.allNotNull(null, "a"));
        assertFalse(ObjectUtils.allNotNull("a", null));
        assertFalse(ObjectUtils.allNotNull((Object[]) null));
    }

    @Test
    void testAllNull() {
        assertTrue(ObjectUtils.allNull());
        assertTrue(ObjectUtils.allNull((Object) null));
        assertTrue(ObjectUtils.allNull(null, null));
        assertFalse(ObjectUtils.allNull("a"));
        assertFalse(ObjectUtils.allNull(null, "a"));
        assertFalse(ObjectUtils.allNull("a", null));
        assertTrue(ObjectUtils.allNull((Object[]) null));
    }

    @Test
    void testAnyNotNull() {
        assertFalse(ObjectUtils.anyNotNull());
        assertFalse(ObjectUtils.anyNotNull((Object) null));
        assertFalse(ObjectUtils.anyNotNull(null, null));
        assertTrue(ObjectUtils.anyNotNull("a"));
        assertTrue(ObjectUtils.anyNotNull(null, "a"));
        assertTrue(ObjectUtils.anyNotNull("a", null));
        assertFalse(ObjectUtils.anyNotNull((Object[]) null));
    }

    @Test
    void testAnyNull() {
        assertTrue(ObjectUtils.anyNull((Object) null));
        assertTrue(ObjectUtils.anyNull(null, null));
        assertTrue(ObjectUtils.anyNull(null, "a"));
        assertTrue(ObjectUtils.anyNull("a", null));
        assertFalse(ObjectUtils.anyNull("a"));
        assertFalse(ObjectUtils.anyNull("a", "b"));
        assertFalse(ObjectUtils.anyNull());
        assertTrue(ObjectUtils.anyNull((Object[]) null));
    }

    @Test
    void testCloneNull() {
        assertNull(ObjectUtils.clone((Object) null));
    }

    @Test
    void testCloneNotCloneable() {
        final NotCloneable obj = new NotCloneable();
        assertNull(ObjectUtils.clone(obj));
    }

    @Test
    void testClonePublicCloneable() {
        final PublicCloneable obj = new PublicCloneable(42);
        final PublicCloneable clone = ObjectUtils.clone(obj);
        assertNotNull(clone);
        assertEquals(42, clone.value);
        assertFalse(obj == clone);
    }

    @Test
    void testCloneArray() {
        final int[] array = {1, 2, 3};
        final int[] clone = ObjectUtils.clone(array);
        assertNotNull(clone);
        assertTrue(array != clone);
        assertEquals(1, clone[0]);
        assertEquals(2, clone[1]);
        assertEquals(3, clone[2]);
    }

    @Test
    void testCloneObjectArray() {
        final String[] array = {"a", "b"};
        final String[] clone = ObjectUtils.clone(array);
        assertNotNull(clone);
        assertTrue(array != clone);
        assertEquals("a", clone[0]);
        assertEquals("b", clone[1]);
    }

    @Test
    void testCloneFailsForNonPublicCloneMethod() {
        final NoPublicCloneMethod obj = new NoPublicCloneMethod();
        assertThrows(CloneFailedException.class, () -> ObjectUtils.clone(obj));
    }

    @Test
    void testCloneIfPossibleNotCloneableReturnsSameInstance() {
        final NotCloneable obj = new NotCloneable();
        assertSame(obj, ObjectUtils.cloneIfPossible(obj));
    }

    @Test
    void testCloneIfPossibleCloneable() {
        final PublicCloneable obj = new PublicCloneable(7);
        final PublicCloneable clone = ObjectUtils.cloneIfPossible(obj);
        assertNotNull(clone);
        assertFalse(obj == clone);
        assertEquals(7, clone.value);
    }

    @Test
    void testCloneIfPossibleNull() {
        assertNull(ObjectUtils.cloneIfPossible((Object) null));
    }

    @Test
    void testCompareTwoArg() {
        assertEquals(0, ObjectUtils.compare(null, null));
        assertEquals(-1, ObjectUtils.compare(null, "a"));
        assertEquals(1, ObjectUtils.compare("a", null));
        assertEquals(0, ObjectUtils.compare("a", "a"));
        assertTrue(ObjectUtils.compare("a", "b") < 0);
        assertTrue(ObjectUtils.compare("b", "a") > 0);
    }

    @Test
    void testCompareThreeArgNullGreaterTrue() {
        assertEquals(0, ObjectUtils.compare(null, null, true));
        assertEquals(1, ObjectUtils.compare(null, "a", true));
        assertEquals(-1, ObjectUtils.compare("a", null, true));
    }

    @Test
    void testCompareThreeArgNullGreaterFalse() {
        assertEquals(0, ObjectUtils.compare(null, null, false));
        assertEquals(-1, ObjectUtils.compare(null, "a", false));
        assertEquals(1, ObjectUtils.compare("a", null, false));
    }

    @Test
    void testConstBoolean() {
        assertTrue(ObjectUtils.CONST(true));
        assertFalse(ObjectUtils.CONST(false));
    }

    @Test
    void testConstByte() {
        assertEquals((byte) 5, ObjectUtils.CONST((byte) 5));
    }

    @Test
    void testConstChar() {
        assertEquals('a', ObjectUtils.CONST('a'));
    }

    @Test
    void testConstDouble() {
        assertEquals(1.5d, ObjectUtils.CONST(1.5d), 0d);
    }

    @Test
    void testConstFloat() {
        assertEquals(1.5f, ObjectUtils.CONST(1.5f), 0f);
    }

    @Test
    void testConstInt() {
        assertEquals(123, ObjectUtils.CONST(123));
    }

    @Test
    void testConstLong() {
        assertEquals(123L, ObjectUtils.CONST(123L));
    }

    @Test
    void testConstShort() {
        assertEquals((short) 123, ObjectUtils.CONST((short) 123));
    }

    @Test
    void testConstGeneric() {
        assertEquals("abc", ObjectUtils.CONST("abc"));
        assertNull(ObjectUtils.CONST((String) null));
    }

    @Test
    void testConstByteBoundaries() {
        assertEquals((byte) 127, ObjectUtils.CONST_BYTE(127));
        assertEquals((byte) -128, ObjectUtils.CONST_BYTE(-128));
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.CONST_BYTE(128));
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.CONST_BYTE(-129));
    }

    @Test
    void testConstShortBoundaries() {
        assertEquals((short) 32767, ObjectUtils.CONST_SHORT(32767));
        assertEquals((short) -32768, ObjectUtils.CONST_SHORT(-32768));
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.CONST_SHORT(32768));
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.CONST_SHORT(-32769));
    }

    @Test
    void testDefaultIfNull() {
        assertNull(ObjectUtils.defaultIfNull(null, null));
        assertEquals("", ObjectUtils.defaultIfNull(null, ""));
        assertEquals("zz", ObjectUtils.defaultIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.defaultIfNull("abc", "zz"));
    }

    @Test
    void testEquals() {
        assertTrue(ObjectUtils.equals(null, null));
        assertFalse(ObjectUtils.equals(null, ""));
        assertFalse(ObjectUtils.equals("", null));
        assertTrue(ObjectUtils.equals("", ""));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, "true"));
        assertTrue(ObjectUtils.equals(Boolean.TRUE, Boolean.TRUE));
    }

    @Test
    void testFirstNonNull() {
        assertNull(ObjectUtils.firstNonNull());
        assertNull(ObjectUtils.firstNonNull((Object[]) null));
        assertNull(ObjectUtils.firstNonNull(null, null));
        assertEquals("", ObjectUtils.firstNonNull(null, ""));
        assertEquals("zz", ObjectUtils.firstNonNull(null, "zz"));
        assertEquals("abc", ObjectUtils.firstNonNull("abc", "xyz"));
        assertEquals("xyz", ObjectUtils.firstNonNull(null, "xyz", "abc"));
    }

    @Test
    void testGetClass() {
        assertNull(ObjectUtils.getClass(null));
        assertEquals(String.class, ObjectUtils.<Object>getClass("abc"));
        assertEquals(Integer.class, ObjectUtils.<Object>getClass(Integer.valueOf(1)));
    }

    @Test
    void testGetFirstNonNullSuppliers() {
        assertNull(ObjectUtils.getFirstNonNull());
        final Supplier<String> returnsNull = new Supplier<String>() {
            @Override
            public String get() {
                return null;
            }
        };
        final Supplier<String> returnsZz = new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        };
        assertNull(ObjectUtils.getFirstNonNull(returnsNull, returnsNull));
        assertEquals("zz", ObjectUtils.getFirstNonNull(returnsNull, returnsZz));
        assertNull(ObjectUtils.getFirstNonNull((Supplier<String>) null));
    }

    @Test
    void testGetFirstNonNullShortCircuits() {
        final List<String> callOrder = new ArrayList<String>();
        final Supplier<String> first = new Supplier<String>() {
            @Override
            public String get() {
                callOrder.add("first");
                return "value";
            }
        };
        final Supplier<String> second = new Supplier<String>() {
            @Override
            public String get() {
                callOrder.add("second");
                return "unreached";
            }
        };
        assertEquals("value", ObjectUtils.getFirstNonNull(first, second));
        assertEquals(1, callOrder.size());
        assertEquals("first", callOrder.get(0));
    }

    @Test
    void testGetIfNullWithSupplier() {
        assertNull(ObjectUtils.getIfNull(null, (Supplier<String>) null));
        assertEquals("", ObjectUtils.getIfNull(null, new Supplier<String>() {
            @Override
            public String get() {
                return "";
            }
        }));
        assertEquals("abc", ObjectUtils.getIfNull("abc", (Supplier<String>) null));
    }

    @Test
    void testGetIfNullWithDefaultValue() {
        assertNull(ObjectUtils.getIfNull(null, (String) null));
        assertEquals("", ObjectUtils.getIfNull(null, ""));
        assertEquals("zz", ObjectUtils.getIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.getIfNull("abc", "zz"));
    }

    @Test
    void testHashCode() {
        assertEquals(0, ObjectUtils.hashCode(null));
        assertEquals("abc".hashCode(), ObjectUtils.hashCode("abc"));
    }

    @Test
    void testHashCodeHex() {
        assertEquals(Integer.toHexString(0), ObjectUtils.hashCodeHex(null));
        assertEquals(Integer.toHexString("abc".hashCode()), ObjectUtils.hashCodeHex("abc"));
    }

    @Test
    void testHashCodeMulti() {
        assertEquals(1, ObjectUtils.hashCodeMulti());
        assertEquals(1, ObjectUtils.hashCodeMulti((Object[]) null));
        final Object a = "a";
        final Object b = "b";
        assertEquals(31 + a.hashCode(), ObjectUtils.hashCodeMulti(a));
        assertEquals((31 + a.hashCode()) * 31 + b.hashCode(), ObjectUtils.hashCodeMulti(a, b));
    }

    @Test
    void testIdentityHashCodeHex() {
        final Object obj = new Object();
        assertEquals(Integer.toHexString(System.identityHashCode(obj)), ObjectUtils.identityHashCodeHex(obj));
    }

    @Test
    void testIdentityToStringAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final Object obj = new Object();
        ObjectUtils.identityToString(sb, obj);
        final String expected = obj.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(obj);
        assertEquals(expected, sb.toString());
    }

    @Test
    void testIdentityToStringAppendableNullObjectThrows() {
        final StringBuilder sb = new StringBuilder();
        assertThrows(NullPointerException.class, () -> ObjectUtils.identityToString((Appendable) sb, null));
    }

    @Test
    void testIdentityToStringObject() {
        assertNull(ObjectUtils.identityToString(null));
        final Object obj = new Object();
        final String expected = obj.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(obj);
        assertEquals(expected, ObjectUtils.identityToString(obj));
    }

    @Test
    void testIdentityToStringStringBuffer() {
        final StringBuffer buf = new StringBuffer();
        final Object obj = new Object();
        ObjectUtils.identityToString(buf, obj);
        final String expected = obj.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(obj);
        assertEquals(expected, buf.toString());
    }

    @Test
    void testIdentityToStringStringBufferNullThrows() {
        final StringBuffer buf = new StringBuffer();
        assertThrows(NullPointerException.class, () -> ObjectUtils.identityToString(buf, null));
    }

    @Test
    void testIdentityToStringStringBuilder() {
        final StringBuilder builder = new StringBuilder();
        final Object obj = new Object();
        ObjectUtils.identityToString(builder, obj);
        final String expected = obj.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(obj);
        assertEquals(expected, builder.toString());
    }

    @Test
    void testIdentityToStringStringBuilderNullThrows() {
        final StringBuilder builder = new StringBuilder();
        assertThrows(NullPointerException.class, () -> ObjectUtils.identityToString(builder, null));
    }

    @Test
    void testIdentityToStringStrBuilder() {
        final StrBuilder builder = new StrBuilder();
        final Object obj = new Object();
        ObjectUtils.identityToString(builder, obj);
        final String expected = obj.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(obj);
        assertEquals(expected, builder.toString());
    }

    @Test
    void testIdentityToStringStrBuilderNullThrows() {
        final StrBuilder builder = new StrBuilder();
        assertThrows(NullPointerException.class, () -> ObjectUtils.identityToString(builder, null));
    }

    @Test
    void testIsArray() {
        assertFalse(ObjectUtils.isArray(null));
        assertFalse(ObjectUtils.isArray(""));
        assertFalse(ObjectUtils.isArray("ab"));
        assertTrue(ObjectUtils.isArray(new int[]{}));
        assertTrue(ObjectUtils.isArray(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isArray(1234));
    }

    @Test
    void testIsEmpty() {
        assertTrue(ObjectUtils.isEmpty(null));
        assertTrue(ObjectUtils.isEmpty(""));
        assertFalse(ObjectUtils.isEmpty("ab"));
        assertTrue(ObjectUtils.isEmpty(new int[]{}));
        assertFalse(ObjectUtils.isEmpty(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isEmpty(1234));
        assertFalse(ObjectUtils.isEmpty(Optional.of("")));
        assertTrue(ObjectUtils.isEmpty(Optional.empty()));
        assertTrue(ObjectUtils.isEmpty(new ArrayList<String>()));
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertFalse(ObjectUtils.isEmpty(list));
        assertTrue(ObjectUtils.isEmpty(new HashMap<String, String>()));
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertFalse(ObjectUtils.isEmpty(map));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ObjectUtils.isNotEmpty(null));
        assertFalse(ObjectUtils.isNotEmpty(""));
        assertTrue(ObjectUtils.isNotEmpty("ab"));
        assertFalse(ObjectUtils.isNotEmpty(new int[]{}));
        assertTrue(ObjectUtils.isNotEmpty(new int[]{1, 2, 3}));
        assertTrue(ObjectUtils.isNotEmpty(1234));
        assertTrue(ObjectUtils.isNotEmpty(Optional.of("")));
        assertFalse(ObjectUtils.isNotEmpty(Optional.empty()));
    }

    @Test
    void testMax() {
        assertNull(ObjectUtils.max((String[]) null));
        assertNull(ObjectUtils.max((String) null, (String) null));
        assertEquals("b", ObjectUtils.max("a", "b"));
        assertEquals("b", ObjectUtils.max("b", "a"));
        assertEquals("b", ObjectUtils.max(null, "b"));
        assertEquals("b", ObjectUtils.max("b", null));
        assertEquals(Integer.valueOf(3), ObjectUtils.max(Integer.valueOf(1), null, Integer.valueOf(3), Integer.valueOf(2)));
    }

    @Test
    void testMin() {
        assertNull(ObjectUtils.min((String[]) null));
        assertNull(ObjectUtils.min((String) null, (String) null));
        assertEquals("a", ObjectUtils.min("a", "b"));
        assertEquals("a", ObjectUtils.min("b", "a"));
        assertEquals("a", ObjectUtils.min(null, "a"));
        assertEquals("a", ObjectUtils.min("a", null));
        assertEquals(Integer.valueOf(1), ObjectUtils.min(Integer.valueOf(3), null, Integer.valueOf(1), Integer.valueOf(2)));
    }

    @Test
    void testMedianVarargs() {
        assertEquals(Integer.valueOf(3), ObjectUtils.median(Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5)));
        assertEquals(Integer.valueOf(2), ObjectUtils.median(Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4)));
        assertEquals(Integer.valueOf(7), ObjectUtils.median(Integer.valueOf(7)));
    }

    @Test
    void testMedianNullArrayThrows() {
        assertThrows(NullPointerException.class, () -> ObjectUtils.median((Integer[]) null));
    }

    @Test
    void testMedianEmptyThrows() {
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.<Integer>median());
    }

    @Test
    void testMedianNullElementThrows() {
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.median(Integer.valueOf(1), null, Integer.valueOf(3)));
    }

    @Test
    void testMedianWithComparator() {
        final Comparator<Integer> reverse = new Comparator<Integer>() {
            @Override
            public int compare(final Integer a, final Integer b) {
                return b.compareTo(a);
            }
        };
        assertEquals(Integer.valueOf(3), ObjectUtils.median(reverse, Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5)));
    }

    @Test
    void testMedianWithComparatorNullComparatorThrows() {
        assertThrows(NullPointerException.class, () -> ObjectUtils.median((Comparator<Integer>) null, Integer.valueOf(1)));
    }

    @Test
    void testModeUniqueMostFrequent() {
        assertEquals(Integer.valueOf(1), ObjectUtils.mode(Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2)));
    }

    @Test
    void testModeTieReturnsNull() {
        assertNull(ObjectUtils.mode(Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2)));
    }

    @Test
    void testModeEmptyOrNullReturnsNull() {
        assertNull(ObjectUtils.mode());
        assertNull(ObjectUtils.mode((Object[]) null));
    }

    @Test
    void testModeSingleElement() {
        assertEquals("x", ObjectUtils.mode("x"));
    }

    @Test
    void testNotEqual() {
        assertFalse(ObjectUtils.notEqual(null, null));
        assertTrue(ObjectUtils.notEqual(null, ""));
        assertTrue(ObjectUtils.notEqual("", null));
        assertFalse(ObjectUtils.notEqual("", ""));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, Boolean.FALSE));
    }

    @Test
    void testRequireNonEmptyOneArg() {
        final String value = "abc";
        assertSame(value, ObjectUtils.requireNonEmpty(value));
        assertThrows(NullPointerException.class, () -> ObjectUtils.requireNonEmpty((String) null));
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.requireNonEmpty(""));
    }

    @Test
    void testRequireNonEmptyTwoArg() {
        final String value = "abc";
        assertSame(value, ObjectUtils.requireNonEmpty(value, "myMessage"));
        final NullPointerException npe = assertThrows(NullPointerException.class, () -> ObjectUtils.requireNonEmpty((String) null, "myMessage"));
        assertEquals("myMessage", npe.getMessage());
        final IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, () -> ObjectUtils.requireNonEmpty("", "myMessage"));
        assertEquals("myMessage", iae.getMessage());
    }

    @Test
    void testToStringObject() {
        assertEquals("", ObjectUtils.toString(null));
        assertEquals("", ObjectUtils.toString(""));
        assertEquals("bat", ObjectUtils.toString("bat"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE));
    }

    @Test
    void testToStringObjectWithNullStr() {
        assertNull(ObjectUtils.toString((Object) null, (String) null));
        assertEquals("null", ObjectUtils.toString((Object) null, "null"));
        assertEquals("", ObjectUtils.toString("", "null"));
        assertEquals("bat", ObjectUtils.toString("bat", "null"));
    }

    @Test
    void testToStringWithObjectSupplier() {
        final Supplier<String> expensive = new Supplier<String>() {
            @Override
            public String get() {
                return "expensive";
            }
        };
        assertEquals("bat", ObjectUtils.toString("bat", expensive));
        assertEquals("expensive", ObjectUtils.toString((Object) null, expensive));
    }

    @Test
    void testToStringWithSupplierAndSupplier() {
        final Supplier<String> expensive = new Supplier<String>() {
            @Override
            public String get() {
                return "expensive";
            }
        };
        final Supplier<Object> nullSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return null;
            }
        };
        final Supplier<Object> batSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return "bat";
            }
        };
        assertEquals("expensive", ObjectUtils.toString(nullSupplier, expensive));
        assertEquals("expensive", ObjectUtils.toString((Supplier<Object>) null, expensive));
        assertEquals("bat", ObjectUtils.toString(batSupplier, expensive));
    }

    @Test
    void testWaitNegativeDurationThrows() {
        final Object monitor = new Object();
        assertThrows(IllegalArgumentException.class, () -> ObjectUtils.wait(monitor, Duration.ofSeconds(-1)));
    }

    @Test
    void testWaitWithoutMonitorThrows() throws InterruptedException {
        final Object monitor = new Object();
        assertThrows(IllegalMonitorStateException.class, () -> ObjectUtils.wait(monitor, Duration.ofMillis(10)));
    }

    @Test
    void testWaitShortDurationUsesMonitorOwner() throws InterruptedException {
        final Object monitor = new Object();
        synchronized (monitor) {
            ObjectUtils.wait(monitor, Duration.ofMillis(10));
        }
    }

    @Test
    void testNullSingleton() {
        assertNotNull(ObjectUtils.NULL);
        assertSame(ObjectUtils.NULL, ObjectUtils.NULL);
    }
}
