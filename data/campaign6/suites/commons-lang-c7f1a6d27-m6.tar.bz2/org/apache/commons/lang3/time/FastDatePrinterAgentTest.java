/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone INDIA = TimeZone.getTimeZone("GMT+05:30");
    private static final Locale LOCALE = Locale.US;

    private static Calendar newCalendar(final TimeZone tz, final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance(tz, LOCALE);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        // Force the instant to be computed now, while clear() with set() leaves time/field
        // state ambiguous, which matters for format(Calendar) with a different time zone.
        cal.getTimeInMillis();
        return cal;
    }

    private static FastDatePrinter newPrinter(final String pattern) {
        return new FastDatePrinter(pattern, GMT, LOCALE);
    }

    private static FastDatePrinter newPrinter(final String pattern, final TimeZone tz) {
        return new FastDatePrinter(pattern, tz, LOCALE);
    }

    @Test
    void testBasicDatePattern() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss");
        final Calendar cal = newCalendar(GMT, 2021, Calendar.MARCH, 5, 13, 45, 7, 0);
        assertEquals("2021-03-05T13:45:07", printer.format(cal));
        assertEquals("2021-03-05T13:45:07", printer.format(cal.getTime()));
        assertEquals("2021-03-05T13:45:07", printer.format(cal.getTimeInMillis()));
    }

    @Test
    void testFormatAppliesConfiguredTimeZoneToCalendar() {
        // Printer's time zone (GMT+05:30) is applied even though the input calendar is in GMT.
        final FastDatePrinter printer = newPrinter("HH:mm", INDIA);
        final Calendar cal = newCalendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("05:30", printer.format(cal));
    }

    @Test
    void testFormatObjectDispatchesByRuntimeType() {
        final FastDatePrinter printer = newPrinter("yyyy");
        final Calendar cal = newCalendar(GMT, 1999, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("1999", printer.format((Object) cal.getTime()));
        assertEquals("1999", printer.format((Object) cal));
        assertEquals("1999", printer.format((Object) Long.valueOf(cal.getTimeInMillis())));
    }

    @Test
    void testFormatObjectRejectsUnsupportedType() {
        final FastDatePrinter printer = newPrinter("yyyy");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
    }

    @Test
    void testGetPatternLocaleAndTimeZone() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", INDIA);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(LOCALE, printer.getLocale());
        assertEquals(INDIA, printer.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", INDIA);
        final TimeZone first = printer.getTimeZone();
        final TimeZone second = printer.getTimeZone();
        assertNotSame(first, second);
        assertEquals(INDIA, first);
        first.setID("Mutated/Zone");
        assertEquals(INDIA, printer.getTimeZone());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter a = newPrinter("yyyy-MM-dd", INDIA);
        final FastDatePrinter b = newPrinter("yyyy-MM-dd", INDIA);
        final FastDatePrinter diffPattern = newPrinter("yyyy", INDIA);
        final FastDatePrinter diffZone = newPrinter("yyyy-MM-dd", GMT);

        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
        assertFalse(a.equals(diffPattern));
        assertFalse(a.equals(diffZone));
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(null));
        assertTrue(a.equals(a));
    }

    @Test
    void testToStringContainsPatternLocaleAndZoneId() {
        final FastDatePrinter printer = newPrinter("yyyy", INDIA);
        final String str = printer.toString();
        assertTrue(str.contains("yyyy"));
        assertTrue(str.contains(INDIA.getID()));
        assertTrue(str.contains(LOCALE.toString()));
    }

    @Test
    void testMaxLengthEstimateForFixedWidthPattern() {
        final FastDatePrinter printer = newPrinter("yyyy");
        assertEquals(4, printer.getMaxLengthEstimate());
    }

    @Test
    void testMaxLengthEstimateForLiteral() {
        final FastDatePrinter printer = newPrinter("'hello'");
        assertEquals(5, printer.getMaxLengthEstimate());
        final Calendar cal = newCalendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("hello", printer.format(cal));
    }

    @Test
    void testEscapedSingleQuoteLiteral() {
        final FastDatePrinter printer = newPrinter("''");
        final Calendar cal = newCalendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("'", printer.format(cal));
    }

    @Test
    void testTwelveHourFieldMidnightBecomesTwelve() {
        final FastDatePrinter printer = newPrinter("h");
        final Calendar cal = newCalendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("12", printer.format(cal));
        cal.set(Calendar.HOUR_OF_DAY, 13);
        assertEquals("1", printer.format(cal));
    }

    @Test
    void testTwentyFourHourFieldMidnightBecomesTwentyFour() {
        final FastDatePrinter printer = newPrinter("k");
        final Calendar cal = newCalendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("24", printer.format(cal));
        cal.set(Calendar.HOUR_OF_DAY, 5);
        assertEquals("5", printer.format(cal));
    }

    @Test
    void testUnpaddedDayField() {
        final FastDatePrinter printer = newPrinter("d");
        final Calendar cal = newCalendar(GMT, 2000, Calendar.JANUARY, 5, 0, 0, 0, 0);
        assertEquals("5", printer.format(cal));
        cal.set(Calendar.DAY_OF_MONTH, 25);
        assertEquals("25", printer.format(cal));
    }

    @Test
    void testUnpaddedMillisecondField() {
        final FastDatePrinter printer = newPrinter("S");
        final Calendar cal = newCalendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 7);
        assertEquals("7", printer.format(cal));
        cal.set(Calendar.MILLISECOND, 500);
        assertEquals("500", printer.format(cal));
    }

    @Test
    void testDayInWeekNumberField() {
        final FastDatePrinter printer = newPrinter("u");
        // 2021-01-03 is a Sunday.
        final Calendar sunday = newCalendar(GMT, 2021, Calendar.JANUARY, 3, 0, 0, 0, 0);
        assertEquals("7", printer.format(sunday));
        // 2021-01-04 is a Monday.
        final Calendar monday = newCalendar(GMT, 2021, Calendar.JANUARY, 4, 0, 0, 0, 0);
        assertEquals("1", printer.format(monday));
    }

    @Test
    void testMonthAndWeekdayTextFields() {
        final Calendar cal = newCalendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("January", newPrinter("MMMM").format(cal));
        assertEquals("Jan", newPrinter("MMM").format(cal));
        // 2021-01-01 is a Friday.
        assertEquals("Friday", newPrinter("EEEE").format(cal));
        assertEquals("Fri", newPrinter("EEE").format(cal));
    }

    @Test
    void testEraField() {
        final Calendar ad = newCalendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("AD", newPrinter("G").format(ad));

        final GregorianCalendar bc = new GregorianCalendar(GMT, LOCALE);
        bc.clear();
        bc.set(Calendar.ERA, GregorianCalendar.BC);
        bc.set(100, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("BC", newPrinter("G").format(bc));
    }

    @Test
    void testTwoDigitYearField() {
        final FastDatePrinter printer = newPrinter("yy");
        final Calendar cal = newCalendar(GMT, 2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("05", printer.format(cal));
        cal.set(Calendar.YEAR, 1899);
        assertEquals("99", printer.format(cal));
    }

    @Test
    void testPaddedYearWithLargeValue() {
        final FastDatePrinter printer = newPrinter("yyyy");
        final Calendar cal = newCalendar(GMT, 99999, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("99999", printer.format(cal));
    }

    @Test
    void testWeekYearNegativeProlepticValue() {
        final FastDatePrinter printer = newPrinter("YYYY");
        final GregorianCalendar bc = new GregorianCalendar(GMT, LOCALE);
        bc.clear();
        bc.set(Calendar.ERA, GregorianCalendar.BC);
        // Use a date comfortably inside the year, away from week-year boundaries.
        bc.set(100, Calendar.JUNE, 15, 0, 0, 0);

        final int weekYear = bc.getWeekYear();
        assertTrue(weekYear < 0, "Expected a negative proleptic week year for a BC date");
        final String expectedDigits = String.valueOf(Math.abs(weekYear));
        final StringBuilder expected = new StringBuilder();
        expected.append('-');
        for (int i = expectedDigits.length(); i < 4; i++) {
            expected.append('0');
        }
        expected.append(expectedDigits);

        assertEquals(expected.toString(), printer.format(bc));
    }

    @Test
    void testIso8601PatternVariants() {
        final Calendar cal = newCalendar(INDIA, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("+05", newPrinter("X", INDIA).format(cal));
        assertEquals("+0530", newPrinter("XX", INDIA).format(cal));
        assertEquals("+05:30", newPrinter("XXX", INDIA).format(cal));

        final Calendar gmtCal = newCalendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("Z", newPrinter("X", GMT).format(gmtCal));
    }

    @Test
    void testIso8601InvalidTokenLengthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                newPrinter("XXXX");
            }
        });
    }

    @Test
    void testTimeZoneNumberPatternVariants() {
        final Calendar cal = newCalendar(INDIA, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("+0530", newPrinter("Z", INDIA).format(cal));
        assertEquals("+05:30", newPrinter("ZZ", INDIA).format(cal));
        assertEquals("+05:30", newPrinter("ZZZ", INDIA).format(cal));
    }

    @Test
    void testUnknownPatternLetterThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                newPrinter("qqq");
            }
        });
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, GMT, LOCALE);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy", null, LOCALE);
            }
        });
    }

    @Test
    void testConstructorDefaultsNullLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testSerializationRoundTripPreservesBehavior() throws Exception {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd", INDIA);

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(printer);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        assertNotNull(deserialized);
        assertEquals(printer.getPattern(), deserialized.getPattern());
        assertEquals(printer, deserialized);

        final Calendar cal = newCalendar(GMT, 2021, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals(printer.format(cal), deserialized.format(cal));
    }
}
