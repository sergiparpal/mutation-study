/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface Marker {
        // empty
    }

    public interface Greeter {
        @Deprecated
        String greet(String name);
    }

    public static class BaseGreeter implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hello, " + name;
        }

        public static String staticGreet(final String name) {
            return "StaticHello, " + name;
        }

        public String noArgs() {
            return "noArgs";
        }

        private String secret() {
            return "secret";
        }
    }

    // Package-private: not itself public, but inherits public methods via a public interface/superclass.
    static class PackagePrivateGreeter extends BaseGreeter {
        // empty
    }

    public static class Ops {
        public String describe(final Object o) {
            return "Object:" + o;
        }

        public String describe(final String s) {
            return "String:" + s;
        }

        public String join(final String sep, final Object... parts) {
            final StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    sb.append(sep);
                }
                sb.append(parts[i]);
            }
            return sb.toString();
        }

        public String explode() {
            throw new IllegalStateException("boom");
        }

        public static String staticAdd(final int a, final int b) {
            return String.valueOf(a + b);
        }
    }

    public interface AnnotatedInterface {
        @Marker
        void process(Number n);
    }

    public static class AnnotatedImpl implements AnnotatedInterface {
        @Override
        public void process(final Number n) {
            // empty
        }

        public void plainMethod() {
            // empty
        }
    }

    public static class Parent {
        public String run(final String s) {
            return "Parent:" + s;
        }
    }

    public static class Child extends Parent {
        @Override
        public String run(final String s) {
            return "Child:" + s;
        }
    }

    public static class Numeric {
        public String take(final Integer i) {
            return "Integer";
        }

        public String take(final Number n) {
            return "Number";
        }
    }

    public interface GenericHandler<T> {
        @Marker
        void handle(T t);
    }

    public static class StringHandler implements GenericHandler<String> {
        @Override
        public void handle(final String s) {
            // empty
        }
    }

    @Test
    void testConstructorIsPublicButDeprecated() throws Exception {
        assertNotNull(new MethodUtils());
        assertNotNull(MethodUtils.class.getConstructor());
    }

    // --- getAccessibleMethod ---

    @Test
    void testGetAccessibleMethodNullReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    void testGetAccessibleMethodOnPublicClassReturnsSameMethod() throws Exception {
        final Method m = BaseGreeter.class.getMethod("greet", String.class);
        assertEquals(m, MethodUtils.getAccessibleMethod(m));
    }

    @Test
    void testGetAccessibleMethodPrivateMethodReturnsNull() throws Exception {
        final Method m = BaseGreeter.class.getDeclaredMethod("secret");
        assertNull(MethodUtils.getAccessibleMethod(BaseGreeter.class, m));
    }

    @Test
    void testGetAccessibleMethodClimbsToPublicInterface() throws Exception {
        // "greet" is only directly declared on the public interface Greeter and the public BaseGreeter;
        // PackagePrivateGreeter itself is not public, so the accessible method must come from the interface.
        final Method declared = PackagePrivateGreeter.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateGreeter.class, declared);
        assertNotNull(accessible);
        assertEquals(Greeter.class, accessible.getDeclaringClass());
    }

    @Test
    void testGetAccessibleMethodByNameAndParameterTypes() {
        final Method m = MethodUtils.getAccessibleMethod(BaseGreeter.class, "greet", String.class);
        assertNotNull(m);
        assertEquals("greet", m.getName());
    }

    @Test
    void testGetAccessibleMethodByNameNoSuchMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(BaseGreeter.class, "doesNotExist"));
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Ops.class, "describe", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethodAssignable() {
        // No overload declared for Integer, Object is the only assignable candidate.
        final Method m = MethodUtils.getMatchingAccessibleMethod(Ops.class, "describe", Integer.class);
        assertNotNull(m);
        assertEquals(Object.class, m.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Ops.class, "doesNotExist", String.class));
    }

    @Test
    void testGetMatchingAccessibleMethodVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Ops.class, "join", String.class, String.class, String.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    // --- getMatchingMethod ---

    @Test
    void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "foo"));
    }

    @Test
    void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(Ops.class, ""));
    }

    @Test
    void testGetMatchingMethodFindsPrivateDeclaredMethod() throws Exception {
        // getMatchingMethod searches declared methods regardless of accessibility.
        final Method m = MethodUtils.getMatchingMethod(BaseGreeter.class, "secret");
        assertNotNull(m);
        assertEquals(BaseGreeter.class.getDeclaredMethod("secret"), m);
    }

    @Test
    void testGetMatchingMethodExactMatch() {
        final Method m = MethodUtils.getMatchingMethod(Ops.class, "describe", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingMethodNoCandidatesReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(Ops.class, "describe", java.util.Date.class, java.util.Date.class));
    }

    // --- getMethodObject ---

    @Test
    void testGetMethodObjectFound() {
        final Method m = MethodUtils.getMethodObject(BaseGreeter.class, "greet", String.class);
        assertNotNull(m);
    }

    @Test
    void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(BaseGreeter.class, "doesNotExist"));
    }

    @Test
    void testGetMethodObjectNullClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "greet", String.class));
    }

    @Test
    void testGetMethodObjectNullNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(BaseGreeter.class, null));
    }

    // --- getMethodsListWithAnnotation / getMethodsWithAnnotation ---

    @Test
    void testGetMethodsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, Marker.class));
    }

    @Test
    void testGetMethodsListWithAnnotationNullAnnotationThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(AnnotatedImpl.class, null));
    }

    @Test
    void testGetMethodsListWithAnnotationNoMatchesIsEmpty() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AnnotatedImpl.class, Marker.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    void testGetMethodsWithAnnotationSearchSupersFindsInterfaceAnnotation() {
        // AnnotatedImpl.process itself has no @Marker; only AnnotatedInterface.process does.
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AnnotatedImpl.class, Marker.class, true, true);
        boolean found = false;
        for (final Method m : methods) {
            if (m.getDeclaringClass() == AnnotatedInterface.class && m.getName().equals("process")) {
                found = true;
            }
        }
        assertTrue(found);
    }

    // --- getOverrideHierarchy ---

    @Test
    void testGetOverrideHierarchyNullThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE));
    }

    @Test
    void testGetOverrideHierarchyIncludesParentAndChild() throws Exception {
        final Method childRun = Child.class.getMethod("run", String.class);
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(childRun, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        boolean hasChild = false;
        boolean hasParent = false;
        for (final Method m : hierarchy) {
            if (m.getDeclaringClass() == Child.class) {
                hasChild = true;
            }
            if (m.getDeclaringClass() == Parent.class) {
                hasParent = true;
            }
        }
        assertTrue(hasChild);
        assertTrue(hasParent);
    }

    // --- invokeExactMethod ---

    @Test
    void testInvokeExactMethodNoArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new BaseGreeter(), "noArgs");
        assertEquals("noArgs", result);
    }

    @Test
    void testInvokeExactMethodWithArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new BaseGreeter(), "greet", "World");
        assertEquals("Hello, World", result);
    }

    @Test
    void testInvokeExactMethodNoMatchThrowsNoSuchMethodException() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(new Ops(), "describe", 42));
    }

    @Test
    void testInvokeExactMethodNullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeExactMethod(null, "greet", "World"));
    }

    // --- invokeMethod (assignable, non-exact) ---

    @Test
    void testInvokeMethodAssignableArg() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Ops(), "describe", 42);
        assertEquals("Object:42", result);
    }

    @Test
    void testInvokeMethodVarArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Ops(), "join", "-", "a", "b", "c");
        assertEquals("a-b-c", result);
    }

    @Test
    void testInvokeMethodWrapsTargetException() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class,
                () -> MethodUtils.invokeMethod(new Ops(), "explode"));
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeMethodForceAccessInvokesPrivateMethod() throws Exception {
        final Object result = MethodUtils.invokeMethod(new BaseGreeter(), true, "secret");
        assertEquals("secret", result);
    }

    @Test
    void testInvokeMethodWithoutForceAccessFailsOnPrivateMethod() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(new BaseGreeter(), false, "secret"));
    }

    @Test
    void testInvokeMethodNoMatchThrowsNoSuchMethodException() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(new Ops(), "doesNotExist"));
    }

    // --- invokeStaticMethod / invokeExactStaticMethod ---

    @Test
    void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Ops.class, "staticAdd", 2, 3);
        assertEquals("5", result);
    }

    @Test
    void testInvokeStaticMethodNoMatchThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(Ops.class, "doesNotExist"));
    }

    @Test
    void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(BaseGreeter.class, "staticGreet", "World");
        assertEquals("StaticHello, World", result);
    }

    @Test
    void testInvokeExactStaticMethodNoMatchThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactStaticMethod(Ops.class, "staticAdd", "notAnInt", "notAnInt"));
    }

    // --- getAnnotation ---

    @Test
    void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, Marker.class, false, false));
    }

    @Test
    void testGetAnnotationDirectlyPresent() throws Exception {
        final Method m = AnnotatedInterface.class.getMethod("process", Number.class);
        assertNotNull(MethodUtils.getAnnotation(m, Marker.class, false, false));
    }

    @Test
    void testGetAnnotationSearchSupersFindsOnInterface() throws Exception {
        final Method implMethod = AnnotatedImpl.class.getMethod("process", Number.class);
        assertNull(implMethod.getAnnotation(Marker.class));
        final Marker found = MethodUtils.getAnnotation(implMethod, Marker.class, true, true);
        assertNotNull(found);
    }

    @Test
    void testGetAnnotationWithoutSearchSupersReturnsNull() throws Exception {
        final Method implMethod = AnnotatedImpl.class.getMethod("process", Number.class);
        assertNull(MethodUtils.getAnnotation(implMethod, Marker.class, false, true));
    }

    @Test
    void testGetAnnotationNoMatchAnywhereReturnsNull() throws Exception {
        final Method plain = AnnotatedImpl.class.getMethod("plainMethod");
        assertNull(MethodUtils.getAnnotation(plain, Marker.class, true, true));
    }

    @Test
    void testGetAnnotationSearchSupersAcrossGenericBridgeMethod() throws Exception {
        // StringHandler.handle(String) overrides the generic GenericHandler<T>.handle(T), whose
        // erasure is handle(Object). The annotation lives only on the generic interface method.
        final Method implMethod = StringHandler.class.getMethod("handle", String.class);
        assertNull(implMethod.getAnnotation(Marker.class));
        final Marker found = MethodUtils.getAnnotation(implMethod, Marker.class, true, true);
        assertNotNull(found);
    }

    // --- distance()-driven overload selection (via getMatchingMethod) ---

    @Test
    void testGetMatchingMethodPrefersExactWrapperOverSupertypeForBoxedPrimitive() {
        // Per the documented intent of MemberUtils/MethodUtils distance scoring: when a primitive
        // is boxed, the exact wrapper type (Integer) should outrank a wider supertype (Number).
        final Method m = MethodUtils.getMatchingMethod(Numeric.class, "take", int.class);
        assertNotNull(m);
        assertEquals(Integer.class, m.getParameterTypes()[0]);
    }
}
