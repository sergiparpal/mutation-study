/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ConstructorUtils}.
 */
public class ConstructorUtilsAgentTest {

    public static class BaseClass {
        // empty
    }

    public static class SubClass extends BaseClass {
        // empty
    }

    public static class PublicFixture {
        public final String calledWith;

        public PublicFixture() {
            calledWith = "()";
        }

        public PublicFixture(final String s) {
            calledWith = "(String)";
        }

        public PublicFixture(final Object o) {
            calledWith = "(Object)";
        }

        public PublicFixture(final String s, final Object... rest) {
            calledWith = "(String, Object...)";
        }

        public PublicFixture(final int i) {
            throw new IllegalStateException("boom");
        }
    }

    public abstract static class AbstractFixture {
        public AbstractFixture() {
            // empty
        }
    }

    // Package-private: not accessible via ConstructorUtils by design.
    static class PackagePrivateFixture {
        public PackagePrivateFixture() {
            // empty
        }
    }

    @Test
    void testConstructorIsPublicButDeprecated() throws Exception {
        assertNotNull(new ConstructorUtils());
        assertNotNull(ConstructorUtils.class.getConstructor());
    }

    @Test
    void testGetAccessibleConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, () -> ConstructorUtils.getAccessibleConstructor((Class<?>) null));
    }

    @Test
    void testGetAccessibleConstructorNullConstructorThrows() {
        assertThrows(NullPointerException.class, () -> ConstructorUtils.getAccessibleConstructor((Constructor<Object>) null));
    }

    @Test
    void testGetAccessibleConstructorFoundExact() throws Exception {
        final Constructor<PublicFixture> ctor = ConstructorUtils.getAccessibleConstructor(PublicFixture.class, String.class);
        assertNotNull(ctor);
        assertEquals(1, ctor.getParameterCount());
        assertEquals(String.class, ctor.getParameterTypes()[0]);
    }

    @Test
    void testGetAccessibleConstructorNoSuchConstructorReturnsNull() {
        assertNull(ConstructorUtils.getAccessibleConstructor(PublicFixture.class, java.util.Date.class));
    }

    @Test
    void testGetAccessibleConstructorOnNonPublicClassReturnsNull() {
        assertNull(ConstructorUtils.getAccessibleConstructor(PackagePrivateFixture.class));
    }

    @Test
    void testGetAccessibleConstructorFromConstructorObject() throws Exception {
        final Constructor<PublicFixture> raw = PublicFixture.class.getConstructor(String.class);
        final Constructor<PublicFixture> accessible = ConstructorUtils.getAccessibleConstructor(raw);
        assertEquals(raw, accessible);
    }

    @Test
    void testGetAccessibleConstructorFromConstructorObjectOnNonPublicClassReturnsNull() throws Exception {
        final Constructor<PackagePrivateFixture> raw = PackagePrivateFixture.class.getConstructor();
        assertNull(ConstructorUtils.getAccessibleConstructor(raw));
    }

    @Test
    void testGetMatchingAccessibleConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, () -> ConstructorUtils.getMatchingAccessibleConstructor(null));
    }

    @Test
    void testGetMatchingAccessibleConstructorExactMatch() throws Exception {
        final Constructor<PublicFixture> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicFixture.class, String.class);
        assertNotNull(ctor);
        assertEquals(String.class, ctor.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleConstructorAssignableMatch() throws Exception {
        // SubClass is assignable to Object but not to String, so the (Object) constructor should match.
        final Constructor<PublicFixture> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicFixture.class, SubClass.class);
        assertNotNull(ctor);
        assertEquals(Object.class, ctor.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleConstructorNoMatchReturnsNull() {
        assertNull(ConstructorUtils.getMatchingAccessibleConstructor(String.class, java.util.Date.class));
    }

    @Test
    void testGetMatchingAccessibleConstructorNoArgs() throws Exception {
        final Constructor<PublicFixture> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicFixture.class);
        assertNotNull(ctor);
        assertEquals(0, ctor.getParameterCount());
    }

    @Test
    void testInvokeConstructorNoArgs() throws Exception {
        final PublicFixture instance = ConstructorUtils.invokeConstructor(PublicFixture.class);
        assertEquals("()", instance.calledWith);
    }

    @Test
    void testInvokeConstructorPicksBestMatch() throws Exception {
        final PublicFixture instance = ConstructorUtils.invokeConstructor(PublicFixture.class, "hello");
        assertEquals("(String)", instance.calledWith);
    }

    @Test
    void testInvokeConstructorWithAssignableArg() throws Exception {
        final PublicFixture instance = ConstructorUtils.invokeConstructor(PublicFixture.class, new SubClass());
        assertEquals("(Object)", instance.calledWith);
    }

    @Test
    void testInvokeConstructorNoMatchThrowsNoSuchMethodException() {
        // Two Date args match none of the declared constructors: not (), not (String), not (Object)
        // (wrong arg count), not (int), and not (String, Object...) since the first arg isn't a String.
        assertThrows(NoSuchMethodException.class,
                () -> ConstructorUtils.invokeConstructor(PublicFixture.class, new java.util.Date(), new java.util.Date()));
    }

    @Test
    void testInvokeConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, () -> ConstructorUtils.invokeConstructor(null));
    }

    @Test
    void testInvokeConstructorWrapsTargetException() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class,
                () -> ConstructorUtils.invokeConstructor(PublicFixture.class, 42));
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeConstructorOnAbstractClassThrowsInstantiationException() {
        assertThrows(InstantiationException.class,
                () -> ConstructorUtils.invokeConstructor(AbstractFixture.class));
    }

    @Test
    void testInvokeConstructorWithExplicitTypesAndVarArgs() throws Exception {
        final PublicFixture instance = ConstructorUtils.invokeConstructor(PublicFixture.class,
                new Object[] {"a", "b", "c"}, new Class<?>[] {String.class, Object[].class});
        assertEquals("(String, Object...)", instance.calledWith);
    }

    @Test
    void testInvokeExactConstructorNoArgs() throws Exception {
        final PublicFixture instance = ConstructorUtils.invokeExactConstructor(PublicFixture.class);
        assertEquals("()", instance.calledWith);
    }

    @Test
    void testInvokeExactConstructorRequiresExactTypeMatch() {
        // SubClass does not exactly match any declared constructor parameter type (String, Object, or int),
        // so an exact-match search must fail even though an assignable (Object) constructor exists.
        assertThrows(NoSuchMethodException.class, () -> ConstructorUtils.invokeExactConstructor(PublicFixture.class, new SubClass()));
    }

    @Test
    void testInvokeExactConstructorExactObjectMatch() throws Exception {
        final Object plainObject = new Object();
        final PublicFixture instance = ConstructorUtils.invokeExactConstructor(PublicFixture.class, plainObject);
        assertEquals("(Object)", instance.calledWith);
    }

    @Test
    void testInvokeExactConstructorNoMatchThrowsNoSuchMethodException() {
        assertThrows(NoSuchMethodException.class, () -> ConstructorUtils.invokeExactConstructor(PublicFixture.class, new java.util.Date()));
    }

    @Test
    void testInvokeExactConstructorWithExplicitTypes() throws Exception {
        final PublicFixture instance = ConstructorUtils.invokeExactConstructor(PublicFixture.class,
                new Object[] {"hello"}, new Class<?>[] {String.class});
        assertEquals("(String)", instance.calledWith);
    }

    @Test
    void testInvokeExactConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, () -> ConstructorUtils.invokeExactConstructor(null));
    }
}
