/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MemberUtils}.
 */
class MemberUtilsAgentTest {

    public static class PublicFixture {
        public PublicFixture() {
            // empty
        }

        public PublicFixture(final String s) {
            // empty
        }

        public PublicFixture(final Object o) {
            // empty
        }

        public void foo(final Object o) {
            // empty
        }

        public void foo(final String s) {
            // empty
        }

        public void varargsOnly(final Object... rest) {
            // empty
        }

        public void varargsTail(final String s, final Object... rest) {
            // empty
        }

        public static void staticMethod() {
            // empty
        }

        public final void finalMethod() {
            // empty
        }

        private void privateMethod() {
            // empty
        }

        void packageMethod() {
            // empty
        }

        protected void protectedMethod() {
            // empty
        }
    }

    private Method method(final String name, final Class<?>... types) throws NoSuchMethodException {
        return PublicFixture.class.getMethod(name, types);
    }

    private Method declaredMethod(final String name, final Class<?>... types) throws NoSuchMethodException {
        return PublicFixture.class.getDeclaredMethod(name, types);
    }

    @Test
    void testIsAccessibleWithNull() {
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    void testIsAccessibleWithPublicMethod() throws Exception {
        assertTrue(MemberUtils.isAccessible(method("finalMethod")));
    }

    @Test
    void testIsAccessibleWithPrivateMethod() throws Exception {
        assertFalse(MemberUtils.isAccessible(declaredMethod("privateMethod")));
    }

    @Test
    void testIsAccessibleWithProtectedMethod() throws Exception {
        assertFalse(MemberUtils.isAccessible(declaredMethod("protectedMethod")));
    }

    @Test
    void testIsPublicWithNull() {
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    void testIsPublicWithPublicMember() throws Exception {
        assertTrue(MemberUtils.isPublic(method("foo", Object.class)));
    }

    @Test
    void testIsPublicWithPrivateMember() throws Exception {
        assertFalse(MemberUtils.isPublic(declaredMethod("privateMethod")));
    }

    @Test
    void testIsStaticWithNull() {
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    void testIsStaticWithStaticMember() throws Exception {
        assertTrue(MemberUtils.isStatic(method("staticMethod")));
    }

    @Test
    void testIsStaticWithInstanceMember() throws Exception {
        assertFalse(MemberUtils.isStatic(method("finalMethod")));
    }

    @Test
    void testIsPackageWithPublicModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
    }

    @Test
    void testIsPackageWithProtectedModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
    }

    @Test
    void testIsPackageWithPrivateModifier() {
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    void testIsPackageWithNoAccessModifiers() {
        assertTrue(MemberUtils.isPackage(0));
        // STATIC alone is not one of PUBLIC/PROTECTED/PRIVATE, so this is still "package".
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
    }

    @Test
    void testIsMatchingMethodExact() throws Exception {
        final Method m = method("foo", String.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class}));
    }

    @Test
    void testIsMatchingMethodAssignable() throws Exception {
        final Method m = method("foo", Object.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class}));
    }

    @Test
    void testIsMatchingMethodNullArgMatchesReferenceType() throws Exception {
        final Method m = method("foo", String.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {null}));
    }

    @Test
    void testIsMatchingMethodWrongParameterCount() throws Exception {
        final Method m = method("foo", String.class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class, String.class}));
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[0]));
    }

    @Test
    void testIsMatchingMethodVarArgsOnlyAcceptsZeroOrMoreArgs() throws Exception {
        final Method m = method("varargsOnly", Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[0]));
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class}));
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class, Integer.class}));
    }

    @Test
    void testIsMatchingMethodVarArgsTail() throws Exception {
        final Method m = method("varargsTail", String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class}));
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] {String.class, String.class, Integer.class}));
        // not enough args to satisfy the non-varargs prefix
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[0]));
    }

    @Test
    void testIsMatchingConstructorExact() throws Exception {
        final Constructor<?> c = PublicFixture.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class<?>[] {String.class}));
    }

    @Test
    void testIsMatchingConstructorWrongArgCount() throws Exception {
        final Constructor<?> c = PublicFixture.class.getConstructor(String.class);
        assertFalse(MemberUtils.isMatchingConstructor(c, new Class<?>[0]));
    }

    @Test
    void testCompareMethodFitPrefersExactOverAssignable() throws Exception {
        final Method exact = method("foo", String.class);
        final Method general = method("foo", Object.class);
        // exact String match should be strictly better (lower cost) than the Object overload
        // when invoking with a String argument.
        assertTrue(MemberUtils.compareMethodFit(exact, general, new Class<?>[] {String.class}) < 0);
        assertTrue(MemberUtils.compareMethodFit(general, exact, new Class<?>[] {String.class}) > 0);
    }

    @Test
    void testCompareMethodFitEqualForSameMethod() throws Exception {
        final Method m = method("foo", String.class);
        assertEquals(0, MemberUtils.compareMethodFit(m, m, new Class<?>[] {String.class}));
    }

    @Test
    void testCompareConstructorFitPrefersExactOverAssignable() throws Exception {
        final Constructor<?> withString = PublicFixture.class.getConstructor(String.class);
        final Constructor<?> withObject = PublicFixture.class.getConstructor(Object.class);
        assertTrue(MemberUtils.compareConstructorFit(withString, withObject, new Class<?>[] {String.class}) < 0);
    }

    @Test
    void testSetAccessibleWorkaroundReturnsSameAccessibleObject() throws Exception {
        final Method m = method("finalMethod");
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertNotNull(result);
        assertEquals(m, result);
    }

    @Test
    void testSetAccessibleWorkaroundWithPrivateMemberOfPublicClassIsNoop() throws Exception {
        final Method m = declaredMethod("privateMethod");
        // Already accessible (same class) — but conceptually, setAccessibleWorkaround only
        // forces accessibility for public members of a package-private declaring class.
        // A private method on a public declaring class should simply be returned unchanged.
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertEquals(m, result);
    }

    static class PackagePrivateFixture {
        public void publicMethodOnPackagePrivateClass() {
            // empty
        }
    }

    @Test
    void testSetAccessibleWorkaroundForcesAccessOnPublicMemberOfPackagePrivateClass() throws Exception {
        final Method m = PackagePrivateFixture.class.getMethod("publicMethodOnPackagePrivateClass");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertEquals(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    void testIsPublicFieldNull() {
        assertFalse(MemberUtils.isPublic((Field) null));
    }
}
