/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    private static boolean isAsciiLetter(final char c) {
        return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z';
    }

    private static boolean isAsciiDigit(final char c) {
        return c >= '0' && c <= '9';
    }

    @Test
    void testInsecureSingleton() {
        assertNotNull(RandomStringUtils.insecure());
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
    }

    @Test
    void testSecureSingleton() {
        assertNotNull(RandomStringUtils.secure());
        assertSame(RandomStringUtils.secure(), RandomStringUtils.secure());
    }

    @Test
    void testSecureStrongSingleton() {
        assertNotNull(RandomStringUtils.secureStrong());
        assertSame(RandomStringUtils.secureStrong(), RandomStringUtils.secureStrong());
    }

    @Test
    void testSingletonsAreDistinct() {
        assertNotSame(RandomStringUtils.insecure(), RandomStringUtils.secure());
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.secureStrong());
        assertNotSame(RandomStringUtils.insecure(), RandomStringUtils.secureStrong());
    }

    @Test
    void testDeprecatedConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        final String s = instance.next(5);
        assertEquals(5, s.length());
    }

    @Test
    void testRandomZeroCount() {
        assertEquals("", RandomStringUtils.random(0));
        assertEquals("", RandomStringUtils.random(0, true, true));
        assertEquals("", RandomStringUtils.random(0, (char[]) null));
        assertEquals("", RandomStringUtils.random(0, (String) null));
    }

    @Test
    void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    void testRandomLength() {
        final String s = RandomStringUtils.random(100);
        assertEquals(100, s.length());
    }

    @Test
    void testRandomAlphabetic() {
        final String s = RandomStringUtils.randomAlphabetic(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(isAsciiLetter(s.charAt(i)), "Not a letter: " + s.charAt(i));
        }
    }

    @Test
    void testRandomAlphabeticRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.randomAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10, "length=" + s.length());
            for (int j = 0; j < s.length(); j++) {
                assertTrue(isAsciiLetter(s.charAt(j)));
            }
        }
    }

    @Test
    void testRandomAlphanumeric() {
        final String s = RandomStringUtils.randomAlphanumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(isAsciiLetter(c) || isAsciiDigit(c), "Not alphanumeric: " + c);
        }
    }

    @Test
    void testRandomNumeric() {
        final String s = RandomStringUtils.randomNumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(isAsciiDigit(s.charAt(i)), "Not a digit: " + s.charAt(i));
        }
    }

    @Test
    void testRandomAscii() {
        final String s = RandomStringUtils.randomAscii(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Out of ASCII printable range: " + (int) c);
        }
    }

    @Test
    void testRandomGraph() {
        final String s = RandomStringUtils.randomGraph(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126, "Out of graph range: " + (int) c);
        }
    }

    @Test
    void testRandomPrint() {
        final String s = RandomStringUtils.randomPrint(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Out of print range: " + (int) c);
        }
    }

    @Test
    void testRandomWithCharsArray() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(50, chars);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Unexpected char: " + c);
        }
    }

    @Test
    void testRandomWithNullCharsArrayUsesAllChars() {
        final String s = RandomStringUtils.random(10, (char[]) null);
        assertEquals(10, s.length());
    }

    @Test
    void testRandomWithEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(10, new char[0]);
            }
        });
    }

    @Test
    void testRandomWithString() {
        final String s = RandomStringUtils.random(20, "ab");
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b', "Unexpected char: " + c);
        }
    }

    @Test
    void testRandomWithEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(10, "");
            }
        });
    }

    @Test
    void testRandomWithNullStringUsesAllChars() {
        final String s = RandomStringUtils.random(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    void testRandomStartEndLettersNumbers() {
        final String s = RandomStringUtils.random(50, 'a', 'f' + 1, true, false);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 'a' && c <= 'f', "Out of expected range: " + c);
        }
    }

    @Test
    void testRandomEndLessThanOrEqualStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 10, false, false);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false);
            }
        });
    }

    @Test
    void testRandomNegativeStartOrEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false);
            }
        });
    }

    @Test
    void testRandomStartGreaterThanOrEqualCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 3, 4, false, false, chars);
            }
        });
    }

    @Test
    void testRandomEndGreaterThanCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 4, false, false, chars);
            }
        });
    }

    @Test
    void testRandomNoLettersInRangeThrows() {
        // Range [0, 'A') contains no letters, but letters=true is requested.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, 'A', true, false);
            }
        });
    }

    @Test
    void testRandomNoDigitsInRangeThrows() {
        // Range [0, '0') contains no digits, but numbers=true is requested.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, '0', false, true);
            }
        });
    }

    @Test
    void testRandomCharsArrayWithoutRequestedCategoryThrows() {
        final char[] chars = { '!', '@', '#' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, chars.length, true, false, chars);
            }
        });
    }

    @Test
    void testRandomWithSuppliedRandomIsDeterministic() {
        final char[] chars = { 'a', 'b', 'c', 'd', 'e' };
        final String s1 = RandomStringUtils.random(20, 0, 0, false, false, chars, new Random(42));
        final String s2 = RandomStringUtils.random(20, 0, 0, false, false, chars, new Random(42));
        assertEquals(s1, s2);
        assertEquals(20, s1.length());
    }

    @Test
    void testNextZeroCount() {
        assertEquals("", RandomStringUtils.secure().next(0));
    }

    @Test
    void testNextNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-5);
            }
        });
    }

    @Test
    void testNextLength() {
        final String s = RandomStringUtils.secure().next(15);
        assertEquals(15, s.length());
    }

    @Test
    void testNextWithCharsVarargs() {
        final String s = RandomStringUtils.insecure().next(30, 'x', 'y');
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y');
        }
    }

    @Test
    void testNextWithNullCharsVarargs() {
        final String s = RandomStringUtils.insecure().next(10, (char[]) null);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithStringChars() {
        final String s = RandomStringUtils.insecure().next(15, "qr");
        assertEquals(15, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'q' || c == 'r');
        }
    }

    @Test
    void testNextWithNullStringChars() {
        final String s = RandomStringUtils.insecure().next(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    void testNextAlphabetic() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(isAsciiLetter(s.charAt(i)));
        }
    }

    @Test
    void testNextAlphabeticRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.insecure().nextAlphabetic(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testNextAlphanumeric() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(isAsciiLetter(c) || isAsciiDigit(c));
        }
    }

    @Test
    void testNextAlphanumericRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.insecure().nextAlphanumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testNextAscii() {
        final String s = RandomStringUtils.insecure().nextAscii(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testNextAsciiRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.insecure().nextAscii(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testNextGraph() {
        final String s = RandomStringUtils.insecure().nextGraph(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126);
        }
    }

    @Test
    void testNextGraphRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.insecure().nextGraph(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testNextNumeric() {
        final String s = RandomStringUtils.insecure().nextNumeric(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(isAsciiDigit(s.charAt(i)));
        }
    }

    @Test
    void testNextNumericRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.insecure().nextNumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testNextPrint() {
        final String s = RandomStringUtils.insecure().nextPrint(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testNextPrintRange() {
        for (int i = 0; i < 50; i++) {
            final String s = RandomStringUtils.insecure().nextPrint(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testToStringContainsClassName() {
        final String s = RandomStringUtils.secure().toString();
        assertNotNull(s);
        assertTrue(s.startsWith("RandomStringUtils ["));
    }

    @Test
    void testRandomDistinctCalls() {
        final String s1 = RandomStringUtils.randomAlphanumeric(32);
        final String s2 = RandomStringUtils.randomAlphanumeric(32);
        assertFalse(s1.equals(s2) && s1.length() == 0);
        assertEquals(32, s1.length());
        assertEquals(32, s2.length());
    }

    @Test
    void testSingleCharacterSetProducesOnlyThatCharacter() {
        final char[] chars = { 'q' };
        final String s = RandomStringUtils.random(25, chars);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertEquals('q', s.charAt(i));
        }
    }

    @Test
    void testCountOne() {
        final String s = RandomStringUtils.randomNumeric(1);
        assertEquals(1, s.length());
        assertTrue(isAsciiDigit(s.charAt(0)));
    }
}
