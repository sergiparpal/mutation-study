/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class LocaleUtilsAgentTest {

    // -- availableLocaleList() --

    @Test
    void testAvailableLocaleListNotEmptyAndSorted() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertFalse(list.isEmpty());
        for (int i = 1; i < list.size(); i++) {
            final String prev = list.get(i - 1).toString();
            final String cur = list.get(i).toString();
            assertTrue(prev.compareTo(cur) <= 0, "Not sorted at index " + i + ": " + prev + " > " + cur);
        }
    }

    @Test
    void testAvailableLocaleListUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    @Test
    void testAvailableLocaleListCached() {
        final List<Locale> list1 = LocaleUtils.availableLocaleList();
        final List<Locale> list2 = LocaleUtils.availableLocaleList();
        assertSame(list1, list2);
    }

    // -- availableLocaleSet() --

    @Test
    void testAvailableLocaleSetContainsAllOfList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        final Iterator<Locale> it = list.iterator();
        while (it.hasNext()) {
            final Locale locale = it.next();
            assertTrue(set.contains(locale));
        }
        assertEquals(list.size(), set.size());
    }

    @Test
    void testAvailableLocaleSetUnmodifiable() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                set.add(Locale.US);
            }
        });
    }

    // -- isAvailableLocale(Locale) --

    @Test
    void testIsAvailableLocaleTrueForUs() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
    }

    @Test
    void testIsAvailableLocaleFalseForUnknown() {
        final Locale bogus = new Locale("xx", "YY", "zzzzzzzzz");
        assertFalse(LocaleUtils.isAvailableLocale(bogus));
    }

    @Test
    void testIsAvailableLocaleNullReturnsFalse() {
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    // -- countriesByLanguage(String) --

    @Test
    void testCountriesByLanguageNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguageEn() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertFalse(list.isEmpty());
        final Iterator<Locale> it = list.iterator();
        while (it.hasNext()) {
            final Locale locale = it.next();
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty(), "Expected a country for " + locale);
            assertTrue(locale.getVariant().isEmpty(), "Expected no variant for " + locale);
        }
    }

    @Test
    void testCountriesByLanguageUnmodifiable() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    // -- languagesByCountry(String) --

    @Test
    void testLanguagesByCountryNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryUs() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertFalse(list.isEmpty());
        final Iterator<Locale> it = list.iterator();
        while (it.hasNext()) {
            final Locale locale = it.next();
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty(), "Expected no variant for " + locale);
        }
    }

    @Test
    void testLanguagesByCountryUnmodifiable() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    // -- localeLookupList --

    @Test
    void testLocaleLookupListSingleArgPlainLocale() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("en"));
        assertEquals(1, list.size());
        assertEquals(new Locale("en"), list.get(0));
    }

    @Test
    void testLocaleLookupListSingleArgFull() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    void testLocaleLookupListTwoArgsDifferentDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final Locale defaultLocale = new Locale("en");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(new Locale("en"), list.get(3));
    }

    @Test
    void testLocaleLookupListNullLocaleReturnsEmpty() {
        final List<Locale> list = LocaleUtils.localeLookupList(null, Locale.US);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("en"));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    // -- isLanguageUndetermined --

    @Test
    void testIsLanguageUndeterminedNullIsTrue() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
    }

    @Test
    void testIsLanguageUndeterminedDeterminedIsFalse() {
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
    }

    @Test
    void testIsLanguageUndeterminedEmptyLanguageIsTrue() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
    }

    // -- toLocale(Locale) --

    @Test
    void testToLocaleLocaleNonNullReturnsSame() {
        assertSame(Locale.US, LocaleUtils.toLocale(Locale.US));
    }

    @Test
    void testToLocaleLocaleNullReturnsDefault() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    // -- toLocale(String) happy paths from the documented examples --

    @Test
    void testToLocaleStringNullReturnsNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        final Locale locale = LocaleUtils.toLocale("en");
        assertEquals(new Locale("en", ""), locale);
    }

    @Test
    void testToLocaleStringLanguageCountryUnderscore() {
        final Locale locale = LocaleUtils.toLocale("en_GB");
        assertEquals(new Locale("en", "GB"), locale);
    }

    @Test
    void testToLocaleStringLanguageCountryDash() {
        final Locale locale = LocaleUtils.toLocale("en-GB");
        assertEquals(new Locale("en", "GB"), locale);
    }

    @Test
    void testToLocaleStringNumericAreaCode() {
        final Locale locale = LocaleUtils.toLocale("en_001");
        assertEquals("en", locale.getLanguage());
        assertEquals("001", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageCountryVariant() {
        final Locale locale = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    void testToLocaleStringCountryOnlyFromBareIsoCode() {
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    void testToLocaleStringUnderscorePrefixCountryOnly() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringUnderscorePrefixVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_VARIANT");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("VARIANT", locale.getVariant());
    }

    @Test
    void testToLocaleStringSpecialCaseThai() {
        final Locale locale = LocaleUtils.toLocale("th_TH_TH_#u-nu-thai");
        assertEquals("th", locale.getLanguage());
        assertEquals("TH", locale.getCountry());
        assertEquals("TH", locale.getVariant());
    }

    @Test
    void testToLocaleStringSpecialCaseJapanese() {
        final Locale locale = LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese");
        assertEquals("ja", locale.getLanguage());
        assertEquals("JP", locale.getCountry());
        assertEquals("JP", locale.getVariant());
    }

    // -- toLocale(String) error / boundary cases --

    @Test
    void testToLocaleStringTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("e");
            }
        });
    }

    @Test
    void testToLocaleStringInvalidFormatThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("abcd");
            }
        });
    }

    @Test
    void testToLocaleStringInvalidCountryCodeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // "en" is a valid language, but "G" is not a valid ISO-3166 or UN M.49 country code.
                LocaleUtils.toLocale("en_G");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscorePrefixTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscorePrefixLowercaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscorePrefixCountryPlusTwoCharsThrows() {
        // Length 4 after the leading separator is neither the "_CC" (country only, length 3)
        // nor the "_CC_variant" (length >= 5) form, so it must be rejected.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBX");
            }
        });
    }

    @Test
    void testToLocaleStringUnderscorePrefixSeparatorMismatchThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GB-VARIANT");
            }
        });
    }

    @Test
    void testToLocaleStringInvalidLanguageWithNumericAreaCodeThrows() {
        // "q" is a one-letter language code, which is not a well-formed ISO-639 code,
        // so the whole string must be rejected even though "001" alone is a valid UN M.49 area code.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("q_001");
            }
        });
    }

    // -- ofCountry(String) --

    @Test
    void testOfCountry() {
        final Locale locale = LocaleUtils.ofCountry("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    void testOfCountryNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.ofCountry(null);
            }
        });
    }

    // -- deprecated public constructor --

    @Test
    void testConstructorIsUsable() {
        final LocaleUtils instance = new LocaleUtils();
        assertNotNull(instance);
    }
}
