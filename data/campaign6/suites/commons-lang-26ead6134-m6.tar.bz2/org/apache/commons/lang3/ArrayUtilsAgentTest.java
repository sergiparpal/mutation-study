/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testEmptyArrayConstants() {
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(Integer.MAX_VALUE - 8, ArrayUtils.SAFE_MAX_ARRAY_LENGTH);
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    @Test
    void testAddPrimitiveAndObject() {
        int[] intArray = ArrayUtils.add((int[]) null, 1);
        assertArrayEquals(new int[] { 1 }, intArray);
        intArray = ArrayUtils.add(new int[] { 1, 2 }, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, intArray);

        final String[] stringArray = ArrayUtils.add(new String[] { "a", "b" }, "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, stringArray);
        assertEquals(String.class, stringArray.getClass().getComponentType());
    }

    @Test
    void testAddWithIndex() {
        final int[] result = ArrayUtils.add(new int[] { 1, 3 }, 1, 2);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);

        final String[] result2 = ArrayUtils.add(new String[] { "a", "c" }, 1, "b");
        assertArrayEquals(new String[] { "a", "b", "c" }, result2);

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, -1, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, 3, 9);
            }
        });
    }

    @Test
    void testAddAll() {
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll(new int[] { 1, 2 }, (int[]) null));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll((int[]) null, new int[] { 1, 2 }));
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.addAll(new int[] { 1, 2 }, new int[] { 3, 4 }));

        final String[] joined = ArrayUtils.addAll(new String[] { "a", "b" }, "c", "d");
        assertArrayEquals(new String[] { "a", "b", "c", "d" }, joined);

        final Number[] numbers = new Number[] { Integer.valueOf(1) };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.addAll(numbers, "not-a-number");
            }
        });
    }

    @Test
    void testAddFirst() {
        assertArrayEquals(new int[] { 9 }, ArrayUtils.addFirst((int[]) null, 9));
        assertArrayEquals(new int[] { 0, 1, 2 }, ArrayUtils.addFirst(new int[] { 1, 2 }, 0));
        assertArrayEquals(new String[] { "z", "a" }, ArrayUtils.addFirst(new String[] { "a" }, "z"));
    }

    @Test
    void testClone() {
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));

        final int[] original = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);

        final String[] originalObjects = { "a", "b" };
        final String[] clonedObjects = ArrayUtils.clone(originalObjects);
        assertArrayEquals(originalObjects, clonedObjects);
        assertNotSame(originalObjects, clonedObjects);
    }

    @Test
    void testConcat() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.concat((int[][]) null);
            }
        });
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.concat(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.concat(new int[] { 1, 2 }, null));
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.concat(new int[0]));
    }

    @Test
    void testContains() {
        final int[] intArray = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(intArray, 2));
        assertFalse(ArrayUtils.contains(intArray, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final double[] doubleArray = { 1.0, 2.0, 3.0 };
        assertTrue(ArrayUtils.contains(doubleArray, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(doubleArray, 2.5, 0.1));

        final Object[] objectArray = { "a", null, "c" };
        assertTrue(ArrayUtils.contains(objectArray, (Object) null));
        assertTrue(ArrayUtils.contains(objectArray, "c"));
        assertFalse(ArrayUtils.contains(objectArray, "z"));
    }

    @Test
    void testContainsAny() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.containsAny(array, 9, 2));
        assertFalse(ArrayUtils.containsAny(array, 7, 8));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));

        final String[] objArray = { "a", "b" };
        assertTrue(ArrayUtils.containsAny(objArray, "x", "b"));
        assertFalse(ArrayUtils.containsAny(objArray, "x", "y"));
    }

    @Test
    void testGet() {
        final String[] array = { "a", "b", "c" };
        assertEquals("b", ArrayUtils.get(array, 1));
        assertNull(ArrayUtils.get(array, 10));
        assertNull(ArrayUtils.get(array, -1));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("a", ArrayUtils.get(array, 0, "default"));
    }

    @Test
    void testGetComponentTypeAndDimensionsAndLength() {
        final String[] array = { "a" };
        assertEquals(String.class, ArrayUtils.getComponentType(array));
        assertNull(ArrayUtils.getComponentType((Object[]) null));

        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[0]));
        assertEquals(2, ArrayUtils.getDimensions(new int[0][0]));

        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    void testHashCode() {
        assertEquals(629, ArrayUtils.hashCode(null));
        final int[] array = { 1, 2, 3 };
        assertEquals(ArrayUtils.hashCode(new int[] { 1, 2, 3 }), ArrayUtils.hashCode(array));
        assertFalse(ArrayUtils.hashCode(array) == ArrayUtils.hashCode(new int[] { 3, 2, 1 }));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet expected = new BitSet();
        expected.set(0);
        expected.set(2);
        expected.set(4);
        assertEquals(expected, ArrayUtils.indexesOf(array, 1));
        assertTrue(ArrayUtils.indexesOf(array, 9).isEmpty());
        assertTrue(ArrayUtils.indexesOf((int[]) null, 1).isEmpty());
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        final int[] array = { 1, 2, 3, 2, 1 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -10));

        final Object[] objects = { "a", "b", "a" };
        assertEquals(0, ArrayUtils.indexOf(objects, "a"));
        assertEquals(2, ArrayUtils.lastIndexOf(objects, "a"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(objects, (Object) null));
    }

    @Test
    void testInsert() {
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
        final int[] result = ArrayUtils.insert(1, new int[] { 1, 3 }, 2);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.insert(0, new int[] { 1, 2 }, (int[]) null));

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new int[] { 1, 2 }, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(5, new int[] { 1, 2 }, 9);
            }
        });
    }

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((Object[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new Object[] { "a" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] { "a" }, -1));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] { "a" }, 1));
    }

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));

        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));
        assertFalse(ArrayUtils.isNotEmpty(new Object[0]));
    }

    @Test
    void testIsSameLengthAndIsSameType() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));

        assertTrue(ArrayUtils.isSameType(new String[0], new String[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Integer[0]));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new String[0]);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsEqualsDeprecated() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] { 1 }));

        final Integer[] boxed = { 3, 1, 2 };
        assertFalse(ArrayUtils.isSorted(boxed));
        final Comparator<Integer> reverse = new Comparator<Integer>() {
            @Override
            public int compare(final Integer a, final Integer b) {
                return b.compareTo(a);
            }
        };
        assertTrue(ArrayUtils.isSorted(new Integer[] { 3, 2, 1 }, reverse));
    }

    @Test
    void testNullToEmpty() {
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = { 1, 2 };
        assertSame(array, ArrayUtils.nullToEmpty(array));

        assertArrayEquals(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        final String[] strings = { "a" };
        assertSame(strings, ArrayUtils.nullToEmpty(strings));
    }

    @Test
    void testRemove() {
        assertArrayEquals(new int[] { 1, 3 }, ArrayUtils.remove(new int[] { 1, 2, 3 }, 1));
        assertArrayEquals(new String[] { "b" }, ArrayUtils.remove(new String[] { "a", "b" }, 0));

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2 }, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2 }, 2);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    void testRemoveAll() {
        assertArrayEquals(new int[] { 2 }, ArrayUtils.removeAll(new int[] { 1, 2, 3 }, 0, 2));
        assertArrayEquals(new int[] { 1, 2, 3 }, ArrayUtils.removeAll(new int[] { 1, 2, 3 }));
        assertArrayEquals(new String[] { "b" }, ArrayUtils.removeAll(new String[] { "a", "b", "c" }, 2, 0));
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] array = { 1, 2, 1, 3, 1 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.removeAllOccurrences(array, 1));
        assertArrayEquals(array, ArrayUtils.removeAllOccurrences(array, 9));

        final String[] strings = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b" }, ArrayUtils.removeAllOccurrences(strings, "a"));
    }

    @Test
    void testRemoveElement() {
        final int[] array = { 1, 2, 1 };
        assertArrayEquals(new int[] { 2, 1 }, ArrayUtils.removeElement(array, 1));
        assertArrayEquals(array, ArrayUtils.removeElement(array, 99));

        final String[] strings = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b", "a" }, ArrayUtils.removeElement(strings, "a"));
    }

    @Test
    void testRemoveElements() {
        final int[] array = { 1, 2, 1, 3 };
        assertArrayEquals(new int[] { 2, 1, 3 }, ArrayUtils.removeElements(array, 1));
        assertArrayEquals(new int[] { 3 }, ArrayUtils.removeElements(array, 1, 1, 2));
        assertArrayEquals(array, ArrayUtils.removeElements(array));
    }

    @Test
    void testReverse() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] empty = {};
        ArrayUtils.reverse(empty);
        assertArrayEquals(new int[] {}, empty);

        final int[] ranged = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(ranged, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, ranged);

        ArrayUtils.reverse((int[]) null);

        final String[] objects = { "a", "b", "c" };
        ArrayUtils.reverse(objects);
        assertArrayEquals(new String[] { "c", "b", "a" }, objects);
    }

    @Test
    void testSetAll() {
        final Integer[] array = new Integer[3];
        ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            @Override
            public Integer apply(final int index) {
                return index * 2;
            }
        });
        assertArrayEquals(new Integer[] { 0, 2, 4 }, array);
    }

    @Test
    void testShift() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] { 5, 1, 2, 3, 4 }, array);

        final int[] array2 = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array2, array2.length);
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, array2);

        final int[] array3 = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array3, -1);
        assertArrayEquals(new int[] { 2, 3, 4, 5, 1 }, array3);

        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    void testShuffle() {
        final int[] array = { 1, 2, 3, 4, 5 };
        final int[] original = ArrayUtils.clone(array);
        ArrayUtils.shuffle(array, new Random(42));
        assertEquals(original.length, array.length);
        final int[] sortedOriginal = ArrayUtils.clone(original);
        final int[] sortedShuffled = ArrayUtils.clone(array);
        java.util.Arrays.sort(sortedOriginal);
        java.util.Arrays.sort(sortedShuffled);
        assertArrayEquals(sortedOriginal, sortedShuffled);
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2 }, new byte[0]));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, new byte[] { 1, 2 }));
    }

    @Test
    void testSubarray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, ArrayUtils.subarray(array, -2, 10));
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.subarray(array, 3, 1));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));

        final String[] objects = { "a", "b", "c" };
        assertArrayEquals(new String[] { "b", "c" }, ArrayUtils.subarray(objects, 1, 5));
    }

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);

        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.swap(array3, -1, 1);
        assertArrayEquals(new int[] { 2, 1, 3 }, array3);

        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testToArray() {
        final String[] result = ArrayUtils.toArray("a", "b");
        assertArrayEquals(new String[] { "a", "b" }, result);
    }

    @Test
    void testToMap() {
        assertNull(ArrayUtils.toMap(null));

        final Object[] array = { new Object[] { "key1", "value1" }, new Object[] { "key2", "value2" } };
        final Map<Object, Object> map = ArrayUtils.toMap(array);
        assertEquals(2, map.size());
        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] { new Object[] { "onlyOneElement" } });
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] { "not an entry or array" });
            }
        });
    }

    @Test
    void testToObjectAndToPrimitive() {
        final Integer[] boxed = ArrayUtils.toObject(new int[] { 1, 2, 3 });
        assertArrayEquals(new Integer[] { 1, 2, 3 }, boxed);
        assertEquals(0, ArrayUtils.toObject(new int[0]).length);
        assertNull(ArrayUtils.toObject((int[]) null));

        final int[] primitives = ArrayUtils.toPrimitive(new Integer[] { 4, 5 });
        assertArrayEquals(new int[] { 4, 5 }, primitives);
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] { 1, null });
            }
        });

        assertArrayEquals(new int[] { 1, 9 }, ArrayUtils.toPrimitive(new Integer[] { 1, null }, 9));

        assertArrayEquals(new boolean[] { true, false }, ArrayUtils.toPrimitive(new Boolean[] { true, false }));
        assertArrayEquals(new boolean[] { true, false }, ArrayUtils.toPrimitive(new Boolean[] { true, null }, false));
    }

    @Test
    void testToStringMethods() {
        assertEquals("{}", ArrayUtils.toString(new Object[0]));
        assertEquals("{}", ArrayUtils.toString(new Object[0], "null-default"));
        assertEquals("null-default", ArrayUtils.toString(null, "null-default"));
        assertEquals("{}", ArrayUtils.toString(null));

        final String[] strings = ArrayUtils.toStringArray(new Object[] { "a", Integer.valueOf(1) });
        assertArrayEquals(new String[] { "a", "1" }, strings);
    }
}
