/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetWithExplicitOptions() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testDecimalEntityWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A", neu.translate("Test &#65;"));
    }

    @Test
    void testHexEntityLowerCaseX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A", neu.translate("Test &#x41;"));
    }

    @Test
    void testHexEntityUpperCaseX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A", neu.translate("Test &#X41;"));
    }

    @Test
    void testSemiColonRequiredButMissingIsIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonRequired);
        final String input = "Test &#65 not test";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testSemiColonOptionalAllowsMissingSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("Test A not test", neu.translate("Test &#65 not test"));
    }

    @Test
    void testErrorIfNoSemiColonThrowsWhenMissing() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final String input = "Test &#65 not test";
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                neu.translate(input);
            }
        });
        assertEquals("Semi-colon required at end of numeric entity", ex.getMessage());
    }

    @Test
    void testErrorIfNoSemiColonDoesNotThrowWhenPresent() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertEquals("Test A", neu.translate("Test &#65;"));
    }

    @Test
    void testOutOfBoundsTrailingAmp() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test &", neu.translate("Test &"));
        assertEquals("Test &#", neu.translate("Test &#"));
        assertEquals("Test &#x", neu.translate("Test &#x"));
        assertEquals("Test &#X", neu.translate("Test &#X"));
    }

    @Test
    void testHexPrefixOnlyAtEndOfInputReturnsZero() throws Exception {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("&#x", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testNotAnEntityReturnsZero() throws Exception {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("hello", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testInvalidNumberReturnsZero() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testInvalidHexNumberReturnsZero() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#x;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testEntityValueAboveMaxCodePointIsIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#1114112;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testEntityValueAtMaxCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String expected = new String(Character.toChars(Character.MAX_CODE_POINT));
        assertEquals("Test " + expected, neu.translate("Test &#1114111;"));
    }

    @Test
    void testEntityValueAtMinCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test \u0000", neu.translate("Test &#0;"));
    }

    @Test
    void testSupplementaryUnescaping() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("𐰢", neu.translate("&#68642;"));
    }

    @Test
    void testTranslateReturnsConsumedLengthDecimalWithSemiColon() throws Exception {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("&#65;REST", 0, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateReturnsConsumedLengthHexWithSemiColon() throws Exception {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("&#x41;REST", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateAtNonZeroIndex() throws Exception {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final String input = "xx&#65;";
        final int consumed = neu.translate(input, 2, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testUnfinishedEntityAllThreeModes() {
        NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final String input = "Test &#x30 not test";
        final String expected = "Test 0 not test";
        assertEquals(expected, neu.translate(input));

        neu = new NumericEntityUnescaper();
        assertEquals(input, neu.translate(input));

        final NumericEntityUnescaper failingNeu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                failingNeu.translate(input);
            }
        });
    }
}
