/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    interface AgentIFaceA {
        // marker
    }

    interface AgentIFaceB extends AgentIFaceA {
        // marker
    }

    static class AgentGrandParent implements AgentIFaceB {
        // empty
    }

    static class AgentParent extends AgentGrandParent {
        // empty
    }

    static class AgentChild extends AgentParent {
        // empty
    }

    static class AgentNested {
        // static nested class, used for isInnerClass tests
    }

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>(Arrays.asList(String.class, Boolean.class, Byte.class));
        Collections.sort(list, ClassUtils.comparator());
        assertEquals(Arrays.asList(Boolean.class, Byte.class, String.class), list);
    }

    @Test
    public void testConvertClassesToClassNames() {
        final List<Class<?>> classes = Arrays.asList(String.class, null, Integer.class);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(Arrays.asList("java.lang.String", null, "java.lang.Integer"), names);
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        final List<String> names = Arrays.asList("java.lang.String", "not.a.real.ClassName", null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertSame(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testGetAbbreviatedNameFromClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 10));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
    }

    @Test
    public void testGetAbbreviatedNameFromStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameLengthZeroThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameLengthNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
        assertEquals("Foo", ClassUtils.getAbbreviatedName("Foo", 1));
    }

    @Test
    public void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertTrue(interfaces.contains(AgentIFaceA.class));
        assertTrue(interfaces.contains(AgentIFaceB.class));
        assertEquals(2, interfaces.size());
        assertNull(ClassUtils.getAllInterfaces(null));
        assertTrue(ClassUtils.getAllInterfaces(String.class).contains(CharSequence.class));
    }

    @Test
    public void testGetAllSuperclasses() {
        final List<Class<?>> supers = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentParent.class, AgentGrandParent.class, Object.class), supers);
        assertNull(ClassUtils.getAllSuperclasses(null));
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
    }

    @Test
    public void testGetClassSuccess() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClass("java.lang.String"));
        assertSame(int.class, ClassUtils.getClass("int"));
        assertSame(int[].class, ClassUtils.getClass("[I"));
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertSame(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertSame(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    public void testGetClassNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassNotFoundThrows() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("com.example.DoesNotExist12345");
            }
        });
    }

    @Test
    public void testGetClassNameTooLongThrowsIllegalArgumentException() {
        final StringBuilder sb = new StringBuilder(70000);
        for (int i = 0; i < 65536; i++) {
            sb.append('a');
        }
        final String longName = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(longName);
            }
        });
    }

    @Test
    public void testGetClassArrayDimensionTooLargeThrowsIllegalArgumentException() {
        final StringBuilder sb = new StringBuilder("int");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String bigArrayName = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(bigArrayName);
            }
        });
    }

    @Test
    public void testGetClassWithMalformedArraySuffixThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("java.lang.String[]junk[]");
            }
        });
    }

    @Test
    public void testGetClassWithEmptyNameThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("");
            }
        });
    }

    @Test
    public void testGetComponentType() {
        assertSame(String.class, ClassUtils.getComponentType(String[].class));
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetName() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("fallback", ClassUtils.getName((Object) null, "fallback"));
    }

    @Test
    public void testGetPackageCanonicalNameAndPackageName() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("fallback", ClassUtils.getPackageCanonicalName((Object) null, "fallback"));
    }

    @Test
    public void testGetPackageCanonicalNameInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getPackageCanonicalName("[");
            }
        });
    }

    @Test
    public void testGetPublicMethodOnPublicClass() throws Exception {
        final Method m = ClassUtils.getPublicMethod(String.class, "length");
        assertEquals("length", m.getName());
        assertTrue(Modifier.isPublic(m.getDeclaringClass().getModifiers()));
    }

    @Test
    public void testGetPublicMethodOnPackagePrivateImplClass() throws Exception {
        final List<String> list = Collections.unmodifiableList(new ArrayList<String>());
        assertFalse(Modifier.isPublic(list.getClass().getModifiers()));
        final Method m = ClassUtils.getPublicMethod(list.getClass(), "size");
        assertTrue(Modifier.isPublic(m.getDeclaringClass().getModifiers()));
        assertEquals(0, m.invoke(list));
    }

    @Test
    public void testGetPublicMethodNotFoundThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodHere");
            }
        });
    }

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName(ClassUtils.class));
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("fallback", ClassUtils.getShortCanonicalName((Object) null, "fallback"));
    }

    @Test
    public void testGetShortClassName() {
        assertEquals("ClassUtils", ClassUtils.getShortClassName(ClassUtils.class));
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("fallback", ClassUtils.getShortClassName((Object) null, "fallback"));
    }

    @Test
    public void testGetSimpleName() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Class<?>) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
    }

    @Test
    public void testHierarchyExcludingInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(AgentChild.class);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        for (final Class<?> c : hierarchy) {
            list.add(c);
        }
        assertEquals(Arrays.asList(AgentChild.class, AgentParent.class, AgentGrandParent.class, Object.class), list);
    }

    @Test
    public void testHierarchyIncludingInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        for (final Class<?> c : hierarchy) {
            list.add(c);
        }
        assertTrue(list.contains(AgentChild.class));
        assertTrue(list.contains(AgentIFaceA.class));
        assertTrue(list.contains(AgentIFaceB.class));
        assertTrue(list.contains(Object.class));
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        it.next();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    @Test
    public void testIsAssignable() {
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.TYPE, null));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, null));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Long.TYPE));
        assertFalse(ClassUtils.isAssignable(Long.TYPE, Integer.TYPE));
        assertTrue(ClassUtils.isAssignable(Integer.class, Integer.TYPE));
        assertFalse(ClassUtils.isAssignable(Integer.class, Long.TYPE, false));
        assertTrue(ClassUtils.isAssignable(Byte.TYPE, Short.TYPE));
        assertFalse(ClassUtils.isAssignable(Boolean.TYPE, Integer.TYPE));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class[] { String.class, Integer.TYPE }, new Class[] { Object.class, Long.TYPE }));
        assertFalse(ClassUtils.isAssignable(new Class[] { String.class }, new Class[] { Object.class, Long.TYPE }));
        assertFalse(ClassUtils.isAssignable(new Class[] { String.class }, (Class<?>[]) null));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsInnerClass() {
        assertTrue(ClassUtils.isInnerClass(AgentNested.class));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.TYPE));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(Boolean.TYPE));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(Collections.unmodifiableList(new ArrayList<String>()).getClass()));
    }

    @Test
    public void testIsPublicNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        final Class<?>[] empty = ClassUtils.primitivesToWrappers();
        assertEquals(0, empty.length);
        assertArrayEquals(new Class<?>[] { Integer.class, String.class, null }, ClassUtils.primitivesToWrappers(Integer.TYPE, String.class, null));
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(Integer.TYPE));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertArrayEquals(ArrayUtils.EMPTY_CLASS_ARRAY, ClassUtils.toClass());
        assertArrayEquals(new Class<?>[] { String.class, null, Integer.class }, ClassUtils.toClass("hi", null, 1));
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        final Class<?>[] empty = ClassUtils.wrappersToPrimitives();
        assertEquals(0, empty.length);
        assertArrayEquals(new Class<?>[] { Integer.TYPE, null, null }, ClassUtils.wrappersToPrimitives(Integer.class, String.class, null));
    }

    @Test
    public void testWrapperToPrimitive() {
        assertEquals(Integer.TYPE, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testConstructorIsPublicButDeprecated() {
        assertNotNull(new ClassUtils());
    }
}
