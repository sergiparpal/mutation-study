/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.UUID;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Conversion}.
 */
class ConversionAgentTest {

    // ---------------------------------------------------------------
    // binaryBeMsb0ToHexDigit
    // ---------------------------------------------------------------

    @Test
    void testBinaryBeMsb0ToHexDigit_docExample1() {
        // (1, 0, 0, 0) is converted to '8'
        final boolean[] src = { true, false, false, false };
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(src));
    }

    @Test
    void testBinaryBeMsb0ToHexDigit_docExample2() {
        // (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0) is converted to '4'
        final boolean[] src = { true, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false };
        assertEquals('4', Conversion.binaryBeMsb0ToHexDigit(src));
    }

    @Test
    void testBinaryBeMsb0ToHexDigitWithPos_docExamples() {
        final boolean[] src1 = { true, false, false, false };
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(src1, 0));
        final boolean[] src2 = { true, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false };
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(src2, 2));
    }

    @Test
    void testBinaryBeMsb0ToHexDigit_emptyArrayThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryBeMsb0ToHexDigit(new boolean[0]));
    }

    @Test
    void testBinaryBeMsb0ToHexDigit_srcPosOutOfBoundsThrows() {
        final boolean[] src = { true, false, false, false };
        assertThrows(IndexOutOfBoundsException.class, () -> Conversion.binaryBeMsb0ToHexDigit(src, 4));
    }

    @Test
    void testBinaryBeMsb0ToHexDigit_negativeSrcPosThrows() {
        final boolean[] src = { true, false, false, false };
        assertThrows(IndexOutOfBoundsException.class, () -> Conversion.binaryBeMsb0ToHexDigit(src, -1));
    }

    // ---------------------------------------------------------------
    // binaryToByte / Int / Long / Short  (and inverse: byteToBinary etc.)
    // ---------------------------------------------------------------

    @Test
    void testBinaryToByte_zeroNBoolsReturnsDstInit() {
        assertEquals((byte) 42, Conversion.binaryToByte(new boolean[0], 5, (byte) 42, 3, 0));
    }

    @Test
    void testBinaryToByte_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToByte(new boolean[8], 0, (byte) 0, 1, 8));
    }

    @Test
    void testBinaryToByte_roundTripWithByteToBinary() {
        for (int v = -128; v <= 127; v += 7) {
            final byte original = (byte) v;
            final boolean[] bits = Conversion.byteToBinary(original, 0, new boolean[8], 0, 8);
            final byte roundTripped = Conversion.binaryToByte(bits, 0, (byte) 0, 0, 8);
            assertEquals(original, roundTripped, "roundtrip failed for " + v);
        }
    }

    @Test
    void testBinaryToInt_roundTripWithIntToBinary() {
        final int[] values = { 0, 1, -1, Integer.MAX_VALUE, Integer.MIN_VALUE, 0x12345678, -42 };
        for (final int original : values) {
            final boolean[] bits = Conversion.intToBinary(original, 0, new boolean[32], 0, 32);
            final int roundTripped = Conversion.binaryToInt(bits, 0, 0, 0, 32);
            assertEquals(original, roundTripped, "roundtrip failed for " + original);
        }
    }

    @Test
    void testBinaryToInt_zeroNBoolsReturnsDstInit() {
        assertEquals(99, Conversion.binaryToInt(new boolean[0], 0, 99, 0, 0));
    }

    @Test
    void testBinaryToInt_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToInt(new boolean[32], 0, 0, 1, 32));
    }

    @Test
    void testBinaryToLong_roundTripWithLongToBinary() {
        final long[] values = { 0L, 1L, -1L, Long.MAX_VALUE, Long.MIN_VALUE, 0x123456789ABCDEFL, -42L };
        for (final long original : values) {
            final boolean[] bits = Conversion.longToBinary(original, 0, new boolean[64], 0, 64);
            final long roundTripped = Conversion.binaryToLong(bits, 0, 0L, 0, 64);
            assertEquals(original, roundTripped, "roundtrip failed for " + original);
        }
    }

    @Test
    void testBinaryToLong_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToLong(new boolean[64], 0, 0L, 1, 64));
    }

    @Test
    void testBinaryToShort_roundTripWithShortToBinary() {
        final short[] values = { 0, 1, -1, Short.MAX_VALUE, Short.MIN_VALUE, (short) 0x1234, -42 };
        for (final short original : values) {
            final boolean[] bits = Conversion.shortToBinary(original, 0, new boolean[16], 0, 16);
            final short roundTripped = Conversion.binaryToShort(bits, 0, (short) 0, 0, 16);
            assertEquals(original, roundTripped, "roundtrip failed for " + original);
        }
    }

    @Test
    void testBinaryToShort_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToShort(new boolean[16], 0, (short) 0, 1, 16));
    }

    // ---------------------------------------------------------------
    // binaryToHexDigit (LSB0) and binaryToHexDigitMsb0_4bits
    // ---------------------------------------------------------------

    @Test
    void testBinaryToHexDigit_docExample() {
        // (1, 0, 0, 0) is converted to '1'
        final boolean[] src = { true, false, false, false };
        assertEquals('1', Conversion.binaryToHexDigit(src));
        assertEquals('1', Conversion.binaryToHexDigit(src, 0));
    }

    @Test
    void testBinaryToHexDigit_allSixteenValues() {
        for (int i = 0; i < 16; i++) {
            final boolean[] src = new boolean[4];
            for (int b = 0; b < 4; b++) {
                src[b] = (i >> b & 1) != 0;
            }
            final char expected = Character.forDigit(i, 16);
            assertEquals(expected, Conversion.binaryToHexDigit(src), "mismatch for value " + i);
        }
    }

    @Test
    void testBinaryToHexDigit_emptyThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToHexDigit(new boolean[0]));
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits_docExample1() {
        // (1, 0, 0, 0) is converted to '8'
        final boolean[] src = { true, false, false, false };
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(src));
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits_docExample2() {
        // (1, 0, 0, 1, 1, 0, 1, 0) with srcPos = 3 is converted to 'd'
        final boolean[] src = { true, false, false, true, true, false, true, false };
        assertEquals('d', Conversion.binaryToHexDigitMsb0_4bits(src, 3));
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits_tooLongThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToHexDigitMsb0_4bits(new boolean[9]));
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits_notEnoughBitsThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.binaryToHexDigitMsb0_4bits(new boolean[3]));
    }

    // ---------------------------------------------------------------
    // byteArrayToInt / Long / Short  (+ inverse intToByteArray etc.)
    // ---------------------------------------------------------------

    @Test
    void testByteArrayToInt_littleEndian() {
        final byte[] src = { 0x01, 0x02, 0x03, 0x04 };
        assertEquals(0x04030201, Conversion.byteArrayToInt(src, 0, 0, 0, 4));
    }

    @Test
    void testByteArrayToInt_zeroNBytesReturnsDstInit() {
        assertEquals(123, Conversion.byteArrayToInt(new byte[0], 0, 123, 0, 0));
    }

    @Test
    void testByteArrayToInt_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteArrayToInt(new byte[4], 0, 0, 8, 4));
    }

    @Test
    void testByteArrayToInt_roundTripWithIntToByteArray() {
        final int[] values = { 0, 1, -1, Integer.MAX_VALUE, Integer.MIN_VALUE, 0x12345678 };
        for (final int original : values) {
            final byte[] bytes = Conversion.intToByteArray(original, 0, new byte[4], 0, 4);
            final int roundTripped = Conversion.byteArrayToInt(bytes, 0, 0, 0, 4);
            assertEquals(original, roundTripped, "roundtrip failed for " + original);
        }
    }

    @Test
    void testByteArrayToLong_littleEndian() {
        final byte[] src = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 };
        assertEquals(0x0807060504030201L, Conversion.byteArrayToLong(src, 0, 0L, 0, 8));
    }

    @Test
    void testByteArrayToLong_roundTripWithLongToByteArray() {
        final long[] values = { 0L, 1L, -1L, Long.MAX_VALUE, Long.MIN_VALUE, 0x123456789ABCDEFL };
        for (final long original : values) {
            final byte[] bytes = Conversion.longToByteArray(original, 0, new byte[8], 0, 8);
            final long roundTripped = Conversion.byteArrayToLong(bytes, 0, 0L, 0, 8);
            assertEquals(original, roundTripped, "roundtrip failed for " + original);
        }
    }

    @Test
    void testByteArrayToShort_littleEndian() {
        final byte[] src = { 0x01, 0x02 };
        assertEquals((short) 0x0201, Conversion.byteArrayToShort(src, 0, (short) 0, 0, 2));
    }

    @Test
    void testByteArrayToShort_roundTripWithShortToByteArray() {
        final short[] values = { 0, 1, -1, Short.MAX_VALUE, Short.MIN_VALUE, (short) 0x1234 };
        for (final short original : values) {
            final byte[] bytes = Conversion.shortToByteArray(original, 0, new byte[2], 0, 2);
            final short roundTripped = Conversion.byteArrayToShort(bytes, 0, (short) 0, 0, 2);
            assertEquals(original, roundTripped, "roundtrip failed for " + original);
        }
    }

    // ---------------------------------------------------------------
    // byteArrayToUuid / uuidToByteArray
    // ---------------------------------------------------------------

    @Test
    void testByteArrayToUuid_tooShortThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteArrayToUuid(new byte[15], 0));
    }

    @Test
    void testByteArrayToUuid_normal() {
        final byte[] src = new byte[16];
        for (int i = 0; i < 16; i++) {
            src[i] = (byte) (i + 1);
        }
        final UUID uuid = Conversion.byteArrayToUuid(src, 0);
        assertEquals(Conversion.byteArrayToLong(src, 0, 0L, 0, 8), uuid.getMostSignificantBits());
        assertEquals(Conversion.byteArrayToLong(src, 8, 0L, 0, 8), uuid.getLeastSignificantBits());
    }

    @Test
    void testUuidToByteArray_roundTripWithByteArrayToUuid() {
        final UUID original = UUID.fromString("01234567-89ab-cdef-0123-456789abcdef");
        final byte[] dst = Conversion.uuidToByteArray(original, new byte[16], 0, 16);
        final UUID roundTripped = Conversion.byteArrayToUuid(dst, 0);
        assertEquals(original, roundTripped);
    }

    @Test
    void testUuidToByteArray_zeroNBytesReturnsDstUnchanged() {
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.uuidToByteArray(UUID.randomUUID(), dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new byte[4], result);
    }

    @Test
    void testUuidToByteArray_tooManyBytesThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.uuidToByteArray(UUID.randomUUID(), new byte[17], 0, 17));
    }

    // ---------------------------------------------------------------
    // byteToBinary / byteToHex
    // ---------------------------------------------------------------

    @Test
    void testByteToBinary_zeroNBoolsReturnsDstUnchanged() {
        final boolean[] dst = new boolean[8];
        final boolean[] result = Conversion.byteToBinary((byte) 0xFF, 0, dst, 0, 0);
        assertSame(dst, result);
        for (final boolean b : result) {
            assertEquals(false, b);
        }
    }

    @Test
    void testByteToBinary_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteToBinary((byte) 1, 1, new boolean[8], 0, 8));
    }

    @Test
    void testByteToHex_normal() {
        // 0xAB = 1010 1011, LSB0 nibble order: low nibble 'b' first, then high nibble 'a'
        assertEquals("ba", Conversion.byteToHex((byte) 0xAB, 0, "", 0, 2));
    }

    @Test
    void testByteToHex_zeroNHexsReturnsDstInit() {
        assertEquals("xyz", Conversion.byteToHex((byte) 0xAB, 0, "xyz", 0, 0));
    }

    @Test
    void testByteToHex_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.byteToHex((byte) 1, 4, "", 0, 2));
    }

    @Test
    void testByteToHex_roundTripWithHexToByte() {
        for (int v = -128; v <= 127; v += 5) {
            final byte original = (byte) v;
            final String hex = Conversion.byteToHex(original, 0, "", 0, 2);
            final byte roundTripped = Conversion.hexToByte(hex, 0, (byte) 0, 0, 2);
            assertEquals(original, roundTripped, "roundtrip failed for " + v);
        }
    }

    // ---------------------------------------------------------------
    // hexDigitMsb0ToBinary / hexDigitMsb0ToInt
    // ---------------------------------------------------------------

    @Test
    void testHexDigitMsb0ToBinary_docExample() {
        // '1' is converted to (0, 0, 0, 1)
        assertArrayEquals(new boolean[] { false, false, false, true }, Conversion.hexDigitMsb0ToBinary('1'));
    }

    @Test
    void testHexDigitMsb0ToBinary_allDigitsAreMsbFirstBinary() {
        final String hexDigits = "0123456789abcdef";
        for (int i = 0; i < 16; i++) {
            final boolean[] bits = Conversion.hexDigitMsb0ToBinary(hexDigits.charAt(i));
            int value = 0;
            for (int b = 0; b < 4; b++) {
                value = value << 1 | (bits[b] ? 1 : 0);
            }
            assertEquals(i, value, "mismatch for hex digit " + hexDigits.charAt(i));
        }
        // uppercase variants
        final String hexDigitsUpper = "ABCDEF";
        for (int i = 0; i < hexDigitsUpper.length(); i++) {
            final boolean[] lower = Conversion.hexDigitMsb0ToBinary(Character.toLowerCase(hexDigitsUpper.charAt(i)));
            final boolean[] upper = Conversion.hexDigitMsb0ToBinary(hexDigitsUpper.charAt(i));
            assertArrayEquals(lower, upper);
        }
    }

    @Test
    void testHexDigitMsb0ToBinary_invalidCharThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitMsb0ToBinary('g'));
    }

    @Test
    void testHexDigitMsb0ToInt_docExample() {
        // '1' is converted to 8
        assertEquals(0x8, Conversion.hexDigitMsb0ToInt('1'));
    }

    @Test
    void testHexDigitMsb0ToInt_isNibbleBitReversalOfValue() {
        final String hexDigits = "0123456789abcdef";
        for (int i = 0; i < 16; i++) {
            int reversed = 0;
            for (int b = 0; b < 4; b++) {
                reversed |= (i >> b & 1) << 3 - b;
            }
            assertEquals(reversed, Conversion.hexDigitMsb0ToInt(hexDigits.charAt(i)), "mismatch for hex digit " + hexDigits.charAt(i));
        }
    }

    @Test
    void testHexDigitMsb0ToInt_invalidCharThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitMsb0ToInt('z'));
    }

    @Test
    void testHexDigitMsb0ToInt_inverseOfIntToHexDigitMsb0() {
        for (int nibble = 0; nibble < 16; nibble++) {
            final char hexChar = Conversion.intToHexDigitMsb0(nibble);
            assertEquals(nibble, Conversion.hexDigitMsb0ToInt(hexChar), "mismatch for nibble " + nibble);
        }
    }

    // ---------------------------------------------------------------
    // hexDigitToBinary / hexDigitToInt
    // ---------------------------------------------------------------

    @Test
    void testHexDigitToBinary_docExample() {
        // '1' is converted to (1, 0, 0, 0)
        assertArrayEquals(new boolean[] { true, false, false, false }, Conversion.hexDigitToBinary('1'));
    }

    @Test
    void testHexDigitToBinary_allDigitsAreLsbFirstBinary() {
        final String hexDigits = "0123456789abcdef";
        for (int i = 0; i < 16; i++) {
            final boolean[] bits = Conversion.hexDigitToBinary(hexDigits.charAt(i));
            int value = 0;
            for (int b = 0; b < 4; b++) {
                value |= (bits[b] ? 1 : 0) << b;
            }
            assertEquals(i, value, "mismatch for hex digit " + hexDigits.charAt(i));
        }
    }

    @Test
    void testHexDigitToBinary_invalidCharThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitToBinary('x'));
    }

    @Test
    void testHexDigitToInt_docExample() {
        // '1' is converted to 1
        assertEquals(1, Conversion.hexDigitToInt('1'));
    }

    @Test
    void testHexDigitToInt_allValidDigits() {
        final String hexDigits = "0123456789abcdefABCDEF";
        for (int i = 0; i < hexDigits.length(); i++) {
            final char c = hexDigits.charAt(i);
            assertEquals(Character.digit(c, 16), Conversion.hexDigitToInt(c), "mismatch for " + c);
        }
    }

    @Test
    void testHexDigitToInt_invalidCharThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitToInt('g'));
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexDigitToInt(' '));
    }

    // ---------------------------------------------------------------
    // hexToByte / hexToInt / hexToLong / hexToShort
    // ---------------------------------------------------------------

    @Test
    void testHexToByte_zeroNHexReturnsDstInit() {
        assertEquals((byte) 7, Conversion.hexToByte("ff", 0, (byte) 7, 0, 0));
    }

    @Test
    void testHexToByte_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToByte("ff", 0, (byte) 0, 4, 2));
    }

    @Test
    void testHexToByte_roundTripWithByteToHex() {
        for (int v = -128; v <= 127; v += 5) {
            final byte original = (byte) v;
            final String hex = Conversion.byteToHex(original, 0, "", 0, 2);
            assertEquals(original, Conversion.hexToByte(hex, 0, (byte) 0, 0, 2), "roundtrip failed for " + v);
        }
    }

    @Test
    void testHexToInt_fixedValueLsb0NibbleOrder() {
        assertEquals(0x1234, Conversion.hexToInt("4321", 0, 0, 0, 4));
    }

    @Test
    void testHexToInt_zeroNHexReturnsDstInit() {
        assertEquals(42, Conversion.hexToInt("ff", 0, 42, 0, 0));
    }

    @Test
    void testHexToInt_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToInt("ffffffff", 0, 0, 5, 8));
    }

    @Test
    void testHexToInt_roundTripWithIntToHex() {
        final int[] values = { 0, 1, -1, Integer.MAX_VALUE, Integer.MIN_VALUE, 0x12345678 };
        for (final int original : values) {
            final String hex = Conversion.intToHex(original, 0, "", 0, 8);
            assertEquals(original, Conversion.hexToInt(hex, 0, 0, 0, 8), "roundtrip failed for " + original);
        }
    }

    @Test
    void testHexToLong_roundTripWithLongToHex() {
        final long[] values = { 0L, 1L, -1L, Long.MAX_VALUE, Long.MIN_VALUE, 0x123456789ABCDEFL };
        for (final long original : values) {
            final String hex = Conversion.longToHex(original, 0, "", 0, 16);
            assertEquals(original, Conversion.hexToLong(hex, 0, 0L, 0, 16), "roundtrip failed for " + original);
        }
    }

    @Test
    void testHexToLong_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToLong("f", 0, 0L, 4, 16));
    }

    @Test
    void testHexToShort_roundTripWithShortToHex() {
        final short[] values = { 0, 1, -1, Short.MAX_VALUE, Short.MIN_VALUE, (short) 0x1234 };
        for (final short original : values) {
            final String hex = Conversion.shortToHex(original, 0, "", 0, 4);
            assertEquals(original, Conversion.hexToShort(hex, 0, (short) 0, 0, 4), "roundtrip failed for " + original);
        }
    }

    @Test
    void testHexToShort_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.hexToShort("f", 0, (short) 0, 4, 4));
    }

    // ---------------------------------------------------------------
    // intArrayToLong / longToIntArray
    // ---------------------------------------------------------------

    @Test
    void testIntArrayToLong_littleEndian() {
        final int[] src = { 0x11223344, 0x55667788 };
        assertEquals(0x5566778811223344L, Conversion.intArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    void testIntArrayToLong_zeroNIntsReturnsDstInit() {
        assertEquals(5L, Conversion.intArrayToLong(new int[0], 0, 5L, 0, 0));
    }

    @Test
    void testIntArrayToLong_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intArrayToLong(new int[2], 0, 0L, 32, 2));
    }

    @Test
    void testIntArrayToLong_roundTripWithLongToIntArray() {
        final long[] values = { 0L, 1L, -1L, Long.MAX_VALUE, Long.MIN_VALUE, 0x123456789ABCDEFL };
        for (final long original : values) {
            final int[] ints = Conversion.longToIntArray(original, 0, new int[2], 0, 2);
            assertEquals(original, Conversion.intArrayToLong(ints, 0, 0L, 0, 2), "roundtrip failed for " + original);
        }
    }

    // ---------------------------------------------------------------
    // intToBinary / intToByteArray / intToHex / intToHexDigit / intToHexDigitMsb0 / intToShortArray
    // ---------------------------------------------------------------

    @Test
    void testIntToBinary_zeroNBoolsReturnsDstUnchanged() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.intToBinary(0xF, 0, dst, 0, 0);
        assertSame(dst, result);
        for (final boolean b : result) {
            assertEquals(false, b);
        }
    }

    @Test
    void testIntToBinary_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToBinary(1, 1, new boolean[32], 0, 32));
    }

    @Test
    void testIntToByteArray_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToByteArray(1, 8, new byte[4], 0, 4));
    }

    @Test
    void testIntToByteArray_zeroNBytesReturnsDstUnchanged() {
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.intToByteArray(0xFF, 0, dst, 0, 0);
        assertSame(dst, result);
        assertArrayEquals(new byte[4], result);
    }

    @Test
    void testIntToHex_fixedValueLsb0NibbleOrder() {
        // LSB0: least-significant nibble is written first
        assertEquals("4321", Conversion.intToHex(0x1234, 0, "", 0, 4));
    }

    @Test
    void testIntToHex_zeroNHexsReturnsDstInit() {
        assertEquals("abc", Conversion.intToHex(0xFF, 0, "abc", 0, 0));
    }

    @Test
    void testIntToHex_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHex(1, 5, "", 0, 8));
    }

    @Test
    void testIntToHexDigit_allValidNibbles() {
        for (int n = 0; n < 16; n++) {
            assertEquals(Character.forDigit(n, 16), Conversion.intToHexDigit(n), "mismatch for nibble " + n);
        }
    }

    @Test
    void testIntToHexDigit_negativeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigit(-1));
    }

    @Test
    void testIntToHexDigit_tooLargeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigit(16));
    }

    @Test
    void testIntToHexDigitMsb0_docExamples() {
        // 0 returns '0', 1 returns '8', 10 returns '5'
        assertEquals('0', Conversion.intToHexDigitMsb0(0));
        assertEquals('8', Conversion.intToHexDigitMsb0(1));
        assertEquals('5', Conversion.intToHexDigitMsb0(10));
    }

    @Test
    void testIntToHexDigitMsb0_negativeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigitMsb0(-1));
    }

    @Test
    void testIntToHexDigitMsb0_tooLargeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToHexDigitMsb0(16));
    }

    @Test
    void testIntToShortArray_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.intToShortArray(1, 17, new short[2], 0, 2));
    }

    @Test
    void testIntToShortArray_roundTripWithShortArrayToInt() {
        final int[] values = { 0, 1, -1, Integer.MAX_VALUE, Integer.MIN_VALUE, 0x12345678 };
        for (final int original : values) {
            final short[] shorts = Conversion.intToShortArray(original, 0, new short[2], 0, 2);
            assertEquals(original, Conversion.shortArrayToInt(shorts, 0, 0, 0, 2), "roundtrip failed for " + original);
        }
    }

    // ---------------------------------------------------------------
    // longToBinary / longToByteArray / longToHex / longToIntArray / longToShortArray
    // ---------------------------------------------------------------

    @Test
    void testLongToBinary_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToBinary(1L, 1, new boolean[64], 0, 64));
    }

    @Test
    void testLongToByteArray_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToByteArray(1L, 8, new byte[8], 0, 8));
    }

    @Test
    void testLongToHex_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToHex(1L, 4, "", 0, 16));
    }

    @Test
    void testLongToIntArray_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToIntArray(1L, 33, new int[2], 0, 2));
    }

    @Test
    void testLongToShortArray_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.longToShortArray(1L, 17, new short[4], 0, 4));
    }

    @Test
    void testLongToShortArray_roundTripWithShortArrayToLong() {
        final long[] values = { 0L, 1L, -1L, Long.MAX_VALUE, Long.MIN_VALUE, 0x123456789ABCDEFL };
        for (final long original : values) {
            final short[] shorts = Conversion.longToShortArray(original, 0, new short[4], 0, 4);
            assertEquals(original, Conversion.shortArrayToLong(shorts, 0, 0L, 0, 4), "roundtrip failed for " + original);
        }
    }

    // ---------------------------------------------------------------
    // shortArrayToInt / shortArrayToLong
    // ---------------------------------------------------------------

    @Test
    void testShortArrayToInt_littleEndian() {
        final short[] src = { 0x1234, 0x5678 };
        assertEquals(0x56781234, Conversion.shortArrayToInt(src, 0, 0, 0, 2));
    }

    @Test
    void testShortArrayToInt_zeroNShortsReturnsDstInit() {
        assertEquals(11, Conversion.shortArrayToInt(new short[0], 0, 11, 0, 0));
    }

    @Test
    void testShortArrayToInt_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortArrayToInt(new short[2], 0, 0, 17, 2));
    }

    @Test
    void testShortArrayToLong_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortArrayToLong(new short[4], 0, 0L, 17, 4));
    }

    // ---------------------------------------------------------------
    // shortToBinary / shortToByteArray / shortToHex
    // ---------------------------------------------------------------

    @Test
    void testShortToBinary_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortToBinary((short) 1, 1, new boolean[16], 0, 16));
    }

    @Test
    void testShortToByteArray_littleEndian() {
        final byte[] dst = Conversion.shortToByteArray((short) 0x0201, 0, new byte[2], 0, 2);
        assertArrayEquals(new byte[] { 0x01, 0x02 }, dst);
    }

    @Test
    void testShortToByteArray_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortToByteArray((short) 1, 9, new byte[2], 0, 2));
    }

    @Test
    void testShortToHex_outOfRangeThrowsIAE() {
        assertThrows(IllegalArgumentException.class, () -> Conversion.shortToHex((short) 1, 4, "", 0, 4));
    }

    @Test
    void testShortToHex_zeroNHexsReturnsDstInit() {
        assertEquals("zzz", Conversion.shortToHex((short) 1, 0, "zzz", 0, 0));
    }

    // ---------------------------------------------------------------
    // Constructor (deprecated, but public)
    // ---------------------------------------------------------------

    @Test
    void testConstructor() {
        assertNotNull(new Conversion());
    }
}
