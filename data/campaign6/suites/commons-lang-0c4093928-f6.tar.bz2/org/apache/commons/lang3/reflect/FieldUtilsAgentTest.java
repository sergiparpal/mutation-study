/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FieldUtils}.
 */
public class FieldUtilsAgentTest {

    @Test
    public void testGetAllFieldsNullThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getAllFields(null));
    }

    @Test
    public void testGetAllFieldsListNullThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getAllFieldsList(null));
    }

    @Test
    public void testGetAllFieldsIncludesOwnAndSuperclassFields() {
        final List<Field> fields = FieldUtils.getAllFieldsList(AgentAccessSub.class);
        final List<String> names = fieldNames(fields);
        assertTrue(names.contains("subField"), "expected subField in " + names);
        assertTrue(names.contains("publicField"), "expected publicField in " + names);
        assertTrue(names.contains("privateField"), "expected privateField in " + names);

        final Field[] array = FieldUtils.getAllFields(AgentAccessSub.class);
        assertEquals(fields.size(), array.length);
    }

    @Test
    public void testGetAllFieldsOfObjectIsEmpty() {
        assertEquals(0, FieldUtils.getAllFields(Object.class).length);
    }

    @Test
    public void testGetDeclaredFieldNullClassThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getDeclaredField(null, "publicField"));
    }

    @Test
    public void testGetDeclaredFieldBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getDeclaredField(AgentAccessBase.class, " "));
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getDeclaredField(AgentAccessBase.class, ""));
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getDeclaredField(AgentAccessBase.class, null));
    }

    @Test
    public void testGetDeclaredFieldUnknownNameReturnsNull() {
        assertNull(FieldUtils.getDeclaredField(AgentAccessBase.class, "doesNotExist"));
    }

    @Test
    public void testGetDeclaredFieldPublicFound() {
        final Field field = FieldUtils.getDeclaredField(AgentAccessBase.class, "publicField");
        assertNotNull(field);
        assertEquals("publicField", field.getName());
    }

    @Test
    public void testGetDeclaredFieldPrivateWithoutForceAccessReturnsNull() {
        assertNull(FieldUtils.getDeclaredField(AgentAccessBase.class, "privateField", false));
    }

    @Test
    public void testGetDeclaredFieldPrivateWithForceAccessIsAccessible() {
        final Field field = FieldUtils.getDeclaredField(AgentAccessBase.class, "privateField", true);
        assertNotNull(field);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetDeclaredFieldOnlyLooksAtSpecifiedClass() {
        // publicField is declared on the base class, not the subclass, so it must not be found
        // by getDeclaredField() when queried on the subclass.
        assertNull(FieldUtils.getDeclaredField(AgentAccessSub.class, "publicField"));
    }

    @Test
    public void testGetFieldNullClassThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getField(null, "publicField"));
    }

    @Test
    public void testGetFieldBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getField(AgentAccessBase.class, ""));
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getField(AgentAccessBase.class, null));
    }

    @Test
    public void testGetFieldFindsInheritedPublicField() {
        final Field field = FieldUtils.getField(AgentAccessSub.class, "publicField");
        assertNotNull(field);
        assertEquals(AgentAccessBase.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldDoesNotMatchNonPublicWithoutForceAccess() {
        assertNull(FieldUtils.getField(AgentAccessSub.class, "protectedField", false));
        assertNull(FieldUtils.getField(AgentAccessSub.class, "packageField", false));
        assertNull(FieldUtils.getField(AgentAccessSub.class, "privateField", false));
    }

    @Test
    public void testGetFieldWithForceAccessFindsNonPublicAndMakesItAccessible() {
        final Field field = FieldUtils.getField(AgentAccessSub.class, "protectedField", true);
        assertNotNull(field);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetFieldFindsFieldDeclaredOnlyInInterface() {
        final Field field = FieldUtils.getField(AgentInterfaceImpl.class, "ONLY_A");
        assertNotNull(field);
        assertEquals(AgentInterfaceA.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldFindsInterfaceFieldInheritedThroughSuperclass() {
        // AgentAccessSub extends AgentAccessBase, which implements AgentInterfaceA.
        final Field field = FieldUtils.getField(AgentAccessSub.class, "ONLY_A");
        assertNotNull(field);
        assertEquals(AgentInterfaceA.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldAmbiguousInterfaceFieldThrows() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getField(AgentAmbiguous.class, "SHARED"));
    }

    @Test
    public void testGetFieldsWithAnnotationNullAnnotationThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getFieldsWithAnnotation(AgentAccessBase.class, null));
    }

    @Test
    public void testGetFieldsListWithAnnotationFindsAnnotatedField() {
        final List<Field> fields = FieldUtils.getFieldsListWithAnnotation(AgentAccessBase.class, AgentMarker.class);
        assertEquals(1, fields.size());
        assertEquals("annotatedField", fields.get(0).getName());
    }

    @Test
    public void testGetFieldsWithAnnotationNoMatchesIsEmptyArray() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(AgentAccessBase.class, Deprecated.class);
        assertEquals(0, fields.length);
    }

    @Test
    public void testGetFieldsWithAnnotationIncludesInheritedAnnotatedFields() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(AgentAccessSub.class, AgentMarker.class);
        assertEquals(1, fields.length);
        assertEquals(AgentAccessBase.class, fields[0].getDeclaringClass());
    }

    @Test
    public void testReadDeclaredFieldNullTargetThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readDeclaredField(null, "publicField"));
    }

    @Test
    public void testReadDeclaredFieldPublicReturnsValue() throws IllegalAccessException {
        final AgentAccessBase target = new AgentAccessBase();
        assertEquals("public-value", FieldUtils.readDeclaredField(target, "publicField"));
    }

    @Test
    public void testReadDeclaredFieldUnreachableNameThrows() {
        final AgentAccessBase target = new AgentAccessBase();
        // Without forceAccess, a private field cannot be located as a "declared, accessible" field.
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readDeclaredField(target, "privateField", false));
    }

    @Test
    public void testReadDeclaredFieldWithForceAccessReadsPrivateField() throws IllegalAccessException {
        final AgentAccessBase target = new AgentAccessBase();
        assertEquals("private-value", FieldUtils.readDeclaredField(target, "privateField", true));
    }

    @Test
    public void testReadDeclaredFieldOnlyConsidersActualClass() {
        // publicField is declared on AgentAccessBase, not AgentAccessSub, so looking it up as a
        // "declared" field of a AgentAccessSub instance must fail.
        final AgentAccessSub target = new AgentAccessSub();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readDeclaredField(target, "publicField"));
    }

    @Test
    public void testReadDeclaredStaticFieldReadsValue() throws IllegalAccessException {
        assertEquals("public-static-value", FieldUtils.readDeclaredStaticField(AgentAccessBase.class, "publicStaticField"));
    }

    @Test
    public void testReadDeclaredStaticFieldWithForceAccessReadsPrivateStatic() throws IllegalAccessException {
        assertEquals("private-static-value", FieldUtils.readDeclaredStaticField(AgentAccessBase.class, "privateStaticField", true));
    }

    @Test
    public void testReadFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readField((Field) null, new AgentAccessBase()));
    }

    @Test
    public void testReadFieldByFieldObjectReturnsValue() throws Exception {
        final AgentAccessBase target = new AgentAccessBase();
        final Field field = AgentAccessBase.class.getDeclaredField("publicField");
        assertEquals("public-value", FieldUtils.readField(field, target));
    }

    @Test
    public void testReadFieldInaccessibleWithoutForceAccessThrows() throws Exception {
        final AgentAccessBase target = new AgentAccessBase();
        final Field field = AgentAccessBase.class.getDeclaredField("privateField");
        assertThrows(IllegalAccessException.class, () -> FieldUtils.readField(field, target, false));
    }

    @Test
    public void testReadFieldInaccessibleWithForceAccessReturnsValue() throws Exception {
        final AgentAccessBase target = new AgentAccessBase();
        final Field field = AgentAccessBase.class.getDeclaredField("privateField");
        assertEquals("private-value", FieldUtils.readField(field, target, true));
    }

    @Test
    public void testReadFieldByNameNullTargetThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readField((Object) null, "publicField"));
    }

    @Test
    public void testReadFieldByNameOnSubclassFindsInheritedField() throws IllegalAccessException {
        final AgentAccessSub target = new AgentAccessSub();
        assertEquals("public-value", FieldUtils.readField(target, "publicField"));
    }

    @Test
    public void testReadFieldByNameNotFoundThrows() {
        final AgentAccessBase target = new AgentAccessBase();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readField(target, "doesNotExist"));
    }

    @Test
    public void testReadStaticFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readStaticField((Field) null));
    }

    @Test
    public void testReadStaticFieldByNameReturnsValue() throws IllegalAccessException {
        assertEquals("public-static-value", FieldUtils.readStaticField(AgentAccessBase.class, "publicStaticField"));
    }

    @Test
    public void testReadStaticFieldOnNonStaticFieldThrows() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readStaticField(AgentAccessBase.class, "publicField"));
    }

    @Test
    public void testReadStaticFieldByFieldObjectOnNonStaticThrows() throws Exception {
        final Field field = AgentAccessBase.class.getDeclaredField("publicField");
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readStaticField(field));
    }

    @Test
    public void testRemoveFinalModifierClearsFinalBit() throws Exception {
        final Field field = AgentFinalFixture.class.getDeclaredField("publicFinalField");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @Test
    public void testRemoveFinalModifierNullThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.removeFinalModifier(null));
    }

    @Test
    public void testWriteFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.writeField(null, new AgentAccessBase(), "x"));
    }

    @Test
    public void testWriteFieldPublicInstanceFieldChangesValue() throws Exception {
        final AgentAccessBase target = new AgentAccessBase();
        final Field field = AgentAccessBase.class.getDeclaredField("publicField");
        FieldUtils.writeField(field, target, "new-value");
        assertEquals("new-value", target.publicField);
    }

    @Test
    public void testWriteFieldInaccessibleWithoutForceAccessThrows() throws Exception {
        final AgentAccessBase target = new AgentAccessBase();
        final Field field = AgentAccessBase.class.getDeclaredField("privateField");
        assertThrows(IllegalAccessException.class, () -> FieldUtils.writeField(field, target, "new-value", false));
    }

    @Test
    public void testWriteFieldFinalInstanceFieldWithForceAccessSucceeds() throws Exception {
        final AgentFinalFixture target = new AgentFinalFixture();
        final Field field = AgentFinalFixture.class.getDeclaredField("publicFinalField");
        FieldUtils.writeField(field, target, "changed", true);
        assertEquals("changed", FieldUtils.readField(field, target, true));
    }

    @Test
    public void testWriteFieldStaticFinalFieldWithForceAccessStillThrows() throws Exception {
        final Field field = AgentFinalFixture.class.getDeclaredField("STATIC_FINAL_FIELD");
        assertThrows(IllegalAccessException.class, () -> FieldUtils.writeField(field, (Object) null, "changed", true));
    }

    @Test
    public void testWriteFieldByNameNotAssignableValueThrows() {
        final AgentAccessBase target = new AgentAccessBase();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeField(target, "publicField", Integer.valueOf(1)));
    }

    @Test
    public void testWriteFieldByNameUpdatesAndIsObservableViaReadField() throws IllegalAccessException {
        final AgentAccessSub target = new AgentAccessSub();
        FieldUtils.writeField(target, "publicField", "via-name");
        assertEquals("via-name", FieldUtils.readField(target, "publicField"));
    }

    @Test
    public void testWriteStaticFieldByNameUpdatesValue() throws IllegalAccessException {
        FieldUtils.writeStaticField(AgentAccessBase.class, "publicStaticField", "updated-static");
        try {
            assertEquals("updated-static", FieldUtils.readStaticField(AgentAccessBase.class, "publicStaticField"));
        } finally {
            FieldUtils.writeStaticField(AgentAccessBase.class, "publicStaticField", "public-static-value");
        }
    }

    @Test
    public void testWriteStaticFieldOnNonStaticFieldThrows() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeStaticField(AgentAccessBase.class, "publicField", "x"));
    }

    @Test
    public void testWriteDeclaredFieldOnlyConsidersActualClass() {
        final AgentAccessSub target = new AgentAccessSub();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeDeclaredField(target, "publicField", "x"));
    }

    @Test
    public void testWriteDeclaredStaticFieldUpdatesValue() throws IllegalAccessException {
        FieldUtils.writeDeclaredStaticField(AgentAccessBase.class, "publicStaticField", "declared-static");
        try {
            assertEquals("declared-static", FieldUtils.readDeclaredStaticField(AgentAccessBase.class, "publicStaticField"));
        } finally {
            FieldUtils.writeDeclaredStaticField(AgentAccessBase.class, "publicStaticField", "public-static-value");
        }
    }

    @Test
    public void testWriteFieldByNameNullTargetThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.writeField((Object) null, "publicField", "x"));
    }

    @Test
    public void testWriteStaticFieldNullClassThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.writeStaticField(null, "publicStaticField", "x"));
    }

    @Test
    public void testGetFieldsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getFieldsListWithAnnotation(null, AgentMarker.class));
    }

    @Test
    public void testFieldUtilsConstructorIsPublicForBeanTools() {
        final FieldUtils instance = new FieldUtils();
        assertNotNull(instance);
    }

    private static List<String> fieldNames(final List<Field> fields) {
        final List<String> names = new java.util.ArrayList<>();
        for (final Field f : fields) {
            names.add(f.getName());
        }
        return names;
    }
}

interface AgentInterfaceA {
    String ONLY_A = "onlyA";
    String SHARED = "fromA";
}

interface AgentInterfaceB {
    String SHARED = "fromB";
}

class AgentAccessBase implements AgentInterfaceA {

    public static String publicStaticField = "public-static-value";
    private static String privateStaticField = "private-static-value";

    @AgentMarker
    public String annotatedField = "annotated-value";
    public String publicField = "public-value";
    protected String protectedField = "protected-value";
    String packageField = "package-value";
    private String privateField = "private-value";
}

class AgentAccessSub extends AgentAccessBase {
    public String subField = "sub-value";
}

class AgentInterfaceImpl implements AgentInterfaceA {
}

class AgentAmbiguous implements AgentInterfaceA, AgentInterfaceB {
}

class AgentFinalFixture {
    public static final String STATIC_FINAL_FIELD = "static-final-value";
    public final String publicFinalField = "public-final-value";
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface AgentMarker {
}
