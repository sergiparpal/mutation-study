/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
public class TypeUtilsAgentTest {

    private static class Box<T> {
        @SuppressWarnings("unused")
        private T value;
    }

    private static class ArrayBox<T> {
        @SuppressWarnings("unused")
        private T[] values;
    }

    private static class Unbounded<T> {
        // no explicit bound
    }

    private static class Bounded<T extends Number> {
        // bounded by Number
    }

    private static class Pair<T, S extends T> {
        // S depends on T
    }

    private static class StringList extends ArrayList<String> {
        private static final long serialVersionUID = 1L;
    }

    private static Executable toExecutable(final Runnable runnable) {
        return new Executable() {
            @Override
            public void execute() {
                runnable.run();
            }
        };
    }

    // containsTypeVariables

    @Test
    public void testContainsTypeVariablesFalseForConcreteClass() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
    }

    @Test
    public void testContainsTypeVariablesTrueForTypeVariable() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(tv));
    }

    @Test
    public void testContainsTypeVariablesInParameterizedType() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final ParameterizedType withVariable = TypeUtils.parameterize(List.class, tv);
        assertTrue(TypeUtils.containsTypeVariables(withVariable));
        final ParameterizedType withoutVariable = TypeUtils.parameterize(List.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(withoutVariable));
    }

    // determineTypeArguments

    @Test
    public void testDetermineTypeArguments() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(ArrayList.class, superType);
        assertEquals(String.class, result.get(ArrayList.class.getTypeParameters()[0]));
    }

    @Test
    public void testDetermineTypeArgumentsNotAssignableReturnsNull() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        assertNull(TypeUtils.determineTypeArguments(String.class, superType));
    }

    @Test
    public void testDetermineTypeArgumentsNullArguments() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.determineTypeArguments(null, superType);
            }
        }));
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.determineTypeArguments(ArrayList.class, null);
            }
        }));
    }

    // equals

    @Test
    public void testEqualsSameClass() {
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
    }

    @Test
    public void testEqualsParameterizedTypesByValue() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, String.class);
        assertNotSame(a, b);
        assertTrue(TypeUtils.equals(a, b));
        final ParameterizedType c = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.equals(a, c));
    }

    // genericArrayType / getArrayComponentType / isArrayType

    @Test
    public void testGenericArrayType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
        assertEquals("java.lang.String[]", TypeUtils.toString(gat));
        assertTrue(TypeUtils.isArrayType(gat));
    }

    @Test
    public void testGenericArrayTypeNullComponentThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.genericArrayType(null);
            }
        }));
    }

    @Test
    public void testGetArrayComponentType() {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(gat));
    }

    @Test
    public void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertFalse(TypeUtils.isArrayType(TypeUtils.parameterize(List.class, String.class)));
    }

    // getImplicitBounds / getImplicitLowerBounds / getImplicitUpperBounds

    @Test
    public void testGetImplicitBoundsUnbounded() {
        final TypeVariable<?> tv = Unbounded.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitBounds(tv));
    }

    @Test
    public void testGetImplicitBoundsBounded() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] {Number.class}, TypeUtils.getImplicitBounds(tv));
    }

    @Test
    public void testGetImplicitBoundsNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.getImplicitBounds(null);
            }
        }));
    }

    @Test
    public void testGetImplicitLowerBoundsNoneMeansNull() {
        final WildcardType wildcard = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[] {null}, TypeUtils.getImplicitLowerBounds(wildcard));
    }

    @Test
    public void testGetImplicitLowerBoundsNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        }));
    }

    @Test
    public void testGetImplicitUpperBoundsNoneMeansObject() {
        final WildcardType wildcard = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitUpperBounds(wildcard));
    }

    @Test
    public void testGetImplicitUpperBoundsNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        }));
    }

    // getRawType(Type, Type)

    @Test
    public void testGetRawTypeFromClass() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    public void testGetRawTypeFromTypeVariable() throws Exception {
        final Field field = Box.class.getDeclaredField("value");
        final Type fieldType = field.getGenericType();
        final ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(fieldType, boxOfString));
    }

    @Test
    public void testGetRawTypeFromTypeVariableWithoutAssigningTypeIsNull() throws Exception {
        final Field field = Box.class.getDeclaredField("value");
        final Type fieldType = field.getGenericType();
        assertNull(TypeUtils.getRawType(fieldType, null));
    }

    @Test
    public void testGetRawTypeFromGenericArrayType() throws Exception {
        final Field field = ArrayBox.class.getDeclaredField("values");
        final Type fieldType = field.getGenericType();
        final ParameterizedType boxOfInteger = TypeUtils.parameterize(ArrayBox.class, Integer.class);
        final Class<?> raw = TypeUtils.getRawType(fieldType, boxOfInteger);
        assertEquals(Integer[].class, raw);
    }

    @Test
    public void testGetRawTypeFromWildcardIsNull() {
        final WildcardType wildcard = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertNull(TypeUtils.getRawType(wildcard, null));
    }

    @Test
    public void testGetRawTypeFromUnknownTypeThrows() {
        final Type bogus = new Type() {
            @Override
            public String toString() {
                return "bogus";
            }
        };
        assertThrows(IllegalArgumentException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.getRawType(bogus, null);
            }
        }));
    }

    // getTypeArguments

    @Test
    public void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(Map.class, String.class, Integer.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(pt);
        final TypeVariable<?>[] mapParams = Map.class.getTypeParameters();
        assertEquals(String.class, args.get(mapParams[0]));
        assertEquals(Integer.class, args.get(mapParams[1]));
    }

    @Test
    public void testGetTypeArgumentsBySubtype() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringList.class, List.class);
        assertEquals(String.class, args.get(List.class.getTypeParameters()[0]));
    }

    @Test
    public void testGetTypeArgumentsNotAssignableReturnsNull() {
        assertNull(TypeUtils.getTypeArguments(String.class, List.class));
    }

    // isAssignable

    @Test
    public void testIsAssignableBasicClasses() {
        assertTrue(TypeUtils.isAssignable(String.class, Object.class));
        assertFalse(TypeUtils.isAssignable(Object.class, String.class));
        assertTrue(TypeUtils.isAssignable(ArrayList.class, List.class));
    }

    @Test
    public void testIsAssignableParameterizedTypes() {
        final ParameterizedType listOfString1 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfString2 = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isAssignable(listOfString1, listOfString2));
        final ParameterizedType arrayListOfString = TypeUtils.parameterize(ArrayList.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.isAssignable(arrayListOfString, listOfInteger));
    }

    @Test
    public void testIsAssignableNullHandling() {
        assertTrue(TypeUtils.isAssignable(null, (Type) null));
        assertTrue(TypeUtils.isAssignable(null, String.class));
        assertFalse(TypeUtils.isAssignable(null, int.class));
        assertFalse(TypeUtils.isAssignable(String.class, (Type) null));
    }

    // isInstance

    @Test
    public void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(42), String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance("x", null));
    }

    // normalizeUpperBounds

    @Test
    public void testNormalizeUpperBoundsSingleElementUnchanged() {
        final Type[] bounds = {Number.class};
        assertSame(bounds, TypeUtils.normalizeUpperBounds(bounds));
    }

    @Test
    public void testNormalizeUpperBoundsRemovesRedundantSupertype() {
        final Type[] bounds = {Serializable.class, ArrayList.class};
        final Type[] result = TypeUtils.normalizeUpperBounds(bounds);
        assertArrayEquals(new Type[] {ArrayList.class}, result);
    }

    @Test
    public void testNormalizeUpperBoundsNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.normalizeUpperBounds(null);
            }
        }));
    }

    // parameterize / parameterizeWithOwner

    @Test
    public void testParameterizeWithMap() {
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(List.class.getTypeParameters()[0], String.class);
        final ParameterizedType pt = TypeUtils.parameterize(List.class, map);
        assertEquals(List.class, pt.getRawType());
        assertArrayEquals(new Type[] {String.class}, pt.getActualTypeArguments());
    }

    @Test
    public void testParameterizeWrongArgumentCountThrows() {
        assertThrows(IllegalArgumentException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        }));
    }

    @Test
    public void testParameterizeNullRawClassThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.parameterize(null, String.class);
            }
        }));
    }

    // toLongString

    @Test
    public void testToLongStringUnbounded() {
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final String expected = TypeUtilsAgentTest.class.getName() + ".Box:T";
        assertEquals(expected, TypeUtils.toLongString(tv));
    }

    @Test
    public void testToLongStringBounded() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        final String expected = TypeUtilsAgentTest.class.getName() + ".Bounded:T extends java.lang.Number";
        assertEquals(expected, TypeUtils.toLongString(tv));
    }

    @Test
    public void testToLongStringNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.toLongString(null);
            }
        }));
    }

    // toString

    @Test
    public void testToStringClass() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
        assertEquals("java.lang.String[]", TypeUtils.toString(String[].class));
    }

    @Test
    public void testToStringParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(pt));
    }

    @Test
    public void testToStringCyclicalClassDetected() {
        assertEquals("Enum(cycle)", TypeUtils.toString(Enum.class));
    }

    @Test
    public void testToStringNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.toString(null);
            }
        }));
    }

    // typesSatisfyVariables

    @Test
    public void testTypesSatisfyVariablesTrue() {
        final TypeVariable<?>[] vars = Pair.class.getTypeParameters();
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(vars[0], Number.class);
        map.put(vars[1], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesFalse() {
        final TypeVariable<?>[] vars = Pair.class.getTypeParameters();
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(vars[0], Number.class);
        map.put(vars[1], String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesNullThrows() {
        assertThrows(NullPointerException.class, toExecutable(new Runnable() {
            @Override
            public void run() {
                TypeUtils.typesSatisfyVariables(null);
            }
        }));
    }

    // unrollVariables

    @Test
    public void testUnrollVariablesSubstitutesAssignedVariable() throws Exception {
        final Field field = Box.class.getDeclaredField("value");
        final Type fieldType = field.getGenericType();
        final TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(tv, String.class);
        assertEquals(String.class, TypeUtils.unrollVariables(map, fieldType));
    }

    @Test
    public void testUnrollVariablesNullMapLeavesUnassignedVariableUnresolved() throws Exception {
        final Field field = Box.class.getDeclaredField("value");
        final Type fieldType = field.getGenericType();
        assertNull(TypeUtils.unrollVariables(null, fieldType));
    }

    // wildcardType builder / WILDCARD_ALL

    @Test
    public void testWildcardTypeBuilder() {
        final WildcardType wildcard = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertArrayEquals(new Type[] {Number.class}, wildcard.getUpperBounds());
        assertEquals("? extends java.lang.Number", TypeUtils.toString(wildcard));
    }

    @Test
    public void testWildcardAllConstant() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.WILDCARD_ALL.getUpperBounds());
    }

    // wrap

    @Test
    public void testWrapClass() {
        final Typed<String> typed = TypeUtils.wrap(String.class);
        assertEquals(String.class, typed.getType());
    }

    @Test
    public void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> typed = TypeUtils.wrap((Type) pt);
        assertSame(pt, typed.getType());
    }
}
