/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    @Test
    void testNewFormatDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getHeader());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    void testDefaultFormatSettings() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testDelimiterCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\r'));
    }

    @Test
    void testDelimiterCannotBeEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testCommentMarkerCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
    }

    @Test
    void testEscapeCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\r'));
    }

    @Test
    void testQuoteCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\n'));
    }

    @Test
    void testQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testQuoteCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testEscapeCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape(null).setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderNamesDisallowedByDefaultMode() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .setHeader("A", "B", "A").get());
    }

    @Test
    void testDuplicateHeaderNamesAllowedByAllowAllMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("A", "B", "A").get();
        assertArrayEquals(new String[] {"A", "B", "A"}, format.getHeader());
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowedByAllowEmptyMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "B", "").get();
        assertArrayEquals(new String[] {"", "B", ""}, format.getHeader());
    }

    @Test
    void testDuplicateNonEmptyHeaderNamesDisallowedByAllowEmptyMode() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY)
                .setHeader("A", "B", "A").get());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testHeaderCommentsFromObjectsConvertedToStrings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(1, null, "x").get();
        assertArrayEquals(new String[] {"1", null, "x"}, format.getHeaderComments());
    }

    @Test
    void testNullStringSetsQuotedNullStringAndFlag() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(format.isNullStringSet());
        assertEquals("NULL", format.getNullString());
    }

    @Test
    void testNullStringNotSetByDefault() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertNull(CSVFormat.DEFAULT.getNullString());
    }

    @Test
    void testQuoteCharacterNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    @Test
    void testEscapeCharacterNullDisablesEscaping() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape((Character) null).get();
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getEscapeCharacter());
    }

    @Test
    void testCommentMarkerNullDisablesComments() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker((Character) null).get();
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getCommentMarker());
    }

    @Test
    void testRecordSeparatorFromChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator('\n').get();
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testMaxRowsDefaultIsZeroAndUnused() {
        assertEquals(0, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        assertTrue(CSVFormat.DEFAULT.useRow(1000));
    }

    @Test
    void testMaxRowsLimitsUseRow() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    @Test
    void testBuilderCopiesExistingFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setHeader("A").get();
        final CSVFormat copyFormat = CSVFormat.Builder.create(original).get();
        assertEquals(original, copyFormat);
        assertNotSame(original, copyFormat);
    }

    @Test
    void testFormatValues() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", formatted);
    }

    @Test
    void testFormatNullValueWithoutNullStringIsEmpty() {
        final String formatted = CSVFormat.DEFAULT.format((Object) null);
        assertEquals("", formatted);
    }

    @Test
    void testFormatNullValueWithNullString() {
        final String formatted = CSVFormat.DEFAULT.builder().setNullString("NULL").get().format((Object) null);
        assertEquals("NULL", formatted);
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b");
        assertEquals("a,b\r\n", writer.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterAndSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get().println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintSingleValueWithTrim() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setTrim(true).get().print("  value  ", writer, true);
        assertEquals("value", writer.toString());
    }

    @Test
    void testParseReturnsParser() throws IOException {
        final Reader reader = new StringReader("a,b\nc,d\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
        parser.close();
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat first = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat second = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    void testEqualsFalseForDifferentDelimiter() {
        final CSVFormat first = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat second = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(first, second);
    }

    @Test
    void testEqualsFalseForNullAndDifferentType() {
        assertNotEquals(null, CSVFormat.DEFAULT);
        assertNotEquals("not a format", CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsReflexive() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
    }

    @Test
    void testToStringContainsDelimiterAndSkipHeaderRecord() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringIncludesHeaderWhenSet() {
        final String str = CSVFormat.DEFAULT.builder().setHeader("A", "B").get().toString();
        assertTrue(str.contains("Header:[A, B]"));
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
    }

    @Test
    void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("DoesNotExist"));
    }

    @Test
    void testGetDelimiterDeprecatedMatchesFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(";").get();
        assertEquals(';', format.getDelimiter());
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testExcelPredefinedSettings() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testMySqlPredefinedSettings() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
    }

    @Test
    void testWithDelimiterDeprecatedBuildsNewFormat() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    void testWithHeaderDeprecatedBuildsNewFormat() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("X", "Y");
        assertArrayEquals(new String[] {"X", "Y"}, format.getHeader());
    }

    @Test
    void testWithFirstRecordAsHeaderSetsSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testCopyProducesEqualButDistinctInstance() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("A").get();
        final CSVFormat copyFormat = CSVFormat.copy(original);
        assertEquals(original, copyFormat);
        assertNotSame(original, copyFormat);
        assertNull(CSVFormat.copy(null));
    }

    @Test
    void testBuilderGetReturnsNewFormatEachTime() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        final CSVFormat format1 = builder.get();
        final CSVFormat format2 = builder.get();
        assertEquals(format1, format2);
        assertNotSame(format1, format2);
    }
}
