/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    /** Subclass needed only because the {@link FastDateParser} constructors are protected. */
    private static final class Parser extends FastDateParser {

        private static final long serialVersionUID = 1L;

        Parser(final String pattern, final TimeZone timeZone, final Locale locale) {
            super(pattern, timeZone, locale);
        }

        Parser(final String pattern, final TimeZone timeZone, final Locale locale, final Date centuryStart) {
            super(pattern, timeZone, locale, centuryStart);
        }
    }

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date utcDate(final int year, final int month, final int day, final int hour, final int minute, final int second) {
        final Calendar cal = new GregorianCalendar(UTC);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal.getTime();
    }

    // --- basic happy-path parsing -----------------------------------------------------------

    @Test
    void testParseBasicDate() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final Date date = parser.parse("2017-03-23");
        assertEquals(utcDate(2017, Calendar.MARCH, 23, 0, 0, 0), date);
    }

    @Test
    void testParseDateTime() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        final Date date = parser.parse("2020-01-02 03:04:05");
        assertEquals(utcDate(2020, Calendar.JANUARY, 2, 3, 4, 5), date);
    }

    @Test
    void testParseDoesNotRequireConsumingEntireString() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        // parse(String) only needs to consume a prefix.
        final Date date = parser.parse("2017-03-23 trailing garbage");
        assertEquals(utcDate(2017, Calendar.MARCH, 23, 0, 0, 0), date);
    }

    // --- simple getters ----------------------------------------------------------------------

    @Test
    void testGetPattern() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
    }

    @Test
    void testGetLocale() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.FRENCH);
        assertEquals(Locale.FRENCH, parser.getLocale());
    }

    @Test
    void testGetTimeZoneReturnsEquivalentButDefensiveCopy() {
        final TimeZone tz = TimeZone.getTimeZone("America/New_York");
        final FastDateParser parser = new Parser("yyyy-MM-dd", tz, Locale.US);
        final TimeZone returned = parser.getTimeZone();
        assertEquals(tz, returned);
        // Mutating the returned instance must not corrupt the parser's internal state.
        returned.setID("Bogus/Zone");
        assertEquals("America/New_York", parser.getTimeZone().getID());
    }

    // --- equals / hashCode / toString ---------------------------------------------------------

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser b = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser diffPattern = new Parser("yyyy/MM/dd", UTC, Locale.US);
        final FastDateParser diffLocale = new Parser("yyyy-MM-dd", UTC, Locale.FRENCH);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffLocale);
        assertNotEquals(a, null);
        assertNotEquals(a, "yyyy-MM-dd");
    }

    @Test
    void testToStringContainsPattern() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"), "toString() should mention the pattern: " + s);
    }

    // --- null arguments ------------------------------------------------------------------------

    @Test
    void testNullPatternThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new Parser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new Parser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        // the four-arg constructor docs say "locale, null maps to the default Locale"
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, null, null);
        assertNotNull(parser.getLocale());
    }

    // --- parse failure behaviour -----------------------------------------------------------

    @Test
    void testParseStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("not-a-date"));
    }

    @Test
    void testParseWithParsePositionReturnsNullOnFailure() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("garbage", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
        // index must remain unmodified on failure
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParsePositionIndexAdvancesOnPartialConsumption() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2017-03-23extra", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParseWithStartIndexBeyondSourceLengthFails() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date date = parser.parse("2017-03-23", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParseEmptyStringFails() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParseIntoCalendarUpdatesFieldsAndReturnsTrue() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2021-07-04", pos, cal);
        assertTrue(ok);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseIntoCalendarReturnsFalseOnFailureAndLeavesCalendarUntouched() {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(1999, Calendar.DECEMBER, 31);
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("garbage", pos, cal);
        assertFalse(ok);
        assertEquals(1999, cal.get(Calendar.YEAR));
    }

    // --- two digit year / century adjustment -------------------------------------------------

    @Test
    void testTwoDigitYearUsesExplicitCenturyStart() throws ParseException {
        // Century start of 1950 means two digit years from 50-99 map to 1950-1999,
        // and 00-49 map to 2000-2049.
        final Date centuryStart = utcDate(1950, Calendar.JANUARY, 1, 0, 0, 0);
        final FastDateParser parser = new Parser("yy-MM-dd", UTC, Locale.US, centuryStart);
        assertEquals(utcDate(1999, Calendar.JANUARY, 1, 0, 0, 0), parser.parse("99-01-01"));
        assertEquals(utcDate(1950, Calendar.JANUARY, 1, 0, 0, 0), parser.parse("50-01-01"));
        assertEquals(utcDate(2049, Calendar.JANUARY, 1, 0, 0, 0), parser.parse("49-01-01"));
        assertEquals(utcDate(2000, Calendar.JANUARY, 1, 0, 0, 0), parser.parse("00-01-01"));
    }

    @Test
    void testFourDigitYearIsNotCenturyAdjusted() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(utcDate(99, Calendar.JANUARY, 1, 0, 0, 0), parser.parse("0099-01-01"));
    }

    // --- hour strategies and their boundary behaviour (SimpleDateFormat-compatible) -----------

    @Test
    void testHourOfDay_H_boundaries() throws ParseException {
        final FastDateParser parser = new Parser("HH", UTC, Locale.US);
        final Calendar cal00 = Calendar.getInstance(UTC, Locale.US);
        cal00.clear();
        cal00.setTime(parser.parse("00"));
        assertEquals(0, cal00.get(Calendar.HOUR_OF_DAY));

        final Calendar cal23 = Calendar.getInstance(UTC, Locale.US);
        cal23.clear();
        cal23.setTime(parser.parse("23"));
        assertEquals(23, cal23.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHourInDay_k_midnightIsTwentyFourMappedToZero() throws ParseException {
        // Pattern 'k': Hour in day (1-24); midnight is 24, maps to HOUR_OF_DAY 0.
        final FastDateParser parser = new Parser("kk", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.setTime(parser.parse("24"));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));

        final Calendar cal1 = Calendar.getInstance(UTC, Locale.US);
        cal1.clear();
        cal1.setTime(parser.parse("01"));
        assertEquals(1, cal1.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHourInAmPm_h_middayIsTwelveMappedToZero() throws ParseException {
        // Pattern 'h': Hour in am/pm (1-12); 12 maps to HOUR 0.
        final FastDateParser parser = new Parser("hh", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.setTime(parser.parse("12"));
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    @Test
    void testHourInAmPm_K_boundaries() throws ParseException {
        // Pattern 'K': Hour in am/pm (0-11).
        final FastDateParser parser = new Parser("KK", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.setTime(parser.parse("11"));
        assertEquals(11, cal.get(Calendar.HOUR));
    }

    // --- am/pm and text fields ------------------------------------------------------------------

    @Test
    void testAmPmTextField() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd hh:mm a", UTC, Locale.US);
        final Date pm = parser.parse("2020-01-01 03:15 PM");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.setTime(pm);
        assertEquals(15, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(15, cal.get(Calendar.MINUTE));
    }

    @Test
    void testMonthNameTextField() throws ParseException {
        final FastDateParser parser = new Parser("dd MMMM yyyy", UTC, Locale.US);
        final Date date = parser.parse("04 July 2021");
        assertEquals(utcDate(2021, Calendar.JULY, 4, 0, 0, 0), date);
    }

    @Test
    void testMonthNameTextFieldIsCaseInsensitive() throws ParseException {
        final FastDateParser parser = new Parser("dd MMMM yyyy", UTC, Locale.US);
        final Date date = parser.parse("04 JULY 2021");
        assertEquals(utcDate(2021, Calendar.JULY, 4, 0, 0, 0), date);
    }

    @Test
    void testInvalidMonthNameFailsGracefullyWithoutThrowingUnexpectedException() {
        final FastDateParser parser = new Parser("dd MMMM yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        // "Blorgtember" is not a real month display name: must be a parse failure (null / error
        // index set), not an undeclared IllegalArgumentException/NullPointerException escaping.
        final Date date = parser.parse("04 Blorgtember 2021", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    // --- literal / quoted text ------------------------------------------------------------------

    @Test
    void testQuotedLiteralText() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        final Date date = parser.parse("2020-05-06T07:08:09");
        assertEquals(utcDate(2020, Calendar.MAY, 6, 7, 8, 9), date);
    }

    @Test
    void testQuotedLiteralTextMismatchFails() {
        final FastDateParser parser = new Parser("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2020-05-06X07:08:09", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new Parser("yyyy-MM-dd'T", UTC, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        // 'q' (lower-case stand-alone quarter) is not amongst the letters FastDateParser supports.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new Parser("yyyy-MM-dd q", UTC, Locale.US);
            }
        });
    }

    // --- time zone patterns --------------------------------------------------------------------

    @Test
    void testRfc822TimeZoneOffset() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd HH:mm Z", UTC, Locale.US);
        final Date date = parser.parse("2020-01-01 10:00 +0200");
        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+02:00"), Locale.US);
        cal.clear();
        cal.set(2020, Calendar.JANUARY, 1, 10, 0, 0);
        assertEquals(cal.getTime(), date);
    }

    @Test
    void testIso8601TimeZoneOffset() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd HH:mm XXX", UTC, Locale.US);
        final Date date = parser.parse("2020-01-01 10:00 +02:00");
        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+02:00"), Locale.US);
        cal.clear();
        cal.set(2020, Calendar.JANUARY, 1, 10, 0, 0);
        assertEquals(cal.getTime(), date);
    }

    @Test
    void testIso8601ZuluTimeZone() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd HH:mm X", UTC, Locale.US);
        final Date date = parser.parse("2020-01-01 10:00 Z");
        assertEquals(utcDate(2020, Calendar.JANUARY, 1, 10, 0, 0), date);
    }

    @Test
    void testNamedTimeZone() throws ParseException {
        final FastDateParser parser = new Parser("yyyy-MM-dd HH:mm z", UTC, Locale.US);
        final Date date = parser.parse("2020-01-01 10:00 GMT");
        assertEquals(utcDate(2020, Calendar.JANUARY, 1, 10, 0, 0), date);
    }

    // --- serialization ---------------------------------------------------------------------

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser parser = new Parser("yyyy-MM-dd", TimeZone.getTimeZone("America/Chicago"), Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser roundTripped = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, roundTripped);
        assertEquals(parser.getPattern(), roundTripped.getPattern());
        assertEquals(parser.getTimeZone(), roundTripped.getTimeZone());
        assertEquals(parser.getLocale(), roundTripped.getLocale());
        // the deserialized instance must still be able to parse (transient fields reinitialized)
        final Calendar expected = Calendar.getInstance(TimeZone.getTimeZone("America/Chicago"), Locale.US);
        expected.clear();
        expected.set(2021, Calendar.MARCH, 3, 0, 0, 0);
        assertEquals(expected.getTime(), roundTripped.parse("2021-03-03"));
    }

    // --- week year pattern ('Y') -----------------------------------------------------------

    @Test
    void testWeekYearPatternResolvesWeekDate() throws ParseException {
        // 2015-01-01 is a Thursday; under the ISO definition (used by java.util.Calendar's
        // default behaviour in most locales) week year 2015, week 1, day THURSDAY resolves
        // back to 2015-01-01.
        final FastDateParser parser = new Parser("YYYY-'W'ww-u", UTC, Locale.US);
        final Date date = parser.parse("2015-W01-4");
        assertEquals(utcDate(2015, Calendar.JANUARY, 1, 0, 0, 0), date);
    }

    // --- overflow handling in numeric fields ------------------------------------------------

    @Test
    void testOverlongNumericFieldDoesNotThrowUndeclaredException() {
        final FastDateParser parser = new Parser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        // a run of digits whose integer value overflows an int: must be a controlled parse
        // failure (null / errorIndex set), not an escaping NumberFormatException.
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    // --- Locale with Thai / non-Gregorian-ish behaviour, and basic non-US locale -------------

    @Test
    void testDifferentLocaleMonthNames() throws ParseException {
        final FastDateParser parser = new Parser("dd MMMM yyyy", UTC, Locale.FRENCH);
        final Date date = parser.parse("04 juillet 2021");
        assertEquals(utcDate(2021, Calendar.JULY, 4, 0, 0, 0), date);
    }
}
