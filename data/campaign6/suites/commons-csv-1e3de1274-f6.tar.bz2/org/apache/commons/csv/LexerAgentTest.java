/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testEmptyInputYieldsEof() throws Exception {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testSimpleTokensCommaDelimiter() throws Exception {
        final Lexer lexer = createLexer("a,b,c\n", CSVFormat.DEFAULT);

        Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());

        token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    @Test
    void testFirstEolDetectedAfterEndOfRecord() throws Exception {
        final Lexer lexer = createLexer("a,b\nc,d\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        assertNull(lexer.getFirstEol());
        lexer.nextToken(token); // TOKEN "a"
        token.reset();
        lexer.nextToken(token); // EORECORD "b"
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testFirstEolCrlf() throws Exception {
        final Lexer lexer = createLexer("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token); // TOKEN "a"
        token.reset();
        lexer.nextToken(token); // EORECORD "b"
        assertEquals("\r\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testFirstEolCr() throws Exception {
        final Lexer lexer = createLexer("a,b\rc,d\r", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token); // TOKEN "a"
        token.reset();
        lexer.nextToken(token); // EORECORD "b"
        assertEquals("\r", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testEncapsulatedTokenWithDoubledQuote() throws Exception {
        final Lexer lexer = createLexer("\"a,\"\"b\"\"\",c\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertTrue(token.isQuoted);
        assertEquals("a,\"b\"", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testUnquotedTokenIsNotQuoted() throws Exception {
        final Lexer lexer = createLexer("abc\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token);
        assertFalse(token.isQuoted);
        lexer.close();
    }

    @Test
    void testEofBeforeClosingEncapsulatorThrows() throws Exception {
        final Lexer lexer = createLexer("\"abc", CSVFormat.DEFAULT);
        final Token token = new Token();
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        lexer.close();
    }

    @Test
    void testLenientEofAllowsUnterminatedQuotedToken() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"abc", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
        lexer.close();
    }

    @Test
    void testInvalidCharacterBetweenEncapsulatedTokenAndDelimiterThrows() throws Exception {
        final Lexer lexer = createLexer("\"abc\"x,d\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        lexer.close();
    }

    @Test
    void testTrailingDataAllowsCharactersAfterEncapsulatedToken() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"abc\"x,d\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abcx", token.content.toString());
        lexer.close();
    }

    @Test
    void testCommentLineIsTrimmedAndTypedComment() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("# a comment \nd,e\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("d", token.content.toString());
        lexer.close();
    }

    @Test
    void testCommentNotAtStartOfLineIsNotComment() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("d#e\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("d#e", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\na,b\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesFalseKeepsBlankLines() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer("\na,b\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesAllBlankYieldsEof() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\n\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsWhitespace() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer("  a  , b \n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesFalseKeepsWhitespace() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(false).get();
        final Lexer lexer = createLexer(" a , b \n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals(" a ", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeCharacterUnescapesKnownSequences() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\tb\n", format);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a\tb", token.content.toString());
        lexer.close();
    }

    @Test
    void testReadEscapeReturnsEofForUnexpectedCharacter() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("z", format);
        final int unescaped = lexer.readEscape();
        assertEquals(EOF, unescaped);
        lexer.close();
    }

    @Test
    void testReadEscapeThrowsOnEofAfterEscape() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("", format);
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        lexer.close();
    }

    @Test
    void testIsDelimiterSingleChar() throws Exception {
        final Lexer lexer = createLexer(",x", CSVFormat.DEFAULT);
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('x'));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiChar() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(":xrest"));
        final Lexer lexer = new Lexer(format, reader);
        final int c = reader.read(); // consume the first ':' as nextToken() would
        assertFalse(lexer.isDelimiter(c));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharMatches() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("::abc"));
        final Lexer lexer = new Lexer(format, reader);
        final int c = reader.read(); // consume the first ':' as nextToken() would
        assertTrue(lexer.isDelimiter(c));
        lexer.close();
    }

    @Test
    void testIsEscapeAndIsQuoteCharAndIsCommentStart() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote('"').setCommentMarker('#').get();
        final Lexer lexer = createLexer("", format);
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('#'));
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('%'));
        lexer.close();
    }

    @Test
    void testIsEndOfFile() throws Exception {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));
        lexer.close();
    }

    @Test
    void testIsStartOfLine() throws Exception {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isStartOfLine('\n'));
        assertTrue(lexer.isStartOfLine('\r'));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        lexer.close();
    }

    @Test
    void testReadEndOfLineCrLfIsConsumedTogether() throws Exception {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\r\nabc"));
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        final int c = reader.read(); // consume the '\r' as nextToken() would
        final boolean isEol = lexer.readEndOfLine(c);
        assertTrue(isEol);
        assertEquals("\r\n", lexer.getFirstEol());
        // readEndOfLine silently swallows the paired LF, so the next char available is 'a'
        assertEquals('a', reader.read());
        lexer.close();
    }

    @Test
    void testCloseClosesUnderlyingReader() throws Exception {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testPositionAndLineNumberAdvanceWhileReading() throws Exception {
        final Lexer lexer = createLexer("a,b\nc,d\n", CSVFormat.DEFAULT);
        assertEquals(0, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getCharacterPosition());
        final Token token = new Token();
        lexer.nextToken(token); // "a"
        token.reset();
        lexer.nextToken(token); // EORECORD "b"
        assertEquals(1, lexer.getCurrentLineNumber());
        assertTrue(lexer.getCharacterPosition() > 0);
        lexer.close();
    }

    @Test
    void testGetBytesReadAdvancesWithAsciiInputWhenTrackingEnabled() throws Exception {
        // trailing delimiter means the token is finished without reading past EOF
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc,"),
                java.nio.charset.StandardCharsets.UTF_8, true);
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertEquals(0, lexer.getBytesRead());
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abc", token.content.toString());
        assertEquals(4, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testGetBytesReadDoesNotCountPhantomEofCharacter() throws Exception {
        // Reaching EOF causes one extra internal read() call returning -1; that sentinel must not be
        // counted as a real (3-byte, per UTF-8) character in the byte count.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"),
                java.nio.charset.StandardCharsets.UTF_8, true);
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("abc", token.content.toString());
        assertEquals(3, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testGetBytesReadStaysZeroWhenTrackingDisabled() throws Exception {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterMatchesEscapedDelimiterSequence() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!,rest"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read(); // consume the leading escape char, as appendNextEscapedCharacterToToken() would
        assertTrue(lexer.isEscapeDelimiter());
        assertEquals('r', reader.read());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterFalseWhenNoMatch() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!xrest"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read(); // consume the leading escape char
        assertFalse(lexer.isEscapeDelimiter());
        assertEquals('x', reader.read());
        lexer.close();
    }

    @Test
    void testTrimTrailingSpaces() throws Exception {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());

        final StringBuilder noSpaces = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noSpaces);
        assertEquals("abc", noSpaces.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals("", allSpaces.toString());
        lexer.close();
    }
}
