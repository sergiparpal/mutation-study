/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    @Test
    void testAvailableLocaleListIsSortedAndUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        for (int i = 1; i < list.size(); i++) {
            assertTrue(list.get(i - 1).toString().compareTo(list.get(i).toString()) <= 0,
                    "list should be sorted by toString()");
        }
        assertThrows(UnsupportedOperationException.class, () -> list.add(Locale.US));
        assertSame(list, LocaleUtils.availableLocaleList(), "should return the same cached list instance");
    }

    @Test
    void testAvailableLocaleSetMatchesList() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(set);
        assertEquals(list.size(), set.size());
        assertTrue(set.containsAll(list));
        assertThrows(UnsupportedOperationException.class, () -> set.add(Locale.US));
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "YY", "zzzz_made_up_variant")));
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    @Test
    void testCountriesByLanguageNullAndInvalid() {
        assertEquals(0, LocaleUtils.countriesByLanguage(null).size());
        assertEquals(0, LocaleUtils.countriesByLanguage("ENG").size());
        assertEquals(0, LocaleUtils.countriesByLanguage("e2").size());
        assertEquals(0, LocaleUtils.countriesByLanguage("zzzz").size());
    }

    @Test
    void testCountriesByLanguageValid() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty(), "expected a country for " + locale);
            assertTrue(locale.getVariant().isEmpty(), "expected no variant for " + locale);
        }
        assertThrows(UnsupportedOperationException.class, () -> list.add(Locale.US));
        assertSame(list, LocaleUtils.countriesByLanguage("en"), "result should be cached");
    }

    @Test
    void testLanguagesByCountryNullAndInvalid() {
        assertEquals(0, LocaleUtils.languagesByCountry(null).size());
        assertEquals(0, LocaleUtils.languagesByCountry("usa").size());
        assertEquals(0, LocaleUtils.languagesByCountry("U1").size());
        assertEquals(0, LocaleUtils.languagesByCountry("U").size());
    }

    @Test
    void testLanguagesByCountryValid() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty(), "expected no variant for " + locale);
        }
        assertThrows(UnsupportedOperationException.class, () -> list.add(Locale.US));
        assertSame(list, LocaleUtils.languagesByCountry("US"), "result should be cached");
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(Locale.ROOT));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("", "")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
    }

    @Test
    void testLocaleLookupListSingleArg() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(locale, list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertThrows(UnsupportedOperationException.class, () -> list.add(Locale.US));
    }

    @Test
    void testLocaleLookupListTwoArgs() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, Locale.ENGLISH);
        assertEquals(4, list.size());
        assertEquals(locale, list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(Locale.ENGLISH, list.get(3));
    }

    @Test
    void testLocaleLookupListNoCountryNoVariant() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr"), Locale.ENGLISH);
        assertEquals(2, list.size());
        assertEquals(new Locale("fr"), list.get(0));
        assertEquals(Locale.ENGLISH, list.get(1));
    }

    @Test
    void testLocaleLookupListCountryNoVariant() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA"), Locale.ENGLISH);
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
        assertEquals(Locale.ENGLISH, list.get(2));
    }

    @Test
    void testLocaleLookupListDefaultAlreadyPresent() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, locale);
        assertEquals(3, list.size());
    }

    @Test
    void testLocaleLookupListNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null, null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
        assertThrows(UnsupportedOperationException.class, () -> list.add(Locale.US));
    }

    @Test
    void testLocaleLookupListNoDuplicates() {
        // A locale with a variant but no country must not list the language-only locale twice.
        final Locale locale = new Locale("fr", "", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, new Locale("fr"));
        final java.util.Set<Locale> distinct = new java.util.HashSet<>(list);
        assertEquals(distinct.size(), list.size(), "localeLookupList must not contain duplicates: " + list);
    }

    @Test
    void testToLocaleFromLocale() {
        assertEquals(Locale.CANADA, LocaleUtils.toLocale(Locale.CANADA));
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
        assertEquals("", locale.getVariant());
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en"), LocaleUtils.toLocale("en"));
    }

    @Test
    void testToLocaleStringLanguageAndCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    void testToLocaleStringLanguageAndCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    void testToLocaleStringLanguageAndNumericArea() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    void testToLocaleStringFull() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    void testToLocaleStringCountryOnlyIsoAlias() {
        // "US" is a recognized ISO country code, so it parses as a country-only locale.
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    void testToLocaleStringUnderscorePrefixCountryOnly() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringUnderscorePrefixWithVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_xxx");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    void testToLocaleStringThaiSpecialCase() {
        assertEquals(new Locale("th", "TH", "TH"), LocaleUtils.toLocale("th_TH_TH_#u-nu-thai"));
    }

    @Test
    void testToLocaleStringJapaneseSpecialCase() {
        assertEquals(new Locale("ja", "JP", "JP"), LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese"));
    }

    @Test
    void testToLocaleStringTooShortThrows() {
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale("a"));
    }

    @Test
    void testToLocaleStringUnderscorePrefixTooShortThrows() {
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale("_G"));
    }

    @Test
    void testToLocaleStringUnderscorePrefixLowerCaseThrows() {
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale("_gb"));
    }

    @Test
    void testToLocaleStringUpperCaseNonCountryThrows() {
        // "EN" is not a recognized ISO country code and is not a well formed language tag.
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale("EN"));
    }

    @Test
    void testToLocaleStringLowerCaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale("en_gb"));
    }

    @Test
    void testToLocaleStringTrailingUnderscoreThrows() {
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale("en_GB_"));
    }

    @Test
    void testToLocaleStringWhitespaceThrows() {
        assertThrows(IllegalArgumentException.class, () -> LocaleUtils.toLocale(" en"));
    }

    @Test
    void testOfCountry() {
        final Locale locale = LocaleUtils.ofCountry("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    void testOfCountryNullThrows() {
        assertThrows(NullPointerException.class, () -> LocaleUtils.ofCountry(null));
    }

    @Test
    void testCacheMapsArePopulatedOnLookup() {
        LocaleUtils.languagesByCountry("FR");
        assertTrue(LocaleUtils.getCcToLocalesMap().containsKey("FR"));
        LocaleUtils.countriesByLanguage("de");
        assertTrue(LocaleUtils.getLcToLocalesMap().containsKey("de"));
    }
}
