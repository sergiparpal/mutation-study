/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link WordUtils}.
 */
@Deprecated
class WordUtilsAgentTest {

    @Test
    void testCapitalizeNullAndEmpty() {
        assertNull(WordUtils.capitalize(null));
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    void testCapitalizeWhitespaceDelimited() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
        assertEquals("I", WordUtils.capitalize("i"));
        assertEquals(" I", WordUtils.capitalize(" i"));
    }

    @Test
    void testCapitalizeWithDelimiters() {
        assertNull(WordUtils.capitalize(null, '.'));
        assertEquals("", WordUtils.capitalize("", '.'));
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalize(str, new char[0]));
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    @Test
    void testCapitalizeFullyNullAndEmpty() {
        assertNull(WordUtils.capitalizeFully(null));
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    void testCapitalizeFully() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    @Test
    void testCapitalizeFullyWithDelimiters() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
        assertEquals("", WordUtils.capitalizeFully("", '.'));
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalizeFully(str, new char[0]));
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am fine", (char[]) null));
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    @Test
    void testContainsAllWordsNullAndEmptyInputs() {
        assertFalse(WordUtils.containsAllWords(null, "ab"));
        assertFalse(WordUtils.containsAllWords(""));
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
        assertFalse(WordUtils.containsAllWords("abc def"));
    }

    @Test
    void testContainsAllWordsBlankWord() {
        assertFalse(WordUtils.containsAllWords("abc def", "abc", ""));
        assertFalse(WordUtils.containsAllWords("abc def", "abc", "  "));
    }

    @Test
    void testContainsAllWordsPartialMatch() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    void testContainsAllWordsFullMatch() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
        assertTrue(WordUtils.containsAllWords("ab cd ef", "ab", "cd", "ef"));
        assertFalse(WordUtils.containsAllWords("ab cd ef", "ab", "cd", "xy"));
    }

    @Test
    void testInitialsNullAndEmpty() {
        assertNull(WordUtils.initials(null));
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    void testInitialsDefault() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
        assertEquals("B", WordUtils.initials("Ben"));
    }

    @Test
    void testInitialsWithDelimiters() {
        assertNull(WordUtils.initials(null, '.'));
        assertEquals("", WordUtils.initials("", '.'));
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
        assertEquals("BJ", WordUtils.initials("Ben J.Lee", (char[]) null));
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    @Test
    void testSwapCaseNullAndEmpty() {
        assertNull(WordUtils.swapCase(null));
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    void testSwapCase() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
        assertEquals("1 i", WordUtils.swapCase("1 I"));
        assertEquals("i", WordUtils.swapCase("I"));
    }

    @Test
    void testUncapitalizeNullAndEmpty() {
        assertNull(WordUtils.uncapitalize(null));
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    void testUncapitalize() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    @Test
    void testUncapitalizeWithDelimiters() {
        assertNull(WordUtils.uncapitalize(null, '.'));
        assertEquals("", WordUtils.uncapitalize("", '.'));
        final String str = "I AM FINE";
        assertSame(str, WordUtils.uncapitalize(str, new char[0]));
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    @Test
    void testWrapNull() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    void testWrapEmpty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    void testWrapBasic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    void testWrapLongWordNotWrappedByDefault() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    void testWrapLongWordWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    void testWrapCustomNewLineString() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    void testWrapCustomWrapOn() {
        assertEquals("flammable\ninflammable", WordUtils.wrap("flammable/inflammable", 20, "\n", true, "/"));
    }

    @Test
    void testWrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("abc def", 0, "\n", false);
        assertEquals("abc\ndef", result);
        final String resultNegative = WordUtils.wrap("abc def", -5, "\n", false);
        assertEquals("abc\ndef", resultNegative);
    }

    @Test
    void testWrapBlankWrapOnDefaultsToSpace() {
        assertEquals("abc\ndef", WordUtils.wrap("abc def", 3, "\n", false, "  "));
    }

    @Test
    void testWrapNullNewLineUsesSystemLineSeparator() {
        final String result = WordUtils.wrap("abcdef ghijkl", 6, null, false);
        assertEquals("abcdef" + System.lineSeparator() + "ghijkl", result);
    }

    @Test
    void testConstructorIsPublic() {
        assertNotNull(new WordUtils());
    }
}
