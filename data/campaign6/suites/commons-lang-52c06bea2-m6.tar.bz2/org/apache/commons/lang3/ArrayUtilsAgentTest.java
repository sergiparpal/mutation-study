/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.AbstractMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
public class ArrayUtilsAgentTest {

    // ---- isEmpty / isNotEmpty ----

    @Test
    public void testIsEmptyNullAndEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(ArrayUtils.isNotEmpty((long[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new long[0]));
        assertTrue(ArrayUtils.isNotEmpty(new long[] {1L}));
    }

    // ---- getLength ----

    @Test
    public void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(2, ArrayUtils.getLength(new String[] {"a", "b"}));
    }

    @Test
    public void testGetLengthNotAnArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    // ---- contains ----

    @Test
    public void testContainsPrimitiveAndObject() {
        final int[] ints = {1, 2, 3};
        assertTrue(ArrayUtils.contains(ints, 2));
        assertFalse(ArrayUtils.contains(ints, 4));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final Object[] objects = {"a", null, "b"};
        assertTrue(ArrayUtils.contains(objects, "a"));
        assertTrue(ArrayUtils.contains(objects, null));
        assertFalse(ArrayUtils.contains(objects, "z"));
    }

    @Test
    public void testContainsDoubleWithTolerance() {
        final double[] doubles = {1.0, 2.0, 3.0};
        assertFalse(ArrayUtils.contains(doubles, 2.05));
        assertTrue(ArrayUtils.contains(doubles, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(doubles, 2.5, 0.1));
    }

    // ---- indexOf / lastIndexOf ----

    @Test
    public void testIndexOfBoundaries() {
        final int[] array = {1, 2, 3, 2, 1};
        assertEquals(-1, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(-1, ArrayUtils.indexOf(array, 9));
        assertEquals(0, ArrayUtils.indexOf(array, 1));
        assertEquals(1, ArrayUtils.indexOf(array, 2, 1));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
        assertEquals(-1, ArrayUtils.indexOf(array, 1, 10));
    }

    @Test
    public void testLastIndexOfBoundaries() {
        final int[] array = {1, 2, 3, 2, 1};
        assertEquals(-1, ArrayUtils.lastIndexOf((int[]) null, 1));
        assertEquals(4, ArrayUtils.lastIndexOf(array, 1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 1, -1));
        assertEquals(4, ArrayUtils.lastIndexOf(array, 1, 100));
    }

    // ---- add ----

    @Test
    public void testAddElement() {
        final int[] result = ArrayUtils.add(new int[] {1, 2}, 3);
        assertArrayEquals(new int[] {1, 2, 3}, result);

        final int[] fromNull = ArrayUtils.add((int[]) null, 5);
        assertArrayEquals(new int[] {5}, fromNull);
    }

    @Test
    public void testAddElementAtIndex() {
        final int[] result = ArrayUtils.add(new int[] {1, 3}, 1, 2);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testAddElementAtIndexOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] {1, 2}, 5, 3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] {1, 2}, -1, 3);
            }
        });
    }

    @Test
    public void testAddAllObjectArrays() {
        final String[] a = {"a", "b"};
        final String[] b = {"c"};
        final String[] result = ArrayUtils.addAll(a, b);
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
        assertArrayEquals(a, ArrayUtils.addAll(a, (String[]) null));
    }

    // ---- remove ----

    @Test
    public void testRemoveAtIndex() {
        assertArrayEquals(new int[] {6}, ArrayUtils.remove(new int[] {2, 6}, 0));
        assertArrayEquals(new int[] {2}, ArrayUtils.remove(new int[] {2, 6}, 1));
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.remove(new int[] {2, 6, 3}, 1));
    }

    @Test
    public void testRemoveInvalidIndexThrows() {
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] {1, 2}, 2);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] {1, 2}, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    public void testRemoveElement() {
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.removeElement(new int[] {1, 2, 3}, 2));
        // element not present: returns a clone, unchanged
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.removeElement(new int[] {1, 2, 3}, 9));
    }

    @Test
    public void testRemoveAllOccurrences() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1);
        assertArrayEquals(new int[] {2, 3}, result);
    }

    // ---- insert ----

    @Test
    public void testInsert() {
        final int[] result = ArrayUtils.insert(1, new int[] {1, 3}, 2);
        assertArrayEquals(new int[] {1, 2, 3}, result);

        assertNull(ArrayUtils.insert(0, (int[]) null, 1));

        final int[] original = {1, 2, 3};
        assertArrayEquals(original, ArrayUtils.insert(1, original));
        assertNotSame(original, ArrayUtils.insert(1, original));
    }

    @Test
    public void testInsertInvalidIndexThrows() {
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new int[] {1, 2}, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(5, new int[] {1, 2}, 9);
            }
        });
    }

    // ---- clone ----

    @Test
    public void testClone() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
        assertNull(ArrayUtils.clone((int[]) null));

        final Object[] originalObj = {"a", "b"};
        final Object[] clonedObj = ArrayUtils.clone(originalObj);
        assertArrayEquals(originalObj, clonedObj);
        assertNotSame(originalObj, clonedObj);
    }

    // ---- isSameLength / isSameType ----

    @Test
    public void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
        assertFalse(ArrayUtils.isSameLength(new Object[] {1}, null));
    }

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
    }

    @Test
    public void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    // ---- isSorted ----

    @Test
    public void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
    }

    // ---- reverse ----

    @Test
    public void testReverseFullArray() {
        final int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);

        // null should not throw
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    public void testReverseRange() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    // ---- swap ----

    @Test
    public void testSwap() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testSwapOutOfBoundsIsNoOp() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, array);

        // null is a no-op, must not throw
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    public void testSwapNegativeIndexIsPromotedToZero() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, -3, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    // ---- shift ----

    @Test
    public void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] {4, 5, 1, 2, 3}, array);
    }

    @Test
    public void testShiftNullAndEmptyIsNoOp() {
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    // ---- subarray ----

    @Test
    public void testSubarray() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSubarrayClampsOutOfRangeIndices() {
        final int[] array = {1, 2, 3};
        // undervalue start is promoted to 0
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.subarray(array, -5, 10));
        // overvalue start results in empty array
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 10, 20));
        // end before start results in empty array
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 1));
    }

    // ---- toMap ----

    @Test
    public void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new Object[] {
                new Object[] {"key1", "value1"},
                new AbstractMap.SimpleEntry<Object, Object>("key2", "value2")
        });
        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
        assertEquals(2, map.size());

        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    public void testToMapInvalidElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {"not a map entry or array"});
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {new Object[] {"onlyOneElement"}});
            }
        });
    }

    // ---- toObject / toPrimitive ----

    @Test
    public void testToObjectAndToPrimitive() {
        final int[] primitives = {1, 2, 3};
        final Integer[] objects = ArrayUtils.toObject(primitives);
        assertArrayEquals(new Integer[] {1, 2, 3}, objects);

        final int[] roundTrip = ArrayUtils.toPrimitive(objects);
        assertArrayEquals(primitives, roundTrip);
    }

    @Test
    public void testToPrimitiveWithNullElementUsesDefault() {
        final Integer[] objects = {1, null, 3};
        final int[] result = ArrayUtils.toPrimitive(objects, -1);
        assertArrayEquals(new int[] {1, -1, 3}, result);
    }

    @Test
    public void testToPrimitiveNullElementThrowsWithoutDefault() {
        final Integer[] objects = {1, null, 3};
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(objects);
            }
        });
    }

    // ---- nullToEmpty ----

    @Test
    public void testNullToEmpty() {
        assertArrayEquals(new int[0], ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = {1, 2};
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    // ---- isArrayIndexValid ----

    @Test
    public void testIsArrayIndexValid() {
        final String[] array = {"a", "b"};
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
    }

    // ---- toStringArray ----

    @Test
    public void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {1, "two", 3.0});
        assertArrayEquals(new String[] {"1", "two", "3.0"}, result);
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    public void testToStringArrayNullElementUsesDefault() {
        assertArrayEquals(new String[] {"a", "null"}, ArrayUtils.toStringArray(new Object[] {"a", null}));
        assertArrayEquals(new String[] {"a", "default"}, ArrayUtils.toStringArray(new Object[] {"a", null}, "default"));
    }

    // ---- startsWith ----

    @Test
    public void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2, 3, 4}));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, null));
    }
}
