/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.util.Formattable;
import java.util.FormattableFlags;
import java.util.Formatter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link FormattableUtils}.
 */
@Deprecated
class FormattableUtilsAgentTest {

    private static final class SimpleFormattable implements Formattable {
        private final String value;

        SimpleFormattable(final String value) {
            this.value = value;
        }

        @Override
        public void formatTo(final Formatter formatter, final int flags, final int width, final int precision) {
            try {
                formatter.out().append(value);
            } catch (final IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Test
    void testAppendFiveArgNoWidthNoPrecision() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("hello", formatter, 0, -1, -1);
        assertSame(formatter, result);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendDefaultRightJustifyPadsWithSpaces() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hi", formatter, 0, 10, -1);
        assertEquals("        hi", formatter.toString());
    }

    @Test
    void testAppendLeftJustifyPadsWithSpacesOnRight() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hi", formatter, FormattableFlags.LEFT_JUSTIFY, 10, -1);
        assertEquals("hi        ", formatter.toString());
    }

    @Test
    void testAppendWidthNegativeMeansNoPadding() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hi", formatter, 0, -1, -1);
        assertEquals("hi", formatter.toString());
    }

    @Test
    void testAppendWidthSmallerThanSeqMeansNoPadding() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 2, -1);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendPrecisionTruncatesHard() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 3);
        assertEquals("hel", formatter.toString());
    }

    @Test
    void testAppendPrecisionEqualToLengthMeansNoTruncation() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 5);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendPrecisionOneLessThanLengthTruncatesByOne() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 4);
        assertEquals("hell", formatter.toString());
    }

    @Test
    void testAppendPrecisionZeroTruncatesToEmpty() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 0);
        assertEquals("", formatter.toString());
    }

    @Test
    void testAppendSixArgCustomPadChar() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, 0, 5, -1, '*');
        assertEquals("***ab", formatter.toString());
    }

    @Test
    void testAppendSixArgCustomPadCharLeftJustify() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1, '*');
        assertEquals("ab***", formatter.toString());
    }

    @Test
    void testAppendSixArgWithEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("helloworld", formatter, 0, -1, 5, "...");
        assertEquals("he...", formatter.toString());
    }

    @Test
    void testAppendSixArgWithEllipsisAndPadding() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("helloworld", formatter, 0, 8, 5, "...");
        assertEquals("   he...", formatter.toString());
    }

    @Test
    void testAppendSevenArgNullEllipsisIsHardTruncation() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("hello", formatter, 0, -1, 3, ' ', null);
        assertSame(formatter, result);
        assertEquals("hel", formatter.toString());
    }

    @Test
    void testAppendSevenArgEllipsisExactlyAtPrecisionIsAllowed() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, 3, ' ', "...");
        assertEquals("...", formatter.toString());
    }

    @Test
    void testAppendEllipsisLongerThanPrecisionThrows() {
        final Formatter formatter = new Formatter();
        assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        FormattableUtils.append("hello", formatter, 0, -1, 3, ' ', "abcdef");
                    }
                });
    }

    @Test
    void testAppendEllipsisAllowedWhenPrecisionNegative() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -1, -1, ' ', "this ellipsis is long");
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendEmptySequenceWithPositiveWidth() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("", formatter, 0, 4, -1);
        assertEquals("    ", formatter.toString());
    }

    @Test
    void testToStringReturnsFormattedValue() {
        final SimpleFormattable formattable = new SimpleFormattable("custom-value");
        assertEquals("custom-value", FormattableUtils.toString(formattable));
    }

    @Test
    void testToStringWithNullFormattableReturnsNullLiteral() {
        assertEquals("null", FormattableUtils.toString(null));
    }

    @Test
    void testConstructorIsPublicAndUsable() {
        final FormattableUtils instance = new FormattableUtils();
        assertEquals(FormattableUtils.class, instance.getClass());
    }
}
