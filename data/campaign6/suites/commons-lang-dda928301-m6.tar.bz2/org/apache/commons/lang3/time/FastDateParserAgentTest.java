/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final Locale US = Locale.US;

    private static Calendar newCalendar() {
        final Calendar cal = Calendar.getInstance(UTC, US);
        cal.clear();
        return cal;
    }

    // -------------------- basic accessors --------------------

    @Test
    void testAccessors() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(US, parser.getLocale());
    }

    @Test
    void testToStringContainsPatternAndZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("UTC"));
    }

    @Test
    void testToStringAllContainsPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        assertTrue(parser.toStringAll().contains("pattern=yyyy-MM-dd"));
    }

    // -------------------- equals / hashCode --------------------

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", UTC, US);
        final FastDateParser diffPattern = new FastDateParser("dd/MM/yyyy", UTC, US);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), US);
        final FastDateParser diffLocale = new FastDateParser("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffZone);
        assertNotEquals(a, diffLocale);
        assertFalse(a.equals("not a parser"));
        assertFalse(a.equals(null));
    }

    // -------------------- happy path parsing --------------------

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        final Date date = parser.parse("2023-07-04");
        final Calendar cal = newCalendar();
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithTextMonthAndWeekday() throws ParseException {
        // 2001-07-04 was indeed a Wednesday
        final FastDateParser parser = new FastDateParser("EEE, dd MMM yyyy", UTC, US);
        final Date date = parser.parse("Wed, 04 Jul 2001");
        final Calendar cal = newCalendar();
        cal.setTime(date);
        assertEquals(2001, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.WEDNESDAY, cal.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testConsecutiveNumericFieldsRespectWidth() throws ParseException {
        // yyyy limited to 4 chars, MM to 2 chars, dd unbounded (last field)
        final FastDateParser parser = new FastDateParser("yyyyMMdd", UTC, US);
        final Date date = parser.parse("20231101");
        final Calendar cal = newCalendar();
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.NOVEMBER, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    // -------------------- 3-arg parse(source, pos, calendar) --------------------

    @Test
    void testParseIntoCalendarReturnsTrueAndUpdatesPosition() {
        final FastDateParser parser = new FastDateParser("MM/dd", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = newCalendar();
        final boolean ok = parser.parse("03/23", pos, cal);
        assertTrue(ok);
        assertEquals(5, pos.getIndex());
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseIntoCalendarReturnsFalseAndSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("MM/dd", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = newCalendar();
        final boolean ok = parser.parse("03-23", pos, cal);
        assertFalse(ok);
        assertEquals(2, pos.getErrorIndex());
    }

    @Test
    void testLenientOverflowMinutesRollIntoHours() {
        // the parser operates in lenient mode: 90 minutes becomes 1h30
        final FastDateParser parser = new FastDateParser("HH:mm", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = newCalendar();
        final boolean ok = parser.parse("01:90", pos, cal);
        assertTrue(ok);
        assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(30, cal.get(Calendar.MINUTE));
    }

    // -------------------- parse(source) / parse(source, pos) failure cases --------------------

    @Test
    void testParseStringThrowsParseExceptionOnUnparseableInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertEquals(0, ex.getErrorOffset());
        assertTrue(ex.getMessage().contains("Unparseable date"));
    }

    @Test
    void testParseWithPositionReturnsNullOnFailure() {
        final FastDateParser parser = new FastDateParser("MM/dd", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("A 3/23", pos);
        assertNull(date);
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testInputShorterThanPatternFails() {
        final FastDateParser parser = new FastDateParser("MM/dd/yyy", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("03/23", pos));
        assertEquals(5, pos.getErrorIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        final Object obj = parser.parseObject("2020-01-02");
        assertTrue(obj instanceof Date);
        final Calendar cal = newCalendar();
        cal.setTime((Date) obj);
        assertEquals(2020, cal.get(Calendar.YEAR));
    }

    @Test
    void testParseObjectWithPositionReturnsNullOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parseObject("garbage", pos));
    }

    // -------------------- literal / quoted text --------------------

    @Test
    void testQuotedLiteralMatches() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy'T'HH", UTC, US);
        final Date date = parser.parse("2024T10");
        final Calendar cal = newCalendar();
        cal.setTime(date);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(10, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testQuotedLiteralMismatchSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy'T'HH", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("2024X10", pos));
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testQuotedLiteralRunsOutOfInputSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy'T'HH", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("2024", pos));
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'T", UTC, US);
            }
        });
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-q", UTC, US);
            }
        });
        assertTrue(ex.getMessage().contains("'q'"));
    }

    @Test
    void testUnsupportedIsoTimeZoneWidthThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("XXXX", UTC, US);
            }
        });
    }

    // -------------------- numeric field boundaries / overflow --------------------

    @Test
    void testOverflowingNumberFieldFailsGracefully() {
        // a single unbounded numeric field that overflows an int must fail cleanly,
        // not throw NumberFormatException out of parse()
        final FastDateParser parser = new FastDateParser("y", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("123456789012345678901234567890", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testHour24RollsMidnightToZero() {
        final FastDateParser parser = new FastDateParser("k", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("24", pos, cal));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHour12NoonIsZero() {
        final FastDateParser parser = new FastDateParser("h", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("12", pos, cal));
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    @Test
    void testNumericMonthIsZeroBased() {
        final FastDateParser parser = new FastDateParser("MM", UTC, US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("01", pos, cal));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }

    @Test
    void testIsoDayOfWeekMondayAndSunday() {
        final FastDateParser parser = new FastDateParser("u", UTC, US);

        final Calendar monday = newCalendar();
        assertTrue(parser.parse("1", new ParsePosition(0), monday));
        assertEquals(Calendar.MONDAY, monday.get(Calendar.DAY_OF_WEEK));

        final Calendar sunday = newCalendar();
        assertTrue(parser.parse("7", new ParsePosition(0), sunday));
        assertEquals(Calendar.SUNDAY, sunday.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testLiteralYearWidthGreaterThanTwoIsNotCenturyAdjusted() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, US);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("0099", new ParsePosition(0), cal));
        assertEquals(99, cal.get(Calendar.YEAR));
    }

    @Test
    void testTwoDigitYearIsCenturyAdjustedWithExplicitCenturyStart() {
        final Calendar centuryStartCal = newCalendar();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final Date centuryStart = centuryStartCal.getTime();

        final FastDateParser parser = new FastDateParser("yy", UTC, US, centuryStart);

        final Calendar low = newCalendar();
        assertTrue(parser.parse("30", new ParsePosition(0), low));
        assertEquals(2030, low.get(Calendar.YEAR));

        final Calendar high = newCalendar();
        assertTrue(parser.parse("70", new ParsePosition(0), high));
        assertEquals(1970, high.get(Calendar.YEAR));
    }

    // -------------------- AM/PM and era text strategies --------------------

    @Test
    void testAmPmCaseInsensitive() {
        final FastDateParser parser = new FastDateParser("a", UTC, US);

        final Calendar pm = newCalendar();
        assertTrue(parser.parse("PM", new ParsePosition(0), pm));
        assertEquals(1, pm.get(Calendar.AM_PM));

        final Calendar am = newCalendar();
        assertTrue(parser.parse("am", new ParsePosition(0), am));
        assertEquals(0, am.get(Calendar.AM_PM));
    }

    @Test
    void testEraTextCaseInsensitive() {
        final FastDateParser parser = new FastDateParser("G", UTC, US);

        final Calendar ad = newCalendar();
        assertTrue(parser.parse("AD", new ParsePosition(0), ad));
        assertEquals(GregorianCalendar.AD, ad.get(Calendar.ERA));

        final Calendar lower = newCalendar();
        assertTrue(parser.parse("ad", new ParsePosition(0), lower));
        assertEquals(GregorianCalendar.AD, lower.get(Calendar.ERA));
    }

    // -------------------- time zone strategies --------------------

    @Test
    void testRfc822TimeZoneOffset() {
        final FastDateParser parser = new FastDateParser("yyyy Z", UTC, US);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("2024 +0500", new ParsePosition(0), cal));
        assertEquals(5 * 60 * 60 * 1000, cal.getTimeZone().getRawOffset());
    }

    @Test
    void testIso8601TimeZoneWithColon() {
        final FastDateParser parser = new FastDateParser("yyyy ZZ", UTC, US);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("2024 +05:00", new ParsePosition(0), cal));
        assertEquals(5 * 60 * 60 * 1000, cal.getTimeZone().getRawOffset());
    }

    @Test
    void testIsoXTimeZoneZuluIsGmt() {
        final FastDateParser parser = new FastDateParser("yyyy X", UTC, US);
        final Calendar cal = newCalendar();
        assertTrue(parser.parse("2024 Z", new ParsePosition(0), cal));
        assertEquals(0, cal.getTimeZone().getRawOffset());
    }

    @Test
    void testSkipTimeZoneHelper() {
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("GMT"));
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("gmt"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("America/New_York"));
    }

    // -------------------- Japanese imperial locale --------------------

    @Test
    void testJapaneseImperialLocaleErrorMessageMentionsEraLimit() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("garbage");
            }
        });
        assertTrue(ex.getMessage().contains("does not support dates before 1868-01-01"));
    }

    // -------------------- null argument handling --------------------

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, UTC, US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd", null, US);
            }
        });
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    // -------------------- serialization round-trip --------------------

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", UTC, US);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        assertNotNull(deserialized.parse("2023-07-04"));

        final Date originalDate = original.parse("2023-07-04");
        final Date deserializedDate = deserialized.parse("2023-07-04");
        assertEquals(originalDate, deserializedDate);
    }
}
