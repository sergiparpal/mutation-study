/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    @Test
    void testParseSimpleDateYieldsExpectedFields() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2021-06-15");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testGetters() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(GMT, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final TimeZone tz = TimeZone.getTimeZone("America/New_York");
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", tz, Locale.US);
        final TimeZone returned = parser.getTimeZone();
        assertEquals(tz, returned);
        assertNotEquals(System.identityHashCode(tz), System.identityHashCode(returned));
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser parser1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser parser2 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser differentPattern = new FastDateParser("MM/dd/yyyy", GMT, Locale.US);
        final FastDateParser differentZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDateParser differentLocale = new FastDateParser("yyyy-MM-dd", GMT, Locale.FRANCE);

        assertEquals(parser1, parser2);
        assertEquals(parser1.hashCode(), parser2.hashCode());
        assertNotEquals(parser1, differentPattern);
        assertNotEquals(parser1, differentZone);
        assertNotEquals(parser1, differentLocale);
        assertFalse(parser1.equals("not a parser"));
        assertFalse(parser1.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndZoneId() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String str = parser.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("GMT"));
    }

    @Test
    void testToStringAllContainsPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String str = parser.toStringAll();
        assertTrue(str.contains("yyyy-MM-dd"));
    }

    @Test
    void testParseStringThrowsParseExceptionForInvalidInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("Unparseable date"));
        assertEquals(0, e.getErrorOffset());
    }

    @Test
    void testParseWithParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("abcd-ef-gh", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testParseWithTrailingCharactersStopsAtPatternEnd() {
        final FastDateParser parser = new FastDateParser("MM/dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("3/23/1999", pos);
        assertNotNull(date);
        assertEquals(4, pos.getIndex());
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(23, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithShortSourceFailsAtEndOfInput() {
        final FastDateParser parser = new FastDateParser("MM/dd/yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("03/23", pos));
        assertEquals(5, pos.getErrorIndex());
    }

    @Test
    void testParseWithPositionBeyondSourceLengthFails() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        assertNull(parser.parse("2021-06-15", pos));
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseCalendarOverloadReturnsFalseOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = new GregorianCalendar(GMT);
        cal.clear();
        assertFalse(parser.parse("garbage", pos, cal));
    }

    @Test
    void testParseCalendarOverloadReturnsTrueAndUpdatesCalendarOnSuccess() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = new GregorianCalendar(GMT);
        cal.clear();
        assertTrue(parser.parse("2021-06-15", pos, cal));
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object obj = parser.parseObject("2021-06-15");
        assertTrue(obj instanceof Date);
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime((Date) obj);
        assertEquals(2021, cal.get(Calendar.YEAR));
    }

    @Test
    void testParseObjectWithParsePositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object result = parser.parseObject("bad input", pos);
        assertNull(result);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testTwoDigitYearAdjustmentBelowStartYearRollsToNextCentury() throws ParseException {
        final Calendar centuryStartCal = new GregorianCalendar(GMT);
        centuryStartCal.clear();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy-MM-dd", GMT, Locale.US, centuryStartCal.getTime());

        final Date below = parser.parse("30-01-01");
        final Calendar calBelow = Calendar.getInstance(GMT);
        calBelow.setTime(below);
        assertEquals(2030, calBelow.get(Calendar.YEAR));

        final Date atBoundary = parser.parse("50-01-01");
        final Calendar calAt = Calendar.getInstance(GMT);
        calAt.setTime(atBoundary);
        assertEquals(1950, calAt.get(Calendar.YEAR));

        final Date above = parser.parse("60-01-01");
        final Calendar calAbove = Calendar.getInstance(GMT);
        calAbove.setTime(above);
        assertEquals(1960, calAbove.get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearIsNotAdjusted() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("0099-01-01");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(99, cal.get(Calendar.YEAR));
    }

    @Test
    void testIsoTimeZoneStrategyParsesOffsetAndLiteralZ() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssX", GMT, Locale.US);
        final Date dateZ = parser.parse("2021-06-15T10:00:00Z");
        final Calendar calZ = Calendar.getInstance(GMT);
        calZ.setTime(dateZ);
        assertEquals(10, calZ.get(Calendar.HOUR_OF_DAY));

        final Date dateOffset = parser.parse("2021-06-15T10:00:00+02");
        final Calendar calOffset = Calendar.getInstance(GMT);
        calOffset.setTime(dateOffset);
        assertEquals(8, calOffset.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testIsoTimeZoneStrategyInvalidWidthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXXX", GMT, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd-q", GMT, Locale.US);
            }
        });
        assertTrue(e.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd'", GMT, Locale.US);
            }
        });
        assertTrue(e.getMessage().contains("Unterminated quote"));
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testNullLocaleFallsBackToDefaultLocale() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, null);
        assertNotNull(parser.getLocale());
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'T'MM", GMT, Locale.US);
        final ParsePosition posGood = new ParsePosition(0);
        assertNotNull(parser.parse("2021T06", posGood));

        final ParsePosition posBad = new ParsePosition(0);
        assertNull(parser.parse("2021X06", posBad));
        assertEquals(4, posBad.getErrorIndex());
    }

    @Test
    void testMonthNameTextStrategyParsesFullAndAbbreviatedNames() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM dd, yyyy", GMT, Locale.US);
        final Date date = parser.parse("June 15, 2021");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTextStrategyInvalidDisplayNameFailsParseWithoutException() {
        final FastDateParser parser = new FastDateParser("MMMM dd, yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Notamonth 15, 2021", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testNamedTimeZoneStrategyParsesGmtAndUnknownZoneFails() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm z", GMT, Locale.US);
        final ParsePosition posGood = new ParsePosition(0);
        assertNotNull(parser.parse("2021-06-15 10:00 GMT", posGood));

        final ParsePosition posBad = new ParsePosition(0);
        final Date bad = parser.parse("2021-06-15 10:00 NotAZone", posBad);
        assertNull(bad);
        assertEquals("2021-06-15 10:00 ".length(), posBad.getErrorIndex());
    }

    @Test
    void testHour24StrategyWrapsMidnight() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd kk:mm", GMT, Locale.US);
        final Date date = parser.parse("2021-06-15 24:00");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testHour12StrategyTwelveMapsToZero() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh:mm a", GMT, Locale.US);
        final Date date = parser.parse("12:00 AM");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(0, cal.get(Calendar.HOUR));
        assertEquals(Calendar.AM, cal.get(Calendar.AM_PM));
    }

    @Test
    void testWeekYearPatternResolvesViaSetWeekDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", GMT, Locale.US);
        final Date date = parser.parse("2021-W01-1");

        final Calendar expected = Calendar.getInstance(GMT, Locale.US);
        expected.clear();
        expected.setWeekDate(2021, 1, Calendar.MONDAY);

        assertEquals(expected.getTime(), date);
        final Calendar actual = Calendar.getInstance(GMT, Locale.US);
        actual.setTime(date);
        assertEquals(Calendar.MONDAY, actual.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testDigitOverflowFailsParseWithoutException() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testSerializationRoundTripPreservesStateAndBehavior() throws IOException, ClassNotFoundException, ParseException {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        final Date date = deserialized.parse("2021-06-15");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testJapaneseImperialLocaleAddsExplanatoryMessageOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("1868-01-01"));
    }
}
