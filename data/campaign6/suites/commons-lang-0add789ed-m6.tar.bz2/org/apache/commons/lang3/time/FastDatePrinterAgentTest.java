/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static FastDatePrinter newPrinter(final String pattern) {
        return new FastDatePrinter(pattern, UTC, Locale.US);
    }

    private static FastDatePrinter newPrinter(final String pattern, final TimeZone tz) {
        return new FastDatePrinter(pattern, tz, Locale.US);
    }

    private static Calendar utcCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = new GregorianCalendar(UTC);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        // Force the fields to be resolved into a concrete instant now, so that
        // later TimeZone changes on a clone correctly re-render the same instant
        // instead of just reinterpreting the still-pending fields.
        cal.getTimeInMillis();
        return cal;
    }

    @Test
    void testBasicDatePattern() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Calendar cal = utcCalendar(2023, Calendar.MARCH, 5, 10, 30, 0, 0);
        assertEquals("2023-03-05", printer.format(cal));
        assertEquals("2023-03-05", printer.format(cal.getTime()));
        assertEquals("2023-03-05", printer.format(cal.getTimeInMillis()));
    }

    @Test
    void testEmptyPatternProducesEmptyOutput() {
        final FastDatePrinter printer = newPrinter("");
        assertEquals("", printer.getPattern());
        assertEquals(0, printer.getMaxLengthEstimate());
        assertEquals("", printer.format(new Date(0L)));
    }

    @Test
    void testIllegalPatternCharacterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                newPrinter("yyyy-qq");
            }
        });
    }

    @Test
    void testIso8601InvalidLengthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                newPrinter("XXXX");
            }
        });
    }

    @Test
    void testIso8601Patterns() {
        final TimeZone plusTwo = new SimpleTimeZone(2 * 60 * 60 * 1000, "PLUS_TWO");
        final Calendar cal = utcCalendar(2020, Calendar.JUNE, 15, 12, 0, 0, 0);

        assertEquals("+02", newPrinter("X", plusTwo).format(cal));
        assertEquals("+0200", newPrinter("XX", plusTwo).format(cal));
        assertEquals("+02:00", newPrinter("XXX", plusTwo).format(cal));

        assertEquals("Z", newPrinter("X", UTC).format(cal));
        assertEquals("Z", newPrinter("XX", UTC).format(cal));
        assertEquals("Z", newPrinter("XXX", UTC).format(cal));
    }

    @Test
    void testTimeZoneNumberPatternsUseColonConsistently() {
        final TimeZone plusTwoThirty = new SimpleTimeZone((2 * 60 + 30) * 60 * 1000, "PLUS_0230");
        final Calendar cal = utcCalendar(2020, Calendar.JUNE, 15, 12, 0, 0, 0);

        assertEquals("+0230", newPrinter("Z", plusTwoThirty).format(cal));
        assertEquals("+02:30", newPrinter("ZZ", plusTwoThirty).format(cal));
        assertEquals("+02:30", newPrinter("ZZZ", plusTwoThirty).format(cal));
    }

    @Test
    void testTimeZoneNameRule() {
        final FastDatePrinter printer = newPrinter("z", UTC);
        final Calendar cal = utcCalendar(2020, Calendar.JUNE, 15, 12, 0, 0, 0);
        final String expected = UTC.getDisplayName(false, TimeZone.SHORT, Locale.US);
        assertEquals(expected, printer.format(cal));
    }

    @Test
    void testTwelveHourFieldMidnightBoundary() {
        final FastDatePrinter printer = newPrinter("h");
        final Calendar midnight = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar noon = utcCalendar(2020, Calendar.JANUARY, 1, 12, 0, 0, 0);
        final Calendar oneAm = utcCalendar(2020, Calendar.JANUARY, 1, 1, 0, 0, 0);
        assertEquals("12", printer.format(midnight));
        assertEquals("12", printer.format(noon));
        assertEquals("1", printer.format(oneAm));
    }

    @Test
    void testTwentyFourHourFieldMidnightBoundary() {
        final FastDatePrinter printer = newPrinter("k");
        final Calendar midnight = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar elevenPm = utcCalendar(2020, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertEquals("24", printer.format(midnight));
        assertEquals("23", printer.format(elevenPm));
    }

    @Test
    void testDayInWeekFieldSundayWrapsToSeven() {
        final FastDatePrinter printer = newPrinter("u");
        // 2024-01-07 is a Sunday, 2024-01-08 is a Monday
        final Calendar sunday = utcCalendar(2024, Calendar.JANUARY, 7, 0, 0, 0, 0);
        final Calendar monday = utcCalendar(2024, Calendar.JANUARY, 8, 0, 0, 0, 0);
        assertEquals(Calendar.SUNDAY, sunday.get(Calendar.DAY_OF_WEEK));
        assertEquals("7", printer.format(sunday));
        assertEquals("1", printer.format(monday));
    }

    @Test
    void testWeekYearMatchesCalendarComputation() {
        final FastDatePrinter printer = newPrinter("YYYY");
        // 2017-01-01 is a Sunday; under ISO week rules (Locale.UK) it belongs to the previous week year.
        final Calendar cal = new GregorianCalendar(UTC, Locale.UK);
        cal.clear();
        cal.set(2017, Calendar.JANUARY, 1, 0, 0, 0);
        final int expectedWeekYear = cal.isWeekDateSupported() ? cal.getWeekYear() : cal.get(Calendar.YEAR);
        assertEquals(String.valueOf(expectedWeekYear), printer.format(cal));
        assertNotEquals(cal.get(Calendar.YEAR), expectedWeekYear);
    }

    @Test
    void testTwoDigitYearWraps() {
        final FastDatePrinter printer = newPrinter("yy");
        assertEquals("05", printer.format(utcCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("99", printer.format(utcCalendar(1999, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("00", printer.format(utcCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    void testPaddedYearBeyondFourDigits() {
        final FastDatePrinter printer = newPrinter("yyyy");
        assertEquals("0005", printer.format(utcCalendar(5, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("12345", printer.format(utcCalendar(12345, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    void testUnpaddedDayOfYearField() {
        final FastDatePrinter printer = newPrinter("D");
        assertEquals("5", printer.format(utcCalendar(2021, Calendar.JANUARY, 5, 0, 0, 0, 0)));
        assertEquals("50", printer.format(utcCalendar(2021, Calendar.FEBRUARY, 19, 0, 0, 0, 0)));
        assertEquals("300", printer.format(utcCalendar(2021, Calendar.OCTOBER, 27, 0, 0, 0, 0)));
    }

    @Test
    void testTwoDigitFieldDoesNotTruncateValuesAboveNinetyNine() {
        final FastDatePrinter printer = newPrinter("DD");
        assertEquals("05", printer.format(utcCalendar(2021, Calendar.JANUARY, 5, 0, 0, 0, 0)));
        assertEquals("300", printer.format(utcCalendar(2021, Calendar.OCTOBER, 27, 0, 0, 0, 0)));
    }

    @Test
    void testMonthTextAndNumberVariants() {
        final Calendar may = utcCalendar(2021, Calendar.MAY, 1, 0, 0, 0, 0);
        assertEquals("5", newPrinter("M").format(may));
        assertEquals("05", newPrinter("MM").format(may));
        assertEquals("May", newPrinter("MMM").format(may));
        assertEquals("May", newPrinter("MMMM").format(may));
    }

    @Test
    void testWeekdayTextVariants() {
        // 2021-05-03 is a Monday
        final Calendar monday = utcCalendar(2021, Calendar.MAY, 3, 0, 0, 0, 0);
        assertEquals("Mon", newPrinter("EEE").format(monday));
        assertEquals("Monday", newPrinter("EEEE").format(monday));
    }

    @Test
    void testQuotedLiteralsAndEscapedQuote() {
        final Calendar cal = utcCalendar(2021, Calendar.MAY, 3, 0, 0, 0, 0);
        assertEquals("2021-T-05", newPrinter("yyyy-'T'-MM").format(cal));
        assertEquals("it's 2021", newPrinter("'it''s' yyyy").format(cal));
    }

    @Test
    void testCalendarFormatUsesPrinterTimeZoneNotCalendarTimeZone() {
        final TimeZone plusFive = new SimpleTimeZone(5 * 60 * 60 * 1000, "PLUS_FIVE");
        final FastDatePrinter printer = newPrinter("HH:mm", plusFive);

        final Calendar utcCal = utcCalendar(2021, Calendar.JANUARY, 1, 10, 0, 0, 0);
        // The printer's own time zone (+05:00) must be used, shifting 10:00 UTC to 15:00.
        assertEquals("15:00", printer.format(utcCal));
        // The original Calendar instance passed in must not be mutated.
        assertEquals(UTC, utcCal.getTimeZone());
    }

    @Test
    void testDeprecatedCalendarStringBufferFormatIgnoresCalendarTimeZone() {
        final TimeZone plusFive = new SimpleTimeZone(5 * 60 * 60 * 1000, "PLUS_FIVE");
        final FastDatePrinter printer = newPrinter("HH:mm", plusFive);
        final Calendar utcCal = utcCalendar(2021, Calendar.JANUARY, 1, 10, 0, 0, 0);

        final StringBuffer buf = new StringBuffer();
        final StringBuffer result = printer.format(utcCal, buf);
        assertEquals("15:00", result.toString());
        assertTrue(result == buf);
    }

    @Test
    void testFormatWithAppendableAndStringBufferOverloads() {
        final FastDatePrinter printer = newPrinter("yyyy/MM/dd");
        final Date date = utcCalendar(2022, Calendar.DECEMBER, 25, 0, 0, 0, 0).getTime();

        final StringBuilder sb = new StringBuilder();
        assertEquals("2022/12/25", printer.format(date, sb).toString());

        final StringBuffer buf = new StringBuffer();
        assertEquals("2022/12/25", printer.format(date, buf).toString());

        final StringBuffer millisBuf = new StringBuffer();
        assertEquals("2022/12/25", printer.format(date.getTime(), millisBuf).toString());

        final StringBuilder millisSb = new StringBuilder();
        assertEquals("2022/12/25", printer.format(date.getTime(), millisSb).toString());
    }

    @Test
    void testFormatObjectDispatchesByType() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Date date = utcCalendar(2022, Calendar.JANUARY, 2, 0, 0, 0, 0).getTime();
        final Calendar cal = utcCalendar(2022, Calendar.JANUARY, 2, 0, 0, 0, 0);

        assertEquals("2022-01-02", printer.format((Object) date));
        assertEquals("2022-01-02", printer.format((Object) cal));
        assertEquals("2022-01-02", printer.format((Object) Long.valueOf(date.getTime())));
    }

    @Test
    void testFormatObjectRejectsUnsupportedType() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
    }

    @Test
    void testDeprecatedFieldPositionFormatRejectsUnsupportedType() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final StringBuffer buf = new StringBuffer();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                printer.format((Object) Double.valueOf(3.14), buf, new FieldPosition(0));
            }
        });
    }

    @Test
    void testDeprecatedFieldPositionFormatHandlesAllSupportedTypes() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Date date = utcCalendar(2022, Calendar.JANUARY, 2, 0, 0, 0, 0).getTime();
        final Calendar cal = utcCalendar(2022, Calendar.JANUARY, 2, 0, 0, 0, 0);
        final FieldPosition pos = new FieldPosition(0);

        assertEquals("2022-01-02", printer.format((Object) date, new StringBuffer(), pos).toString());
        assertEquals("2022-01-02", printer.format((Object) cal, new StringBuffer(), pos).toString());
        assertEquals("2022-01-02", printer.format((Object) Long.valueOf(date.getTime()), new StringBuffer(), pos).toString());
    }

    @Test
    void testGettersReflectConstructorArguments() {
        final TimeZone plusFive = new SimpleTimeZone(5 * 60 * 60 * 1000, "PLUS_FIVE");
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", plusFive, Locale.GERMANY);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(plusFive, printer.getTimeZone());
        assertEquals(Locale.GERMANY, printer.getLocale());
        assertTrue(printer.getMaxLengthEstimate() > 0);
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter a = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter b = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter differentPattern = new FastDatePrinter("MM/dd/yyyy", UTC, Locale.US);
        final FastDatePrinter differentZone = new FastDatePrinter("yyyy-MM-dd",
                TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDatePrinter differentLocale = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.GERMANY);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, differentPattern);
        assertNotEquals(a, differentZone);
        assertNotEquals(a, differentLocale);
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final String str = printer.toString();
        assertTrue(str.contains("yyyy"));
        assertTrue(str.contains(UTC.getID()));
        assertTrue(str.startsWith("FastDatePrinter["));
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullLocaleDefaultsToSystemLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, null);
        assertNotNull(printer.getLocale());
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testNullTimeZoneConstructsButFailsOnUse() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", null, Locale.US);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                printer.toString();
            }
        });
    }

    @Test
    void testSerializationRoundTripReproducesFormatting() throws Exception {
        final FastDatePrinter original = newPrinter("yyyy-MM-dd'T'HH:mm:ss");
        final Calendar cal = utcCalendar(2023, Calendar.SEPTEMBER, 9, 8, 7, 6, 0);
        final String expected = original.format(cal);

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        assertEquals(expected, deserialized.format(cal));
        assertEquals(original.getMaxLengthEstimate(), deserialized.getMaxLengthEstimate());
    }

    @Test
    void testParseTokenGroupsRepeatedLetters() {
        final FastDatePrinter printer = newPrinter("yyyy");
        final int[] indexRef = {0};
        final String token = printer.parseToken("yyyy-MM", indexRef);
        assertEquals("yyyy", token);
        assertEquals(3, indexRef[0]);
    }

    @Test
    void testParseTokenHandlesLiteralWithEscapedQuote() {
        final FastDatePrinter printer = newPrinter("yyyy");
        final int[] indexRef = {0};
        final String token = printer.parseToken("'it''s'yyyy", indexRef);
        assertEquals("'it's", token);
    }

    @Test
    void testThreeLetterYearPatternPadsToFourDigits() {
        final FastDatePrinter printer = newPrinter("yyy");
        final Calendar cal = utcCalendar(7, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("0007", printer.format(cal));
    }

    @Test
    void testGetTimeZoneDisplayUsesTimeZoneDisplayName() {
        final String standard = FastDatePrinter.getTimeZoneDisplay(UTC, false, TimeZone.SHORT, Locale.US);
        assertEquals(UTC.getDisplayName(false, TimeZone.SHORT, Locale.US), standard);
    }

    @Test
    void testClearDoesNotBreakSubsequentFormatting() {
        final FastDatePrinter printer = newPrinter("z", UTC);
        final Calendar cal = utcCalendar(2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final String before = printer.format(cal);
        FastDatePrinter.clear();
        final String after = printer.format(cal);
        assertEquals(before, after);
    }
}
