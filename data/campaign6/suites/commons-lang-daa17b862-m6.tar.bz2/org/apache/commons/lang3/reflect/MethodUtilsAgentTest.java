/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MethodUtils}.
 */
class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface AgentAnnotation {
    }

    public interface AgentIFace {
        void overloaded(Number n);
    }

    public static class AgentBase implements AgentIFace {
        @Override
        public void overloaded(final Number n) {
            // no-op
        }
    }

    public static class AgentDerived extends AgentBase {
        public void overloaded(final Integer n) {
            // no-op
        }
    }

    public static class AgentAmbiguous {
        public void over(final Comparable<?> c) {
            // no-op
        }

        public void over(final Number n) {
            // no-op
        }
    }

    public static class AgentFoo {

        public static int staticAdd(final int a, final int b) {
            return a + b;
        }

        public static String staticVarArgs(final String separator, final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    sb.append(separator);
                }
                sb.append(parts[i]);
            }
            return sb.toString();
        }

        @AgentAnnotation
        public void annotated() {
            // no-op
        }

        public int add(final int a, final int b) {
            return a + b;
        }

        public void explode() {
            throw new IllegalStateException("boom");
        }

        public void noArgs() {
            // no-op
        }

        private int secret() {
            return 42;
        }
    }

    @Test
    void testGetAccessibleMethodClassMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(AgentFoo.class, (Method) null));
    }

    @Test
    void testGetAccessibleMethodClassStringClassesFound() {
        final Method method = MethodUtils.getAccessibleMethod(AgentFoo.class, "add", int.class, int.class);
        assertNotNull(method);
        assertEquals("add", method.getName());
    }

    @Test
    void testGetAccessibleMethodClassStringClassesNotFoundReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testGetAccessibleMethodMethodNullReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    void testGetAccessibleMethodMethodReturnsSameForPublicClass() throws NoSuchMethodException {
        final Method method = AgentFoo.class.getMethod("add", int.class, int.class);
        assertEquals(method, MethodUtils.getAccessibleMethod(method));
    }

    @Test
    void testGetAnnotationAbsentReturnsNull() throws NoSuchMethodException {
        final Method method = AgentFoo.class.getMethod("add", int.class, int.class);
        assertNull(MethodUtils.getAnnotation(method, AgentAnnotation.class, true, true));
    }

    @Test
    void testGetAnnotationNullAnnotationClassThrowsNpe() throws NoSuchMethodException {
        final Method method = AgentFoo.class.getMethod("annotated");
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(method, null, true, true));
    }

    @Test
    void testGetAnnotationNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, AgentAnnotation.class, true, true));
    }

    @Test
    void testGetAnnotationPresent() throws NoSuchMethodException {
        final Method method = AgentFoo.class.getMethod("annotated");
        final AgentAnnotation annotation = MethodUtils.getAnnotation(method, AgentAnnotation.class, true, true);
        assertNotNull(annotation);
    }

    @Test
    void testGetMatchingAccessibleMethodExactMatch() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(AgentFoo.class, "add", int.class, int.class);
        assertNotNull(method);
        assertEquals("add", method.getName());
    }

    @Test
    void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(AgentFoo.class, "add", String.class, String.class));
    }

    @Test
    void testGetMatchingAccessibleMethodWithAssignableParameter() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(AgentFoo.class, "add", Integer.class, Integer.class);
        assertNotNull(method);
        assertEquals("add", method.getName());
    }

    @Test
    void testGetMatchingMethodAmbiguousThrowsIllegalStateException() {
        assertThrows(IllegalStateException.class, () -> MethodUtils.getMatchingMethod(AgentAmbiguous.class, "over", Short.class));
    }

    @Test
    void testGetMatchingMethodEmptyMethodNameThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(AgentFoo.class, ""));
    }

    @Test
    void testGetMatchingMethodExactMatch() {
        final Method method = MethodUtils.getMatchingMethod(AgentFoo.class, "add", int.class, int.class);
        assertNotNull(method);
        assertEquals("add", method.getName());
    }

    @Test
    void testGetMatchingMethodNoSuchMethodReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testGetMatchingMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "add", int.class, int.class));
    }

    @Test
    void testGetMethodObjectNoSuchMethodReturnsNull() {
        assertNull(MethodUtils.getMethodObject(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testGetMethodObjectNullArgumentsReturnNull() {
        assertNull(MethodUtils.getMethodObject(null, "add", int.class, int.class));
        assertNull(MethodUtils.getMethodObject(AgentFoo.class, null));
    }

    @Test
    void testGetMethodObjectReturnsMethod() {
        final Method method = MethodUtils.getMethodObject(AgentFoo.class, "add", int.class, int.class);
        assertNotNull(method);
        assertEquals("add", method.getName());
    }

    @Test
    void testGetMethodsListWithAnnotationFindsAnnotatedMethod() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentFoo.class, AgentAnnotation.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    void testGetMethodsListWithAnnotationNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(AgentFoo.class, null));
    }

    @Test
    void testGetMethodsListWithAnnotationNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, AgentAnnotation.class));
    }

    @Test
    void testGetMethodsWithAnnotationNoneFound() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(String.class, AgentAnnotation.class);
        assertEquals(0, methods.length);
    }

    @Test
    void testGetMethodsWithAnnotationReturnsArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentFoo.class, AgentAnnotation.class);
        assertEquals(1, methods.length);
        assertEquals("annotated", methods[0].getName());
    }

    @Test
    void testGetOverrideHierarchyIncludesAllOverriddenMethods() throws NoSuchMethodException {
        final Method method = AgentDerived.class.getMethod("overloaded", Integer.class);
        final java.util.Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, org.apache.commons.lang3.ClassUtils.Interfaces.INCLUDE);
        assertTrue(hierarchy.contains(method));
        assertEquals(1, hierarchy.size());
    }

    @Test
    void testGetOverrideHierarchyNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class,
                () -> MethodUtils.getOverrideHierarchy(null, org.apache.commons.lang3.ClassUtils.Interfaces.INCLUDE));
    }

    @Test
    void testInvokeExactMethodNoArgs() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertNull(MethodUtils.invokeExactMethod(foo, "noArgs"));
    }

    @Test
    void testInvokeExactMethodNoSuchMethodThrows() {
        final AgentFoo foo = new AgentFoo();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(foo, "doesNotExist"));
    }

    @Test
    void testInvokeExactMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeExactMethod(null, "noArgs"));
    }

    @Test
    void testInvokeExactMethodWithArgs() throws Exception {
        final AgentFoo foo = new AgentFoo();
        final Object result = MethodUtils.invokeExactMethod(foo, "add", new Object[] { Integer.valueOf(2), Integer.valueOf(3) },
                new Class<?>[] { int.class, int.class });
        assertEquals(5, result);
    }

    @Test
    void testInvokeExactStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactStaticMethod(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testInvokeExactStaticMethodWithArgs() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(AgentFoo.class, "staticAdd", new Object[] { Integer.valueOf(4), Integer.valueOf(6) },
                new Class<?>[] { int.class, int.class });
        assertEquals(10, result);
    }

    @Test
    void testInvokeMethodForceAccessFalseOnPrivateMethodThrows() {
        final AgentFoo foo = new AgentFoo();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(foo, false, "secret"));
    }

    @Test
    void testInvokeMethodForceAccessTrueOnPrivateMethod() throws Exception {
        final AgentFoo foo = new AgentFoo();
        final Object result = MethodUtils.invokeMethod(foo, true, "secret");
        assertEquals(42, result);
    }

    @Test
    void testInvokeMethodNoArgsConvenience() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertNull(MethodUtils.invokeMethod(foo, "noArgs"));
    }

    @Test
    void testInvokeMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "noArgs"));
    }

    @Test
    void testInvokeMethodVarArgsCanonicalization() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(AgentFoo.class, "staticVarArgs", "-", "a", "b", "c");
        assertEquals("a-b-c", result);
    }

    @Test
    void testInvokeMethodWithArgsAndParameterTypes() throws Exception {
        final AgentFoo foo = new AgentFoo();
        final Object result = MethodUtils.invokeMethod(foo, "add", new Object[] { Integer.valueOf(7), Integer.valueOf(8) },
                new Class<?>[] { int.class, int.class });
        assertEquals(15, result);
    }

    @Test
    void testInvokeMethodWrapsThrownExceptionInInvocationTargetException() {
        final AgentFoo foo = new AgentFoo();
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, () -> MethodUtils.invokeMethod(foo, "explode"));
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testInvokeStaticMethodWithArgs() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(AgentFoo.class, "staticAdd", Integer.valueOf(1), Integer.valueOf(2));
        assertEquals(3, result);
    }

    @Test
    void testPublicConstructorIsAvailable() {
        assertNotNull(new MethodUtils());
    }

    @Test
    void testVarArgsExactArrayPassthrough() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(AgentFoo.class, "staticVarArgs",
                new Object[] { "-", new String[] { "x", "y" } }, new Class<?>[] { String.class, String[].class });
        assertEquals("x-y", result);
        assertArrayEquals(new String[] { "x", "y" }, new String[] { "x", "y" });
    }
}
