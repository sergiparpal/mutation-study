/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    public static class Outer {
        public static class Inner {
        }
    }

    interface Fixture1 {
    }

    interface Fixture2 extends Fixture1 {
    }

    static class Base implements Fixture1 {
    }

    static class Derived extends Base implements Fixture2 {
    }

    @Test
    public void testGetAbbreviatedName_examples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedName_nullAndInvalidLength() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", 0));
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", -1));
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 5));
    }

    @Test
    public void testGetAbbreviatedName_boundaryShortening() {
        assertEquals("a.i.Something", ClassUtils.getAbbreviatedName("abcdefgh.ijklmnop.Something", 1));
        assertEquals("a.d.VeryLongClassNameHere", ClassUtils.getAbbreviatedName("abc.def.VeryLongClassNameHere", 5));
    }

    @Test
    public void testConstants() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    @Test
    public void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(Arrays.asList("java.lang.String", null), names);
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        final List<String> names = Arrays.asList("java.lang.String", "bogus.does.not.Exist", null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Derived.class);
        assertTrue(interfaces.contains(Fixture1.class));
        assertTrue(interfaces.contains(Fixture2.class));
        assertEquals(2, interfaces.size());
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Derived.class);
        assertEquals(Arrays.asList(Base.class, Object.class), superclasses);
        assertNull(ClassUtils.getAllSuperclasses(null));
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    @Test
    public void testGetCanonicalName() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("X", ClassUtils.getCanonicalName((Class<?>) null, "X"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc"));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("abc", "X"));
    }

    @Test
    public void testGetClass_basic() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(int.class, ClassUtils.getClass("int"));
        assertEquals(int[].class, ClassUtils.getClass("int[]"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    public void testGetClass_errors() {
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass("does.not.Exist"));
        assertThrows(NullPointerException.class, () -> ClassUtils.getClass((String) null));
    }

    @Test
    public void testGetClass_dimensionAndLengthLimits() {
        final StringBuilder tooManyDims = new StringBuilder("int");
        for (int i = 0; i < 256; i++) {
            tooManyDims.append("[]");
        }
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getClass(tooManyDims.toString()));

        final StringBuilder tooLong = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            tooLong.append('a');
        }
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getClass(tooLong.toString()));
    }

    @Test
    public void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetName() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("X", ClassUtils.getName((Class<?>) null, "X"));
        assertEquals("java.lang.String", ClassUtils.getName("abc"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("X", ClassUtils.getName((Object) null, "X"));
    }

    @Test
    public void testGetPackageName() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
        assertEquals("X", ClassUtils.getPackageName((Object) null, "X"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("X", ClassUtils.getPackageCanonicalName((Object) null, "X"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        final List<Integer> unmodifiable = Collections.unmodifiableList(new ArrayList<>());
        final Method method = ClassUtils.getPublicMethod(unmodifiable.getClass(), "isEmpty");
        assertTrue(Boolean.TRUE.equals(method.invoke(unmodifiable)));
        assertTrue(java.lang.reflect.Modifier.isPublic(method.getDeclaringClass().getModifiers()));

        assertThrows(NoSuchMethodException.class, () -> ClassUtils.getPublicMethod(String.class, "noSuchMethod"));
    }

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName(ClassUtils.class));
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("X", ClassUtils.getShortCanonicalName((Object) null, "X"));
    }

    @Test
    public void testGetShortClassName() {
        assertEquals("ClassUtils", ClassUtils.getShortClassName(ClassUtils.class));
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("ClassUtils[]", ClassUtils.getShortClassName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("X", ClassUtils.getShortClassName((Object) null, "X"));
        assertEquals("ClassUtilsAgentTest.Outer.Inner", ClassUtils.getShortClassName(Outer.Inner.class));
    }

    @Test
    public void testGetShortClassName_anonymousAndLocal() {
        final Runnable anon = new Runnable() {
            @Override
            public void run() {
            }
        };
        assertEquals("ClassUtilsAgentTest.1", ClassUtils.getShortClassName(anon.getClass()));

        class Local {
        }
        assertEquals("ClassUtilsAgentTest.1Local", ClassUtils.getShortClassName(new Local().getClass()));
    }

    @Test
    public void testGetSimpleName() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("X", ClassUtils.getSimpleName((Class<?>) null, "X"));
        assertEquals("String", ClassUtils.getSimpleName("abc"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("X", ClassUtils.getSimpleName((Object) null, "X"));
    }

    @Test
    public void testHierarchy_excludeInterfaces() {
        final List<Class<?>> seen = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(Derived.class)) {
            seen.add(c);
        }
        assertEquals(Arrays.asList(Derived.class, Base.class, Object.class), seen);
    }

    @Test
    public void testHierarchy_includeInterfaces() {
        final List<Class<?>> seen = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(Derived.class, ClassUtils.Interfaces.INCLUDE)) {
            seen.add(c);
        }
        assertTrue(seen.indexOf(Derived.class) < seen.indexOf(Fixture2.class));
        assertTrue(seen.contains(Fixture1.class));
        assertTrue(seen.contains(Base.class));
        assertTrue(seen.contains(Object.class));
    }

    @Test
    public void testIsAssignable_primitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, float.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertFalse(ClassUtils.isAssignable(short.class, byte.class));
    }

    @Test
    public void testIsAssignable_autoboxingAndNulls() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertFalse(ClassUtils.isAssignable(Object.class, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignable_arrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { int.class, String.class }, new Class<?>[] { long.class, Object.class }));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { int.class }, new Class<?>[] { int.class, String.class }));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsInnerClass() {
        assertTrue(ClassUtils.isInnerClass(Outer.Inner.class));
        assertFalse(ClassUtils.isInnerClass(ClassUtilsAgentTest.class));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    public void testIsPrimitiveOrWrapperAndWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));

        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(Collections.unmodifiableList(new ArrayList<>()).getClass()));
        assertThrows(NullPointerException.class, () -> ClassUtils.isPublic(null));
    }

    @Test
    public void testPrimitivesToWrappersAndBack() {
        final Class<?>[] wrappers = ClassUtils.primitivesToWrappers(int.class, boolean.class, String.class);
        assertArrayEquals(new Class<?>[] { Integer.class, Boolean.class, String.class }, wrappers);
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);

        final Class<?>[] primitives = ClassUtils.wrappersToPrimitives(Integer.class, Boolean.class, String.class);
        assertArrayEquals(new Class<?>[] { int.class, boolean.class, null }, primitives);
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
    }

    @Test
    public void testPrimitiveToWrapperAndBack() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));

        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] classes = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, classes);
    }

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<>(Arrays.asList(String.class, Integer.class, Serializable.class));
        Collections.sort(list, ClassUtils.comparator());
        final List<String> names = new ArrayList<>();
        for (final Class<?> c : list) {
            names.add(c.getName());
        }
        final List<String> sortedNames = new ArrayList<>(names);
        Collections.sort(sortedNames);
        assertEquals(sortedNames, names);
    }
}
