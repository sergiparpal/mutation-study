/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link DurationFormatUtils}.
 */
public class DurationFormatUtilsAgentTest {

    private static Calendar utcCalendar(final int year, final int month, final int day, final int hour, final int minute, final int second,
            final int millis) {
        final Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    // -- formatDuration ------------------------------------------------

    @Test
    public void testFormatDurationZeroPadded() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
    }

    @Test
    public void testFormatDurationHMSCarriesOverFields() {
        // 1h 1m 1s 1ms
        final long millis = 3600000L + 60000L + 1000L + 1L;
        assertEquals("01:01:01.001", DurationFormatUtils.formatDurationHMS(millis));
    }

    @Test
    public void testFormatDurationWithDayToken() {
        // 1 day, 2 hours, 3 minutes, 4 seconds
        final long millis = 86400000L + 2L * 3600000L + 3L * 60000L + 4L * 1000L;
        assertEquals("1d 02:03:04", DurationFormatUtils.formatDuration(millis, "d'd 'HH:mm:ss"));
    }

    @Test
    public void testFormatDurationNoPadding() {
        final long millis = 3600000L + 60000L + 1000L + 1L;
        assertEquals("1:1:1.001", DurationFormatUtils.formatDuration(millis, "H:m:s.S", false));
    }

    @Test
    public void testFormatDurationLiteralText() {
        assertEquals("literal", DurationFormatUtils.formatDuration(0L, "'literal'"));
    }

    @Test
    public void testFormatDurationEscapedApostropheInsideLiteral() {
        assertEquals("it's", DurationFormatUtils.formatDuration(0L, "'it''s'"));
    }

    @Test
    public void testFormatDurationNegativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "HH:mm:ss");
            }
        });
        assertTrue(ex.getMessage().contains("durationMillis"));
    }

    @Test
    public void testFormatDurationZeroDoesNotThrow() {
        assertEquals("00:00:00", DurationFormatUtils.formatDuration(0L, "HH:mm:ss"));
    }

    @Test
    public void testFormatDurationSecondsMillisecondCarryUsesThreeDigitWidth() {
        // when a seconds token is immediately followed by a milliseconds token,
        // at least 3 digits must be used for the milliseconds even without padding requested
        assertEquals("1.000", DurationFormatUtils.formatDuration(1000L, "s.SSS", false));
    }

    // -- error cases in the pattern lexer --------------------------------

    @Test
    public void testFormatDurationUnterminatedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "'unterminated");
            }
        });
    }

    @Test
    public void testFormatDurationNestedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "[[d]]");
            }
        });
    }

    @Test
    public void testFormatDurationUnopenedOptionalCloseThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "]");
            }
        });
    }

    @Test
    public void testFormatDurationUnmatchedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0L, "[d");
            }
        });
    }

    // -- formatDurationISO ------------------------------------------------

    @Test
    public void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    @Test
    public void testFormatDurationISOOneDay() {
        assertEquals("P0Y0M1DT0H0M0.000S", DurationFormatUtils.formatDurationISO(86400000L));
    }

    // -- formatDurationWords ------------------------------------------------

    @Test
    public void testFormatDurationWordsZeroNoSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0L, false, false));
    }

    @Test
    public void testFormatDurationWordsZeroBothSuppressed() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0L, true, true));
    }

    @Test
    public void testFormatDurationWordsOneDayBothSuppressed() {
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(86400000L, true, true));
    }

    @Test
    public void testFormatDurationWordsOneHourSuppressLeadingOnly() {
        assertEquals("1 hour 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(3600000L, true, false));
    }

    @Test
    public void testFormatDurationWordsOneDaySuppressTrailingOnly() {
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(86400000L, false, true));
    }

    @Test
    public void testFormatDurationWordsTwoDaysThreeHoursBothSuppressed() {
        final long millis = 2L * 86400000L + 3L * 3600000L;
        assertEquals("2 days 3 hours", DurationFormatUtils.formatDurationWords(millis, true, true));
    }

    @Test
    public void testFormatDurationWordsSingularPluralization() {
        // 1 minute 1 second, no suppression: singular forms for the 1-valued fields
        assertEquals("0 days 0 hours 1 minute 1 second", DurationFormatUtils.formatDurationWords(61000L, false, false));
    }

    // -- formatPeriod ------------------------------------------------

    @Test
    public void testFormatPeriodBasicFields() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar start = utcCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar end = utcCalendar(2000, Calendar.MARCH, 10, 5, 6, 7, 8);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(),
                "yyyy-MM-dd'T'HH:mm:ss.SSS", true, tz);
        assertEquals("0000-02-09T05:06:07.008", result);
    }

    @Test
    public void testFormatPeriodEqualStartAndEndIsAllZero() {
        assertEquals("00:00:00", DurationFormatUtils.formatPeriod(5000L, 5000L, "HH:mm:ss"));
    }

    @Test
    public void testFormatPeriodStartGreaterThanEndThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(10L, 5L, "HH:mm:ss");
            }
        });
        assertTrue(ex.getMessage().contains("startMillis"));
    }

    @Test
    public void testFormatPeriodWithoutDayTokenRollsDaysIntoHours() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        // 2 days and 5 hours apart, with no 'd' token hours must include the full elapsed time
        final Calendar start = utcCalendar(2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar end = utcCalendar(2021, Calendar.JANUARY, 3, 5, 0, 0, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "H:mm", true, tz);
        assertEquals("53:00", result);
    }

    @Test
    public void testFormatPeriodISOOneDay() {
        assertEquals("P0Y0M1DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(0L, 86400000L));
    }

    /**
     * The class Javadoc states that between January 15th and March 10th the correct split is
     * "1 month and 23 days", obtained by advancing January-&gt;February (1 month) and then counting
     * forward from February 15th to March 10th (23 days) -- and explicitly NOT 26 days, the value
     * obtained by counting backward from March. This asserts the documented contract.
     */
    @Test
    public void testFormatPeriodMonthsAreCalculatedFirstPerJavadocExample() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar start = utcCalendar(2023, Calendar.JANUARY, 15, 0, 0, 0, 0);
        final Calendar end = utcCalendar(2023, Calendar.MARCH, 10, 0, 0, 0, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "M'M 'd'D'", true, tz);
        assertEquals("1M 23D", result);
    }

    // -- optional block examples from the class Javadoc ------------------------------------------------

    @Test
    public void testFixedWidthFieldsExample() {
        final String pattern = "d'd'H'h'm'm's's'";
        assertEquals("1d0h0m0s", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("0d1h0m0s", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("0d0h1m0s", DurationFormatUtils.formatDuration(60000L, pattern));
        assertEquals("0d0h0m0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testOptionalBlockWithLiteralsExample() {
        final String pattern = "d'd'[H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(60000L, pattern));
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testOptionalBlockSuppressesLiteralsWhenZeroExample() {
        final String pattern = "[d'd'H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("1h0s", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("1m0s", DurationFormatUtils.formatDuration(60000L, pattern));
        assertEquals("0s", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testOptionalBlockWithLeadingLiteralOnlyPrintedWhenFollowingFieldNonZeroExample() {
        final String pattern = "['{'d'}']HH':'mm";
        assertEquals("{1}00:00", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("01:00", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("00:01", DurationFormatUtils.formatDuration(60000L, pattern));
        assertEquals("00:00", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testOptionalBlockEntirelyOptionalCanBeEmptyExample() {
        final String pattern = "[d'd'H'h'm'm's's']";
        assertEquals("1d", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("1h", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("1m", DurationFormatUtils.formatDuration(60000L, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testMultipleOptionalBlocksChooseFirstNonZeroExample() {
        final String pattern = "['{'dd'}']['<'HH'>']['('mm')']";
        assertEquals("{01}", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("<01>", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    @Test
    public void testOptionalBlockWithoutLiteralsExample() {
        final String pattern = "[dHms]";
        assertEquals("1", DurationFormatUtils.formatDuration(86400000L, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(3600000L, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(60000L, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(0L, pattern));
    }

    // -- lexx / Token (package-private internals) ------------------------------------------------

    @Test
    public void testLexxGroupsRepeatedTokenCharacters() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyyMM");
        assertEquals(2, tokens.length);
        assertEquals(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
        assertEquals(DurationFormatUtils.M, tokens[1].getValue());
        assertEquals(2, tokens[1].getCount());
    }

    /**
     * Two occurrences of the same token character separated by literal text are two distinct
     * fields (e.g. "day of month - day of month"), not one field whose width is the sum of both
     * occurrences. The literal text between them must also be preserved in its original position.
     */
    @Test
    public void testLexxDoesNotMergeTokensSeparatedByLiteralText() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d-d");
        assertEquals(3, tokens.length);
        assertEquals(DurationFormatUtils.d, tokens[0].getValue());
        assertEquals("-", tokens[1].getValue().toString());
        assertEquals(DurationFormatUtils.d, tokens[2].getValue());
    }

    /**
     * Same bug as above, observed through the public formatDuration API: "d-d" applied to a
     * 5 day duration should render as "5-5", not swallow the second field and misplace the
     * separator.
     */
    @Test
    public void testFormatDurationDoesNotMergeFieldsSeparatedByLiteralText() {
        assertEquals("5-5", DurationFormatUtils.formatDuration(5L * 86400000L, "d-d"));
    }

    @Test
    public void testTokenToStringRepeatsValueByCount() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyy");
        assertEquals(1, tokens.length);
        assertEquals("yyy", tokens[0].toString());
    }

    @Test
    public void testTokenContainsTokenWithValue() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("HH:mm");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.m));
        assertTrue(!DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.s));
    }
}
