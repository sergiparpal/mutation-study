/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" \t\n"));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" a "));

        assertFalse(StringUtils.isNotBlank(null));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
    }

    @Test
    void testEqualsAndEqualsIgnoreCase() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abd"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
    }

    @Test
    void testCompareAndCompareIgnoreCase() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertEquals(0, StringUtils.compare("a", "a"));

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.compareIgnoreCase("abc", "abd") < 0);
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertFalse(StringUtils.contains(null, (int) 'a'));
        assertTrue(StringUtils.contains("abc", (int) 'b'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));

        assertTrue(StringUtils.containsAny("abc", 'a', 'z'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'y'));
        assertFalse(StringUtils.containsAny(null, 'a'));

        assertTrue(StringUtils.containsWhitespace("a b"));
        assertFalse(StringUtils.containsWhitespace("ab"));
        assertFalse(StringUtils.containsWhitespace(""));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'x', 'y', 'c'));

        assertTrue(StringUtils.containsOnly("aabbcc", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("aabbccd", 'a', 'b', 'c'));
    }

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));

        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));

        assertEquals(0, StringUtils.ordinalIndexOf("ababab", "aba", 1));
        assertEquals(2, StringUtils.ordinalIndexOf("ababab", "aba", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("ababab", "aba", 3));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", new char[0]));

        assertEquals(2, StringUtils.indexOfAnyBut("zzabyycdxx", 'z'));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertTrue(StringUtils.endsWith(null, null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));

        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "qrs"));
        assertFalse(StringUtils.startsWithAny(null, "abc"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertEquals("cd", StringUtils.substring("abcde", 2, 4));
        assertEquals("abc", StringUtils.substring("abcde", 0, 3));
        assertEquals("", StringUtils.substring("abcde", 4, 2));

        assertEquals("a", StringUtils.substringBefore("abcbacba", "b"));
        assertEquals("abcbacba", StringUtils.substringBefore("abcbacba", "x"));
        assertEquals("cbacba", StringUtils.substringAfter("abcbacba", "b"));
        assertEquals("", StringUtils.substringAfter("abcbacba", "x"));

        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));

        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertNull(StringUtils.substringBetween("abc", "(", ")"));
        assertEquals("abc", StringUtils.substringBetween("yabcz", "y", "z"));
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
    }

    @Test
    void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new String[] {"a", "b", "c"}, ','));
        assertEquals("abc", StringUtils.join(new String[] {"a", "b", "c"}, null));
        assertEquals("a,,c", StringUtils.join(new String[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-", 1, 3));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("1", StringUtils.join(new int[] {1, 2, 3}, ',', 0, 1));
    }

    @Test
    void testSplit() {
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertNull(StringUtils.split((String) null));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", "."));

        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.splitByWholeSeparator("a..b.c", "."));
        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.splitByWholeSeparator("abXcd", "X"));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("foobarfoo", StringUtils.replace("fooAfoo", "A", "bar"));
        assertEquals("barbarbar", StringUtils.replace("aaa", "a", "bar"));
        assertEquals("baraa", StringUtils.replace("aaa", "a", "bar", 1));
        assertEquals("barba", StringUtils.replaceOnce("aba", "a", "bar"));
        assertEquals("b", StringUtils.replaceChars("a", 'a', 'b'));
        assertEquals("foo", StringUtils.remove("fooxx", "xx"));
        assertEquals("foo", StringUtils.removeStart("xxfoo", "xx"));
        assertEquals("foo", StringUtils.removeEnd("fooxx", "xx"));
        assertEquals("fobar", StringUtils.removeIgnoreCase("fooBARbar", "oBAR"));
        assertEquals("ooo", StringUtils.remove("fooo", 'f'));
    }

    @Test
    void testPaddingAndCenter() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   abc", StringUtils.leftPad("abc", 6));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertEquals("xxabc", StringUtils.leftPad("abc", 5, 'x'));
        assertEquals("xyxyabc", StringUtils.leftPad("abc", 7, "xy"));

        assertEquals("abc   ", StringUtils.rightPad("abc", 6));
        assertEquals("abcxx", StringUtils.rightPad("abc", 5, 'x'));

        assertEquals("  abc   ", StringUtils.center("abc", 8));
        assertEquals("abc", StringUtils.center("abc", 2));
        assertEquals("xxabcxxx", StringUtils.center("abc", 8, 'x'));
    }

    @Test
    void testCaseConversion() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("Abc", StringUtils.capitalize("abc"));
        assertEquals("abc", StringUtils.uncapitalize("Abc"));
        assertEquals("ABcd", StringUtils.swapCase("abCD"));
        assertEquals("", StringUtils.swapCase(""));
        assertNull(StringUtils.swapCase(null));
    }

    @Test
    void testReverseAndRotate() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
    }

    @Test
    void testRepeatAndCountMatches() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
        assertEquals("", StringUtils.repeat("a", "-", 0));

        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abcdabcd", null));
        assertEquals(2, StringUtils.countMatches("abcdabcd", "ab"));
        assertEquals(4, StringUtils.countMatches("aaaa", "a"));
        assertEquals(0, StringUtils.countMatches("abc", ""));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 0));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 3));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghij", 20));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });

        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("klm", StringUtils.truncate("abcdefghijklmno", 10, 3));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghij", -2, 4);
            }
        });
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));

        assertNull(StringUtils.wrap(null, "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("\"\"ab\"\"", StringUtils.wrap("\"ab\"", "\""));

        assertEquals("ab", StringUtils.unwrap("xabx", 'x'));
        assertEquals("abx", StringUtils.unwrap("abx", 'x'));
        assertEquals("ab", StringUtils.unwrap("\"ab\"", "\""));
    }

    @Test
    void testDefaultIfEmptyOrBlank() {
        assertEquals("default", StringUtils.defaultIfEmpty(null, "default"));
        assertEquals("default", StringUtils.defaultIfEmpty("", "default"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "default"));

        assertEquals("default", StringUtils.defaultIfBlank(null, "default"));
        assertEquals("default", StringUtils.defaultIfBlank("  ", "default"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "default"));

        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("def", StringUtils.defaultString(null, "def"));
    }

    @Test
    void testIsAlphaNumericEtc() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abcXYZ"));
        assertFalse(StringUtils.isAlpha("abc123"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("abc 123"));

        assertTrue(StringUtils.isWhitespace("   "));
        assertTrue(StringUtils.isWhitespace(""));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase(""));

        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));
    }

    @Test
    void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", ""));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));

        assertNull(StringUtils.mid(null, 0, 3));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("b", StringUtils.mid("abc", 1, 1));
        assertEquals("bc", StringUtils.mid("abc", 1, 10));
    }

    @Test
    void testToRootUpperLowerCase() {
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
    }

    @Test
    void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference(null, null));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "a"));
        assertEquals(2, StringUtils.indexOfDifference("ab", "abxyz"));
    }
}
