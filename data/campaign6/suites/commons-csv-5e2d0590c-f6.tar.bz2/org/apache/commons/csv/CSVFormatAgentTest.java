/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    // ---------------------------------------------------------------
    // Predefined formats
    // ---------------------------------------------------------------

    @Test
    void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrailingData());
        assertFalse(format.getLenientEof());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
    }

    @Test
    void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
    }

    @Test
    void testRfc4180FormatProperties() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(",", format.getDelimiterString());
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    void testTdfFormatProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testOracleFormatProperties() {
        final CSVFormat format = CSVFormat.ORACLE;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.getTrim());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    void testPostgresCsvFormatProperties() {
        final CSVFormat format = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", format.getDelimiterString());
        assertNull(format.getEscapeCharacter());
        assertEquals("", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testPostgresTextFormatProperties() {
        final CSVFormat format = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertEquals("\\N", format.getNullString());
    }

    @Test
    void testMongoDbCsvFormatProperties() {
        final CSVFormat format = CSVFormat.MONGODB_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    void testMongoDbTsvFormatProperties() {
        final CSVFormat format = CSVFormat.MONGODB_TSV;
        assertEquals("\t", format.getDelimiterString());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    void testInformixUnloadFormatProperties() {
        final CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals("|", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testInformixUnloadCsvFormatProperties() {
        final CSVFormat format = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testValueOfAndPredefined() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotARealFormat");
            }
        });
    }

    // ---------------------------------------------------------------
    // newFormat
    // ---------------------------------------------------------------

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
    }

    // ---------------------------------------------------------------
    // Builder validation: line breaks
    // ---------------------------------------------------------------

    @Test
    void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter('\n');
            }
        });
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter("");
            }
        });
    }

    @Test
    void testSetDelimiterRejectsStringContainingLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter("a\rb");
            }
        });
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker('\r');
            }
        });
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setEscape('\n');
            }
        });
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setQuote('\n');
            }
        });
    }

    @Test
    void testSetQuoteAcceptsNullToDisable() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    // ---------------------------------------------------------------
    // validate()
    // ---------------------------------------------------------------

    @Test
    void testValidateRejectsQuoteEqualsDelimiter() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter(',').setQuote(',');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testValidateRejectsEscapeEqualsDelimiter() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter(',').setEscape(',');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testValidateRejectsCommentEqualsDelimiter() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter(',').setCommentMarker(',');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testValidateRejectsQuoteEqualsComment() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setQuote('#').setCommentMarker('#');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testValidateRejectsEscapeEqualsComment() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setEscape('#').setCommentMarker('#');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testValidateRejectsQuoteModeNoneWithoutEscape() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setQuoteMode(QuoteMode.NONE);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testValidateAllowsQuoteModeNoneWithEscape() {
        final CSVFormat format = CSVFormat.Builder.create().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    // ---------------------------------------------------------------
    // duplicate header validation
    // ---------------------------------------------------------------

    @Test
    void testDuplicateHeaderDisallowRejectsDuplicates() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "b", "a");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    void testDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "b", "a").get();
        assertArrayEquals(new String[] {"a", "b", "a"}, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyPermitsDuplicateBlanks() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "").get();
        assertArrayEquals(new String[] {"a", "", ""}, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyRejectsDuplicateNonBlanks() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    // ---------------------------------------------------------------
    // header / headerComments copy semantics
    // ---------------------------------------------------------------

    @Test
    void testSetHeaderStoresDefensiveCopy() {
        final String[] original = {"a", "b"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(original).get();
        original[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] gotten = format.getHeader();
        gotten[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testGetHeaderEmptyWhenAutoDetected() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(SampleHeader.class).get();
        assertArrayEquals(new String[] {"NAME", "EMAIL"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testHeaderCommentsConvertedToStrings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("text", Integer.valueOf(5), null).get();
        assertArrayEquals(new String[] {"text", "5", null}, format.getHeaderComments());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("a").get();
        final String[] gotten = format.getHeaderComments();
        gotten[0] = "mutated";
        assertEquals("a", format.getHeaderComments()[0]);
    }

    private enum SampleHeader {
        NAME, EMAIL
    }

    // ---------------------------------------------------------------
    // builder() / copy independence
    // ---------------------------------------------------------------

    @Test
    void testBuilderProducesIndependentCopy() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
    }

    @Test
    void testCopyEqualsOriginalButNotSame() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat copy = original.builder().get();
        assertNotSame(original, copy);
        assertEquals(original, copy);
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    void testEqualsReflexiveAndNullSafe() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(format, format);
        assertNotEquals(null, format);
        assertNotEquals(format, "not a format");
    }

    @Test
    void testEqualsDetectsDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsOnEquivalentSeparatelyBuiltFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("a", "b").setNullString("NULL").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("a", "b").setNullString("NULL").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    // ---------------------------------------------------------------
    // getDelimiter (deprecated) / getDelimiterString
    // ---------------------------------------------------------------

    @Test
    void testGetDelimiterReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
        assertEquals("::", format.getDelimiterString());
    }

    // ---------------------------------------------------------------
    // toString
    // ---------------------------------------------------------------

    @Test
    void testToStringContainsDelimiterAndQuote() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("QuoteChar=<\">"));
    }

    @Test
    void testToStringOmitsUnsetFields() {
        final String s = CSVFormat.newFormat(',').toString();
        assertFalse(s.contains("QuoteChar="));
        assertFalse(s.contains("Escape="));
        assertFalse(s.contains("CommentStart="));
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    @Test
    void testFormatBasicValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    void testFormatEmptyArray() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    // ---------------------------------------------------------------
    // print(Object, Appendable, boolean)
    // ---------------------------------------------------------------

    @Test
    void testPrintNullWithoutNullStringWritesEmpty() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintNullWithNullStringWritesNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testPrintAddsLeadingDelimiterWhenNotNewRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("value", sb, false);
        assertEquals(",value", sb.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        final StringBuilder sb = new StringBuilder();
        format.print("  value  ", sb, true);
        assertEquals("value", sb.toString());
    }

    @Test
    void testPrintEscapesWhenNoQuoteCharacterSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).setEscape('\\').get();
        final StringBuilder sb = new StringBuilder();
        format.print("a,b", sb, true);
        assertEquals("a\\,b", sb.toString());
    }

    // ---------------------------------------------------------------
    // println / printRecord
    // ---------------------------------------------------------------

    @Test
    void testPrintlnWritesRecordSeparatorOnly() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterWhenEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    void testPrintRecordWritesValuesAndSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b");
        assertEquals("a,b\r\n", sb.toString());
    }

    // ---------------------------------------------------------------
    // parse(Reader)
    // ---------------------------------------------------------------

    @Test
    void testParseProducesExpectedRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b\r\nc,d\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---------------------------------------------------------------
    // package-private helpers (same package access)
    // ---------------------------------------------------------------

    @Test
    void testCloneNullIsNull() {
        assertNull(CSVFormat.clone((String[]) null));
    }

    @Test
    void testCloneReturnsIndependentArray() {
        final String[] source = {"x", "y"};
        final String[] cloned = CSVFormat.clone(source);
        assertNotSame(source, cloned);
        assertArrayEquals(source, cloned);
    }

    @Test
    void testToStringArrayNullIsNull() {
        assertNull(CSVFormat.toStringArray(null));
    }

    @Test
    void testToStringArrayConvertsElements() {
        final Object[] values = {Integer.valueOf(1), null, "s"};
        assertArrayEquals(new String[] {"1", null, "s"}, CSVFormat.toStringArray(values));
    }

    @Test
    void testIsBlank() {
        assertTrue(CSVFormat.isBlank(null));
        assertTrue(CSVFormat.isBlank(""));
        assertTrue(CSVFormat.isBlank("   "));
        assertFalse(CSVFormat.isBlank("a"));
    }

    @Test
    void testUseMaxRowsAndUseRowBoundaries() {
        final CSVFormat unlimited = CSVFormat.DEFAULT.builder().setMaxRows(0).get();
        assertFalse(unlimited.useMaxRows());
        assertTrue(unlimited.useRow(1000000));

        final CSVFormat limited = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertTrue(limited.useMaxRows());
        assertEquals(5, limited.getMaxRows());
        assertTrue(limited.useRow(5));
        assertFalse(limited.useRow(6));
    }

    @Test
    void testTrimPackagePrivateHelper() {
        final CSVFormat trimming = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertEquals("abc", trimming.trim("  abc  "));
        final CSVFormat notTrimming = CSVFormat.DEFAULT;
        assertEquals("  abc  ", notTrimming.trim("  abc  "));
    }

    @Test
    void testGetEscapeCharDefaultsToZeroWhenUnset() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        final CSVFormat withEscape = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertEquals('\\', withEscape.getEscapeChar());
    }

    @Test
    void testGetDelimiterCharArray() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertArrayEquals(new char[] {':', ':'}, format.getDelimiterCharArray());
    }

    // ---------------------------------------------------------------
    // deprecated with* methods behave like builder equivalents
    // ---------------------------------------------------------------

    @Test
    void testWithDelimiterProducesEquivalentNewFormat() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter(';');
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", changed.getDelimiterString());
    }

    @Test
    void testWithNullStringProducesEquivalentNewFormat() {
        final CSVFormat changed = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", changed.getNullString());
        assertTrue(changed.isNullStringSet());
    }

    @Test
    void testWithFirstRecordAsHeaderSetsSkipAndEmptyHeader() {
        final CSVFormat changed = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(changed.getSkipHeaderRecord());
        assertNotNull(changed.getHeader());
        assertEquals(0, changed.getHeader().length);
    }

    @Test
    void testWithTrailingDelimiterToggle() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    void testGetAllowDuplicateHeaderNamesReflectsMode() {
        final CSVFormat allowAll = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        final CSVFormat disallow = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertTrue(allowAll.getAllowDuplicateHeaderNames());
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    // ---------------------------------------------------------------
    // setNullString / quotedNullString ordering (QuoteMode.ALL)
    // ---------------------------------------------------------------

    @Test
    void testNullStringQuotedWhenQuoteModeAllAndQuoteSetBeforeNullString() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create()
                .setQuote('"')
                .setNullString("NULL")
                .setQuoteMode(QuoteMode.ALL)
                .setEscape('\\')
                .get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("\"NULL\"", sb.toString());
    }

    @Test
    void testNullStringQuotedRegardlessOfSetterOrder() throws IOException {
        // Builder.setQuote() does not retroactively recompute the quoted null string that
        // Builder.setNullString() captured, so the final quote character set here should still
        // be reflected when QuoteMode.ALL is used to print a null value.
        final CSVFormat format = CSVFormat.MYSQL.builder()
                .setNullString("NULL")
                .setQuote('"')
                .setQuoteMode(QuoteMode.ALL)
                .get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("\"NULL\"", sb.toString());
    }
}
