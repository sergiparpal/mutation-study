/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test for {@link ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest {

    /**
     * Simple {@link FormatFactory} used by the tests below, producing a
     * {@link Format} that upper-cases its argument via {@code toString()}.
     */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new UpperCaseFormat();
        }
    }

    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            return null;
        }
    }

    private Map<String, FormatFactory> createUpperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperCaseFormatFactory());
        return registry;
    }

    @Test
    public void testPlainPatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testDefaultLocaleConstructorUsesDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    public void testExplicitLocaleConstructor() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.FRANCE);
        assertEquals(Locale.FRANCE, emf.getLocale());
    }

    @Test
    public void testPatternWithoutBracesPassesThrough() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("plain, no braces");
        assertEquals("plain, no braces", emf.toPattern());
        assertEquals("plain, no braces", emf.format(new Object[0]));
    }

    @Test
    public void testCustomFormatViaRegistryAppliesFormatAndPreservesPattern() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0,upper}!", registry);
        assertEquals("Hi {0,upper}!", emf.toPattern());
        assertEquals("Hi BOB!", emf.format(new Object[] {"bob"}));
    }

    @Test
    public void testRegistryConstructorWithDefaultLocale() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0,upper}!", registry);
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("Hi SAM!", emf.format(new Object[] {"sam"}));
    }

    @Test
    public void testFormatNameNotInRegistryFallsBackToBuiltinAndFailsForUnknownType() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("Hi {0,lower}!", registry);
            }
        });
    }

    @Test
    public void testQuotedTextIsPreservedInPatternAndUnescapedInOutput() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("It''s a {0} day", registry);
        assertEquals("It''s a {0} day", emf.toPattern());
        assertEquals("It's a sunny day", emf.format(new Object[] {"sunny"}));
    }

    @Test
    public void testChoiceFormatStillWorks() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,choice,0#no|1#one|1<many}");
        assertEquals("no", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("many", emf.format(new Object[] {Integer.valueOf(2)}));
    }

    @Test
    public void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    public void testUnmatchedBraceWithoutRegistryThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    public void testUnterminatedQuotedStringWithRegistryThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0,upper,'unterminated", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated quoted string"));
    }

    @Test
    public void testUnterminatedFormatElementWithRegistryThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0,upper,foo", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    public void testInvalidArgumentIndexWithRegistryThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = createUpperRegistry();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0x,upper}", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    public void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, null);
            }
        });
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, null);
            }
        });
    }

    @Test
    public void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[0]);
            }
        });
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[0]);
            }
        });
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentInstances() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("x {0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("x {0}", Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsIsFalseForDifferentLocale() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("x {0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("x {0}", Locale.FRANCE);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsIsFalseForDifferentPattern() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("x {0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("y {0}", Locale.US);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsIsFalseForNullAndUnrelatedType() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("x {0}", Locale.US);
        assertFalse(a.equals(null));
        assertFalse(a.equals("x {0}"));
        assertNotEquals(a, Integer.valueOf(1));
    }

    @Test
    public void testEqualsIsReflexive() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("x {0}", Locale.US);
        assertTrue(a.equals(a));
    }

    @Test
    public void testFormatWithNoArguments() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("No args here");
        assertEquals("No args here", emf.format(new Object[0]));
    }

    @Test
    public void testApplyPatternReplacesExistingPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("first {0}");
        assertEquals("first {0}", emf.toPattern());
        emf.applyPattern("second {0}");
        assertEquals("second {0}", emf.toPattern());
        assertEquals("second X", emf.format(new Object[] {"X"}));
    }
}
