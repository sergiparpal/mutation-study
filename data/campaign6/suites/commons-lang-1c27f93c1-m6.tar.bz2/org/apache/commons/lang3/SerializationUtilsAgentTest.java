/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.NotSerializableException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link SerializationUtils}.
 */
class SerializationUtilsAgentTest {

    /**
     * A plain serializable fixture with value semantics for equality checks.
     */
    static final class SerializablePoint implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int x;
        private final int y;

        SerializablePoint(final int x, final int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof SerializablePoint)) {
                return false;
            }
            final SerializablePoint other = (SerializablePoint) obj;
            return x == other.x && y == other.y;
        }

        @Override
        public int hashCode() {
            return x * 31 + y;
        }
    }

    /**
     * Implements Serializable but holds a field whose runtime type is not
     * serializable, which causes writeObject() to fail with an IOException.
     */
    static final class NotActuallySerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final Object notSerializable = new Object();
    }

    /**
     * An OutputStream whose write always fails, to force the
     * SerializationException wrapping path in serialize(obj, OutputStream).
     */
    static final class ThrowingOutputStream extends OutputStream {
        @Override
        public void write(final int b) throws IOException {
            throw new IOException("boom");
        }
    }

    @Test
    void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    void testCloneReturnsEqualButDistinctInstance() {
        final SerializablePoint original = new SerializablePoint(3, 4);
        final SerializablePoint cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    void testCloneList() {
        final ArrayList<String> original = new ArrayList<String>();
        original.add("a");
        original.add("b");
        final ArrayList<String> cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    void testCloneOfNotSerializableFieldThrows() {
        final SerializationException ex = assertThrows(SerializationException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.clone(new NotActuallySerializable());
            }
        });
        assertTrue(ex.getCause() instanceof NotSerializableException);
    }

    @Test
    void testDeserializeByteArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((byte[]) null);
            }
        });
    }

    @Test
    void testDeserializeInputStreamNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((InputStream) null);
            }
        });
    }

    @Test
    void testDeserializeByteArrayRoundTrip() {
        final List<String> original = new ArrayList<String>();
        original.add("x");
        original.add("y");
        final byte[] bytes = SerializationUtils.serialize((Serializable) original);
        final List<String> result = SerializationUtils.deserialize(bytes);
        assertEquals(original, result);
    }

    @Test
    void testDeserializeGarbageBytesThrows() {
        final byte[] garbage = {1, 2, 3, 4, 5};
        assertThrows(SerializationException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(garbage);
            }
        });
    }

    @Test
    void testDeserializeEmptyBytesThrows() {
        final byte[] empty = new byte[0];
        assertThrows(SerializationException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(empty);
            }
        });
    }

    @Test
    void testDeserializeTruncatedStreamThrows() {
        final byte[] full = SerializationUtils.serialize(new SerializablePoint(1, 2));
        final byte[] truncated = new byte[full.length - 1];
        System.arraycopy(full, 0, truncated, 0, truncated.length);
        assertThrows(SerializationException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(truncated);
            }
        });
    }

    @Test
    void testRequireNonNullReturnsObject() throws InvalidObjectException {
        final String value = "hello";
        assertSame(value, SerializationUtils.requireNonNull(value, "must not be null"));
    }

    @Test
    void testRequireNonNullThrowsOnNull() {
        final InvalidObjectException ex = assertThrows(InvalidObjectException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                SerializationUtils.requireNonNull(null, "custom message");
            }
        });
        assertEquals("custom message", ex.getMessage());
    }

    @Test
    void testRoundtrip() {
        final SerializablePoint original = new SerializablePoint(7, 8);
        final SerializablePoint result = SerializationUtils.roundtrip(original);
        assertEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    void testRoundtripNull() {
        assertNull(SerializationUtils.roundtrip(null));
    }

    @Test
    void testSerializeProducesNonEmptyBytes() {
        final byte[] bytes = SerializationUtils.serialize(new SerializablePoint(1, 1));
        assertTrue(bytes.length > 0);
    }

    @Test
    void testSerializeNullObject() {
        final byte[] bytes = SerializationUtils.serialize(null);
        assertNull(SerializationUtils.deserialize(bytes));
    }

    @Test
    void testSerializeToStreamMatchesByteArrayForm() {
        final SerializablePoint original = new SerializablePoint(9, 10);
        final byte[] direct = SerializationUtils.serialize(original);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(original, baos);
        assertArrayEquals(direct, baos.toByteArray());
    }

    @Test
    void testSerializeOutputStreamNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new SerializablePoint(1, 2), null);
            }
        });
    }

    @Test
    void testSerializeWrapsIOException() {
        final SerializationException ex = assertThrows(SerializationException.class, new Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new SerializablePoint(1, 2), new ThrowingOutputStream());
            }
        });
        assertTrue(ex.getCause() instanceof IOException);
    }

    @Test
    void testSerializeDeserializeStreamRoundTrip() {
        final SerializablePoint original = new SerializablePoint(5, 6);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(original, baos);
        final SerializablePoint result = SerializationUtils.deserialize(new ByteArrayInputStream(baos.toByteArray()));
        assertEquals(original, result);
    }

    @Test
    void testPublicConstructorAvailable() {
        assertNotNull(new SerializationUtils());
    }
}
