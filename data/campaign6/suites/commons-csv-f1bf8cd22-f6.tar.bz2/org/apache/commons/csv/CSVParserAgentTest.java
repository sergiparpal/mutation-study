/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
class CSVParserAgentTest {

    @Test
    void testParseStringSimple() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("3", records.get(1).get(2));
        parser.close();
    }

    @Test
    void testParseNullStringThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseNullFileThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseNullPathThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseFile() throws IOException {
        final Path tmp = Files.createTempFile("CSVParserAgentTest", ".csv");
        try {
            Files.write(tmp, "x,y\nfoo,bar\n".getBytes(StandardCharsets.UTF_8));
            final CSVParser parser = CSVParser.parse(tmp.toFile(), StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("foo", records.get(1).get(0));
            assertEquals("bar", records.get(1).get(1));
            parser.close();
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    @Test
    void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final Reader in = new StringReader("name,age\nJohn,30\n");
        final CSVParser parser = new CSVParser(in, format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("name"));
        assertEquals(Integer.valueOf(1), headerMap.get("age"));
        assertEquals("name", parser.getHeaderNames().get(0));
        assertEquals("age", parser.getHeaderNames().get(1));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("John", records.get(0).get("name"));
        assertEquals("30", records.get(0).get("age"));
        parser.close();
    }

    @Test
    void testHeaderMapIsCopyNotShared() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final Reader in = new StringReader("1,2\n");
        final CSVParser parser = new CSVParser(in, format);
        final Map<String, Integer> map1 = parser.getHeaderMap();
        map1.put("c", Integer.valueOf(99));
        final Map<String, Integer> map2 = parser.getHeaderMap();
        assertFalse(map2.containsKey("c"));
        parser.close();
    }

    @Test
    void testNoHeaderMapWhenFormatHasNoHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertNull(parser.getHeaderMap());
        assertTrue(parser.getHeaderNames().isEmpty());
        parser.close();
    }

    @Test
    void testDuplicateHeaderNameInFirstLineThrows() {
        // setHeader() with no names means the header is read from the first line at parse time,
        // so CSVFormat's own constructor-time duplicate check cannot see it; CSVParser must check it.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader()
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser(new StringReader("a,a\n1,2\n"), format);
            }
        });
    }

    @Test
    void testMissingHeaderNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").setSkipHeaderRecord(false)
                .setAllowMissingColumnNames(false).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser(new StringReader("1,2\n"), format);
            }
        });
    }

    @Test
    void testMissingHeaderNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").setSkipHeaderRecord(false)
                .setAllowMissingColumnNames(true).get();
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), format);
        assertEquals(2, parser.getHeaderNames().size());
        assertEquals("a", parser.getHeaderNames().get(0));
        assertEquals("", parser.getHeaderNames().get(1));
        parser.close();
    }

    @Test
    void testGetRecordNumberIncrements() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getRecordNumber());
        final Iterator<CSVRecord> it = parser.iterator();
        assertEquals("1", it.next().get(0));
        assertEquals(1, parser.getRecordNumber());
        assertEquals("2", it.next().get(0));
        assertEquals(2, parser.getRecordNumber());
        assertEquals("3", it.next().get(0));
        assertEquals(3, parser.getRecordNumber());
        assertFalse(it.hasNext());
        parser.close();
    }

    @Test
    void testIteratorNextWithoutHasNextThrowsNoSuchElement() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertEquals("1", it.next().get(0));
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
        parser.close();
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.remove();
            }
        });
        parser.close();
    }

    @Test
    void testIteratorAfterCloseHasNoMoreElements() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    void testIsClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    void testGetRecordsEmptyInput() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertTrue(records.isEmpty());
        parser.close();
    }

    @Test
    void testStreamProducesSameAsGetRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        final long count = parser.stream().count();
        assertEquals(3, count);
        parser.close();
    }

    @Test
    void testNullStringHandling() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = new CSVParser(new StringReader("a,NULL,c\n"), format);
        final CSVRecord record = parser.iterator().next();
        assertEquals("a", record.get(0));
        assertNull(record.get(1));
        assertEquals("c", record.get(2));
        parser.close();
    }

    @Test
    void testTrailingDelimiterDropsEmptyLastField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = new CSVParser(new StringReader("a,b,\n"), format);
        final CSVRecord record = parser.iterator().next();
        assertEquals(2, record.size());
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        parser.close();
    }

    @Test
    void testQuotedEmptyFieldKeptWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = new CSVParser(new StringReader("a,b,\"\"\n"), format);
        final CSVRecord record = parser.iterator().next();
        assertEquals(3, record.size());
        assertEquals("", record.get(2));
        parser.close();
    }

    @Test
    void testHeaderCommentDetection() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = new CSVParser(new StringReader("# a header comment\na,b\n1,2\n"), format);
        assertTrue(parser.hasHeaderComment());
        assertEquals("a header comment", parser.getHeaderComment());
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        parser.close();
    }

    @Test
    void testNoHeaderCommentByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse(parser.hasHeaderComment());
        assertNull(parser.getHeaderComment());
        parser.close();
    }

    @Test
    void testTrailerCommentDetection() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = new CSVParser(new StringReader("a,b\n# trailing comment\n"), format);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertTrue(parser.hasTrailerComment());
        assertEquals("trailing comment", parser.getTrailerComment());
        parser.close();
    }

    @Test
    void testInvalidInputThrowsCsvException() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser;
        try {
            parser = new CSVParser(new StringReader("\"a\"b,c\n"), format);
        } catch (final IOException e) {
            throw new UncheckedIOException(e);
        }
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.nextRecord();
            }
        });
    }

    @Test
    void testCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getCurrentLineNumber());
        final Iterator<CSVRecord> it = parser.iterator();
        it.next();
        assertEquals(1, parser.getCurrentLineNumber());
        it.next();
        assertEquals(2, parser.getCurrentLineNumber());
        parser.close();
    }

    @Test
    void testMaxRowsLimitsIteration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = new CSVParser(new StringReader("1\n2\n3\n4\n"), format);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
    }

    @Test
    void testDeprecatedConstructorRecordNumberOffset() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\n"), CSVFormat.DEFAULT, 0, 5);
        final Iterator<CSVRecord> it = parser.iterator();
        final CSVRecord first = it.next();
        assertEquals(5, first.getRecordNumber());
        assertEquals(5, parser.getRecordNumber());
        parser.close();
    }

    @Test
    void testBuilderRecordNumberOffset() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(10)
                .get();
        final CSVRecord first = parser.iterator().next();
        assertEquals(10, first.getRecordNumber());
        parser.close();
    }

    @Test
    void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    void testExplicitHeaderWithoutSkipDoesNotConsumeFirstRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(false).get();
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"), format);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get("a"));
        assertEquals("3", records.get(1).get("a"));
        parser.close();
    }
}
