/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TimedSemaphore}.
 */
class TimedSemaphoreAgentTest {

    /** Semaphores created by a test, shut down automatically afterwards. */
    private final java.util.List<TimedSemaphore> created = new java.util.ArrayList<TimedSemaphore>();

    private TimedSemaphore newSemaphore(final long period, final TimeUnit unit, final int limit) {
        final TimedSemaphore sem = new TimedSemaphore(period, unit, limit);
        created.add(sem);
        return sem;
    }

    @AfterEach
    void tearDown() {
        for (int i = 0; i < created.size(); i++) {
            created.get(i).shutdown();
        }
        created.clear();
    }

    @Test
    void testConstructorRejectsNonPositivePeriod() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new TimedSemaphore(0, TimeUnit.SECONDS, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new TimedSemaphore(-1, TimeUnit.SECONDS, 1);
            }
        });
    }

    @Test
    void testConstructorAcceptsMinimalPositivePeriod() {
        final TimedSemaphore sem = newSemaphore(1, TimeUnit.NANOSECONDS, 1);
        assertEquals(1L, sem.getPeriod());
        assertEquals(TimeUnit.NANOSECONDS, sem.getUnit());
    }

    @Test
    void testGetPeriodAndUnit() {
        final TimedSemaphore sem = newSemaphore(5, TimeUnit.SECONDS, 3);
        assertEquals(5L, sem.getPeriod());
        assertEquals(TimeUnit.SECONDS, sem.getUnit());
    }

    @Test
    void testGetAndSetLimit() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 7);
        assertEquals(7, sem.getLimit());
        sem.setLimit(42);
        assertEquals(42, sem.getLimit());
    }

    @Test
    void testTryAcquireRespectsLimit() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 2);
        assertTrue(sem.tryAcquire());
        assertEquals(1, sem.getAcquireCount());
        assertTrue(sem.tryAcquire());
        assertEquals(2, sem.getAcquireCount());
        assertFalse(sem.tryAcquire());
        assertEquals(2, sem.getAcquireCount());
    }

    @Test
    void testGetAvailablePermits() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 3);
        assertEquals(3, sem.getAvailablePermits());
        sem.tryAcquire();
        assertEquals(2, sem.getAvailablePermits());
        sem.tryAcquire();
        sem.tryAcquire();
        assertEquals(0, sem.getAvailablePermits());
        assertFalse(sem.tryAcquire());
        assertEquals(0, sem.getAvailablePermits());
    }

    @Test
    void testNoLimitAlwaysAllowsAcquire() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, TimedSemaphore.NO_LIMIT);
        assertEquals(TimedSemaphore.NO_LIMIT, sem.getLimit());
        for (int i = 0; i < 50; i++) {
            assertTrue(sem.tryAcquire());
        }
        assertEquals(50, sem.getAcquireCount());
    }

    @Test
    void testNegativeLimitDisablesSemaphore() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, -3);
        for (int i = 0; i < 10; i++) {
            assertTrue(sem.tryAcquire());
        }
        assertEquals(10, sem.getAcquireCount());
    }

    @Test
    void testEndOfPeriodResetsCounterAndRecordsStatistics() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 5);
        assertEquals(0, sem.getLastAcquiresPerPeriod());
        assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0001d);

        sem.tryAcquire();
        sem.tryAcquire();
        sem.tryAcquire();
        assertEquals(3, sem.getAcquireCount());

        sem.endOfPeriod();

        assertEquals(0, sem.getAcquireCount());
        assertEquals(3, sem.getLastAcquiresPerPeriod());
        assertEquals(3.0d, sem.getAverageCallsPerPeriod(), 0.0001d);

        sem.tryAcquire();
        sem.endOfPeriod();

        assertEquals(1, sem.getLastAcquiresPerPeriod());
        assertEquals(2.0d, sem.getAverageCallsPerPeriod(), 0.0001d);
    }

    @Test
    void testAcquireBlocksUntilEndOfPeriodThenReleases() throws Exception {
        // Use a long real period so the internal timer task does not fire
        // during the test; endOfPeriod() is invoked manually instead.
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 1);

        sem.acquire();
        assertEquals(1, sem.getAcquireCount());

        final AtomicBoolean secondAcquireCompleted = new AtomicBoolean(false);
        final Thread blockedThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    sem.acquire();
                    secondAcquireCompleted.set(true);
                } catch (final InterruptedException e) {
                    // fall through, flag stays false
                }
            }
        });
        blockedThread.start();

        Thread.sleep(300);
        assertFalse(secondAcquireCompleted.get(), "acquire() should block while the limit is exhausted");

        sem.endOfPeriod();
        blockedThread.join(5000);

        assertTrue(secondAcquireCompleted.get(), "acquire() should unblock once endOfPeriod() runs");
        assertFalse(blockedThread.isAlive());
    }

    @Test
    void testAcquireAfterShutdownThrows() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 1);
        sem.shutdown();
        assertTrue(sem.isShutdown());
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sem.acquire();
            }
        });
    }

    @Test
    void testTryAcquireAfterShutdownThrows() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 1);
        sem.shutdown();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sem.tryAcquire();
            }
        });
    }

    @Test
    void testShutdownIsIdempotent() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 1);
        assertFalse(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
    }

    @Test
    void testShutdownDoesNotStopExternallyProvidedExecutor() {
        final ScheduledExecutorService externalExecutor = Executors.newScheduledThreadPool(1);
        try {
            final TimedSemaphore sem = TimedSemaphore.builder()
                    .setService(externalExecutor)
                    .setPeriod(10)
                    .setTimeUnit(TimeUnit.SECONDS)
                    .setLimit(1)
                    .get();

            assertSame(externalExecutor, sem.getExecutorService());

            // Start the internal timer task so shutdown() has something to cancel.
            sem.tryAcquire();
            sem.shutdown();

            assertTrue(sem.isShutdown());
            assertFalse(externalExecutor.isShutdown(), "an externally supplied executor must not be shut down");
        } finally {
            externalExecutor.shutdownNow();
        }
    }

    @Test
    void testOwnExecutorIsCreatedAndShutDownOnShutdown() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 1);
        final ScheduledExecutorService service = sem.getExecutorService();
        assertNotNull(service);
        assertFalse(service.isShutdown());

        sem.tryAcquire();
        sem.shutdown();

        assertTrue(service.isShutdown(), "an internally created executor must be shut down by shutdown()");
    }

    @Test
    void testBuilderCreatesConfiguredSemaphore() {
        final TimedSemaphore sem = TimedSemaphore.builder()
                .setPeriod(7)
                .setTimeUnit(TimeUnit.MILLISECONDS)
                .setLimit(4)
                .get();
        created.add(sem);

        assertEquals(7L, sem.getPeriod());
        assertEquals(TimeUnit.MILLISECONDS, sem.getUnit());
        assertEquals(4, sem.getLimit());
    }

    @Test
    void testBuilderRejectsNonPositivePeriod() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TimedSemaphore.builder().setPeriod(0).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
            }
        });
    }

    @Test
    void testDeprecatedConstructorWithNullServiceCreatesOwnExecutor() {
        final TimedSemaphore sem = new TimedSemaphore(null, 10, TimeUnit.SECONDS, 1);
        created.add(sem);
        assertNotNull(sem.getExecutorService());
    }

    @Test
    void testDeprecatedConstructorWithProvidedServiceUsesIt() {
        final ScheduledExecutorService externalExecutor = Executors.newScheduledThreadPool(1);
        try {
            final TimedSemaphore sem = new TimedSemaphore(externalExecutor, 10, TimeUnit.SECONDS, 1);
            created.add(sem);
            assertSame(externalExecutor, sem.getExecutorService());
        } finally {
            externalExecutor.shutdownNow();
        }
    }

    @Test
    void testAverageCallsPerPeriodIsZeroBeforeAnyPeriodEnds() {
        final TimedSemaphore sem = newSemaphore(10, TimeUnit.SECONDS, 5);
        sem.tryAcquire();
        sem.tryAcquire();
        assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0001d, "no period has ended yet");
    }
}
