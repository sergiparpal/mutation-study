/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    public interface PublicIface {
        String name();
    }

    private static class PrivateImpl implements PublicIface {
        @Override
        public String name() {
            return "impl";
        }
    }

    private interface Interface1 {
        // empty
    }

    private interface Interface2 extends Interface1 {
        // empty
    }

    private static class GrandParent implements Interface1 {
        // empty
    }

    private static class Parent extends GrandParent implements Interface2 {
        // empty
    }

    private static class Child extends Parent {
        // empty
    }

    private static class Nested {
        // empty
    }

    // ----- comparator -----

    @Test
    public void testComparator() {
        List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        list.sort(ClassUtils.comparator());
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), list);
    }

    // ----- convertClassesToClassNames / convertClassNamesToClasses -----

    @Test
    public void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNames() {
        List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        input.add(Integer.class);
        List<String> result = ClassUtils.convertClassesToClassNames(input);
        assertEquals(Arrays.asList("java.lang.String", null, "java.lang.Integer"), result);
    }

    @Test
    public void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        List<String> input = Arrays.asList("java.lang.String", "not.a.real.ClassName", null);
        List<Class<?>> result = ClassUtils.convertClassNamesToClasses(input);
        assertEquals(3, result.size());
        assertSame(String.class, result.get(0));
        assertNull(result.get(1));
        assertNull(result.get(2));
    }

    // ----- getAbbreviatedName -----

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 5));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 5));
    }

    @Test
    public void testGetAbbreviatedNameStringExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameAlreadyShortEnough() {
        assertEquals("Foo", ClassUtils.getAbbreviatedName("Foo", 100));
    }

    @Test
    public void testGetAbbreviatedNameLengthHintNotPositive() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    // ----- getAllInterfaces / getAllSuperclasses / hierarchy -----

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfaces() {
        List<Class<?>> result = ClassUtils.getAllInterfaces(Child.class);
        assertEquals(Arrays.asList(Interface2.class, Interface1.class), result);
    }

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclasses() {
        List<Class<?>> result = ClassUtils.getAllSuperclasses(Child.class);
        assertEquals(Arrays.asList(Parent.class, GrandParent.class, Object.class), result);
    }

    @Test
    public void testGetAllSuperclassesOfObject() {
        assertEquals(0, ClassUtils.getAllSuperclasses(Object.class).size());
    }

    @Test
    public void testHierarchyExcludeInterfaces() {
        List<Class<?>> result = new ArrayList<Class<?>>();
        Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class).iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        assertEquals(Arrays.asList(Child.class, Parent.class, GrandParent.class, Object.class), result);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        List<Class<?>> result = new ArrayList<Class<?>>();
        Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class, ClassUtils.Interfaces.INCLUDE).iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        assertEquals(Arrays.asList(Child.class, Parent.class, Interface2.class, Interface1.class, GrandParent.class, Object.class), result);
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class).iterator();
        it.next();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                it.remove();
            }
        });
    }

    // ----- getCanonicalName -----

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    public void testGetCanonicalNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hi"));
    }

    @Test
    public void testGetCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
    }

    // ----- getClass -----

    @Test
    public void testGetClassByName() throws Exception {
        assertSame(String.class, ClassUtils.getClass("java.lang.String"));
        assertSame(int.class, ClassUtils.getClass("int"));
    }

    @Test
    public void testGetClassArraySyntaxes() throws Exception {
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertSame(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassInnerClassSyntaxes() throws Exception {
        assertSame(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertSame(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("not.a.real.ClassName");
            }
        });
    }

    @Test
    public void testGetClassNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassWhitespaceNormalized() throws Exception {
        assertSame(Runtime.class, ClassUtils.getClass(" java.lang.Runtime"));
    }

    @Test
    public void testGetClassTooManyArrayDimensions() {
        final StringBuilder sb = new StringBuilder("java.lang.String");
        for (int i = 0; i < 300; i++) {
            sb.append("[]");
        }
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(sb.toString());
            }
        });
    }

    @Test
    public void testGetClassNameTooLong() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(sb.toString());
            }
        });
    }

    // ----- getClassStrict -----

    @Test
    public void testGetClassStrictDoesNotNormalizeWhitespace() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClassStrict(" java.lang.Runtime");
            }
        });
    }

    @Test
    public void testGetClassStrictExactMatch() throws Exception {
        assertSame(Runtime.class, ClassUtils.getClassStrict("java.lang.Runtime"));
    }

    // ----- getComponentType -----

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertSame(String.class, ClassUtils.getComponentType(String[].class));
    }

    // ----- getName -----

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    @Test
    public void testGetNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
    }

    // ----- getPackageCanonicalName / getPackageName -----

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hi", "NULL"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObject() {
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageName("hi", "NULL"));
    }

    @Test
    public void testGetPackageNameStringDefaultPackage() {
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
    }

    @Test
    public void testGetPackageNameStringArrayEncoded() {
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    // ----- getPublicMethod -----

    @Test
    public void testGetPublicMethodFromPrivateImpl() throws Exception {
        Method m = ClassUtils.getPublicMethod(PrivateImpl.class, "name");
        assertNotNull(m);
        assertSame(PublicIface.class, m.getDeclaringClass());
        assertEquals("impl", m.invoke(new PrivateImpl()));
    }

    @Test
    public void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(PrivateImpl.class, "doesNotExist");
            }
        });
    }

    @Test
    public void testGetPublicMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "name");
            }
        });
    }

    // ----- getShortCanonicalName -----

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
    }

    @Test
    public void testGetShortCanonicalNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hi", "NULL"));
    }

    @Test
    public void testGetShortCanonicalNameStringExamples() {
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
    }

    @Test
    public void testGetShortCanonicalNameInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getShortCanonicalName("[");
            }
        });
    }

    @Test
    public void testGetShortCanonicalNameTooManyDimensions() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append('I');
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getShortCanonicalName(sb.toString());
            }
        });
    }

    // ----- getShortClassName -----

    @Test
    public void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
    }

    @Test
    public void testGetShortClassNameNestedClass() {
        assertEquals("ClassUtilsAgentTest.Nested", ClassUtils.getShortClassName(Nested.class));
    }

    @Test
    public void testGetShortClassNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "NULL"));
    }

    @Test
    public void testGetShortClassNameStringNullOrEmpty() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    public void testGetShortClassNameStringArrayEncoded() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetShortClassNameStringInnerClassDollar() {
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    // ----- getSimpleName -----

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameClassValueIfNull() {
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    @Test
    public void testGetSimpleNameObjectValueIfNull() {
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
    }

    // ----- isAssignable -----

    @Test
    public void testIsAssignableNulls() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
    }

    @Test
    public void testIsAssignableSameClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
        assertTrue(ClassUtils.isAssignable(int.class, int.class));
    }

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertFalse(ClassUtils.isAssignable(byte.class, char.class));
        assertTrue(ClassUtils.isAssignable(char.class, int.class));
        assertFalse(ClassUtils.isAssignable(char.class, short.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableArraysMismatchedLength() {
        assertFalse(ClassUtils.isAssignable(new Class[] {String.class}, new Class[] {String.class, String.class}));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class[] {String.class, int.class}, new Class[] {Object.class, long.class}));
        assertFalse(ClassUtils.isAssignable(new Class[] {String.class, int.class}, new Class[] {Object.class, boolean.class}));
    }

    // ----- isInnerClass -----

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(ClassUtilsAgentTest.class));
        assertTrue(ClassUtils.isInnerClass(Nested.class));
    }

    // ----- isPrimitiveOrWrapper / isPrimitiveWrapper -----

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    // ----- isPublic -----

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateImpl.class));
    }

    @Test
    public void testIsPublicNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    // ----- primitivesToWrappers / primitiveToWrapper -----

    @Test
    public void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    public void testPrimitivesToWrappersEmpty() {
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
    }

    @Test
    public void testPrimitivesToWrappers() {
        Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(3, result.length);
        assertSame(Integer.class, result[0]);
        assertSame(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertSame(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertSame(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    // ----- toClass -----

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        assertEquals(0, ClassUtils.toClass().length);
    }

    @Test
    public void testToClass() {
        Class<?>[] result = ClassUtils.toClass("hi", 1, null);
        assertEquals(3, result.length);
        assertSame(String.class, result[0]);
        assertSame(Integer.class, result[1]);
        assertNull(result[2]);
    }

    // ----- wrappersToPrimitives / wrapperToPrimitive -----

    @Test
    public void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    public void testWrappersToPrimitivesEmpty() {
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
    }

    @Test
    public void testWrappersToPrimitives() {
        Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(3, result.length);
        assertSame(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertSame(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    // ----- Interfaces enum -----

    @Test
    public void testInterfacesEnum() {
        assertEquals(2, ClassUtils.Interfaces.values().length);
        assertEquals(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertEquals(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    // ----- public constructor -----

    @Test
    public void testPublicConstructor() {
        assertNotNull(new ClassUtils());
    }
}
