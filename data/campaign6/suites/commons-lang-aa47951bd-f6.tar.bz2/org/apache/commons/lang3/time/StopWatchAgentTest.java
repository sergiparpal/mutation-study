/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

class StopWatchAgentTest {

    @Test
    void testCreateReturnsUnstartedWatch() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
    }

    @Test
    void testCreateStartedReturnsRunningWatch() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testMessageConstructor() {
        final StopWatch watch = new StopWatch("my message");
        assertEquals("my message", watch.getMessage());
        final StopWatch noMessage = new StopWatch();
        assertNotNull(noMessage); // ensure no-arg constructor does not throw
        assertEquals(null, noMessage.getMessage());
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    void testSplitBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::resume);
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::unsplit);
    }

    @Test
    void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch watch = StopWatch.createStarted();
        assertThrows(IllegalStateException.class, watch::getSplitTime);
        assertThrows(IllegalStateException.class, watch::getSplitDuration);
    }

    @Test
    void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStartInstant);
        assertThrows(IllegalStateException.class, watch::getStartTime);
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    void testResetAllowsRestart() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        watch.start();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
    }

    @Test
    void testResetClearsSplits() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.split();
        assertEquals(1, watch.getSplits().size());
        watch.reset();
        assertEquals(0, watch.getSplits().size());
    }

    @Test
    void testStopAfterStartSetsStoppedAndTimeIsNonNegative() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getTime() >= 0);
        assertTrue(watch.getNanoTime() >= 0);
    }

    @Test
    void testStopTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    void testSuspendResumeExcludesSuspendedTime() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedTime = watch.getTime();
        Thread.sleep(50);
        // time must not advance while suspended
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        Thread.sleep(5);
        watch.stop();
        assertTrue(watch.getTime() >= suspendedTime);
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    void testStopWhileSuspendedSucceeds() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        watch.stop();
        assertTrue(watch.isStopped());
    }

    @Test
    void testSplitAndUnsplit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.split();
        assertEquals(1, watch.getSplits().size());
        final long splitTime = watch.getSplitTime();
        assertTrue(splitTime >= 0);
        // time continues to be reported after split, watch is still running
        assertTrue(watch.isStarted());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, watch::getSplitTime);
        // can split again after unsplit
        watch.split();
        assertEquals(1, watch.getSplits().size());
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        assertEquals("first", watch.getSplits().get(0).getLabel());
        assertEquals(1, watch.getSplits().size());
    }

    @Test
    void testDefaultSplitLabelsAreIndexBased() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.unsplit();
        watch.split();
        // Per Javadoc, split()/suspend()/stop() cannot be invoked twice without an
        // intervening unsplit()/resume()/reset(); each split label should reflect
        // its position (0-based) among the currently recorded splits.
        assertEquals("0", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testGetSplitsReturnsUnmodifiableList() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, () -> splits.add(new StopWatch.Split("x", Duration.ZERO)));
    }

    @Test
    void testSplitCannotBeInvokedTwiceWithoutUnsplit() {
        // Class Javadoc: "split(), suspend(), or stop() cannot be invoked twice"
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    void testSplitClassAccessors() {
        final Duration d = Duration.ofMillis(42);
        final StopWatch.Split split = new StopWatch.Split("lbl", d);
        assertEquals("lbl", split.getLabel());
        assertSame(d, split.getDuration());
        assertEquals("lbl", split.getLeft());
        assertSame(d, split.getRight());
    }

    @Test
    void testGetDurationMatchesGetNanoTime() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        assertEquals(watch.getNanoTime(), watch.getDuration().toNanos());
    }

    @Test
    void testGetTimeInSpecifiedTimeUnit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(20);
        watch.stop();
        final long nanos = watch.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), watch.getTime(TimeUnit.MILLISECONDS));
        assertEquals(TimeUnit.NANOSECONDS.toSeconds(nanos), watch.getTime(TimeUnit.SECONDS));
    }

    @Test
    void testGetStartInstantAndStopInstant() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        final Instant before = Instant.now();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final Instant after = Instant.now();
        final Instant start = watch.getStartInstant();
        final Instant stop = watch.getStopInstant();
        assertFalse(start.isBefore(before.minusSeconds(1)));
        assertFalse(stop.isAfter(after.plusSeconds(1)));
        assertFalse(stop.isBefore(start));
        assertEquals(start.toEpochMilli(), watch.getStartTime());
        assertEquals(stop.toEpochMilli(), watch.getStopTime());
    }

    @Test
    void testToStringContainsMessageWhenPresent() {
        final StopWatch withMessage = new StopWatch("hello");
        withMessage.start();
        withMessage.stop();
        assertTrue(withMessage.toString().startsWith("hello "));

        final StopWatch withoutMessage = new StopWatch();
        withoutMessage.start();
        withoutMessage.stop();
        assertFalse(withoutMessage.toString().startsWith("null"));
    }

    @Test
    void testToSplitStringContainsMessageWhenPresent() {
        final StopWatch withMessage = new StopWatch("hello");
        withMessage.start();
        withMessage.split();
        assertTrue(withMessage.toSplitString().startsWith("hello "));
    }

    @Test
    void testFormatTimeMatchesHmsPattern() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertTrue(watch.formatTime().matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    void testRunRunnableStartsAndSuspendsFreshWatch() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = {false};
        watch.run(() -> ran[0] = true);
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
    }

    @Test
    void testRunPropagatesExceptionAndStillSuspends() {
        final StopWatch watch = new StopWatch();
        final RuntimeException boom = new RuntimeException("boom");
        final RuntimeException caught = assertThrows(RuntimeException.class, () -> watch.run(() -> {
            throw boom;
        }));
        assertSame(boom, caught);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetSupplierReturnsValueAndSuspendsWatch() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(() -> "value");
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetResumesSuspendedWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertTrue(watch.isSuspended());
        final Integer result = watch.get(() -> 42);
        assertEquals(42, result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesCheckedThrowable() {
        final StopWatch watch = new StopWatch();
        final Exception checked = new Exception("checked failure");
        final Throwable caught = assertThrows(Exception.class, () -> watch.runT(() -> {
            throw checked;
        }));
        assertSame(checked, caught);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTPropagatesCheckedThrowableAndReturnsValue() throws Throwable {
        final StopWatch watch = new StopWatch();
        final Object result = watch.getT(() -> "ok");
        assertEquals("ok", result);
        assertTrue(watch.isSuspended());
    }
}
