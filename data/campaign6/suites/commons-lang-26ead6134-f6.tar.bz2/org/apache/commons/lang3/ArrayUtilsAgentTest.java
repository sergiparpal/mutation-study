/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.AbstractMap;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
public class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------
    // add
    // ---------------------------------------------------------------

    @Test
    public void testAddIntElement() {
        final int[] result = ArrayUtils.add(new int[] {1, 2, 3}, 4);
        assertArrayEquals(new int[] {1, 2, 3, 4}, result);
        final int[] fromNull = ArrayUtils.add((int[]) null, 1);
        assertArrayEquals(new int[] {1}, fromNull);
    }

    @Test
    public void testAddIntAtIndex() {
        final int[] result = ArrayUtils.add(new int[] {1, 2, 3}, 1, 9);
        assertArrayEquals(new int[] {1, 9, 2, 3}, result);
    }

    @Test
    public void testAddIntAtIndexOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] {1, 2, 3}, 4, 9);
            }
        });
    }

    @Test
    public void testAddObjectElement() {
        final String[] result = ArrayUtils.add(new String[] {"a", "b"}, "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
        final String[] fromNull = ArrayUtils.add((String[]) null, "a");
        assertArrayEquals(new String[] {"a"}, fromNull);
    }

    // ---------------------------------------------------------------
    // addAll
    // ---------------------------------------------------------------

    @Test
    public void testAddAllIntArrays() {
        final int[] result = ArrayUtils.addAll(new int[] {1, 2}, new int[] {3, 4});
        assertArrayEquals(new int[] {1, 2, 3, 4}, result);
    }

    @Test
    public void testAddAllFirstNullReturnsCopyOfSecond() {
        final int[] result = ArrayUtils.addAll((int[]) null, new int[] {1, 2});
        assertArrayEquals(new int[] {1, 2}, result);
    }

    @Test
    public void testAddAllBothNullReturnsNull() {
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
    }

    @Test
    public void testAddAllObjectArrays() {
        final String[] result = ArrayUtils.addAll(new String[] {"a"}, "b", "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
    }

    // ---------------------------------------------------------------
    // addFirst
    // ---------------------------------------------------------------

    @Test
    public void testAddFirstInt() {
        final int[] result = ArrayUtils.addFirst(new int[] {2, 3}, 1);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testAddFirstFromNull() {
        final int[] result = ArrayUtils.addFirst((int[]) null, 1);
        assertArrayEquals(new int[] {1}, result);
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    public void testCloneIntArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
    }

    @Test
    public void testCloneNullReturnsNull() {
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    public void testCloneObjectArray() {
        final String[] original = {"a", "b"};
        final String[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
    }

    // ---------------------------------------------------------------
    // concat
    // ---------------------------------------------------------------

    @Test
    public void testConcatIntArrays() {
        final int[] result = ArrayUtils.concat(new int[] {1, 2}, new int[] {3}, new int[] {4, 5});
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, result);
    }

    @Test
    public void testConcatNoArgs() {
        final int[] result = ArrayUtils.concat(new int[0][]);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    // ---------------------------------------------------------------
    // contains
    // ---------------------------------------------------------------

    @Test
    public void testContainsIntArray() {
        final int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
    }

    @Test
    public void testContainsObjectArrayWithNull() {
        final Object[] array = {"a", null, "b"};
        assertTrue(ArrayUtils.contains(array, null));
        assertTrue(ArrayUtils.contains(array, "b"));
        assertFalse(ArrayUtils.contains(array, "z"));
    }

    @Test
    public void testContainsDoubleWithTolerance() {
        final double[] array = {1.0, 2.0, 3.0};
        assertTrue(ArrayUtils.contains(array, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(array, 2.5, 0.1));
    }

    // ---------------------------------------------------------------
    // containsAny
    // ---------------------------------------------------------------

    @Test
    public void testContainsAnyInt() {
        assertTrue(ArrayUtils.containsAny(new int[] {1, 2, 3}, 5, 3));
        assertFalse(ArrayUtils.containsAny(new int[] {1, 2, 3}, 5, 6));
    }

    @Test
    public void testContainsAnyObject() {
        assertTrue(ArrayUtils.containsAny(new Object[] {"a", "b"}, "z", "b"));
        assertFalse(ArrayUtils.containsAny(new Object[] {"a", "b"}, "y", "z"));
    }

    // ---------------------------------------------------------------
    // get
    // ---------------------------------------------------------------

    @Test
    public void testGetWithIndex() {
        final String[] array = {"a", "b", "c"};
        assertEquals("b", ArrayUtils.get(array, 1));
    }

    @Test
    public void testGetOutOfBoundsReturnsNull() {
        final String[] array = {"a", "b"};
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
    }

    @Test
    public void testGetWithDefault() {
        final String[] array = {"a", "b"};
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("default", ArrayUtils.get((String[]) null, 0, "default"));
    }

    // ---------------------------------------------------------------
    // getLength
    // ---------------------------------------------------------------

    @Test
    public void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(2, ArrayUtils.getLength(new String[] {"a", "b"}));
    }

    // ---------------------------------------------------------------
    // hashCode
    // ---------------------------------------------------------------

    @Test
    public void testHashCodeNull() {
        assertEquals(0, ArrayUtils.hashCode(null));
    }

    @Test
    public void testHashCodeMatchesForEqualArrays() {
        final int[] a = {1, 2, 3};
        final int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    // ---------------------------------------------------------------
    // indexesOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexesOfInt() {
        final int[] array = {1, 2, 1, 3, 1};
        final BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertFalse(bits.get(1));
        assertFalse(bits.get(3));
        assertEquals(3, bits.cardinality());
    }

    @Test
    public void testIndexesOfNullArray() {
        final BitSet bits = ArrayUtils.indexesOf((int[]) null, 1);
        assertEquals(0, bits.cardinality());
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexOfIntBasic() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(-1, ArrayUtils.indexOf(array, 9));
        assertEquals(-1, ArrayUtils.indexOf((int[]) null, 9));
    }

    @Test
    public void testIndexOfIntWithStartIndex() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
    }

    @Test
    public void testIndexOfObjectWithNegativeStartIndexTreatedAsZero() {
        final String[] array = {"a", "b", "c"};
        assertEquals(0, ArrayUtils.indexOf(array, "a", -10));
    }

    @Test
    public void testIndexOfObjectWithStartIndexBeyondLengthReturnsNotFound() {
        final String[] array = {"a", "b", "c"};
        assertEquals(-1, ArrayUtils.indexOf(array, "a", 10));
    }

    @Test
    public void testLastIndexOfIntBasic() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(-1, ArrayUtils.lastIndexOf((int[]) null, 1));
    }

    @Test
    public void testLastIndexOfObjectNegativeStartIndexNotFound() {
        final String[] array = {"a", "b", "c"};
        assertEquals(-1, ArrayUtils.lastIndexOf(array, "a", -1));
    }

    @Test
    public void testLastIndexOfObjectStartIndexBeyondLengthSearchesFromEnd() {
        final String[] array = {"a", "b", "c"};
        assertEquals(2, ArrayUtils.lastIndexOf(array, "c", 100));
    }

    @Test
    public void testIndexOfDoubleWithTolerance() {
        final double[] array = {1.0, 2.0, 3.0};
        assertEquals(1, ArrayUtils.indexOf(array, 2.05, 0.1));
        assertEquals(-1, ArrayUtils.indexOf(array, 2.5, 0.1));
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    public void testInsertIntArray() {
        final int[] result = ArrayUtils.insert(1, new int[] {1, 2, 3}, 9, 10);
        assertArrayEquals(new int[] {1, 9, 10, 2, 3}, result);
    }

    @Test
    public void testInsertIntoNullArrayReturnsNull() {
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
    }

    @Test
    public void testInsertNoValuesReturnsClone() {
        final int[] array = {1, 2, 3};
        final int[] result = ArrayUtils.insert(1, array);
        assertArrayEquals(array, result);
        assertTrue(array != result);
    }

    @Test
    public void testInsertOutOfBoundsThrows() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(10, array, 9);
            }
        });
    }

    @Test
    public void testInsertObjectArrayAtStart() {
        final String[] result = ArrayUtils.insert(0, new String[] {"b", "c"}, "a");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
    }

    // ---------------------------------------------------------------
    // isArrayIndexValid
    // ---------------------------------------------------------------

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    public void testIsEmptyPrimitiveAndObjectArrays() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));
        assertFalse(ArrayUtils.isNotEmpty((String[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new String[] {"a"}));
    }

    // ---------------------------------------------------------------
    // isEquals (deprecated but still present)
    // ---------------------------------------------------------------

    @Test
    public void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(null, new int[] {1}));
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType
    // ---------------------------------------------------------------

    @Test
    public void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, (int[]) null));
    }

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[] {1}, new int[] {2, 3}));
        assertFalse(ArrayUtils.isSameType(new int[] {1}, new String[] {"a"}));
    }

    @Test
    public void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[] {1});
            }
        });
    }

    // ---------------------------------------------------------------
    // isSorted
    // ---------------------------------------------------------------

    @Test
    public void testIsSortedIntArray() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    @Test
    public void testIsSortedWithComparator() {
        final Comparator<String> byLength = new Comparator<String>() {
            @Override
            public int compare(final String a, final String b) {
                return Integer.compare(a.length(), b.length());
            }
        };
        assertTrue(ArrayUtils.isSorted(new String[] {"a", "bb", "ccc"}, byLength));
        assertFalse(ArrayUtils.isSorted(new String[] {"ccc", "a"}, byLength));
    }

    @Test
    public void testIsSortedNullComparatorThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSorted(new String[] {"a"}, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // nullTo / nullToEmpty
    // ---------------------------------------------------------------

    @Test
    public void testNullTo() {
        final String[] defaultArray = {"d"};
        assertSame(defaultArray, ArrayUtils.nullTo(null, defaultArray));
        assertSame(defaultArray, ArrayUtils.nullTo(new String[0], defaultArray));
        final String[] array = {"a"};
        assertSame(array, ArrayUtils.nullTo(array, defaultArray));
    }

    @Test
    public void testNullToEmptyInt() {
        final int[] result = ArrayUtils.nullToEmpty((int[]) null);
        assertNotNull(result);
        assertEquals(0, result.length);
        final int[] array = {1, 2};
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    public void testNullToEmptyObjectArray() {
        final Object[] result = ArrayUtils.nullToEmpty((Object[]) null);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testNullToEmptyWithTypeNullTypeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.nullToEmpty((String[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // remove / removeAll / removeAllOccurrences / removeElement / removeElements
    // ---------------------------------------------------------------

    @Test
    public void testRemoveIndex() {
        final int[] result = ArrayUtils.remove(new int[] {1, 2, 3}, 1);
        assertArrayEquals(new int[] {1, 3}, result);
    }

    @Test
    public void testRemoveOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] {1, 2, 3}, 5);
            }
        });
    }

    @Test
    public void testRemoveAllIndices() {
        final int[] result = ArrayUtils.removeAll(new int[] {1, 2, 3, 4, 5}, 0, 2, 4);
        assertArrayEquals(new int[] {2, 4}, result);
    }

    @Test
    public void testRemoveAllOccurrencesInt() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1);
        assertArrayEquals(new int[] {2, 3}, result);
    }

    @Test
    public void testRemoveAllOccurrencesObjectWithNull() {
        final String[] result = ArrayUtils.removeAllOccurrences(new String[] {"a", null, "b", null}, null);
        assertArrayEquals(new String[] {"a", "b"}, result);
    }

    @Test
    public void testRemoveElementNoMatchReturnsEqualCopy() {
        final int[] array = {1, 2, 3};
        final int[] result = ArrayUtils.removeElement(array, 9);
        assertArrayEquals(array, result);
    }

    @Test
    public void testRemoveElementRemovesFirstMatch() {
        final int[] result = ArrayUtils.removeElement(new int[] {1, 2, 1}, 1);
        assertArrayEquals(new int[] {2, 1}, result);
    }

    @Test
    public void testRemoveElementsMultipleOccurrences() {
        final int[] result = ArrayUtils.removeElements(new int[] {1, 2, 1, 1, 3}, 1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, result);
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    public void testReverseFullArray() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {4, 3, 2, 1}, array);
    }

    @Test
    public void testReverseRange() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseNullArrayDoesNotThrow() {
        ArrayUtils.reverse((int[]) null);
    }

    // ---------------------------------------------------------------
    // setAll
    // ---------------------------------------------------------------

    @Test
    public void testSetAllWithGenerator() {
        final Integer[] array = new Integer[] {0, 0, 0};
        final Integer[] result = ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            @Override
            public Integer apply(final int index) {
                return index * 2;
            }
        });
        assertArrayEquals(new Integer[] {0, 2, 4}, result);
        assertSame(array, result);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    public void testShiftWholeArray() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] {5, 1, 2, 3, 4}, array);
    }

    @Test
    public void testShiftNegativeOffset() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, -1);
        assertArrayEquals(new int[] {2, 3, 4, 5, 1}, array);
    }

    @Test
    public void testShiftNullArrayDoesNotThrow() {
        ArrayUtils.shift((int[]) null, 1);
    }

    // ---------------------------------------------------------------
    // startsWith
    // ---------------------------------------------------------------

    @Test
    public void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2, 3, 4}));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, null));
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    public void testSubarrayBasic() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3, 4}, ArrayUtils.subarray(array, 1, 4));
    }

    @Test
    public void testSubarrayClampsEndIndex() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 100));
    }

    @Test
    public void testSubarrayNegativeStartTreatedAsZero() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.subarray(array, -5, 3));
    }

    @Test
    public void testSubarrayEmptyWhenStartAfterEnd() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
    }

    @Test
    public void testSubarrayNullReturnsNull() {
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    public void testSwapTwoElements() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1, 4}, array);
    }

    @Test
    public void testSwapWithLength() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 3, 3);
        assertArrayEquals(new int[] {4, 2, 3, 1}, array);
    }

    @Test
    public void testSwapNegativeIndicesPromotedToZero() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, -3, 2, 2);
        assertArrayEquals(new int[] {3, 4, 1, 2}, array);
    }

    @Test
    public void testSwapNullArrayDoesNotThrow() {
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    // ---------------------------------------------------------------
    // toArray / toMap
    // ---------------------------------------------------------------

    @Test
    public void testToArray() {
        final String[] result = ArrayUtils.toArray("a", "b");
        assertArrayEquals(new String[] {"a", "b"}, result);
    }

    @Test
    public void testToMapWithEntries() {
        final Map<Object, Object> map = ArrayUtils.toMap(new Object[] {
            new AbstractMap.SimpleEntry<Object, Object>("key1", "value1"),
            new Object[] {"key2", "value2"}
        });
        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));
        assertEquals(2, map.size());
    }

    @Test
    public void testToMapNullReturnsNull() {
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    public void testToMapInvalidElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {"not a pair"});
            }
        });
    }

    @Test
    public void testToMapShortArrayElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {new Object[] {"onlyKey"}});
            }
        });
    }

    // ---------------------------------------------------------------
    // toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    public void testToObjectInt() {
        final Integer[] result = ArrayUtils.toObject(new int[] {1, 2, 3});
        assertArrayEquals(new Integer[] {1, 2, 3}, result);
    }

    @Test
    public void testToPrimitiveInteger() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] {1, 2, 3});
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testToPrimitiveIntegerWithNullElementThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] {1, null, 3});
            }
        });
    }

    @Test
    public void testToPrimitiveIntegerWithDefaultForNull() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, -1);
        assertArrayEquals(new int[] {1, -1, 3}, result);
    }

    @Test
    public void testToPrimitiveNullArrayReturnsNull() {
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    // ---------------------------------------------------------------
    // toString / toStringArray
    // ---------------------------------------------------------------

    @Test
    public void testToStringNullArray() {
        assertEquals("{}", ArrayUtils.toString(null));
    }

    @Test
    public void testToStringNullArrayWithDefault() {
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
    }

    @Test
    public void testToStringWithContents() {
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] {1, 2, 3}));
    }

    @Test
    public void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {"a", 1, null});
        assertArrayEquals(new String[] {"a", "1", "null"}, result);
    }

    @Test
    public void testToStringArrayWithNullElementsReplacement() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {"a", null}, "<null>");
        assertArrayEquals(new String[] {"a", "<null>"}, result);
    }

    @Test
    public void testToStringArrayNullArrayReturnsNull() {
        assertNull(ArrayUtils.toStringArray(null));
    }

    // ---------------------------------------------------------------
    // getComponentType / getDimensions / newInstance
    // ---------------------------------------------------------------

    @Test
    public void testGetComponentType() {
        assertSame(String.class, ArrayUtils.getComponentType(new String[0]));
    }

    @Test
    public void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(1, ArrayUtils.getDimensions(new int[3]));
        assertEquals(2, ArrayUtils.getDimensions(new int[3][2]));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
    }

    @Test
    public void testNewInstance() {
        final String[] result = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, result.length);
        assertSame(String.class, result.getClass().getComponentType());
    }
}
