/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    private static class Bounded<T extends Number> {
        // fixture for bounded type variable tests
    }

    private interface SelfReferential<T extends SelfReferential<T>> {
        // fixture for cyclical class detection
    }

    private static class StringList extends ArrayList<String> {
        private static final long serialVersionUID = 1L;
    }

    private static class Outer<K> {
        class Inner<V> {
            // fixture for owner type tests
        }
    }

    // --- toString(Type) ---

    @Test
    void testToStringClass() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
    }

    @Test
    void testToStringArrayClass() {
        assertEquals("java.lang.String[]", TypeUtils.toString(String[].class));
    }

    @Test
    void testToStringCyclicalClass() {
        assertEquals("SelfReferential(cycle)", TypeUtils.toString(SelfReferential.class));
    }

    @Test
    void testToStringParameterizedType() {
        final ParameterizedType type = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(type));
    }

    @Test
    void testToStringGenericArrayType() {
        final GenericArrayType type = TypeUtils.genericArrayType(String.class);
        assertEquals("java.lang.String[]", TypeUtils.toString(type));
    }

    @Test
    void testToStringWildcardAll() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testToStringWildcardUpperBound() {
        final WildcardType type = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals("? extends java.lang.Number", TypeUtils.toString(type));
    }

    @Test
    void testToStringWildcardLowerBound() {
        final WildcardType type = TypeUtils.wildcardType().withLowerBounds(Number.class).build();
        assertEquals("? super java.lang.Number", TypeUtils.toString(type));
    }

    @Test
    void testToStringTypeVariableNoExplicitBound() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertEquals("E", TypeUtils.toString(e));
    }

    @Test
    void testToStringTypeVariableWithBound() {
        final TypeVariable<?> t = Bounded.class.getTypeParameters()[0];
        assertEquals("T extends java.lang.Number", TypeUtils.toString(t));
    }

    @Test
    void testToStringNullThrowsNullPointerException() {
        try {
            TypeUtils.toString(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- toLongString(TypeVariable) ---

    @Test
    void testToLongString() {
        final TypeVariable<?> t = Bounded.class.getTypeParameters()[0];
        final String expected = TypeUtilsAgentTest.class.getName() + ".Bounded:T extends java.lang.Number";
        assertEquals(expected, TypeUtils.toLongString(t));
    }

    @Test
    void testToLongStringNullThrowsNullPointerException() {
        try {
            TypeUtils.toLongString(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- genericArrayType ---

    @Test
    void testGenericArrayType() {
        final GenericArrayType type = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, type.getGenericComponentType());
    }

    @Test
    void testGenericArrayTypeNullThrowsNullPointerException() {
        try {
            TypeUtils.genericArrayType(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- getArrayComponentType ---

    @Test
    void testGetArrayComponentTypeClass() {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
    }

    @Test
    void testGetArrayComponentTypePrimitiveArray() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
    }

    @Test
    void testGetArrayComponentTypeNonArrayReturnsNull() {
        assertNull(TypeUtils.getArrayComponentType(String.class));
    }

    @Test
    void testGetArrayComponentTypeGenericArrayType() {
        final GenericArrayType type = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(type));
    }

    // --- isArrayType ---

    @Test
    void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertFalse(TypeUtils.isArrayType(List.class));
    }

    // --- parameterize / parameterizeWithOwner ---

    @Test
    void testParameterizeBasic() {
        final ParameterizedType type = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, type.getRawType());
        assertArrayEquals(new Type[] {String.class}, type.getActualTypeArguments());
        assertNull(type.getOwnerType());
    }

    @Test
    void testParameterizeWithMap() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(e, Integer.class);
        final ParameterizedType type = TypeUtils.parameterize(List.class, map);
        assertArrayEquals(new Type[] {Integer.class}, type.getActualTypeArguments());
    }

    @Test
    void testParameterizeWrongArgumentCountThrowsIllegalArgumentException() {
        try {
            TypeUtils.parameterize(List.class);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeNullElementThrowsIllegalArgumentException() {
        try {
            TypeUtils.parameterize(List.class, (Type) null);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeNullRawClassThrowsNullPointerException() {
        try {
            TypeUtils.parameterize(null, String.class);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeNullMapThrowsNullPointerException() {
        try {
            TypeUtils.parameterize(List.class, (Map<TypeVariable<?>, Type>) null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeWithOwnerTopLevelClassRejectsOwner() {
        try {
            TypeUtils.parameterizeWithOwner(String.class, List.class, String.class);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeWithOwnerInvalidOwnerThrowsIllegalArgumentException() {
        try {
            TypeUtils.parameterizeWithOwner(String.class, Outer.Inner.class, Integer.class);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testParameterizeWithOwnerValid() {
        final ParameterizedType owner = TypeUtils.parameterize(Outer.class, String.class);
        final ParameterizedType type = TypeUtils.parameterizeWithOwner(owner, Outer.Inner.class, Integer.class);
        assertEquals(owner, type.getOwnerType());
        assertArrayEquals(new Type[] {Integer.class}, type.getActualTypeArguments());
    }

    // --- getTypeArguments ---

    @Test
    void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType type = TypeUtils.parameterize(Map.class, String.class, Integer.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(type);
        final TypeVariable<?> k = Map.class.getTypeParameters()[0];
        final TypeVariable<?> v = Map.class.getTypeParameters()[1];
        assertEquals(String.class, args.get(k));
        assertEquals(Integer.class, args.get(v));
    }

    @Test
    void testGetTypeArgumentsSubtypeToSupertype() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringList.class, List.class);
        assertNotNull(args);
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(e));
    }

    @Test
    void testGetTypeArgumentsNotAssignableReturnsNull() {
        assertNull(TypeUtils.getTypeArguments(StringList.class, Set.class));
    }

    // --- determineTypeArguments ---

    @Test
    void testDetermineTypeArguments() {
        final ParameterizedType superType = TypeUtils.parameterize(Collection.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(ArrayList.class, superType);
        final TypeVariable<?> arrayListVar = ArrayList.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(arrayListVar));
    }

    @Test
    void testDetermineTypeArgumentsSameClass() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(List.class, superType);
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(e));
    }

    @Test
    void testDetermineTypeArgumentsNotAssignableReturnsNull() {
        final ParameterizedType superType = TypeUtils.parameterize(List.class, String.class);
        assertNull(TypeUtils.determineTypeArguments(HashMap.class, superType));
    }

    @Test
    void testDetermineTypeArgumentsNullClsThrowsNullPointerException() {
        try {
            TypeUtils.determineTypeArguments(null, TypeUtils.parameterize(List.class, String.class));
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testDetermineTypeArgumentsNullSuperTypeThrowsNullPointerException() {
        try {
            TypeUtils.determineTypeArguments(ArrayList.class, null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- isAssignable ---

    @Test
    void testIsAssignableClasses() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
    }

    @Test
    void testIsAssignableNullTypeToNonPrimitiveClassIsTrue() {
        assertTrue(TypeUtils.isAssignable((Type) null, String.class));
    }

    @Test
    void testIsAssignableNullTypeToPrimitiveClassIsFalse() {
        assertFalse(TypeUtils.isAssignable((Type) null, int.class));
    }

    @Test
    void testIsAssignableToNullToTypeIsFalse() {
        assertFalse(TypeUtils.isAssignable(String.class, (Type) null));
    }

    @Test
    void testIsAssignableGenericsInvariance() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfObject = TypeUtils.parameterize(List.class, Object.class);
        assertFalse(TypeUtils.isAssignable(listOfString, listOfObject));
    }

    @Test
    void testIsAssignableWildcardCovariance() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfWildcard = TypeUtils.parameterize(List.class, TypeUtils.WILDCARD_ALL);
        assertTrue(TypeUtils.isAssignable(listOfString, listOfWildcard));
    }

    @Test
    void testIsAssignableRawToParameterizedUnchecked() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isAssignable(List.class, listOfString));
    }

    @Test
    void testIsAssignableClassOfTIsInvariant() {
        final ParameterizedType classOfInteger = TypeUtils.parameterize(Class.class, Integer.class);
        final ParameterizedType classOfNumber = TypeUtils.parameterize(Class.class, Number.class);
        assertFalse(TypeUtils.isAssignable(classOfInteger, classOfNumber));
    }

    @Test
    void testIsAssignableClassOfTToClassOfWildcard() {
        final ParameterizedType classOfInteger = TypeUtils.parameterize(Class.class, Integer.class);
        final WildcardType extendsNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final ParameterizedType classOfExtendsNumber = TypeUtils.parameterize(Class.class, extendsNumber);
        assertTrue(TypeUtils.isAssignable(classOfInteger, classOfExtendsNumber));
    }

    // --- isInstance ---

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(5), String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("hello", null));
    }

    // --- containsTypeVariables ---

    @Test
    void testContainsTypeVariables() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(e));
        assertTrue(TypeUtils.containsTypeVariables(List.class));
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.parameterize(List.class, String.class)));
        assertTrue(TypeUtils.containsTypeVariables(TypeUtils.parameterize(List.class, e)));
    }

    // --- typesSatisfyVariables ---

    @Test
    void testTypesSatisfyVariables() {
        final TypeVariable<?> t = Bounded.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(t, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
        map.put(t, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    void testTypesSatisfyVariablesNullThrowsNullPointerException() {
        try {
            TypeUtils.typesSatisfyVariables(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- unrollVariables ---

    @Test
    void testUnrollVariables() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> assigns = new HashMap<TypeVariable<?>, Type>();
        assigns.put(e, String.class);
        final Type listOfE = TypeUtils.parameterize(List.class, e);
        final Type unrolled = TypeUtils.unrollVariables(assigns, listOfE);
        assertEquals(TypeUtils.parameterize(List.class, String.class), unrolled);
    }

    @Test
    void testUnrollVariablesUnmappedReturnsNull() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertNull(TypeUtils.unrollVariables(null, e));
    }

    // --- normalizeUpperBounds ---

    @Test
    void testNormalizeUpperBoundsSingle() {
        final Type[] bounds = {Number.class};
        assertArrayEquals(bounds, TypeUtils.normalizeUpperBounds(bounds));
    }

    @Test
    void testNormalizeUpperBoundsRemovesRedundantSupertype() {
        final Type[] bounds = {Collection.class, List.class};
        final Type[] result = TypeUtils.normalizeUpperBounds(bounds);
        assertArrayEquals(new Type[] {List.class}, result);
    }

    @Test
    void testNormalizeUpperBoundsNullThrowsNullPointerException() {
        try {
            TypeUtils.normalizeUpperBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- getImplicitBounds / getImplicitLowerBounds / getImplicitUpperBounds ---

    @Test
    void testGetImplicitBoundsUnbounded() {
        final TypeVariable<?> e = List.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitBounds(e));
    }

    @Test
    void testGetImplicitBoundsBounded() {
        final TypeVariable<?> t = Bounded.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] {Number.class}, TypeUtils.getImplicitBounds(t));
    }

    @Test
    void testGetImplicitBoundsNullThrowsNullPointerException() {
        try {
            TypeUtils.getImplicitBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testGetImplicitLowerBoundsDefault() {
        assertArrayEquals(new Type[] {null}, TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testGetImplicitLowerBoundsNullThrowsNullPointerException() {
        try {
            TypeUtils.getImplicitLowerBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testGetImplicitUpperBoundsDefault() {
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testGetImplicitUpperBoundsNullThrowsNullPointerException() {
        try {
            TypeUtils.getImplicitUpperBounds(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- WildcardTypeBuilder / wildcardType ---

    @Test
    void testWildcardTypeBuilderDefaults() {
        final WildcardType type = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[] {Object.class}, type.getUpperBounds());
        assertArrayEquals(new Type[0], type.getLowerBounds());
    }

    @Test
    void testWildcardAllConstant() {
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.WILDCARD_ALL.getUpperBounds());
    }

    // --- equals(Type, Type) ---

    @Test
    void testEqualsSameClass() {
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
    }

    @Test
    void testEqualsParameterizedType() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType c = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.equals(a, b));
        assertFalse(TypeUtils.equals(a, c));
    }

    @Test
    void testEqualsGenericArrayType() {
        final GenericArrayType a = TypeUtils.genericArrayType(String.class);
        final GenericArrayType b = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(a, b));
    }

    @Test
    void testEqualsWildcardType() {
        final WildcardType a = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType b = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.equals(a, b));
    }

    // --- wrap ---

    @Test
    void testWrapClass() {
        assertEquals(String.class, TypeUtils.wrap(String.class).getType());
    }

    @Test
    void testWrapType() {
        final ParameterizedType type = TypeUtils.parameterize(List.class, String.class);
        assertEquals(type, TypeUtils.wrap((Type) type).getType());
    }
}
