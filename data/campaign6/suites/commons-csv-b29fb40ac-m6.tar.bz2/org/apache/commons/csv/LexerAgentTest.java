/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testNextTokenSimpleRecord() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b,c\n");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a", token1.content.toString());

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token2.type);
        assertEquals("b", token2.content.toString());

        final Token token3 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token3.type);
        assertEquals("c", token3.content.toString());

        final Token token4 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token4.type);
        assertFalse(token4.isReady);
        assertEquals("", token4.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEmptyInput() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenEofWithDataNoTrailingNewline() throws IOException {
        // No trailing newline: last token is EOF but carries data (isReady == true)
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a", token1.content.toString());

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token2.type);
        assertTrue(token2.isReady);
        assertEquals("b", token2.content.toString());
        lexer.close();
    }

    @Test
    void testQuotedToken() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a,b\",c\n");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a,b", token1.content.toString());
        assertTrue(token1.isQuoted);

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token2.type);
        assertEquals("c", token2.content.toString());
        assertFalse(token2.isQuoted);
        lexer.close();
    }

    @Test
    void testQuotedTokenWithDoubledQuoteEscaping() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\"b\",c\n");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a\"b", token1.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenEofBeforeClosingQuoteThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(false).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        assertTrue(e.getMessage().contains("EOF reached before encapsulated token finished"));
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenLenientEofReturnsPartialToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenInvalidCharacterBetweenQuoteAndDelimiterThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(false).get();
        final Lexer lexer = createLexer(format, "\"ab\"x,c\n");
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        assertTrue(e.getMessage().contains("Invalid character between encapsulated token and delimiter"));
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenAllowsWhitespaceBetweenQuoteAndDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(false).get();
        final Lexer lexer = createLexer(format, "\"ab\"  ,c\n");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("ab", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenTrailingDataAppendsInsteadOfThrowing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"ab\"x,c\n");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abx", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapedDelimiterKeptAsPartOfToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\,b,c\n");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a,b", token1.content.toString());

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token2.type);
        assertEquals("c", token2.content.toString());
        lexer.close();
    }

    @Test
    void testCommentLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "# a comment\na,b\n");
        final Token commentToken = lexer.nextToken(new Token());
        assertEquals(Token.Type.COMMENT, commentToken.type);
        assertEquals("a comment", commentToken.content.toString());

        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a", token1.content.toString());

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token2.type);
        assertEquals("b", token2.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        // CSVFormat.DEFAULT has ignoreEmptyLines == true
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\n\na\n");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testEmptyLineAtEndOfFileWithIgnoreEmptyLinesReturnsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\n\n");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token1.type);
        assertEquals("a", token1.content.toString());

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token2.type);
        assertFalse(token2.isReady);
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsWhitespace() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  ,  b  \n");
        final Token token1 = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token1.type);
        assertEquals("a", token1.content.toString());

        final Token token2 = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token2.type);
        assertEquals("b", token2.content.toString());
        lexer.close();
    }

    @Test
    void testReadEscapeLetterMappings() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "r");
        assertEquals(Constants.CR, lexer.readEscape());
        lexer.close();

        final Lexer lexerN = createLexer(CSVFormat.DEFAULT, "n");
        assertEquals(Constants.LF, lexerN.readEscape());
        lexerN.close();

        final Lexer lexerT = createLexer(CSVFormat.DEFAULT, "t");
        assertEquals(Constants.TAB, lexerT.readEscape());
        lexerT.close();

        final Lexer lexerB = createLexer(CSVFormat.DEFAULT, "b");
        assertEquals(Constants.BACKSPACE, lexerB.readEscape());
        lexerB.close();

        final Lexer lexerF = createLexer(CSVFormat.DEFAULT, "f");
        assertEquals(Constants.FF, lexerF.readEscape());
        lexerF.close();
    }

    @Test
    void testReadEscapeLiteralControlCharactersPassThrough() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, String.valueOf(Constants.CR));
        assertEquals(Constants.CR, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeMetaCharacterReturnsItself() throws IOException {
        // The default quote character '"' is a meta character.
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"");
        assertEquals('"', lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeUnexpectedCharacterReturnsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "z");
        assertEquals(EOF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeAtEndOfStreamThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        assertTrue(e.getMessage().contains("EOF while processing escape sequence"));
        lexer.close();
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('a'));
    }

    @Test
    void testIsDelimiterMultiCharMatches() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(":x"));
        final Lexer lexer = new Lexer(format, reader);
        assertTrue(lexer.isDelimiter(':'));
        // The second ':' of the delimiter has been consumed from the reader.
        assertEquals('x', reader.read());
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharNoMatchDoesNotConsume() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("x")); // expects ':'
        final Lexer lexer = new Lexer(format, reader);
        assertFalse(lexer.isDelimiter(':'));
        // Non-matching lookahead must not be consumed.
        assertEquals('x', reader.read());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterMatchConsumesDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(",X"));
        final Lexer lexer = new Lexer(format, reader);
        assertTrue(lexer.isEscapeDelimiter());
        assertEquals('X', reader.read());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterNoMatchDoesNotConsume() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("X"));
        final Lexer lexer = new Lexer(format, reader);
        assertFalse(lexer.isEscapeDelimiter());
        assertEquals('X', reader.read());
        lexer.close();
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));
    }

    @Test
    void testIsQuoteCharAndIsEscapeAndIsCommentStart() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "");
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('/'));
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('@'));
    }

    @Test
    void testIsQuoteCharDisabledNeverMatchesRealQuoteChar() {
        // No quote character configured: disabled sentinel must not spuriously match a real quote char.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        final Lexer lexer = createLexer(format, "");
        assertFalse(lexer.isQuoteChar('"'));
    }

    @Test
    void testReadEndOfLineDetectsCrLfAsSingleEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\r\nb");
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());
        assertEquals(Constants.CRLF, lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineDetectsPlainLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\nb");
        lexer.nextToken(new Token());
        assertEquals("\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineDetectsPlainCr() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\rb");
        lexer.nextToken(new Token());
        assertEquals("\r", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testGetFirstEolIsNullBeforeAnyEolSeen() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        assertEquals(null, lexer.getFirstEol());
    }

    @Test
    void testPositionAndLineNumberTracking() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "ab\ncd\n");
        assertEquals(0, lexer.getCharacterPosition());
        assertEquals(0, lexer.getCurrentLineNumber());

        lexer.nextToken(new Token());
        assertEquals(3, lexer.getCharacterPosition());
        assertEquals(1, lexer.getCurrentLineNumber());

        lexer.nextToken(new Token());
        assertEquals(6, lexer.getCharacterPosition());
        assertEquals(2, lexer.getCurrentLineNumber());
        lexer.close();
    }

    @Test
    void testGetBytesReadWithoutCharsetTrackingStaysZero() throws IOException {
        // The Lexer constructor wraps callers' readers without byte tracking enabled.
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc\n");
        lexer.nextToken(new Token());
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\n");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testNextTokenAfterCloseThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\n");
        lexer.close();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());

        final StringBuilder onlySpaces = new StringBuilder("    ");
        lexer.trimTrailingSpaces(onlySpaces);
        assertEquals("", onlySpaces.toString());

        final StringBuilder noSpaces = new StringBuilder("xyz");
        lexer.trimTrailingSpaces(noSpaces);
        assertEquals("xyz", noSpaces.toString());
    }
}
