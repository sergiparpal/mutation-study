/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date buildDate(final TimeZone tz, final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = new GregorianCalendar(tz, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    @Test
    void testFormatDateMatchesSimpleDateFormat() throws Exception {
        final String pattern = "yyyy-MM-dd HH:mm:ss.SSS EEE MMM a G";
        final Date date = buildDate(UTC, 2023, Calendar.MARCH, 15, 13, 45, 30, 123);

        final FastDatePrinter printer = new FastDatePrinter(pattern, UTC, Locale.US);
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);

        assertEquals(sdf.format(date), printer.format(date));
    }

    @Test
    void testFormatLongMillisMatchesSimpleDateFormat() {
        final String pattern = "yyyy/MM/dd";
        final Date date = buildDate(UTC, 1999, Calendar.DECEMBER, 31, 0, 0, 0, 0);

        final FastDatePrinter printer = new FastDatePrinter(pattern, UTC, Locale.US);
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);

        assertEquals(sdf.format(date), printer.format(date.getTime()));
    }

    @Test
    void testFormatCalendarUsesPrinterTimeZoneNotCalendarTimeZone() {
        final TimeZone easternLike = TimeZone.getTimeZone("America/New_York");
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);

        final Calendar cal = Calendar.getInstance(easternLike, Locale.US);
        cal.clear();
        cal.set(2020, Calendar.JUNE, 1, 10, 0, 0);

        // Same instant, formatted with a calendar in a different zone than the printer.
        final Calendar calUtc = Calendar.getInstance(UTC, Locale.US);
        calUtc.setTimeInMillis(cal.getTimeInMillis());

        assertEquals(printer.format(calUtc), printer.format(cal));
    }

    @Test
    void testFormatCalendarDoesNotMutateInput() {
        final TimeZone other = TimeZone.getTimeZone("Asia/Tokyo");
        final FastDatePrinter printer = new FastDatePrinter("HH:mm", UTC, Locale.US);

        final Calendar cal = Calendar.getInstance(other, Locale.US);
        cal.set(2021, Calendar.JANUARY, 1, 5, 30, 0);
        final TimeZone originalZone = cal.getTimeZone();

        printer.format(cal, new StringBuilder());

        assertEquals(originalZone, cal.getTimeZone());
    }

    @Test
    void testFormatCalendarConvertsToPrinterTimeZoneWithoutPriorMillisAccess() {
        // The Calendar's fields are set but its time-in-millis is never read before formatting,
        // which is the normal way to build and use a Calendar.
        final TimeZone tokyo = TimeZone.getTimeZone("Asia/Tokyo");
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);

        final Calendar cal = Calendar.getInstance(tokyo, Locale.US);
        cal.set(2021, Calendar.JANUARY, 1, 5, 30, 0);
        cal.set(Calendar.MILLISECOND, 0);

        // 2021-01-01 05:30:00 Asia/Tokyo (UTC+9) is 2020-12-31 20:30:00 UTC. Per the documented
        // contract, the printer's own TimeZone (UTC) determines the TimeZone used in the output.
        assertEquals("2020-12-31 20:30:00", printer.format(cal));
    }

    @Test
    void testFormatCalendarStringBufferConvertsToPrinterTimeZoneWithoutPriorMillisAccess() {
        final TimeZone tokyo = TimeZone.getTimeZone("Asia/Tokyo");
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);

        final Calendar cal = Calendar.getInstance(tokyo, Locale.US);
        cal.set(2021, Calendar.JANUARY, 1, 5, 30, 0);
        cal.set(Calendar.MILLISECOND, 0);

        assertEquals("2020-12-31 20:30:00", printer.format(cal, new StringBuffer()).toString());
    }

    @Test
    void testGetPatternTimeZoneLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        assertEquals("yyyy", printer.getPattern());
        assertEquals(UTC, printer.getTimeZone());
        assertEquals(Locale.US, printer.getLocale());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final SimpleTimeZone mutable = new SimpleTimeZone(3600000, "FDP_TEST_ZONE");
        final FastDatePrinter printer = new FastDatePrinter("Z", mutable, Locale.US);

        final TimeZone returned = printer.getTimeZone();
        returned.setRawOffset(999);

        assertEquals(3600000, printer.getTimeZone().getRawOffset());
    }

    @Test
    void testConstructorClonesTimeZoneDefensively() {
        final SimpleTimeZone mutable = new SimpleTimeZone(3600000, "FDP_TEST_ZONE2");
        final FastDatePrinter printer = new FastDatePrinter("Z", mutable, Locale.US);

        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final String before = printer.format(date);

        // Mutate the original time zone object after construction.
        mutable.setRawOffset(0);

        final String after = printer.format(date);
        assertEquals(before, after, "Printer should not be affected by later mutation of the TimeZone passed to its constructor");
        assertEquals("+0100", before);
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDatePrinter a = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter b = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter diffPattern = new FastDatePrinter("MM-dd-yyyy", UTC, Locale.US);
        final FastDatePrinter diffZone = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDatePrinter diffLocale = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());

        assertFalse(a.equals(diffPattern));
        assertFalse(a.equals(diffZone));
        assertFalse(a.equals(diffLocale));
        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZoneId() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final String s = printer.toString();
        assertTrue(s.contains("yyyy"));
        assertTrue(s.contains("UTC"));
    }

    @Test
    void testConstructorNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testConstructorNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructorNullLocaleThrowsNullPointerException() {
        // Javadoc on the constructor documents: "Thrown if pattern, timeZone, or locale is null."
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy", UTC, null);
            }
        });
    }

    @Test
    void testIllegalPatternComponentThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("qqqq", UTC, Locale.US);
            }
        });
    }

    @Test
    void testEscapedSingleQuoteLiteral() {
        final FastDatePrinter printer = new FastDatePrinter("''", UTC, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("'", printer.format(date));
    }

    @Test
    void testQuotedLiteralText() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy'-literal-'MM", UTC, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.MARCH, 1, 0, 0, 0, 0);
        assertEquals("2020-literal-03", printer.format(date));
    }

    @Test
    void testTwelveHourFieldMidnightIsTwelve() {
        final FastDatePrinter printer = new FastDatePrinter("h", UTC, Locale.US);
        final Date midnight = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date noon = buildDate(UTC, 2020, Calendar.JANUARY, 1, 12, 0, 0, 0);
        assertEquals("12", printer.format(midnight));
        assertEquals("12", printer.format(noon));
    }

    @Test
    void testTwentyFourHourFieldMidnightIsTwentyFour() {
        final FastDatePrinter printer = new FastDatePrinter("k", UTC, Locale.US);
        final Date midnight = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date oneAm = buildDate(UTC, 2020, Calendar.JANUARY, 1, 1, 0, 0, 0);
        assertEquals("24", printer.format(midnight));
        assertEquals("1", printer.format(oneAm));
    }

    @Test
    void testHourInDayZeroBased() {
        final FastDatePrinter printer = new FastDatePrinter("HH", UTC, Locale.US);
        final Date midnight = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("00", printer.format(midnight));
    }

    @Test
    void testDayInWeekFieldIsoNumbering() {
        final FastDatePrinter printer = new FastDatePrinter("u", UTC, Locale.US);
        // 2024-01-01 is a Monday, 2024-01-07 is a Sunday.
        final Date monday = buildDate(UTC, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date sunday = buildDate(UTC, 2024, Calendar.JANUARY, 7, 0, 0, 0, 0);
        assertEquals("1", printer.format(monday));
        assertEquals("7", printer.format(sunday));
    }

    @Test
    void testWeekYearPatternMatchesSimpleDateFormat() {
        final String pattern = "YYYY-ww";
        // 2023-01-01 is a Sunday; depending on locale week rules it may belong to the previous week-year.
        final Date date = buildDate(UTC, 2023, Calendar.JANUARY, 1, 0, 0, 0, 0);

        final FastDatePrinter printer = new FastDatePrinter(pattern, UTC, Locale.US);
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);

        assertEquals(sdf.format(date), printer.format(date));
    }

    @Test
    void testTwoDigitYearTruncates() {
        final FastDatePrinter printer = new FastDatePrinter("yy", UTC, Locale.US);
        final Date date = buildDate(UTC, 2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("05", printer.format(date));
    }

    @Test
    void testSingleYPatternIsPaddedToFourDigitsMinimum() {
        final FastDatePrinter printer = new FastDatePrinter("y", UTC, Locale.US);
        final Date smallYear = buildDate(UTC, 5, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date normalYear = buildDate(UTC, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("0005", printer.format(smallYear));
        assertEquals("2024", printer.format(normalYear));
    }

    @Test
    void testZeroOffsetTimeZoneNumberPatterns() {
        final FastDatePrinter zPrinter = new FastDatePrinter("Z", UTC, Locale.US);
        final FastDatePrinter zzPrinter = new FastDatePrinter("ZZ", UTC, Locale.US);
        final FastDatePrinter zzzPrinter = new FastDatePrinter("ZZZ", UTC, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("+0000", zPrinter.format(date));
        assertEquals("Z", zzPrinter.format(date));
        assertEquals("+00:00", zzzPrinter.format(date));
    }

    @Test
    void testNonZeroOffsetTimeZoneNumberPatterns() {
        final TimeZone offsetZone = new SimpleTimeZone(5 * 60 * 60 * 1000 + 30 * 60 * 1000, "FDP_TEST_OFFSET");
        final FastDatePrinter zPrinter = new FastDatePrinter("Z", offsetZone, Locale.US);
        final FastDatePrinter zzPrinter = new FastDatePrinter("ZZ", offsetZone, Locale.US);
        final FastDatePrinter zzzPrinter = new FastDatePrinter("ZZZ", offsetZone, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("+0530", zPrinter.format(date));
        assertEquals("+05:30", zzPrinter.format(date));
        assertEquals("+05:30", zzzPrinter.format(date));
    }

    @Test
    void testIso8601PatternZeroOffsetIsZ() {
        final FastDatePrinter x1 = new FastDatePrinter("X", UTC, Locale.US);
        final FastDatePrinter x2 = new FastDatePrinter("XX", UTC, Locale.US);
        final FastDatePrinter x3 = new FastDatePrinter("XXX", UTC, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("Z", x1.format(date));
        assertEquals("Z", x2.format(date));
        assertEquals("Z", x3.format(date));
    }

    @Test
    void testIso8601PatternNonZeroOffset() {
        final TimeZone offsetZone = new SimpleTimeZone(5 * 60 * 60 * 1000 + 30 * 60 * 1000, "FDP_TEST_OFFSET2");
        final FastDatePrinter x1 = new FastDatePrinter("X", offsetZone, Locale.US);
        final FastDatePrinter x2 = new FastDatePrinter("XX", offsetZone, Locale.US);
        final FastDatePrinter x3 = new FastDatePrinter("XXX", offsetZone, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("+05", x1.format(date));
        assertEquals("+0530", x2.format(date));
        assertEquals("+05:30", x3.format(date));
    }

    @Test
    void testIso8601InvalidTokenLengthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testTimeZoneNameRuleMatchesTimeZoneDisplayName() {
        final TimeZone tokyo = TimeZone.getTimeZone("Asia/Tokyo");
        final FastDatePrinter longPrinter = new FastDatePrinter("zzzz", tokyo, Locale.US);
        final FastDatePrinter shortPrinter = new FastDatePrinter("z", tokyo, Locale.US);
        final Date date = buildDate(tokyo, 2020, Calendar.JUNE, 1, 0, 0, 0, 0);

        final String expectedLong = tokyo.getDisplayName(false, TimeZone.LONG, Locale.US);
        final String expectedShort = tokyo.getDisplayName(false, TimeZone.SHORT, Locale.US);

        assertEquals(expectedLong, longPrinter.format(date));
        assertEquals(expectedShort, shortPrinter.format(date));
    }

    @Test
    void testDayOfYearUnpadded() {
        final FastDatePrinter printer = new FastDatePrinter("D", UTC, Locale.US);
        final Date lastDayNonLeap = buildDate(UTC, 2023, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        final Date lastDayLeap = buildDate(UTC, 2024, Calendar.DECEMBER, 31, 0, 0, 0, 0);

        assertEquals("365", printer.format(lastDayNonLeap));
        assertEquals("366", printer.format(lastDayLeap));
    }

    @Test
    void testEmptyPatternFormatsToEmptyStringAndZeroEstimate() {
        final FastDatePrinter printer = new FastDatePrinter("", UTC, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(0, printer.getMaxLengthEstimate());
        assertEquals("", printer.format(date));
    }

    @Test
    void testMaxLengthEstimateIsUpperBoundOfActualOutput() {
        final String[] patterns = {
            "yyyy-MM-dd HH:mm:ss.SSS EEEE MMMM a G zzzz Z",
            "yy/M/d h:mm:ss k K",
            "'literal' yyyy"
        };
        final Date[] dates = {
            buildDate(UTC, 2024, Calendar.FEBRUARY, 29, 23, 59, 59, 999),
            buildDate(UTC, 1, Calendar.JANUARY, 1, 0, 0, 0, 0),
            buildDate(UTC, 2000, Calendar.JULY, 4, 12, 0, 0, 0)
        };
        for (final String pattern : patterns) {
            final FastDatePrinter printer = new FastDatePrinter(pattern, UTC, Locale.US);
            for (final Date date : dates) {
                final String formatted = printer.format(date);
                assertTrue(formatted.length() <= printer.getMaxLengthEstimate(),
                    "pattern=" + pattern + " formatted=" + formatted + " estimate=" + printer.getMaxLengthEstimate());
            }
        }
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDatePrinter original = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        final Date date = buildDate(UTC, 2022, Calendar.MAY, 5, 6, 7, 8, 0);

        assertNotNull(deserialized);
        assertEquals(original.getPattern(), deserialized.getPattern());
        assertEquals(original.getTimeZone(), deserialized.getTimeZone());
        assertEquals(original.getLocale(), deserialized.getLocale());
        assertEquals(original.format(date), deserialized.format(date));
        assertEquals(original, deserialized);
    }

    @Test
    void testFormatObjectDispatchesByType() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);

        assertEquals(printer.format(date), printer.format((Object) date));
        assertEquals(printer.format(date), printer.format((Object) cal));
        assertEquals(printer.format(date.getTime()), printer.format((Object) Long.valueOf(date.getTime())));
    }

    @Test
    void testFormatObjectUnknownTypeThrows() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
    }

    @Test
    void testAmPmMarker() {
        final FastDatePrinter printer = new FastDatePrinter("a", UTC, Locale.US);
        final Date am = buildDate(UTC, 2020, Calendar.JANUARY, 1, 1, 0, 0, 0);
        final Date pm = buildDate(UTC, 2020, Calendar.JANUARY, 1, 13, 0, 0, 0);
        assertEquals("AM", printer.format(am));
        assertEquals("PM", printer.format(pm));
    }

    @Test
    void testPatternsWithDifferentTimeZonesAreNotEqualButFormatDifferently() {
        final FastDatePrinter utcPrinter = new FastDatePrinter("HH", UTC, Locale.US);
        final FastDatePrinter offsetPrinter = new FastDatePrinter("HH", new SimpleTimeZone(5 * 60 * 60 * 1000, "FDP_TEST_OFFSET3"), Locale.US);
        final Date date = buildDate(UTC, 2020, Calendar.JANUARY, 1, 10, 0, 0, 0);

        assertNotEquals(utcPrinter, offsetPrinter);
        assertEquals("10", utcPrinter.format(date));
        assertEquals("15", offsetPrinter.format(date));
    }
}
