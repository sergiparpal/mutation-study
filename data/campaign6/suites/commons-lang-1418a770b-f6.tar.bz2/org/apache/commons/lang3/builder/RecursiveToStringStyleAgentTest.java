/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RecursiveToStringStyle}.
 */
class RecursiveToStringStyleAgentTest {

    static class Job {
        String title;

        Job(final String title) {
            this.title = title;
        }
    }

    static class Person {
        String name;
        int age;
        boolean smoker;
        Job job;
    }

    static class WithCollection {
        List<Job> jobs = new ArrayList<>();
    }

    static class Empty {
    }

    /** accept() always returns false, so nested objects fall back to plain toString(). */
    static class RejectingStyle extends RecursiveToStringStyle {
        private static final long serialVersionUID = 1L;

        @Override
        protected boolean accept(final Class<?> clazz) {
            return false;
        }
    }

    private String getClassPrefix(final Object object) {
        return object.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(object));
    }

    private String toString(final Object object) {
        return new ReflectionToStringBuilder(object, new RecursiveToStringStyle()).toString();
    }

    @Test
    void testSimpleObjectNoFields() {
        final Empty empty = new Empty();
        final String expected = getClassPrefix(empty) + "[]";
        assertEquals(expected, toString(empty));
    }

    @Test
    void testPrimitivesAndWrapperAreNotRecursed() {
        final Person person = new Person();
        person.name = "Stephen";
        person.age = 29;
        person.smoker = false;
        person.job = null;

        final String expected = getClassPrefix(person)
                + "[age=29,job=<null>,name=Stephen,smoker=false]";
        assertEquals(expected, toString(person));
    }

    @Test
    void testNestedObjectIsRecursed() {
        final Person person = new Person();
        person.name = "Stephen";
        person.age = 29;
        person.smoker = false;
        final Job job = new Job("Manager");
        person.job = job;

        final String expected = getClassPrefix(person)
                + "[age=29,job=" + getClassPrefix(job) + "[title=Manager],name=Stephen,smoker=false]";
        assertEquals(expected, toString(person));
    }

    @Test
    void testStringFieldIsNotQuotedOrRecursed() {
        final Job job = new Job("Manager");
        final String expected = getClassPrefix(job) + "[title=Manager]";
        assertEquals(expected, toString(job));
    }

    @Test
    void testNullStringField() {
        final Job job = new Job(null);
        final String expected = getClassPrefix(job) + "[title=<null>]";
        assertEquals(expected, toString(job));
    }

    @Test
    void testCollectionFieldAppendsClassNameAndIdentityHashCodeOfCollection() {
        final WithCollection wc = new WithCollection();
        final Job job = new Job("Manager");
        wc.jobs.add(job);

        final String expected = getClassPrefix(wc)
                + "[jobs=" + getClassPrefix(wc.jobs) + "{" + getClassPrefix(job) + "[title=Manager]}]";
        assertEquals(expected, toString(wc));
    }

    @Test
    void testEmptyCollectionField() {
        final WithCollection wc = new WithCollection();
        final String expected = getClassPrefix(wc) + "[jobs=" + getClassPrefix(wc.jobs) + "{}]";
        assertEquals(expected, toString(wc));
    }

    @Test
    void testAcceptDefaultsToTrue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertTrue(invokeAccept(style, Job.class));
        assertTrue(invokeAccept(style, String.class));
        assertTrue(invokeAccept(style, Object.class));
    }

    private boolean invokeAccept(final RecursiveToStringStyle style, final Class<?> clazz) {
        try {
            final java.lang.reflect.Method m = RecursiveToStringStyle.class.getDeclaredMethod("accept", Class.class);
            m.setAccessible(true);
            return (Boolean) m.invoke(style, clazz);
        } catch (final ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testAcceptFalseFallsBackToPlainToString() {
        final Person person = new Person();
        person.name = "Stephen";
        person.job = new Job("Manager");
        final String result = new ReflectionToStringBuilder(person, new RejectingStyle()).toString();
        // accept() == false for the nested Job type: it must not be recursed into "title=Manager",
        // falling back instead to the Job's own (default, non-overridden) Object#toString().
        assertFalse(result.contains("title=Manager"));
        assertTrue(result.contains(getClassPrefix(person.job)));
    }

    @Test
    void testAppendDetailDirectlyWithObject() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final Job job = new Job("Manager");
        style.appendDetail(buffer, "job", job);
        final String expected = getClassPrefix(job) + "[title=Manager]";
        assertEquals(expected, buffer.toString());
    }

    @Test
    void testAppendDetailDirectlyWithString() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "name", "Stephen");
        assertEquals("Stephen", buffer.toString());
    }

    @Test
    void testAppendDetailDirectlyWithPrimitiveWrapper() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "age", Integer.valueOf(29));
        assertEquals("29", buffer.toString());
    }

    @Test
    void testAppendDetailCollectionOverload() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<Job> jobs = new ArrayList<>();
        final Job job = new Job("Manager");
        jobs.add(job);
        style.appendDetail(buffer, "jobs", jobs);
        final String expected = getClassPrefix(jobs) + "{" + getClassPrefix(job) + "[title=Manager]}";
        assertEquals(expected, buffer.toString());
    }
}
