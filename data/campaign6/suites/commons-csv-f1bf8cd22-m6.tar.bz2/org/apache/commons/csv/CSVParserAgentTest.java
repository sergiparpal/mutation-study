/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
class CSVParserAgentTest {

    @Test
    void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderFromFirstLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,30\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, headerMap.size());
            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(2, headerNames.size());
            assertEquals("name", headerNames.get(0));
            assertEquals("age", headerNames.get(1));
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testExplicitHeaderNotSkipped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("x", "y").setSkipHeaderRecord(false).get();
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            // Header record is not skipped, so it is also returned as data.
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("x"));
            assertEquals("2", records.get(0).get("y"));
            assertEquals("3", records.get(1).get("x"));
            assertEquals("4", records.get(1).get("y"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoHeaderMeansNullHeaderMapAndNames() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDuplicateHeaderNamesDisallowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class,
                () -> CSVParser.parse("a,a\n1,2\n", format));
        assertTrue(thrown.getMessage().contains("duplicate"));
    }

    @Test
    void testDuplicateHeaderNamesAllowedByDefault() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        final CSVParser parser = CSVParser.parse("a,a\n1,2\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(2, headerNames.size());
            assertEquals("a", headerNames.get(0));
            assertEquals("a", headerNames.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testMissingHeaderNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertThrows(IllegalArgumentException.class, () -> CSVParser.parse("a,,c\n1,2,3\n", format));
    }

    @Test
    void testMissingHeaderNameAllowedWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setAllowMissingColumnNames(true).get();
        final CSVParser parser = CSVParser.parse("a,,c\n1,2,3\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertEquals(3, headerNames.size());
            assertEquals("a", headerNames.get(0));
            assertEquals("", headerNames.get(1));
            assertEquals("c", headerNames.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorHasNextAndNextAgreeWithNoMoreElements() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            final CSVRecord record = it.next();
            assertEquals("1", record.get(0));
            assertEquals("2", record.get(1));
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, it::next);
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, it::remove);
        } finally {
            parser.close();
        }
    }

    @Test
    void testIsClosedAndClose() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    void testIteratorReturnsNoRecordsAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testGetRecordNumberIncrements() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(0).getRecordNumber());
            assertEquals(2, records.get(1).getRecordNumber());
            assertEquals(3, records.get(2).getRecordNumber());
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.iterator().next();
            assertEquals(1, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testStream() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final long count = parser.stream().count();
            assertEquals(3, count);
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeader().get();
        final CSVParser parser = CSVParser.parse("# header comment\na,b\n1,2\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoHeaderCommentByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailerComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n# trailer\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoTrailerCommentByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testQuotedField() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a,b", records.get(0).get(0));
            assertEquals("c", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailingDelimiterDropsEmptyLastField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testNullStringMapsToNullValue() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals("a", records.get(0).get(0));
            assertNull(records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidTokenThrowsCsvException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser = CSVParser.parse("\"a\"b,c\n", format);
        try {
            final UncheckedIOException thrown = assertThrows(UncheckedIOException.class, parser::getRecords);
            assertTrue(thrown.getCause() instanceof CSVException);
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidTokenViaNextRecordThrowsCsvException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser = CSVParser.parse("\"a\"b,c\n", format);
        try {
            assertThrows(CSVException.class, parser::nextRecord);
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> CSVParser.parse((String) null, CSVFormat.DEFAULT));
    }

    @Test
    void testBuilderWithDefaultFormatWhenNullIsPassed() throws IOException {
        final CSVParser parser = CSVParser.builder().setReader(new StringReader("a,b\n")).setFormat(null).get();
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testBuilderRecordNumberStartsAtGivenValue() throws IOException {
        final CSVParser parser = CSVParser.builder().setReader(new StringReader("a\nb\n")).setFormat(CSVFormat.DEFAULT).setRecordNumber(5).get();
        try {
            assertEquals(4, parser.getRecordNumber());
            final CSVRecord first = parser.iterator().next();
            assertEquals(5, first.getRecordNumber());
            assertEquals(5, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDeprecatedConstructorWithOffsetAndRecordNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\n"), CSVFormat.DEFAULT, 100, 10);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(10, record.getRecordNumber());
            assertEquals(100, record.getCharacterPosition());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDeprecatedConstructorNullFormatThrows() {
        assertThrows(NullPointerException.class, () -> new CSVParser(new StringReader("a\n"), null, 0, 1));
    }

    @Test
    void testIgnoreHeaderCase() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setIgnoreHeaderCase(true).setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("Name,Age\nJohn,30\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("John", record.get("name"));
            assertEquals("30", record.get("AGE"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetFirstEndOfLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    @Test
    void testMaxRowsLimitsIteration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapIsCopyNotLive() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("c", Integer.valueOf(99));
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse(map2.containsKey("c"));
            assertEquals(2, map2.size());
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseStringNullFormatDefaultsToCsvFormatDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", null);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }
}
