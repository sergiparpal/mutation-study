/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    @Test
    void testDefaultFormatBasics() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getTrim());
        assertFalse(format.getAllowMissingColumnNames());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getTrim());
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\r'));
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testSetDelimiterRejectsLineBreakInString() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\nb"));
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker(Character.valueOf('\r')));
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape(Character.valueOf('\r')));
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote(Character.valueOf('\r')));
    }

    @Test
    void testValidateQuoteEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testValidateEscapeEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(';').setEscape(';').get());
    }

    @Test
    void testValidateCommentEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateQuoteEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateEscapeEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeadersDisallowedThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B", "A").get());
    }

    @Test
    void testValidateDuplicateHeadersAllowAllDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B", "A").get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertTrue(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testValidateDuplicateEmptyHeadersAllowedWithAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "").get();
        assertEquals(2, countOccurrences(format.getHeader(), ""));
    }

    @Test
    void testValidateDuplicateNonEmptyHeadersDisallowedWithAllowEmpty() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get());
    }

    private static int countOccurrences(final String[] array, final String value) {
        int count = 0;
        for (final String s : array) {
            if (value.equals(s)) {
                count++;
            }
        }
        return count;
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testGetHeaderNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testBuilderCreatesIndependentCopy() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
        assertNotEquals(original, modified);
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("X", "Y").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("X", "Y").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertEquals(a, a);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
    }

    @Test
    void testEqualsDetectsDifference() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotEquals(a, b);
    }

    @Test
    void testToStringContainsDelimiterAndOtherSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setNullString("NULL").get();
        final String s = format.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("CommentStart=<#>"));
        assertTrue(s.contains("Escape=<\\>"));
        assertTrue(s.contains("NullString=<NULL>"));
    }

    @Test
    void testFormatMethod() throws IOException {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatMethodQuotesWhenNeeded() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testPrintNullValueUsesEmptyByDefault() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintNullValueUsesNullStringWhenSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testPrintAddsDelimiterWhenNotNewRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("value", sb, false);
        assertEquals(",value", sb.toString());
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b");
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        final StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",\n", sb.toString());
    }

    @Test
    void testIsSetPredicates() {
        final CSVFormat none = CSVFormat.DEFAULT.builder().setQuote(null).get();
        assertFalse(none.isQuoteCharacterSet());
        assertFalse(none.isCommentMarkerSet());
        assertFalse(none.isEscapeCharacterSet());
        assertFalse(none.isNullStringSet());

        final CSVFormat all = none.builder().setQuote('"').setCommentMarker('#').setEscape('\\').setNullString("NULL").get();
        assertTrue(all.isQuoteCharacterSet());
        assertTrue(all.isCommentMarkerSet());
        assertTrue(all.isEscapeCharacterSet());
        assertTrue(all.isNullStringSet());
    }

    @Test
    void testValueOfAndPredefined() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NoSuchFormat"));
    }

    @Test
    void testMaxRowsDefaultsToUnlimited() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        final CSVFormat limited = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertEquals(5L, limited.getMaxRows());
        assertTrue(limited.useMaxRows());
        assertTrue(limited.useRow(5));
        assertFalse(limited.useRow(6));
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').setTrim(true).setHeader("A").get();
        final CSVFormat.Builder builder = CSVFormat.Builder.create(source);
        final CSVFormat copy = builder.get();
        assertEquals(source, copy);
        assertNotSame(source, copy);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testDeprecatedWithDelimiterCreatesNewFormat() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    void testDeprecatedWithAllowDuplicateHeaderNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(format.getAllowDuplicateHeaderNames());
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
    }

    @Test
    void testDeprecatedWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testDeprecatedWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @Test
    void testDeprecatedWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    void testDeprecatedWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDeprecatedWithRecordSeparator() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator("\n").getRecordSeparator());
    }

    @Test
    void testDeprecatedWithSkipHeaderRecordAndTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
    }

    @Test
    void testDeprecatedBuildMatchesGet() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter('|');
        assertEquals(builder.get(), builder.build());
    }

    @Test
    void testPredefinedFormatsHaveExpectedSettings() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }
}
