/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link Validate}.
 */
class ValidateAgentTest {

    // ---------- isTrue ----------

    @Test
    void testIsTrue_simple_pass() {
        Validate.isTrue(true);
    }

    @Test
    void testIsTrue_simple_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false);
            }
        });
        assertEquals("The validated expression is false", e.getMessage());
    }

    @Test
    void testIsTrue_withMessageAndLong() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "value: %d", 42L);
            }
        });
        assertEquals("value: 42", e.getMessage());
    }

    @Test
    void testIsTrue_withMessageAndDouble() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "value: %s", 1.5);
            }
        });
        assertEquals("value: 1.5", e.getMessage());
    }

    @Test
    void testIsTrue_withMessageAndVarargs() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "min=%d max=%d", 1, 5);
            }
        });
        assertEquals("min=1 max=5", e.getMessage());
    }

    @Test
    void testIsTrue_withSupplier() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, new java.util.function.Supplier<String>() {
                    @Override
                    public String get() {
                        return "supplied message";
                    }
                });
            }
        });
        assertEquals("supplied message", e.getMessage());
    }

    // ---------- notNull ----------

    @Test
    void testNotNull_pass() {
        final String s = "hello";
        assertSame(s, Validate.notNull(s));
    }

    @Test
    void testNotNull_fail_defaultMessage() {
        final NullPointerException e = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null);
            }
        });
        assertEquals("The validated object is null", e.getMessage());
    }

    @Test
    void testNotNull_withMessage_fail() {
        final NullPointerException e = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null, "my %s message", "custom");
            }
        });
        assertEquals("my custom message", e.getMessage());
    }

    @Test
    void testNotNull_withMessage_pass() {
        final Object o = new Object();
        assertSame(o, Validate.notNull(o, "should not be used"));
    }

    // ---------- notEmpty (CharSequence) ----------

    @Test
    void testNotEmptyCharSequence_pass() {
        assertEquals("abc", Validate.notEmpty("abc"));
    }

    @Test
    void testNotEmptyCharSequence_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((String) null);
            }
        });
    }

    @Test
    void testNotEmptyCharSequence_emptyThrowsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty("");
            }
        });
        assertEquals("The validated character sequence is empty", e.getMessage());
    }

    @Test
    void testNotEmptyCharSequence_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty("", "custom %s", "msg");
            }
        });
        assertEquals("custom msg", e.getMessage());
    }

    // ---------- notEmpty (array) ----------

    @Test
    void testNotEmptyArray_pass() {
        final String[] array = {"a"};
        assertSame(array, Validate.notEmpty(array));
    }

    @Test
    void testNotEmptyArray_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((Object[]) null);
            }
        });
    }

    @Test
    void testNotEmptyArray_emptyThrowsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new String[0]);
            }
        });
        assertEquals("The validated array is empty", e.getMessage());
    }

    // ---------- notEmpty (collection) ----------

    @Test
    void testNotEmptyCollection_pass() {
        final List<String> list = new ArrayList<String>();
        list.add("x");
        assertSame(list, Validate.notEmpty(list));
    }

    @Test
    void testNotEmptyCollection_emptyThrowsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new ArrayList<String>());
            }
        });
        assertEquals("The validated collection is empty", e.getMessage());
    }

    @Test
    void testNotEmptyCollection_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((List<?>) null);
            }
        });
    }

    // ---------- notEmpty (map) ----------

    @Test
    void testNotEmptyMap_pass() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertSame(map, Validate.notEmpty(map));
    }

    @Test
    void testNotEmptyMap_emptyThrowsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new HashMap<String, String>());
            }
        });
        assertEquals("The validated map is empty", e.getMessage());
    }

    // ---------- notBlank ----------

    @Test
    void testNotBlank_pass() {
        assertEquals("abc", Validate.notBlank("abc"));
    }

    @Test
    void testNotBlank_blankThrowsIAE() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("   ");
            }
        });
        assertEquals("The validated character sequence is blank", e.getMessage());
    }

    @Test
    void testNotBlank_emptyThrowsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("");
            }
        });
    }

    @Test
    void testNotBlank_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank((String) null);
            }
        });
    }

    // ---------- noNullElements (array) ----------

    @Test
    void testNoNullElementsArray_pass() {
        final String[] array = {"a", "b"};
        assertSame(array, Validate.noNullElements(array));
    }

    @Test
    void testNoNullElementsArray_nullArrayThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((String[]) null);
            }
        });
    }

    @Test
    void testNoNullElementsArray_withNullElementThrowsIAE_withIndex() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(new String[] {"a", null, "c"});
            }
        });
        assertEquals("The validated array contains null element at index: 1", e.getMessage());
    }

    // ---------- noNullElements (iterable) ----------

    @Test
    void testNoNullElementsIterable_pass() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertSame(list, Validate.noNullElements(list));
    }

    @Test
    void testNoNullElementsIterable_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((List<?>) null);
            }
        });
    }

    @Test
    void testNoNullElementsIterable_withNullElementThrowsIAE_withIndex() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add(null);
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(list);
            }
        });
        assertEquals("The validated collection contains null element at index: 1", e.getMessage());
    }

    // ---------- validIndex (array) ----------

    @Test
    void testValidIndexArray_pass() {
        final String[] array = {"a", "b", "c"};
        assertSame(array, Validate.validIndex(array, 1));
    }

    @Test
    void testValidIndexArray_negativeThrows() {
        final String[] array = {"a"};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(array, -1);
            }
        });
    }

    @Test
    void testValidIndexArray_tooLargeThrows() {
        final String[] array = {"a"};
        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(array, 1);
            }
        });
        assertEquals("The validated array index is invalid: 1", e.getMessage());
    }

    @Test
    void testValidIndexArray_boundaryLastElement() {
        final String[] array = {"a", "b"};
        assertSame(array, Validate.validIndex(array, 1));
    }

    @Test
    void testValidIndexArray_nullArrayThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((String[]) null, 0);
            }
        });
    }

    // ---------- validIndex (CharSequence) ----------

    @Test
    void testValidIndexCharSequence_pass() {
        assertEquals("abc", Validate.validIndex("abc", 2));
    }

    @Test
    void testValidIndexCharSequence_tooLargeThrows() {
        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex("abc", 3);
            }
        });
        assertEquals("The validated character sequence index is invalid: 3", e.getMessage());
    }

    @Test
    void testValidIndexCharSequence_negativeThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex("abc", -1);
            }
        });
    }

    @Test
    void testValidIndexCharSequence_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((String) null, 0);
            }
        });
    }

    // ---------- validIndex (collection) ----------

    @Test
    void testValidIndexCollection_pass() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertSame(list, Validate.validIndex(list, 1));
    }

    @Test
    void testValidIndexCollection_tooLargeThrows() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        final IndexOutOfBoundsException e = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, 1);
            }
        });
        assertEquals("The validated collection index is invalid: 1", e.getMessage());
    }

    @Test
    void testValidIndexCollection_emptyAnyIndexThrows() {
        final List<String> list = new ArrayList<String>();
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, 0);
            }
        });
    }

    // ---------- validState ----------

    @Test
    void testValidState_pass() {
        Validate.validState(true);
    }

    @Test
    void testValidState_fail_defaultMessage() {
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false);
            }
        });
        assertEquals("The validated state is false", e.getMessage());
    }

    @Test
    void testValidState_withMessage() {
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false, "state is %s", "bad");
            }
        });
        assertEquals("state is bad", e.getMessage());
    }

    // ---------- matchesPattern ----------

    @Test
    void testMatchesPattern_pass() {
        Validate.matchesPattern("hi", "[a-z]*");
    }

    @Test
    void testMatchesPattern_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("Hi", "[a-z]*");
            }
        });
        assertEquals("The string Hi does not match the pattern [a-z]*", e.getMessage());
    }

    @Test
    void testMatchesPattern_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("Hi", "[a-z]*", "custom %s", "msg");
            }
        });
        assertEquals("custom msg", e.getMessage());
    }

    // ---------- notNaN / finite ----------

    @Test
    void testNotNaN_pass() {
        Validate.notNaN(1.0);
    }

    @Test
    void testNotNaN_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNaN(Double.NaN);
            }
        });
        assertEquals("The validated value is not a number", e.getMessage());
    }

    @Test
    void testFinite_pass() {
        Validate.finite(1.0);
    }

    @Test
    void testFinite_failOnNaN() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NaN);
            }
        });
    }

    @Test
    void testFinite_failOnPositiveInfinity() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.POSITIVE_INFINITY);
            }
        });
        assertTrue(e.getMessage().length() > 0);
    }

    @Test
    void testFinite_failOnNegativeInfinity() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NEGATIVE_INFINITY);
            }
        });
    }

    // ---------- inclusiveBetween (long) ----------

    @Test
    void testInclusiveBetweenLong_pass_middle() {
        Validate.inclusiveBetween(0L, 2L, 1L);
    }

    @Test
    void testInclusiveBetweenLong_pass_boundaries() {
        Validate.inclusiveBetween(0L, 2L, 0L);
        Validate.inclusiveBetween(0L, 2L, 2L);
    }

    @Test
    void testInclusiveBetweenLong_fail_below() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, -1L);
            }
        });
        assertEquals("The value -1 is not in the specified inclusive range of 0 to 2", e.getMessage());
    }

    @Test
    void testInclusiveBetweenLong_fail_above() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L);
            }
        });
    }

    @Test
    void testInclusiveBetweenLong_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L, "Not in range");
            }
        });
        assertEquals("Not in range", e.getMessage());
    }

    // ---------- inclusiveBetween (double) ----------

    @Test
    void testInclusiveBetweenDouble_pass_boundaries() {
        Validate.inclusiveBetween(0.1, 2.1, 0.1);
        Validate.inclusiveBetween(0.1, 2.1, 2.1);
    }

    @Test
    void testInclusiveBetweenDouble_fail() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 5.0);
            }
        });
    }

    // ---------- inclusiveBetween (Comparable) ----------

    @Test
    void testInclusiveBetweenComparable_pass() {
        Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1));
    }

    @Test
    void testInclusiveBetweenComparable_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3));
            }
        });
        assertEquals("The value 3 is not in the specified inclusive range of 0 to 2", e.getMessage());
    }

    @Test
    void testInclusiveBetweenComparable_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3), "bad %s", "value");
            }
        });
        assertEquals("bad value", e.getMessage());
    }

    // ---------- exclusiveBetween (long) ----------

    @Test
    void testExclusiveBetweenLong_pass() {
        Validate.exclusiveBetween(0L, 2L, 1L);
    }

    @Test
    void testExclusiveBetweenLong_fail_onBoundaries() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 0L);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 2L);
            }
        });
    }

    @Test
    void testExclusiveBetweenLong_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 2L, "Not in range");
            }
        });
        assertEquals("Not in range", e.getMessage());
    }

    // ---------- exclusiveBetween (double) ----------

    @Test
    void testExclusiveBetweenDouble_pass() {
        Validate.exclusiveBetween(0.1, 2.1, 1.1);
    }

    @Test
    void testExclusiveBetweenDouble_failOnBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 0.1);
            }
        });
    }

    // ---------- exclusiveBetween (Comparable) ----------

    @Test
    void testExclusiveBetweenComparable_pass() {
        Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1));
    }

    @Test
    void testExclusiveBetweenComparable_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(2));
            }
        });
        assertEquals("The value 2 is not in the specified exclusive range of 0 to 2", e.getMessage());
    }

    @Test
    void testExclusiveBetweenComparable_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(2), "bad %s", "value");
            }
        });
        assertEquals("bad value", e.getMessage());
    }

    // ---------- isAssignableFrom ----------

    @Test
    void testIsAssignableFrom_pass() {
        Validate.isAssignableFrom(Number.class, Integer.class);
    }

    @Test
    void testIsAssignableFrom_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(String.class, Integer.class);
            }
        });
        assertTrue(e.getMessage().contains("Integer"));
        assertTrue(e.getMessage().contains("String"));
    }

    @Test
    void testIsAssignableFrom_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(String.class, Integer.class, "cannot assign %s", "it");
            }
        });
        assertEquals("cannot assign it", e.getMessage());
    }

    // ---------- isInstanceOf ----------

    @Test
    void testIsInstanceOf_pass() {
        Validate.isInstanceOf(String.class, "hello");
    }

    @Test
    void testIsInstanceOf_fail() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, Integer.valueOf(1));
            }
        });
        assertTrue(e.getMessage().contains("String"));
    }

    @Test
    void testIsInstanceOf_withMessage() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, Integer.valueOf(1), "wrong type: %s", "int");
            }
        });
        assertEquals("wrong type: int", e.getMessage());
    }

    @Test
    void testIsInstanceOf_nullObjectFails() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, null);
            }
        });
    }

    // ---------- getMessage edge case: % in message without values ----------

    @Test
    void testIsTrue_messageWithPercentAndNoValues_notFormatted() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "100%Failed%");
            }
        });
        assertEquals("100%Failed%", e.getMessage());
    }
}
