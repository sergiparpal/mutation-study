/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    @Test
    void testParseReturnsExpectedDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date actual = parser.parse("2023-06-15");

        final Calendar expected = Calendar.getInstance(UTC, Locale.US);
        expected.clear();
        expected.set(2023, Calendar.JUNE, 15);

        assertEquals(expected.getTime(), actual);
    }

    @Test
    void testParseMatchesSimpleDateFormatForTimeAndMillis() throws ParseException {
        final String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
        final String input = "2023-06-15 23:59:59.999";
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);
        final FastDateParser parser = new FastDateParser(pattern, UTC, Locale.US);

        assertEquals(sdf.parse(input), parser.parse(input));
    }

    @Test
    void testParseThrowsParseExceptionForUnparseable() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("Unparseable date"));
        assertEquals(0, e.getErrorOffset());
    }

    @Test
    void testParseExceptionMessageMentionsJapaneseImperialRestriction() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("bogus");
            }
        });
        assertTrue(e.getMessage().contains("1868-01-01"), "message was: " + e.getMessage());
    }

    @Test
    void testParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("xxxx-MM-dd", pos);

        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParsePositionPartialConsumption() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("2023extra", pos);

        assertNotNull(result);
        assertEquals(4, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testCheckLengthRejectsStartIndexBeyondSourceLength() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date result = parser.parse("2023", pos);

        assertNull(result);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseWithCalendarTrueAndFieldsAreSet() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar calendar = Calendar.getInstance(UTC, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);

        final boolean parsed = parser.parse("2023-06-15", pos, calendar);

        assertTrue(parsed);
        assertEquals(10, pos.getIndex());
        assertEquals(2023, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithCalendarFalseOnFailureAndErrorIndexSet() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar calendar = Calendar.getInstance(UTC, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);

        final boolean parsed = parser.parse("2023/06/15", pos, calendar);

        assertFalse(parsed);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testCheckLengthWithCalendarOverloadRejectsOutOfRangeStart() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final Calendar calendar = Calendar.getInstance(UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(50);

        final boolean parsed = parser.parse("2023", pos, calendar);

        assertFalse(parsed);
        assertEquals(50, pos.getErrorIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object parsed = parser.parseObject("2023-06-15");
        assertEquals(parser.parse("2023-06-15"), parsed);

        final ParsePosition pos = new ParsePosition(0);
        final Object parsedWithPos = parser.parseObject("2023-06-15", pos);
        assertEquals(parser.parse("2023-06-15"), parsedWithPos);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testGetPatternLocaleAndTimeZone() {
        final TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", tz, Locale.FRANCE);

        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.FRANCE, parser.getLocale());
        assertEquals(tz, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", tz, Locale.US);

        final TimeZone returned = parser.getTimeZone();
        assertEquals(tz, returned);
        returned.setRawOffset(123456);

        final TimeZone returnedAgain = parser.getTimeZone();
        assertEquals(tz, returnedAgain);
        assertNotEquals(123456, returnedAgain.getRawOffset());
    }

    @Test
    void testNullLocaleDefaultsToSystemLocale() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser diffPattern = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDateParser diffLocale = new FastDateParser("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffZone);
        assertNotEquals(a, diffLocale);
    }

    @Test
    void testEqualsRejectsNullAndForeignType() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertNotEquals(a, null);
        assertNotEquals(a, "yyyy-MM-dd");
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZoneId() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains(Locale.US.toString()));
        assertTrue(s.contains("UTC"));
    }

    @Test
    void testToStringAllContainsPatternsList() {
        final FastDateParser parser = new FastDateParser("yyyy-MM", UTC, Locale.US);
        final String s = parser.toStringAll();
        assertTrue(s.contains("FastDateParser"));
        assertTrue(s.contains("patterns="));
    }

    @Test
    void testGetPatternsStrategyCountMatchesTokenCount() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final List<?> strategies = parser.getPatterns();
        // yyyy | - | MM | - | dd
        assertEquals(5, strategies.size());
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-qq", UTC, Locale.US);
            }
        });
        assertTrue(e.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'MM", UTC, Locale.US);
            }
        });
        assertEquals("Unterminated quote", e.getMessage());
    }

    @Test
    void testInvalidXWidthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testTwoDigitYearCenturyBoundaryWithExplicitCenturyStart() throws ParseException {
        final Calendar centuryStartCal = Calendar.getInstance(UTC, Locale.US);
        centuryStartCal.clear();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final Date centuryStart = centuryStartCal.getTime();

        final FastDateParser parser = new FastDateParser("yy-MM-dd", UTC, Locale.US, centuryStart);

        assertYear(parser, "00-01-01", 2000);
        assertYear(parser, "49-01-01", 2049);
        assertYear(parser, "50-01-01", 1950);
        assertYear(parser, "99-01-01", 1999);
    }

    private void assertYear(final FastDateParser parser, final String source, final int expectedYear) throws ParseException {
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(parser.parse(source));
        assertEquals(expectedYear, cal.get(Calendar.YEAR), "source=" + source);
    }

    @Test
    void testCaseInsensitiveMonthNameParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMM d, yyyy", UTC, Locale.US);

        final Date lower = parser.parse("jun 15, 2023");
        final Date upper = parser.parse("JUN 15, 2023");
        final Date mixed = parser.parse("Jun 15, 2023");

        assertEquals(lower, upper);
        assertEquals(lower, mixed);

        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(lower);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(2023, cal.get(Calendar.YEAR));
    }

    @Test
    void testInvalidMonthNameThrowsParseException() {
        final FastDateParser parser = new FastDateParser("MMM d, yyyy", UTC, Locale.US);
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("Frobtember 15, 2023");
            }
        });
    }

    @Test
    void testGmtOffsetTimeZoneParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd z", UTC, Locale.US);
        final Date actual = parser.parse("2023-06-15 GMT+05:30");

        final Calendar expected = Calendar.getInstance(TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        expected.clear();
        expected.set(2023, Calendar.JUNE, 15, 0, 0, 0);

        assertEquals(expected.getTime(), actual);
    }

    @Test
    void testIso8601ExtendedOffsetParsing() throws ParseException {
        final String pattern = "yyyy-MM-dd'T'HH:mm:ssXXX";
        final String input = "2021-03-05T10:15:30+05:30";
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(UTC);
        final FastDateParser parser = new FastDateParser(pattern, UTC, Locale.US);

        assertEquals(sdf.parse(input), parser.parse(input));
    }

    @Test
    void testWeekYearPatternResolvesViaSetWeekDate() throws ParseException {
        // 2015-01-01 is a Thursday and is ISO week 1 of 2015; Locale.GERMANY uses
        // Monday as the first day of week and 4 minimal days in the first week,
        // matching the ISO-8601 week definition.
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", UTC, Locale.GERMANY);
        final Date actual = parser.parse("2015-W01-4");

        final Calendar expected = Calendar.getInstance(UTC, Locale.GERMANY);
        expected.clear();
        expected.setWeekDate(2015, 1, Calendar.THURSDAY);

        assertEquals(expected.getTime(), actual);
    }

    @Test
    void testHour24StrategyWrapsValueTwentyFourToZero() {
        final FastDateParser parser = new FastDateParser("kk:mm", UTC, Locale.US);
        final Calendar calendar = Calendar.getInstance(UTC, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);

        assertTrue(parser.parse("24:00", pos, calendar));
        assertEquals(0, calendar.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHour12StrategyWrapsValueTwelveToZero() {
        final FastDateParser parser = new FastDateParser("hh:mm", UTC, Locale.US);
        final Calendar calendar = Calendar.getInstance(UTC, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);

        assertTrue(parser.parse("12:30", pos, calendar));
        assertEquals(0, calendar.get(Calendar.HOUR));
        assertEquals(30, calendar.get(Calendar.MINUTE));
    }

    @Test
    void testDayOfWeekStrategyWrapsIsoSundayToCalendarSunday() {
        final FastDateParser parser = new FastDateParser("u", UTC, Locale.US);
        final Calendar calendarForSeven = Calendar.getInstance(UTC, Locale.US);
        calendarForSeven.clear();
        assertTrue(parser.parse("7", new ParsePosition(0), calendarForSeven));
        assertEquals(Calendar.SUNDAY, calendarForSeven.get(Calendar.DAY_OF_WEEK));

        final Calendar calendarForOne = Calendar.getInstance(UTC, Locale.US);
        calendarForOne.clear();
        assertTrue(parser.parse("1", new ParsePosition(0), calendarForOne));
        assertEquals(Calendar.MONDAY, calendarForOne.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testNumberOverflowCausesParseFailureInsteadOfException() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);

        final Date result = parser.parse("99999999999999999999", pos);

        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testSerializationRoundTripPreservesStateAndParsing() throws Exception {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        assertEquals(original.getPattern(), deserialized.getPattern());
        assertEquals(original.getTimeZone(), deserialized.getTimeZone());
        assertEquals(original.getLocale(), deserialized.getLocale());
        assertEquals(original.parse("2023-06-15"), deserialized.parse("2023-06-15"));
    }
}
