/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StopWatch}.
 */
public class StopWatchAgentTest {

    @Test
    public void testCreateIsUnstartedAndZero() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
        assertNull(watch.getMessage());
    }

    @Test
    public void testCreateStartedIsRunning() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    public void testMessageConstructor() {
        final StopWatch watch = new StopWatch("my message");
        assertEquals("my message", watch.getMessage());
        assertTrue(watch.toString().startsWith("my message "));
    }

    @Test
    public void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    public void testStartStopLifecycle() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertTrue(watch.isStarted());
        Thread.sleep(10);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getNanoTime() > 0);
        assertTrue(watch.getTime() >= 0);
    }

    @Test
    public void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    public void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    public void testStartAfterResetSucceeds() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    public void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    public void testStopAfterStopThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    public void testSuspendResume() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.suspend();
        assertTrue(watch.isSuspended());
        final long suspendedTime = watch.getNanoTime();
        Thread.sleep(20);
        assertEquals(suspendedTime, watch.getNanoTime());
        watch.resume();
        assertTrue(watch.isStarted());
        assertFalse(watch.isSuspended());
        watch.stop();
        assertTrue(watch.getNanoTime() >= suspendedTime);
    }

    @Test
    public void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::resume);
    }

    @Test
    public void testResumeBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::resume);
    }

    @Test
    public void testSplitUnsplit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.split();
        final long splitNanos = watch.getSplitNanoTime();
        assertTrue(splitNanos > 0);
        Thread.sleep(5);
        assertEquals(splitNanos, watch.getSplitNanoTime());
        watch.unsplit();
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
    }

    @Test
    public void testSplitBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    public void testSplitTwiceWhileRunningAddsTwoSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.split();
        assertEquals(2, watch.getSplits().size());
        assertEquals("0", watch.getSplits().get(0).getLabel());
        assertEquals("1", watch.getSplits().get(1).getLabel());
    }

    @Test
    public void testSplitAfterStopThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    public void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
        assertThrows(IllegalStateException.class, watch::getSplitDuration);
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::unsplit);
    }

    @Test
    public void testSplitWithLabelRecordedInSplits() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.split("first");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertNotNull(splits.get(0).getDuration());
        assertTrue(splits.get(0).getDuration().toNanos() > 0);
        assertTrue(splits.get(0).toString().contains("first"));
    }

    @Test
    public void testDefaultSplitLabelIsIndex() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals("0", watch.getSplits().get(0).getLabel());
    }

    @Test
    public void testGetSplitsIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    public void testUnsplitRemovesLastSplitFromList() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
    }

    @Test
    public void testStartClearsPreviousSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.stop();
        watch.reset();
        watch.start();
        assertEquals(0, watch.getSplits().size());
    }

    @Test
    public void testResetClearsSplitsAndState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
    }

    @Test
    public void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStartInstant);
        assertThrows(IllegalStateException.class, watch::getStopInstant);
        assertThrows(IllegalStateException.class, watch::getStartTime);
        assertThrows(IllegalStateException.class, watch::getStopTime);
    }

    @Test
    public void testGetStartInstantAfterStart() {
        final Instant before = Instant.now();
        final StopWatch watch = new StopWatch();
        watch.start();
        final Instant after = Instant.now();
        final Instant startInstant = watch.getStartInstant();
        assertNotNull(startInstant);
        assertFalse(startInstant.isBefore(before.minusSeconds(1)));
        assertFalse(startInstant.isAfter(after.plusSeconds(1)));
    }

    @Test
    public void testGetStopInstantAfterStop() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertNotNull(watch.getStopInstant());
        assertFalse(watch.getStopInstant().isBefore(watch.getStartInstant()));
    }

    @Test
    public void testGetDurationMatchesNanoTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertEquals(watch.getNanoTime(), watch.getDuration().toNanos());
    }

    @Test
    public void testGetTimeTimeUnit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertEquals(0, watch.getTime(TimeUnit.HOURS));
        assertEquals(watch.getTime(TimeUnit.MILLISECONDS), watch.getTime());
    }

    @Test
    public void testFormatTimeAndToString() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String formatted = watch.formatTime();
        assertNotNull(formatted);
        assertEquals(formatted, watch.toString());
    }

    @Test
    public void testToStringWithMessagePrefix() {
        final StopWatch watch = new StopWatch("hello");
        watch.start();
        watch.stop();
        assertEquals("hello " + watch.formatTime(), watch.toString());
    }

    @Test
    public void testFormatSplitTimeAndToSplitString() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String formatted = watch.formatSplitTime();
        assertNotNull(formatted);
        assertEquals(formatted, watch.toSplitString());
    }

    @Test
    public void testToSplitStringWithMessagePrefix() {
        final StopWatch watch = new StopWatch("split-msg");
        watch.start();
        watch.split();
        assertEquals("split-msg " + watch.formatSplitTime(), watch.toSplitString());
    }

    @Test
    public void testRunDelegatesAndRecordsTime() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = new boolean[1];
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getNanoTime() >= 0);
    }

    @Test
    public void testGetDelegatesAndReturnsValue() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testRunTwiceAccumulatesTime() {
        final StopWatch watch = new StopWatch();
        watch.run(new Runnable() {
            @Override
            public void run() {
                // no-op
            }
        });
        final long firstTime = watch.getNanoTime();
        watch.run(new Runnable() {
            @Override
            public void run() {
                // no-op
            }
        });
        assertTrue(watch.getNanoTime() >= firstTime);
    }

    @Test
    public void testGetTPropagatesException() {
        final StopWatch watch = new StopWatch();
        final RuntimeException thrown = new RuntimeException("boom");
        final Throwable caught = assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getT(new org.apache.commons.lang3.function.FailableSupplier<String, RuntimeException>() {
                    @Override
                    public String get() {
                        throw thrown;
                    }
                });
            }
        });
        assertEquals(thrown, caught);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testRunTPropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        final Exception caught = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new org.apache.commons.lang3.function.FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw new java.io.IOException("io failure");
                    }
                });
            }
        });
        assertEquals("io failure", caught.getMessage());
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testSplitToString() {
        final StopWatch.Split split = new StopWatch.Split("label", Duration.ofMillis(500));
        assertEquals("label", split.getLabel());
        assertEquals(Duration.ofMillis(500), split.getDuration());
        assertEquals("Split [label, PT0.5S])", split.toString());
    }
}
