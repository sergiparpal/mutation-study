/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Formattable;
import java.util.FormattableFlags;
import java.util.Formatter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link FormattableUtils}.
 */
@Deprecated
class FormattableUtilsAgentTest {

    private static final class RecordingFormattable implements Formattable {
        private final String value;

        RecordingFormattable(final String value) {
            this.value = value;
        }

        @Override
        public void formatTo(final Formatter formatter, final int flags, final int width, final int precision) {
            formatter.format("%s", value);
        }
    }

    @Test
    void testConstructorIsPublicAndUsable() {
        final FormattableUtils instance = new FormattableUtils();
        assertNotNull(instance);
    }

    @Test
    void testAppendNoTruncationNoPadding() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("hello", formatter, 0, 0, -1);
        assertSame(formatter, result);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendRightJustifyPadsWithSpacesOnLeft() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 10, -1);
        assertEquals("     hello", formatter.toString());
    }

    @Test
    void testAppendLeftJustifyPadsOnRight() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, FormattableFlags.LEFT_JUSTIFY, 10, -1);
        assertEquals("hello     ", formatter.toString());
    }

    @Test
    void testAppendCustomPadChar() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 8, -1, '*');
        assertEquals("***hello", formatter.toString());
    }

    @Test
    void testAppendNegativeWidthDoesNotPad() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, -5, -1);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendPrecisionTruncatesWithoutEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, 0, 5);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendPrecisionEqualToLengthDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 0, 5);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendPrecisionGreaterThanLengthDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 0, 100);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendZeroPrecisionTruncatesToEmpty() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 0, 0);
        assertEquals("", formatter.toString());
    }

    @Test
    void testAppendWithEllipsisWithinPrecision() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, 0, 8, "...");
        assertEquals("hello...", formatter.toString());
    }

    @Test
    void testAppendWithNullEllipsisIsHardTruncation() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, 0, 5, (CharSequence) null);
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendEllipsisExceedingPrecisionThrows() {
        final Formatter formatter = new Formatter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FormattableUtils.append("hello world", formatter, 0, 0, 2, "...");
            }
        });
    }

    @Test
    void testAppendEllipsisAllowedWhenPrecisionNegative() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello", formatter, 0, 0, -1, "...");
        assertEquals("hello", formatter.toString());
    }

    @Test
    void testAppendFourArgOverloadMatchesDefaultsPadCharAndNoEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hello world", formatter, 0, 15, 8);
        assertEquals("       hello wo", formatter.toString());
    }

    @Test
    void testAppendPadCharOverloadMatchesNoEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("hi", formatter, 0, 5, -1, '0');
        assertEquals("000hi", formatter.toString());
    }

    @Test
    void testAppendEllipsisOverloadFullString() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("hello world", formatter, 0, 12, 8, "...");
        assertSame(formatter, result);
        assertEquals(12, formatter.toString().length());
        assertEquals("hello...", formatter.toString().trim());
    }

    @Test
    void testToStringDelegatesToFormattable() {
        final RecordingFormattable formattable = new RecordingFormattable("some-value");
        assertEquals("some-value", FormattableUtils.toString(formattable));
    }

    @Test
    void testToStringWithEmptyValue() {
        final RecordingFormattable formattable = new RecordingFormattable("");
        assertEquals("", FormattableUtils.toString(formattable));
    }
}
