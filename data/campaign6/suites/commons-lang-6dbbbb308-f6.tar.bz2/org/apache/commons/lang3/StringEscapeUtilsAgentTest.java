/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link StringEscapeUtils}.
 */
public class StringEscapeUtilsAgentTest {

    // --- null / empty handling -------------------------------------------------

    @Test
    public void testNullInputReturnsNullForAllMethods() {
        assertNull(StringEscapeUtils.escapeCsv(null));
        assertNull(StringEscapeUtils.unescapeCsv(null));
        assertNull(StringEscapeUtils.escapeEcmaScript(null));
        assertNull(StringEscapeUtils.unescapeEcmaScript(null));
        assertNull(StringEscapeUtils.escapeHtml3(null));
        assertNull(StringEscapeUtils.unescapeHtml3(null));
        assertNull(StringEscapeUtils.escapeHtml4(null));
        assertNull(StringEscapeUtils.unescapeHtml4(null));
        assertNull(StringEscapeUtils.escapeJava(null));
        assertNull(StringEscapeUtils.unescapeJava(null));
        assertNull(StringEscapeUtils.escapeJson(null));
        assertNull(StringEscapeUtils.unescapeJson(null));
        assertNull(StringEscapeUtils.escapeXml(null));
        assertNull(StringEscapeUtils.escapeXml10(null));
        assertNull(StringEscapeUtils.escapeXml11(null));
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    public void testEmptyInputReturnsEmptyForAllMethods() {
        assertEquals("", StringEscapeUtils.escapeCsv(""));
        assertEquals("", StringEscapeUtils.unescapeCsv(""));
        assertEquals("", StringEscapeUtils.escapeEcmaScript(""));
        assertEquals("", StringEscapeUtils.unescapeEcmaScript(""));
        assertEquals("", StringEscapeUtils.escapeHtml3(""));
        assertEquals("", StringEscapeUtils.unescapeHtml3(""));
        assertEquals("", StringEscapeUtils.escapeHtml4(""));
        assertEquals("", StringEscapeUtils.unescapeHtml4(""));
        assertEquals("", StringEscapeUtils.escapeJava(""));
        assertEquals("", StringEscapeUtils.unescapeJava(""));
        assertEquals("", StringEscapeUtils.escapeJson(""));
        assertEquals("", StringEscapeUtils.unescapeJson(""));
        assertEquals("", StringEscapeUtils.escapeXml(""));
        assertEquals("", StringEscapeUtils.escapeXml10(""));
        assertEquals("", StringEscapeUtils.escapeXml11(""));
        assertEquals("", StringEscapeUtils.unescapeXml(""));
    }

    @Test
    public void testPlainTextUnchangedByAllEscapers() {
        final String plain = "just a plain ASCII sentence 123";
        assertEquals(plain, StringEscapeUtils.escapeCsv(plain));
        assertEquals(plain, StringEscapeUtils.escapeEcmaScript(plain));
        assertEquals(plain, StringEscapeUtils.escapeHtml3(plain));
        assertEquals(plain, StringEscapeUtils.escapeHtml4(plain));
        assertEquals(plain, StringEscapeUtils.escapeJava(plain));
        assertEquals(plain, StringEscapeUtils.escapeJson(plain));
        assertEquals(plain, StringEscapeUtils.escapeXml(plain));
        assertEquals(plain, StringEscapeUtils.escapeXml10(plain));
        assertEquals(plain, StringEscapeUtils.escapeXml11(plain));
    }

    // --- Java ---------------------------------------------------------------

    @Test
    public void testEscapeJavaQuotesAndBackslash() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    @Test
    public void testEscapeJavaControlChars() {
        assertEquals("\\b\\f\\n\\r\\t", StringEscapeUtils.escapeJava("\b\f\n\r\t"));
    }

    @Test
    public void testEscapeJavaDoesNotEscapeSingleQuoteOrSlash() {
        // unlike EcmaScript, Java strings don't need ' or / escaped
        assertEquals("'", StringEscapeUtils.escapeJava("'"));
        assertEquals("/", StringEscapeUtils.escapeJava("/"));
    }

    @Test
    public void testEscapeJavaEscapesNonAsciiAsUnicode() {
        assertEquals("\\u00E9", StringEscapeUtils.escapeJava("é"));
    }

    @Test
    public void testUnescapeJavaStandardEscapes() {
        assertEquals("He didn't say, \"Stop!\"", StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
        assertEquals("\b\f\n\r\t", StringEscapeUtils.unescapeJava("\\b\\f\\n\\r\\t"));
        assertEquals("\\", StringEscapeUtils.unescapeJava("\\\\"));
    }

    @Test
    public void testUnescapeJavaOctalEscapes() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\101"));
        assertEquals("ÿ", StringEscapeUtils.unescapeJava("\\377"));
    }

    @Test
    public void testUnescapeJavaUnicodeEscapes() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\u0041"));
    }

    @Test
    public void testUnescapeJavaTrailingLoneBackslashIsDropped() {
        assertEquals("abc", StringEscapeUtils.unescapeJava("abc\\"));
    }

    @Test
    public void testJavaEscapeUnescapeRoundTrip() {
        final String original = "Tab\t Quote\" Backslash\\ Unicodeé";
        assertEquals(original, StringEscapeUtils.unescapeJava(StringEscapeUtils.escapeJava(original)));
    }

    // --- EcmaScript -----------------------------------------------------------

    @Test
    public void testEscapeEcmaScriptEscapesSingleQuoteAndSlash() {
        assertEquals("\\'", StringEscapeUtils.escapeEcmaScript("'"));
        assertEquals("\\/", StringEscapeUtils.escapeEcmaScript("/"));
        assertEquals("\\\"", StringEscapeUtils.escapeEcmaScript("\""));
        assertEquals("\\\\", StringEscapeUtils.escapeEcmaScript("\\"));
    }

    @Test
    public void testEscapeEcmaScriptExample() {
        assertEquals("He didn\\'t say, \\\"Stop!\\\"", StringEscapeUtils.escapeEcmaScript("He didn't say, \"Stop!\""));
    }

    @Test
    public void testUnescapeEcmaScriptBehavesLikeUnescapeJava() {
        assertEquals(StringEscapeUtils.unescapeJava("\\u0041\\n"), StringEscapeUtils.unescapeEcmaScript("\\u0041\\n"));
    }

    // --- Json -------------------------------------------------------------

    @Test
    public void testEscapeJsonEscapesSlashButNotSingleQuote() {
        assertEquals("\\/", StringEscapeUtils.escapeJson("/"));
        // JSON strings do not require a single quote to be escaped
        assertEquals("'", StringEscapeUtils.escapeJson("'"));
        assertEquals("\\\"", StringEscapeUtils.escapeJson("\""));
        assertEquals("\\\\", StringEscapeUtils.escapeJson("\\"));
    }

    @Test
    public void testUnescapeJsonBehavesLikeUnescapeJava() {
        assertEquals(StringEscapeUtils.unescapeJava("\\/"), StringEscapeUtils.unescapeJson("\\/"));
    }

    // --- HTML 3 vs HTML 4 ----------------------------------------------------

    @Test
    public void testEscapeHtml3BasicEntities() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml3("\"bread\" & \"butter\""));
        assertEquals("&lt;&gt;", StringEscapeUtils.escapeHtml3("<>"));
    }

    @Test
    public void testEscapeHtml3DoesNotKnowHtml40ExtendedEntities() {
        // the euro sign is only part of the HTML 4.0 extended entity set
        assertEquals("€", StringEscapeUtils.escapeHtml3("€"));
    }

    @Test
    public void testEscapeHtml3Iso8859Entity() {
        assertEquals("&nbsp;", StringEscapeUtils.escapeHtml3(" "));
    }

    @Test
    public void testEscapeHtml4KnowsExtendedEntities() {
        assertEquals("&euro;", StringEscapeUtils.escapeHtml4("€"));
    }

    @Test
    public void testEscapeHtml4DoesNotEscapeApostrophe() {
        // apos is not a legal HTML 4 entity
        assertEquals("'", StringEscapeUtils.escapeHtml4("'"));
    }

    @Test
    public void testUnescapeHtml3LeavesHtml40ExtendedEntityUntouched() {
        assertEquals("&euro;", StringEscapeUtils.unescapeHtml3("&euro;"));
    }

    @Test
    public void testUnescapeHtml4KnowsExtendedEntities() {
        assertEquals("€", StringEscapeUtils.unescapeHtml4("&euro;"));
    }

    @Test
    public void testUnescapeHtml4LeavesApostropheEntityUntouched() {
        // &apos; is not a legal HTML 4 entity, so it must be left alone
        assertEquals("&apos;", StringEscapeUtils.unescapeHtml4("&apos;"));
    }

    @Test
    public void testUnescapeHtml4UnrecognizedEntityLeftVerbatim() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml4("&gt;&zzzz;x"));
    }

    @Test
    public void testUnescapeHtml4NumericEntities() {
        assertEquals("A", StringEscapeUtils.unescapeHtml4("&#65;"));
        assertEquals("A", StringEscapeUtils.unescapeHtml4("&#x41;"));
    }

    // --- XML ------------------------------------------------------------------

    @Test
    public void testEscapeXmlBasicEntities() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
    }

    @Test
    public void testEscapeXml10And11EscapeApostrophe() {
        assertEquals("&apos;", StringEscapeUtils.escapeXml10("'"));
        assertEquals("&apos;", StringEscapeUtils.escapeXml11("'"));
    }

    @Test
    public void testEscapeXml10RemovesControlCharacters() {
        // control characters have no valid representation in an XML 1.0 document
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0005b"));
        assertEquals("", StringEscapeUtils.escapeXml10("\u0000"));
    }

    @Test
    public void testEscapeXml11EscapesControlCharactersNumerically() {
        // XML 1.1 can represent most control characters, escaped numerically
        assertEquals("a&#5;b", StringEscapeUtils.escapeXml11("a\u0005b"));
        assertEquals("&#11;", StringEscapeUtils.escapeXml11("\u000b"));
    }

    @Test
    public void testEscapeXml11RemovesNullByte() {
        // XML 1.1 cannot represent the null byte even after escaping
        assertEquals("", StringEscapeUtils.escapeXml11("\u0000"));
    }

    @Test
    public void testUnescapeXmlBasicAndApos() {
        assertEquals("<>&\"'", StringEscapeUtils.unescapeXml("&lt;&gt;&amp;&quot;&apos;"));
    }

    @Test
    public void testUnescapeXmlNumericEntitiesDecimalAndHex() {
        assertEquals("A", StringEscapeUtils.unescapeXml("&#65;"));
        assertEquals("J", StringEscapeUtils.unescapeXml("&#x4A;"));
    }

    @Test
    public void testUnescapeXmlUnknownEntityLeftVerbatim() {
        assertEquals("&unknown;", StringEscapeUtils.unescapeXml("&unknown;"));
    }

    @Test
    public void testXmlEscapeUnescapeRoundTrip() {
        final String original = "<tag attr=\"a & b\">'quoted'</tag>";
        assertEquals(original, StringEscapeUtils.unescapeXml(StringEscapeUtils.escapeXml10(original)));
    }

    // --- CSV --------------------------------------------------------------

    @Test
    public void testEscapeCsvPlainValueUnchanged() {
        assertEquals("abc", StringEscapeUtils.escapeCsv("abc"));
    }

    @Test
    public void testEscapeCsvQuotesValueContainingComma() {
        assertEquals("\"a,b\"", StringEscapeUtils.escapeCsv("a,b"));
    }

    @Test
    public void testEscapeCsvQuotesValueContainingNewline() {
        assertEquals("\"a\nb\"", StringEscapeUtils.escapeCsv("a\nb"));
    }

    @Test
    public void testEscapeCsvDoublesEmbeddedQuotes() {
        assertEquals("\"a\"\"b\"", StringEscapeUtils.escapeCsv("a\"b"));
    }

    @Test
    public void testUnescapeCsvPlainValueUnchanged() {
        assertEquals("abc", StringEscapeUtils.unescapeCsv("abc"));
    }

    @Test
    public void testUnescapeCsvStripsEnclosingQuotesAndUnescapesEmbeddedQuotes() {
        assertEquals("a,b", StringEscapeUtils.unescapeCsv("\"a,b\""));
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("\"a\"\"b\""));
    }

    @Test
    public void testUnescapeCsvValueNotEnclosedInQuotesIsUnchangedEvenIfItContainsAQuote() {
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("a\"b"));
    }

    @Test
    public void testCsvEscapeUnescapeRoundTrip() {
        final String original = "a,\"b\"\nc";
        assertEquals(original, StringEscapeUtils.unescapeCsv(StringEscapeUtils.escapeCsv(original)));
    }

    @Test
    public void testUnescapeCsvSingleQuoteCharacterDoesNotThrow() {
        // A lone double-quote character is not a validly CSV-quoted value (it would need
        // a separate opening and closing quote), so it must be returned unchanged rather
        // than make unescapeCsv throw an exception.
        assertEquals("\"", StringEscapeUtils.unescapeCsv("\""));
    }

    // --- misc -------------------------------------------------------------

    @Test
    public void testConstructorIsPubliclyInstantiable() {
        final StringEscapeUtils instance = new StringEscapeUtils();
        assertNotNull(instance);
    }
}
