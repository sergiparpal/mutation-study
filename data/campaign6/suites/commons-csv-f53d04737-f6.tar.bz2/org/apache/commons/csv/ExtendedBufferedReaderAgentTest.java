/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testReadSingleCharUpdatesLastCharAndPosition() throws IOException {
        final ExtendedBufferedReader br = create("AB");
        assertEquals('A', br.read());
        assertEquals('A', br.getLastChar());
        assertEquals(1, br.getPosition());
        assertEquals('B', br.read());
        assertEquals('B', br.getLastChar());
        assertEquals(2, br.getPosition());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadAtEofDoesNotAdvancePosition() throws IOException {
        // Reading past the end of the stream should not count as characters read.
        final ExtendedBufferedReader br = create("");
        assertEquals(EOF, br.read());
        assertEquals(0, br.getPosition());
        assertEquals(EOF, br.read());
        assertEquals(0, br.getPosition());
        br.close();
    }

    @Test
    void testEmptyStreamSingleReadLineNumberStaysZero() throws IOException {
        // An empty stream contains no lines at all.
        final ExtendedBufferedReader br = create("");
        assertEquals(EOF, br.read());
        assertEquals(0, br.getLineNumber());
        br.close();
    }

    @Test
    void testEmptyStreamBulkReadLineNumberStaysZero() throws IOException {
        final ExtendedBufferedReader br = create("");
        final char[] buf = new char[10];
        assertEquals(EOF, br.read(buf, 0, buf.length));
        assertEquals(0, br.getLineNumber());
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadZeroLengthReturnsZeroWithoutConsuming() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        final char[] buf = new char[10];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        // The stream must still be positioned at the start.
        assertEquals('a', br.read());
        br.close();
    }

    @Test
    void testBulkReadReturnsCharactersAndUpdatesState() throws IOException {
        final ExtendedBufferedReader br = create("abcdef");
        final char[] buf = new char[4];
        final int n = br.read(buf, 0, 4);
        assertEquals(4, n);
        assertArrayEquals(new char[] { 'a', 'b', 'c', 'd' }, buf);
        assertEquals('d', br.getLastChar());
        assertEquals(4, br.getPosition());
        br.close();
    }

    @Test
    void testBulkReadAtEofReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader br = create("");
        final char[] buf = new char[4];
        final int n = br.read(buf, 0, 4);
        assertEquals(EOF, n);
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testGetLineNumberLookahead() throws IOException {
        // getLineNumber() reports the line currently being read even before its
        // terminator has been seen, but stays accurate once the terminator (or
        // EOF after some content) has been consumed.
        final ExtendedBufferedReader br = create("ab\ncd");
        assertEquals(0, br.getLineNumber());
        br.read(); // 'a'
        assertEquals(1, br.getLineNumber());
        br.read(); // 'b'
        assertEquals(1, br.getLineNumber());
        br.read(); // '\n'
        assertEquals(1, br.getLineNumber());
        br.read(); // 'c'
        assertEquals(2, br.getLineNumber());
        br.read(); // 'd'
        assertEquals(2, br.getLineNumber());
        br.read(); // EOF, 'd' was not a terminator so this counts as ending line 2
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testLineNumberWithCrLfAndLfCr() throws IOException {
        final ExtendedBufferedReader br = create("1\r\n2\n\r3");
        int count = 0;
        while (br.read() != EOF) {
            count++;
        }
        assertEquals(7, count);
        // 1\r\n (1 EOL) 2\n (1 EOL) \r (1 EOL) 3<EOF> (1 EOL)
        assertEquals(4, br.getLineNumber());
        br.close();
    }

    @Test
    void testBulkReadLineCountingMatchesSingleCharReadAcrossSmallBuffers() throws IOException {
        final String test = "a\nb\r\nc\r\rd";
        long expectedLines;
        final ExtendedBufferedReader single = create(test);
        int readCount = 0;
        while (single.read() != EOF) {
            readCount++;
        }
        expectedLines = single.getLineNumber();
        assertEquals(test.length(), readCount);
        single.close();

        final ExtendedBufferedReader bulk = create(test);
        final char[] buf = new char[3];
        while (bulk.read(buf, 0, 3) != EOF) {
            // consume all, in chunks that may split a CRLF pair across calls
        }
        assertEquals(expectedLines, bulk.getLineNumber());
        bulk.close();
    }

    @Test
    void testPeekDoesNotAdvanceStateOrPosition() throws IOException {
        final ExtendedBufferedReader br = create("xy");
        assertEquals('x', br.peek());
        assertEquals('x', br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getLineNumber());
        assertEquals('x', br.read());
        assertEquals('y', br.peek());
        assertEquals('x', br.getLastChar());
        br.close();
    }

    @Test
    void testPeekAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertEquals(EOF, br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        br.close();
    }

    @Test
    void testReadLineBasic() throws IOException {
        final ExtendedBufferedReader br = create("foo\n\nbar");
        assertEquals("foo", br.readLine());
        assertEquals(1, br.getLineNumber());
        assertEquals("", br.readLine());
        assertEquals(2, br.getLineNumber());
        assertEquals("bar", br.readLine());
        assertEquals(3, br.getLineNumber());
        assertNull(br.readLine());
        assertEquals(3, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadLineOnEmptyStreamReturnsNull() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertNull(br.readLine());
        assertEquals(0, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadLineHandlesCrLfAndLoneCr() throws IOException {
        final ExtendedBufferedReader br = create("foo\r\nbar\rbaz");
        assertEquals("foo", br.readLine());
        assertEquals("bar", br.readLine());
        assertEquals("baz", br.readLine());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testReadLineDropsTerminators() throws IOException {
        final ExtendedBufferedReader br = create("a\r\n");
        final String line = br.readLine();
        assertEquals("a", line);
        assertTrue(line.indexOf('\r') < 0 && line.indexOf('\n') < 0);
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd\nef");
        br.read(); // 'a'
        br.read(); // 'b'
        br.mark(16);
        final long markedPosition = br.getPosition();
        final long markedLine = br.getLineNumber();
        final int markedLastChar = br.getLastChar();

        br.read(); // '\n'
        br.read(); // 'c'
        br.read(); // 'd'

        br.reset();
        assertEquals(markedPosition, br.getPosition());
        assertEquals(markedLine, br.getLineNumber());
        assertEquals(markedLastChar, br.getLastChar());

        // Reading again after reset must reproduce the same characters.
        assertEquals('\n', br.read());
        assertEquals('c', br.read());
        br.close();
    }

    @Test
    void testResetWithoutMarkThrows() {
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                final ExtendedBufferedReader br = create("abc");
                try {
                    br.reset();
                } finally {
                    br.close();
                }
            }
        });
    }

    @Test
    void testCloseSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.read();
        assertEquals('a', br.getLastChar());
        br.close();
        assertEquals(EOF, br.getLastChar());
    }

    @Test
    void testReadAfterCloseThrows() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.close();
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testBytesReadNotTrackedWithoutEncoder() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, false);
        while (br.read() != EOF) {
            // consume
        }
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadTrackedForAsciiCharacters() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, true);
        while (br.read() != EOF) {
            // consume
        }
        assertEquals(5, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadTrackedForMultiByteCharacters() throws IOException {
        // 'é' (e-acute) is 2 bytes in UTF-8, '中' is 3 bytes in UTF-8.
        final String input = "é中";
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        while (br.read() != EOF) {
            // consume
        }
        assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadTrackedForSupplementaryCharacterViaBulkRead() throws IOException {
        final String input = "😀"; // a single supplementary character (grinning face)
        final char[] buffer = new char[input.length()];
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        final int n = br.read(buffer, 0, buffer.length);
        assertEquals(input.length(), n);
        assertArrayEquals(input.toCharArray(), buffer);
        assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        br.close();
    }

    @Test
    void testUnmappableCharacterThrowsOnRead() throws IOException {
        // 'é' cannot be encoded as US-ASCII.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("é"), StandardCharsets.US_ASCII, true);
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
        br.close();
    }

    @Test
    void testLoneLowSurrogateThrowsOnRead() throws IOException {
        // A lone low surrogate without a preceding high surrogate is invalid UTF-16.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\udc00"), StandardCharsets.UTF_8, true);
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
        br.close();
    }

    @Test
    void testReadNegativeLengthThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                final ExtendedBufferedReader br = create("abc");
                try {
                    br.read(new char[4], 0, -1);
                } finally {
                    br.close();
                }
            }
        });
    }

    @Test
    void testReadOffsetOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                final ExtendedBufferedReader br = create("abc");
                try {
                    br.read(new char[4], 3, 4);
                } finally {
                    br.close();
                }
            }
        });
    }

    @Test
    void testGetLastCharReflectsOnlyReadNotPeek() throws IOException {
        final ExtendedBufferedReader br = create("x");
        assertEquals(UNDEFINED, br.getLastChar());
        br.peek();
        assertEquals(UNDEFINED, br.getLastChar());
        br.read();
        assertEquals('x', br.getLastChar());
        br.peek();
        assertEquals('x', br.getLastChar());
        br.close();
    }
}
