/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private static Date makeDate(final int year, final int month, final int day, final int hour, final int minute, final int second,
            final int millis) {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    private static Calendar toCal(final Date date) {
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    // ---------------------------------------------------------------
    // add* methods
    // ---------------------------------------------------------------

    @Test
    void testAddDays() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        final Date result = DateUtils.addDays(base, 5);
        final Calendar cal = toCal(result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(20, cal.get(Calendar.DAY_OF_MONTH));
        // Original date must remain unchanged.
        assertEquals(15, toCal(base).get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddDaysNegativeAmount() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        final Date result = DateUtils.addDays(base, -20);
        final Calendar cal = toCal(result);
        assertEquals(Calendar.MAY, cal.get(Calendar.MONTH));
        assertEquals(26, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddDaysNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
    }

    @Test
    void testAddHoursCrossesDay() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 22, 0, 0, 0);
        final Date result = DateUtils.addHours(base, 5);
        final Calendar cal = toCal(result);
        assertEquals(16, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(3, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testAddMillisecondsAndSecondsAndMinutes() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(600, toCal(DateUtils.addMilliseconds(base, 100)).get(Calendar.MILLISECOND));
        assertEquals(50, toCal(DateUtils.addSeconds(base, 5)).get(Calendar.SECOND));
        assertEquals(35, toCal(DateUtils.addMinutes(base, 5)).get(Calendar.MINUTE));
    }

    @Test
    void testAddMonthsRollsDayDown() {
        // Jan 31 + 1 month must normalize to the last day of February.
        final Date base = makeDate(2023, Calendar.JANUARY, 31, 10, 0, 0, 0);
        final Date result = DateUtils.addMonths(base, 1);
        final Calendar cal = toCal(result);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddWeeks() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 0, 0, 0);
        final Date result = DateUtils.addWeeks(base, 2);
        final Calendar cal = toCal(result);
        assertEquals(29, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddYears() {
        final Date base = makeDate(2020, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        final Date result = DateUtils.addYears(base, 1);
        final Calendar cal = toCal(result);
        // Leap day is adjusted down to Feb 28 on a non-leap year.
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(2021, cal.get(Calendar.YEAR));
    }

    // ---------------------------------------------------------------
    // ceiling
    // ---------------------------------------------------------------

    @Test
    void testCeilingDateHour() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(base, Calendar.HOUR_OF_DAY);
        final Calendar cal = toCal(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));
    }

    @Test
    void testCeilingDateMonth() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(base, Calendar.MONTH);
        final Calendar cal = toCal(result);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testCeilingExactMatchDoesNotRoll() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0);
        final Date result = DateUtils.ceiling(base, Calendar.HOUR_OF_DAY);
        assertEquals(base, result);
    }

    @Test
    void testCeilingObjectDispatch() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date fromDate = DateUtils.ceiling((Object) base, Calendar.HOUR_OF_DAY);
        final Date fromCalendar = DateUtils.ceiling((Object) toCal(base), Calendar.HOUR_OF_DAY);
        assertEquals(fromDate, fromCalendar);
    }

    @Test
    void testCeilingObjectWithInvalidTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingInvalidFieldThrowsIllegalArgumentException() {
        final Calendar cal = toCal(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testCeilingHugeYearThrowsArithmeticException() {
        final Calendar cal = new GregorianCalendar(280000001, Calendar.JANUARY, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(cal, Calendar.MONTH);
            }
        });
    }

    // ---------------------------------------------------------------
    // getFragmentIn*
    // ---------------------------------------------------------------

    @Test
    void testGetFragmentInDays() {
        final Date date = makeDate(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(28, DateUtils.getFragmentInDays(date, Calendar.MONTH));
        assertEquals(59, DateUtils.getFragmentInDays(date, Calendar.YEAR));
        assertEquals(0, DateUtils.getFragmentInDays(date, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Date date = makeDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(date, Calendar.DAY_OF_YEAR));
        assertEquals(127, DateUtils.getFragmentInHours(date, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutesAndSecondsAndMilliseconds() {
        final Date firstOfMonth = makeDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(435, DateUtils.getFragmentInMinutes(firstOfMonth, Calendar.MONTH));

        final Date date = makeDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
        assertEquals(538, DateUtils.getFragmentInMilliseconds(date, Calendar.SECOND));
    }

    @Test
    void testGetFragmentUnsupportedThrowsIllegalArgumentException() {
        final Date date = makeDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(date, Calendar.AM_PM);
            }
        });
    }

    @Test
    void testGetFragmentNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.MONTH);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSameDay / isSameInstant / isSameLocalTime
    // ---------------------------------------------------------------

    @Test
    void testIsSameDayTrueAndFalse() {
        final Date d1 = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = makeDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = makeDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    @Test
    void testIsSameDayNullThrows() {
        final Date d1 = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay(d1, (Date) null);
            }
        });
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = new Date(10000L);
        final Date d2 = new Date(10000L);
        final Date d3 = new Date(10001L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    @Test
    void testIsSameInstantNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Date) null, new Date());
            }
        });
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarClassIsFalse() {
        final Calendar cal1 = new GregorianCalendar(2020, Calendar.JANUARY, 1, 10, 0, 0);
        final Calendar cal2 = new java.util.Calendar.Builder().setCalendarType("iso8601")
                .setDate(2020, Calendar.JANUARY, 1).setTimeOfDay(10, 0, 0).build();
        // Equal fields, but not necessarily the same runtime Calendar subtype.
        assertEquals(cal1.getClass() == cal2.getClass(), DateUtils.isSameLocalTime(cal1, cal2));
    }

    @Test
    void testIsSameLocalTimeSameFieldsTrue() {
        final Calendar cal1 = new GregorianCalendar(2020, Calendar.JANUARY, 1, 10, 30, 15);
        final Calendar cal2 = new GregorianCalendar(2020, Calendar.JANUARY, 1, 10, 30, 15);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));
    }

    @Test
    void testIsSameLocalTimeNullThrows() {
        final Calendar cal1 = new GregorianCalendar();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(cal1, (Calendar) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // iterator
    // ---------------------------------------------------------------

    @Test
    void testIteratorRangeWeekSunday() {
        final Date focus = makeDate(2002, Calendar.JULY, 4, 0, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorRangeMonthSunday() {
        final Date focus = makeDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        final Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorExhaustionThrowsNoSuchElementException() {
        final Date focus = makeDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final Date focus = makeDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    @Test
    void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        final Date focus = makeDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.iterator(focus, 999);
            }
        });
    }

    @Test
    void testIteratorNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorObjectWithInvalidTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    // ---------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ---------------------------------------------------------------

    @Test
    void testParseDateValid() throws ParseException {
        final Date result = DateUtils.parseDate("2023-06-15", "yyyy-MM-dd");
        final Calendar cal = toCal(result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateTriesPatternsInOrder() throws ParseException {
        final Date result = DateUtils.parseDate("15/06/2023", "yyyy-MM-dd", "dd/MM/yyyy");
        final Calendar cal = toCal(result);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNoMatchThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNoPatternsThrowsParseException() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("2023-06-15");
            }
        });
    }

    @Test
    void testParseDatePartialMatchFails() {
        // Lenient parse still requires the whole string to be consumed.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("2023-06-15 extra", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate((String) null, "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNullPatternsThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDate("2023-06-15", (String[]) null);
            }
        });
    }

    @Test
    void testParseDateWithLocale() throws ParseException {
        final Date result = DateUtils.parseDate("2023-06-15", Locale.US, "yyyy-MM-dd");
        assertNotNull(result);
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        // Lenient parsing accepts day 32 by rolling over; strict parsing must reject it.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                DateUtils.parseDateStrictly("2023-01-32", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateLeniencyAllowsOverflow() throws ParseException {
        final Date lenient = DateUtils.parseDate("2023-01-32", "yyyy-MM-dd");
        final Calendar cal = toCal(lenient);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    // ---------------------------------------------------------------
    // round
    // ---------------------------------------------------------------

    @Test
    void testRoundHourUp() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.round(base, Calendar.HOUR_OF_DAY);
        final Calendar cal = toCal(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test
    void testRoundHourDown() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 15, 1, 231);
        final Date result = DateUtils.round(base, Calendar.HOUR_OF_DAY);
        final Calendar cal = toCal(result);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test
    void testRoundSemiMonthRoundsUpToSixteenth() {
        final Date base = makeDate(2002, Calendar.MARCH, 10, 0, 0, 0, 0);
        final Date result = DateUtils.round(base, DateUtils.SEMI_MONTH);
        final Calendar cal = toCal(result);
        assertEquals(16, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    @Test
    void testRoundSemiMonthRoundsUpToNextMonthFirst() {
        final Date base = makeDate(2002, Calendar.MARCH, 25, 0, 0, 0, 0);
        final Date result = DateUtils.round(base, DateUtils.SEMI_MONTH);
        final Calendar cal = toCal(result);
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
    }

    @Test
    void testRoundAmPmRoundsToNoon() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 7, 0, 0, 0);
        final Date result = DateUtils.round(base, Calendar.AM_PM);
        final Calendar cal = toCal(result);
        assertEquals(12, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testRoundObjectDispatch() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date fromDate = DateUtils.round((Object) base, Calendar.HOUR_OF_DAY);
        final Date fromCalendar = DateUtils.round((Object) toCal(base), Calendar.HOUR_OF_DAY);
        assertEquals(fromDate, fromCalendar);
    }

    @Test
    void testRoundObjectInvalidTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) Integer.valueOf(1), Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundHugeYearThrowsArithmeticException() {
        final Calendar cal = new GregorianCalendar(280000001, Calendar.JANUARY, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.round(cal, Calendar.MONTH);
            }
        });
    }

    // ---------------------------------------------------------------
    // set*
    // ---------------------------------------------------------------

    @Test
    void testSetDays() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        final Date result = DateUtils.setDays(base, 1);
        assertEquals(1, toCal(result).get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testSetDaysOutOfRangeThrowsIllegalArgumentException() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(base, 32);
            }
        });
    }

    @Test
    void testSetHoursBoundaries() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(0, toCal(DateUtils.setHours(base, 0)).get(Calendar.HOUR_OF_DAY));
        assertEquals(23, toCal(DateUtils.setHours(base, 23)).get(Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(base, 24);
            }
        });
    }

    @Test
    void testSetMillisecondsBoundaries() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(999, toCal(DateUtils.setMilliseconds(base, 999)).get(Calendar.MILLISECOND));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(base, 1000);
            }
        });
    }

    @Test
    void testSetMinutesBoundaries() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(59, toCal(DateUtils.setMinutes(base, 59)).get(Calendar.MINUTE));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(base, 60);
            }
        });
    }

    @Test
    void testSetMonthsBoundaries() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(Calendar.DECEMBER, toCal(DateUtils.setMonths(base, Calendar.DECEMBER)).get(Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(base, 12);
            }
        });
    }

    @Test
    void testSetSecondsBoundaries() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(59, toCal(DateUtils.setSeconds(base, 59)).get(Calendar.SECOND));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(base, 60);
            }
        });
    }

    @Test
    void testSetYears() {
        final Date base = makeDate(2023, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals(1999, toCal(DateUtils.setYears(base, 1999)).get(Calendar.YEAR));
    }

    @Test
    void testSetNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.setYears(null, 2000);
            }
        });
    }

    // ---------------------------------------------------------------
    // toCalendar / toLocalDateTime / toOffsetDateTime / toZonedDateTime
    // ---------------------------------------------------------------

    @Test
    void testToCalendar() {
        final Date date = new Date(123456789L);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar((Date) null);
            }
        });
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = new Date(123456789L);
        final java.util.TimeZone tz = java.util.TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date, cal.getTime());
        assertEquals(tz, cal.getTimeZone());
    }

    @Test
    void testToCalendarWithNullTimeZoneThrowsNullPointerException() {
        final Date date = new Date(123456789L);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(date, null);
            }
        });
    }

    @Test
    void testToLocalDateTimeAndOffsetAndZoned() {
        final Date date = new Date(0L);
        final java.util.TimeZone utc = java.util.TimeZone.getTimeZone("UTC");
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, utc);
        assertEquals(1970, ldt.getYear());
        assertEquals(1, ldt.getMonthValue());
        assertEquals(1, ldt.getDayOfMonth());

        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, utc);
        assertEquals(0, odt.getOffset().getTotalSeconds());

        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, utc);
        assertEquals(1970, zdt.getYear());

        // Default-timezone overloads must not throw and must be self-consistent with toInstant().
        assertEquals(date.toInstant(), DateUtils.toLocalDateTime(date).atZone(java.time.ZoneId.systemDefault()).toInstant());
        assertEquals(date.toInstant(), DateUtils.toOffsetDateTime(date).toInstant());
        assertEquals(date.toInstant(), DateUtils.toZonedDateTime(date).toInstant());
    }

    // ---------------------------------------------------------------
    // truncate
    // ---------------------------------------------------------------

    @Test
    void testTruncateDateHour() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.truncate(base, Calendar.HOUR_OF_DAY);
        final Calendar cal = toCal(result);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));
    }

    @Test
    void testTruncateDateMonth() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.truncate(base, Calendar.MONTH);
        final Calendar cal = toCal(result);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncateObjectDispatch() {
        final Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date fromDate = DateUtils.truncate((Object) base, Calendar.HOUR_OF_DAY);
        final Date fromCalendar = DateUtils.truncate((Object) toCal(base), Calendar.HOUR_OF_DAY);
        assertEquals(fromDate, fromCalendar);
    }

    @Test
    void testTruncateObjectInvalidTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) Boolean.TRUE, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateHugeYearThrowsArithmeticException() {
        final Calendar cal = new GregorianCalendar(280000001, Calendar.JANUARY, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(cal, Calendar.MONTH);
            }
        });
    }

    // ---------------------------------------------------------------
    // truncatedCompareTo / truncatedEquals
    // ---------------------------------------------------------------

    @Test
    void testTruncatedCompareToAndEquals() {
        final Date d1 = makeDate(2023, Calendar.JUNE, 15, 10, 30, 0, 0);
        final Date d2 = makeDate(2023, Calendar.JUNE, 15, 20, 0, 0, 0);
        final Date d3 = makeDate(2023, Calendar.JUNE, 16, 10, 30, 0, 0);

        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));

        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.DATE) < 0);
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DATE));
    }

    @Test
    void testTruncatedCompareToCalendarOverload() {
        final Calendar c1 = toCal(makeDate(2023, Calendar.JUNE, 15, 10, 30, 0, 0));
        final Calendar c2 = toCal(makeDate(2023, Calendar.JUNE, 15, 20, 0, 0, 0));
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
    }

    @Test
    void testTruncatedCompareToNullThrowsNullPointerException() {
        final Date d1 = makeDate(2023, Calendar.JUNE, 15, 10, 30, 0, 0);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedCompareTo(d1, (Date) null, Calendar.DATE);
            }
        });
    }

    // ---------------------------------------------------------------
    // constants and constructor
    // ---------------------------------------------------------------

    @Test
    void testMillisecondConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    void testRangeAndSemiMonthConstants() {
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    void testPublicConstructorIsUsable() {
        assertNotNull(new DateUtils());
    }
}
