/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrSubstitutor}.
 */
@SuppressWarnings("deprecation")
class StrSubstitutorAgentTest {

    @Test
    void testBasicReplaceWithMap() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("animal", "quick brown fox");
        values.put("target", "lazy dog");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final String result = sub.replace("The ${animal} jumps over the ${target}.");
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testStaticReplaceWithMap() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("name", "World");
        final String result = StrSubstitutor.replace((Object) "Hello ${name}!", values);
        assertEquals("Hello World!", result);
    }

    @Test
    void testStaticReplaceWithCustomPrefixSuffix() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("name", "World");
        final String result = StrSubstitutor.replace((Object) "Hello <name>!", values, "<", ">");
        assertEquals("Hello World!", result);
    }

    @Test
    void testStaticReplaceWithProperties() {
        final Properties props = new Properties();
        props.setProperty("name", "World");
        final String result = StrSubstitutor.replace((Object) "Hello ${name}!", props);
        assertEquals("Hello World!", result);
    }

    @Test
    void testStaticReplaceWithNullPropertiesReturnsSourceToString() {
        final String result = StrSubstitutor.replace((Object) "Hello ${name}!", (Properties) null);
        assertEquals("Hello ${name}!", result);
    }

    @Test
    void testStaticReplaceWithNullSourceAndNullPropertiesReturnsNull() {
        // Per javadoc: "source The source text ... null returns null."
        assertNull(StrSubstitutor.replace((Object) null, (Properties) null));
    }

    @Test
    void testReplaceNullSourceVariants() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertNull(sub.replace((String) null));
        assertNull(sub.replace((Object) null));
        assertNull(sub.replace((char[]) null));
        assertNull(sub.replace((CharSequence) null));
        assertNull(sub.replace((StrBuilder) null));
        assertNull(sub.replace((StringBuffer) null));
    }

    @Test
    void testReplaceUnknownVariableLeftUntouched() {
        final StrSubstitutor sub = new StrSubstitutor(new HashMap<String, String>());
        final String result = sub.replace("Hello ${unknown}!");
        assertEquals("Hello ${unknown}!", result);
    }

    @Test
    void testDefaultValueDelimiterUsedWhenVariableUnresolved() {
        final Map<String, String> values = new HashMap<String, String>();
        final StrSubstitutor sub = new StrSubstitutor(values);
        final String result = sub.replace("${undefined.number:-1234567890}.");
        assertEquals("1234567890.", result);
    }

    @Test
    void testDefaultValueNotUsedWhenVariableResolved() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "actual");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final String result = sub.replace("${x:-fallback}");
        assertEquals("actual", result);
    }

    @Test
    void testValueDelimiterDisabledWhenSetToEmpty() {
        final Map<String, String> values = new HashMap<String, String>();
        final StrSubstitutor sub = new StrSubstitutor(values);
        sub.setValueDelimiter("");
        assertNull(sub.getValueDelimiterMatcher());
        final String result = sub.replace("${undefined:-fallback}");
        assertEquals("${undefined:-fallback}", result);
    }

    @Test
    void testEscapeCharacterPreventsSubstitutionAndIsRemovedByDefault() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("name", "x");
        final StrSubstitutor sub = new StrSubstitutor(values);
        assertFalse(sub.isPreserveEscapes());
        final String result = sub.replace("The variable $${${name}} must be used.");
        assertEquals("The variable ${x} must be used.", result);
    }

    @Test
    void testPreserveEscapesKeepsEscapeCharacter() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("this-is-escaped", "should-not-appear");
        final StrSubstitutor sub = new StrSubstitutor(values);
        sub.setPreserveEscapes(true);
        assertTrue(sub.isPreserveEscapes());
        final String result = sub.replace("$${this-is-escaped}");
        assertEquals("$${this-is-escaped}", result);
    }

    @Test
    void testEscapeCharDisabledTreatsDollarLiterally() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("name", "value");
        final StrSubstitutor sub = new StrSubstitutor(values);
        sub.setEscapeChar((char) 0);
        assertEquals((char) 0, sub.getEscapeChar());
        final String result = sub.replace("$${name}");
        assertEquals("$value", result);
    }

    @Test
    void testEnableSubstitutionInVariableNames() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("key", "suffix");
        values.put("name-suffix", "resolved");
        final StrSubstitutor sub = new StrSubstitutor(values);
        assertFalse(sub.isEnableSubstitutionInVariables());
        sub.setEnableSubstitutionInVariables(true);
        assertTrue(sub.isEnableSubstitutionInVariables());
        final String result = sub.replace("${name-${key}}");
        assertEquals("resolved", result);
    }

    @Test
    void testSubstitutionInVariableNamesDisabledLeavesNestedUnresolved() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("key", "suffix");
        values.put("name-suffix", "resolved");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final String result = sub.replace("${name-${key}}");
        assertEquals("${name-${key}}", result);
    }

    @Test
    void testCyclicSubstitutionThrowsIllegalStateException() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("a", "${b}");
        values.put("b", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${a}");
            }
        });
        assertTrue(ex.getMessage().contains("Infinite loop"));
    }

    @Test
    void testDeepAcyclicNestingExceedsMaxDepth() {
        final int chainLength = 400;
        final Map<String, String> values = new HashMap<String, String>();
        for (int i = 0; i < chainLength; i++) {
            values.put("v" + i, "${v" + (i + 1) + "}");
        }
        values.put("v" + chainLength, "end");
        final StrSubstitutor sub = new StrSubstitutor(values);
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${v0}");
            }
        });
    }

    @Test
    void testReplaceWithOffsetAndLengthOnlyProcessesPortion() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "VALUE");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final String source = "prefix ${x} suffix";
        final int offset = source.indexOf("${x}");
        final String result = sub.replace(source, offset, 4);
        assertEquals("VALUE", result);
    }

    @Test
    void testReplaceInStrBuilderMutatesAndReturnsTrue() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "VALUE");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final StrBuilder builder = new StrBuilder("start ${x} end");
        final boolean altered = sub.replaceIn(builder);
        assertTrue(altered);
        assertEquals("start VALUE end", builder.toString());
    }

    @Test
    void testReplaceInStrBuilderReturnsFalseWhenNull() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertFalse(sub.replaceIn((StrBuilder) null));
    }

    @Test
    void testReplaceInStrBuilderReturnsFalseWhenNoVariables() {
        final StrSubstitutor sub = new StrSubstitutor(new HashMap<String, String>());
        final StrBuilder builder = new StrBuilder("no variables here");
        final boolean altered = sub.replaceIn(builder);
        assertFalse(altered);
        assertEquals("no variables here", builder.toString());
    }

    @Test
    void testReplaceInStringBuilderMutatesAndReturnsTrue() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "VALUE");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final StringBuilder sb = new StringBuilder("start ${x} end");
        final boolean altered = sub.replaceIn(sb);
        assertTrue(altered);
        assertEquals("start VALUE end", sb.toString());
    }

    @Test
    void testReplaceInStringBufferMutatesAndReturnsTrue() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "VALUE");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final StringBuffer buffer = new StringBuffer("start ${x} end");
        final boolean altered = sub.replaceIn(buffer);
        assertTrue(altered);
        assertEquals("start VALUE end", buffer.toString());
    }

    @Test
    void testReplaceCharArrayWithOffsetLength() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "VALUE");
        final StrSubstitutor sub = new StrSubstitutor(values);
        final char[] chars = "AA${x}BB".toCharArray();
        final String result = sub.replace(chars, 2, 4);
        assertEquals("VALUE", result);
    }

    @Test
    void testCustomVariablePrefixAndSuffixChars() {
        final Map<String, String> values = new HashMap<String, String>();
        values.put("x", "VALUE");
        final StrSubstitutor sub = new StrSubstitutor(values);
        sub.setVariablePrefix('<');
        sub.setVariableSuffix('>');
        final String result = sub.replace("<x>");
        assertEquals("VALUE", result);
    }

    @Test
    void testDefaultPrefixSuffixMatchersAreTheStandardOnes() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertSame(StrSubstitutor.DEFAULT_PREFIX, sub.getVariablePrefixMatcher());
        assertSame(StrSubstitutor.DEFAULT_SUFFIX, sub.getVariableSuffixMatcher());
        assertEquals(StrSubstitutor.DEFAULT_ESCAPE, sub.getEscapeChar());
    }

    @Test
    void testSetVariableResolverCustomLookup() {
        final StrLookup<String> upperCaseLookup = new StrLookup<String>() {
            @Override
            public String lookup(final String key) {
                return key.toUpperCase();
            }
        };
        final StrSubstitutor sub = new StrSubstitutor();
        sub.setVariableResolver(upperCaseLookup);
        assertSame(upperCaseLookup, sub.getVariableResolver());
        final String result = sub.replace("${abc}");
        assertEquals("ABC", result);
    }

    @Test
    void testResolveVariableCanBeOverriddenBySubclass() {
        final StrSubstitutor sub = new StrSubstitutor() {
            @Override
            protected String resolveVariable(final String variableName, final StrBuilder buf, final int startPos, final int endPos) {
                return "[" + variableName + "]";
            }
        };
        final String result = sub.replace("${foo}");
        assertEquals("[foo]", result);
    }

    @Test
    void testConstructorRejectsNullPrefixWithIllegalArgumentException() {
        // Per javadoc: "@throws IllegalArgumentException Thrown if the prefix or suffix is null."
        final Map<String, String> values = new HashMap<String, String>();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new StrSubstitutor(values, null, "}");
            }
        });
    }

    @Test
    void testConstructorRejectsNullSuffixWithIllegalArgumentException() {
        // Per javadoc: "@throws IllegalArgumentException Thrown if the prefix or suffix is null."
        final Map<String, String> values = new HashMap<String, String>();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new StrSubstitutor(values, "${", null);
            }
        });
    }

    @Test
    void testReplaceWithStringReturnsSameInstanceWhenUnaltered() {
        final StrSubstitutor sub = new StrSubstitutor(new HashMap<String, String>());
        final String source = "no variables";
        final String result = sub.replace(source);
        assertSame(source, result);
    }

    @Test
    void testReplaceSystemProperties() {
        final String javaVersion = System.getProperty("java.version");
        final String result = StrSubstitutor.replaceSystemProperties("version=${java.version}");
        assertEquals("version=" + javaVersion, result);
    }
}
