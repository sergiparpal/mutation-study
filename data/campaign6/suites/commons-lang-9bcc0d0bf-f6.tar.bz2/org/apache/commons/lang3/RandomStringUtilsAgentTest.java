/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
public class RandomStringUtilsAgentTest {

    private static void assertAllCharsIn(final String s, final String allowed) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(allowed.indexOf(c) >= 0, "Unexpected char '" + c + "' (" + (int) c + ") not in allowed set");
        }
    }

    // ---- deprecated static random(...) overloads ----

    @Test
    public void testRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    public void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    public void testRandomPositiveCountLength() {
        final String s = RandomStringUtils.random(257);
        assertEquals(257, s.length());
    }

    @Test
    public void testRandomLettersOnly() {
        final String s = RandomStringUtils.random(200, true, false);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)), "Expected only letters, got '" + s.charAt(i) + "'");
        }
    }

    @Test
    public void testRandomNumbersOnly() {
        final String s = RandomStringUtils.random(200, false, true);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)), "Expected only digits, got '" + s.charAt(i) + "'");
        }
    }

    @Test
    public void testRandomLettersAndNumbers() {
        final String s = RandomStringUtils.random(200, true, true);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetterOrDigit(c), "Expected letter or digit, got '" + c + "'");
        }
    }

    @Test
    public void testRandomCustomCharsArray() {
        final String s = RandomStringUtils.random(100, 'x', 'y', 'z');
        assertEquals(100, s.length());
        assertAllCharsIn(s, "xyz");
    }

    @Test
    public void testRandomCustomCharsString() {
        final String s = RandomStringUtils.random(100, "xyz");
        assertEquals(100, s.length());
        assertAllCharsIn(s, "xyz");
    }

    @Test
    public void testRandomEmptyCharsStringThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    // ---- full overload: random(count, start, end, letters, digits, chars, random) ----

    @Test
    public void testRandomFullOverloadCountZeroIgnoresOtherValidation() {
        // count == 0 is checked before start/end validation, so even an invalid
        // start/end combination must not throw: the result must simply be empty.
        final String s = RandomStringUtils.random(0, 5, 2, true, true, null, new Random());
        assertEquals("", s);
    }

    @Test
    public void testRandomFullOverloadNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-5, 0, 0, false, false, null, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 0, false, false, new char[0], new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadEndLessThanOrEqualStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 5, 2, false, false, null, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false, null, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadNoLettersInCustomCharsThrows() {
        final char[] onlyDigits = { '1', '2', '3' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, onlyDigits.length, true, false, onlyDigits, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadNoDigitsInCustomCharsThrows() {
        final char[] onlyLetters = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, onlyLetters.length, false, true, onlyLetters, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadCustomCharsAreRespected() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(500, 0, chars.length, false, false, chars, new Random());
        assertEquals(500, s.length());
        assertAllCharsIn(s, "xyz");
    }

    @Test
    public void testRandomFullOverloadArrayIndexOutOfBoundsWhenRangeExceedsCharsLength() {
        // end (5) exceeds chars.length (2): generated indices in [2,5) are valid
        // (not rejected, since they are < end) but out of bounds for chars[].
        // With a large count, hitting one of those indices is practically certain.
        final char[] chars = { 'a', 'b' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(2000, 0, 5, false, false, chars, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadRejectsIndefinitelyInvalidRangeThrows() {
        // The entire range [0xD800, 0xD801) is a single lone high-surrogate code
        // point, which is always rejected by the SURROGATE check; bounded
        // rejection sampling must eventually give up rather than loop forever.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0xD800, 0xD801, false, false, null, new Random());
            }
        });
    }

    @Test
    public void testRandomFullOverloadNullCharsNullRandomUsesGivenCharSubsetOnly() {
        // chars == null, pure ASCII digit range: start='0', end='9'+1
        final String s = RandomStringUtils.random(300, '0', '9' + 1, false, false, null, new Random());
        assertEquals(300, s.length());
        assertAllCharsIn(s, "0123456789");
    }

    // ---- randomAlphabetic / randomAlphanumeric / randomAscii / randomGraph / randomNumeric / randomPrint ----

    @Test
    public void testRandomAlphabeticAllLetters() {
        final String s = RandomStringUtils.randomAlphabetic(150);
        assertEquals(150, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @Test
    public void testRandomAlphabeticRangeLength() {
        final String s = RandomStringUtils.randomAlphabetic(3, 3);
        assertEquals(3, s.length());
    }

    @Test
    public void testRandomAlphabeticRangeMinGreaterThanMaxThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(10, 5);
            }
        });
    }

    @Test
    public void testRandomAlphanumericAllAlphanumeric() {
        final String s = RandomStringUtils.randomAlphanumeric(150);
        assertEquals(150, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)));
        }
    }

    @Test
    public void testRandomNumericAllDigits() {
        final String s = RandomStringUtils.randomNumeric(150);
        assertEquals(150, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    public void testRandomAsciiInRange() {
        final String s = RandomStringUtils.randomAscii(500);
        assertEquals(500, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char '" + c + "' (" + (int) c + ") out of ASCII [32,126]");
        }
    }

    @Test
    public void testRandomNegativeCountOverloadsThrow() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphanumeric(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomNumeric(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAscii(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomGraph(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomPrint(-1);
            }
        });
    }

    // ---- singleton instances ----

    @Test
    public void testSecureIsSingleton() {
        assertSame(RandomStringUtils.secure(), RandomStringUtils.secure());
    }

    @Test
    public void testInsecureIsSingleton() {
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
    }

    @Test
    public void testSecureStrongIsSingleton() {
        assertSame(RandomStringUtils.secureStrong(), RandomStringUtils.secureStrong());
    }

    @Test
    public void testSecureAndInsecureAreDifferentInstances() {
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.insecure());
    }

    @Test
    public void testDeprecatedConstructorProducesWorkingInstance() {
        @SuppressWarnings("deprecation")
        final RandomStringUtils instance = new RandomStringUtils();
        final String s = instance.next(50);
        assertEquals(50, s.length());
    }

    @Test
    public void testToStringContainsClassName() {
        final String s = RandomStringUtils.secure().toString();
        assertTrue(s.startsWith("RandomStringUtils [random="));
    }

    // ---- instance methods: next / nextAlphabetic / nextAlphanumeric / nextAscii / nextGraph / nextNumeric / nextPrint ----

    @Test
    public void testNextZeroLength() {
        assertEquals("", RandomStringUtils.secure().next(0));
        assertEquals("", RandomStringUtils.insecure().next(0));
    }

    @Test
    public void testNextNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-3);
            }
        });
    }

    @Test
    public void testNextWithCharsVarargs() {
        final String s = RandomStringUtils.secure().next(80, '1', '2');
        assertEquals(80, s.length());
        assertAllCharsIn(s, "12");
    }

    @Test
    public void testNextWithNullCharsVarargs() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.secure().next(10, nullChars);
        assertEquals(10, s.length());
    }

    @Test
    public void testNextWithStringChars() {
        final String s = RandomStringUtils.secure().next(80, "AB");
        assertEquals(80, s.length());
        assertAllCharsIn(s, "AB");
    }

    @Test
    public void testNextWithNullStringChars() {
        final String nullString = null;
        final String s = RandomStringUtils.secure().next(10, nullString);
        assertEquals(10, s.length());
    }

    @Test
    public void testNextAlphabeticInstance() {
        final String s = RandomStringUtils.secure().nextAlphabetic(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @Test
    public void testNextAlphabeticRangeEndExclusive() {
        // minLengthInclusive == maxLengthExclusive is allowed and yields exactly that length.
        final String s = RandomStringUtils.secure().nextAlphabetic(7, 7);
        assertEquals(7, s.length());
    }

    @Test
    public void testNextAlphanumericInstance() {
        final String s = RandomStringUtils.secure().nextAlphanumeric(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)));
        }
    }

    @Test
    public void testNextNumericInstance() {
        final String s = RandomStringUtils.secure().nextNumeric(100);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    public void testNextAsciiInstance() {
        final String s = RandomStringUtils.secure().nextAscii(300);
        assertEquals(300, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    public void testNextGraphInstanceExcludesSpace() {
        final String s = RandomStringUtils.secure().nextGraph(300);
        assertEquals(300, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertFalse(c == ' ', "Graph class must not contain spaces");
            assertTrue(c >= 33 && c <= 126, "Char '" + c + "' (" + (int) c + ") out of graph range [33,126]");
        }
    }

    @Test
    public void testNextGraphInstanceCanProduceTilde() {
        // The POSIX [:graph:] class is '!' (33) through '~' (126) inclusive, as
        // documented. With a large enough sample, '~' must eventually appear.
        final String s = RandomStringUtils.secure().nextGraph(200000);
        assertTrue(s.indexOf('~') >= 0, "nextGraph() never produced '~' (126), the upper bound of the documented [:graph:] range");
    }

    @Test
    public void testNextPrintInstanceIncludesSpaceButNoControl() {
        final String s = RandomStringUtils.secure().nextPrint(300);
        assertEquals(300, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char '" + c + "' (" + (int) c + ") out of print range [32,126]");
        }
    }

    @Test
    public void testNextPrintInstanceCanProduceTilde() {
        // The POSIX [:print:] class is ' ' (32) through '~' (126) inclusive, as
        // documented. With a large enough sample, '~' must eventually appear.
        final String s = RandomStringUtils.secure().nextPrint(200000);
        assertTrue(s.indexOf('~') >= 0, "nextPrint() never produced '~' (126), the upper bound of the documented [:print:] range");
    }

    @Test
    public void testRandomGraphStaticCanProduceTilde() {
        final String s = RandomStringUtils.randomGraph(200000);
        assertTrue(s.indexOf('~') >= 0, "randomGraph() never produced '~' (126), the upper bound of the documented [:graph:] range");
    }

    @Test
    public void testRandomPrintStaticCanProduceTilde() {
        final String s = RandomStringUtils.randomPrint(200000);
        assertTrue(s.indexOf('~') >= 0, "randomPrint() never produced '~' (126), the upper bound of the documented [:print:] range");
    }

    @Test
    public void testNextRangeMethodsNegativeCountThrow() {
        final RandomStringUtils r = RandomStringUtils.secure();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                r.nextAlphabetic(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                r.nextAlphanumeric(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                r.nextNumeric(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                r.nextAscii(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                r.nextGraph(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                r.nextPrint(-1);
            }
        });
    }

    @Test
    public void testInsecureInstanceWorksEndToEnd() {
        final RandomStringUtils r = RandomStringUtils.insecure();
        final String s = r.nextAlphanumeric(64);
        assertEquals(64, s.length());
        assertNotNull(s);
    }

    @Test
    public void testSecureStrongInstanceWorksEndToEnd() {
        final RandomStringUtils r = RandomStringUtils.secureStrong();
        final String s = r.next(10);
        assertEquals(10, s.length());
    }

    @Test
    public void testNextFullUnicodeRangeProducesValidSurrogatePairsAndLength() {
        // next(count) with no letters/numbers restriction draws from the whole
        // code point range; the resulting String.length() (UTF-16 units) must
        // equal count exactly, and no lone (unpaired) surrogate may appear.
        final int count = 4000;
        final String s = RandomStringUtils.secure().next(count);
        assertEquals(count, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (Character.isHighSurrogate(c)) {
                assertTrue(i + 1 < s.length() && Character.isLowSurrogate(s.charAt(i + 1)),
                        "Lone high surrogate at index " + i);
            } else if (Character.isLowSurrogate(c)) {
                assertTrue(i > 0 && Character.isHighSurrogate(s.charAt(i - 1)), "Lone low surrogate at index " + i);
            }
        }
    }

    @Test
    public void testNextFullUnicodeRangeExcludesUnassignedPrivateUseAndSurrogateCategories() {
        final String s = RandomStringUtils.secure().next(4000);
        int i = 0;
        while (i < s.length()) {
            final int cp = s.codePointAt(i);
            final int type = Character.getType(cp);
            assertFalse(type == Character.UNASSIGNED, "Unassigned code point " + cp + " must not be generated");
            assertFalse(type == Character.PRIVATE_USE, "Private-use code point " + cp + " must not be generated");
            assertFalse(type == Character.SURROGATE, "Lone surrogate code point " + cp + " must not be generated");
            i += Character.charCount(cp);
        }
    }
}
