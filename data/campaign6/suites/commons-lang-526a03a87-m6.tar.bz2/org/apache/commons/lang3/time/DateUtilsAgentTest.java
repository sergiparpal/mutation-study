/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private Calendar newCalendar(final int year, final int month, final int day, final int hour, final int minute, final int second,
            final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private Date newDate(final int year, final int month, final int day, final int hour, final int minute, final int second, final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ---------------------------------------------------------------
    // add*
    // ---------------------------------------------------------------

    @Test
    void testAddDays() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 12, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 5);
        assertEquals(newDate(2005, Calendar.JANUARY, 6, 12, 0, 0, 0), result);
        // original unchanged
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 12, 0, 0, 0), date);
        assertEquals(newDate(2004, Calendar.DECEMBER, 27, 12, 0, 0, 0), DateUtils.addDays(date, -5));
    }

    @Test
    void testAddDaysNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addDays(null, 1));
    }

    @Test
    void testAddHours() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 2, 1, 0, 0, 0), DateUtils.addHours(date, 2));
    }

    @Test
    void testAddHoursNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addHours(null, 1));
    }

    @Test
    void testAddMilliseconds() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 500);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 0, 0, 1, 0), DateUtils.addMilliseconds(date, 500));
    }

    @Test
    void testAddMillisecondsNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addMilliseconds(null, 1));
    }

    @Test
    void testAddMinutes() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 59, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 1, 4, 0, 0), DateUtils.addMinutes(date, 5));
    }

    @Test
    void testAddMinutesNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addMinutes(null, 1));
    }

    @Test
    void testAddMonths() {
        final Date date = newDate(2005, Calendar.NOVEMBER, 15, 0, 0, 0, 0);
        assertEquals(newDate(2006, Calendar.JANUARY, 15, 0, 0, 0, 0), DateUtils.addMonths(date, 2));
    }

    @Test
    void testAddMonthsNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addMonths(null, 1));
    }

    @Test
    void testAddSeconds() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 59, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 0, 1, 4, 0), DateUtils.addSeconds(date, 5));
    }

    @Test
    void testAddSecondsNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addSeconds(null, 1));
    }

    @Test
    void testAddWeeks() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 15, 0, 0, 0, 0), DateUtils.addWeeks(date, 2));
    }

    @Test
    void testAddWeeksNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addWeeks(null, 1));
    }

    @Test
    void testAddYears() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2008, Calendar.JANUARY, 1, 0, 0, 0, 0), DateUtils.addYears(date, 3));
    }

    @Test
    void testAddYearsNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.addYears(null, 1));
    }

    // ---------------------------------------------------------------
    // ceiling
    // ---------------------------------------------------------------

    @Test
    void testCeilingDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling(date, Calendar.HOUR));
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.ceiling(date, Calendar.MONTH));
    }

    @Test
    void testCeilingCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(cal, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result.getTime());
        // original is not mutated
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), cal.getTime());
    }

    @Test
    void testCeilingObject() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling((Object) date, Calendar.HOUR));
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling((Object) cal, Calendar.HOUR));
    }

    @Test
    void testCeilingObjectInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling("not a date", Calendar.HOUR));
    }

    @Test
    void testCeilingNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Date) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Calendar) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Object) null, Calendar.HOUR));
    }

    @Test
    void testCeilingYearTooLarge() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(cal, Calendar.HOUR));
    }

    @Test
    void testCeilingInvalidField() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.ceiling(date, -9999));
    }

    // ---------------------------------------------------------------
    // getFragmentIn*
    // ---------------------------------------------------------------

    @Test
    void testGetFragmentInDays() {
        final Date date = newDate(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(28, DateUtils.getFragmentInDays(date, Calendar.MONTH));
        assertEquals(59, DateUtils.getFragmentInDays(date, Calendar.YEAR));
        assertEquals(0, DateUtils.getFragmentInDays(date, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInDaysCalendar() {
        final Calendar cal = newCalendar(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(28, DateUtils.getFragmentInDays(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInHours() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(date, Calendar.DAY_OF_YEAR));
        assertEquals(127, DateUtils.getFragmentInHours(date, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(date, Calendar.HOUR_OF_DAY));
        // 5 whole days (day 6 of the month) plus 7h15m within the day: 5 * 1440 + 7 * 60 + 15
        assertEquals(7635, DateUtils.getFragmentInMinutes(date, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(date, Calendar.MINUTE));
        assertEquals(26110, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(date, Calendar.SECOND));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(date, Calendar.MINUTE));
        assertEquals(0, DateUtils.getFragmentInMilliseconds(date, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentNullDate() {
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR));
    }

    @Test
    void testGetFragmentUnsupportedField() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInDays(date, -9999));
    }

    // ---------------------------------------------------------------
    // isSameDay / isSameInstant / isSameLocalTime
    // ---------------------------------------------------------------

    @Test
    void testIsSameDayDate() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    @Test
    void testIsSameDayCalendar() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
    }

    @Test
    void testIsSameDayNull() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay(d1, null));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Date) null, d1));
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 1);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    @Test
    void testIsSameInstantNull() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant(d1, null));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant(null, d1));
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
        c2.add(Calendar.MILLISECOND, 1);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarClass() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = new java.util.GregorianCalendar() {
            private static final long serialVersionUID = 1L;
        };
        c2.setTime(c1.getTime());
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeNull() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(c1, null));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(null, c1));
    }

    // ---------------------------------------------------------------
    // iterator
    // ---------------------------------------------------------------

    @Test
    void testIteratorWeekSunday() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar last = null;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertNotNull(last);
    }

    @Test
    void testIteratorMonthSunday() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            final Calendar c = it.next();
            assertNotNull(c);
            count++;
        }
        // June 30 2002 (Sunday) through Aug 3 2002 (Saturday) inclusive = 35 days
        assertEquals(35, count);
    }

    @Test
    void testIteratorObject() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<?> it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
        final Calendar cal = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<?> it2 = DateUtils.iterator((Object) cal, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it2.hasNext());
    }

    @Test
    void testIteratorObjectInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.iterator("foo", DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorInvalidRangeStyle() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(focus, -9999));
    }

    @Test
    void testIteratorNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorExhausted() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    // ---------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ---------------------------------------------------------------

    @Test
    void testParseDate() throws ParseException {
        final Date parsed = DateUtils.parseDate("2005-07-27", "yyyy-MM-dd");
        final Date expected = newDate(2005, Calendar.JULY, 27, 0, 0, 0, 0);
        assertEquals(expected, parsed);
    }

    @Test
    void testParseDateMultiplePatternsPicksFirstMatch() throws ParseException {
        final Date parsed = DateUtils.parseDate("2005-07-27", "dd/MM/yyyy", "yyyy-MM-dd");
        final Date expected = newDate(2005, Calendar.JULY, 27, 0, 0, 0, 0);
        assertEquals(expected, parsed);
    }

    @Test
    void testParseDateWithLocale() throws ParseException {
        final Date parsed = DateUtils.parseDate("27-July-2005", Locale.US, "dd-MMMM-yyyy");
        final Date expected = newDate(2005, Calendar.JULY, 27, 0, 0, 0, 0);
        assertEquals(expected, parsed);
    }

    @Test
    void testParseDateLenientAllowsOutOfRange() throws ParseException {
        // Lenient parsing allows day-of-month 32 to roll into the next month.
        final Date parsed = DateUtils.parseDate("2005-01-32", "yyyy-MM-dd");
        final Date expected = newDate(2005, Calendar.FEBRUARY, 1, 0, 0, 0, 0);
        assertEquals(expected, parsed);
    }

    @Test
    void testParseDateStrictlyRejectsOutOfRange() {
        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly("2005-01-32", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateStrictlyValid() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2005-07-27", "yyyy-MM-dd");
        assertEquals(newDate(2005, Calendar.JULY, 27, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateNoMatchingPattern() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2005-07-27", "dd/MM/yyyy"));
    }

    @Test
    void testParseDateNoPatterns() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2005-07-27"));
    }

    @Test
    void testParseDateNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate(null, "yyyy-MM-dd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate("2005-07-27", (String[]) null));
    }

    // ---------------------------------------------------------------
    // round
    // ---------------------------------------------------------------

    @Test
    void testRoundDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.round(date, Calendar.HOUR));
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.round(date, Calendar.MONTH));
    }

    @Test
    void testRoundCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar rounded = DateUtils.round(cal, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded.getTime());
        // original not mutated
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), cal.getTime());
    }

    @Test
    void testRoundObject() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.round((Object) date, Calendar.HOUR));
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.round((Object) cal, Calendar.HOUR));
    }

    @Test
    void testRoundObjectInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.round(Integer.valueOf(1), Calendar.HOUR));
    }

    @Test
    void testRoundNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.round((Date) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Calendar) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Object) null, Calendar.HOUR));
    }

    @Test
    void testRoundYearTooLarge() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.round(cal, Calendar.HOUR));
    }

    @Test
    void testRoundSemiMonth() {
        // Day 1 is already the anchor of the first half: stays at day 1.
        final Date d1 = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0), DateUtils.round(d1, DateUtils.SEMI_MONTH));
        // Day 10 is closer to day 16 (offset 9 > 7) than to day 1.
        final Date d2 = newDate(2005, Calendar.JANUARY, 10, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 16, 0, 0, 0, 0), DateUtils.round(d2, DateUtils.SEMI_MONTH));
        // Day 25 is closer to the 1st of next month (offset 9 > 7 in the second half) than to day 16.
        final Date d3 = newDate(2005, Calendar.JANUARY, 25, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.FEBRUARY, 1, 0, 0, 0, 0), DateUtils.round(d3, DateUtils.SEMI_MONTH));
    }

    // ---------------------------------------------------------------
    // set*
    // ---------------------------------------------------------------

    @Test
    void testSetDays() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 22, 0, 0, 0, 0), DateUtils.setDays(date, 22));
    }

    @Test
    void testSetDaysInvalid() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 32));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 0));
    }

    @Test
    void testSetHours() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 23, 0, 0, 0), DateUtils.setHours(date, 23));
    }

    @Test
    void testSetHoursInvalid() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, 24));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, -1));
    }

    @Test
    void testSetMilliseconds() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 999), DateUtils.setMilliseconds(date, 999));
    }

    @Test
    void testSetMillisecondsInvalid() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, 1000));
    }

    @Test
    void testSetMinutes() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 0, 59, 0, 0), DateUtils.setMinutes(date, 59));
    }

    @Test
    void testSetMinutesInvalid() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, 60));
    }

    @Test
    void testSetMonths() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.DECEMBER, 1, 0, 0, 0, 0), DateUtils.setMonths(date, Calendar.DECEMBER));
    }

    @Test
    void testSetMonthsInvalid() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, 12));
    }

    @Test
    void testSetSeconds() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(2005, Calendar.JANUARY, 1, 0, 0, 59, 0), DateUtils.setSeconds(date, 59));
    }

    @Test
    void testSetSecondsInvalid() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, 60));
    }

    @Test
    void testSetYears() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newDate(1999, Calendar.JANUARY, 1, 0, 0, 0, 0), DateUtils.setYears(date, 1999));
    }

    @Test
    void testSetNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.setDays(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setYears(null, 2000));
    }

    // ---------------------------------------------------------------
    // toCalendar / toLocalDateTime / toOffsetDateTime / toZonedDateTime
    // ---------------------------------------------------------------

    @Test
    void testToCalendar() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null));
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date, cal.getTime());
        assertEquals(tz, cal.getTimeZone());
    }

    @Test
    void testToCalendarWithTimeZoneNull() {
        final Date date = newDate(2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC")));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(date, null));
    }

    @Test
    void testToLocalDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, tz);
        assertEquals(1970, ldt.getYear());
        assertEquals(1, ldt.getMonthValue());
        assertEquals(1, ldt.getDayOfMonth());
        assertEquals(0, ldt.getHour());
    }

    @Test
    void testToLocalDateTimeDefaultZone() {
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date);
        assertNotNull(ldt);
    }

    @Test
    void testToOffsetDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, tz);
        assertEquals(1970, odt.getYear());
        assertEquals(0, odt.getOffset().getTotalSeconds());
    }

    @Test
    void testToOffsetDateTimeDefaultZone() {
        final Date date = new Date(0L);
        assertNotNull(DateUtils.toOffsetDateTime(date));
    }

    @Test
    void testToZonedDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, tz);
        assertEquals(1970, zdt.getYear());
    }

    @Test
    void testToZonedDateTimeDefaultZone() {
        final Date date = new Date(0L);
        assertNotNull(DateUtils.toZonedDateTime(date));
    }

    // ---------------------------------------------------------------
    // truncate
    // ---------------------------------------------------------------

    @Test
    void testTruncateDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate(date, Calendar.HOUR));
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.truncate(date, Calendar.MONTH));
    }

    @Test
    void testTruncateCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar truncated = DateUtils.truncate(cal, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncated.getTime());
        // original not mutated
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), cal.getTime());
    }

    @Test
    void testTruncateObject() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate((Object) date, Calendar.HOUR));
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate((Object) cal, Calendar.HOUR));
    }

    @Test
    void testTruncateObjectInvalidType() {
        assertThrows(ClassCastException.class, () -> DateUtils.truncate(Integer.valueOf(1), Calendar.HOUR));
    }

    @Test
    void testTruncateNull() {
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Date) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Calendar) null, Calendar.HOUR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Object) null, Calendar.HOUR));
    }

    @Test
    void testTruncateYearTooLarge() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.truncate(cal, Calendar.HOUR));
    }

    @Test
    void testTruncateMilliseconds() {
        // truncating at MILLISECOND is a no-op (returns input unchanged).
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(date, DateUtils.truncate(date, Calendar.MILLISECOND));
    }

    // ---------------------------------------------------------------
    // truncatedCompareTo / truncatedEquals
    // ---------------------------------------------------------------

    @Test
    void testTruncatedCompareToDate() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 29, 0, 0, 0, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DAY_OF_MONTH));
        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.DAY_OF_MONTH) < 0);
        assertTrue(DateUtils.truncatedCompareTo(d3, d1, Calendar.DAY_OF_MONTH) > 0);
    }

    @Test
    void testTruncatedCompareToCalendar() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTruncatedEqualsDate() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 29, 0, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTruncatedEqualsCalendar() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 9, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTruncatedComparisonNull() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedCompareTo(d1, null, Calendar.DATE));
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedEquals(null, d1, Calendar.DATE));
    }

    // ---------------------------------------------------------------
    // constants and misc
    // ---------------------------------------------------------------

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    void testDeprecatedPublicConstructor() {
        assertNotNull(new DateUtils());
    }

    @Test
    void testDateIteratorDirectUsage() {
        final Calendar start = newCalendar(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        final Calendar end = newCalendar(2002, Calendar.MARCH, 3, 0, 0, 0, 0);
        final DateUtils.DateIterator it = new DateUtils.DateIterator(start, end);
        int count = 0;
        while (it.hasNext()) {
            final Calendar c = it.next();
            assertNotNull(c);
            count++;
        }
        assertEquals(3, count);
        assertThrows(NoSuchElementException.class, it::next);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }
}
