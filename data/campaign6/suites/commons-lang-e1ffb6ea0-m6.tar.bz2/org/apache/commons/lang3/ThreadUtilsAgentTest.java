/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.Collection;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ThreadUtils}.
 */
class ThreadUtilsAgentTest {

    /**
     * A thread that keeps running (spinning on short sleeps) until told to stop, so that it stays
     * active and discoverable while a test runs.
     */
    private static final class SpinningThread extends Thread {

        private final AtomicBoolean running = new AtomicBoolean(true);

        SpinningThread(final String name) {
            super(name);
            setDaemon(true);
        }

        SpinningThread(final ThreadGroup group, final String name) {
            super(group, name);
            setDaemon(true);
        }

        @Override
        public void run() {
            while (running.get()) {
                try {
                    Thread.sleep(10);
                } catch (final InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }

        void stopRunning() {
            running.set(false);
        }
    }

    private String uniqueName(final String prefix) {
        return prefix + "-" + UUID.randomUUID();
    }

    // ---- findThreadById(long) ----

    @Test
    void testFindThreadByIdRejectsNonPositiveIds() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(0L);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(-1L);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(Long.MIN_VALUE);
            }
        });
    }

    @Test
    void testFindThreadByIdFindsCurrentThread() {
        final long id = Thread.currentThread().getId();
        final Thread found = ThreadUtils.findThreadById(id);
        assertSame(Thread.currentThread(), found);
    }

    @Test
    void testFindThreadByIdReturnsNullWhenNotFound() {
        assertNull(ThreadUtils.findThreadById(Long.MAX_VALUE));
    }

    // ---- findThreadById(long, String) ----

    @Test
    void testFindThreadByIdWithGroupNameRequiresNonNullGroupName() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(id, (String) null);
            }
        });
    }

    @Test
    void testFindThreadByIdWithGroupNameMatchAndMismatch() {
        final long id = Thread.currentThread().getId();
        final String actualGroupName = Thread.currentThread().getThreadGroup().getName();
        assertSame(Thread.currentThread(), ThreadUtils.findThreadById(id, actualGroupName));
        assertNull(ThreadUtils.findThreadById(id, uniqueName("no-such-group")));
    }

    // ---- findThreadById(long, ThreadGroup) ----

    @Test
    void testFindThreadByIdWithThreadGroupRequiresNonNullGroup() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(id, (ThreadGroup) null);
            }
        });
    }

    @Test
    void testFindThreadByIdWithThreadGroupMatchAndMismatch() {
        final long id = Thread.currentThread().getId();
        final ThreadGroup actualGroup = Thread.currentThread().getThreadGroup();
        assertSame(Thread.currentThread(), ThreadUtils.findThreadById(id, actualGroup));
        final ThreadGroup otherGroup = new ThreadGroup(uniqueName("other-group"));
        assertNull(ThreadUtils.findThreadById(id, otherGroup));
    }

    // ---- findThreadGroups(Predicate<ThreadGroup>) ----

    @Test
    void testFindThreadGroupsPredicateRequiresNonNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups((Predicate<ThreadGroup>) null);
            }
        });
    }

    // ---- findThreadGroups(ThreadGroup, boolean, Predicate<ThreadGroup>) ----

    @Test
    void testFindThreadGroupsWithGroupRecursePredicateNullChecks() {
        final Predicate<ThreadGroup> alwaysTrue = new Predicate<ThreadGroup>() {
            @Override
            public boolean test(final ThreadGroup t) {
                return true;
            }
        };
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups(null, true, alwaysTrue);
            }
        });
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups(group, true, (Predicate<ThreadGroup>) null);
            }
        });
    }

    // ---- findThreadGroupsByName(String) ----

    @Test
    void testFindThreadGroupsByNameRequiresNonNullName() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroupsByName(null);
            }
        });
    }

    @Test
    void testFindThreadGroupsByNameFindsCreatedGroup() {
        final String name = uniqueName("group");
        final ThreadGroup group = new ThreadGroup(name);
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName(name);
        assertTrue(found.contains(group));
    }

    @Test
    void testFindThreadGroupsByNameReturnsEmptyWhenNotFound() {
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName(uniqueName("no-such-group"));
        assertTrue(found.isEmpty());
    }

    @Test
    void testFindThreadGroupsResultIsUnmodifiable() {
        final Collection<ThreadGroup> found = ThreadUtils.getAllThreadGroups();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                found.clear();
            }
        });
    }

    // ---- findThreads(Predicate<Thread>) ----

    @Test
    void testFindThreadsPredicateRequiresNonNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads((Predicate<Thread>) null);
            }
        });
    }

    // ---- findThreads(ThreadGroup, boolean, Predicate<Thread>) ----

    @Test
    void testFindThreadsWithGroupRecursePredicateNullChecks() {
        final Predicate<Thread> alwaysTrue = new Predicate<Thread>() {
            @Override
            public boolean test(final Thread t) {
                return true;
            }
        };
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads(null, true, alwaysTrue);
            }
        });
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads(group, true, (Predicate<Thread>) null);
            }
        });
    }

    // ---- findThreadsByName(String) ----

    @Test
    void testFindThreadsByNameRequiresNonNullName() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName(null);
            }
        });
    }

    @Test
    void testFindThreadsByNameFindsRunningThread() throws InterruptedException {
        final String name = uniqueName("thread");
        final SpinningThread worker = new SpinningThread(name);
        worker.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreadsByName(name);
            assertTrue(found.contains(worker));
        } finally {
            worker.stopRunning();
            worker.join(2000);
        }
        assertFalse(worker.isAlive());
    }

    @Test
    void testFindThreadsByNameReturnsEmptyWhenNotFound() {
        final Collection<Thread> found = ThreadUtils.findThreadsByName(uniqueName("no-such-thread"));
        assertTrue(found.isEmpty());
    }

    // ---- findThreadsByName(String, String) ----

    @Test
    void testFindThreadsByNameAndGroupNameNullChecks() {
        final String groupName = Thread.currentThread().getThreadGroup().getName();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName(null, groupName);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName("whatever", (String) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameAndGroupNameFindsThread() throws InterruptedException {
        final String groupName = uniqueName("group");
        final String threadName = uniqueName("thread");
        final ThreadGroup group = new ThreadGroup(groupName);
        final SpinningThread worker = new SpinningThread(group, threadName);
        worker.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreadsByName(threadName, groupName);
            assertTrue(found.contains(worker));
            assertTrue(ThreadUtils.findThreadsByName(uniqueName("other"), groupName).isEmpty());
        } finally {
            worker.stopRunning();
            worker.join(2000);
        }
    }

    // ---- findThreadsByName(String, ThreadGroup) ----

    @Test
    void testFindThreadsByNameAndThreadGroupNullChecks() {
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName(null, group);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName("whatever", (ThreadGroup) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameAndThreadGroupFindsThread() throws InterruptedException {
        final String threadName = uniqueName("thread");
        final ThreadGroup group = Thread.currentThread().getThreadGroup();
        final SpinningThread worker = new SpinningThread(group, threadName);
        worker.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreadsByName(threadName, group);
            assertTrue(found.contains(worker));
        } finally {
            worker.stopRunning();
            worker.join(2000);
        }
    }

    // ---- getAllThreadGroups() / getAllThreads() / getSystemThreadGroup() ----

    @Test
    void testGetAllThreadGroupsExcludesSystemGroup() {
        final Collection<ThreadGroup> all = ThreadUtils.getAllThreadGroups();
        assertNotNull(all);
        assertFalse(all.contains(ThreadUtils.getSystemThreadGroup()));
    }

    @Test
    void testGetAllThreadsContainsCurrentThread() {
        final Collection<Thread> all = ThreadUtils.getAllThreads();
        assertTrue(all.contains(Thread.currentThread()));
    }

    @Test
    void testGetSystemThreadGroupHasNoParentAndIsAncestor() {
        final ThreadGroup system = ThreadUtils.getSystemThreadGroup();
        assertNotNull(system);
        assertNull(system.getParent());
        ThreadGroup walked = Thread.currentThread().getThreadGroup();
        while (walked.getParent() != null) {
            walked = walked.getParent();
        }
        assertSame(system, walked);
    }

    // ---- join(Thread, Duration) ----

    @Test
    void testJoinWaitsUntilThreadFinishes() throws InterruptedException {
        final Thread quick = new Thread(new Runnable() {
            @Override
            public void run() {
                // completes immediately
            }
        }, uniqueName("quick"));
        quick.start();
        ThreadUtils.join(quick, Duration.ofSeconds(5));
        assertFalse(quick.isAlive());
    }

    @Test
    void testJoinReturnsAfterTimeoutWhileThreadStillAlive() throws InterruptedException {
        final SpinningThread worker = new SpinningThread(uniqueName("slow"));
        worker.start();
        try {
            ThreadUtils.join(worker, Duration.ofMillis(50));
            assertTrue(worker.isAlive());
        } finally {
            worker.stopRunning();
            worker.join(2000);
        }
    }

    @Test
    void testJoinWithNullDurationIsNoop() throws InterruptedException {
        final SpinningThread worker = new SpinningThread(uniqueName("noop-join"));
        worker.start();
        try {
            ThreadUtils.join(worker, null);
            assertTrue(worker.isAlive());
        } finally {
            worker.stopRunning();
            worker.join(2000);
        }
    }

    @Test
    void testJoinRejectsNegativeDuration() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws InterruptedException {
                ThreadUtils.join(Thread.currentThread(), Duration.ofMillis(-5));
            }
        });
    }

    // ---- sleep(Duration) ----

    @Test
    void testSleepSleepsAtLeastRequestedDuration() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ofMillis(100));
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 90, "expected at least ~100ms, got " + elapsedMillis);
    }

    @Test
    void testSleepWithZeroDurationReturnsImmediately() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ZERO);
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis < 1000, "expected a near-instant return, got " + elapsedMillis);
    }

    @Test
    void testSleepWithNullDurationIsNoop() throws InterruptedException {
        ThreadUtils.sleep(null);
    }

    @Test
    void testSleepRejectsNegativeDuration() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws InterruptedException {
                ThreadUtils.sleep(Duration.ofMillis(-5));
            }
        });
    }

    // ---- sleepQuietly(Duration) ----

    @Test
    void testSleepQuietlyRestoresInterruptFlagOnInterruptedException() throws InterruptedException {
        final AtomicBoolean interruptedAfterSleep = new AtomicBoolean(false);
        final Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                ThreadUtils.sleepQuietly(Duration.ofSeconds(5));
                interruptedAfterSleep.set(Thread.currentThread().isInterrupted());
            }
        }, uniqueName("sleepy"));
        worker.start();
        Thread.sleep(100);
        worker.interrupt();
        worker.join(2000);
        assertFalse(worker.isAlive());
        assertTrue(interruptedAfterSleep.get());
    }

    @Test
    void testSleepQuietlyPropagatesNonInterruptedException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ThreadUtils.sleepQuietly(Duration.ofMillis(-5));
            }
        });
    }

    @Test
    void testSleepQuietlySleepsRequestedDuration() {
        final long start = System.nanoTime();
        ThreadUtils.sleepQuietly(Duration.ofMillis(100));
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 90, "expected at least ~100ms, got " + elapsedMillis);
    }

    // ---- NamePredicate ----

    @Test
    void testNamePredicateConstructorRequiresNonNullName() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new ThreadUtils.NamePredicate(null);
            }
        });
    }

    @Test
    void testNamePredicateMatchesThreadAndThreadGroup() {
        final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(Thread.currentThread().getName());
        assertTrue(predicate.test(Thread.currentThread()));
        assertFalse(predicate.test((Thread) null));
        assertFalse(predicate.test(new Thread("totally-different-name")));

        final ThreadUtils.NamePredicate groupPredicate = new ThreadUtils.NamePredicate(Thread.currentThread().getThreadGroup().getName());
        assertTrue(groupPredicate.test(Thread.currentThread().getThreadGroup()));
        assertFalse(groupPredicate.test((ThreadGroup) null));
    }

    // ---- ThreadIdPredicate ----

    @Test
    void testThreadIdPredicateConstructorRejectsNonPositiveIds() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ThreadUtils.ThreadIdPredicate(0L);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ThreadUtils.ThreadIdPredicate(-1L);
            }
        });
    }

    @Test
    void testThreadIdPredicateMatchesThreadId() {
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(Thread.currentThread().getId());
        assertTrue(predicate.test(Thread.currentThread()));
        assertFalse(predicate.test(null));
        final ThreadUtils.ThreadIdPredicate otherPredicate = new ThreadUtils.ThreadIdPredicate(Thread.currentThread().getId() + 1000000L);
        assertFalse(otherPredicate.test(Thread.currentThread()));
    }

    // ---- ALWAYS_TRUE_PREDICATE ----

    @Test
    @SuppressWarnings("deprecation")
    void testAlwaysTruePredicateMatchesEverythingIncludingNull() {
        final ThreadUtils.ThreadPredicate threadPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(threadPredicate.test(Thread.currentThread()));
        assertTrue(threadPredicate.test(null));

        final ThreadUtils.ThreadGroupPredicate groupPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(groupPredicate.test(Thread.currentThread().getThreadGroup()));
        assertTrue(groupPredicate.test(null));
    }

    // ---- deprecated overloads taking ThreadPredicate / ThreadGroupPredicate ----

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFindThreadGroupsWithThreadGroupPredicateOverloads() {
        final String name = uniqueName("deprecated-group");
        final ThreadGroup group = new ThreadGroup(name);
        final ThreadUtils.ThreadGroupPredicate predicate = new ThreadUtils.NamePredicate(name);

        final Collection<ThreadGroup> foundGlobal = ThreadUtils.findThreadGroups(predicate);
        assertTrue(foundGlobal.contains(group));

        final Collection<ThreadGroup> foundScoped = ThreadUtils.findThreadGroups(ThreadUtils.getSystemThreadGroup(), true, predicate);
        assertTrue(foundScoped.contains(group));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFindThreadsWithThreadPredicateOverloads() throws InterruptedException {
        final String name = uniqueName("deprecated-thread");
        final SpinningThread worker = new SpinningThread(name);
        worker.start();
        try {
            final ThreadUtils.ThreadPredicate predicate = new ThreadUtils.NamePredicate(name);

            final Collection<Thread> foundGlobal = ThreadUtils.findThreads(predicate);
            assertTrue(foundGlobal.contains(worker));

            final Collection<Thread> foundScoped = ThreadUtils.findThreads(ThreadUtils.getSystemThreadGroup(), true, predicate);
            assertTrue(foundScoped.contains(worker));
        } finally {
            worker.stopRunning();
            worker.join(2000);
        }
    }

    // ---- constructor ----

    @Test
    @SuppressWarnings("deprecation")
    void testConstructorIsPublicAndInstantiable() {
        assertNotNull(new ThreadUtils());
    }
}
