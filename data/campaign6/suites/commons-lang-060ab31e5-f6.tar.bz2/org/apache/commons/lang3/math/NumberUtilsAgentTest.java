/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // constants
    // ---------------------------------------------------------------

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue());
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue());
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue());
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue());
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue());
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testConstructor() {
        // public constructor exists and does not throw, for bean tools
        assertTrue(new NumberUtils() != null);
    }

    // ---------------------------------------------------------------
    // compare
    // ---------------------------------------------------------------

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
        assertTrue(NumberUtils.compare(Integer.MIN_VALUE, Integer.MAX_VALUE) < 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
        assertTrue(NumberUtils.compare(Long.MIN_VALUE, Long.MAX_VALUE) < 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("   ");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    void testCreateBigIntegerDecimal() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(12345), NumberUtils.createBigInteger("12345"));
        assertEquals(BigInteger.valueOf(-12345), NumberUtils.createBigInteger("-12345"));
        assertEquals(BigInteger.valueOf(12345), NumberUtils.createBigInteger("+12345"));
    }

    @Test
    void testCreateBigIntegerHexAndOctal() {
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0X1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(-26), NumberUtils.createBigInteger("-0x1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.ZERO, NumberUtils.createBigInteger("00"));
    }

    @Test
    void testCreateBigIntegerEmpty() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createBigInteger("");
            }
        });
    }

    // ---------------------------------------------------------------
    // createDouble / createFloat
    // ---------------------------------------------------------------

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createInteger / createLong
    // ---------------------------------------------------------------

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12345), NumberUtils.createInteger("12345"));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12345L), NumberUtils.createLong("12345"));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlank() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("12345");
        assertTrue(n instanceof Integer, "expected Integer, got " + n.getClass());
        assertEquals(12345, n.intValue());
    }

    @Test
    void testCreateNumberNegativeInteger() {
        final Number n = NumberUtils.createNumber("-12345");
        assertTrue(n instanceof Integer, "expected Integer, got " + n.getClass());
        assertEquals(-12345, n.intValue());
    }

    @Test
    void testCreateNumberOverflowsToLong() {
        final Number n = NumberUtils.createNumber("123456789012345");
        assertTrue(n instanceof Long, "expected Long, got " + n.getClass());
        assertEquals(123456789012345L, n.longValue());
    }

    @Test
    void testCreateNumberOverflowsToBigInteger() {
        final Number n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n instanceof BigInteger, "expected BigInteger, got " + n.getClass());
        assertEquals(new BigInteger("123456789012345678901234567890"), n);
    }

    @Test
    void testCreateNumberHex() {
        final Number lower = NumberUtils.createNumber("0x1A");
        assertTrue(lower instanceof Integer);
        assertEquals(26, lower.intValue());
        final Number upperPrefix = NumberUtils.createNumber("0X1a");
        assertEquals(26, upperPrefix.intValue());
        final Number altPrefix = NumberUtils.createNumber("#1A");
        assertEquals(26, altPrefix.intValue());
        final Number negative = NumberUtils.createNumber("-0x1A");
        assertEquals(-26, negative.intValue());
    }

    @Test
    void testCreateNumberHexOverflowToLong() {
        // 8 hex digits with first digit > '7' overflows int range
        final Number n = NumberUtils.createNumber("0x80000000");
        assertTrue(n instanceof Long, "expected Long, got " + n.getClass());
        assertEquals(0x80000000L, n.longValue());
    }

    @Test
    void testCreateNumberHexOverflowToBigInteger() {
        // 16 hex digits with first digit > '7' overflows long range
        final Number n = NumberUtils.createNumber("0xFFFFFFFFFFFFFFFF");
        assertTrue(n instanceof BigInteger, "expected BigInteger, got " + n.getClass());
        assertEquals(new BigInteger("FFFFFFFFFFFFFFFF", 16), n);
    }

    @Test
    void testCreateNumberHexWithLSuffix() {
        final Number n = NumberUtils.createNumber("0x1AL");
        assertTrue(n instanceof Long, "expected Long, got " + n.getClass());
        assertEquals(26L, n.longValue());
    }

    @Test
    void testCreateNumberOctal() {
        final Number n = NumberUtils.createNumber("010");
        assertTrue(n instanceof Integer, "expected Integer, got " + n.getClass());
        assertEquals(8, n.intValue());
    }

    @Test
    void testCreateNumberInvalidOctalThrows() {
        // leading zero makes "09" octal, but 9 is not a valid octal digit
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("09");
            }
        });
    }

    @Test
    void testCreateNumberLeadingZeroDecimalPoint() {
        // numbers starting with "0." are treated as decimal, not octal
        final Number n = NumberUtils.createNumber("0.9");
        assertEquals(0.9d, n.doubleValue(), 0.0000001d);
    }

    @Test
    void testCreateNumberFloatTypeQualifier() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float, "expected Float, got " + n.getClass());
        assertEquals(1.5f, n.floatValue());
    }

    @Test
    void testCreateNumberDoubleTypeQualifier() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double, "expected Double, got " + n.getClass());
        assertEquals(1.5d, n.doubleValue());
    }

    @Test
    void testCreateNumberLongTypeQualifier() {
        final Number n = NumberUtils.createNumber("100L");
        assertTrue(n instanceof Long, "expected Long, got " + n.getClass());
        assertEquals(100L, n.longValue());
    }

    @Test
    void testCreateNumberLongTypeQualifierOverflowsToBigInteger() {
        final Number n = NumberUtils.createNumber("123456789012345678901L");
        assertTrue(n instanceof BigInteger, "expected BigInteger, got " + n.getClass());
        assertEquals(new BigInteger("123456789012345678901"), n);
    }

    @Test
    void testCreateNumberLongTypeQualifierWithDecimalThrows() {
        // an 'L' suffix is invalid on a value that has a decimal point
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    @Test
    void testCreateNumberFloatOverflowFallsBackToDouble() {
        // too large to be represented precisely as a Float
        final Number n = NumberUtils.createNumber("1.4E40F");
        assertTrue(n instanceof Double, "expected Double, got " + n.getClass());
    }

    @Test
    void testCreateNumberDoubleOverflowFallsBackToBigDecimal() {
        // too large to be represented as a Double
        final Number n = NumberUtils.createNumber("1E400D");
        assertTrue(n instanceof BigDecimal, "expected BigDecimal, got " + n.getClass());
    }

    @Test
    void testCreateNumberInvalidTypeQualifierThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("xF");
            }
        });
    }

    @Test
    void testCreateNumberMalformedExponentThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("1e");
            }
        });
    }

    @Test
    void testCreateNumberDecimalBiggerThanLongIsBigDecimal() {
        final Number n = NumberUtils.createNumber("1.23456789012345678901234567890123");
        assertTrue(n instanceof BigDecimal || n instanceof Double, "expected BigDecimal or Double, got " + n.getClass());
    }

    // ---------------------------------------------------------------
    // isCreatable / isNumber (deprecated alias)
    // ---------------------------------------------------------------

    @Test
    void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
    }

    @Test
    void testIsCreatableValidNumbers() {
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12345"));
        assertTrue(NumberUtils.isCreatable("1.5"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("010"));
        assertTrue(NumberUtils.isCreatable("0.09"));
    }

    @Test
    void testIsCreatableInvalidNumbers() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("1.5L"));
        // "--1" is not valid Java number syntax and must not be creatable
        assertFalse(NumberUtils.isCreatable("--1"));
        assertFalse(NumberUtils.isCreatable("1,2"));
    }

    @Test
    void testCreateNumberDoubleSignThrows() {
        // "--1" is not valid Java number syntax (unlike "-1"); a double sign
        // must be rejected rather than silently parsed as a positive number
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.createNumber("--1");
            }
        });
    }

    @Test
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("12345"), NumberUtils.isNumber("12345"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertEquals(NumberUtils.isCreatable("09"), NumberUtils.isNumber("09"));
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("12 45"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // ---------------------------------------------------------------
    // isParsable
    // ---------------------------------------------------------------

    @Test
    void testIsParsableNullAndEmpty() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    void testIsParsableValid() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("1.5e10"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
    }

    @Test
    void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("1.5L"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        // Double.parseDouble() trims surrounding whitespace, so these are parsable
        assertTrue(NumberUtils.isParsable(" 123"));
        assertTrue(NumberUtils.isParsable("123 "));
    }

    // ---------------------------------------------------------------
    // max / min - arrays
    // ---------------------------------------------------------------

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.max(new byte[] { (byte) 1 }));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMaxDoubleArrayAndNaN() {
        assertEquals(5.5d, NumberUtils.max(1.5d, 5.5d, 3.5d));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    void testMinDoubleArrayAndNaN() {
        assertEquals(1.5d, NumberUtils.min(1.5d, 5.5d, 3.5d));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMaxFloatArrayAndNaN() {
        assertEquals(5.5f, NumberUtils.max(1.5f, 5.5f, 3.5f));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    void testMinFloatArrayAndNaN() {
        assertEquals(1.5f, NumberUtils.min(1.5f, 5.5f, 3.5f));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(Integer.MAX_VALUE, NumberUtils.max(1, Integer.MAX_VALUE, 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(Integer.MIN_VALUE, NumberUtils.min(1, Integer.MIN_VALUE, 3));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(Long.MAX_VALUE, NumberUtils.max(1L, Long.MAX_VALUE, 3L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertEquals(Long.MIN_VALUE, NumberUtils.min(1L, Long.MIN_VALUE, 3L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                NumberUtils.min(new short[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // toByte / toShort / toInt / toLong / toFloat / toDouble
    // ---------------------------------------------------------------

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("abc", (byte) 9));
        // out of byte range should fall back to the default, not throw
        assertEquals((byte) 9, NumberUtils.toByte("1000", (byte) 9));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("abc", (short) 9));
        assertEquals((short) 9, NumberUtils.toShort("100000", (short) 9));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("abc", 9));
        assertEquals(9, NumberUtils.toInt("99999999999999", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("abc", 9L));
        assertEquals(9L, NumberUtils.toLong("999999999999999999999999999", 9L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f));
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f));
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f));
        assertEquals(9.0f, NumberUtils.toFloat("abc", 9.0f));
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d));
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d));
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d));
        assertEquals(9.0d, NumberUtils.toDouble("abc", 9.0d));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d));
    }

    // ---------------------------------------------------------------
    // toScaledBigDecimal
    // ---------------------------------------------------------------

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2356")));
        assertEquals(new BigDecimal("1.236"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2356"), 3, RoundingMode.HALF_UP));
        // null rounding mode defaults to HALF_EVEN
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2356"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.2356d)));
        assertEquals(new BigDecimal("1.236"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.2356d), 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.2356f)));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.2356"));
        assertEquals(new BigDecimal("1.236"), NumberUtils.toScaledBigDecimal("1.2356", 3, RoundingMode.HALF_UP));
    }
}
