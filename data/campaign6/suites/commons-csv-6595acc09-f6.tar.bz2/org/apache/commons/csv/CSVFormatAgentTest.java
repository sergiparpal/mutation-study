/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
public class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    // --- Predefined formats ---

    @Test
    public void testDefaultFormatSettings() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testRfc4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        final CSVFormat rebuilt = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        assertEquals(rebuilt, CSVFormat.RFC4180);
    }

    @Test
    public void testExcelFormatSettings() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    public void testMySqlFormatSettings() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    public void testTdfFormatSettings() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testValueOfLooksUpPredefinedFormat() {
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NoSuchFormat"));
    }

    @Test
    public void testPredefinedEnumGetFormat() {
        assertSame(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertSame(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
    }

    // --- newFormat / builder basics ---

    @Test
    public void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    public void testBuilderCreateCopiesFromExistingFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("NULL").get();
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    // --- Validation in builder / constructor ---

    @Test
    public void testSetDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter('\r'));
    }

    @Test
    public void testSetDelimiterRejectsEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(""));
    }

    @Test
    public void testSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setCommentMarker('\n'));
    }

    @Test
    public void testSetQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setQuote('\r'));
    }

    @Test
    public void testSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setEscape('\n'));
    }

    @Test
    public void testQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(',').setQuote(',').get());
    }

    @Test
    public void testEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(',').setEscape(',').get());
    }

    @Test
    public void testCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    public void testCommentMarkerSameAsQuoteThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    public void testCommentMarkerSameAsEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    public void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    public void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.Builder.create().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    public void testDuplicateHeadersDisallowedByDefaultModeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .setHeader("A", "B", "A").get());
    }

    @Test
    public void testDuplicateHeadersAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("A", "B", "A").get();
        assertArrayEquals(new String[] {"A", "B", "A"}, format.getHeader());
    }

    @Test
    public void testDuplicateHeadersAllowEmptyPermitsOnlyBlankDuplicates() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "", "").get();
        assertArrayEquals(new String[] {"A", "", ""}, format.getHeader());
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get());
    }

    // --- getHeader / getHeaderComments defensive copies ---

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    public void testSetHeaderKeepsCopyOfInputArray() {
        final String[] input = {"A", "B"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(input).get();
        input[0] = "MUTATED";
        assertEquals("A", format.getHeader()[0]);
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        assertEquals("c1", format.getHeaderComments()[0]);
    }

    @Test
    public void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    public void testSetHeaderNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    public void testSetHeaderEmptyMeansParseFromFile() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        final String[] header = format.getHeader();
        assertNotNull(header);
        assertEquals(0, header.length);
    }

    // --- getDelimiter deprecated, getDelimiterCharArray ---

    @Test
    public void testGetDelimiterReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
        assertEquals("::", format.getDelimiterString());
    }

    // --- isXxxSet methods ---

    @Test
    public void testIsSetMethods() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertTrue(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isNullStringSet());

        final CSVFormat other = format.builder().setEscape('\\').setCommentMarker('#').setNullString("NULL").setQuote(null).get();
        assertFalse(other.isQuoteCharacterSet());
        assertTrue(other.isEscapeCharacterSet());
        assertTrue(other.isCommentMarkerSet());
        assertTrue(other.isNullStringSet());
    }

    // --- equals / hashCode ---

    @Test
    public void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("X", "Y").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("X", "Y").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsIsFalseForDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT;
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotEquals(a, b);
    }

    @Test
    public void testEqualsHandlesNullAndOtherTypes() {
        final CSVFormat a = CSVFormat.DEFAULT;
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
        assertEquals(a, a);
    }

    // --- getMaxRows / useMaxRows / useRow ---

    @Test
    public void testMaxRowsDefaultIsZeroMeaningNoLimit() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    public void testMaxRowsPositiveIsRespected() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    // --- format(Object...) ---

    @Test
    public void testFormatProducesCsvLineWithoutRecordSeparator() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    public void testFormatHandlesNullValueWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final String result = format.format((Object) null, "x");
        assertEquals("NULL,x", result);
    }

    @Test
    public void testFormatHandlesNullValueWithoutNullStringAsEmpty() {
        final String result = CSVFormat.DEFAULT.format((Object) null, "x");
        assertEquals(",x", result);
    }

    // --- print(Object, Appendable, boolean) ---

    @Test
    public void testPrintSimpleValueNoQuotingNeeded() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    public void testPrintAddsDelimiterWhenNotNewRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, false);
        assertEquals(",hello", writer.toString());
    }

    @Test
    public void testPrintQuotesValueContainingQuoteCharacter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("a\"b", writer, true);
        assertEquals("\"a\"\"b\"", writer.toString());
    }

    @Test
    public void testPrintWithQuoteModeAllQuotesEverything() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print("simple", writer, true);
        assertEquals("\"simple\"", writer.toString());
    }

    @Test
    public void testPrintWithQuoteModeNonNumericQuotesStringsNotNumbers() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NON_NUMERIC).get();
        final StringWriter writer = new StringWriter();
        format.print(Integer.valueOf(42), writer, true);
        assertEquals("42", writer.toString());
        final StringWriter writer2 = new StringWriter();
        format.print("text", writer2, true);
        assertEquals("\"text\"", writer2.toString());
    }

    @Test
    public void testPrintWithEscapeCharacterEscapesDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setEscape('\\').get();
        final StringWriter writer = new StringWriter();
        format.print("a,b", writer, true);
        assertEquals("a\\,b", writer.toString());
    }

    @Test
    public void testPrintTrimsValueWhenTrimEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).setQuote(null).get();
        final StringWriter writer = new StringWriter();
        format.print("  hello  ", writer, true);
        assertEquals("hello", writer.toString());
    }

    // --- printRecord / println ---

    @Test
    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b");
        assertEquals("a,b\r\n", writer.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiterAndRecordSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    public void testPrintlnWithoutTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    // --- parse ---

    @Test
    public void testParseReturnsWorkingParser() throws IOException {
        try (CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n"))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
        }
    }

    // --- print(Appendable) factory ---

    @Test
    public void testPrintFactoryReturnsUsablePrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        try (CSVPrinter printer = CSVFormat.DEFAULT.print(writer)) {
            printer.printRecord("a", "b");
        }
        assertEquals("a,b\r\n", writer.toString());
    }

    // --- toString ---

    @Test
    public void testToStringContainsDelimiterAndSkipHeaderInfo() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("SkipHeaderRecord:false"));
    }

    @Test
    public void testToStringIncludesHeaderWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String s = format.toString();
        assertTrue(s.contains("Header:[A, B]"));
    }

    // --- deprecated with* methods delegate correctly ---

    @Test
    public void testWithDelimiterDeprecatedMethod() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    public void testWithQuoteDeprecatedMethod() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
    }

    @Test
    public void testWithHeaderDeprecatedMethod() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("X", "Y");
        assertArrayEquals(new String[] {"X", "Y"}, format.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeaderSetsSkipAndEmptyHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testWithAllowDuplicateHeaderNamesDeprecatedMethod() {
        final CSVFormat trueFormat = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true);
        assertTrue(trueFormat.getAllowDuplicateHeaderNames());
        final CSVFormat falseFormat = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(falseFormat.getAllowDuplicateHeaderNames());
    }

    @Test
    public void testWithNullStringDeprecatedMethod() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @Test
    public void testWithTrimDeprecatedMethods() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    // --- immutability: builder mutation does not affect already-built format ---

    @Test
    public void testFormatIsImmutableAfterBuilderReuse() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat first = builder.setDelimiter(';').get();
        builder.setDelimiter(':');
        final CSVFormat second = builder.get();
        assertEquals(";", first.getDelimiterString());
        assertEquals(":", second.getDelimiterString());
    }

    // --- multi-character delimiter edge cases ---

    @Test
    public void testMultiCharSelfOverlappingDelimiterTriggersQuoting() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        final StringWriter writer = new StringWriter();
        format.print("ab|", writer, true);
        assertEquals("\"ab|\"", writer.toString());
    }

    @Test
    public void testMultiCharNonOverlappingDelimiterNoSpuriousQuoting() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("|~").get();
        final StringWriter writer = new StringWriter();
        format.print("end|", writer, true);
        assertEquals("end|", writer.toString());
    }

    @Test
    public void testMultiCharDelimiterRoundTripsOnParse() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final String formatted = format.format("a", "b", "c");
        assertEquals("a::b::c", formatted);
        try (CSVParser parser = format.parse(new StringReader(formatted))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
        }
    }

    // --- quoted null string interactions ---

    @Test
    public void testQuoteModeAllPrintsQuotedNullStringForNull() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("\"NULL\"", writer.toString());
    }

    @Test
    public void testQuoteModeAllUsesCustomQuoteCharacterForNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuote('\'').setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("'NULL'", writer.toString());
    }

    @Test
    public void testQuoteModeAllRespectsQuoteSetAfterNullString() throws IOException {
        // Setting the quote AFTER the null string must still recompute the quoted null string.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuote('\'').get()
                .builder().setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("'NULL'", writer.toString());
    }

    // --- duplicate header with blank/null entries ---

    @Test
    public void testDuplicateHeadersAllowEmptyPermitsMultipleNullHeaders() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY)
                .setHeader("A", null, null).get();
        assertArrayEquals(new String[] {"A", null, null}, format.getHeader());
    }

    @Test
    public void testDuplicateHeadersDisallowRejectsBlankDuplicates() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "", "").get());
    }

    // --- leading low-ASCII char (<= '#') forces quoting even without a comment marker ---

    @Test
    public void testLeadingCharBelowCommentThresholdIsQuoted() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("!text", writer, true);
        assertEquals("\"!text\"", writer.toString());
    }

    @Test
    public void testLeadingCharAboveCommentThresholdIsNotQuoted() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("$text", writer, true);
        assertEquals("$text", writer.toString());
    }

    // --- trailing delimiter round trip with parser ---

    @Test
    public void testTrailingDelimiterRoundTripsOnParse() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        try (CSVParser parser = format.parse(new StringReader("a,b,\r\n"))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        }
    }
}
