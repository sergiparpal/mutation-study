/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructorExists() {
        assertNotNull(new NumberUtils());
    }

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    // ---- compare (deprecated) ----

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(5, 6) < 0);
        assertTrue(NumberUtils.compare(6, 5) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(5L, 6L) < 0);
        assertTrue(NumberUtils.compare(6L, 5L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 5, (short) 6) < 0);
        assertTrue(NumberUtils.compare((short) 6, (short) 5) > 0);
    }

    // ---- createBigDecimal ----

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("3.14"), NumberUtils.createBigDecimal("3.14"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("   ");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---- createBigInteger ----

    @Test
    void testCreateBigIntegerNullAndEmpty() {
        assertNull(NumberUtils.createBigInteger(null));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(12345L), NumberUtils.createBigInteger("12345"));
        assertEquals(BigInteger.valueOf(-12345L), NumberUtils.createBigInteger("-12345"));
        assertEquals(BigInteger.ZERO, NumberUtils.createBigInteger("0"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(26L), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26L), NumberUtils.createBigInteger("0X1A"));
        assertEquals(BigInteger.valueOf(26L), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(-26L), NumberUtils.createBigInteger("-0x1A"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8L), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(-8L), NumberUtils.createBigInteger("-010"));
    }

    @Test
    void testCreateBigIntegerExplicitPlusSign() {
        assertEquals(BigInteger.valueOf(123L), NumberUtils.createBigInteger("+123"));
    }

    @Test
    void testCreateBigIntegerInvalidOctalDigit() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("08");
            }
        });
    }

    @Test
    void testCreateBigIntegerBadSignPosition() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("--1");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("+-1");
            }
        });
    }

    // ---- createDouble / createFloat ----

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    // ---- createInteger / createLong ----

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(-5), NumberUtils.createInteger("-5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
        assertEquals(Long.valueOf(-5L), NumberUtils.createLong("-5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ---- createNumber ----

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    void testCreateNumberPlainIntegerAndLong() {
        final Number small = NumberUtils.createNumber("123");
        assertTrue(small instanceof Integer, "expected Integer for '123' but got " + small.getClass());
        assertEquals(123, small.intValue());

        final Number big = NumberUtils.createNumber(String.valueOf(Long.MAX_VALUE));
        assertTrue(big instanceof Long, "expected Long for Long.MAX_VALUE but got " + big.getClass());
        assertEquals(Long.MAX_VALUE, big.longValue());

        final Number huge = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(huge instanceof BigInteger, "expected BigInteger for huge integral literal but got " + huge.getClass());
        assertEquals(new BigInteger("123456789012345678901234567890"), huge);
    }

    @Test
    void testCreateNumberOctal() {
        final Number n = NumberUtils.createNumber("045");
        assertEquals(37, n.intValue());
    }

    @Test
    void testCreateNumberHexBoundaries() {
        final Number maxIntHex = NumberUtils.createNumber("0x7FFFFFFF");
        assertTrue(maxIntHex instanceof Integer, "expected Integer but got " + maxIntHex.getClass());
        assertEquals(Integer.MAX_VALUE, maxIntHex.intValue());

        final Number overflowsIntHex = NumberUtils.createNumber("0x80000000");
        assertTrue(overflowsIntHex instanceof Long, "expected Long but got " + overflowsIntHex.getClass());
        assertEquals(2147483648L, overflowsIntHex.longValue());

        final Number maxLongHex = NumberUtils.createNumber("0x7FFFFFFFFFFFFFFF");
        assertTrue(maxLongHex instanceof Long, "expected Long but got " + maxLongHex.getClass());
        assertEquals(Long.MAX_VALUE, maxLongHex.longValue());

        final Number overflowsLongHex = NumberUtils.createNumber("0xFFFFFFFFFFFFFFFF");
        assertTrue(overflowsLongHex instanceof BigInteger, "expected BigInteger but got " + overflowsLongHex.getClass());
        assertEquals(new BigInteger("FFFFFFFFFFFFFFFF", 16), overflowsLongHex);
    }

    @Test
    void testCreateNumberTypeQualifiers() {
        assertEquals(Long.valueOf(10L), NumberUtils.createNumber("10L"));
        assertEquals(Long.valueOf(10L), NumberUtils.createNumber("10l"));
        assertEquals(Float.valueOf(10.0f), NumberUtils.createNumber("10f"));
        assertEquals(Double.valueOf(10.0d), NumberUtils.createNumber("10d"));
        assertTrue(NumberUtils.createNumber("10L") instanceof Long);
        assertTrue(NumberUtils.createNumber("10f") instanceof Float);
        assertTrue(NumberUtils.createNumber("10d") instanceof Double);
    }

    @Test
    void testCreateNumberInvalidTypeQualifier() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1e");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.2.3");
            }
        });
    }

    @Test
    void testCreateNumberDoubleExponent() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1e1e1");
            }
        });
    }

    @Test
    void testCreateNumberScientificNotation() {
        final Number n = NumberUtils.createNumber("1.5e10");
        assertEquals(1.5e10, n.doubleValue(), 0.0001);
    }

    // ---- isCreatable / isNumber (deprecated) ----

    @Test
    void testCreateNumberInvalidOctal() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("09");
            }
        });
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("-123"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("3.14"));
        assertTrue(NumberUtils.isCreatable("3.14e10"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("1.2.3"));
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertEquals(NumberUtils.isCreatable(null), NumberUtils.isNumber(null));
    }

    // ---- isDigits ----

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits("-1234"));
        assertFalse(NumberUtils.isDigits("12 45"));
        assertFalse(NumberUtils.isDigits("1a"));
    }

    // ---- isParsable ----

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("1.5e10"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertFalse(NumberUtils.isParsable("1.5L"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ---- max/min: byte ----

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMaxMinByteThreeArg() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 2, (byte) 1));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 2, (byte) 1));
    }

    // ---- max/min: short ----

    @Test
    void testMaxMinShortArray() {
        assertEquals((short) 9, NumberUtils.max((short) 9, (short) 2, (short) 7));
        assertEquals((short) 2, NumberUtils.min((short) 9, (short) 2, (short) 7));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    void testMaxMinShortThreeArg() {
        assertEquals((short) 7, NumberUtils.max((short) 7, (short) 5, (short) 1));
        assertEquals((short) 1, NumberUtils.min((short) 7, (short) 5, (short) 1));
    }

    // ---- max/min: int ----

    @Test
    void testMaxMinIntArray() {
        assertEquals(9, NumberUtils.max(9, 2, 7));
        assertEquals(2, NumberUtils.min(9, 2, 7));
        assertEquals(Integer.MAX_VALUE, NumberUtils.max(Integer.MIN_VALUE, Integer.MAX_VALUE, 0));
        assertEquals(Integer.MIN_VALUE, NumberUtils.min(Integer.MIN_VALUE, Integer.MAX_VALUE, 0));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMaxMinIntThreeArg() {
        assertEquals(7, NumberUtils.max(7, 5, 1));
        assertEquals(1, NumberUtils.min(7, 5, 1));
        assertEquals(7, NumberUtils.max(1, 5, 7));
        assertEquals(1, NumberUtils.min(1, 5, 7));
    }

    // ---- max/min: long ----

    @Test
    void testMaxMinLongArray() {
        assertEquals(9L, NumberUtils.max(9L, 2L, 7L));
        assertEquals(2L, NumberUtils.min(9L, 2L, 7L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    void testMaxMinLongThreeArg() {
        assertEquals(7L, NumberUtils.max(7L, 5L, 1L));
        assertEquals(1L, NumberUtils.min(7L, 5L, 1L));
    }

    // ---- max/min: float ----

    @Test
    void testMaxMinFloatArray() {
        assertEquals(9.5f, NumberUtils.max(9.5f, 2.5f, 7.5f));
        assertEquals(2.5f, NumberUtils.min(9.5f, 2.5f, 7.5f));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    void testMaxMinFloatArrayNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    void testMaxMinFloatThreeArg() {
        assertEquals(7.5f, NumberUtils.max(7.5f, 5.5f, 1.5f));
        assertEquals(1.5f, NumberUtils.min(7.5f, 5.5f, 1.5f));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    // ---- max/min: double ----

    @Test
    void testMaxMinDoubleArray() {
        assertEquals(9.5d, NumberUtils.max(9.5d, 2.5d, 7.5d));
        assertEquals(2.5d, NumberUtils.min(9.5d, 2.5d, 7.5d));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    void testMaxMinDoubleArrayNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMaxMinDoubleThreeArg() {
        assertEquals(7.5d, NumberUtils.max(7.5d, 5.5d, 1.5d));
        assertEquals(1.5d, NumberUtils.min(7.5d, 5.5d, 1.5d));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    // ---- toByte / toShort / toInt / toLong / toFloat / toDouble (String) ----

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f));
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f));
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f));
        assertEquals(9.0f, NumberUtils.toFloat("not a number", 9.0f));
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d));
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d));
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d));
        assertEquals(9.0d, NumberUtils.toDouble("not a number", 9.0d));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d));
    }

    // ---- toScaledBigDecimal ----

    @Test
    void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    void testToScaledBigDecimalBigDecimalDefaultScale() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(BigDecimal.valueOf(5.25d));
        assertEquals(new BigDecimal("5.25"), result);
        assertEquals(2, result.scale());
    }

    @Test
    void testToScaledBigDecimalHalfEvenRounding() {
        final BigDecimal roundDown = NumberUtils.toScaledBigDecimal(new BigDecimal("5.125"), 2, RoundingMode.HALF_EVEN);
        assertEquals(new BigDecimal("5.12"), roundDown);

        final BigDecimal roundUp = NumberUtils.toScaledBigDecimal(new BigDecimal("5.135"), 2, RoundingMode.HALF_EVEN);
        assertEquals(new BigDecimal("5.14"), roundUp);
    }

    @Test
    void testToScaledBigDecimalNullRoundingModeDefaultsToHalfEven() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("5.125"), 2, null);
        assertEquals(new BigDecimal("5.12"), result);
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(5.25d));
        assertEquals(new BigDecimal("5.25"), result);
        final BigDecimal scaled = NumberUtils.toScaledBigDecimal(Double.valueOf(5.125d), 2, RoundingMode.HALF_EVEN);
        assertEquals(new BigDecimal("5.12"), scaled);
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(5.25f));
        assertEquals(new BigDecimal("5.25"), result);
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        final BigDecimal result = NumberUtils.toScaledBigDecimal("5.25");
        assertEquals(new BigDecimal("5.25"), result);
        final BigDecimal scaled = NumberUtils.toScaledBigDecimal("5.125", 2, RoundingMode.HALF_EVEN);
        assertEquals(new BigDecimal("5.12"), scaled);
    }
}
