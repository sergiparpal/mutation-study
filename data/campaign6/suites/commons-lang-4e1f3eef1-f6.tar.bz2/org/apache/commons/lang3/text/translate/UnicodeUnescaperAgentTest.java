/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link UnicodeUnescaper}.
 */
@Deprecated
class UnicodeUnescaperAgentTest {

    @Test
    void testBasicUnicodeEscape() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0041");
        assertEquals("A", result);
    }

    @Test
    void testUnicodeEscapeWithLeadingAndTrailingText() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("foo \\u0041 bar");
        assertEquals("foo A bar", result);
    }

    @Test
    void testMultipleUChars() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uuuu0041");
        assertEquals("A", result);
    }

    @Test
    void testPlusForm() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u+0041");
        assertEquals("A", result);
    }

    @Test
    void testMultipleUCharsWithPlus() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uu+0041");
        assertEquals("A", result);
    }

    @Test
    void testNonUnicodeBackslashPassesThrough() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\n");
        assertEquals("\\n", result);
    }

    @Test
    void testLonelyBackslashAtEnd() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("abc\\");
        assertEquals("abc\\", result);
    }

    @Test
    void testNoBackslashUnchanged() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("hello world");
        assertEquals("hello world", result);
    }

    @Test
    void testEmptyString() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("");
        assertEquals("", result);
    }

    @Test
    void testNullInput() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate((CharSequence) null);
        assertEquals(null, result);
    }

    @Test
    void testTooFewHexDigitsThrows() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                uu.translate("\\u004");
            }
        });
    }

    @Test
    void testInvalidHexDigitsThrows() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                uu.translate("\\uZZZZ");
            }
        });
    }

    @Test
    void testExactlyFourHexDigitsAtEndOfString() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0061");
        assertEquals("a", result);
    }

    @Test
    void testDirectTranslateReturnsConsumedLengthForBasicCase() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("\\u0041rest", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testDirectTranslateReturnsZeroForNonMatch() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("abc", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testDirectTranslateReturnsZeroWhenBackslashIsLastChar() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("\\", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testDirectTranslateConsumedLengthWithExtraUChars() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        // "\uuu0041" -> backslash + u + u + u + 0041, consumed should be 4 (u's) + 4 (hex) = 8
        final int consumed = uu.translate("\\uuu0041", 0, writer);
        assertEquals(8, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testHighValueUnicodeCodeUnit() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uFFFF");
        assertEquals("￿", result);
    }

    @Test
    void testLowerCaseHexDigits() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\uabcd");
        assertEquals("ꯍ", result);
    }

    @Test
    void testConsecutiveEscapes() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("\\u0041\\u0042");
        assertEquals("AB", result);
    }
}
