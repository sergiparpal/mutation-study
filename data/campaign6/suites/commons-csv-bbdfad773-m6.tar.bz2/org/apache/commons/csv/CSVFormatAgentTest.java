/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Iterator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class CSVFormatAgentTest {

    private enum FixtureHeader {
        NAME, EMAIL, PHONE
    }

    @Test
    void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
        assertTrue(format.isQuoteCharacterSet());
        assertNull(format.getHeader());
    }

    @Test
    void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testTdfFormatProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
    }

    @Test
    void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("DoesNotExist");
            }
        });
    }

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    void testBuilderCreateDefaultsMatchRfc4180WithEmptyLines() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    void testBuilderCreateFromExistingFormatCopiesSettings() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setHeader("a", "b").setNullString("NULL").get();
        final CSVFormat copy = CSVFormat.Builder.create(source).get();
        assertEquals(source, copy);
        assertArrayEquals(source.getHeader(), copy.getHeader());
    }

    @Test
    void testBuilderMethod() {
        final CSVFormat base = CSVFormat.DEFAULT;
        final CSVFormat derived = base.builder().setDelimiter(';').get();
        assertEquals(";", derived.getDelimiterString());
        // Original is unaffected since CSVFormat is immutable.
        assertEquals(",", base.getDelimiterString());
    }

    @Test
    void testSetDelimiterCharAndString() {
        final CSVFormat byChar = CSVFormat.DEFAULT.builder().setDelimiter('|').get();
        assertEquals("|", byChar.getDelimiterString());
        final CSVFormat byString = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("||", byString.getDelimiterString());
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("a\rb");
            }
        });
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("");
            }
        });
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\r');
            }
        });
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('\n');
            }
        });
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('\r');
            }
        });
    }

    @Test
    void testValidateQuoteCharEqualsDelimiterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
        assertTrue(ex.getMessage().contains("quoteChar"));
    }

    @Test
    void testValidateEscapeCharEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentMarkerEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteCharEqualsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeCharEqualsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
        // Should succeed once an escape character is present.
        final CSVFormat ok = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, ok.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderDisallowedByDefaultThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testDuplicateHeaderAllowEmptyAllowsBlanksButNotNonBlankDuplicates() {
        final CSVFormat ok = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "").get();
        assertArrayEquals(new String[] { "a", "", "" }, ok.getHeader());
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "a").get();
        assertArrayEquals(new String[] { "a", "a" }, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testSetHeaderFromEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(FixtureHeader.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumClassDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(FixtureHeader.class).setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderEmptyMeansParseFromFile() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("x", "y").setNullString("NULL").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("x", "y").setNullString("NULL").get();
        final CSVFormat c = CSVFormat.DEFAULT.builder().setHeader("x", "z").setNullString("NULL").get();

        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
    }

    @Test
    void testToStringContainsConfiguredAttributes() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").setHeader("a", "b").get();
        final String s = format.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("QuoteChar=<\">"));
        assertTrue(s.contains("CommentStart=<#>"));
        assertTrue(s.contains("NullString=<NULL>"));
        assertTrue(s.contains("Header:[a, b]"));
    }

    @Test
    void testFormatValues() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b,c", "d\"e");
        assertEquals("a,\"b,c\",\"d\"\"e\"", formatted);
    }

    @Test
    void testPrintAndPrintRecordWriteExpectedOutput() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        try {
            printer.printRecord("1", "2", "3");
        } finally {
            printer.close();
        }
        assertEquals("1,2,3\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\n", writer.toString());
    }

    @Test
    void testPrintNullValueUsesNullStringAndQuotedWithQuoteModeAll() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("\"NULL\"", writer.toString());
    }

    @Test
    void testPrintNullValueWithoutQuoteModeAllUsesPlainNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testParseRoundTrip() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n1,2,3\r\n"));
        final Iterator<CSVRecord> it = parser.iterator();
        final CSVRecord first = it.next();
        assertEquals("a", first.get(0));
        assertEquals("b", first.get(1));
        assertEquals("c", first.get(2));
        final CSVRecord second = it.next();
        assertEquals("1", second.get(0));
        assertFalse(it.hasNext());
    }

    @Test
    void testGetMaxRowsAndUseMaxRowsDefaults() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(0, format.getMaxRows());
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(100));
    }

    @Test
    void testUseMaxRowsAndUseRowWithLimit() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertEquals(2, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    @Test
    void testCopyProducesEqualButIndependentInstance() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("a").get();
        final CSVFormat copy = CSVFormat.copy(original);
        assertEquals(original, copy);
        assertNull(CSVFormat.copy(null));
    }

    @Test
    void testIsSetFlags() {
        final CSVFormat plain = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(plain.isQuoteCharacterSet());
        assertFalse(plain.isEscapeCharacterSet());
        assertFalse(plain.isCommentMarkerSet());
        assertFalse(plain.isNullStringSet());

        final CSVFormat configured = plain.builder().setEscape('\\').setCommentMarker('#').setNullString("NULL").get();
        assertTrue(configured.isEscapeCharacterSet());
        assertTrue(configured.isCommentMarkerSet());
        assertTrue(configured.isNullStringSet());
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
    }

    @Test
    void testDeprecatedAllowDuplicateHeaderNamesAccessor() {
        final CSVFormat allowAll = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertTrue(allowAll.getAllowDuplicateHeaderNames());
        final CSVFormat disallow = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithDelimiterDeprecatedMethodReturnsNewFormat() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testGetTrailingDelimiterDefaultFalse() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get().getTrailingDelimiter());
    }
}
