/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultConstructorRequiresSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testSingleOptionConstructor() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testMultipleOptionConstructor() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonOptional, NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#65;"));
    }

    @Test
    void testHexWithSemiColonLowerX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#x41;"));
    }

    @Test
    void testHexWithSemiColonUpperX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#X41;"));
    }

    @Test
    void testEmbeddedInLargerString() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("fooAbar", neu.translate("foo&#65;bar"));
    }

    @Test
    void testNoEntityUnchanged() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("hello world", neu.translate("hello world"));
    }

    @Test
    void testNullInputReturnsNull() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertNull(neu.translate((String) null));
    }

    @Test
    void testMissingSemiColonDefaultIsUnchanged() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&#65", neu.translate("&#65"));
    }

    @Test
    void testMissingSemiColonOptionalTranslates() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A", neu.translate("&#65"));
    }

    @Test
    void testMissingSemiColonOptionalTranslatesFollowedByText() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("AXYZ", neu.translate("&#65XYZ"));
    }

    @Test
    void testMissingSemiColonErrorThrows() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                neu.translate("&#65");
            }
        });
    }

    @Test
    void testEmptyDigitsDecimalUnchanged() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&#;", neu.translate("&#;"));
    }

    @Test
    void testEmptyDigitsHexUnchanged() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&#x;", neu.translate("&#x;"));
    }

    @Test
    void testCodePointOutOfRangeUnchanged() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#x110000;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testMaxValidCodePointTranslates() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String result = neu.translate("&#x10FFFF;");
        assertEquals(Character.MAX_CODE_POINT, result.codePointAt(0));
    }

    @Test
    void testSupplementaryCodePointSurrogatePair() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final int codePoint = 0x1F600;
        final String result = neu.translate("&#x1F600;");
        assertEquals(2, result.length());
        assertEquals(codePoint, result.codePointAt(0));
        assertTrue(Character.isHighSurrogate(result.charAt(0)));
        assertTrue(Character.isLowSurrogate(result.charAt(1)));
    }

    @Test
    void testBoundaryJustAmpersandHash() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&#", neu.translate("&#"));
    }

    @Test
    void testBoundaryAmpersandHashXOnly() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&#x", neu.translate("&#x"));
    }

    @Test
    void testBoundaryAmpersandNearEndOfString() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("a&#", neu.translate("a&#"));
    }

    @Test
    void testDirectTranslateReturnsConsumedCountDecimal() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#65;", 0, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testDirectTranslateReturnsConsumedCountHex() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#x41;", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testDirectTranslateReturnsZeroWhenNoMatch() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("hello", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testIsSetWithoutOptionsArgumentIsFalseForUnrelated() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
    }
}
