/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private interface AgentInterface {
        // marker interface
    }

    private static class AgentBase {
        // base class
    }

    private static class AgentChild extends AgentBase implements AgentInterface {
        // child class
    }

    private static class AgentOuter {
        private static class AgentInner {
            // static nested class
        }
    }

    // ---- comparator ----

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        list.sort(ClassUtils.comparator());
        final List<String> names = new ArrayList<String>();
        for (final Class<?> c : list) {
            names.add(c.getName());
        }
        assertEquals(Arrays.asList("java.lang.Boolean", "java.lang.Integer", "java.lang.String"), names);
    }

    // ---- convertClassesToClassNames / convertClassNamesToClasses ----

    @Test
    public void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNamesWithNullElement() {
        final List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(input);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClassesUnknownAndNull() {
        final List<String> input = new ArrayList<String>();
        input.add("java.lang.String");
        input.add("this.is.not.a.real.Class");
        input.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(input);
        assertEquals(3, classes.size());
        assertSame(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    // ---- getAbbreviatedName ----

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameZeroLengthThrows() {
        try {
            ClassUtils.getAbbreviatedName("java.lang.String", 0);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testGetAbbreviatedNameNegativeLengthThrows() {
        try {
            ClassUtils.getAbbreviatedName("java.lang.String", -1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testGetAbbreviatedNameExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameShorterThanHint() {
        assertEquals("String", ClassUtils.getAbbreviatedName("String", 50));
    }

    @Test
    public void testGetAbbreviatedNameClassArg() {
        assertEquals(String.class.getName(), ClassUtils.getAbbreviatedName(String.class, 100));
    }

    // ---- getAllInterfaces / getAllSuperclasses ----

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfacesOfChild() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertTrue(interfaces.contains(AgentInterface.class));
        assertEquals(1, interfaces.size());
    }

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclassesOfChild() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentBase.class, Object.class), superclasses);
    }

    @Test
    public void testGetAllSuperclassesOfObject() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    // ---- getCanonicalName ----

    @Test
    public void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    public void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    // ---- getClass ----

    @Test
    public void testGetClassSimple() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    public void testGetClassPrimitive() throws ClassNotFoundException {
        assertSame(int.class, ClassUtils.getClass("int"));
    }

    @Test
    public void testGetClassArrayJvmSyntax() throws ClassNotFoundException {
        assertSame(int[].class, ClassUtils.getClass("[I"));
        assertSame(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassArrayCanonicalSyntax() throws ClassNotFoundException {
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
    }

    @Test
    public void testGetClassInnerClassDotSyntax() throws ClassNotFoundException {
        assertSame(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertSame(Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    public void testGetClassNotFoundThrows() {
        try {
            ClassUtils.getClass("this.does.not.Exist");
            fail("Expected ClassNotFoundException");
        } catch (final ClassNotFoundException expected) {
            // expected
        }
    }

    @Test
    public void testGetClassNullThrowsNpe() {
        try {
            ClassUtils.getClass((String) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final ClassNotFoundException e) {
            fail("Expected NullPointerException, got ClassNotFoundException");
        }
    }

    @Test
    public void testGetClassWhitespaceNormalized() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClass(" java.lang.String "));
    }

    @Test
    public void testGetClassStrictWhitespaceNotNormalized() {
        try {
            ClassUtils.getClassStrict(" java.lang.String");
            fail("Expected ClassNotFoundException");
        } catch (final ClassNotFoundException expected) {
            // expected
        }
    }

    @Test
    public void testGetClassStrictValid() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClassStrict("java.lang.String"));
    }

    // ---- getComponentType ----

    @Test
    public void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetComponentTypeArray() {
        assertSame(String.class, ClassUtils.getComponentType(String[].class));
    }

    // ---- getName ----

    @Test
    public void testGetNameClassNull() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetNameClass() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObjectNull() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    // ---- getPackageName / getPackageCanonicalName ----

    @Test
    public void testGetPackageNameClassNull() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
    }

    @Test
    public void testGetPackageNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameDefaultPackage() {
        assertEquals("", ClassUtils.getPackageName("NoPackageClass"));
    }

    @Test
    public void testGetPackageNameNullOrEmptyString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
    }

    @Test
    public void testGetPackageNameArrayEncoded() {
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPackageNameObjectNull() {
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
    }

    @Test
    public void testGetPackageCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetPackageCanonicalNameArray() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectNull() {
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
    }

    // ---- getPublicMethod ----

    @Test
    public void testGetPublicMethodFound() throws NoSuchMethodException {
        final java.lang.reflect.Method m = ClassUtils.getPublicMethod(String.class, "length");
        assertNotNull(m);
        assertEquals("length", m.getName());
    }

    @Test
    public void testGetPublicMethodNotFoundThrows() {
        try {
            ClassUtils.getPublicMethod(String.class, "noSuchMethod");
            fail("Expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        }
    }

    // ---- getShortCanonicalName ----

    @Test
    public void testGetShortCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetShortCanonicalNameArray() {
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    @Test
    public void testGetShortCanonicalNameObjectNull() {
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
    }

    @Test
    public void testGetShortCanonicalNameInnerClassDropsOuter() {
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getCanonicalName()));
    }

    // ---- getShortClassName ----

    @Test
    public void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    public void testGetShortClassNameSimple() {
        assertEquals("ClassUtils", ClassUtils.getShortClassName(ClassUtils.class));
    }

    @Test
    public void testGetShortClassNameArray() {
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("String[][]", ClassUtils.getShortClassName(String[][].class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
    }

    @Test
    public void testGetShortClassNameInnerKeepsOuter() {
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
    }

    @Test
    public void testGetShortClassNameStringNullOrEmpty() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    public void testGetShortClassNameStringJvmArray() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("String[][]", ClassUtils.getShortClassName("[[Ljava.lang.String;"));
    }

    @Test
    public void testGetShortClassNameObjectNull() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("String", ClassUtils.getShortClassName("hello", "NULL"));
    }

    // ---- getSimpleName ----

    @Test
    public void testGetSimpleNameClassNull() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObjectNull() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("String", ClassUtils.getSimpleName("hello"));
    }

    // ---- hierarchy ----

    @Test
    public void testHierarchyExcludeInterfaces() {
        final List<Class<?>> seen = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class)) {
            seen.add(c);
        }
        assertEquals(Arrays.asList(AgentChild.class, AgentBase.class, Object.class), seen);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> seen = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE)) {
            seen.add(c);
        }
        assertTrue(seen.contains(AgentChild.class));
        assertTrue(seen.contains(AgentInterface.class));
        assertTrue(seen.contains(Object.class));
    }

    @Test
    public void testHierarchyIteratorRemoveThrows() {
        final java.util.Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        try {
            it.remove();
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    // ---- isAssignable ----

    @Test
    public void testIsAssignableNullToClassFalse() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
    }

    @Test
    public void testIsAssignableNullClassToReferenceTrue() {
        assertTrue(ClassUtils.isAssignable(null, String.class));
    }

    @Test
    public void testIsAssignableNullClassToPrimitiveFalse() {
        assertFalse(ClassUtils.isAssignable(null, int.class));
    }

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableSameClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
    }

    @Test
    public void testIsAssignableSubclass() {
        assertTrue(ClassUtils.isAssignable(AgentChild.class, AgentBase.class));
        assertFalse(ClassUtils.isAssignable(AgentBase.class, AgentChild.class));
    }

    @Test
    public void testIsAssignableArraysNullBoth() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsAssignableArraysDifferentLengths() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, Integer.class}));
    }

    @Test
    public void testIsAssignableArraysMatching() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {Integer.class, String.class}, new Class<?>[] {Object.class, Object.class}));
    }

    // ---- isInnerClass ----

    @Test
    public void testIsInnerClassNull() {
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    public void testIsInnerClassTopLevel() {
        assertFalse(ClassUtils.isInnerClass(String.class));
    }

    @Test
    public void testIsInnerClassNested() {
        assertTrue(ClassUtils.isInnerClass(AgentOuter.AgentInner.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
    }

    // ---- isPrimitiveOrWrapper / isPrimitiveWrapper ----

    @Test
    public void testIsPrimitiveOrWrapperNull() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveOrWrapperTrueCases() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
    }

    @Test
    public void testIsPrimitiveOrWrapperFalseCase() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapperNull() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapperTrue() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(boolean.class));
    }

    // ---- isPublic ----

    @Test
    public void testIsPublicTrue() {
        assertTrue(ClassUtils.isPublic(String.class));
    }

    @Test
    public void testIsPublicFalse() {
        assertFalse(ClassUtils.isPublic(AgentBase.class));
    }

    @Test
    public void testIsPublicNullThrows() {
        try {
            ClassUtils.isPublic(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // ---- primitivesToWrappers / primitiveToWrapper ----

    @Test
    public void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    public void testPrimitivesToWrappersEmpty() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers();
        assertEquals(0, result.length);
    }

    @Test
    public void testPrimitivesToWrappersMixed() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, null}, result);
    }

    @Test
    public void testPrimitiveToWrapperNull() {
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    public void testPrimitiveToWrapperNonPrimitive() {
        assertSame(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    @Test
    public void testPrimitiveToWrapperVoid() {
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testPrimitiveToWrapperEachPrimitive() {
        assertSame(Boolean.class, ClassUtils.primitiveToWrapper(boolean.class));
        assertSame(Byte.class, ClassUtils.primitiveToWrapper(byte.class));
        assertSame(Character.class, ClassUtils.primitiveToWrapper(char.class));
        assertSame(Short.class, ClassUtils.primitiveToWrapper(short.class));
        assertSame(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertSame(Long.class, ClassUtils.primitiveToWrapper(long.class));
        assertSame(Double.class, ClassUtils.primitiveToWrapper(double.class));
        assertSame(Float.class, ClassUtils.primitiveToWrapper(float.class));
    }

    // ---- toClass ----

    @Test
    public void testToClassNullArray() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmptyArray() {
        final Class<?>[] result = ClassUtils.toClass();
        assertEquals(0, result.length);
    }

    @Test
    public void testToClassMixed() {
        final Class<?>[] result = ClassUtils.toClass("a", 1, null);
        assertArrayEquals(new Class<?>[] {String.class, Integer.class, null}, result);
    }

    // ---- wrappersToPrimitives / wrapperToPrimitive ----

    @Test
    public void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    public void testWrappersToPrimitivesEmpty() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives();
        assertEquals(0, result.length);
    }

    @Test
    public void testWrappersToPrimitivesMixed() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class);
        assertArrayEquals(new Class<?>[] {int.class, null}, result);
    }

    @Test
    public void testWrapperToPrimitiveNull() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testWrapperToPrimitiveNonWrapper() {
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    public void testWrapperToPrimitiveEachWrapper() {
        assertSame(boolean.class, ClassUtils.wrapperToPrimitive(Boolean.class));
        assertSame(byte.class, ClassUtils.wrapperToPrimitive(Byte.class));
        assertSame(char.class, ClassUtils.wrapperToPrimitive(Character.class));
        assertSame(short.class, ClassUtils.wrapperToPrimitive(Short.class));
        assertSame(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertSame(long.class, ClassUtils.wrapperToPrimitive(Long.class));
        assertSame(double.class, ClassUtils.wrapperToPrimitive(Double.class));
        assertSame(float.class, ClassUtils.wrapperToPrimitive(Float.class));
    }

    // ---- public constructor (deprecated but present) ----

    @Test
    public void testPublicConstructor() {
        assertNotNull(new ClassUtils());
    }

    // ---- constants ----

    @Test
    public void testConstants() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }
}
