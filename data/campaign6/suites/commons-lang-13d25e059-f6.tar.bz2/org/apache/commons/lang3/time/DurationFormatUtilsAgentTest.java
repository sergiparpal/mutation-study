/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 */
public class DurationFormatUtilsAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    // ---- formatDuration ----

    @Test
    public void testFormatDurationZeroPadded() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDuration(0, "HH:mm:ss.SSS"));
    }

    @Test
    public void testFormatDurationBasicPadded() {
        final long millis = (((1L * 24 + 2) * 60 + 3) * 60 + 4) * 1000 + 5;
        assertEquals("01 02:03:04.005", DurationFormatUtils.formatDuration(millis, "dd HH:mm:ss.SSS"));
    }

    @Test
    public void testFormatDurationNoPadding() {
        final long millis = (((1L * 24 + 2) * 60 + 3) * 60 + 4) * 1000 + 5;
        assertEquals("1 2:3:4.005", DurationFormatUtils.formatDuration(millis, "d H:m:s.SSS", false));
    }

    @Test
    public void testFormatDurationHoursRollOverWithoutDayToken() {
        // Without a 'd' token in the pattern, all days' worth of millis fold into hours.
        final long twentyFiveHours = 25L * 3600000L;
        assertEquals("25:00:00.000", DurationFormatUtils.formatDuration(twentyFiveHours, "HH:mm:ss.SSS"));
    }

    @Test
    public void testFormatDurationMillisecondsAfterSecondsAlwaysAtLeastThreeDigits() {
        // Per the 'S' token semantics, when preceded by 's' at least 3 digits are shown even without padding.
        assertEquals("0.005", DurationFormatUtils.formatDuration(5, "s.S", false));
    }

    @Test
    public void testFormatDurationMillisecondsAloneNotForcedToThreeDigits() {
        assertEquals("5", DurationFormatUtils.formatDuration(5, "S", false));
    }

    @Test
    public void testFormatDurationRepeatedTokenWidensField() {
        assertEquals("005", DurationFormatUtils.formatDuration(5 * 3600000L, "HHH", true));
        assertEquals("5", DurationFormatUtils.formatDuration(5 * 3600000L, "HHH", false));
    }

    @Test
    public void testFormatDurationNegativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1, "HH:mm:ss");
            }
        });
        assertTrue(ex.getMessage().contains("negative"));
    }

    @Test
    public void testFormatDurationNullFormatThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, null);
            }
        });
    }

    @Test
    public void testFormatDurationLiteralOnly() {
        assertEquals("hello", DurationFormatUtils.formatDuration(123456, "'hello'"));
    }

    // ---- formatDurationHMS / formatDurationISO ----

    @Test
    public void testFormatDurationHMSZero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    @Test
    public void testFormatDurationHMSOneMillisecond() {
        assertEquals("00:00:00.001", DurationFormatUtils.formatDurationHMS(1));
    }

    @Test
    public void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
    }

    @Test
    public void testFormatDurationISOMatchesJavadocExample() {
        // The javadoc of formatDurationISO documents output "such as P7D6TH5M4.321S" for the
        // days-and-lower ISO period format (no year/month fields). The actual implementation
        // always emits the year and month fields (always zero), producing
        // "P0Y0M7DT6H5M4.321S" instead -- a bug relative to the documented contract.
        final long millis = 7L * 86400000L + 6L * 3600000L + 5L * 60000L + 4321L;
        assertEquals("P7D6TH5M4.321S", DurationFormatUtils.formatDurationISO(millis));
    }

    // ---- formatDurationWords ----

    @Test
    public void testFormatDurationWordsZeroBothSuppressed() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
    }

    @Test
    public void testFormatDurationWordsZeroNoSuppress() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0, false, false));
    }

    @Test
    public void testFormatDurationWordsSingularPluralization() {
        final long oneHour = 3600000L;
        assertEquals("1 hour", DurationFormatUtils.formatDurationWords(oneHour, true, true));
    }

    @Test
    public void testFormatDurationWordsOneDayNoSuppress() {
        final long oneDay = 86400000L;
        assertEquals("1 day 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(oneDay, false, false));
    }

    @Test
    public void testFormatDurationWordsMixedUnitsNoSuppress() {
        final long millis = 3600000L + 60000L + 1000L;
        assertEquals("0 days 1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    // ---- formatPeriod ----

    @Test
    public void testFormatPeriodYearsMonthsDays() {
        final Calendar start = Calendar.getInstance(GMT);
        start.clear();
        start.set(2002, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(GMT);
        end.clear();
        end.set(2003, Calendar.MARCH, 26, 0, 0, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(),
                "y' years 'M' months 'd' days 'H' hours 'm' minutes 's' seconds'", true, GMT);
        assertEquals("1 years 2 months 25 days 0 hours 0 minutes 0 seconds", result);
    }

    @Test
    public void testFormatPeriodExactlyOneYear() {
        final Calendar start = Calendar.getInstance(GMT);
        start.clear();
        start.set(2000, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(GMT);
        end.clear();
        end.set(2001, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("1y0m0d",
                DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "y'y'M'm'd'd'", true, GMT));
    }

    @Test
    public void testFormatPeriodDaysOnlyAcrossLeapYear() {
        // 2000 is a leap year, so Jan 1 2000 -> Jan 1 2001 spans 366 days.
        final Calendar start = Calendar.getInstance(GMT);
        start.clear();
        start.set(2000, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(GMT);
        end.clear();
        end.set(2001, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("366d", DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "d'd'", true, GMT));
    }

    @Test
    public void testFormatPeriodEqualInstantsIsAllZero() {
        final long millis = 1_000_000L;
        assertEquals("0y0m0d0h0m0s",
                DurationFormatUtils.formatPeriod(millis, millis, "y'y'M'm'd'd'H'h'm'm's's'", true, GMT));
    }

    @Test
    public void testFormatPeriodStartAfterEndThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(5, 1, "d");
            }
        });
        assertTrue(ex.getMessage().contains("greater"));
    }

    @Test
    public void testFormatPeriodISO() {
        final Calendar start = Calendar.getInstance(GMT);
        start.clear();
        start.set(2002, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(GMT);
        end.clear();
        end.set(2003, Calendar.MARCH, 26, 0, 0, 0);
        assertEquals("P1Y2M25DT0H0M0.000S",
                DurationFormatUtils.formatPeriodISO(start.getTimeInMillis(), end.getTimeInMillis()));
    }

    // ---- optional block handling, per class-level javadoc examples ----

    @Test
    public void testOptionalBlockSuppressesZeroFieldAndTrailingLiteral() {
        final String pattern = "d'd'[H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, pattern, false));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(3600000L, pattern, false));
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(60000L, pattern, false));
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0, pattern, false));
    }

    @Test
    public void testLeadingOptionalBlockDropsLeadingZeroFields() {
        final String pattern = "[d'd'H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, pattern, false));
        assertEquals("1h0s", DurationFormatUtils.formatDuration(3600000L, pattern, false));
        assertEquals("1m0s", DurationFormatUtils.formatDuration(60000L, pattern, false));
        assertEquals("0s", DurationFormatUtils.formatDuration(0, pattern, false));
    }

    @Test
    public void testFullyOptionalPatternCanProduceEmptyString() {
        final String pattern = "[d'd'H'h'm'm's's']";
        assertEquals("1d", DurationFormatUtils.formatDuration(86400000L, pattern, false));
        assertEquals("1h", DurationFormatUtils.formatDuration(3600000L, pattern, false));
        assertEquals("1m", DurationFormatUtils.formatDuration(60000L, pattern, false));
        assertEquals("", DurationFormatUtils.formatDuration(0, pattern, false));
    }

    @Test
    public void testOptionalBlockWithLiteralBraces() {
        final String pattern = "['{'d'}']HH':'mm";
        assertEquals("{1}00:00", DurationFormatUtils.formatDuration(86400000L, pattern, true));
        assertEquals("01:00", DurationFormatUtils.formatDuration(3600000L, pattern, true));
        assertEquals("00:01", DurationFormatUtils.formatDuration(60000L, pattern, true));
        assertEquals("00:00", DurationFormatUtils.formatDuration(0, pattern, true));
    }

    @Test
    public void testFullyOptionalMultiTokenNoLiteralsCanProduceEmptyString() {
        final String pattern = "[dHms]";
        assertEquals("1", DurationFormatUtils.formatDuration(86400000L, pattern, false));
        assertEquals("1", DurationFormatUtils.formatDuration(3600000L, pattern, false));
        assertEquals("1", DurationFormatUtils.formatDuration(60000L, pattern, false));
        assertEquals("", DurationFormatUtils.formatDuration(0, pattern, false));
    }

    // ---- pattern parsing errors ----

    @Test
    public void testNestedOptionalBlockThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "[d[H]]");
            }
        });
    }

    @Test
    public void testUnopenedOptionalCloseThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "d]");
            }
        });
    }

    @Test
    public void testUnmatchedOptionalOpenThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "[d");
            }
        });
    }

    @Test
    public void testUnmatchedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "d'abc");
            }
        });
    }

    // ---- a repeated-letter token separated by a literal is a distinct occurrence ----

    @Test
    public void testSameLetterTokenSeparatedByLiteralAreIndependentOccurrences() {
        // 'd' then the literal "x" then another separate 'd' should render as two
        // independent day fields around the literal (e.g. "5x5"), not silently merge the
        // second occurrence's count into the first and drop its own rendered output.
        // The actual implementation merges them via a stale "previous token" reference
        // that survives across the intervening literal, producing "5x" -- losing the
        // second field entirely instead of outputting it.
        final long fiveDays = 5L * 86400000L;
        assertEquals("5x5", DurationFormatUtils.formatDuration(fiveDays, "d'x'd", false));
    }

    // ---- constructor ----

    @Test
    public void testPublicConstructorIsUsable() {
        final DurationFormatUtils instance = new DurationFormatUtils();
        assertTrue(instance instanceof DurationFormatUtils);
    }
}
