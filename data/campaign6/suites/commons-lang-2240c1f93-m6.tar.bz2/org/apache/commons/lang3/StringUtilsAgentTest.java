/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" a "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("x"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("x"));
    }

    @Test
    void testIsAnyAllEmptyBlank() {
        assertTrue(StringUtils.isAnyEmpty("a", null));
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertFalse(StringUtils.isAnyEmpty());

        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "a"));
        assertTrue(StringUtils.isAllEmpty());

        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));

        assertTrue(StringUtils.isAllBlank(" ", null, ""));
        assertFalse(StringUtils.isAllBlank(" ", "a"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertNull(StringUtils.trimToNull(null));
        assertEquals("abc", StringUtils.trimToNull(" abc "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("  "));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", " "));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", " "));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "a"));
        assertFalse(StringUtils.equals("a", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "a"));

        assertTrue(StringUtils.equalsAny("abc", "x", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "x", "y"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "x", "ABC"));
    }

    @Test
    void testContainsFamily() {
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "d"));
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", (String) null));

        assertTrue(StringUtils.contains("abc", 'b'));
        assertFalse(StringUtils.contains(null, 'b'));

        assertTrue(StringUtils.containsAny("abc", 'z', 'b'));
        assertFalse(StringUtils.containsAny("abc", 'z', 'y'));
        assertFalse(StringUtils.containsAny((String) null, 'a'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "D"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));

        assertTrue(StringUtils.containsOnly("aabbcc", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("aabbccd", 'a', 'b', 'c'));

        assertTrue(StringUtils.containsWhitespace("a b"));
        assertFalse(StringUtils.containsWhitespace("ab"));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("abcdef", "ABC"));
        assertFalse(StringUtils.startsWith(null, "a"));

        assertTrue(StringUtils.startsWithIgnoreCase("abcdef", "ABC"));

        assertTrue(StringUtils.startsWithAny("abcdef", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcdef", "xyz", "pqr"));

        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("abcdef", "DEF"));
        assertTrue(StringUtils.endsWithIgnoreCase("abcdef", "DEF"));
        assertTrue(StringUtils.endsWithAny("abcdef", "xyz", "def"));
    }

    @Test
    void testIndexOfFamily() {
        assertEquals(1, StringUtils.indexOf("abcabc", "b"));
        assertEquals(-1, StringUtils.indexOf(null, "b"));
        assertEquals(4, StringUtils.indexOf("abcabc", "b", 2));

        assertEquals(1, StringUtils.indexOf("abc", 'b'));
        assertEquals(-1, StringUtils.indexOf("abc", 'z'));

        assertEquals(4, StringUtils.lastIndexOf("abcabc", "b"));
        assertEquals(-1, StringUtils.lastIndexOf(null, "b"));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", 'x', 'y'));

        assertEquals(2, StringUtils.indexOfIgnoreCase("abCD", "CD"));
        assertEquals(3, StringUtils.ordinalIndexOf("aabaabaa", "a", 3));
        assertEquals(2, StringUtils.lastOrdinalIndexOf("aabaabaa", "b", 2));
    }

    @Test
    void testSubstringBoundaries() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("abc", StringUtils.substring("abc", -10));
        assertEquals("", StringUtils.substring("abc", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));

        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));

        assertEquals("a", StringUtils.substringBefore("abc", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));
        assertNull(StringUtils.substringBefore(null, "b"));

        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "d"));

        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("abcba", StringUtils.substringBeforeLast("abcba", "d"));

        assertEquals("b", StringUtils.substringBetween("yabcz", "a", "c"));
        assertNull(StringUtils.substringBetween("yabcz", "d", "c"));
        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
    }

    @Test
    void testSplitAndJoin() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a b c"));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a,b,c", ","));
        assertArrayEquals(new String[] {"a", "", "b"}, StringUtils.splitPreserveAllTokens("a,,b", ","));

        assertEquals("a,b,c", StringUtils.join(new String[] {"a", "b", "c"}, ','));
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new String[0], ','));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
    }

    @Test
    void testReplaceAndRemove() {
        assertEquals("fooXfooXfoo", StringUtils.replace("fooZfooZfoo", "Z", "X"));
        assertEquals("fooXfooZfoo", StringUtils.replace("fooZfooZfoo", "Z", "X", 1));
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", "", "x"));

        assertEquals("ab", StringUtils.remove("abc", 'c'));
        assertEquals("", StringUtils.remove("", 'c'));
        assertNull(StringUtils.remove(null, 'c'));

        assertEquals("qeick", StringUtils.remove("queick", "u"));
        assertEquals("queick", StringUtils.removeStart("queick", "x"));
        assertEquals("eick", StringUtils.removeStart("queick", "qu"));
        assertEquals("quei", StringUtils.removeEnd("queick", "ck"));
    }

    @Test
    void testRepeatPadCenter() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertNull(StringUtils.repeat(null, 2));

        assertEquals("  abc", StringUtils.leftPad("abc", 5));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertNull(StringUtils.leftPad(null, 5));

        assertEquals("abc  ", StringUtils.rightPad("abc", 5));
        assertNull(StringUtils.rightPad(null, 5));

        assertEquals("  abc   ", StringUtils.center("abc", 8));
        assertNull(StringUtils.center(null, 4));
        assertEquals("abc", StringUtils.center("abc", 2));
    }

    @Test
    void testCaseConversion() {
        assertEquals("Foo", StringUtils.capitalize("foo"));
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));

        assertEquals("foo", StringUtils.uncapitalize("Foo"));
        assertNull(StringUtils.uncapitalize(null));

        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertNull(StringUtils.upperCase(null));

        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertNull(StringUtils.lowerCase(null));

        assertEquals("aB", StringUtils.swapCase("Ab"));
        assertNull(StringUtils.swapCase(null));
    }

    @Test
    void testReverseAndMisc() {
        assertEquals("cba", StringUtils.reverse("abc"));
        assertNull(StringUtils.reverse(null));

        assertEquals(3, StringUtils.countMatches("ababab", "ab"));
        assertEquals(0, StringUtils.countMatches(null, "a"));

        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric(null));

        assertTrue(StringUtils.isAlpha("abcXYZ"));
        assertFalse(StringUtils.isAlpha("abc123"));
        assertFalse(StringUtils.isAlpha(null));

        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("abc 123"));

        assertTrue(StringUtils.isWhitespace("   "));
        assertTrue(StringUtils.isWhitespace(""));
        assertFalse(StringUtils.isWhitespace(null));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("Abc"));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertTrue(StringUtils.isMixedCase("AbC"));
        assertFalse(StringUtils.isMixedCase("ABC"));
    }

    @Test
    void testDefaultAndFirstNonBlankEmpty() {
        assertEquals("default", StringUtils.defaultString(null, "default"));
        assertEquals("abc", StringUtils.defaultString("abc", "default"));
        assertEquals("", StringUtils.defaultString(null));

        assertEquals("def", StringUtils.defaultIfEmpty("", "def"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "def"));

        assertEquals("def", StringUtils.defaultIfBlank("  ", "def"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "def"));

        assertEquals("abc", StringUtils.firstNonBlank(null, " ", "abc"));
        assertNull(StringUtils.firstNonBlank((String[]) null));

        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    void testAbbreviateAndTruncate() {
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertNull(StringUtils.abbreviate(null, 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 10));

        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("", StringUtils.truncate("abcdefg", 0));
        assertNull(StringUtils.truncate(null, 3));
    }

    @Test
    void testWrapAndUnwrap() {
        assertEquals("'abc'", StringUtils.wrap("abc", '\''));
        assertNull(StringUtils.wrap(null, '\''));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("abc", StringUtils.unwrap("abc", '\''));
    }

    @Test
    void testChompChopLength() {
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n", ""));
        assertNull(StringUtils.chomp(null));

        assertEquals("ab", StringUtils.chop("abc"));
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));

        assertEquals(3, StringUtils.length("abc"));
        assertEquals(0, StringUtils.length(null));
    }

    @Test
    void testCompareAndDifference() {
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertEquals(0, StringUtils.compare("a", "a"));
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);

        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);

        assertEquals("a", StringUtils.difference("abc", "aba"));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("abc", StringUtils.difference(null, "abc"));
    }

    @Test
    void testLeftRightMid() {
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));
        assertEquals("", StringUtils.left("abc", -1));
        assertNull(StringUtils.left(null, 2));

        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertNull(StringUtils.right(null, 2));

        assertEquals("b", StringUtils.mid("abc", 1, 1));
        assertEquals("", StringUtils.mid("abc", 1, -1));
        assertNull(StringUtils.mid(null, 0, 1));
        assertNull(StringUtils.mid(null, -1, 1));
    }

    @Test
    void testGetLevenshteinDistanceAndFuzzy() {
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc"));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));

        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "abd", 0));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd", 5));
    }

    @Test
    void testNormalizeSpaceAndDeleteWhitespace() {
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
        assertNull(StringUtils.normalizeSpace(null));

        assertEquals("abc", StringUtils.deleteWhitespace(" a b c "));
        assertNull(StringUtils.deleteWhitespace(null));
    }

    @Test
    void testOverlayAndRotate() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("aXXXXf", StringUtils.overlay("abcdef", "XXXX", 1, 5));
        assertNull(StringUtils.overlay(null, "x", 0, 1));

        assertEquals("defabc", StringUtils.rotate("abcdef", 3));
        assertEquals("abcdef", StringUtils.rotate("abcdef", 0));
        assertNull(StringUtils.rotate(null, 2));
    }

    @Test
    void testToCodePointsAndValueOf() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));

        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
        assertNull(StringUtils.valueOf(null));
    }

    @Test
    void testConstantsAreStable() {
        assertEquals("", StringUtils.EMPTY);
        assertEquals(" ", StringUtils.SPACE);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
        assertSame(StringUtils.EMPTY, StringUtils.defaultString(null));
    }
}
