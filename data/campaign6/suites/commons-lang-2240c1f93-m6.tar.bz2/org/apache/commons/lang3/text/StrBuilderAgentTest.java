/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
class StrBuilderAgentTest {

    @Test
    void testConstructors() {
        assertEquals("", new StrBuilder().toString());
        assertEquals(0, new StrBuilder().length());

        final StrBuilder negativeCapacity = new StrBuilder(-5);
        assertTrue(negativeCapacity.capacity() > 0);

        final StrBuilder zeroCapacity = new StrBuilder(0);
        assertTrue(zeroCapacity.capacity() > 0);

        assertEquals("abc", new StrBuilder("abc").toString());
        assertEquals("", new StrBuilder((String) null).toString());
    }

    @Test
    void testAppendVariousTypes() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(' ').append(1).append(' ').append(2L).append(' ').append(1.5).append(' ').append(2.5f);
        assertEquals("true 1 2 1.5 2.5", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.append("abcdef", 1, 3);
        assertEquals("bcd", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.append((Object) null);
        assertEquals("", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendNull();
        assertEquals("", sb4.toString());
        sb4.setNullText("NULL");
        sb4.appendNull();
        assertEquals("NULL", sb4.toString());
    }

    @Test
    void testAppendReturnsThisForChaining() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append("a").append("b").append("c");
        assertSame(sb, result);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testCharAtBoundaries() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.charAt(-1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.charAt(3);
            }
        });
    }

    @Test
    void testDeleteCharAtBoundaries() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.deleteCharAt(-1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.deleteCharAt(99);
            }
        });
    }

    @Test
    void testDeleteRangeAndClampedEndIndex() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcdef");
        sb2.delete(2, 1000);
        assertEquals("ab", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb3.delete(-1, 3);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb3.delete(4, 2);
            }
        });
    }

    @Test
    void testDeleteAllAndDeleteFirst() {
        final StrBuilder sb = new StrBuilder("abcabcabc");
        sb.deleteAll('a');
        assertEquals("bcbcbc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcabcabc");
        sb2.deleteFirst('a');
        assertEquals("bcabcabc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("xxyyxx");
        sb3.deleteAll("xx");
        assertEquals("yy", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("xxyyxx");
        sb4.deleteFirst("xx");
        assertEquals("yyxx", sb4.toString());
    }

    @Test
    void testInsertBoundaries() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.insert(1, "XY");
        assertEquals("aXYbc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abc");
        sb2.insert(0, (String) null);
        assertEquals("abc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abc");
        sb3.insert(3, "Z");
        assertEquals("abcZ", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb4.insert(-1, "Z");
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb4.insert(4, "Z");
            }
        });
    }

    @Test
    void testReplaceAndReplaceAllFirst() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XY");
        assertEquals("aXYdef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("aXaXaX");
        sb2.replaceAll('X', 'Y');
        assertEquals("aYaYaY", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("aXaXaX");
        sb3.replaceFirst('X', 'Y');
        assertEquals("aYaXaX", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("foobarfoobar");
        sb4.replaceAll("foo", "X");
        assertEquals("XbarXbar", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("foobarfoobar");
        sb5.replaceFirst("foo", "X");
        assertEquals("Xbarfoobar", sb5.toString());
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(-1, sb.indexOf('z'));

        assertEquals(1, sb.indexOf("bc"));
        assertEquals(4, sb.indexOf("bc", 2));
        assertEquals(-1, sb.indexOf("zz"));

        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(1, sb.lastIndexOf('b', 2));

        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(1, sb.lastIndexOf("bc", 2));
    }

    @Test
    void testContainsStartsEndsWith() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains('c'));
        assertFalse(sb.contains('z'));
        assertTrue(sb.contains("cd"));
        assertFalse(sb.contains("zz"));

        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("xyz"));
        assertFalse(sb.startsWith(null));

        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("xyz"));
        assertFalse(sb.endsWith(null));
    }

    @Test
    void testEqualsAndHashCode() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("ABC");

        assertTrue(sb1.equals(sb2));
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((StrBuilder) null));
        assertEquals(sb1.hashCode(), sb2.hashCode());

        assertTrue(sb1.equalsIgnoreCase(sb3));
        assertFalse(sb1.equalsIgnoreCase(new StrBuilder("abcd")));
    }

    @Test
    void testSubstringMidLeftRight() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
        assertEquals("cd", sb.substring(2, 4));
        assertEquals("ab", sb.leftString(2));
        assertEquals("ef", sb.rightString(2));
        assertEquals("cd", sb.midString(2, 2));

        assertEquals("abcdef", sb.leftString(100));
        assertEquals("abcdef", sb.rightString(100));
        assertEquals("", sb.leftString(-1));
        assertEquals("", sb.rightString(-1));
    }

    @Test
    void testSetCharAtAndSetLength() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(0, 'X');
        assertEquals("Xbc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.setCharAt(-1, 'Y');
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.setCharAt(10, 'Y');
            }
        });

        sb.setLength(1);
        assertEquals("X", sb.toString());
        assertEquals(1, sb.length());

        sb.setLength(3);
        assertEquals(3, sb.length());

        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.setLength(-1);
            }
        });
    }

    @Test
    void testClearSizeIsEmpty() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
        sb.clear();
        assertEquals(0, sb.size());
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        assertEquals("", sb.toString());
    }

    @Test
    void testReverse() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.reverse();
        assertEquals("fedcba", sb.toString());

        final StrBuilder empty = new StrBuilder();
        empty.reverse();
        assertEquals("", empty.toString());

        final StrBuilder single = new StrBuilder("a");
        single.reverse();
        assertEquals("a", single.toString());
    }

    @Test
    void testTrim() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());

        final StrBuilder blank = new StrBuilder("   ");
        blank.trim();
        assertEquals("", blank.toString());
    }

    @Test
    void testAppendSeparator() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(",");
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendSeparator(',', 0);
        sb2.append("x");
        assertEquals("x", sb2.toString());
        sb2.appendSeparator(',', 1);
        sb2.append("y");
        assertEquals("x,y", sb2.toString());
    }

    @Test
    void testAppendPaddingAndFixedWidth() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadLeft(1, 4, '0');
        assertEquals("0001", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendFixedWidthPadRight(1, 4, '0');
        assertEquals("1000", sb3.toString());
    }

    @Test
    void testToCharArrayAndGetChars() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd', 'e', 'f'}, sb.toCharArray());
        assertArrayEquals(new char[] {'b', 'c'}, sb.toCharArray(1, 3));
        assertArrayEquals(new char[0], new StrBuilder().toCharArray());

        final char[] dest = new char[6];
        sb.getChars(dest);
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd', 'e', 'f'}, dest);
    }

    @Test
    void testCapacityAndEnsureCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        assertTrue(sb.capacity() >= 5);
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);

        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    void testSubSequence() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final CharSequence seq = sb.subSequence(1, 4);
        assertEquals("bcd", seq.toString());
    }

    @Test
    void testBuildMatchesToString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(sb.toString(), sb.build());
    }

    @Test
    void testToStringBufferAndBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.toStringBuffer().toString());
        assertEquals("abc", sb.toStringBuilder().toString());
    }

    @Test
    void testNullTextHandling() {
        final StrBuilder sb = new StrBuilder();
        assertNotNull(sb);
        sb.setNullText("");
        assertEquals(null, sb.getNullText());
        sb.setNullText("N/A");
        assertEquals("N/A", sb.getNullText());
    }

    @Test
    void testNewLineText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br/>");
        assertEquals("<br/>", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("<br/>", sb.toString());
    }
}
