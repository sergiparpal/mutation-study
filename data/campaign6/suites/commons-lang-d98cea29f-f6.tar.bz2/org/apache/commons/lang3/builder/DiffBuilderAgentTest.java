/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link DiffBuilder}.
 */
class DiffBuilderAgentTest {

    /** Simple value type with value-based equals/hashCode, distinct from identity. */
    static final class Point {
        final int x;
        final int y;

        Point(final int x, final int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof Point)) {
                return false;
            }
            final Point other = (Point) obj;
            return x == other.x && y == other.y;
        }

        @Override
        public int hashCode() {
            return x * 31 + y;
        }
    }

    // ---- basic construction / builder -------------------------------------------------

    @Test
    void testDeprecatedConstructorNullLeftThrowsNpe() {
        assertThrows(NullPointerException.class, () -> new DiffBuilder<>(null, "x", ToStringStyle.DEFAULT_STYLE));
    }

    @Test
    void testDeprecatedConstructorNullRightThrowsNpe() {
        assertThrows(NullPointerException.class, () -> new DiffBuilder<>("x", null, ToStringStyle.DEFAULT_STYLE));
    }

    @Test
    void testBuilderWithoutLeftOrRightThrowsNpeOnBuild() {
        final DiffBuilder.Builder<String> builder = DiffBuilder.<String>builder().setRight("right");
        assertThrows(NullPointerException.class, builder::build);
    }

    @Test
    void testBuilderNullStyleUsesDefault() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("a").setRight("b").setStyle(null).build();
        final DiffResult<String> result = db.append("f", 1, 2).build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    void testBuilderCustomStyleIsUsed() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("a").setRight("b").setStyle(ToStringStyle.SHORT_PREFIX_STYLE).build();
        final DiffResult<String> result = db.append("f", 1, 2).build();
        assertSame(ToStringStyle.SHORT_PREFIX_STYLE, result.getToStringStyle());
    }

    @Test
    void testBuilderNullToStringFormatUsesDefault() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("a").setRight("b").setToStringFormat(null).build();
        final DiffResult<String> result = db.append("f", 1, 2).build();
        assertTrue(result.toString().contains("differs from"));
    }

    @Test
    void testBuilderCustomToStringFormat() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("a").setRight("b").setToStringFormat("%s <> %s").build();
        final DiffResult<String> result = db.append("f", 1, 2).build();
        assertTrue(result.toString().contains("<>"));
        assertFalse(result.toString().contains("differs from"));
    }

    @Test
    void testBuilderFluentReturnsSameInstance() {
        final DiffBuilder.Builder<String> builder = new DiffBuilder.Builder<>();
        assertSame(builder, builder.setLeft("a"));
        assertSame(builder, builder.setRight("b"));
        assertSame(builder, builder.setTestObjectsEquals(false));
        assertSame(builder, builder.setToStringFormat("x"));
    }

    @Test
    void testGetLeftGetRight() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("left").setRight("right").build();
        assertEquals("left", db.getLeft());
        assertEquals("right", db.getRight());
    }

    // ---- triviality / testObjectsEquals ------------------------------------------------

    @Test
    void testIdenticalReferenceSkipsAllDiffs() {
        final Point p = new Point(1, 2);
        final DiffBuilder<Point> db = DiffBuilder.<Point>builder().setLeft(p).setRight(p).build();
        final DiffResult<Point> result = db.append("x", 1, 2).append("y", "a", "b").build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testEqualButDistinctObjectsSkipAllDiffs() {
        final Point left = new Point(1, 2);
        final Point right = new Point(1, 2);
        assertFalse(left == right);
        assertEquals(left, right);
        final DiffBuilder<Point> db = DiffBuilder.<Point>builder().setLeft(left).setRight(right).build();
        final DiffResult<Point> result = db.append("x", 1, 2).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testTestObjectsEqualsFalseForcesPerFieldEvaluationEvenIfEqual() {
        final Point left = new Point(1, 2);
        final Point right = new Point(1, 2);
        final DiffBuilder<Point> db = DiffBuilder.<Point>builder().setLeft(left).setRight(right).setTestObjectsEquals(false).build();
        final DiffResult<Point> result = db.append("x", 1, 2).append("y", 5, 5).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals("x", result.getDiffs().get(0).getFieldName());
    }

    @Test
    void testBuildWithNoAppendsIsEmpty() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("a").setRight("b").build();
        final DiffResult<String> result = db.build();
        assertEquals(0, result.getNumberOfDiffs());
        assertEquals(DiffResult.OBJECTS_SAME_STRING, result.toString());
    }

    // ---- primitive append methods -------------------------------------------------------

    private <T> DiffBuilder<T> newBuilder(final T left, final T right) {
        return DiffBuilder.<T>builder().setLeft(left).setRight(right).build();
    }

    @Test
    void testAppendBoolean() {
        final DiffResult<String> same = newBuilder("l", "r").append("f", true, true).build();
        assertEquals(0, same.getNumberOfDiffs());

        final DiffResult<String> diff = newBuilder("l", "r").append("f", true, false).build();
        assertEquals(1, diff.getNumberOfDiffs());
        final Diff<?> d = diff.getDiffs().get(0);
        assertEquals("f", d.getFieldName());
        assertEquals(Boolean.TRUE, d.getLeft());
        assertEquals(Boolean.FALSE, d.getRight());
    }

    @Test
    void testAppendBooleanArray() {
        final DiffResult<String> same = newBuilder("l", "r").append("f", new boolean[] {true, false}, new boolean[] {true, false}).build();
        assertEquals(0, same.getNumberOfDiffs());

        final DiffResult<String> diff = newBuilder("l", "r").append("f", new boolean[] {true, false}, new boolean[] {true, true}).build();
        assertEquals(1, diff.getNumberOfDiffs());
        final Diff<?> d = diff.getDiffs().get(0);
        assertEquals(Boolean[].class, d.getLeft().getClass());
    }

    @Test
    void testAppendByte() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", (byte) 1, (byte) 2).build();
        assertEquals(1, diff.getNumberOfDiffs());
        assertEquals(Byte.valueOf((byte) 1), diff.getDiffs().get(0).getLeft());
        assertEquals(Byte.valueOf((byte) 2), diff.getDiffs().get(0).getRight());

        final DiffResult<String> same = newBuilder("l", "r").append("f", (byte) 1, (byte) 1).build();
        assertEquals(0, same.getNumberOfDiffs());
    }

    @Test
    void testAppendByteArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new byte[] {1, 2}, new byte[] {1, 3}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    @Test
    void testAppendChar() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", 'a', 'b').build();
        assertEquals(1, diff.getNumberOfDiffs());
        assertEquals(Character.valueOf('a'), diff.getDiffs().get(0).getLeft());

        final DiffResult<String> same = newBuilder("l", "r").append("f", 'a', 'a').build();
        assertEquals(0, same.getNumberOfDiffs());
    }

    @Test
    void testAppendCharArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new char[] {'a', 'b'}, new char[] {'a', 'c'}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    @Test
    void testAppendDouble() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", 1.0d, 2.0d).build();
        assertEquals(1, diff.getNumberOfDiffs());

        final DiffResult<String> same = newBuilder("l", "r").append("f", 1.0d, 1.0d).build();
        assertEquals(0, same.getNumberOfDiffs());

        // NaN is considered equal to itself per Double bit-level comparison.
        final DiffResult<String> nan = newBuilder("l", "r").append("f", Double.NaN, Double.NaN).build();
        assertEquals(0, nan.getNumberOfDiffs());

        // +0.0 and -0.0 are different bit patterns.
        final DiffResult<String> zeros = newBuilder("l", "r").append("f", 0.0d, -0.0d).build();
        assertEquals(1, zeros.getNumberOfDiffs());
    }

    @Test
    void testAppendDoubleArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new double[] {1.0}, new double[] {2.0}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    @Test
    void testAppendFloat() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", 1.0f, 2.0f).build();
        assertEquals(1, diff.getNumberOfDiffs());

        final DiffResult<String> same = newBuilder("l", "r").append("f", 1.0f, 1.0f).build();
        assertEquals(0, same.getNumberOfDiffs());

        final DiffResult<String> nan = newBuilder("l", "r").append("f", Float.NaN, Float.NaN).build();
        assertEquals(0, nan.getNumberOfDiffs());
    }

    @Test
    void testAppendFloatArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new float[] {1.0f}, new float[] {2.0f}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    @Test
    void testAppendInt() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", 1, 2).build();
        assertEquals(1, diff.getNumberOfDiffs());
        assertEquals(Integer.valueOf(1), diff.getDiffs().get(0).getLeft());
        assertEquals(Integer.valueOf(2), diff.getDiffs().get(0).getRight());

        final DiffResult<String> same = newBuilder("l", "r").append("f", 5, 5).build();
        assertEquals(0, same.getNumberOfDiffs());
    }

    @Test
    void testAppendIntArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new int[] {1, 2}, new int[] {1, 3}).build();
        assertEquals(1, diff.getNumberOfDiffs());
        assertEquals(Integer[].class, diff.getDiffs().get(0).getLeft().getClass());
    }

    @Test
    void testAppendLong() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", 1L, 2L).build();
        assertEquals(1, diff.getNumberOfDiffs());

        final DiffResult<String> same = newBuilder("l", "r").append("f", 5L, 5L).build();
        assertEquals(0, same.getNumberOfDiffs());
    }

    @Test
    void testAppendLongArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new long[] {1L}, new long[] {2L}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    @Test
    void testAppendShort() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", (short) 1, (short) 2).build();
        assertEquals(1, diff.getNumberOfDiffs());

        final DiffResult<String> same = newBuilder("l", "r").append("f", (short) 5, (short) 5).build();
        assertEquals(0, same.getNumberOfDiffs());
    }

    @Test
    void testAppendShortArray() {
        final DiffResult<String> diff = newBuilder("l", "r").append("f", new short[] {1}, new short[] {2}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    // ---- Object / Object[] append --------------------------------------------------------

    @Test
    void testAppendObjectEqualByEquals() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", new Point(1, 2), new Point(1, 2)).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testAppendObjectDifferent() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", new Point(1, 2), new Point(9, 9)).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    void testAppendObjectBothNull() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", (Object) null, (Object) null).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testAppendObjectOneNull() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", "value", (Object) null).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals("value", result.getDiffs().get(0).getLeft());
        assertNull(result.getDiffs().get(0).getRight());
    }

    @Test
    void testAppendObjectDispatchesToIntArray() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", (Object) new int[] {1, 2}, (Object) new int[] {1, 3}).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Integer[].class, result.getDiffs().get(0).getLeft().getClass());
    }

    @Test
    void testAppendObjectDispatchesToBooleanArray() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", (Object) new boolean[] {true}, (Object) new boolean[] {false}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    void testAppendObjectDispatchesToObjectArrayForNonPrimitiveArrays() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", (Object) new String[] {"a"}, (Object) new String[] {"b"}).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(String[].class, result.getDiffs().get(0).getLeft().getClass());
    }

    @Test
    void testAppendObjectDispatchWithNullLhsArray() {
        final DiffResult<String> result = newBuilder("l", "r").append("f", (Object) null, (Object) new int[] {1, 2}).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertNull(result.getDiffs().get(0).getLeft());
        assertEquals(Integer[].class, result.getDiffs().get(0).getRight().getClass());
    }

    @Test
    void testAppendObjectArray() {
        final DiffResult<String> same = newBuilder("l", "r").append("f", new Object[] {"a", "b"}, new Object[] {"a", "b"}).build();
        assertEquals(0, same.getNumberOfDiffs());

        final DiffResult<String> diff = newBuilder("l", "r").append("f", new Object[] {"a"}, new Object[] {"b"}).build();
        assertEquals(1, diff.getNumberOfDiffs());
    }

    // ---- append(String, DiffResult) ------------------------------------------------------

    @Test
    void testAppendDiffResultNullThrowsNpe() {
        final DiffBuilder<String> db = newBuilder("l", "r");
        assertThrows(NullPointerException.class, () -> db.append("f", null));
    }

    @Test
    void testAppendDiffResultMergesAndPrefixesFieldNames() {
        final DiffResult<String> nested = newBuilder("innerLeft", "innerRight").append("name", "a", "b").build();
        assertEquals(1, nested.getNumberOfDiffs());

        final DiffResult<String> outer = newBuilder("l", "r").append("person", nested).build();
        assertEquals(1, outer.getNumberOfDiffs());
        assertEquals("person.name", outer.getDiffs().get(0).getFieldName());
        assertEquals("a", outer.getDiffs().get(0).getLeft());
        assertEquals("b", outer.getDiffs().get(0).getRight());
    }

    @Test
    void testAppendDiffResultWithNoDiffsAddsNothing() {
        final DiffResult<String> emptyNested = newBuilder("x", "x").build();
        final DiffResult<String> outer = newBuilder("l", "r").append("field", emptyNested).build();
        assertEquals(0, outer.getNumberOfDiffs());
    }

    @Test
    void testAppendDiffResultSkippedWhenBuilderObjectsEqual() {
        final Point left = new Point(1, 1);
        final Point right = new Point(1, 1);
        final DiffResult<String> nested = newBuilder("innerLeft", "innerRight").append("name", "a", "b").build();
        final DiffBuilder<Point> outerBuilder = DiffBuilder.<Point>builder().setLeft(left).setRight(right).build();
        final DiffResult<Point> outer = outerBuilder.append("person", nested).build();
        assertEquals(0, outer.getNumberOfDiffs());
    }

    // ---- fluent chaining / lazy evaluation ----------------------------------------------

    @Test
    void testAppendReturnsSameBuilderInstanceForChaining() {
        final DiffBuilder<String> db = newBuilder("l", "r");
        final DiffBuilder<String> after = db.append("a", 1, 1);
        assertSame(db, after);
    }

    @Test
    void testMultipleAppendsAccumulateInOrder() {
        final DiffResult<String> result = newBuilder("l", "r").append("a", 1, 2).append("b", "x", "x").append("c", 3L, 4L).build();
        assertEquals(2, result.getNumberOfDiffs());
        final List<Diff<?>> diffs = result.getDiffs();
        assertEquals("a", diffs.get(0).getFieldName());
        assertEquals("c", diffs.get(1).getFieldName());
    }

    @Test
    void testDiffsListIsUnmodifiable() {
        final DiffResult<String> result = newBuilder("l", "r").append("a", 1, 2).build();
        assertThrows(UnsupportedOperationException.class, () -> result.getDiffs().add(null));
    }

    @Test
    void testDiffValueIsCapturedAtAppendTime() {
        final DiffBuilder<String> db = newBuilder("l", "r");
        final DiffResult<String> result = db.append("f", 7, 99).build();
        assertEquals(Integer.valueOf(7), result.getDiffs().get(0).getLeft());
        assertEquals(Integer.valueOf(99), result.getDiffs().get(0).getRight());
    }

    // ---- DiffResult basics produced by build() -------------------------------------------

    @Test
    void testBuildResultExposesLeftAndRight() {
        final DiffResult<String> result = newBuilder("leftVal", "rightVal").append("f", 1, 2).build();
        assertEquals("leftVal", result.getLeft());
        assertEquals("rightVal", result.getRight());
    }

    @Test
    void testToStringEmptyIsObjectsSameString() {
        final DiffResult<String> result = newBuilder("l", "r").build();
        assertEquals("", result.toString());
    }

    @Test
    void testToStringNonEmptyUsesConfiguredFormat() {
        final DiffBuilder<String> db = DiffBuilder.<String>builder().setLeft("l").setRight("r").setToStringFormat("LEFT[%s]RIGHT[%s]").build();
        final DiffResult<String> result = db.append("f", 1, 2).build();
        final String s = result.toString();
        assertTrue(s.startsWith("LEFT["));
        assertTrue(s.contains("]RIGHT["));
    }

    @Test
    void testDiffToStringFormat() {
        final DiffResult<String> result = newBuilder("l", "r").append("age", 1, 2).build();
        final Diff<?> diff = result.getDiffs().get(0);
        assertEquals("[age: 1, 2]", diff.toString());
    }

    @Test
    void testDiffSetValueThrowsUnsupported() {
        final DiffResult<String> result = newBuilder("l", "r").append("age", 1, 2).build();
        final Diff<Object> diff = (Diff<Object>) result.getDiffs().get(0);
        assertThrows(UnsupportedOperationException.class, () -> diff.setValue("x"));
    }

    @Test
    void testDiffFieldNameIsNotNull() {
        final DiffResult<String> result = newBuilder("l", "r").append("age", 1, 2).build();
        assertNotNull(result.getDiffs().get(0).getFieldName());
    }

    /** An object whose equals() re-enters DiffBuilder construction for the very same pair, simulating a cyclic object graph. */
    static final class CyclicNode {
        final int id;

        CyclicNode(final int id) {
            this.id = id;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof CyclicNode)) {
                return false;
            }
            final CyclicNode other = (CyclicNode) obj;
            return new DiffBuilder<>(this, other, ToStringStyle.DEFAULT_STYLE).append("id", id, other.id).build().getNumberOfDiffs() == 0;
        }

        @Override
        public int hashCode() {
            return id;
        }
    }

    @Test
    void testConstructorAvoidsInfiniteRecursionForCyclicEquals() {
        final CyclicNode a = new CyclicNode(1);
        final CyclicNode b = new CyclicNode(2);
        // Must not throw StackOverflowError: the pair (a, b) is registered before Objects.equals(a, b)
        // is invoked, so the re-entrant DiffBuilder construction inside CyclicNode.equals() short-circuits.
        final DiffResult<CyclicNode> result = new DiffBuilder<>(a, b, ToStringStyle.DEFAULT_STYLE).append("id", a.id, b.id).build();
        assertEquals(0, result.getNumberOfDiffs());
    }
}
