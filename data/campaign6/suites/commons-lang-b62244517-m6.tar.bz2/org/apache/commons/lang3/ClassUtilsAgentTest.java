/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private interface AgentInterfaceA {
        // marker
    }

    private interface AgentInterfaceB extends AgentInterfaceA {
        // marker
    }

    private static class AgentSuper implements AgentInterfaceA {
        // marker
    }

    private static class AgentChild extends AgentSuper implements AgentInterfaceB {
        // marker
    }

    public static class AgentOuter {
        public class AgentInner {
            // marker
        }
    }

    // --- getAbbreviatedName(Class, int) ---

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    // --- getAbbreviatedName(String, int) ---

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameNonPositiveLength() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
    }

    // --- getAllInterfaces ---

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertEquals(2, interfaces.size());
        assertTrue(interfaces.contains(AgentInterfaceA.class));
        assertTrue(interfaces.contains(AgentInterfaceB.class));
    }

    // --- getAllSuperclasses ---

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(2, superclasses.size());
        assertEquals(AgentSuper.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    // --- getCanonicalName(Class, String) / getCanonicalName(Class) ---

    @Test
    public void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
    }

    // --- getCanonicalName(Object, String) ---

    @Test
    public void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    // --- getClass(String) / getClass(ClassLoader, String, boolean) ---

    @Test
    public void testGetClassSimpleName() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    public void testGetClassArrayPrimitive() throws ClassNotFoundException {
        assertEquals(int[].class, ClassUtils.getClass("[I"));
    }

    @Test
    public void testGetClassArrayOfObjects() throws ClassNotFoundException {
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassWithDotArraySyntax() throws ClassNotFoundException {
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
    }

    @Test
    public void testGetClassInnerClassWithDot() throws ClassNotFoundException {
        assertEquals(AgentOuter.AgentInner.class, ClassUtils.getClass(AgentOuter.AgentInner.class.getName().replace('$', '.')));
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("this.class.does.not.Exist");
            }
        });
    }

    @Test
    public void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassPrimitive() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
    }

    // --- getComponentType ---

    @Test
    public void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // --- getName ---

    @Test
    public void testGetNameClassNull() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetNameClass() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObjectNull() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    // --- getPackageCanonicalName ---

    @Test
    public void testGetPackageCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectNull() {
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
    }

    @Test
    public void testGetPackageCanonicalNameString() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    // --- getPackageName ---

    @Test
    public void testGetPackageNameClassNull() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
    }

    @Test
    public void testGetPackageNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObjectNull() {
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
    }

    @Test
    public void testGetPackageNameStringNullOrEmpty() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
    }

    @Test
    public void testGetPackageNameDefaultPackage() {
        assertEquals("", ClassUtils.getPackageName("NoPackageClass"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
    }

    // --- getPublicMethod ---

    @Test
    public void testGetPublicMethod() throws Exception {
        assertNotNull(ClassUtils.getPublicMethod(java.util.Collections.emptyList().getClass(), "isEmpty"));
    }

    @Test
    public void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExist");
            }
        });
    }

    // --- getShortCanonicalName ---

    @Test
    public void testGetShortCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
    }

    @Test
    public void testGetShortCanonicalNameArray() {
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    @Test
    public void testGetShortCanonicalNameObjectNull() {
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
    }

    // --- getShortClassName ---

    @Test
    public void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
    }

    @Test
    public void testGetShortClassNameObjectNull() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
    }

    @Test
    public void testGetShortClassNameStringNullOrEmpty() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    public void testGetShortClassNameInnerClass() {
        assertEquals("ClassUtilsAgentTest.AgentOuter.AgentInner", ClassUtils.getShortClassName(AgentOuter.AgentInner.class.getName()));
    }

    @Test
    public void testGetShortClassNameArrayEncoded() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
    }

    // --- getSimpleName ---

    @Test
    public void testGetSimpleNameClassNull() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObjectNull() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    // --- hierarchy ---

    @Test
    public void testHierarchyExcludeInterfaces() {
        final List<Class<?>> found = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class)) {
            found.add(c);
        }
        assertEquals(3, found.size());
        assertEquals(AgentChild.class, found.get(0));
        assertEquals(AgentSuper.class, found.get(1));
        assertEquals(Object.class, found.get(2));
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> found = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE)) {
            found.add(c);
        }
        assertTrue(found.contains(AgentChild.class));
        assertTrue(found.contains(AgentInterfaceA.class));
        assertTrue(found.contains(AgentInterfaceB.class));
        assertTrue(found.contains(AgentSuper.class));
        assertTrue(found.contains(Object.class));
    }

    // --- isAssignable ---

    @Test
    public void testIsAssignableNullToClass() {
        assertFalse(ClassUtils.isAssignable((Class<?>) null, null));
        assertFalse(ClassUtils.isAssignable(String.class, null));
    }

    @Test
    public void testIsAssignableNullFromClassNonPrimitive() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, String.class));
    }

    @Test
    public void testIsAssignableNullFromClassPrimitive() {
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
    }

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
    }

    @Test
    public void testIsAssignableNoAutoboxing() {
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableSameClass() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
    }

    @Test
    public void testIsAssignableSubclass() {
        assertTrue(ClassUtils.isAssignable(AgentChild.class, AgentSuper.class));
        assertFalse(ClassUtils.isAssignable(AgentSuper.class, AgentChild.class));
    }

    // --- isAssignable(Class[], Class...) ---

    @Test
    public void testIsAssignableArraysDifferentLength() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, String.class}));
    }

    @Test
    public void testIsAssignableArraysNulls() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsAssignableArraysMatch() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {Integer.class, String.class}, new Class<?>[] {int.class, String.class}));
    }

    @Test
    public void testIsAssignableArraysMismatch() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {Integer.class}));
    }

    // --- isInnerClass ---

    @Test
    public void testIsInnerClassNull() {
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    public void testIsInnerClassTopLevel() {
        assertFalse(ClassUtils.isInnerClass(String.class));
    }

    @Test
    public void testIsInnerClassTrue() {
        assertTrue(ClassUtils.isInnerClass(AgentOuter.AgentInner.class));
    }

    // --- isPrimitiveOrWrapper / isPrimitiveWrapper ---

    @Test
    public void testIsPrimitiveOrWrapperNull() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveOrWrapperPrimitive() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
    }

    @Test
    public void testIsPrimitiveOrWrapperWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
    }

    @Test
    public void testIsPrimitiveOrWrapperOther() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapperNull() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapperPrimitive() {
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
    }

    @Test
    public void testIsPrimitiveWrapperWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
    }

    // --- isPublic ---

    @Test
    public void testIsPublicTrue() {
        assertTrue(ClassUtils.isPublic(String.class));
    }

    @Test
    public void testIsPublicFalse() {
        assertFalse(ClassUtils.isPublic(AgentSuper.class));
    }

    @Test
    public void testIsPublicNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    // --- primitiveToWrapper / primitivesToWrappers ---

    @Test
    public void testPrimitiveToWrapperNull() {
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    public void testPrimitiveToWrapperPrimitive() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testPrimitiveToWrapperNonPrimitive() {
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    @Test
    public void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    public void testPrimitivesToWrappersEmpty() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers();
        assertEquals(0, result.length);
    }

    @Test
    public void testPrimitivesToWrappers() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, null}, result);
    }

    // --- toClass ---

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        final Class<?>[] result = ClassUtils.toClass();
        assertEquals(0, result.length);
    }

    @Test
    public void testToClass() {
        final Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertArrayEquals(new Class<?>[] {String.class, Integer.class, null}, result);
    }

    // --- wrapperToPrimitive / wrappersToPrimitives ---

    @Test
    public void testWrapperToPrimitiveNull() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testWrapperToPrimitiveWrapper() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
    }

    @Test
    public void testWrapperToPrimitiveNonWrapper() {
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    public void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    public void testWrappersToPrimitivesEmpty() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives();
        assertEquals(0, result.length);
    }

    @Test
    public void testWrappersToPrimitives() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertArrayEquals(new Class<?>[] {int.class, null, null}, result);
    }

    // --- convertClassesToClassNames / convertClassNamesToClasses ---

    @Test
    public void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("this.does.not.Exist");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    // --- comparator ---

    @Test
    public void testComparator() {
        assertEquals(0, ClassUtils.comparator().compare(String.class, String.class));
        assertTrue(ClassUtils.comparator().compare(Integer.class, String.class) < 0);
    }

    // --- Interfaces enum ---

    @Test
    public void testInterfacesEnumValues() {
        final ClassUtils.Interfaces[] values = ClassUtils.Interfaces.values();
        assertEquals(2, values.length);
        assertEquals(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertEquals(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    // --- public constructor exists (deprecated but present) ---

    @Test
    public void testPublicConstructor() {
        assertNotNull(new ClassUtils());
    }
}
