/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Test {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    private static Token nextToken(final Lexer lexer) throws IOException {
        final Token token = new Token();
        lexer.nextToken(token);
        return token;
    }

    // --- nextToken() basic tokenizing -------------------------------------------------

    @Test
    void testNextTokenSimpleRecord() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b,c\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("b", t2.content.toString());
        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t3.type);
        assertEquals("c", t3.content.toString());
        final Token t4 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t4.type);
        lexer.close();
    }

    @Test
    void testNextTokenEmptyInputIsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testNextTokenLastLineWithoutTrailingNewlineIsReady() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        nextToken(lexer); // "a"
        final Token last = nextToken(lexer);
        assertEquals(Token.Type.EOF, last.type);
        assertTrue(last.isReady);
        assertEquals("b", last.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenCommentLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "# a comment\na,b\n");
        final Token comment = nextToken(lexer);
        assertEquals(Token.Type.COMMENT, comment.type);
        assertEquals("a comment", comment.content.toString());
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "\n\na,b\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenNotIgnoreEmptyLinesProducesEmptyRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "\na\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("", t1.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEmptyLineAtEndOfFileIsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "a\n\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertFalse(t2.isReady);
        lexer.close();
    }

    // --- quoted / encapsulated tokens -------------------------------------------------

    @Test
    void testNextTokenQuotedSimple() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a,b\",c\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a,b", t1.content.toString());
        assertTrue(t1.isQuoted);
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals("c", t2.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenQuotedWithDoubledQuote() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\"b\"\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a\"b", t1.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenEofBeforeClosingQuoteThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a,b");
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                nextToken(lexer);
            }
        });
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenEofBeforeClosingQuoteLenient() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"a,b");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("a,b", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenInvalidCharAfterQuoteThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"b,c\n");
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                nextToken(lexer);
            }
        });
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenTrailingDataAllowsExtraChars() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"a\"b,c\n");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("ab", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenWhitespaceAfterQuoteIsIgnored() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"  ,b\n");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    // --- surrounding spaces -------------------------------------------------

    @Test
    void testNextTokenIgnoreSurroundingSpacesTrimsLeadingAndTrailing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  ,b\n");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals(0, allSpaces.length());
        final StringBuilder noSpaces = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noSpaces);
        assertEquals("abc", noSpaces.toString());
    }

    // --- predicate methods -------------------------------------------------

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    @Test
    void testIsQuoteCharAndIsEscapeAndIsCommentStart() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "");
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('/'));
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart(';'));
    }

    @Test
    void testIsQuoteCharDisabledByDefaultFormatWithoutQuote() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        final Lexer lexer = createLexer(format, "");
        assertFalse(lexer.isQuoteChar('"'));
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, ",x");
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('a'));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharMatches() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        // The first ':' is the "current" char passed in; the reader holds the lookahead chars.
        final Lexer lexer = createLexer(format, ":rest");
        assertTrue(lexer.isDelimiter(':'));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharNoMatchDoesNotConsume() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "arest");
        assertFalse(lexer.isDelimiter(':'));
        // A failed lookahead must not consume input: the whole "arest" should still be there.
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("arest", token.content.toString());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterMatches() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        // isEscapeDelimiter() peeks forward only; the triggering escape char is assumed already consumed.
        final Lexer lexer = createLexer(format, ":!:rest");
        assertTrue(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterNoMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final Lexer lexer = createLexer(format, "abcdef");
        assertFalse(lexer.isEscapeDelimiter());
        lexer.close();
    }

    // --- readEndOfLine / firstEol -------------------------------------------------

    @Test
    void testGetFirstEolInitiallyNull() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\n");
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "x");
        assertTrue(lexer.readEndOfLine(Constants.LF));
        assertEquals("\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineCr() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "x");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineCrLfConsumesLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\na");
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r\n", lexer.getFirstEol());
        // The LF following the CR must have been consumed, so the next unread char is 'a'.
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testReadEndOfLineNotEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "x");
        assertFalse(lexer.readEndOfLine('a'));
        assertNull(lexer.getFirstEol());
        lexer.close();
    }

    // --- readEscape -------------------------------------------------

    @Test
    void testReadEscapeLetterMappings() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "rntbf");
        assertEquals(Constants.CR, lexer.readEscape());
        assertEquals(Constants.LF, lexer.readEscape());
        assertEquals(Constants.TAB, lexer.readEscape());
        assertEquals(Constants.BACKSPACE, lexer.readEscape());
        assertEquals(Constants.FF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeMetaCharReturnsItself() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "\\\"#");
        assertEquals('\\', lexer.readEscape());
        assertEquals('"', lexer.readEscape());
        assertEquals('#', lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeUnexpectedCharReturnsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "z");
        assertEquals(EOF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeAtEndOfStreamThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        lexer.close();
    }

    @Test
    void testNextTokenWithEscapedDelimiterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\,b,c\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a,b", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals("c", t2.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenWithUnexpectedCharAfterEscapeKeepsEscapeAndChar() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\zb,c\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a\\zb", t1.content.toString());
        lexer.close();
    }

    // --- misc accessors -------------------------------------------------

    @Test
    void testGetCurrentLineNumberAndCharacterPositionAdvance() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\nb\n");
        assertEquals(0, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getCharacterPosition());
        nextToken(lexer); // consumes "a\n" -> EORECORD
        assertEquals(1, lexer.getCurrentLineNumber());
        assertTrue(lexer.getCharacterPosition() > 0);
        lexer.close();
    }

    @Test
    void testGetBytesReadWithoutByteTracking() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        // Byte tracking is disabled by the (Reader) constructor used here, so no bytes are counted.
        assertEquals(0, lexer.getBytesRead());
        nextToken(lexer);
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testIsClosedAndClose() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    // --- additional boundary / integration cases -------------------------------------------------

    @Test
    void testNextTokenMultiCharDelimiterIntegration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "a::b::c\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("b", t2.content.toString());
        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t3.type);
        assertEquals("c", t3.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEscapedMultiCharDelimiterIntegration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final Lexer lexer = createLexer(format, "a!:!:b::c\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a::b", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals("c", t2.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenTrailingDelimiterAtEofProducesEmptyLastField() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertTrue(t2.isReady);
        assertEquals("", t2.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenConsecutiveDelimitersProduceEmptyField() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,,b\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("", t2.content.toString());
        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t3.type);
        assertEquals("b", t3.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenAfterEofKeepsReturningEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        assertFalse(t3.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenCommentMarkerNotAtStartOfLineIsLiteral() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "a#b\n");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a#b", token.content.toString());
        lexer.close();
    }

    @Test
    void testParseEncapsulatedTokenWithEscapedQuoteCharacter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "\"a\\\"b\"\n");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a\"b", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEscapeCharacterAtEndOfStreamThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\");
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                nextToken(lexer);
            }
        });
        lexer.close();
    }

    @Test
    void testGetCurrentLineNumberCrLfCountsAsOneLine() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\r\nb\r\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals(1, lexer.getCurrentLineNumber());
        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals(2, lexer.getCurrentLineNumber());
        lexer.close();
    }
}
