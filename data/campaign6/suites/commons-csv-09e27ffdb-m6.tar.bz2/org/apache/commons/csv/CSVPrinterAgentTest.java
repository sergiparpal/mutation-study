/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
public class CSVPrinterAgentTest {

    /** Appendable that records flush/close calls on top of a StringBuilder buffer. */
    private static final class RecordingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private int flushCount;
        private boolean closed;

        @Override
        public Appendable append(final char c) {
            sb.append(c);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq) {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public void close() {
            closed = true;
        }

        @Override
        public void flush() {
            flushCount++;
        }

        int getFlushCount() {
            return flushCount;
        }

        boolean isClosed() {
            return closed;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    /** Appendable whose append() always fails, to verify IOException propagation. */
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }
    }

    @Test
    public void testConstructorNullAppendableThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testConstructorNullFormatThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringWriter(), null);
            }
        });
    }

    @Test
    public void testConstructorPrintsHeaderWhenNotSkipped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        assertEquals("A,B\r\n", writer.toString());
        // The header record printed during construction is counted like any other record.
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testConstructorSkipsHeaderWhenRequested() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").setSkipHeaderRecord(true).get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        assertEquals("", writer.toString());
        printer.close();
    }

    @Test
    public void testConstructorPrintsHeaderComments() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("line1", "line2").get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        assertEquals("# line1\r\n# line2\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testGetOutReturnsSameAppendable() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertSame(writer, printer.getOut());
        printer.close();
    }

    @Test
    public void testPrintSimpleValueNotQuoted() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("simple");
        assertEquals("simple", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintValueContainingDelimiterIsQuoted() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintNullValuePrintsEmpty() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintSecondValueOnLineIsPrecededByDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintPropagatesIoException() {
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVPrinter printer = new CSVPrinter(new ThrowingAppendable(), CSVFormat.DEFAULT);
                printer.print("x");
            }
        });
    }

    @Test
    public void testPrintlnWritesRecordSeparatorAndMarksNewRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a\r\nb", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordVarargsIncrementsCountAndWritesSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
        printer.printRecord("d", "e");
        assertEquals("a,b,c\r\nd,e\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordEmptyVarargsStillWritesSeparatorAndCounts() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordStream() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("p", "q").stream());
        assertEquals("p,q\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsObjectArrayOfSimpleValuesPrintsOneRecordPerValue() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords("a", "b");
        assertEquals("a\r\nb\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsObjectArrayOfArraysPrintsOneRecordPerNestedArray() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "a", "b" }, (Object) new String[] { "1", "2" });
        assertEquals("a,b\r\n1,2\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsIterableOfArraysPrintsMultipleRecords() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsEmptyIterableWritesNothing() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", writer.toString());
        assertEquals(0, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsStream() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data.stream());
        assertEquals("A,B\r\n1,2\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintCommentWithoutMarkerIsNoOp() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printComment("hello");
        assertEquals("", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentNullIsNoOp() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment(null);
        assertEquals("", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentSingleLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentWithEmbeddedNewlinesSplitsIntoMultipleCommentLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printComment("line1\r\nline2\nline3");
        assertEquals("# line1\r\n# line2\r\n# line3\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentAfterValueStartsOnNewLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.print("a");
        printer.printComment("note");
        assertEquals("a\r\n# note\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testFlushDelegatesToFlushableAppendable() throws IOException {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertEquals(0, appendable.getFlushCount());
        printer.flush();
        assertEquals(1, appendable.getFlushCount());
        printer.close();
    }

    @Test
    public void testFlushOnNonFlushableAppendableDoesNotThrow() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.flush();
        printer.close();
    }

    @Test
    public void testCloseWithoutAutoFlushDoesNotFlushButCloses() throws IOException {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
        assertEquals(0, appendable.getFlushCount());
        assertTrue(appendable.isClosed());
    }

    @Test
    public void testCloseWithFlushParamTrueFlushesBeforeClosing() throws IOException {
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(true);
        assertEquals(1, appendable.getFlushCount());
        assertTrue(appendable.isClosed());
    }

    @Test
    public void testCloseHonorsFormatAutoFlush() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final RecordingAppendable appendable = new RecordingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.close();
        assertEquals(1, appendable.getFlushCount());
        assertTrue(appendable.isClosed());
    }

    @Test
    public void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close();
        // No exception; writer content from construction (empty) is preserved.
        assertEquals("", writer.toString());
    }

    @Test
    public void testPrintHeadersFromResultSet() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("ID");
        when(metaData.getColumnLabel(2)).thenReturn("NAME");

        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printHeaders(resultSet);
        assertEquals("ID,NAME\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsFromResultSet() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(resultSet.next()).thenReturn(true, true, false);
        when(resultSet.getObject(1)).thenReturn("1", "2");
        when(resultSet.getObject(2)).thenReturn("john", "mary");

        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords(resultSet);
        assertEquals("1,john\r\n2,mary\r\n", writer.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsFromResultSetRespectsMaxRows() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(resultSet.next()).thenReturn(true, true, false);
        when(resultSet.getObject(1)).thenReturn("row1", "row2");

        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.printRecords(resultSet);
        assertEquals("row1\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsFromResultSetWithHeaderTrue() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("VAL");
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getObject(1)).thenReturn("v1");

        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords(resultSet, true);
        assertEquals("VAL\r\nv1\r\n", writer.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrintRecordsFromResultSetWithHeaderFalseSkipsHeader() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getObject(1)).thenReturn("v1");

        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords(resultSet, false);
        assertEquals("v1\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsFromResultSetWithClobColumnReadsCharacterStream() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        final Clob clob = mock(Clob.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getObject(1)).thenReturn(clob);
        when(clob.getCharacterStream()).thenReturn(new StringReader("clobbed"));

        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.printRecords(resultSet);
        assertEquals("\"clobbed\"\r\n", writer.toString());
        printer.close();
    }

    @Test
    public void testGetRecordCountStartsAtZero() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void testPrinterImplementsFlushableAndCloseable() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertTrue(printer instanceof Flushable);
        assertTrue(printer instanceof Closeable);
        assertNotNull(printer.getOut());
        assertFalse(printer.getOut() == null);
        printer.close();
    }
}
