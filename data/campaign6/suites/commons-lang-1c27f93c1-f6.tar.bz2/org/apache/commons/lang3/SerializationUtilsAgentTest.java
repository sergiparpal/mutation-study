/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InvalidObjectException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link SerializationUtils}.
 */
class SerializationUtilsAgentTest {

    /**
     * Simple serializable fixture with value semantics, used to verify round
     * trips actually reconstruct equivalent (but distinct) data.
     */
    static class Fixture implements Serializable {
        private static final long serialVersionUID = 1L;

        private final int number;
        private final String text;
        private final List<String> items;

        Fixture(final int number, final String text) {
            this.number = number;
            this.text = text;
            this.items = new ArrayList<String>();
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Fixture)) {
                return false;
            }
            final Fixture other = (Fixture) obj;
            return number == other.number && text.equals(other.text) && items.equals(other.items);
        }

        @Override
        public int hashCode() {
            return number;
        }
    }

    /**
     * Serializable wrapper whose field is NOT serializable, used to force a
     * serialization failure.
     */
    static class UnserializableFixture implements Serializable {
        private static final long serialVersionUID = 1L;

        @SuppressWarnings("unused")
        private final Object notSerializable = new Object();
    }

    // ---------------------------------------------------------------
    // clone()
    // ---------------------------------------------------------------

    @Test
    void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    void testCloneProducesEqualButDistinctObject() {
        final Fixture original = new Fixture(42, "hello");
        original.items.add("a");
        final Fixture cloned = SerializationUtils.clone(original);

        assertNotSame(original, cloned);
        assertEquals(original, cloned);
        assertNotSame(original.items, cloned.items);
    }

    @Test
    void testCloneMutationDoesNotAffectOriginal() {
        final Fixture original = new Fixture(1, "x");
        original.items.add("one");
        final Fixture cloned = SerializationUtils.clone(original);

        cloned.items.add("two");

        assertEquals(1, original.items.size());
        assertEquals(2, cloned.items.size());
    }

    @Test
    void testCloneArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = SerializationUtils.clone(original);

        assertNotSame(original, cloned);
        assertArrayEquals(original, cloned);
    }

    @Test
    void testCloneStringIsSameTypeAndValue() {
        final String original = "immutable value";
        final String cloned = SerializationUtils.clone(original);

        assertEquals(original, cloned);
    }

    // ---------------------------------------------------------------
    // serialize(Serializable)
    // ---------------------------------------------------------------

    @Test
    void testSerializeProducesNonEmptyByteArray() {
        final byte[] bytes = SerializationUtils.serialize(new Fixture(7, "abc"));
        assertNotNull(bytes);
        assertTrue(bytes.length > 0);
    }

    @Test
    void testSerializeNullObjectRoundTrips() {
        final byte[] bytes = SerializationUtils.serialize((Serializable) null);
        assertNotNull(bytes);
        final Object result = SerializationUtils.deserialize(bytes);
        assertNull(result);
    }

    @Test
    void testSerializeUnserializableFieldThrowsSerializationException() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new UnserializableFixture());
            }
        });
    }

    // ---------------------------------------------------------------
    // serialize(Serializable, OutputStream)
    // ---------------------------------------------------------------

    @Test
    void testSerializeToStreamNullOutputStreamThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new Fixture(1, "a"), null);
            }
        });
    }

    @Test
    void testSerializeToStreamWritesData() {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(new Fixture(5, "z"), baos);
        assertTrue(baos.toByteArray().length > 0);
    }

    // ---------------------------------------------------------------
    // deserialize(byte[])
    // ---------------------------------------------------------------

    @Test
    void testDeserializeNullByteArrayThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((byte[]) null);
            }
        });
    }

    @Test
    void testDeserializeGarbageBytesThrowsSerializationException() {
        final byte[] garbage = {1, 2, 3, 4, 5};
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(garbage);
            }
        });
    }

    @Test
    void testDeserializeEmptyByteArrayThrowsSerializationException() {
        final byte[] empty = {};
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(empty);
            }
        });
    }

    @Test
    void testSerializeThenDeserializeByteArrayRoundTrip() {
        final Fixture original = new Fixture(99, "round-trip");
        original.items.add("only-item");

        final byte[] bytes = SerializationUtils.serialize(original);
        final Fixture result = SerializationUtils.deserialize(bytes);

        assertNotSame(original, result);
        assertEquals(original, result);
    }

    // ---------------------------------------------------------------
    // deserialize(InputStream)
    // ---------------------------------------------------------------

    @Test
    void testDeserializeNullInputStreamThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((java.io.InputStream) null);
            }
        });
    }

    @Test
    void testDeserializeFromStreamRoundTrip() {
        final Fixture original = new Fixture(3, "stream");
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(original, baos);

        final Fixture result = SerializationUtils.deserialize(new ByteArrayInputStream(baos.toByteArray()));

        assertNotSame(original, result);
        assertEquals(original, result);
    }

    // ---------------------------------------------------------------
    // roundtrip(T)
    // ---------------------------------------------------------------

    @Test
    void testRoundtripProducesEqualButDistinctObject() {
        final Fixture original = new Fixture(123, "roundtrip-method");
        original.items.add("entry");

        final Fixture result = SerializationUtils.roundtrip(original);

        assertNotSame(original, result);
        assertEquals(original, result);
    }

    // ---------------------------------------------------------------
    // requireNonNull(T, String)
    // ---------------------------------------------------------------

    @Test
    void testRequireNonNullReturnsSameReferenceWhenNotNull() throws InvalidObjectException {
        final String value = "not null";
        final String result = SerializationUtils.requireNonNull(value, "should not be used");
        assertSame(value, result);
    }

    @Test
    void testRequireNonNullThrowsWithMessageWhenNull() {
        final InvalidObjectException ex = assertThrows(InvalidObjectException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                SerializationUtils.requireNonNull(null, "field must not be null");
            }
        });
        assertEquals("field must not be null", ex.getMessage());
    }

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------

    @Test
    void testConstructorIsPublicAndUsable() {
        assertNotNull(new SerializationUtils());
    }
}
