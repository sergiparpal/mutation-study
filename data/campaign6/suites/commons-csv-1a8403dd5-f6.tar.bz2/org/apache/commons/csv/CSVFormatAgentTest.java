/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat} and {@link CSVFormat.Builder}.
 */
class CSVFormatAgentTest {

    private enum TestHeaderEnum {
        Name, Email, Phone
    }

    // ---------------------------------------------------------------
    // Builder.create() defaults
    // ---------------------------------------------------------------

    @Test
    void testBuilderCreateDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrim());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').setHeader("a", "b").get();
        final CSVFormat.Builder builder = CSVFormat.Builder.create(source);
        final CSVFormat copy = builder.get();
        assertEquals(source, copy);
        assertNotSame(source, copy);
    }

    // ---------------------------------------------------------------
    // Builder setter validation
    // ---------------------------------------------------------------

    @Test
    void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\r'));
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testSetDelimiterRejectsStringContainingLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\nb"));
    }

    @Test
    void testSetDelimiterMultiCharAccepted() {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("||").get();
        assertEquals("||", format.getDelimiterString());
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker((Character) '\r'));
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\r'));
    }

    @Test
    void testSetQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    @Test
    void testSetDuplicateHeaderModeRejectsNull() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(NullPointerException.class, () -> builder.setDuplicateHeaderMode(null));
    }

    @Test
    void testSetMaxRowsNegativeMeansNoLimit() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(-5).get();
        assertEquals(-5L, format.getMaxRows());
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(1000000L));
    }

    @Test
    void testUseMaxRowsAndUseRow() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    // ---------------------------------------------------------------
    // Header handling
    // ---------------------------------------------------------------

    @Test
    void testSetHeaderCopiesInputArray() {
        final String[] header = {"a", "b"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        header[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderReturnsIndependentCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] gotten = format.getHeader();
        gotten[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testSetHeaderFromEnumValues() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(TestHeaderEnum.class).get();
        final String[] header = format.getHeader();
        assertEquals(3, header.length);
        assertEquals("Name", header[0]);
        assertEquals("Email", header[1]);
        assertEquals("Phone", header[2]);
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("col1");
        when(metaData.getColumnLabel(2)).thenReturn("col2");
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(metaData).get();
        assertEquals(new String[] {"col1", "col2"}.length, format.getHeader().length);
        assertEquals("col1", format.getHeader()[0]);
        assertEquals("col2", format.getHeader()[1]);
    }

    @Test
    void testSetHeaderFromResultSet() throws SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("onlyCol");
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(resultSet).get();
        assertEquals(1, format.getHeader().length);
        assertEquals("onlyCol", format.getHeader()[0]);
    }

    @Test
    void testSetHeaderFromNullResultSetDisablesHeader() throws SQLException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((ResultSet) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testDuplicateHeaderNamesAllowedByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "a").get();
        assertEquals(2, format.getHeader().length);
    }

    @Test
    void testDuplicateHeaderNamesDisallowedThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a");
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowedWhenAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "", "a").get();
        assertEquals(3, format.getHeader().length);
    }

    @Test
    void testDuplicateNonEmptyHeaderNamesDisallowedWhenAllowEmpty() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a");
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testSetHeaderCommentsCopiesArray() {
        final String[] comments = {"c1", "c2"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(comments).get();
        comments[0] = "mutated";
        assertEquals("c1", format.getHeaderComments()[0]);
    }

    @Test
    void testSetHeaderCommentsFromObjectsConvertsToString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(Integer.valueOf(42), null, "text").get();
        final String[] comments = format.getHeaderComments();
        assertEquals("42", comments[0]);
        assertNull(comments[1]);
        assertEquals("text", comments[2]);
    }

    @Test
    void testGetHeaderCommentsReturnsIndependentCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1").get();
        final String[] gotten = format.getHeaderComments();
        gotten[0] = "mutated";
        assertEquals("c1", format.getHeaderComments()[0]);
    }

    // ---------------------------------------------------------------
    // validate()
    // ---------------------------------------------------------------

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';').setQuote(';');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';').setEscape(';');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateCommentMarkerSameAsDelimiterThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';').setCommentMarker(';');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateQuoteSameAsCommentMarkerThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateEscapeSameAsCommentMarkerThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE);
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\n'));
    }

    @Test
    void testNewFormatMinimalFields() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    // ---------------------------------------------------------------
    // equals / hashCode / toString
    // ---------------------------------------------------------------

    @Test
    void testEqualsReflexiveAndDifferentTypes() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(CSVFormat.DEFAULT, "not a format");
        assertNotEquals(CSVFormat.DEFAULT, null);
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDetectsDifference() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(a, b);
    }

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringContainsHeaderWhenSet() {
        final String str = CSVFormat.DEFAULT.builder().setHeader("a", "b").get().toString();
        assertTrue(str.contains("Header:"));
        assertTrue(str.contains("a"));
    }

    // ---------------------------------------------------------------
    // copy() / builder()
    // ---------------------------------------------------------------

    @Test
    void testBuilderMutationAfterGetDoesNotAffectPriorFormat() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat first = builder.get();
        builder.setDelimiter(';');
        final CSVFormat second = builder.get();
        assertEquals(",", first.getDelimiterString());
        assertEquals(";", second.getDelimiterString());
    }

    @Test
    void testBuilderThenGetProducesEqualButDistinctFormat() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat copy = builder.get();
        assertEquals(CSVFormat.DEFAULT, copy);
        assertNotSame(CSVFormat.DEFAULT, copy);
    }

    // ---------------------------------------------------------------
    // deprecated get/with methods delegate correctly
    // ---------------------------------------------------------------

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testWithDelimiterProducesNewFormat() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', format.getDelimiter());
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testWithHeaderDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("x", "y");
        assertEquals(2, format.getHeader().length);
    }

    @Test
    void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testWithAllowDuplicateHeaderNamesFalseMapsToAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
    }

    @Test
    void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.getTrim());
    }

    @Test
    void testWithRecordSeparatorRejectsInvalidString() {
        // Javadoc on CSVFormat#withRecordSeparator(String) documents that an IllegalArgumentException
        // is thrown if recordSeparator is none of CR, LF or CRLF.
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.withRecordSeparator("xyz"));
    }

    @Test
    void testWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    // ---------------------------------------------------------------
    // format(Object...) / print / printRecord / println
    // ---------------------------------------------------------------

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b");
        assertEquals("a,b\r\n", writer.toString());
    }

    @Test
    void testPrintSingleValueNoQuotingNeeded() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintSecondValuePrependsDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, false);
        assertEquals(",hello", writer.toString());
    }

    @Test
    void testPrintNullValueWithoutNullStringIsEmpty() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueWithNullStringSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintNullValueWithNullStringAndQuoteModeAllRoundTrips() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        final String printed = writer.toString();
        try (CSVParser parser = CSVFormat.DEFAULT.builder().setNullString("NULL").get().parse(new java.io.StringReader(printed))) {
            final CSVRecord record = parser.iterator().next();
            assertNull(record.get(0), "Printed value should parse back to null, but was [" + printed + "]");
        }
    }

    @Test
    void testPrintTrimsValueWhenTrimSet() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).setQuote((Character) null).get();
        final StringWriter writer = new StringWriter();
        format.print("  hello  ", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintlnWritesRecordSeparatorOnly() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterThenSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testQuoteModeNoneEscapesDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        final StringWriter writer = new StringWriter();
        format.print("a,b", writer, true);
        assertEquals("a\\,b", writer.toString());
    }

    @Test
    void testQuoteModeAllQuotesEverything() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.ALL).get();
        final StringWriter writer = new StringWriter();
        format.print("simple", writer, true);
        assertEquals("\"simple\"", writer.toString());
    }

    @Test
    void testQuoteModeNonNumericQuotesStrings() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NON_NUMERIC).get();
        final StringWriter numberWriter = new StringWriter();
        format.print(Integer.valueOf(5), numberWriter, true);
        assertEquals("5", numberWriter.toString());
        final StringWriter stringWriter = new StringWriter();
        format.print("text", stringWriter, true);
        assertEquals("\"text\"", stringWriter.toString());
    }

    @Test
    void testPrintEscapesEmbeddedQuoteCharacter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("a\"b", writer, true);
        assertEquals("\"a\"\"b\"", writer.toString());
    }

    // ---------------------------------------------------------------
    // isXxxSet() accessors
    // ---------------------------------------------------------------

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertTrue(CSVFormat.DEFAULT.builder().setCommentMarker('#').get().isCommentMarkerSet());
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertTrue(CSVFormat.DEFAULT.builder().setEscape('\\').get().isEscapeCharacterSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.builder().setQuote((Character) null).get().isQuoteCharacterSet());
    }

    // ---------------------------------------------------------------
    // valueOf / Predefined
    // ---------------------------------------------------------------

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.Predefined.Excel.getFormat(), CSVFormat.EXCEL);
    }

    @Test
    void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NotARealFormat"));
    }

    // ---------------------------------------------------------------
    // parse/print integration smoke test
    // ---------------------------------------------------------------

    @Test
    void testMultiCharDelimiterValueEndingInDelimiterPrefixRoundTrips() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        final String formatted = format.format("a|", "b");
        try (CSVParser parser = format.parse(new java.io.StringReader(formatted))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a|", record.get(0), "Round trip failed for formatted string [" + formatted + "]");
            assertEquals("b", record.get(1));
        }
    }

    @Test
    void testParseRoundTripsFormattedRecord() throws IOException {
        final String formatted = CSVFormat.DEFAULT.format("a", "b,c", "d\"e");
        try (CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader(formatted))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertEquals("b,c", record.get(1));
            assertEquals("d\"e", record.get(2));
        }
    }
}
