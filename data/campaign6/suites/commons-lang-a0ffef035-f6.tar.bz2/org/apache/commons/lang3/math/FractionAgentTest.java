/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Fraction}.
 */
class FractionAgentTest {

    // ---- getFraction(int, int) ----

    @Test
    void testGetFractionTwoArgsBasic() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testGetFractionTwoArgsNegativeDenominatorNormalized() {
        final Fraction f = Fraction.getFraction(3, -4);
        assertEquals(-3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testGetFractionTwoArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(3, 0);
            }
        });
    }

    @Test
    void testGetFractionTwoArgsMinValueNumeratorNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    void testGetFractionTwoArgsMinValueDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(5, Integer.MIN_VALUE);
            }
        });
    }

    @Test
    void testGetFractionTwoArgsNotReduced() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
        assertEquals("2/4", f.toString());
    }

    // ---- getFraction(int, int, int) ----

    @Test
    void testGetFractionThreeArgsBasic() {
        final Fraction f = Fraction.getFraction(1, 1, 2);
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionThreeArgsNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 1, 2);
        assertEquals(-3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionThreeArgsNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(0, 0, -1);
            }
        });
    }

    @Test
    void testGetFractionThreeArgsNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    void testGetFractionThreeArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0, 0);
            }
        });
    }

    @Test
    void testGetFractionThreeArgsOverflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 1);
            }
        });
    }

    // ---- getFraction(double) ----

    @Test
    void testGetFractionDoubleZero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    void testGetFractionDoubleOne() {
        final Fraction f = Fraction.getFraction(1.0d);
        assertEquals(1, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    void testGetFractionDoubleHalf() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionDoubleTwoAndHalf() {
        final Fraction f = Fraction.getFraction(2.5d);
        assertEquals(5, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionDoubleNegativeHalf() {
        final Fraction f = Fraction.getFraction(-0.5d);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(((double) Integer.MAX_VALUE) + 10.0d);
            }
        });
    }

    // ---- getFraction(String) ----

    @Test
    void testGetFractionStringSimpleFraction() {
        final Fraction f = Fraction.getFraction("1/3");
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    void testGetFractionStringWholeAndFraction() {
        final Fraction f = Fraction.getFraction("1 1/2");
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionStringDecimal() {
        final Fraction f = Fraction.getFraction("1.5");
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetFractionStringWholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    void testGetFractionStringNoSlashThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 2");
            }
        });
    }

    @Test
    void testGetFractionStringGarbageThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("not a fraction");
            }
        });
    }

    // ---- getReducedFraction(int, int) ----

    @Test
    void testGetReducedFractionBasic() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetReducedFractionZeroNumerator() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertEquals(Fraction.ZERO, f);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetReducedFractionMinValueDenominatorEvenNumerator() {
        final Fraction f = Fraction.getReducedFraction(4, Integer.MIN_VALUE);
        assertEquals(-1, f.getNumerator());
        assertEquals(536870912, f.getDenominator());
    }

    @Test
    void testGetReducedFractionMinValueDenominatorOddNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(3, Integer.MIN_VALUE);
            }
        });
    }

    @Test
    void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ---- abs() ----

    @Test
    void testAbsOnNegative() {
        final Fraction f = Fraction.getFraction(-3, 4).abs();
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testAbsOnPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.abs());
    }

    // ---- add() ----

    @Test
    void testAdd() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    void testAddNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.add(null);
            }
        });
    }

    @Test
    void testAddIdentity() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertEquals(f, Fraction.ZERO.add(f));
        assertEquals(f, f.add(Fraction.ZERO));
    }

    // ---- subtract() ----

    @Test
    void testSubtract() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 3));
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    void testSubtractNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.subtract(null);
            }
        });
    }

    // ---- multiplyBy() ----

    @Test
    void testMultiplyByReducesResult() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    void testMultiplyByZero() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.ZERO);
        assertEquals(Fraction.ZERO, result);
    }

    @Test
    void testMultiplyByNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.multiplyBy(null);
            }
        });
    }

    // ---- divideBy() ----

    @Test
    void testDivideBy() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 4));
        assertEquals(2, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    void testDivideByZeroThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    void testDivideByNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.divideBy(null);
            }
        });
    }

    // ---- compareTo() ----

    @Test
    void testCompareToLessGreaterEqual() {
        final Fraction oneHalf = Fraction.getFraction(1, 2);
        final Fraction oneThird = Fraction.getFraction(1, 3);
        assertTrue(oneThird.compareTo(oneHalf) < 0);
        assertTrue(oneHalf.compareTo(oneThird) > 0);
        assertEquals(0, oneHalf.compareTo(oneHalf));
    }

    @Test
    void testCompareToEqualValueDifferentRepresentation() {
        final Fraction oneHalf = Fraction.getFraction(1, 2);
        final Fraction twoQuarters = Fraction.getFraction(2, 4);
        assertEquals(0, oneHalf.compareTo(twoQuarters));
        assertFalse(oneHalf.equals(twoQuarters));
    }

    @Test
    void testCompareToNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.compareTo(null);
            }
        });
    }

    // ---- numeric conversions ----

    @Test
    void testDoubleValue() {
        assertEquals(1.5d, Fraction.getFraction(3, 2).doubleValue(), 0.0d);
    }

    @Test
    void testFloatValue() {
        assertEquals(1.5f, Fraction.getFraction(3, 2).floatValue(), 0.0f);
    }

    @Test
    void testIntValueTruncatesTowardZero() {
        assertEquals(1, Fraction.getFraction(3, 2).intValue());
        assertEquals(-1, Fraction.getFraction(-3, 2).intValue());
    }

    @Test
    void testLongValueTruncatesTowardZero() {
        assertEquals(1L, Fraction.getFraction(3, 2).longValue());
        assertEquals(-1L, Fraction.getFraction(-3, 2).longValue());
    }

    // ---- equals() / hashCode() ----

    @Test
    void testEqualsSameValueSameRepresentation() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
    }

    @Test
    void testEqualsDifferentRepresentationNotEqual() {
        assertFalse(Fraction.getFraction(1, 2).equals(Fraction.getFraction(2, 4)));
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertFalse(f.equals(null));
        assertFalse(f.equals("1/2"));
    }

    @Test
    void testHashCodeConsistentForEqualFractions() {
        assertEquals(Fraction.getFraction(1, 2).hashCode(), Fraction.getFraction(1, 2).hashCode());
    }

    // ---- getProperNumerator() / getProperWhole() ----

    @Test
    void testGetProperNumeratorAndWholePositive() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    void testGetProperNumeratorAndWholeNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    void testGetProperNumeratorWhenExact() {
        final Fraction f = Fraction.getFraction(4, 4);
        assertEquals(0, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    // ---- invert() ----

    @Test
    void testInvertPositive() {
        final Fraction f = Fraction.getFraction(3, 4).invert();
        assertEquals(4, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-3, 4).invert();
        assertEquals(-4, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    // ---- negate() ----

    @Test
    void testNegate() {
        final Fraction f = Fraction.getFraction(3, 4).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testNegateMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    // ---- pow() ----

    @Test
    void testPowOneReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    void testPowZeroReturnsOneEvenForZero() {
        assertSame(Fraction.ONE, Fraction.getFraction(2, 3).pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3).pow(2);
        assertEquals(4, f.getNumerator());
        assertEquals(9, f.getDenominator());
    }

    @Test
    void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-2);
        assertEquals(9, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testPowZeroBaseWithPositivePower() {
        assertEquals(Fraction.ZERO, Fraction.ZERO.pow(3));
    }

    @Test
    void testPowZeroBaseWithNegativePowerThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.pow(-1);
            }
        });
    }

    // ---- reduce() ----

    @Test
    void testReduceNonTrivial() {
        final Fraction f = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.reduce());
    }

    @Test
    void testReduceZeroNumeratorNonCanonicalReturnsZero() {
        final Fraction f = Fraction.getFraction(0, 5);
        final Fraction reduced = f.reduce();
        assertEquals(Fraction.ZERO, reduced);
        assertEquals(1, reduced.getDenominator());
    }

    // ---- toString() / toProperString() ----

    @Test
    void testToString() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
        assertEquals("-3/4", Fraction.getFraction(-3, 4).toString());
        assertEquals("0/1", Fraction.ZERO.toString());
    }

    @Test
    void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    void testToProperStringWholeOne() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    void testToProperStringWholeMinusOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    void testToProperStringProperFractionOnly() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    @Test
    void testToProperStringImproperPositive() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    void testToProperStringImproperNegative() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    void testConstantsHaveExpectedValues() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    @Test
    void testGetFractionTwoArgsNotNullSanityCheck() {
        assertNotNull(Fraction.getFraction(1, 1));
    }
}
