/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface Tagged {
        // marker annotation
    }

    public interface Greeter {
        String greet(String name);
    }

    // Package-private class implementing a public interface: exercises the
    // "accessible method on default-access class" workaround.
    static class PackagePrivateGreeterImpl implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hi, " + name;
        }
    }

    public static class Calculator {
        public int add(final int a, final int b) {
            return a + b;
        }

        public static int multiply(final int a, final int b) {
            return a * b;
        }

        private int privateAdd(final int a, final int b) {
            return a + b + 1000;
        }

        public int sum(final int... nums) {
            int total = 0;
            for (final int n : nums) {
                total += n;
            }
            return total;
        }

        public String concat(final String sep, final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    sb.append(sep);
                }
                sb.append(parts[i]);
            }
            return sb.toString();
        }
    }

    public interface IfaceA {
        void foo(CharSequence c);
    }

    public interface IfaceB {
        void foo(CharSequence c);
    }

    abstract static class AmbiguousImpl implements IfaceA, IfaceB {
        // deliberately does not override foo(), to create an ambiguous match
    }

    static class SameClassOverloadAmbiguity {
        void bar(final CharSequence a, final Object b) {
            // no-op
        }

        void bar(final Object a, final CharSequence b) {
            // no-op
        }
    }

    static class AnnotatedBase {
        @Tagged
        public void baseTagged() {
            // no-op
        }

        public void baseUntagged() {
            // no-op
        }
    }

    static class AnnotatedChild extends AnnotatedBase {
        @Override
        public void baseTagged() {
            // overridden without re-annotating
        }

        @Tagged
        private void childPrivateTagged() {
            // no-op
        }
    }

    public interface Shape {
        void draw();
    }

    public static class BaseShape implements Shape {
        @Override
        public void draw() {
            // no-op
        }
    }

    public static class SubShape extends BaseShape {
        @Override
        public void draw() {
            // no-op
        }
    }

    // --- getAccessibleMethod ---

    @Test
    public void testGetAccessibleMethod_null() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethod_noSuchMethod() throws Exception {
        assertNull(MethodUtils.getAccessibleMethod(Calculator.class, "noSuchMethod"));
    }

    @Test
    public void testGetAccessibleMethod_publicClassReturnsSameMethod() throws Exception {
        final Method m = Calculator.class.getMethod("add", int.class, int.class);
        final Method accessible = MethodUtils.getAccessibleMethod(m);
        assertEquals(m, accessible);
    }

    @Test
    public void testGetAccessibleMethod_defaultAccessClassUsesInterfaceMethod() throws Exception {
        assertFalse(Modifier.isPublic(PackagePrivateGreeterImpl.class.getModifiers()));
        final Method declared = PackagePrivateGreeterImpl.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateGreeterImpl.class, declared);
        assertNotNull(accessible);
        assertEquals(Greeter.class, accessible.getDeclaringClass());
        final PackagePrivateGreeterImpl instance = new PackagePrivateGreeterImpl();
        assertEquals("Hi, World", accessible.invoke(instance, "World"));
    }

    @Test
    public void testGetAccessibleMethod_byNameAndParams() {
        final Method m = MethodUtils.getAccessibleMethod(Calculator.class, "add", int.class, int.class);
        assertNotNull(m);
        assertEquals("add", m.getName());
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    public void testGetMatchingAccessibleMethod_primitiveWrapperMatch() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Calculator.class, "add", Integer.class, Integer.class);
        assertNotNull(m);
        assertEquals(int.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethod_noMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Calculator.class, "noSuchMethod", int.class));
    }

    @Test
    public void testGetMatchingAccessibleMethod_defaultAccessClass() throws Exception {
        final Method m = MethodUtils.getMatchingAccessibleMethod(PackagePrivateGreeterImpl.class, "greet", String.class);
        assertNotNull(m);
        assertTrue(m.isAccessible());
        assertEquals("Hi, World", m.invoke(new PackagePrivateGreeterImpl(), "World"));
    }

    // --- getMatchingMethod ---

    @Test
    public void testGetMatchingMethod_nullClass() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "add", int.class, int.class));
    }

    @Test
    public void testGetMatchingMethod_nullMethodName() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(Calculator.class, null, int.class));
    }

    @Test
    public void testGetMatchingMethod_emptyMethodName() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(Calculator.class, "", int.class));
    }

    @Test
    public void testGetMatchingMethod_exactMatch() {
        final Method m = MethodUtils.getMatchingMethod(Calculator.class, "add", int.class, int.class);
        assertNotNull(m);
        assertEquals("add", m.getName());
    }

    @Test
    public void testGetMatchingMethod_noMatch() {
        assertNull(MethodUtils.getMatchingMethod(Calculator.class, "add", String.class, String.class));
    }

    @Test
    public void testGetMatchingMethod_diamondInterfaceAmbiguityThrowsIllegalState() {
        // Per the javadoc, getMatchingMethod() "@throws IllegalStateException if there is no
        // unique result." Here IfaceA.foo(CharSequence) and IfaceB.foo(CharSequence) are two
        // equally-specific, equally-distant candidates with no way to pick a unique winner,
        // so this should throw rather than silently returning an arbitrary one of them.
        assertThrows(IllegalStateException.class, () -> MethodUtils.getMatchingMethod(AmbiguousImpl.class, "foo", String.class));
    }

    @Test
    public void testGetMatchingMethod_sameClassOverloadAmbiguityThrowsIllegalState() {
        assertThrows(IllegalStateException.class,
                () -> MethodUtils.getMatchingMethod(SameClassOverloadAmbiguity.class, "bar", String.class, String.class));
    }

    // --- getMethodObject ---

    @Test
    public void testGetMethodObject_found() {
        final Method m = MethodUtils.getMethodObject(Calculator.class, "add", int.class, int.class);
        assertNotNull(m);
    }

    @Test
    public void testGetMethodObject_notFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Calculator.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObject_nullClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "add", int.class, int.class));
    }

    @Test
    public void testGetMethodObject_nullNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Calculator.class, null));
    }

    // --- getMethodsWithAnnotation / getMethodsListWithAnnotation ---

    @Test
    public void testGetMethodsWithAnnotation_directOnly() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AnnotatedBase.class, Tagged.class);
        assertEquals(1, methods.length);
        assertEquals("baseTagged", methods[0].getName());
    }

    @Test
    public void testGetMethodsListWithAnnotation_overriddenLosesAnnotation() {
        // AnnotatedChild overrides baseTagged() without re-annotating it, and getMethods()
        // returns the child's (unannotated) Method object, so a non-searchSupers,
        // non-ignoreAccess lookup should find nothing.
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AnnotatedChild.class, Tagged.class, false, false);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotation_searchSupersAndIgnoreAccess() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AnnotatedChild.class, Tagged.class, true, true);
        assertEquals(2, methods.size());
    }

    @Test
    public void testGetMethodsWithAnnotation_nullClassThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsWithAnnotation(null, Tagged.class));
    }

    @Test
    public void testGetMethodsWithAnnotation_nullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsWithAnnotation(AnnotatedBase.class, null));
    }

    // --- getAnnotation ---

    @Test
    public void testGetAnnotation_directlyPresent() throws Exception {
        final Method m = AnnotatedBase.class.getMethod("baseTagged");
        final Annotation a = MethodUtils.getAnnotation(m, Tagged.class, false, false);
        assertNotNull(a);
    }

    @Test
    public void testGetAnnotation_searchSupersFindsOverriddenAnnotation() throws Exception {
        final Method m = AnnotatedChild.class.getMethod("baseTagged");
        assertNull(m.getAnnotation(Tagged.class));
        final Annotation found = MethodUtils.getAnnotation(m, Tagged.class, true, false);
        assertNotNull(found);
    }

    @Test
    public void testGetAnnotation_withoutSearchSupersReturnsNull() throws Exception {
        final Method m = AnnotatedChild.class.getMethod("baseTagged");
        assertNull(MethodUtils.getAnnotation(m, Tagged.class, false, false));
    }

    @Test
    public void testGetAnnotation_nullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, Tagged.class, false, false));
    }

    // --- getOverrideHierarchy ---

    @Test
    public void testGetOverrideHierarchy_includeInterfaces() throws Exception {
        final Method m = SubShape.class.getMethod("draw");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.INCLUDE);
        assertEquals(3, hierarchy.size());
        final Method[] inOrder = hierarchy.toArray(new Method[0]);
        assertEquals(SubShape.class, inOrder[0].getDeclaringClass());
        assertEquals(BaseShape.class, inOrder[1].getDeclaringClass());
        assertEquals(Shape.class, inOrder[2].getDeclaringClass());
    }

    @Test
    public void testGetOverrideHierarchy_excludeInterfaces() throws Exception {
        final Method m = SubShape.class.getMethod("draw");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchy_nullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE));
    }

    // --- invokeMethod ---

    @Test
    public void testInvokeMethod_simple() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Calculator(), "add", 1, 2);
        assertEquals(3, result);
    }

    @Test
    public void testInvokeMethod_varArgsMultiple() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Calculator(), "sum", 1, 2, 3);
        assertEquals(6, result);
    }

    @Test
    public void testInvokeMethod_varArgsEmpty() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Calculator(), "sum");
        assertEquals(0, result);
    }

    @Test
    public void testInvokeMethod_leadingArgPlusVarArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Calculator(), "concat", "-", "a", "b", "c");
        assertEquals("a-b-c", result);
    }

    @Test
    public void testInvokeMethod_noSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(new Calculator(), "doesNotExist"));
    }

    @Test
    public void testInvokeMethod_nullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "add", 1, 2));
    }

    @Test
    public void testInvokeMethod_forceAccessTrueCallsPrivate() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Calculator(), true, "privateAdd", 2, 3);
        assertEquals(1005, result);
    }

    @Test
    public void testInvokeMethod_forceAccessFalseCannotCallPrivate() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(new Calculator(), false, "privateAdd", 2, 3));
    }

    // --- invokeExactMethod ---

    @Test
    public void testInvokeExactMethod_exactParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Calculator(), "add", new Object[] { 1, 2 }, new Class[] { int.class, int.class });
        assertEquals(3, result);
    }

    @Test
    public void testInvokeExactMethod_wrapperTypesDoNotMatchPrimitiveSignature() {
        // invokeExactMethod requires an exact signature match; Integer != int, so no
        // accessible method should be found and a NoSuchMethodException thrown.
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(new Calculator(), "add", 1, 2));
    }

    @Test
    public void testInvokeExactMethod_nullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeExactMethod(null, "add"));
    }

    // --- invokeStaticMethod / invokeExactStaticMethod ---

    @Test
    public void testInvokeStaticMethod_simple() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Calculator.class, "multiply", 3, 4);
        assertEquals(12, result);
    }

    @Test
    public void testInvokeStaticMethod_noSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(Calculator.class, "doesNotExist"));
    }

    @Test
    public void testInvokeExactStaticMethod_exactParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Calculator.class, "multiply", new Object[] { 3, 4 }, new Class[] { int.class, int.class });
        assertEquals(12, result);
    }

    @Test
    public void testInvokeExactStaticMethod_wrapperTypesDoNotMatch() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactStaticMethod(Calculator.class, "multiply", 3, 4));
    }

    // --- exception propagation from the invoked method itself ---

    public static class Thrower {
        public void explode() {
            throw new IllegalStateException("boom");
        }
    }

    @Test
    public void testInvokeMethod_wrapsTargetException() {
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class,
                () -> MethodUtils.invokeMethod(new Thrower(), "explode"));
        assertTrue(ex.getCause() instanceof IllegalStateException);
        assertEquals("boom", ex.getCause().getMessage());
    }
}
