/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    private static final int INITIAL = 17;

    private static final int CONSTANT = 37;

    static class Fixture {
        @SuppressWarnings("unused")
        private final int a;
        @SuppressWarnings("unused")
        private final int b;

        Fixture(final int a, final int b) {
            this.a = a;
            this.b = b;
        }
    }

    static class FixtureExclude {
        @HashCodeExclude
        @SuppressWarnings("unused")
        private final int excluded;
        @SuppressWarnings("unused")
        private final int included;

        FixtureExclude(final int excluded, final int included) {
            this.excluded = excluded;
            this.included = included;
        }
    }

    static class FixtureSub extends Fixture {
        @SuppressWarnings("unused")
        private final int c;

        FixtureSub(final int a, final int b, final int c) {
            super(a, b);
            this.c = c;
        }
    }

    static class CycleA {
        CycleB b;

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }
    }

    static class CycleB {
        CycleA a;

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }
    }

    @Test
    void testDefaultConstructor() {
        final HashCodeBuilder hcb = new HashCodeBuilder();
        assertEquals(INITIAL, hcb.toHashCode());
        hcb.append(0);
        assertEquals(INITIAL * CONSTANT, hcb.toHashCode());
    }

    @Test
    void testConstructorRejectsEvenInitial() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(2, 3);
            }
        });
    }

    @Test
    void testConstructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(3, 2);
            }
        });
    }

    @Test
    void testConstructorRejectsZero() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(0, 0);
            }
        });
    }

    @Test
    void testConstructorRejectsNegativeEven() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(-2, -2);
            }
        });
    }

    @Test
    void testAppendBoolean() {
        assertEquals(INITIAL * CONSTANT + 0, new HashCodeBuilder(INITIAL, CONSTANT).append(true).toHashCode());
        assertEquals(INITIAL * CONSTANT + 1, new HashCodeBuilder(INITIAL, CONSTANT).append(false).toHashCode());
    }

    @Test
    void testAppendBooleanArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((boolean[]) null).toHashCode());
    }

    @Test
    void testAppendBooleanArray() {
        final boolean[] arr = {true, false};
        final int expected = (INITIAL * CONSTANT + 0) * CONSTANT + 1;
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(arr).toHashCode());
    }

    @Test
    void testAppendByte() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((byte) 0).toHashCode());
        assertEquals(INITIAL * CONSTANT + 123, new HashCodeBuilder(INITIAL, CONSTANT).append((byte) 123).toHashCode());
    }

    @Test
    void testAppendByteArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((byte[]) null).toHashCode());
    }

    @Test
    void testAppendByteArray() {
        final byte[] arr = {5, 6};
        final int expected = (INITIAL * CONSTANT + 5) * CONSTANT + 6;
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(arr).toHashCode());
    }

    @Test
    void testAppendChar() {
        assertEquals(INITIAL * CONSTANT + 1234, new HashCodeBuilder(INITIAL, CONSTANT).append((char) 1234).toHashCode());
    }

    @Test
    void testAppendCharArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((char[]) null).toHashCode());
    }

    @Test
    void testAppendDouble() {
        final double d = 1234567.89;
        final long l = Double.doubleToLongBits(d);
        final int expected = INITIAL * CONSTANT + (int) (l ^ l >> 32);
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(d).toHashCode());
    }

    @Test
    void testAppendDoubleArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((double[]) null).toHashCode());
    }

    @Test
    void testAppendFloat() {
        final float f = 1234.89f;
        final int expected = INITIAL * CONSTANT + Float.floatToIntBits(f);
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(f).toHashCode());
    }

    @Test
    void testAppendFloatArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((float[]) null).toHashCode());
    }

    @Test
    void testAppendInt() {
        assertEquals(INITIAL * CONSTANT + 123456, new HashCodeBuilder(INITIAL, CONSTANT).append(123456).toHashCode());
    }

    @Test
    void testAppendIntArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((int[]) null).toHashCode());
    }

    @Test
    void testAppendIntArray() {
        final int[] arr = {5, 6};
        final int expected = (INITIAL * CONSTANT + 5) * CONSTANT + 6;
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(arr).toHashCode());
    }

    @Test
    void testAppendLong() {
        final long value = 123456789L;
        final int expected = INITIAL * CONSTANT + (int) (value ^ value >> 32);
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(value).toHashCode());
    }

    @Test
    void testAppendLongArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((long[]) null).toHashCode());
    }

    @Test
    void testAppendShort() {
        assertEquals(INITIAL * CONSTANT + 12345, new HashCodeBuilder(INITIAL, CONSTANT).append((short) 12345).toHashCode());
    }

    @Test
    void testAppendShortArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((short[]) null).toHashCode());
    }

    @Test
    void testAppendObjectNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((Object) null).toHashCode());
    }

    @Test
    void testAppendObject() {
        final Object obj = new Object();
        assertEquals(INITIAL * CONSTANT + obj.hashCode(), new HashCodeBuilder(INITIAL, CONSTANT).append(obj).toHashCode());
    }

    @Test
    void testAppendObjectArrayViaObjectOverload() {
        final int[] primitiveArray = {5, 6};
        final int expected = (INITIAL * CONSTANT + 5) * CONSTANT + 6;
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append((Object) primitiveArray).toHashCode());
    }

    @Test
    void testAppendObjectArrayNull() {
        assertEquals(INITIAL * CONSTANT, new HashCodeBuilder(INITIAL, CONSTANT).append((Object[]) null).toHashCode());
    }

    @Test
    void testAppendObjectArray() {
        final Object a = new Object();
        final Object b = new Object();
        final Object[] arr = {a, b};
        final int expected = (INITIAL * CONSTANT + a.hashCode()) * CONSTANT + b.hashCode();
        assertEquals(expected, new HashCodeBuilder(INITIAL, CONSTANT).append(arr).toHashCode());
    }

    @Test
    void testAppendSuper() {
        final int superCode = 999;
        assertEquals(INITIAL * CONSTANT + superCode, new HashCodeBuilder(INITIAL, CONSTANT).appendSuper(superCode).toHashCode());
    }

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder hcb = new HashCodeBuilder(INITIAL, CONSTANT).append(42);
        final Integer built = hcb.build();
        assertNotNull(built);
        assertEquals(hcb.toHashCode(), built.intValue());
    }

    @Test
    void testHashCodeMatchesToHashCode() {
        final HashCodeBuilder hcb = new HashCodeBuilder(INITIAL, CONSTANT).append(new Object()).append('a');
        assertEquals(hcb.toHashCode(), hcb.hashCode());
    }

    @Test
    void testEqualsContract() {
        final HashCodeBuilder hcb1 = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append('a');
        final HashCodeBuilder hcb2 = new HashCodeBuilder(INITIAL, CONSTANT).append(1).append('a');
        final HashCodeBuilder hcb3 = new HashCodeBuilder(INITIAL, CONSTANT).append(2).append('c');

        assertTrue(hcb1.equals(hcb1));
        assertTrue(hcb1.equals(hcb2));
        assertTrue(hcb2.equals(hcb1));
        assertFalse(hcb1.equals(hcb3));
        assertFalse(hcb2.equals(hcb3));
        assertFalse(hcb1.equals(null));
        assertFalse(hcb1.equals("not a HashCodeBuilder"));
    }

    @Test
    void testBuilderStaticFactory() {
        final HashCodeBuilder.Builder builder = HashCodeBuilder.builder();
        assertNotNull(builder);
        final HashCodeBuilder.Builder sameBuilder = builder.setInitialOddNumber(INITIAL).setMultiplierOddNumber(CONSTANT);
        assertSame(builder, sameBuilder);
        final HashCodeBuilder hcb = builder.get();
        assertEquals(INITIAL, hcb.toHashCode());
        hcb.append(0);
        assertEquals(INITIAL * CONSTANT, hcb.toHashCode());
    }

    @Test
    void testBuilderRejectsEvenValues() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.builder().setInitialOddNumber(2).setMultiplierOddNumber(3).get();
            }
        });
    }

    @Test
    void testReflectionHashCodeBasic() {
        final Fixture f1 = new Fixture(1, 2);
        final Fixture f2 = new Fixture(1, 2);
        final Fixture f3 = new Fixture(3, 4);
        assertEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f2));
        assertNotEquals(HashCodeBuilder.reflectionHashCode(f1), HashCodeBuilder.reflectionHashCode(f3));
    }

    @Test
    void testReflectionHashCodeNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(13, 19, null, true);
            }
        });
    }

    @Test
    void testReflectionHashCodeEvenNumbersThrow() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(2, 2, new Fixture(1, 2), true);
            }
        });
    }

    @Test
    void testReflectionHashCodeExcludeAnnotation() {
        final FixtureExclude x = new FixtureExclude(100, 5);
        final FixtureExclude y = new FixtureExclude(999, 5);
        assertEquals(HashCodeBuilder.reflectionHashCode(x), HashCodeBuilder.reflectionHashCode(y));
    }

    @Test
    void testReflectionHashCodeExcludeFieldsByName() {
        final Fixture x = new Fixture(1, 2);
        final int fullHash = HashCodeBuilder.reflectionHashCode(x);
        final int excludeAHash = HashCodeBuilder.reflectionHashCode(x, "a");
        final int excludeBothHash = HashCodeBuilder.reflectionHashCode(x, "a", "b");
        assertNotEquals(fullHash, excludeAHash);
        assertEquals(INITIAL, excludeBothHash);
    }

    @Test
    void testReflectionHashCodeIncludesSuperclassFields() {
        final FixtureSub withoutTransient = new FixtureSub(1, 2, 3);
        final int subHash = HashCodeBuilder.reflectionHashCode(withoutTransient);
        final int fixtureOnlyHash = HashCodeBuilder.reflectionHashCode(new Fixture(1, 2));
        assertNotEquals(subHash, fixtureOnlyHash);
    }

    @Test
    void testReflectionHashCodeCycleDoesNotOverflow() {
        final CycleA a = new CycleA();
        final CycleB b = new CycleB();
        a.b = b;
        b.a = a;

        final int hashA = a.hashCode();
        assertTrue(HashCodeBuilder.getRegistry().isEmpty());
        final int hashB = b.hashCode();
        assertTrue(HashCodeBuilder.getRegistry().isEmpty());
        assertEquals(hashA, a.hashCode());
        assertEquals(hashB, b.hashCode());
    }

    @Test
    void testIsRegisteredAndRegistryLifecycle() {
        assertFalse(HashCodeBuilder.isRegistered("not registered"));
        assertTrue(HashCodeBuilder.getRegistry().isEmpty());
    }

    @Test
    void testToHashCodeIsStableAcrossCalls() {
        final HashCodeBuilder hcb = new HashCodeBuilder(INITIAL, CONSTANT).append(7);
        final int first = hcb.toHashCode();
        final int second = hcb.toHashCode();
        assertEquals(first, second);
    }

    @Test
    void testDifferentBuildersWithSameAppendsAreNotTheSameInstance() {
        final HashCodeBuilder hcb1 = new HashCodeBuilder(INITIAL, CONSTANT).append(1);
        final HashCodeBuilder hcb2 = new HashCodeBuilder(INITIAL, CONSTANT).append(1);
        assertNotSame(hcb1, hcb2);
        assertEquals(hcb1.toHashCode(), hcb2.toHashCode());
    }
}
