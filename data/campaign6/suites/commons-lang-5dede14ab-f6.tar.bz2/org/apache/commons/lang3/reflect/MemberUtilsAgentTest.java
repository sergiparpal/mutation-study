/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MemberUtils}.
 */
class MemberUtilsAgentTest {

    static class MethodFixture {
        public void takesObject(final Object o) {
        }

        public void takesString(final String s) {
        }

        public void takesComparable(final Comparable<?> c) {
        }

        public void twoFixed(final String s, final int i) {
        }

        public void varArg(final String s, final int... nums) {
        }

        public void varArgDouble(final String s, final double... nums) {
        }

        public void primLong(final long l) {
        }

        public void primDouble(final double d) {
        }

        public void primInt(final int i) {
        }
    }

    static class CtorFixture {
        public CtorFixture(final Object o) {
        }

        public CtorFixture(final String s) {
        }

        public CtorFixture(final String s, final int... nums) {
        }
    }

    static class PkgPrivateBase {
        public void publicMethod() {
        }

        @SuppressWarnings("unused")
        private void privateMethod() {
        }
    }

    public static class PublicClassWithPublicMethod {
        public void publicMethod() {
        }
    }

    static class NumberBox<T extends Number> {
        public T getValue() {
            return null;
        }
    }

    static class IntBox extends NumberBox<Integer> {
        @Override
        public Integer getValue() {
            return null;
        }
    }

    private static Method bridgeMethod(final Class<?> cls, final String name) throws Exception {
        for (final Method m : cls.getDeclaredMethods()) {
            if (m.getName().equals(name) && m.isBridge()) {
                return m;
            }
        }
        throw new AssertionError("no bridge method named " + name + " found on " + cls);
    }

    @Test
    void testCompareConstructorFitExactBeatsSuperclass() throws Exception {
        final Constructor<?> ctorString = CtorFixture.class.getConstructor(String.class);
        final Constructor<?> ctorObject = CtorFixture.class.getConstructor(Object.class);
        final int result = MemberUtils.compareConstructorFit(ctorString, ctorObject, new Class<?>[] {String.class});
        assertTrue(result < 0, "exact String match should be better than Object match");
        // comparison must be anti-symmetric
        final int reversed = MemberUtils.compareConstructorFit(ctorObject, ctorString, new Class<?>[] {String.class});
        assertTrue(reversed > 0);
    }

    @Test
    void testCompareConstructorFitVarArgsNoArgsPassedVsExact() throws Exception {
        final Constructor<?> ctorVarArgs = CtorFixture.class.getConstructor(String.class, int[].class);
        final Constructor<?> ctorExact = CtorFixture.class.getConstructor(String.class);
        final int result = MemberUtils.compareConstructorFit(ctorExact, ctorVarArgs, new Class<?>[] {String.class});
        assertTrue(result < 0, "exact fixed-arity match should beat a varargs constructor called with no varargs");
    }

    @Test
    void testCompareMethodFitExactBeatsSuperclass() throws Exception {
        final Method takesString = MethodFixture.class.getMethod("takesString", String.class);
        final Method takesObject = MethodFixture.class.getMethod("takesObject", Object.class);
        final Class<?>[] actual = {String.class};
        final int result = MemberUtils.compareMethodFit(takesString, takesObject, actual);
        assertTrue(result < 0, "exact match should be strictly better than widening to Object");
    }

    @Test
    void testCompareMethodFitInterfaceMatchBeatsSuperclassButNotExact() throws Exception {
        final Method takesComparable = MethodFixture.class.getMethod("takesComparable", Comparable.class);
        final Method takesObject = MethodFixture.class.getMethod("takesObject", Object.class);
        final Method takesString = MethodFixture.class.getMethod("takesString", String.class);
        final Class<?>[] actual = {String.class};
        // interface match (0.25) must beat climbing to Object (1.0)
        assertTrue(MemberUtils.compareMethodFit(takesComparable, takesObject, actual) < 0);
        // but an exact match (0.0) must still beat the interface match (0.25)
        assertTrue(MemberUtils.compareMethodFit(takesString, takesComparable, actual) < 0);
    }

    @Test
    void testCompareMethodFitPrimitiveWideningOrder() throws Exception {
        final Method primInt = MethodFixture.class.getMethod("primInt", int.class);
        final Method primLong = MethodFixture.class.getMethod("primLong", long.class);
        final Method primDouble = MethodFixture.class.getMethod("primDouble", double.class);
        final Class<?>[] actual = {int.class};
        assertTrue(MemberUtils.compareMethodFit(primInt, primLong, actual) < 0, "exact primitive match beats widening to long");
        assertTrue(MemberUtils.compareMethodFit(primLong, primDouble, actual) < 0, "narrower widening (to long) beats wider widening (to double)");
        assertTrue(MemberUtils.compareMethodFit(primInt, primDouble, actual) < 0, "exact primitive match beats widening to double");
    }

    @Test
    void testCompareMethodFitVarArgsExplicitArrayUsesComponentType() throws Exception {
        final Method varArgInt = MethodFixture.class.getMethod("varArg", String.class, int[].class);
        final Method varArgDouble = MethodFixture.class.getMethod("varArgDouble", String.class, double[].class);
        // explicit array branch: an explicit int[] fits varArg(int...) exactly but needs widening for varArg(double...)
        final Class<?>[] explicitIntArray = {String.class, int[].class};
        final int result = MemberUtils.compareMethodFit(varArgInt, varArgDouble, explicitIntArray);
        assertTrue(result < 0, "an explicit int[] array should match int... better than double...");
    }

    @Test
    void testCompareMethodFitVarArgsNoArgsPassedIgnoresComponentType() throws Exception {
        final Method varArgInt = MethodFixture.class.getMethod("varArg", String.class, int[].class);
        final Method varArgDouble = MethodFixture.class.getMethod("varArgDouble", String.class, double[].class);
        // when no varargs are passed at all, both are scored solely by their component type's distance to
        // Object.class, which is identical (2.5) for any primitive component type.
        final Class<?>[] noVarArgs = {String.class};
        final int result = MemberUtils.compareMethodFit(varArgInt, varArgDouble, noVarArgs);
        assertEquals(0, result, "with no varargs passed, int... and double... should be scored as equally generic");
    }

    @Test
    void testCompareMethodFitVarArgsNoArgsPassedPrefersGenericMatch() throws Exception {
        final Method varArg = MethodFixture.class.getMethod("varArg", String.class, int[].class);
        final Method twoFixed = MethodFixture.class.getMethod("twoFixed", String.class, int.class);
        // Calling with just the fixed String arg (no varargs at all): varArg is still usable (0 varargs elements)
        // while twoFixed requires a second int argument and thus can't match at all (infinite cost).
        final Class<?>[] actual = {String.class};
        final int result = MemberUtils.compareMethodFit(varArg, twoFixed, actual);
        assertTrue(result < 0, "a usable varargs method should beat a fixed-arity method missing a required argument");
    }

    @Test
    void testIsMatchingMethodFixedArity() throws Exception {
        final Method twoFixed = MethodFixture.class.getMethod("twoFixed", String.class, int.class);
        assertTrue(MemberUtils.isMatchingMethod(twoFixed, new Class<?>[] {String.class, Integer.class}),
                "Integer should be assignable to int via autoboxing");
        assertFalse(MemberUtils.isMatchingMethod(twoFixed, new Class<?>[] {String.class, String.class}),
                "String is not assignable to int");
        assertFalse(MemberUtils.isMatchingMethod(twoFixed, new Class<?>[] {String.class}),
                "too few arguments must not match a fixed-arity method");
        assertFalse(MemberUtils.isMatchingMethod(twoFixed, new Class<?>[] {String.class, Integer.class, Integer.class}),
                "too many arguments must not match a fixed-arity method");
    }

    @Test
    void testIsMatchingMethodVarArgs() throws Exception {
        final Method varArg = MethodFixture.class.getMethod("varArg", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArg, new Class<?>[] {String.class}),
                "zero varargs elements should still match");
        assertTrue(MemberUtils.isMatchingMethod(varArg, new Class<?>[] {String.class, Integer.class, Integer.class}),
                "multiple varargs elements assignable to int should match");
        assertFalse(MemberUtils.isMatchingMethod(varArg, new Class<?>[] {String.class, String.class}),
                "a varargs element not assignable to the component type must not match");
        assertFalse(MemberUtils.isMatchingMethod(varArg, new Class<?>[] {Integer.class, Integer.class}),
                "mismatched fixed argument must not match even if varargs portion would");
    }

    @Test
    void testIsMatchingConstructor() throws Exception {
        final Constructor<?> varArgCtor = CtorFixture.class.getConstructor(String.class, int[].class);
        assertTrue(MemberUtils.isMatchingConstructor(varArgCtor, new Class<?>[] {String.class}));
        assertTrue(MemberUtils.isMatchingConstructor(varArgCtor, new Class<?>[] {String.class, Integer.class}));
        assertFalse(MemberUtils.isMatchingConstructor(varArgCtor, new Class<?>[] {Integer.class}));

        final Constructor<?> fixedCtor = CtorFixture.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(fixedCtor, new Class<?>[] {String.class}));
        assertFalse(MemberUtils.isMatchingConstructor(fixedCtor, new Class<?>[] {String.class, Integer.class}));
    }

    @Test
    void testIsPublic() throws Exception {
        final Method publicMethod = PkgPrivateBase.class.getDeclaredMethod("publicMethod");
        final Method privateMethod = PkgPrivateBase.class.getDeclaredMethod("privateMethod");
        assertTrue(MemberUtils.isPublic(publicMethod));
        assertFalse(MemberUtils.isPublic(privateMethod));
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    void testIsStatic() throws Exception {
        final Method instanceMethod = PkgPrivateBase.class.getDeclaredMethod("publicMethod");
        final Method staticMethod = MethodFixtureStaticHolder.class.getDeclaredMethod("staticMethod");
        assertFalse(MemberUtils.isStatic(instanceMethod));
        assertTrue(MemberUtils.isStatic(staticMethod));
        assertFalse(MemberUtils.isStatic(null));
    }

    static class MethodFixtureStaticHolder {
        static void staticMethod() {
        }
    }

    @Test
    void testIsAccessiblePublicNonSyntheticIsAccessible() throws Exception {
        final Method m = PkgPrivateBase.class.getDeclaredMethod("publicMethod");
        assertTrue(MemberUtils.isAccessible(m));
    }

    @Test
    void testIsAccessiblePrivateIsNotAccessible() throws Exception {
        final Method m = PkgPrivateBase.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isAccessible(m));
    }

    @Test
    void testIsAccessibleSyntheticBridgeIsNotAccessible() throws Exception {
        final Method bridge = bridgeMethod(IntBox.class, "getValue");
        assertTrue(Modifier.isPublic(bridge.getModifiers()), "bridge method should be public");
        assertTrue(bridge.isSynthetic(), "bridge method should be synthetic");
        assertFalse(MemberUtils.isAccessible(bridge), "a synthetic method must not be considered accessible");
    }

    @Test
    void testIsPackage() {
        assertTrue(MemberUtils.isPackage(0));
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC | Modifier.STATIC));
    }

    @Test
    void testSetAccessibleWorkaroundNull() {
        assertNull(MemberUtils.setAccessibleWorkaround(null));
    }

    @Test
    void testSetAccessibleWorkaroundPublicMethodOnPackagePrivateClass() throws Exception {
        final Method m = PkgPrivateBase.class.getDeclaredMethod("publicMethod");
        assertFalse(m.isAccessible(), "reflection access is not granted by default");
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result, "the same object should be returned");
        assertTrue(result.isAccessible(), "accessible flag should now be set to work around the JVM bug");
    }

    @Test
    void testSetAccessibleWorkaroundPrivateMethodOnPackagePrivateClassIsUntouched() throws Exception {
        final Method m = PkgPrivateBase.class.getDeclaredMethod("privateMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertFalse(result.isAccessible(), "a non-public member must not be forced accessible");
    }

    @Test
    void testSetAccessibleWorkaroundPublicMethodOnPublicClassIsUntouched() throws Exception {
        final Method m = PublicClassWithPublicMethod.class.getDeclaredMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertFalse(result.isAccessible(), "no workaround is needed when the declaring class is already public");
    }

    @Test
    void testSetAccessibleWorkaroundAlreadyAccessibleIsReturnedAsIs() throws Exception {
        final Method m = PkgPrivateBase.class.getDeclaredMethod("privateMethod");
        m.setAccessible(true);
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    void testCompareConstructorFitEqualCostIsZero() throws Exception {
        final Constructor<?> ctorString = CtorFixture.class.getConstructor(String.class);
        final int result = MemberUtils.compareConstructorFit(ctorString, ctorString, new Class<?>[] {String.class});
        assertEquals(0, result);
    }
}
