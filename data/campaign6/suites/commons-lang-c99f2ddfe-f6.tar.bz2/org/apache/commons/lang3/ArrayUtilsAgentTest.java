/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testCloneArraysReturnDistinctCopy() {
        final int[] intArray = { 1, 2, 3 };
        final int[] intClone = ArrayUtils.clone(intArray);
        assertArrayEquals(intArray, intClone);
        assertNotSame(intArray, intClone);
        assertNull(ArrayUtils.clone((int[]) null));

        final Object[] objArray = { "a", "b" };
        final Object[] objClone = ArrayUtils.clone(objArray);
        assertArrayEquals(objArray, objClone);
        assertNotSame(objArray, objClone);
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    void testContains() {
        final int[] intArray = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(intArray, 2));
        assertFalse(ArrayUtils.contains(intArray, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final Object[] objArray = { "a", null, "b" };
        assertTrue(ArrayUtils.contains(objArray, "a"));
        assertTrue(ArrayUtils.contains(objArray, null));
        assertFalse(ArrayUtils.contains(objArray, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));

        assertTrue(ArrayUtils.contains(new double[] { 1.0, 2.0 }, 1.95, 0.1));
        assertFalse(ArrayUtils.contains(new double[] { 1.0, 2.0 }, 1.8, 0.1));
    }

    @Test
    void testContainsAny() {
        final int[] intArray = { 1, 2, 3 };
        assertTrue(ArrayUtils.containsAny(intArray, 5, 2));
        assertFalse(ArrayUtils.containsAny(intArray, 7, 8));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1, 2));

        final String[] strArray = { "x", "y" };
        assertTrue(ArrayUtils.containsAny(strArray, "q", "y"));
        assertFalse(ArrayUtils.containsAny(strArray, "q", "r"));
    }

    @Test
    void testGet() {
        final String[] array = { "a", "b", "c" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertEquals("c", ArrayUtils.get(array, 2));
        assertNull(ArrayUtils.get(array, 3));
        assertNull(ArrayUtils.get(array, -1));
        assertNull(ArrayUtils.get((String[]) null, 0));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertEquals(Integer.class, ArrayUtils.getComponentType(new Integer[0]));
        assertNull(ArrayUtils.getComponentType(null));
    }

    @Test
    void testGetDimensionsBoundary() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[0]));
        assertEquals(2, ArrayUtils.getDimensions(new int[0][0]));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertEquals(2, ArrayUtils.getLength(new String[] { "a", "b" }));
    }

    @Test
    void testGetLengthNonArrayThrows() {
        try {
            ArrayUtils.getLength("not an array");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected: non-array argument
        }
    }

    @Test
    void testHashCode() {
        final int[] array1 = { 1, 2, 3 };
        final int[] array2 = { 1, 2, 3 };
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet expected = new BitSet();
        expected.set(0);
        expected.set(2);
        expected.set(4);
        assertEquals(expected, ArrayUtils.indexesOf(array, 1));
        assertTrue(ArrayUtils.indexesOf(array, 42).isEmpty());
        assertTrue(ArrayUtils.indexesOf((int[]) null, 1).isEmpty());

        final BitSet expectedFrom3 = new BitSet();
        expectedFrom3.set(4);
        assertEquals(expectedFrom3, ArrayUtils.indexesOf(array, 1, 3));
    }

    @Test
    void testIndexOfBoundary() {
        final int[] array = { 10, 20, 30 };
        assertEquals(0, ArrayUtils.indexOf(array, 10));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 99));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 10));
        // negative startIndex treated as zero
        assertEquals(1, ArrayUtils.indexOf(array, 20, -5));
        // startIndex beyond length finds nothing
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 10, 10));
    }

    @Test
    void testIndexOfDoubleWithTolerance() {
        final double[] array = { 1.0, 2.0, 3.0 };
        assertEquals(1, ArrayUtils.indexOf(array, 2.05, 0.1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2.5, 0.1));
    }

    @Test
    void testIndexOfDoubleNaN() {
        final double[] array = { 1.0, Double.NaN, 3.0 };
        assertEquals(1, ArrayUtils.indexOf(array, Double.NaN));
        assertEquals(1, ArrayUtils.lastIndexOf(array, Double.NaN));
    }

    @Test
    void testIndexOfObjectNegativeStartIndex() {
        final String[] array = { "a", "b", "c" };
        assertEquals(0, ArrayUtils.indexOf(array, "a", -100));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, "a", 100));
    }

    @Test
    void testIsArrayIndexValid() {
        final String[] array = { "a", "b" };
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
    }

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));

        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(new int[] { 1 }, null));
    }

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, new int[0]));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    @Test
    void testIsSortedPrimitivesAndObjects() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[] { 5 }));

        assertTrue(ArrayUtils.isSorted(new String[] { "a", "b", "c" }));
        assertFalse(ArrayUtils.isSorted(new String[] { "c", "a", "b" }));

        final Comparator<String> reverse = new Comparator<String>() {
            public int compare(final String a, final String b) {
                return b.compareTo(a);
            }
        };
        assertTrue(ArrayUtils.isSorted(new String[] { "c", "b", "a" }, reverse));
        assertFalse(ArrayUtils.isSorted(new String[] { "a", "b", "c" }, reverse));
    }

    @Test
    void testLastIndexOfBoundary() {
        final int[] array = { 10, 20, 30, 20 };
        assertEquals(3, ArrayUtils.lastIndexOf(array, 20));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 99));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 20));
        // negative startIndex -> not found
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 20, -1));
        // startIndex beyond array length searches from the end
        assertEquals(3, ArrayUtils.lastIndexOf(array, 20, 100));
        // startIndex limits the search window
        assertEquals(1, ArrayUtils.lastIndexOf(array, 20, 2));
    }

    @Test
    void testLastIndexOfObjectTypeMismatch() {
        final String[] array = { "a", "b" };
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((Object[]) array, Integer.valueOf(1)));
    }

    @Test
    void testNullToEmpty() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] nonEmpty = { 1, 2 };
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));

        assertSame(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        final String[] strings = { "a" };
        assertSame(strings, ArrayUtils.nullToEmpty(strings));
    }

    @Test
    void testNullToEmptyWithClassThrowsOnNullType() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                ArrayUtils.nullToEmpty((String[]) null, null);
            }
        });
        final String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    void testReverseFullArray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 5, 4, 3, 2, 1 }, array);

        // null input does nothing, no exception
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testReverseRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array);

        // overvalue end index is demoted to array length
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.reverse(array2, 0, 100);
        assertArrayEquals(new int[] { 3, 2, 1 }, array2);

        // undervalue start index promoted to 0
        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.reverse(array3, -5, 3);
        assertArrayEquals(new int[] { 3, 2, 1 }, array3);

        // end index before start index results in no change
        final int[] array4 = { 1, 2, 3 };
        ArrayUtils.reverse(array4, 2, 1);
        assertArrayEquals(new int[] { 1, 2, 3 }, array4);
    }

    @Test
    void testSetAll() {
        final Integer[] array = new Integer[5];
        final Integer[] result = ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            public Integer apply(final int i) {
                return i * i;
            }
        });
        assertSame(array, result);
        assertArrayEquals(new Integer[] { 0, 1, 4, 9, 16 }, result);
    }

    @Test
    void testShiftFullArray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);

        final int[] negShift = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(negShift, -1);
        assertArrayEquals(new int[] { 2, 3, 4, 5, 1 }, negShift);

        // null array is a no-op
        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    void testShiftRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 1, 4, 1);
        assertArrayEquals(new int[] { 1, 4, 2, 3, 5 }, array);

        // offset larger than number of elements wraps via modulo
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.shift(array2, 0, 3, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);
    }

    @Test
    void testShuffleIsPermutation() {
        final int[] array = { 1, 2, 3, 4, 5 };
        final int[] original = ArrayUtils.clone(array);
        ArrayUtils.shuffle(array, new Random(42));
        assertEquals(original.length, array.length);
        final int[] sortedOriginal = ArrayUtils.clone(original);
        final int[] sortedShuffled = ArrayUtils.clone(array);
        java.util.Arrays.sort(sortedOriginal);
        java.util.Arrays.sort(sortedShuffled);
        assertArrayEquals(sortedOriginal, sortedShuffled);
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2 }, new byte[] { 1, 2, 3 }));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1 }, new byte[0]));
        assertFalse(ArrayUtils.startsWith(null, new byte[] { 1 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, null));
    }

    @Test
    void testSubarrayBoundary() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertArrayEquals(array, ArrayUtils.subarray(array, -10, 100));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));

        final String[] stringArray = { "a", "b", "c" };
        final String[] sub = ArrayUtils.subarray(stringArray, 1, 3);
        assertArrayEquals(new String[] { "b", "c" }, sub);
        assertEquals(String.class, sub.getClass().getComponentType());
    }

    @Test
    void testSwapBasic() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        // overflow index is a no-op
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);

        // negative index promoted to 0
        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.swap(array3, -1, 1);
        assertArrayEquals(new int[] { 2, 1, 3 }, array3);

        // null array is a no-op
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testSwapRange() {
        final int[] array = { 1, 2, 3, 4 };
        ArrayUtils.swap(array, 0, 2, 2);
        assertArrayEquals(new int[] { 3, 4, 1, 2 }, array);

        // partial swap at array boundary
        final int[] array2 = { 1, 2, 3, 4 };
        ArrayUtils.swap(array2, 0, 3, 3);
        assertArrayEquals(new int[] { 4, 2, 3, 1 }, array2);
    }

    @Test
    void testToArray() {
        final String[] result = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
    }

    @Test
    void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] { { "RED", "#FF0000" }, { "GREEN", "#00FF00" } });
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
        assertNull(ArrayUtils.toMap(null));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                ArrayUtils.toMap(new Object[] { new String[] { "onlyOne" } });
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                ArrayUtils.toMap(new Object[] { "not an entry" });
            }
        });
    }

    @Test
    void testToObjectAndToPrimitiveRoundTrip() {
        final int[] primitive = { 1, 2, 3 };
        final Integer[] objects = ArrayUtils.toObject(primitive);
        assertArrayEquals(new Integer[] { 1, 2, 3 }, objects);
        final int[] roundTrip = ArrayUtils.toPrimitive(objects);
        assertArrayEquals(primitive, roundTrip);

        assertNull(ArrayUtils.toObject((int[]) null));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    void testToPrimitiveWithNullHandling() {
        final Integer[] withNull = { 1, null, 3 };
        final int[] result = ArrayUtils.toPrimitive(withNull, -1);
        assertArrayEquals(new int[] { 1, -1, 3 }, result);

        final Boolean[] boolWithNull = { Boolean.TRUE, null };
        final boolean[] boolResult = ArrayUtils.toPrimitive(boolWithNull, true);
        assertArrayEquals(new boolean[] { true, true }, boolResult);
    }

    @Test
    void testToPrimitiveNullElementThrows() {
        final Integer[] withNull = { 1, null };
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                ArrayUtils.toPrimitive(withNull);
            }
        });
    }

    @Test
    void testToStringAndToStringArray() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("empty", ArrayUtils.toString(null, "empty"));
        assertTrue(ArrayUtils.toString(new int[] { 1, 2 }).contains("1"));

        final Object[] array = { "a", null, Integer.valueOf(2) };
        final String[] strings = ArrayUtils.toStringArray(array);
        assertArrayEquals(new String[] { "a", "null", "2" }, strings);
        final String[] stringsCustomNull = ArrayUtils.toStringArray(array, "NONE");
        assertArrayEquals(new String[] { "a", "NONE", "2" }, stringsCustomNull);
        assertNull(ArrayUtils.toStringArray(null));
    }

}
