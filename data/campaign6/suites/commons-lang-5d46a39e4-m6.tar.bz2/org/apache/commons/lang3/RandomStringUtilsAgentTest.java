/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    private static void assertAllMatch(final String s, final CharPredicate predicate) {
        for (int i = 0; i < s.length(); i++) {
            assertTrue(predicate.test(s.charAt(i)), "Unexpected character '" + s.charAt(i) + "' at index " + i + " in \"" + s + "\"");
        }
    }

    private interface CharPredicate {
        boolean test(char c);
    }

    // --- Singletons ---

    @Test
    void testSingletonsAreStableAndDistinct() {
        assertSame(RandomStringUtils.secure(), RandomStringUtils.secure());
        assertSame(RandomStringUtils.secureStrong(), RandomStringUtils.secureStrong());
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.insecure());
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.secureStrong());
    }

    @Test
    void testDeprecatedPublicConstructorWorks() {
        final RandomStringUtils instance = new RandomStringUtils();
        final String result = instance.next(5);
        assertEquals(5, result.length());
    }

    @Test
    void testToString() {
        final String str = RandomStringUtils.secure().toString();
        assertNotNull(str);
        assertTrue(str.startsWith("RandomStringUtils [random="), str);
    }

    // --- next(int) / count boundaries ---

    @Test
    void testNextZeroCountReturnsEmptyString() {
        assertEquals("", RandomStringUtils.secure().next(0));
        assertEquals("", RandomStringUtils.insecure().nextAlphabetic(0));
        assertEquals("", RandomStringUtils.secureStrong().nextNumeric(0));
    }

    @Test
    void testNextNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-1);
            }
        });
    }

    @Test
    void testNextCorrectLength() {
        final String s = RandomStringUtils.secure().next(257);
        assertEquals(257, s.length());
    }

    // --- nextAlphabetic / nextAlphanumeric / nextNumeric / nextAscii / nextGraph / nextPrint ---

    @Test
    void testNextAlphabeticOnlyLetters() {
        final String s = RandomStringUtils.secure().nextAlphabetic(200);
        assertEquals(200, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c);
            }
        });
    }

    @Test
    void testNextAlphanumericOnlyLettersOrDigits() {
        final String s = RandomStringUtils.secure().nextAlphanumeric(200);
        assertEquals(200, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c) || Character.isDigit(c);
            }
        });
    }

    @Test
    void testNextNumericOnlyDigits() {
        final String s = RandomStringUtils.secure().nextNumeric(200);
        assertEquals(200, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testNextAsciiRange() {
        final String s = RandomStringUtils.secure().nextAscii(200);
        assertEquals(200, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testNextGraphRange() {
        final String s = RandomStringUtils.secure().nextGraph(200);
        assertEquals(200, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 33 && c < 126;
            }
        });
    }

    @Test
    void testNextPrintRange() {
        final String s = RandomStringUtils.secure().nextPrint(200);
        assertEquals(200, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c < 126;
            }
        });
    }

    // --- min/max length variants ---

    @Test
    void testNextAlphabeticMinMaxExactWhenEqual() {
        final String s = RandomStringUtils.secure().nextAlphabetic(5, 5);
        assertEquals(5, s.length());
    }

    @Test
    void testNextAlphabeticMinMaxWithinRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAlphabetic(3, 9);
            assertTrue(s.length() >= 3 && s.length() < 9, "length=" + s.length());
        }
    }

    @Test
    void testNextNumericMinMaxWithinRange() {
        final String s = RandomStringUtils.secure().nextNumeric(4, 4);
        assertEquals(4, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    // --- next(count, chars) ---

    @Test
    void testNextWithCharArray() {
        final String s = RandomStringUtils.secure().next(10, 'x', 'y', 'z');
        assertEquals(10, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'x' || c == 'y' || c == 'z';
            }
        });
    }

    @Test
    void testNextWithNullCharArray() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.secure().next(10, nullChars);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithEmptyCharArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, new char[0]);
            }
        });
    }

    // --- next(count, String chars) ---

    @Test
    void testNextWithStringChars() {
        final String s = RandomStringUtils.secure().next(10, "AB");
        assertEquals(10, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'A' || c == 'B';
            }
        });
    }

    @Test
    void testNextWithNullStringChars() {
        final String nullStr = null;
        final String s = RandomStringUtils.secure().next(10, nullStr);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(5, "");
            }
        });
    }

    // --- Static random(count, start, end, letters, digits, chars, random) boundary/error cases ---

    @Test
    void testRandomCountZeroReturnsEmpty() {
        assertEquals("", RandomStringUtils.random(0, 0, 0, false, false, null, new Random(1L)));
    }

    @Test
    void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-5, 0, 0, false, false, null, new Random(1L));
            }
        });
    }

    @Test
    void testRandomEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 0, false, false, new char[0], new Random(1L));
            }
        });
    }

    @Test
    void testRandomEndLessThanOrEqualStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false, null, new Random(1L));
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 10, false, false, null, new Random(1L));
            }
        });
    }

    @Test
    void testRandomNegativeStartOrEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false, null, new Random(1L));
            }
        });
    }

    @Test
    void testRandomLettersNoDigitsNoLettersInRangeThrows() {
        // chars == null, end <= 0x7f, letters requested but end is at or before 'A'
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 48, 58, true, false, null, new Random(1L));
            }
        });
    }

    @Test
    void testRandomDigitsNoLettersNoDigitsInRangeThrows() {
        // chars == null, end <= 0x7f, digits requested but end is at or before '0'
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0, 48, false, true, null, new Random(1L));
            }
        });
    }

    @Test
    void testRandomCharsWithNoLettersAmongThemThrows() {
        final char[] nonLetters = { '!', '@', '#' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0, 0, true, false, nonLetters, new Random(1L));
            }
        });
    }

    @Test
    void testRandomCharsWithNoDigitsAmongThemThrows() {
        final char[] nonDigits = { '!', '@', '#' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0, 0, false, true, nonDigits, new Random(1L));
            }
        });
    }

    @Test
    void testRandomReproducibleWithSameSeed() {
        final char[] alphabet = "abcdef".toCharArray();
        final String first = RandomStringUtils.random(50, 0, alphabet.length, false, false, alphabet, new Random(42L));
        final String second = RandomStringUtils.random(50, 0, alphabet.length, false, false, alphabet, new Random(42L));
        assertEquals(first, second);
        assertEquals(50, first.length());
    }

    @Test
    void testRandomWithCustomCharsOnlyUsesThoseChars() {
        final char[] alphabet = "QZ".toCharArray();
        final String s = RandomStringUtils.random(30, 0, alphabet.length, false, false, alphabet, new Random(7L));
        assertEquals(30, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'Q' || c == 'Z';
            }
        });
    }

    // --- Deprecated static convenience methods ---

    @Test
    void testDeprecatedRandomCount() {
        assertEquals(15, RandomStringUtils.random(15).length());
        assertEquals("", RandomStringUtils.random(0));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    void testDeprecatedRandomAlphabetic() {
        final String s = RandomStringUtils.randomAlphabetic(50);
        assertEquals(50, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomAlphabeticMinMax() {
        final String s = RandomStringUtils.randomAlphabetic(4, 4);
        assertEquals(4, s.length());
    }

    @Test
    void testDeprecatedRandomAlphanumeric() {
        final String s = RandomStringUtils.randomAlphanumeric(50);
        assertEquals(50, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomNumeric() {
        final String s = RandomStringUtils.randomNumeric(50);
        assertEquals(50, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomAscii() {
        final String s = RandomStringUtils.randomAscii(50);
        assertEquals(50, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testDeprecatedRandomGraph() {
        final String s = RandomStringUtils.randomGraph(50);
        assertEquals(50, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 33 && c < 126;
            }
        });
    }

    @Test
    void testDeprecatedRandomPrint() {
        final String s = RandomStringUtils.randomPrint(50);
        assertEquals(50, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c < 126;
            }
        });
    }

    @Test
    void testDeprecatedRandomLettersNumbersFlags() {
        final String letters = RandomStringUtils.random(40, true, false);
        assertAllMatch(letters, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c);
            }
        });
        final String numbers = RandomStringUtils.random(40, false, true);
        assertAllMatch(numbers, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomWithCharsArray() {
        final String s = RandomStringUtils.random(20, 'a', 'b');
        assertEquals(20, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'a' || c == 'b';
            }
        });
    }

    @Test
    void testDeprecatedRandomWithStringChars() {
        final String s = RandomStringUtils.random(20, "xy");
        assertEquals(20, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'x' || c == 'y';
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @Test
    void testDeprecatedRandomFullSignature() {
        final String s = RandomStringUtils.random(10, 0, 0, true, true);
        assertEquals(10, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c);
            }
        });
    }

    @Test
    void testDeprecatedRandomFullSignatureWithChars() {
        final char[] chars = { 'c', 'a', 't' };
        final String s = RandomStringUtils.random(10, 0, chars.length, false, false, chars);
        assertEquals(10, s.length());
        assertAllMatch(s, new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'c' || c == 'a' || c == 't';
            }
        });
    }

    // --- Difference between calls (sanity, not a correctness proof) ---

    @Test
    void testTwoCallsProduceDifferentStrings() {
        final String first = RandomStringUtils.secure().nextAlphanumeric(32);
        final String second = RandomStringUtils.secure().nextAlphanumeric(32);
        assertNotEquals(first, second);
        assertFalse(first.isEmpty());
    }

}
