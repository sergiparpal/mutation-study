/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link RandomStringUtils}.
 */
public class RandomStringUtilsAgentTest {

    @Test
    public void testRandomCountZeroReturnsEmpty() {
        assertEquals("", RandomStringUtils.random(0));
        assertEquals(0, RandomStringUtils.random(0).length());
    }

    @Test
    public void testRandomNegativeCountThrows() {
        try {
            RandomStringUtils.random(-1);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomLengthMatchesCount() {
        final String s = RandomStringUtils.random(50);
        assertEquals(50, s.length());
    }

    @Test
    public void testRandomAlphabeticOnlyLetters() {
        final String s = RandomStringUtils.randomAlphabetic(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)), "Not a letter: " + s.charAt(i));
        }
    }

    @Test
    public void testRandomNumericOnlyDigits() {
        final String s = RandomStringUtils.randomNumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)), "Not a digit: " + s.charAt(i));
        }
    }

    @Test
    public void testRandomAlphanumericOnlyLettersOrDigits() {
        final String s = RandomStringUtils.randomAlphanumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetter(c) || Character.isDigit(c), "Not alphanumeric: " + c);
        }
    }

    @Test
    public void testRandomAsciiRange() {
        final String s = RandomStringUtils.randomAscii(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Out of ASCII range: " + (int) c);
        }
    }

    @Test
    public void testRandomGraphRange() {
        final String s = RandomStringUtils.randomGraph(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126, "Out of graph range: " + (int) c);
        }
    }

    @Test
    public void testRandomPrintRange() {
        final String s = RandomStringUtils.randomPrint(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Out of print range: " + (int) c);
        }
    }

    @Test
    public void testRandomAlphabeticRangeLength() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10, "length=" + s.length());
        }
    }

    @Test
    public void testRandomAlphabeticRangeEqualBoundsFixedLength() {
        final String s = RandomStringUtils.randomAlphabetic(5, 5);
        assertEquals(5, s.length());
    }

    @Test
    public void testRandomAlphabeticRangeMinGreaterThanMaxThrows() {
        try {
            RandomStringUtils.randomAlphabetic(6, 5);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomNumericRangeLength() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomNumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8, "length=" + s.length());
        }
    }

    @Test
    public void testRandomWithCharsArray() {
        final char[] chars = { 'a', 'b', 'c' };
        final String s = RandomStringUtils.random(100, chars);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomWithNullCharsArrayUsesAllChars() {
        final String s = RandomStringUtils.random(10, (char[]) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomWithEmptyCharsArrayThrows() {
        try {
            RandomStringUtils.random(5, new char[0]);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomWithCharsString() {
        final String s = RandomStringUtils.random(50, "xyz");
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomWithEmptyCharsStringThrows() {
        try {
            RandomStringUtils.random(5, "");
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomWithNullCharsStringUsesAllChars() {
        final String s = RandomStringUtils.random(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomLettersNumbersFullSignature() {
        final Random random = new Random(42L);
        final String s = RandomStringUtils.random(20, 0, 0, true, true, null, random);
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetterOrDigit(c), "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomDeterministicWithSameSeed() {
        final String s1 = RandomStringUtils.random(30, 0, 0, true, true, null, new Random(123L));
        final String s2 = RandomStringUtils.random(30, 0, 0, true, true, null, new Random(123L));
        assertEquals(s1, s2);
    }

    @Test
    public void testRandomEndLessThanStartThrows() {
        try {
            RandomStringUtils.random(5, 10, 5, false, false, null, new Random());
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomNegativeStartThrows() {
        try {
            RandomStringUtils.random(5, -1, 10, false, false, null, new Random());
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomStartGreaterOrEqualCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        try {
            RandomStringUtils.random(5, 3, 3 + 1, false, false, chars, new Random());
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomEndGreaterThanCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        try {
            RandomStringUtils.random(5, 0, 4, false, false, chars, new Random());
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomLettersRequiredButRangeHasNone() {
        try {
            RandomStringUtils.random(5, '0', '9' + 1, true, false, null, new Random());
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testRandomDigitsRequiredButRangeHasNone() {
        try {
            RandomStringUtils.random(5, 'a', 'z' + 1, false, true, null, new Random());
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testSecureInsecureSecureStrongSingletons() {
        final RandomStringUtils secure1 = RandomStringUtils.secure();
        final RandomStringUtils secure2 = RandomStringUtils.secure();
        assertSame(secure1, secure2);

        final RandomStringUtils insecure1 = RandomStringUtils.insecure();
        final RandomStringUtils insecure2 = RandomStringUtils.insecure();
        assertSame(insecure1, insecure2);

        final RandomStringUtils secureStrong1 = RandomStringUtils.secureStrong();
        final RandomStringUtils secureStrong2 = RandomStringUtils.secureStrong();
        assertSame(secureStrong1, secureStrong2);

        assertNotSame(secure1, insecure1);
        assertNotSame(secure1, secureStrong1);
    }

    @Test
    public void testInsecureNextProducesCorrectLength() {
        final String s = RandomStringUtils.insecure().next(15);
        assertEquals(15, s.length());
    }

    @Test
    public void testInsecureNextAlphabetic() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @Test
    public void testInsecureNextAlphanumericRange() {
        for (int i = 0; i < 10; i++) {
            final String s = RandomStringUtils.insecure().nextAlphanumeric(4, 9);
            assertTrue(s.length() >= 4 && s.length() < 9);
            for (int j = 0; j < s.length(); j++) {
                assertTrue(Character.isLetterOrDigit(s.charAt(j)));
            }
        }
    }

    @Test
    public void testInsecureNextAsciiRange() {
        for (int i = 0; i < 10; i++) {
            final String s = RandomStringUtils.insecure().nextAscii(2, 6);
            assertTrue(s.length() >= 2 && s.length() < 6);
        }
    }

    @Test
    public void testInsecureNextGraphRange() {
        for (int i = 0; i < 10; i++) {
            final String s = RandomStringUtils.insecure().nextGraph(2, 6);
            assertTrue(s.length() >= 2 && s.length() < 6);
        }
    }

    @Test
    public void testInsecureNextNumericRange() {
        for (int i = 0; i < 10; i++) {
            final String s = RandomStringUtils.insecure().nextNumeric(2, 6);
            assertTrue(s.length() >= 2 && s.length() < 6);
            for (int j = 0; j < s.length(); j++) {
                assertTrue(Character.isDigit(s.charAt(j)));
            }
        }
    }

    @Test
    public void testInsecureNextPrintRange() {
        for (int i = 0; i < 10; i++) {
            final String s = RandomStringUtils.insecure().nextPrint(2, 6);
            assertTrue(s.length() >= 2 && s.length() < 6);
        }
    }

    @Test
    public void testInsecureNextWithCharsVarargs() {
        final String s = RandomStringUtils.insecure().next(10, 'x', 'y');
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y');
        }
    }

    @Test
    public void testInsecureNextWithNullCharsVarargs() {
        final String s = RandomStringUtils.insecure().next(10, (char[]) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testInsecureNextWithCharsString() {
        final String s = RandomStringUtils.insecure().next(10, "qp");
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'q' || c == 'p');
        }
    }

    @Test
    public void testInsecureNextWithNullCharsString() {
        final String s = RandomStringUtils.insecure().next(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testInsecureNextZeroCount() {
        assertEquals("", RandomStringUtils.insecure().next(0));
    }

    @Test
    public void testInsecureNextNegativeCountThrows() {
        try {
            RandomStringUtils.insecure().next(-5);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testToStringContainsClassName() {
        final String s = RandomStringUtils.secure().toString();
        assertTrue(s.startsWith("RandomStringUtils ["));
    }

    @Test
    public void testDeprecatedNoArgConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        final String s = instance.toString();
        assertFalse(s.isEmpty());
    }

    @Test
    public void testRandomWithStartEndLettersNumbersDeprecatedMethod() {
        final String s = RandomStringUtils.random(10, '0', '9' + 1, false, true);
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    public void testRandomSingleCodePointHighSurrogateEdge() {
        final String s = RandomStringUtils.random(3, 0, 0, false, false, null, new Random(7L));
        assertEquals(3, s.length());
    }
}
