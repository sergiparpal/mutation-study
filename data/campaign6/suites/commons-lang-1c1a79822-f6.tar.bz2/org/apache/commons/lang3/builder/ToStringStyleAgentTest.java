/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ToStringStyle}.
 */
class ToStringStyleAgentTest {

    /**
     * Minimal concrete subclass used to instantiate the abstract {@link ToStringStyle}.
     */
    private static final class PlainStyle extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    private static final class Fixture {
        @SuppressWarnings("unused")
        String name = "John";
        @SuppressWarnings("unused")
        int age = 42;
    }

    @Test
    void testAppendBoolean() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "flag", true);
        assertEquals("flag=true,", buffer.toString());
    }

    @Test
    void testAppendBooleanArrayNull() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (boolean[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    @Test
    void testAppendBooleanArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new boolean[] {true, false}, Boolean.TRUE);
        assertEquals("arr={true,false},", buffer.toString());
    }

    @Test
    void testAppendBooleanArraySummary() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new boolean[] {true, false, true}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    @Test
    void testAppendIntArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.TRUE);
        assertEquals("arr={1,2,3},", buffer.toString());
    }

    @Test
    void testAppendObjectNull() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "obj", (Object) null, Boolean.TRUE);
        assertEquals("obj=<null>,", buffer.toString());
    }

    @Test
    void testAppendObjectDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "obj", "hello", Boolean.TRUE);
        assertEquals("obj=hello,", buffer.toString());
    }

    @Test
    void testAppendObjectSummary() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "obj", "hello", Boolean.FALSE);
        assertEquals("obj=<String>,", buffer.toString());
    }

    @Test
    void testAppendObjectArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new Object[] {"a", "b"}, Boolean.TRUE);
        assertEquals("arr={a,b},", buffer.toString());
    }

    @Test
    void testAppendStartAndEndDefaultStyle() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        final Fixture fixture = new Fixture();
        style.appendStart(buffer, fixture);
        style.append(buffer, "name", fixture.name, Boolean.TRUE);
        style.appendEnd(buffer, fixture);
        final String result = buffer.toString();
        assertTrue(result.startsWith(Fixture.class.getName() + "@"), "Expected class name prefix in: " + result);
        assertTrue(result.endsWith("[name=John]"), "Expected content and no trailing separator in: " + result);
        assertFalse(ToStringStyle.isRegistered(fixture), "Object should be unregistered after appendEnd");
    }

    @Test
    void testAppendStartNullObject() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    @Test
    void testAppendClassNameDisabled() {
        final ToStringStyle style = new PlainStyle();
        style.setUseClassName(false);
        final StringBuffer buffer = new StringBuffer();
        final Object object = new Object();
        style.appendStart(buffer, object);
        style.appendEnd(buffer, object);
        assertFalse(buffer.toString().contains("Object"), "Class name should not be present: " + buffer);
    }

    @Test
    void testAppendIdentityHashCodeDisabled() {
        final ToStringStyle style = new PlainStyle();
        style.setUseIdentityHashCode(false);
        final StringBuffer buffer = new StringBuffer();
        final Object object = new Object();
        style.appendStart(buffer, object);
        style.appendEnd(buffer, object);
        assertFalse(buffer.toString().contains("@"), "Identity hash code should not be present: " + buffer);
    }

    @Test
    void testIsFullDetailNullUsesDefault() {
        final ToStringStyle style = new PlainStyle();
        assertTrue(invokeIsFullDetail(style, null), "Default full detail should be true");
    }

    @Test
    void testIsFullDetailExplicit() {
        final ToStringStyle style = new PlainStyle();
        assertTrue(invokeIsFullDetail(style, Boolean.TRUE));
        assertFalse(invokeIsFullDetail(style, Boolean.FALSE));
    }

    @Test
    void testIsFullDetailRespectsDefaultFullDetailFlag() {
        final ToStringStyle style = new PlainStyle();
        style.setDefaultFullDetail(false);
        assertFalse(invokeIsFullDetail(style, null));
        assertFalse(style.isDefaultFullDetail());
    }

    private boolean invokeIsFullDetail(final ToStringStyle style, final Boolean request) {
        return style.isFullDetail(request);
    }

    @Test
    void testAppendFieldStartUsesFieldNamesByDefault() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "field", 1);
        assertTrue(buffer.toString().startsWith("field="), "Expected field name in: " + buffer);
    }

    @Test
    void testAppendFieldStartWithUseFieldNamesDisabled() {
        final ToStringStyle style = new PlainStyle();
        style.setUseFieldNames(false);
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "field", 1);
        assertEquals("1,", buffer.toString());
    }

    @Test
    void testAppendFieldStartWithNullFieldName() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, null, 5);
        assertEquals("5,", buffer.toString());
    }

    @Test
    void testRemoveLastFieldSeparator() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer("abc,");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abc", buffer.toString());
    }

    @Test
    void testRemoveLastFieldSeparatorWhenAbsent() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer("abc");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abc", buffer.toString());
    }

    @Test
    void testFieldSeparatorAtEndKeepsTrailingSeparator() {
        final ToStringStyle style = new PlainStyle();
        style.setFieldSeparatorAtEnd(true);
        final StringBuffer buffer = new StringBuffer();
        final Object object = new Object();
        style.appendStart(buffer, object);
        style.append(buffer, "a", 1);
        style.appendEnd(buffer, object);
        assertTrue(buffer.toString().contains(",]"), "Expected trailing separator before content end in: " + buffer);
    }

    @Test
    void testAppendDetailCollection() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<String> list = new ArrayList<>();
        list.add("x");
        list.add("y");
        style.append(buffer, "list", (Object) list, Boolean.TRUE);
        assertEquals("list=[x, y],", buffer.toString());
    }

    @Test
    void testAppendDetailEmptyCollection() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "list", (Object) new ArrayList<String>(), Boolean.TRUE);
        assertEquals("list=[],", buffer.toString());
    }

    @Test
    void testAppendSummaryCollection() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<String> list = new ArrayList<>();
        list.add("x");
        list.add("y");
        list.add("z");
        style.append(buffer, "list", (Object) list, Boolean.FALSE);
        assertEquals("list=<size=3>,", buffer.toString());
    }

    @Test
    void testAppendDetailMap() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        final Map<String, Integer> map = new LinkedHashMap<>();
        map.put("a", 1);
        style.append(buffer, "map", (Object) map, Boolean.TRUE);
        assertEquals("map={a=1},", buffer.toString());
    }

    @Test
    void testGettersReflectDefaults() {
        final ToStringStyle style = new PlainStyle();
        assertEquals("[", style.getContentStart());
        assertEquals("]", style.getContentEnd());
        assertEquals("=", style.getFieldNameValueSeparator());
        assertEquals(",", style.getFieldSeparator());
        assertEquals("{", style.getArrayStart());
        assertEquals("}", style.getArrayEnd());
        assertEquals(",", style.getArraySeparator());
        assertEquals("<null>", style.getNullText());
        assertEquals("<size=", style.getSizeStartText());
        assertEquals(">", style.getSizeEndText());
        assertEquals("<", style.getSummaryObjectStartText());
        assertEquals(">", style.getSummaryObjectEndText());
        assertTrue(style.isUseClassName());
        assertTrue(style.isUseFieldNames());
        assertTrue(style.isUseIdentityHashCode());
        assertFalse(style.isUseShortClassName());
        assertTrue(style.isArrayContentDetail());
        assertTrue(style.isDefaultFullDetail());
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
    }

    @Test
    void testSetArrayStartNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());
    }

    @Test
    void testSetArrayEndNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());
    }

    @Test
    void testSetArraySeparatorNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());
    }

    @Test
    void testSetContentStartNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setContentStart(null);
        assertEquals("", style.getContentStart());
    }

    @Test
    void testSetContentEndNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());
    }

    @Test
    void testSetFieldNameValueSeparatorNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());
    }

    @Test
    void testSetFieldSeparatorNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());
    }

    @Test
    void testSetNullTextNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setNullText(null);
        assertEquals("", style.getNullText());
    }

    @Test
    void testSetSizeStartTextNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());
    }

    @Test
    void testSetSizeEndTextNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());
    }

    @Test
    void testSetSummaryObjectStartTextNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());
    }

    @Test
    void testSetSummaryObjectEndTextNullBecomesEmpty() {
        final ToStringStyle style = new PlainStyle();
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());
    }

    @Test
    void testSetUseShortClassNameTrue() {
        final ToStringStyle style = new PlainStyle();
        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
        final StringBuffer buffer = new StringBuffer();
        final Object object = new Object();
        style.appendStart(buffer, object);
        style.appendEnd(buffer, object);
        assertTrue(buffer.toString().startsWith("Object@"), "Expected short class name in: " + buffer);
    }

    @Test
    void testSetArrayContentDetailFalseUsesSummaryForNestedArrays() {
        final ToStringStyle style = new PlainStyle();
        style.setArrayContentDetail(false);
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new Object[] {new int[] {1, 2, 3}}, Boolean.TRUE);
        assertEquals("arr={<size=3>},", buffer.toString());
    }

    @Test
    void testReflectionAppendArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.reflectionAppendArrayDetail(buffer, "arr", new int[] {7, 8});
        assertEquals("{7,8}", buffer.toString());
    }

    @Test
    void testAppendSuperWithContent() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendSuper(buffer, "Fixture@1[a=1]");
        assertEquals("a=1,", buffer.toString());
    }

    @Test
    void testAppendSuperWithNull() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer("existing,");
        style.appendSuper(buffer, null);
        assertEquals("existing,", buffer.toString());
    }

    @Test
    void testAppendSuperWithEmptyContent() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer("existing,");
        style.appendSuper(buffer, "Fixture@1[]");
        assertEquals("existing,", buffer.toString());
    }

    @Test
    void testAppendToString() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendToString(buffer, "Other@2[b=2]");
        assertEquals("b=2,", buffer.toString());
    }

    @Test
    void testGetShortClassName() {
        final ToStringStyle style = new PlainStyle();
        assertEquals("String", style.getShortClassName(String.class));
    }

    @Test
    void testRegistryRegisterAndUnregister() {
        final Object object = new Object();
        assertFalse(ToStringStyle.isRegistered(object));
        ToStringStyle.register(object);
        assertTrue(ToStringStyle.isRegistered(object));
        ToStringStyle.unregister(object);
        assertFalse(ToStringStyle.isRegistered(object));
    }

    @Test
    void testRegistryUnregisterNullIsNoOp() {
        ToStringStyle.unregister(null);
        assertFalse(ToStringStyle.isRegistered(null));
    }

    @Test
    void testGetRegistryNotNull() {
        assertNotNull(ToStringStyle.getRegistry());
    }

    @Test
    void testAppendInternalCyclicObjectDetected() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<Object> list = new ArrayList<>();
        list.add("first");
        ToStringStyle.register(list);
        try {
            style.append(buffer, "self", (Object) list, Boolean.TRUE);
            final String result = buffer.toString();
            assertTrue(result.contains("@"), "Expected identity-hash cyclic representation in: " + result);
        } finally {
            ToStringStyle.unregister(list);
        }
    }

    @Test
    void testPredefinedStylesAreNotNullAndDistinct() {
        assertNotNull(ToStringStyle.DEFAULT_STYLE);
        assertNotNull(ToStringStyle.MULTI_LINE_STYLE);
        assertNotNull(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertNotNull(ToStringStyle.SHORT_PREFIX_STYLE);
        assertNotNull(ToStringStyle.SIMPLE_STYLE);
        assertNotNull(ToStringStyle.NO_CLASS_NAME_STYLE);
        assertNotNull(ToStringStyle.JSON_STYLE);
    }

    @Test
    void testAppendCharArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "chars", new char[] {'a', 'b', 'c'}, Boolean.TRUE);
        assertEquals("chars={a,b,c},", buffer.toString());
    }

    @Test
    void testAppendByteArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "bytes", new byte[] {1, 2}, Boolean.TRUE);
        assertEquals("bytes={1,2},", buffer.toString());
    }

    @Test
    void testAppendShortArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "shorts", new short[] {1, 2}, Boolean.TRUE);
        assertEquals("shorts={1,2},", buffer.toString());
    }

    @Test
    void testAppendLongArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "longs", new long[] {1L, 2L}, Boolean.TRUE);
        assertEquals("longs={1,2},", buffer.toString());
    }

    @Test
    void testAppendFloatArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "floats", new float[] {1.5f, 2.5f}, Boolean.TRUE);
        assertEquals("floats={1.5,2.5},", buffer.toString());
    }

    @Test
    void testAppendDoubleArrayDetail() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "doubles", new double[] {1.5, 2.5}, Boolean.TRUE);
        assertEquals("doubles={1.5,2.5},", buffer.toString());
    }

    @Test
    void testAppendObjectArrayNull() {
        final ToStringStyle style = new PlainStyle();
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (Object[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

}
