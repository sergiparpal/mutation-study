/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    // --- Builder.create() defaults ---------------------------------------------------------------------------

    @Test
    void testBuilderCreateDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("NULL").get();
        final CSVFormat copyFormat = CSVFormat.Builder.create(original).get();
        assertEquals(original, copyFormat);
        assertNotSame(original, copyFormat);
    }

    // --- newFormat ---------------------------------------------------------------------------------------------

    @Test
    void testNewFormatBasicDefaults() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals("|", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getCommentMarker());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertNull(format.getNullString());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\n'));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\r'));
    }

    // --- Builder setter validation -------------------------------------------------------------------------

    @Test
    void testSetDelimiterRejectsEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(""));
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter("a\nb"));
    }

    @Test
    void testSetDelimiterRejectsNull() {
        assertThrows(NullPointerException.class, () -> CSVFormat.Builder.create().setDelimiter((String) null));
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setQuote('\r'));
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setEscape('\n'));
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setCommentMarker('\n'));
    }

    @Test
    void testSetDuplicateHeaderModeRejectsNull() {
        assertThrows(NullPointerException.class, () -> CSVFormat.Builder.create().setDuplicateHeaderMode(null));
    }

    // --- validate() via get() -------------------------------------------------------------------------------

    @Test
    void testValidateRejectsQuoteEqualsDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote(',').get());
    }

    @Test
    void testValidateRejectsEscapeEqualsDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape(',').get());
    }

    @Test
    void testValidateRejectsCommentEqualsDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker(',').get());
    }

    @Test
    void testValidateRejectsQuoteEqualsComment() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('#').setQuote('#').get());
    }

    @Test
    void testValidateRejectsEscapeEqualsComment() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('#').get());
    }

    @Test
    void testValidateRejectsQuoteModeNoneWithoutEscape() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testValidateAllowsQuoteModeNoneWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateRejectsDuplicateHeadersWhenDisallowed() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a").get());
    }

    @Test
    void testValidateAllowsDuplicateEmptyHeadersWhenAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "").get();
        assertEquals(2, format.getHeader().length);
    }

    @Test
    void testValidateRejectsDuplicateEmptyHeadersWhenDisallowed() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("", "").get());
    }

    @Test
    void testValidateAllowsDuplicateHeadersWhenAllowAll() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "a").get();
        assertEquals(2, format.getHeader().length);
    }

    // --- getHeader() / getHeaderComments() copying semantics -----------------------------------------------

    @Test
    void testSetHeaderCopiesInputArray() {
        final String[] header = {"a", "b"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        header[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderReturnsFreshCopyEachTime() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] got = format.getHeader();
        got[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsFreshCopyEachTime() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] got = format.getHeaderComments();
        got[0] = "mutated";
        assertEquals("c1", format.getHeaderComments()[0]);
    }

    @Test
    void testGetHeaderNullWhenDisabled() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertNull(format.getHeader());
    }

    // --- equals / hashCode -----------------------------------------------------------------------------------

    @Test
    void testEqualsReflexiveAndEqualFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final CSVFormat a = CSVFormat.DEFAULT;
        assertNotEquals(null, a);
        assertNotEquals("not a format", a);
    }

    @Test
    void testEqualsDetectsDifference() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(':').get();
        assertNotEquals(a, b);
    }

    // --- toString ----------------------------------------------------------------------------------------------

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringContainsHeaderWhenSet() {
        final String str = CSVFormat.DEFAULT.builder().setHeader("a", "b").get().toString();
        assertTrue(str.contains("Header:[a, b]"));
    }

    // --- deprecated getDelimiter() ------------------------------------------------------------------------------

    @Test
    void testGetDelimiterReturnsFirstCharOfMultiCharDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals(':', format.getDelimiter());
        assertEquals("::", format.getDelimiterString());
    }

    // --- builder() / copy immutability --------------------------------------------------------------------------

    @Test
    void testBuilderDerivedFormatDoesNotMutateOriginal() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat derived = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", derived.getDelimiterString());
    }

    // --- format(Object...) ---------------------------------------------------------------------------------------

    @Test
    void testFormatSimpleValues() {
        assertEquals("a,b", CSVFormat.DEFAULT.format("a", "b"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\"", CSVFormat.DEFAULT.format("a,b"));
    }

    @Test
    void testFormatEscapesEmbeddedQuoteByDoubling() {
        assertEquals("\"a\"\"b\"", CSVFormat.DEFAULT.format("a\"b"));
    }

    // --- print(Object, Appendable, boolean) ------------------------------------------------------------------

    @Test
    void testPrintPlainValueNoQuotingNeeded() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.RFC4180.print("abc", sb, true);
        assertEquals("abc", sb.toString());
    }

    @Test
    void testPrintAddsDelimiterWhenNotFirstValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.RFC4180.print("abc", sb, false);
        assertEquals(",abc", sb.toString());
    }

    @Test
    void testPrintNullValueWithoutNullStringIsEmpty() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintNullValueWithNullStringIsUnquoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.builder().setNullString("NULL").get().print(null, sb, true);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimEnabled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.builder().setTrim(true).get().print("  abc  ", sb, true);
        assertEquals("abc", sb.toString());
    }

    // --- printRecord / println ------------------------------------------------------------------------------

    @Test
    void testPrintRecordWritesDelimiterAndRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b");
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterWhenEnabled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get().println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    void testPrintlnNoTrailingDelimiterByDefault() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    // --- parse / print(Appendable) integration --------------------------------------------------------------

    @Test
    void testParseReadsRecordsAccordingToFormat() throws IOException {
        final Reader reader = new StringReader("a,b\r\nc,d\r\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        final java.util.List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("d", records.get(1).get(1));
        parser.close();
    }

    @Test
    void testPrintAppendableWritesHeaderWhenConfigured() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = CSVFormat.DEFAULT.builder().setHeader("x", "y").get().print(sb);
        printer.close();
        assertEquals("x,y\r\n", sb.toString());
    }

    // --- valueOf / Predefined --------------------------------------------------------------------------------

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test
    void testValueOfRejectsUnknownName() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NotARealFormat"));
    }

    // --- predefined format field sanity checks -----------------------------------------------------------------

    @Test
    void testExcelPredefinedSettings() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testMySqlPredefinedSettings() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    void testTdfPredefinedSettings() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnEmptyLines() {
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    // --- isXxxSet predicates --------------------------------------------------------------------------------

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.builder().setQuote(null).get().isQuoteCharacterSet());
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertTrue(CSVFormat.DEFAULT.builder().setEscape('\\').get().isEscapeCharacterSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertTrue(CSVFormat.DEFAULT.builder().setCommentMarker('#').get().isCommentMarkerSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    // --- getMaxRows / useMaxRows / useRow ------------------------------------------------------------------------

    @Test
    void testMaxRowsDefaultsToNoLimit() {
        assertEquals(0, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        assertTrue(CSVFormat.DEFAULT.useRow(1000L));
    }

    @Test
    void testMaxRowsLimitsRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        assertEquals(2, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    // --- getAllowDuplicateHeaderNames (deprecated) bridges to DuplicateHeaderMode -----------------------------

    @Test
    void testAllowDuplicateHeaderNamesBridge() {
        final CSVFormat allowAll = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        final CSVFormat disallow = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertTrue(allowAll.getAllowDuplicateHeaderNames());
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    // --- Builder.setNullString quotedNullString computation ----------------------------------------------------

    @Test
    void testNullStringIsQuotedWhenQuoteModeAll() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("\"NULL\"", sb.toString());
    }

    @Test
    void testNullStringQuotedCorrectlyRegardlessOfSetterOrder() throws IOException {
        // setNullString() is called while the quote character is still unset (null); CSVFormat must still
        // produce a correctly quoted representation once a quote character is in effect for QuoteMode.ALL.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setNullString("NULL").setQuote('|').setQuoteMode(QuoteMode.ALL).get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("|NULL|", sb.toString());
    }

    @Test
    void testNullStringNotCorruptedWhenQuoteCharacterUnsetAtSetNullStringTime() throws IOException {
        // Builder.setNullString() precomputes a "quoted" null string using whatever quote character is set
        // at that moment, with no fallback for a null quote character (unlike setQuote(), which falls back
        // to the default double-quote character). When the quote character is disabled before setNullString()
        // is called, and never re-set afterwards, the resulting nullString representation must still be the
        // plain nullString text, not have the literal word "null" spliced onto it.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("NULL", sb.toString());
    }
}
