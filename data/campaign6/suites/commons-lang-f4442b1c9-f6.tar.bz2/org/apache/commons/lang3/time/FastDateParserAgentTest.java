/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}.
 *
 * <p>Note: this test class lives in the same package as {@link FastDateParser} because its
 * constructors are {@code protected}.</p>
 */
class FastDateParserAgentTest {

    private static final TimeZone LA = TimeZone.getTimeZone("America/Los_Angeles");

    private static Date dateOf(final TimeZone tz, final int year, final int month, final int day) {
        final Calendar cal = Calendar.getInstance(tz, Locale.US);
        cal.clear();
        cal.set(year, month, day);
        return cal.getTime();
    }

    private static int yearOf(final TimeZone tz, final Date date) {
        final Calendar cal = Calendar.getInstance(tz, Locale.US);
        cal.setTime(date);
        return cal.get(Calendar.YEAR);
    }

    // --- basic parsing ---

    @Test
    void testParseBasicDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final Date parsed = parser.parse("2020-05-01");
        final Calendar cal = Calendar.getInstance(LA, Locale.US);
        cal.setTime(parsed);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MAY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithTimeFields() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm:ss", LA, Locale.US);
        final Date parsed = parser.parse("2020-05-01 13:45:30");
        final Calendar cal = Calendar.getInstance(LA, Locale.US);
        cal.setTime(parsed);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(45, cal.get(Calendar.MINUTE));
        assertEquals(30, cal.get(Calendar.SECOND));
    }

    @Test
    void testParseAllowsPartialConsumptionOfInput() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy", LA, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date parsed = parser.parse("1999extra", pos);
        assertNotNull(parsed);
        assertEquals(4, pos.getIndex());
        assertEquals(1999, yearOf(LA, parsed));
    }

    @Test
    void testCaseInsensitiveMonthNameParsing() {
        final FastDateParser parser = new FastDateParser("MMM", LA, Locale.US);
        final Calendar lower = Calendar.getInstance(LA, Locale.US);
        lower.clear();
        assertTrue(parser.parse("jan", new ParsePosition(0), lower));
        assertEquals(Calendar.JANUARY, lower.get(Calendar.MONTH));

        final Calendar upper = Calendar.getInstance(LA, Locale.US);
        upper.clear();
        assertTrue(parser.parse("JAN", new ParsePosition(0), upper));
        assertEquals(Calendar.JANUARY, upper.get(Calendar.MONTH));
    }

    @Test
    void testGmtOffsetTimeZoneParsing() {
        final FastDateParser parser = new FastDateParser("z", LA, Locale.US);
        final Calendar cal = Calendar.getInstance(LA, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        assertTrue(parser.parse("GMT+02:00", pos, cal));
        assertEquals(-1, pos.getErrorIndex());
        assertEquals(2 * 60 * 60 * 1000, cal.get(Calendar.ZONE_OFFSET));
    }

    @Test
    void testIso8601TimeZoneOffsetParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXX", LA, Locale.US);
        final Date parsed = parser.parse("2020-05-01T10:00:00+02:00");
        final Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        utc.setTime(parsed);
        assertEquals(8, utc.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, utc.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MAY, utc.get(Calendar.MONTH));
    }

    @Test
    void testWeekYearPattern() {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", LA, Locale.US);
        final Calendar cal = Calendar.getInstance(LA, Locale.US);
        cal.setMinimalDaysInFirstWeek(4);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.clear();
        assertTrue(parser.parse("2008-W01-1", new ParsePosition(0), cal));
        assertEquals(dateOf(LA, 2007, Calendar.DECEMBER, 31), cal.getTime());
    }

    // --- getters ---

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.FRANCE);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.FRANCE, parser.getLocale());
        assertEquals(LA, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = new FastDateParser("yyyy", LA, Locale.US);
        final TimeZone first = parser.getTimeZone();
        first.setRawOffset(123456);
        final TimeZone second = parser.getTimeZone();
        assertEquals(LA.getRawOffset(), second.getRawOffset());
    }

    @Test
    void testNullLocaleDefaultsToSystemDefault() {
        final FastDateParser parser = new FastDateParser("yyyy", LA, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    // --- equals / hashCode / toString ---

    @Test
    void testEqualsAndHashCodeForEqualParsers() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDistinguishesPatternTimeZoneLocale() {
        final FastDateParser base = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        assertNotEquals(base, new FastDateParser("yyyy/MM/dd", LA, Locale.US));
        assertNotEquals(base, new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US));
        assertNotEquals(base, new FastDateParser("yyyy-MM-dd", LA, Locale.FRANCE));
    }

    @Test
    void testEqualsNullAndDifferentType() {
        final FastDateParser parser = new FastDateParser("yyyy", LA, Locale.US);
        assertFalse(parser.equals(null));
        assertFalse(parser.equals("yyyy"));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZoneId() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains(LA.getID()));
    }

    // --- failure / boundary handling ---

    @Test
    void testParseStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final ParseException thrown = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(thrown.getErrorOffset() >= 0);
    }

    @Test
    void testParseStringParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("20xx-01-01", pos);
        assertNull(result);
        assertEquals(2, pos.getErrorIndex());
    }

    @Test
    void testParsePositionIndexBeyondSourceLengthFailsWithoutThrowing() {
        final FastDateParser parser = new FastDateParser("yyyy", LA, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date result = parser.parse("1999", pos);
        assertNull(result);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseCalendarOverloadDoesNotEagerlyValidateNonLenientCalendar() {
        final FastDateParser parser = new FastDateParser("MM/dd/yyyy", LA, Locale.US);
        final Calendar cal = Calendar.getInstance(LA, Locale.US);
        cal.clear();
        cal.setLenient(false);
        final ParsePosition pos = new ParsePosition(0);
        // February 30th does not exist; NumberStrategy does not range-check individual fields.
        assertTrue(parser.parse("02/30/2021", pos, cal));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                cal.getTime();
            }
        });
    }

    @Test
    void testOverflowingDigitRunFailsGracefullyInsteadOfThrowing() {
        final FastDateParser parser = new FastDateParser("yyyy", LA, Locale.US);
        // More digits than fit in an int; must be reported as an unparseable date, not a NumberFormatException.
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("99999999999999");
            }
        });
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("99999999999999", pos));
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testConstructorRejectsNullPattern() {
        final NullPointerException thrown = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, LA, Locale.US);
            }
        });
        assertEquals("pattern", thrown.getMessage());
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        final NullPointerException thrown = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
        assertEquals("timeZone", thrown.getMessage());
    }

    @Test
    void testConstructorRejectsUnsupportedPatternLetter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("Q", LA, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsUnterminatedQuote() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'bad", LA, Locale.US);
            }
        });
    }

    // --- two digit year / century adjustment ---

    @Test
    void testTwoDigitYearCenturyAdjustmentBoundary() throws ParseException {
        final Date centuryStart = dateOf(LA, 1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", LA, Locale.US, centuryStart);
        assertEquals(2049, yearOf(LA, parser.parse("49")));
        assertEquals(1950, yearOf(LA, parser.parse("50")));
        assertEquals(1999, yearOf(LA, parser.parse("99")));
        assertEquals(2000, yearOf(LA, parser.parse("00")));
    }

    // --- parseObject delegation ---

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final Object parsed = parser.parseObject("2020-05-01");
        assertEquals(parser.parse("2020-05-01"), parsed);
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parseObject("garbage");
            }
        });
    }

    @Test
    void testParseObjectWithParsePositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object parsed = parser.parseObject("2020-05-01", pos);
        assertEquals(10, pos.getIndex());
        assertTrue(parsed instanceof Date);
    }

    // --- serialization ---

    @Test
    void testSerializationRoundTripPreservesBehavior() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", LA, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, deserialized);
        assertEquals(parser.parse("2021-06-15"), deserialized.parse("2021-06-15"));
    }
}
