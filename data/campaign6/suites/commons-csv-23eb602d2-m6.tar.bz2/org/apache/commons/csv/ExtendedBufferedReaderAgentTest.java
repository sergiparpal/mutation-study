/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    private ExtendedBufferedReader createTrackingBytes(final String s) {
        return new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testGetPositionTracksSingleCharReads() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals('a', br.read());
        assertEquals(1, br.getPosition());
        assertEquals('b', br.read());
        assertEquals(2, br.getPosition());
        assertEquals('c', br.read());
        assertEquals(3, br.getPosition());
        assertEquals(EOF, br.read());
        // EOF is still counted as a read.
        assertEquals(4, br.getPosition());
        br.close();
    }

    @Test
    void testGetPositionTracksBulkReads() throws IOException {
        final ExtendedBufferedReader br = create("abcdef");
        final char[] buf = new char[4];
        assertEquals(4, br.read(buf, 0, 4));
        assertEquals(4, br.getPosition());
        assertEquals(2, br.read(buf, 0, 4));
        assertEquals(6, br.getPosition());
        // An EOF result (-1) is added to the position as-is.
        assertEquals(EOF, br.read(buf, 0, 4));
        assertEquals(5, br.getPosition());
        br.close();
    }

    @Test
    void testReadZeroLengthDoesNotConsumeOrMove() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        final char[] buf = new char[10];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('a', br.peek());
        br.close();
    }

    @Test
    void testPeekDoesNotConsume() throws IOException {
        final ExtendedBufferedReader br = create("ab");
        assertEquals('a', br.peek());
        assertEquals('a', br.peek());
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('a', br.read());
        assertEquals('b', br.peek());
        assertEquals('a', br.getLastChar());
        br.close();
    }

    @Test
    void testPeekAtEof() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertEquals(EOF, br.peek());
        assertEquals(EOF, br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        br.close();
    }

    @Test
    void testGetLineNumberStartsAtZero() throws IOException {
        final ExtendedBufferedReader br = create("a\nb\n");
        assertEquals(0, br.getLineNumber());
        br.read(); // 'a': mid-line, counter allows for the upcoming EOL.
        assertEquals(1, br.getLineNumber());
        br.read(); // '\n': completes line 1.
        assertEquals(1, br.getLineNumber());
        br.read(); // 'b': mid-line 2.
        assertEquals(2, br.getLineNumber());
        br.read(); // '\n': completes line 2.
        assertEquals(2, br.getLineNumber());
        assertEquals(EOF, br.read());
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadLineEmptyInputReturnsNull() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertNull(br.readLine());
        // readLine() only peeks at EOF without consuming, so lastChar is untouched.
        assertEquals(UNDEFINED, br.getLastChar());
        br.close();
    }

    @Test
    void testReadLineNoTrailingTerminator() throws IOException {
        final ExtendedBufferedReader br = create("hello");
        assertEquals("hello", br.readLine());
        assertEquals(EOF, br.getLastChar());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testReadLineHandlesCrLfAsOneTerminator() throws IOException {
        final ExtendedBufferedReader br = create("foo\r\nbar");
        assertEquals("foo", br.readLine());
        assertEquals(1, br.getLineNumber());
        assertEquals("bar", br.readLine());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testMarkAndResetRestoreAllTrackedState() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd");
        br.read(); // 'a'
        br.mark(10);
        final long markedPosition = br.getPosition();
        final long markedLineNumber = br.getLineNumber();
        final int markedLastChar = br.getLastChar();

        br.read(); // 'b'
        br.read(); // '\n'
        br.read(); // 'c'
        assertTrue(br.getPosition() > markedPosition);

        br.reset();
        assertEquals(markedPosition, br.getPosition());
        assertEquals(markedLineNumber, br.getLineNumber());
        assertEquals(markedLastChar, br.getLastChar());

        // Reading again after reset replays the same characters.
        assertEquals('b', br.read());
        assertEquals('\n', br.read());
        assertEquals('c', br.read());
        br.close();
    }

    @Test
    void testBytesReadIsZeroWithoutCharsetTracking() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.read();
        br.read();
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadForAsciiCharsIsOneBytePerChar() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("ab");
        assertEquals('a', br.read());
        assertEquals(1, br.getBytesRead());
        assertEquals('b', br.read());
        assertEquals(2, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadForMultiByteAndSurrogatePairChars() throws IOException {
        // U+00E9 (e acute) is 2 bytes in UTF-8; U+1F600 (grinning face) is a
        // surrogate pair in UTF-16 and 4 bytes in UTF-8.
        final String input = "é😀";
        final ExtendedBufferedReader br = createTrackingBytes(input);
        assertEquals('é', br.read());
        assertEquals(2, br.getBytesRead());
        // High surrogate alone contributes 0 bytes until paired.
        assertEquals('\ud83d', br.read());
        assertEquals(2, br.getBytesRead());
        // Low surrogate completes the pair, contributing the full 4 bytes.
        assertEquals('\ude00', br.read());
        assertEquals(6, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadThrowsOnUnpairedLowSurrogate() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("\ude00");
        assertThrows(CharacterCodingException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
        br.close();
    }

    @Test
    void testMarkAndResetRestoreBytesRead() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("ab");
        br.read();
        br.mark(10);
        final long markedBytes = br.getBytesRead();
        br.read();
        assertTrue(br.getBytesRead() > markedBytes);
        br.reset();
        assertEquals(markedBytes, br.getBytesRead());
        br.close();
    }
}
