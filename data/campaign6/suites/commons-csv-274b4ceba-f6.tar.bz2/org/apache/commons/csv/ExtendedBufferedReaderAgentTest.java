/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private static final String CR = "\r";
    private static final String LF = "\n";
    private static final String CRLF = CR + LF;
    private static final String LFCR = LF + CR;

    private ExtendedBufferedReader of(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialState() throws IOException {
        try (ExtendedBufferedReader br = of("abc")) {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getLineNumber());
            assertEquals(0, br.getPosition());
            assertEquals(0, br.getBytesRead());
        }
    }

    @Test
    void testPeekDoesNotConsumeOrMutateState() throws IOException {
        try (ExtendedBufferedReader br = of("ab")) {
            assertEquals('a', br.peek());
            assertEquals('a', br.peek());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('a', br.read());
            assertEquals('a', br.getLastChar());
            assertEquals(1, br.getPosition());
        }
    }

    @Test
    void testReadSingleCharUpdatesState() throws IOException {
        try (ExtendedBufferedReader br = of("ab")) {
            assertEquals('a', br.read());
            assertEquals('a', br.getLastChar());
            assertEquals(1, br.getPosition());
            // No EOL seen yet, but a non-EOL last char implies we are on line 1.
            assertEquals(1, br.getLineNumber());
            assertEquals('b', br.read());
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
            assertEquals(1, br.getLineNumber());
        }
    }

    @Test
    void testReadAtEofOfEmptyInput() throws IOException {
        // Bug: read()'s line-increment condition excludes a previous CR/LF/EOF
        // lastChar but forgets to exclude UNDEFINED, so hitting EOF on a reader
        // that has never read a real character bumps an empty input's line
        // count from 0 to 1.
        try (ExtendedBufferedReader br = of("")) {
            assertEquals(EOF, br.peek());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
            assertEquals(0, br.getLineNumber());
            assertNull(br.readLine());
        }
    }

    @Test
    void testGetLineNumberCountsFinalLineWithoutTrailingNewline() throws IOException {
        try (ExtendedBufferedReader br = of("abc")) {
            assertEquals('a', br.read());
            assertEquals('b', br.read());
            assertEquals('c', br.read());
            assertEquals(1, br.getLineNumber());
            assertEquals(EOF, br.read());
            assertEquals(1, br.getLineNumber());
            // Reading EOF again must not keep incrementing the line count.
            assertEquals(EOF, br.read());
            assertEquals(1, br.getLineNumber());
        }
    }

    @Test
    void testPositionDoesNotGrowOnRepeatedEofReads() throws IOException {
        // Bug: ExtendedBufferedReader.read() increments `position` unconditionally,
        // even when the underlying reader returns EOF and no character was consumed.
        // getPosition() should report the number of characters actually read (2),
        // not keep growing on every subsequent EOF read.
        try (ExtendedBufferedReader br = of("ab")) {
            assertEquals('a', br.read());
            assertEquals('b', br.read());
            assertEquals(EOF, br.read());
            assertEquals(2, br.getPosition());
            assertEquals(EOF, br.read());
            assertEquals(2, br.getPosition());
            assertEquals(EOF, br.read());
            assertEquals(2, br.getPosition());
        }
    }

    @Test
    void testBulkReadPositionNeverDecreasesAtEof() throws IOException {
        // Bug: read(char[], int, int) does `position += len`, and len is EOF (-1)
        // when nothing could be read, so position goes DOWN instead of staying put.
        try (ExtendedBufferedReader br = of("ab")) {
            final char[] buf = new char[5];
            assertEquals(2, br.read(buf, 0, 5));
            assertEquals(2, br.getPosition());
            assertEquals(EOF, br.read(buf, 0, 5));
            assertEquals(2, br.getPosition());
        }
    }

    @Test
    void testByteTrackingDoesNotCountEofSentinel() throws IOException {
        // Bug: read() calls getEncodedCharLength(current) even when current == EOF,
        // which encodes the sentinel value -1 (cast to char 0xFFFF) as if it were a
        // real character, spuriously inflating getBytesRead().
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("a"), StandardCharsets.UTF_8, true)) {
            assertEquals('a', br.read());
            assertEquals(1, br.getBytesRead());
            assertEquals(EOF, br.read());
            assertEquals(1, br.getBytesRead());
        }
    }

    @Test
    void testBulkReadByteTrackingIgnoresEof() throws IOException {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("ab"), StandardCharsets.UTF_8, true)) {
            final char[] buf = new char[5];
            assertEquals(2, br.read(buf, 0, 5));
            assertEquals(2, br.getBytesRead());
            assertEquals(EOF, br.read(buf, 0, 5));
            assertEquals(2, br.getBytesRead());
        }
    }

    @Test
    void testByteTrackingDisabledWithoutCharset() throws IOException {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), null, true)) {
            assertEquals('a', br.read());
            assertEquals('b', br.read());
            assertEquals(0, br.getBytesRead());
        }
    }

    @Test
    void testByteTrackingDisabledWhenTrackBytesFalse() throws IOException {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false)) {
            assertEquals('a', br.read());
            assertEquals(0, br.getBytesRead());
        }
    }

    @Test
    void testSurrogatePairByteLengthOverSingleCharReads() throws IOException {
        final String emoji = "😀"; // U+1F600, 4 bytes in UTF-8
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(emoji), StandardCharsets.UTF_8, true)) {
            assertEquals('\uD83D', br.read());
            assertEquals(0, br.getBytesRead());
            assertEquals('\uDE00', br.read());
            assertEquals(4, br.getBytesRead());
        }
    }

    @Test
    void testLoneLowSurrogateThrowsCharacterCodingException() throws IOException {
        try (final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\uDE00x"), StandardCharsets.UTF_8, true)) {
            assertThrows(CharacterCodingException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read();
                }
            });
        }
    }

    @Test
    void testReadBufferZeroLengthIsNoOp() throws IOException {
        try (ExtendedBufferedReader br = of("abc")) {
            final char[] buf = new char[3];
            assertEquals(0, br.read(buf, 0, 0));
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
        }
    }

    @Test
    void testReadBufferPartialAtEof() throws IOException {
        try (ExtendedBufferedReader br = of("ab")) {
            final char[] buf = new char[5];
            final int len = br.read(buf, 0, 5);
            assertEquals(2, len);
            assertEquals('a', buf[0]);
            assertEquals('b', buf[1]);
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
        }
    }

    @Test
    void testReadBufferIntoOffsetPreservesExistingContent() throws IOException {
        final char[] tmp1 = new char[2];
        final char[] tmp2 = new char[4];
        try (ExtendedBufferedReader br = of("1\r\n2\r\n")) {
            assertEquals(2, br.read(tmp1, 0, 2));
            assertArrayEquals(new char[] { '1', '\r' }, tmp1);
            assertEquals(2, br.read(tmp2, 2, 2));
            assertEquals('\n', tmp2[2]);
            assertEquals('2', tmp2[3]);
            assertEquals(2, br.getLineNumber());
        }
    }

    @Test
    void testReadBufferTracksCrlfSplitAcrossCalls() throws IOException {
        try (ExtendedBufferedReader br = of("a\r\nb\r\nc")) {
            final char[] buf = new char[1];
            int lineCount = 0;
            while (br.read(buf, 0, 1) != EOF) {
                // Consume one character at a time, forcing the CR/LF pair to be
                // split across separate calls to read(char[], int, int).
            }
            assertEquals(2, br.getLineNumber());
        }
    }

    @Test
    void testReadLineVariousEolStyles() throws IOException {
        try (ExtendedBufferedReader br = of("")) {
            assertNull(br.readLine());
        }
        try (ExtendedBufferedReader br = of(LF)) {
            assertEquals("", br.readLine());
            assertNull(br.readLine());
        }
        try (ExtendedBufferedReader br = of("foo" + CRLF + "bar" + LFCR + "baz")) {
            assertEquals("foo", br.readLine());
            assertEquals(1, br.getLineNumber());
            assertEquals("bar", br.readLine());
            assertEquals(2, br.getLineNumber());
            // LFCR is two separate EOLs (a LF-terminated empty line, then a lone CR),
            // unlike CRLF which counts as a single EOL.
            assertEquals("", br.readLine());
            assertEquals(3, br.getLineNumber());
            assertEquals("baz", br.readLine());
            assertEquals(4, br.getLineNumber());
            assertNull(br.readLine());
        }
    }

    @Test
    void testReadLineNoTrailingTerminatorReturnsLastChunk() throws IOException {
        try (ExtendedBufferedReader br = of("abc\ndef")) {
            assertEquals("abc", br.readLine());
            assertEquals("def", br.readLine());
            assertNull(br.readLine());
            assertEquals(EOF, br.getLastChar());
        }
    }

    @Test
    void testReadLineInterleavedWithReadAndPeek() throws IOException {
        try (ExtendedBufferedReader br = of("foo\n\nhello")) {
            assertEquals('f', br.read());
            assertEquals('o', br.peek());
            assertEquals("oo", br.readLine());
            assertEquals(1, br.getLineNumber());
            assertEquals('\n', br.peek());
            assertEquals("", br.readLine());
            assertEquals(2, br.getLineNumber());
            assertEquals("hello", br.readLine());
            assertNull(br.readLine());
            assertEquals(3, br.getLineNumber());
        }
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        try (ExtendedBufferedReader br = of("abc\ndef")) {
            assertEquals('a', br.read());
            br.mark(10);
            assertEquals('b', br.read());
            assertEquals('c', br.read());
            assertEquals('\n', br.read());
            assertEquals(4, br.getPosition());
            assertEquals(1, br.getLineNumber());
            br.reset();
            assertEquals(1, br.getPosition());
            assertEquals('a', br.getLastChar());
            assertEquals(1, br.getLineNumber());
            assertEquals('b', br.read());
        }
    }

    @Test
    void testMarkAndResetRestoreBytesRead() throws IOException {
        try (ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true)) {
            assertEquals('a', br.read());
            br.mark(10);
            assertEquals('b', br.read());
            assertEquals('c', br.read());
            assertEquals(3, br.getBytesRead());
            br.reset();
            assertEquals(1, br.getBytesRead());
            assertEquals('b', br.read());
        }
    }

    @Test
    void testCloseSetsLastCharToEofAndRejectsFurtherReads() throws IOException {
        final ExtendedBufferedReader br = of("abc");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }
}
