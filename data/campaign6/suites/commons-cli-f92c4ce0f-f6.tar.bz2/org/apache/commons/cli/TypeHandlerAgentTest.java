/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

class TypeHandlerAgentTest {

    /**
     * A class without a default (no-arg) constructor, used to exercise the
     * "object could not be created" failure path of createObject/createValue.
     */
    public static class NoDefaultCtor {
        public NoDefaultCtor(final int i) {
        }
    }

    @Test
    void testGetDefaultReturnsSameSingletonInstance() {
        final TypeHandler first = TypeHandler.getDefault();
        final TypeHandler second = TypeHandler.getDefault();
        assertNotNull(first);
        assertSame(first, second);
    }

    @Test
    void testDefaultConstructorBehavesLikeDefaultInstance() throws Exception {
        final TypeHandler handler = new TypeHandler();
        assertEquals(Integer.valueOf(42), handler.getConverter(Integer.class).apply("42"));
    }

    @Test
    void testConstructorRejectsNullMap() {
        try {
            new TypeHandler(null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException e) {
            assertEquals("converterMap", e.getMessage());
        }
    }

    @Test
    void testConstructorUsesSuppliedMapInsteadOfDefaults() throws Exception {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        map.put(String.class, new Converter<String, RuntimeException>() {
            @Override
            public String apply(final String string) {
                return new StringBuilder(string).reverse().toString();
            }
        });
        final TypeHandler handler = new TypeHandler(map);

        assertEquals("cba", handler.getConverter(String.class).apply("abc"));
        // A class not present in the supplied map must fall back to Converter.DEFAULT.
        assertEquals("42", handler.getConverter(Integer.class).apply("42"));
    }

    @Test
    void testGetConverterReturnsDefaultForUnregisteredClass() throws Exception {
        final TypeHandler handler = new TypeHandler(new HashMap<Class<?>, Converter<?, ? extends Throwable>>());
        final Converter<Integer, ?> converter = handler.getConverter(Integer.class);
        assertSame(Converter.DEFAULT, converter);
        assertEquals("notANumber", converter.apply("notANumber"));
    }

    @Test
    void testCreateDefaultMapContainsExpectedConverters() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        assertTrue(map.containsKey(Object.class));
        assertTrue(map.containsKey(Class.class));
        assertTrue(map.containsKey(Date.class));
        assertTrue(map.containsKey(File.class));
        assertTrue(map.containsKey(Path.class));
        assertTrue(map.containsKey(Number.class));
        assertTrue(map.containsKey(URL.class));
        assertTrue(map.containsKey(FileInputStream.class));
        assertTrue(map.containsKey(Long.class));
        assertTrue(map.containsKey(Integer.class));
        assertTrue(map.containsKey(Short.class));
        assertTrue(map.containsKey(Byte.class));
        assertTrue(map.containsKey(Character.class));
        assertTrue(map.containsKey(Double.class));
        assertTrue(map.containsKey(Float.class));
        assertTrue(map.containsKey(BigInteger.class));
        assertTrue(map.containsKey(BigDecimal.class));
        assertEquals(17, map.size());
    }

    @Test
    void testCreateClassValid() throws Exception {
        final Class<?> clazz = TypeHandler.createClass(this.getClass().getName());
        assertEquals(this.getClass(), clazz);
    }

    @Test
    void testCreateClassInvalidThrowsParseException() {
        try {
            TypeHandler.createClass("no.such.class.Anywhere");
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    void testCreateDateParsesValidFormat() {
        final Date expected = new Date(1023400137000L);
        final DateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        final String formatted = dateFormat.format(expected);
        final Date actual = TypeHandler.createDate(formatted);
        assertEquals(expected, actual);
    }

    @Test
    void testCreateDateInvalidFormatThrowsIllegalArgumentException() {
        try {
            TypeHandler.createDate("not a date");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getCause() instanceof ParseException);
        }
    }

    @Test
    void testCreateFileAlwaysSucceedsEvenForNonExistentPath() {
        final String path = "/this/path/almost/certainly/does/not/exist/" + System.nanoTime();
        final File file = TypeHandler.createFile(path);
        assertNotNull(file);
        assertEquals(path, file.getPath());
        assertFalse(file.exists());
    }

    @Test
    void testCreateFilesThrowsUnsupportedOperationException() {
        try {
            TypeHandler.createFiles("a,b,c");
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException e) {
            // Documented as "Not yet implemented".
        }
    }

    @Test
    void testCreateNumberReturnsLongForIntegerString() throws Exception {
        final Number number = TypeHandler.createNumber("123");
        assertEquals(Long.valueOf(123), number);
    }

    @Test
    void testCreateNumberReturnsDoubleForDecimalString() throws Exception {
        final Number number = TypeHandler.createNumber("12.3");
        assertEquals(Double.valueOf(12.3), number);
    }

    @Test
    void testCreateNumberInvalidThrowsParseException() {
        try {
            TypeHandler.createNumber("1.2.3");
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof NumberFormatException);
        }
    }

    @Test
    void testCreateObjectValid() throws Exception {
        final Object object = TypeHandler.createObject(Object.class.getName());
        assertNotNull(object);
        assertEquals(Object.class, object.getClass());
    }

    @Test
    void testCreateObjectWithoutDefaultConstructorThrowsParseException() {
        try {
            TypeHandler.createObject(NoDefaultCtor.class.getName());
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof NoSuchMethodException);
        }
    }

    @Test
    void testCreateObjectUnknownClassThrowsParseException() {
        try {
            TypeHandler.createObject("no.such.class.Anywhere");
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    void testCreateURLValid() throws Exception {
        final URL url = TypeHandler.createURL("https://apache.org");
        assertEquals(new URL("https://apache.org"), url);
    }

    @Test
    void testCreateURLInvalidThrowsParseException() {
        try {
            TypeHandler.createURL("foo.bar");
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof java.net.MalformedURLException);
        }
    }

    @Test
    void testCreateValueCharacterLiteral() throws Exception {
        assertEquals(Character.valueOf('A'), TypeHandler.createValue("A", Character.class));
    }

    @Test
    void testCreateValueCharacterUnicodeEscape() throws Exception {
        assertEquals(Character.valueOf('A'), TypeHandler.createValue("\\u0041", Character.class));
    }

    @Test
    void testCreateValueCharacterEmptyStringThrowsParseException() {
        try {
            TypeHandler.createValue("", Character.class);
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof StringIndexOutOfBoundsException);
        }
    }

    @Test
    void testCreateValueByteInRange() throws Exception {
        assertEquals(Byte.valueOf((byte) 127), TypeHandler.createValue("127", Byte.class));
    }

    @Test
    void testCreateValueByteOutOfRangeThrowsParseException() {
        try {
            TypeHandler.createValue("128", Byte.class);
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof NumberFormatException);
        }
    }

    @Test
    void testCreateValueShortOutOfRangeThrowsParseException() {
        try {
            TypeHandler.createValue("32768", Short.class);
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof NumberFormatException);
        }
    }

    @Test
    void testCreateValueBigIntegerAndBigDecimal() throws Exception {
        assertEquals(new BigInteger("123456789012345678901234567890"), TypeHandler.createValue("123456789012345678901234567890", BigInteger.class));
        assertEquals(new BigDecimal("3.14159"), TypeHandler.createValue("3.14159", BigDecimal.class));
    }

    @Test
    void testCreateValuePath() throws Exception {
        final Path path = TypeHandler.createValue("some/relative/path", Path.class);
        assertEquals("some/relative/path", path.toString());
    }

    @Test
    void testCreateValueObjectOverloadDelegatesToClassOverload() throws Exception {
        final Object result = TypeHandler.createValue("42", (Object) Integer.class);
        assertEquals(Integer.valueOf(42), result);
    }

    @Test
    void testCreateValueObjectOverloadWithNonClassThrowsClassCastException() throws ParseException {
        try {
            TypeHandler.createValue("42", (Object) "not a class");
            fail("Expected ClassCastException");
        } catch (final ClassCastException e) {
            // obj must be a Class<?> instance, despite its declared type being Object.
        }
    }

    @Test
    void testOpenFileExistingReadable() throws Exception {
        final URL url = this.getClass().getClassLoader().getResource("org/apache/commons/cli/existing-readable.file");
        assertNotNull(url, "test resource missing");
        final String fileName = url.toString().substring("file:".length());
        final FileInputStream stream = TypeHandler.openFile(fileName);
        try {
            assertNotNull(stream);
        } finally {
            stream.close();
        }
    }

    @Test
    void testOpenFileMissingThrowsParseException() {
        final String path = "/this/path/almost/certainly/does/not/exist/" + System.nanoTime();
        try {
            TypeHandler.openFile(path);
            fail("Expected ParseException");
        } catch (final ParseException e) {
            assertTrue(e.getCause() instanceof java.io.FileNotFoundException);
        }
    }
}
