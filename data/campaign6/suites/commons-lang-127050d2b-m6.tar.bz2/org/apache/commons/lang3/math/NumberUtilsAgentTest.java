/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructor() {
        assertNotNull(new NumberUtils());
    }

    @Test
    void testCompare() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);

        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);

        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);

        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1234.5"), NumberUtils.createBigDecimal("1234.5"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("   "));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("not a number"));
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-0xFF"));
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigInteger(""));
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.23d), NumberUtils.createDouble("1.23"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createDouble("not a number"));
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.23f), NumberUtils.createFloat("1.23"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createFloat("not a number"));
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12), NumberUtils.createInteger("12"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createInteger("not a number"));
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12L), NumberUtils.createLong("12"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createLong("not a number"));
    }

    @Test
    void testCreateNumber() {
        assertNull(NumberUtils.createNumber(null));
        assertEquals(Integer.valueOf(12), NumberUtils.createNumber("12"));
        assertEquals(Long.valueOf(12L), NumberUtils.createNumber("12L"));
        assertEquals(Float.valueOf(1.2f), NumberUtils.createNumber("1.2F"));
        assertEquals(Double.valueOf(1.2d), NumberUtils.createNumber("1.2D"));
        assertEquals(new BigInteger("123456789012345678901234"), NumberUtils.createNumber("123456789012345678901234"));
        assertEquals(new BigDecimal("1.23456789012345678901234"), NumberUtils.createNumber("1.23456789012345678901234"));
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("0xFF"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("   "));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("not a number"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.2.3"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.2.3e4"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("12Q"));
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
        assertFalse(NumberUtils.isCreatable("not a number"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertTrue(NumberUtils.isCreatable("12"));
        assertTrue(NumberUtils.isCreatable("-12.5"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertTrue(NumberUtils.isCreatable("1.2e10"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("12"), NumberUtils.isNumber("12"));
        assertEquals(NumberUtils.isCreatable("not a number"), NumberUtils.isNumber("not a number"));
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("abc"));
        assertTrue(NumberUtils.isDigits("12345"));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("0xFF"));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123.45"));
        assertTrue(NumberUtils.isParsable("1.2e5"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max(new byte[] { 1, 5, 3 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new byte[0]));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.5, NumberUtils.max(1.0, 5.5, 3.0), 0.0001);
        assertEquals(5.5, NumberUtils.max(new double[] { 1.0, 5.5, 3.0 }), 0.0001);
        assertTrue(Double.isNaN(NumberUtils.max(1.0, Double.NaN, 3.0)));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new double[0]));
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.0f, 5.5f, 3.0f), 0.0001f);
        assertEquals(5.5f, NumberUtils.max(new float[] { 1.0f, 5.5f, 3.0f }), 0.0001f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new float[0]));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(5, NumberUtils.max(new int[] { 1, 5, 3 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new int[0]));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(5L, NumberUtils.max(new long[] { 1L, 5L, 3L }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new long[0]));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertEquals((short) 5, NumberUtils.max(new short[] { 1, 5, 3 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new short[0]));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min(new byte[] { 1, 5, 3 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new byte[0]));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0, NumberUtils.min(1.0, 5.5, 3.0), 0.0001);
        assertEquals(1.0, NumberUtils.min(new double[] { 1.0, 5.5, 3.0 }), 0.0001);
        assertTrue(Double.isNaN(NumberUtils.min(1.0, Double.NaN, 3.0)));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new double[0]));
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.5f, 3.0f), 0.0001f);
        assertEquals(1.0f, NumberUtils.min(new float[] { 1.0f, 5.5f, 3.0f }), 0.0001f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new float[0]));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(1, NumberUtils.min(new int[] { 1, 5, 3 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new int[0]));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertEquals(1L, NumberUtils.min(new long[] { 1L, 5L, 3L }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new long[0]));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertEquals((short) 1, NumberUtils.min(new short[] { 1, 5, 3 }));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new short[0]));
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("not a number", (byte) 2));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0001);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0001);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0001);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0001);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0001);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0001);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0001);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0001);
        assertEquals(1.1d, NumberUtils.toDouble("not a number", 1.1d), 0.0001);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0001);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0001f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0001f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0001f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0001f);
        assertEquals(1.1f, NumberUtils.toFloat("not a number", 1.1f), 0.0001f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0001f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("not a number", 2));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("not a number", 2L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("not a number", (short) 2));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.230"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.23"), 3, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.HALF_UP));
        assertNotNull(NumberUtils.toScaledBigDecimal(Float.valueOf(1.235f)));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.230"), NumberUtils.toScaledBigDecimal("1.23", 3, RoundingMode.HALF_UP));
    }

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }
}
