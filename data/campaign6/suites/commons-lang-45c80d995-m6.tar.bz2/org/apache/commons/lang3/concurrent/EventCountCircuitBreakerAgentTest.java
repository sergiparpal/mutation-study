/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Test class for {@code EventCountCircuitBreaker}.
 */
class EventCountCircuitBreakerAgentTest {

    /**
     * A subclass that lets tests fully control the notion of "now" instead of relying on
     * real elapsed wall-clock time, so interval-dependent transitions are deterministic.
     */
    private static final class FakeClockCircuitBreaker extends EventCountCircuitBreaker {

        private long currentNanoTime;

        FakeClockCircuitBreaker(final int openingThreshold, final long openingInterval, final TimeUnit openingUnit,
                final int closingThreshold, final long closingInterval, final TimeUnit closingUnit) {
            super(openingThreshold, openingInterval, openingUnit, closingThreshold, closingInterval, closingUnit);
        }

        void advance(final long nanos) {
            currentNanoTime += nanos;
        }

        @Override
        long nanoTime() {
            return currentNanoTime;
        }
    }

    /**
     * A simple recording listener used to verify property change notifications.
     */
    private static final class RecordingListener implements PropertyChangeListener {

        private final List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            events.add(evt);
        }

        List<PropertyChangeEvent> getEvents() {
            return events;
        }
    }

    @Test
    void testInitialStateIsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        assertTrue(breaker.isClosed(), "Breaker should start closed");
        assertFalse(breaker.isOpen(), "Breaker should not start open");
        assertTrue(breaker.checkState(), "checkState() should report closed");
    }

    @Test
    void testSameThresholdConstructorUsesThresholdForBothOpenAndClose() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(7, 2, TimeUnit.SECONDS);
        assertEquals(7, breaker.getOpeningThreshold());
        assertEquals(7, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getClosingInterval());
    }

    @Test
    void testSameIntervalConstructorAllowsDifferentThresholds() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 3, TimeUnit.MINUTES, 4);
        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(4, breaker.getClosingThreshold());
        assertEquals(TimeUnit.MINUTES.toNanos(3), breaker.getOpeningInterval());
        assertEquals(TimeUnit.MINUTES.toNanos(3), breaker.getClosingInterval());
    }

    @Test
    void testFullConstructorKeepsOpeningAndClosingParametersIndependent() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 2, TimeUnit.MINUTES, 5, 30, TimeUnit.SECONDS);
        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(TimeUnit.MINUTES.toNanos(2), breaker.getOpeningInterval());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(30), breaker.getClosingInterval());
    }

    @Test
    void testNegativeIncrementIsRejected() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final Executable call = new Executable() {
            @Override
            public void execute() {
                breaker.incrementAndCheckState(Integer.valueOf(-1));
            }
        };
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, call);
        assertTrue(ex.getMessage().contains("-1"), "Exception message should mention the rejected value");
        assertTrue(breaker.isClosed(), "A rejected increment must not change the state");
    }

    @Test
    void testZeroIncrementIsAllowedAndDoesNotOpenWhenThresholdIsZero() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(0, 1, TimeUnit.MINUTES);
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(0)), "Zero events must not exceed a zero threshold");
        assertTrue(breaker.checkState(), "Breaker should remain closed with no events recorded");
    }

    @Test
    void testFirstEventOpensCircuitWhenThresholdIsZero() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(0, 1, TimeUnit.MINUTES);
        assertFalse(breaker.incrementAndCheckState(), "A single event must open a breaker with a zero threshold");
        assertTrue(breaker.isOpen());
    }

    @Test
    void testEventsAtOrBelowThresholdKeepCircuitClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        assertTrue(breaker.incrementAndCheckState(), "1st event, below threshold");
        assertTrue(breaker.incrementAndCheckState(), "2nd event, below threshold");
        assertTrue(breaker.incrementAndCheckState(), "3rd event, exactly at threshold (not exceeded)");
        assertTrue(breaker.isClosed(), "Threshold is exceeded only when strictly greater than the configured value");
    }

    @Test
    void testExceedingThresholdOpensCircuit() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        breaker.incrementAndCheckState();
        breaker.incrementAndCheckState();
        breaker.incrementAndCheckState();
        assertFalse(breaker.incrementAndCheckState(), "4th event exceeds the threshold of 3");
        assertTrue(breaker.isOpen());
        assertFalse(breaker.isClosed());
    }

    @Test
    void testIncrementByCustomAmountCanOpenInOneCall() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(10)), "A single large increment above the threshold must open the breaker");
    }

    @Test
    void testManualOpenAndCloseWithoutEvents() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        breaker.open();
        assertTrue(breaker.isOpen(), "Manual open() must switch the state");
        breaker.close();
        assertTrue(breaker.isClosed(), "Manual close() must switch the state back");
    }

    @Test
    void testManualOpenIsIdempotentForListeners() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);
        breaker.open();
        breaker.open();
        assertEquals(1, listener.getEvents().size(), "A second open() on an already open breaker must not fire again");
        final PropertyChangeEvent event = listener.getEvents().get(0);
        assertEquals(AbstractCircuitBreaker.PROPERTY_NAME, event.getPropertyName());
        assertEquals(Boolean.FALSE, event.getOldValue());
        assertEquals(Boolean.TRUE, event.getNewValue());
    }

    @Test
    void testChangeListenerReceivesCloseNotification() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        breaker.open();
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);
        breaker.close();
        assertEquals(1, listener.getEvents().size());
        final PropertyChangeEvent event = listener.getEvents().get(0);
        assertEquals(Boolean.TRUE, event.getOldValue());
        assertEquals(Boolean.FALSE, event.getNewValue());
    }

    @Test
    void testRemovedChangeListenerIsNotNotified() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);
        breaker.removeChangeListener(listener);
        breaker.open();
        assertTrue(listener.getEvents().isEmpty(), "A removed listener must not receive further notifications");
    }

    @Test
    void testNullChangeListenerIsSilentlyIgnored() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        breaker.addChangeListener(null);
        breaker.open();
        assertTrue(breaker.isOpen(), "Adding a null listener must not break the breaker");
    }

    @Test
    void testCheckStateAloneDoesNotCountAsAnEvent() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(2, 1, TimeUnit.MINUTES);
        assertTrue(breaker.checkState());
        assertTrue(breaker.checkState());
        assertTrue(breaker.checkState());
        assertTrue(breaker.isClosed(), "checkState() must not increment the event counter");
    }

    @Test
    void testCircuitStaysOpenBeforeClosingIntervalElapses() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(1, 1, TimeUnit.SECONDS, 1, 1, TimeUnit.SECONDS);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(5)), "Opens because 5 > threshold of 1");
        assertTrue(breaker.isOpen());
        breaker.advance(TimeUnit.MILLISECONDS.toNanos(1));
        assertFalse(breaker.checkState(), "Closing interval has not elapsed yet, breaker must remain open");
        assertTrue(breaker.isOpen());
    }

    @Test
    void testCircuitClosesAfterClosingIntervalWhenEventsDropBelowClosingThreshold() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(1, 1, TimeUnit.SECONDS, 3, 1, TimeUnit.SECONDS);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(5)), "Opens because 5 > opening threshold of 1");
        assertTrue(breaker.isOpen());

        // No further events are recorded during the open check interval (count stays 0, below closing threshold of 3).
        breaker.advance(TimeUnit.SECONDS.toNanos(2));
        assertTrue(breaker.checkState(), "Closing interval elapsed with 0 events (< closing threshold of 3): breaker must close");
        assertTrue(breaker.isClosed());
    }

    @Test
    void testCircuitStaysOpenAfterClosingIntervalWhenEventsAreAtClosingThreshold() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(1, 1, TimeUnit.SECONDS, 2, 1, TimeUnit.SECONDS);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(5)), "Opens because 5 > opening threshold of 1");
        assertTrue(breaker.isOpen());

        // Record exactly 2 events (equal to the closing threshold) while still inside the open check interval.
        breaker.incrementAndCheckState();
        breaker.incrementAndCheckState();

        breaker.advance(TimeUnit.SECONDS.toNanos(2));
        assertFalse(breaker.checkState(), "2 events is not strictly less than the closing threshold of 2: breaker must stay open");
        assertTrue(breaker.isOpen());
    }

    @Test
    void testCircuitStaysOpenAfterClosingIntervalWhenEventsRemainAboveClosingThreshold() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(1, 1, TimeUnit.SECONDS, 2, 1, TimeUnit.SECONDS);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(5)), "Opens because 5 > opening threshold of 1");

        breaker.incrementAndCheckState(Integer.valueOf(10));

        breaker.advance(TimeUnit.SECONDS.toNanos(2));
        assertFalse(breaker.checkState(), "10 events is not below the closing threshold of 2: breaker must stay open");
        assertTrue(breaker.isOpen());
    }

    @Test
    void testOpeningCheckIntervalResetsEventCounter() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(3, 1, TimeUnit.SECONDS, 3, 1, TimeUnit.SECONDS);
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(2)), "2 events, below threshold of 3");

        // Let the opening check interval elapse: the counter must restart rather than keep accumulating.
        breaker.advance(TimeUnit.SECONDS.toNanos(2));
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(2)), "A new interval started, so 2 events is still below the threshold of 3");
        assertTrue(breaker.isClosed());
    }

    @Test
    void testCloseResetsEventCounterEvenWhenAlreadyClosed() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(3, 1, TimeUnit.SECONDS, 3, 1, TimeUnit.SECONDS);
        breaker.incrementAndCheckState(Integer.valueOf(2));
        breaker.close();
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(2)), "close() must restart the check interval and counter");
        assertTrue(breaker.isClosed());
    }

    @Test
    void testOpenResetsEventCounterEvenWhenAlreadyOpen() {
        final FakeClockCircuitBreaker breaker = new FakeClockCircuitBreaker(1, 1, TimeUnit.SECONDS, 2, 1, TimeUnit.SECONDS);
        assertFalse(breaker.incrementAndCheckState(Integer.valueOf(5)), "Opens because 5 > opening threshold of 1");

        // Accumulate events above the closing threshold while open and within the check interval.
        breaker.incrementAndCheckState(Integer.valueOf(10));

        // Calling open() again must restart the interval with a fresh counter of 0, discarding the accumulated events.
        breaker.open();
        breaker.advance(TimeUnit.SECONDS.toNanos(2));
        assertTrue(breaker.checkState(), "open() must reset the counter to 0, which is below the closing threshold of 2");
    }

}
