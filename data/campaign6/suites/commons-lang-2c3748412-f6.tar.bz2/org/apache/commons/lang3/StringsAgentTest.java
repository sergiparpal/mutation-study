/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link Strings}.
 */
public class StringsAgentTest {

    // ---- builder ----

    @Test
    public void testBuilderDefaults() {
        final Strings s = Strings.builder().get();
        assertTrue(s.isCaseSensitive());
    }

    @Test
    public void testBuilderIgnoreCaseTrue() {
        final Strings s = Strings.builder().setIgnoreCase(true).get();
        assertFalse(s.isCaseSensitive());
        assertTrue(s.equals("abc", "ABC"));
    }

    @Test
    public void testBuilderIgnoreCaseFalse() {
        final Strings s = Strings.builder().setIgnoreCase(false).get();
        assertTrue(s.isCaseSensitive());
        assertFalse(s.equals("abc", "ABC"));
    }

    @Test
    public void testBuilderNullIsLessFalse() {
        final Strings s = Strings.builder().setNullIsLess(false).get();
        assertTrue(s.compare(null, "a") > 0);
        assertTrue(s.compare("a", null) < 0);
    }

    @Test
    public void testBuilderNullIsLessTrue() {
        final Strings s = Strings.builder().setNullIsLess(true).get();
        assertTrue(s.compare(null, "a") < 0);
        assertTrue(s.compare("a", null) > 0);
    }

    // ---- isCaseSensitive ----

    @Test
    public void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // ---- compare ----

    @Test
    public void testCompareCsNulls() {
        assertEquals(0, Strings.CS.compare(null, null));
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
    }

    @Test
    public void testCompareCsValues() {
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "b") < 0);
        assertTrue(Strings.CS.compare("b", "a") > 0);
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    public void testCompareCiValues() {
        assertEquals(0, Strings.CI.compare(null, null));
        assertTrue(Strings.CI.compare(null, "a") < 0);
        assertTrue(Strings.CI.compare("a", null) > 0);
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "B") < 0);
        assertTrue(Strings.CI.compare("A", "b") < 0);
    }

    // ---- contains ----

    @Test
    public void testContainsCsNulls() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
        assertFalse(Strings.CS.contains(null, null));
    }

    @Test
    public void testContainsCsEmpty() {
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
    }

    @Test
    public void testContainsCsValues() {
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    @Test
    public void testContainsCiValues() {
        assertFalse(Strings.CI.contains(null, "a"));
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
        assertTrue(Strings.CI.contains("", ""));
    }

    // ---- containsAny ----

    @Test
    public void testContainsAnyCsBasics() {
        assertFalse(Strings.CS.containsAny(null, "a"));
        assertFalse(Strings.CS.containsAny("", "a"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc"));
        assertTrue(Strings.CS.containsAny("abcd", "ab", (CharSequence) null));
        assertTrue(Strings.CS.containsAny("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAnyCiCase() {
        assertTrue(Strings.CI.containsAny("abc", "D", "ABC"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
        assertFalse(Strings.CS.containsAny("ABC", "d", "abc"));
    }

    // ---- endsWith ----

    @Test
    public void testEndsWithCsNulls() {
        assertTrue(Strings.CS.endsWith(null, null));
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
    }

    @Test
    public void testEndsWithCsValues() {
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "cde"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithCiValues() {
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    @Test
    public void testEndsWithSuffixLongerThanString() {
        assertFalse(Strings.CS.endsWith("ab", "abcdef"));
    }

    // ---- endsWithAny ----

    @Test
    public void testEndsWithAnyBasics() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // ---- equals (CharSequence) ----

    @Test
    public void testEqualsCsCharSequence() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) null));
        assertTrue(Strings.CS.equals((CharSequence) "abc", (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    public void testEqualsCiCharSequence() {
        assertTrue(Strings.CI.equals((CharSequence) null, (CharSequence) null));
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABC"));
        assertFalse(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABCD"));
    }

    @Test
    public void testEqualsCsCharSequenceNonStringImpl() {
        final StringBuilder sb1 = new StringBuilder("abc");
        final StringBuilder sb2 = new StringBuilder("abc");
        assertTrue(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb2));
        final StringBuilder sb3 = new StringBuilder("abd");
        assertFalse(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb3));
    }

    // ---- equals (String) ----

    @Test
    public void testEqualsCsString() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsCiString() {
        assertTrue(Strings.CI.equals((String) null, (String) null));
        assertTrue(Strings.CI.equals("abc", "ABC"));
        assertFalse(Strings.CI.equals("abc", (String) null));
    }

    // ---- equalsAny ----

    @Test
    public void testEqualsAnyCs() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CS.equalsAny(null, null, null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAnyCi() {
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // ---- indexOf(2-arg) ----

    @Test
    public void testIndexOfTwoArg() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(-1, Strings.CS.indexOf("", "a"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", ""));
    }

    @Test
    public void testIndexOfTwoArgCi() {
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A"));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B"));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB"));
    }

    // ---- indexOf(3-arg) ----

    @Test
    public void testIndexOfThreeArgCs() {
        assertEquals(-1, Strings.CS.indexOf((CharSequence) null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", (CharSequence) null, 0));
        assertEquals(0, Strings.CS.indexOf("", "", 0));
        assertEquals(-1, Strings.CS.indexOf("", "a", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfThreeArgCi() {
        assertEquals(-1, Strings.CI.indexOf((CharSequence) null, "a", 0));
        assertEquals(0, Strings.CI.indexOf("", "", 0));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
    }

    // ---- lastIndexOf(2-arg) ----

    @Test
    public void testLastIndexOfTwoArgCs() {
        assertEquals(-1, Strings.CS.lastIndexOf((CharSequence) null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", (CharSequence) null));
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfTwoArgCi() {
        assertEquals(-1, Strings.CI.lastIndexOf((CharSequence) null, "a"));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B"));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB"));
    }

    // ---- lastIndexOf(3-arg) ----

    @Test
    public void testLastIndexOfThreeArgCs() {
        assertEquals(-1, Strings.CS.lastIndexOf((CharSequence) null, "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("a", (CharSequence) null, 0));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    public void testLastIndexOfThreeArgCi() {
        assertEquals(-1, Strings.CI.lastIndexOf((CharSequence) null, "a", 0));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 8));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // ---- startsWith ----

    @Test
    public void testStartsWithCs() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithCi() {
        assertTrue(Strings.CI.startsWith(null, null));
        assertFalse(Strings.CI.startsWith(null, "abc"));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithPrefixLongerThanString() {
        assertFalse(Strings.CS.startsWith("ab", "abcdef"));
    }

    // ---- startsWithAny ----

    @Test
    public void testStartsWithAny() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
    }

    // ---- appendIfMissing ----

    @Test
    public void testAppendIfMissingCs() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissingCsAdditional() {
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", (CharSequence) null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissingCi() {
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abcMNO", Strings.CI.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    // ---- prependIfMissing ----

    @Test
    public void testPrependIfMissingCs() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingCsAdditional() {
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", (CharSequence) null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", "xyz", ""));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingCi() {
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
        assertEquals("MNOabc", Strings.CI.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    // ---- remove ----

    @Test
    public void testRemoveCs() {
        assertNull(Strings.CS.remove(null, "a"));
        assertEquals("", Strings.CS.remove("", "a"));
        assertEquals("queued", Strings.CS.remove("queued", null));
        assertEquals("queued", Strings.CS.remove("queued", ""));
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    public void testRemoveCi() {
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    // ---- removeEnd ----

    @Test
    public void testRemoveEndCs() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEndCi() {
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // ---- removeStart ----

    @Test
    public void testRemoveStartCs() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStartCi() {
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
    }

    // ---- replace(3-arg) ----

    @Test
    public void testReplaceThreeArgCs() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceThreeArgCi() {
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    // ---- replace(4-arg, max) ----

    @Test
    public void testReplaceFourArgCs() {
        assertNull(Strings.CS.replace(null, "a", "b", -1));
        assertEquals("", Strings.CS.replace("", "a", "b", -1));
        assertEquals("any", Strings.CS.replace("any", null, "b", -1));
        assertEquals("any", Strings.CS.replace("any", "a", null, -1));
        assertEquals("any", Strings.CS.replace("any", "", "b", -1));
        assertEquals("any", Strings.CS.replace("any", "a", "z", 0));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CS.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceFourArgCi() {
        assertEquals("zbaa", Strings.CI.replace("abaa", "A", "z", 1));
        assertEquals("zbza", Strings.CI.replace("abAa", "a", "z", 2));
        assertEquals("zbzz", Strings.CI.replace("abAa", "a", "z", -1));
    }

    // ---- replaceOnce ----

    @Test
    public void testReplaceOnceCs() {
        assertNull(Strings.CS.replaceOnce(null, "a", "b"));
        assertEquals("", Strings.CS.replaceOnce("", "a", "b"));
        assertEquals("any", Strings.CS.replaceOnce("any", null, "b"));
        assertEquals("any", Strings.CS.replaceOnce("any", "a", null));
        assertEquals("any", Strings.CS.replaceOnce("any", "", "b"));
        assertEquals("aba", Strings.CS.replaceOnce("aba", "a", null));
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceCi() {
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // ---- CI/CS singleton identity ----

    @Test
    public void testSingletonsAreSameInstance() {
        assertSame(Strings.CS, Strings.CS);
        assertSame(Strings.CI, Strings.CI);
    }
}
