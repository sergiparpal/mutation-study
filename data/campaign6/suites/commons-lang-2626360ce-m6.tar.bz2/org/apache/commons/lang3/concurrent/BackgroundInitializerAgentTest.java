/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link BackgroundInitializer}.
 */
public class BackgroundInitializerAgentTest {

    /**
     * A concrete {@link BackgroundInitializer} used by most tests. It counts the number of
     * invocations of {@link #initialize()} and allows the test to control when initialization may
     * proceed by means of a latch.
     */
    private static class AgentBackgroundInitializer extends BackgroundInitializer<Integer> {

        /** Constant for the result returned by {@code initialize()}. */
        static final Integer RESULT = Integer.valueOf(42);

        /** Number of invocations of initialize(). */
        volatile int initializeCalls;

        /** Optional latch the initialize() method waits on before proceeding. */
        private final CountDownLatch startLatch;

        /** Exception to throw from initialize(), if any. */
        private final Exception exceptionToThrow;

        AgentBackgroundInitializer() {
            this(null, null, null);
        }

        AgentBackgroundInitializer(final ExecutorService exec) {
            this(exec, null, null);
        }

        AgentBackgroundInitializer(final ExecutorService exec, final CountDownLatch startLatch, final Exception exceptionToThrow) {
            super(exec);
            this.startLatch = startLatch;
            this.exceptionToThrow = exceptionToThrow;
        }

        @Override
        protected Integer initialize() throws Exception {
            if (startLatch != null) {
                startLatch.await();
            }
            initializeCalls++;
            if (exceptionToThrow != null) {
                throw exceptionToThrow;
            }
            return RESULT;
        }
    }

    /**
     * A {@link BackgroundInitializer} that reports more than one background task.
     */
    private static class MultiTaskBackgroundInitializer extends BackgroundInitializer<Integer> {

        private final int taskCount;

        MultiTaskBackgroundInitializer(final int taskCount) {
            this.taskCount = taskCount;
        }

        @Override
        protected int getTaskCount() {
            return taskCount;
        }

        @Override
        protected Integer initialize() {
            return Integer.valueOf(getTaskCount());
        }
    }

    private static void awaitTermination(final ExecutorService exec) throws InterruptedException {
        exec.awaitTermination(5, TimeUnit.SECONDS);
    }

    @Test
    void testIsStartedFalseBeforeStart() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertFalse(init.isStarted(), "Should not be started yet");
        assertFalse(init.isInitialized(), "Should not be initialized yet");
    }

    @Test
    void testStartReturnsTrueOnlyOnce() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertTrue(init.start(), "First call to start() should return true");
        assertTrue(init.isStarted(), "Should be started now");
        assertFalse(init.start(), "Second call to start() should return false");
        assertFalse(init.start(), "Third call to start() should also return false");
    }

    @Test
    void testGetBeforeStartThrowsIllegalState() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertNotNull(ex.getMessage());
    }

    @Test
    void testGetFutureBeforeStartThrowsIllegalState() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.getFuture();
            }
        });
    }

    @Test
    void testGetFutureAfterStartReturnsSameInstance() throws ConcurrentException {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        init.start();
        final Future<Integer> future1 = init.getFuture();
        final Future<Integer> future2 = init.getFuture();
        assertNotNull(future1);
        assertSame(future1, future2, "getFuture() should return the same Future instance");
        assertEquals(AgentBackgroundInitializer.RESULT, init.get());
    }

    @Test
    void testGetReturnsResultAndMarksInitialized() throws ConcurrentException {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertTrue(init.start());
        final Integer result = init.get();
        assertEquals(AgentBackgroundInitializer.RESULT, result);
        assertEquals(1, init.initializeCalls, "initialize() should be invoked exactly once");
        assertTrue(init.isInitialized(), "Should report initialized after successful get()");
    }

    @Test
    void testExternalExecutorIsUsedAndNotShutDown() throws Exception {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final AgentBackgroundInitializer init = new AgentBackgroundInitializer(exec);
            assertSame(exec, init.getExternalExecutor(), "External executor should be stored as-is");
            assertNull(init.getActiveExecutor(), "Active executor should be null before start()");
            init.start();
            assertSame(exec, init.getActiveExecutor(), "Active executor should be the external one");
            assertEquals(AgentBackgroundInitializer.RESULT, init.get());
            assertFalse(exec.isShutdown(), "External executor must not be shut down by the initializer");
        } finally {
            exec.shutdown();
            awaitTermination(exec);
        }
    }

    @Test
    void testTemporaryExecutorIsCreatedAndShutDownAfterCompletion() throws Exception {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertNull(init.getExternalExecutor(), "No external executor was provided");
        init.start();
        final ExecutorService active = init.getActiveExecutor();
        assertNotNull(active, "A temporary executor should have been created");
        init.get();
        // The temporary executor shuts itself down once the background task completes.
        boolean shutDown = active.awaitTermination(5, TimeUnit.SECONDS);
        assertTrue(shutDown, "Temporary executor should terminate after task completion");
        assertTrue(active.isShutdown(), "Temporary executor should be shut down after completion");
    }

    @Test
    void testSetExternalExecutorBeforeStart() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            init.setExternalExecutor(exec);
            assertSame(exec, init.getExternalExecutor());
            // Overwrite with null is permitted before start().
            init.setExternalExecutor(null);
            assertNull(init.getExternalExecutor());
        } finally {
            exec.shutdown();
        }
    }

    @Test
    void testSetExternalExecutorAfterStartThrows() throws InterruptedException {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        init.start();
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    init.setExternalExecutor(exec);
                }
            });
        } finally {
            exec.shutdown();
            awaitTermination(exec);
        }
    }

    @Test
    void testCheckedExceptionIsWrappedInConcurrentException() {
        final Exception cause = new java.io.IOException("boom");
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, null, cause);
        init.start();
        final ConcurrentException ex = assertThrows(ConcurrentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex.getCause(), "ConcurrentException should wrap the original checked exception");
        assertFalse(init.isInitialized(), "Should not be initialized after a failed initialize()");
    }

    @Test
    void testRuntimeExceptionIsThrownDirectly() {
        final RuntimeException cause = new IllegalArgumentException("bad input");
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, null, cause);
        init.start();
        final RuntimeException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex, "The original RuntimeException should be propagated unwrapped");
        assertFalse(init.isInitialized());
    }

    @Test
    void testIsInitializedFalseWhenFutureNotDone() throws InterruptedException {
        final CountDownLatch latch = new CountDownLatch(1);
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, latch, null);
        init.start();
        assertFalse(init.isInitialized(), "Should not be initialized while background task is blocked");
        latch.countDown();
        // Allow the background thread a chance to finish.
        while (!init.getFuture().isDone()) {
            Thread.sleep(10);
        }
        assertTrue(init.isInitialized(), "Should be initialized once the background task completes");
    }

    @Test
    void testCancellationPropagatesAndIsInitializedReturnsFalse() {
        final CountDownLatch latch = new CountDownLatch(1);
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, latch, null);
        init.start();
        final boolean cancelled = init.getFuture().cancel(true);
        assertTrue(cancelled, "Future should be cancellable before it completes");
        assertTrue(init.getFuture().isCancelled());
        assertThrows(CancellationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertFalse(init.isInitialized(), "A cancelled task must not be considered initialized");
        latch.countDown();
    }

    @Test
    void testGetTaskCountDefaultsToOne() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertEquals(1, init.getTaskCount());
    }

    @Test
    void testOverriddenTaskCountIsUsedForResult() throws ConcurrentException {
        final MultiTaskBackgroundInitializer init = new MultiTaskBackgroundInitializer(3);
        init.start();
        assertEquals(Integer.valueOf(3), init.get());
    }

    @Test
    void testBuilderCreatesWorkingInitializer() throws ConcurrentException {
        final BackgroundInitializer.Builder<BackgroundInitializer<String>, String> builder = BackgroundInitializer.builder();
        builder.setInitializer(new FailableSupplier<String, ConcurrentException>() {
            @Override
            public String get() {
                return "built-result";
            }
        });
        final BackgroundInitializer<String> init = builder.get();
        assertFalse(init.isStarted());
        assertTrue(init.start());
        assertEquals("built-result", init.get());
        assertTrue(init.isInitialized());
    }

    @Test
    void testBuilderWithExternalExecutor() throws Exception {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final BackgroundInitializer.Builder<BackgroundInitializer<String>, String> builder = BackgroundInitializer.builder();
            builder.setExternalExecutor(exec);
            builder.setInitializer(new FailableSupplier<String, ConcurrentException>() {
                @Override
                public String get() {
                    return "ext";
                }
            });
            final BackgroundInitializer<String> init = builder.get();
            assertSame(exec, init.getExternalExecutor());
            init.start();
            assertEquals("ext", init.get());
            assertFalse(exec.isShutdown());
        } finally {
            exec.shutdown();
            awaitTermination(exec);
        }
    }

    @Test
    void testBuilderCloserIsInvokedOnClose() throws ConcurrentException {
        final StringBuilder closedWith = new StringBuilder();
        final BackgroundInitializer.Builder<BackgroundInitializer<String>, String> builder = BackgroundInitializer.builder();
        builder.setInitializer(new FailableSupplier<String, ConcurrentException>() {
            @Override
            public String get() {
                return "closable";
            }
        });
        builder.setCloser(new FailableConsumer<String, ConcurrentException>() {
            @Override
            public void accept(final String value) {
                closedWith.append(value);
            }
        });
        final BackgroundInitializer<String> init = builder.get();
        init.start();
        init.get();
        assertEquals(0, closedWith.length(), "Closer must not run before close() is called");
        init.close();
        assertEquals("closable", closedWith.toString(), "Closer should receive the initialized value");
    }

    @Test
    void testDefaultBuilderInitializerReturnsNull() throws ConcurrentException {
        final BackgroundInitializer.Builder<BackgroundInitializer<Object>, Object> builder = BackgroundInitializer.builder();
        final BackgroundInitializer<Object> init = builder.get();
        init.start();
        assertNull(init.get(), "Default builder initializer supplies null");
        assertTrue(init.isInitialized());
    }

    @Test
    void testMultipleInitializersAreIndependent() throws ConcurrentException {
        final AgentBackgroundInitializer init1 = new AgentBackgroundInitializer();
        final AgentBackgroundInitializer init2 = new AgentBackgroundInitializer();
        init1.start();
        init2.start();
        assertEquals(AgentBackgroundInitializer.RESULT, init1.get());
        assertEquals(AgentBackgroundInitializer.RESULT, init2.get());
        assertNotSame(init1.getActiveExecutor(), init2.getActiveExecutor(), "Each instance should get its own temporary executor");
    }

    @Test
    void testInitializeOnlyInvokedOnce() throws ConcurrentException {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        init.start();
        init.get();
        init.get();
        init.get();
        assertEquals(1, init.initializeCalls, "initialize() must only run once even with repeated get() calls");
    }

    @Test
    void testProtectedNoArgConstructorHasNoExternalExecutor() {
        final BackgroundInitializer<Integer> init = new AgentBackgroundInitializer();
        assertNull(init.getExternalExecutor());
        assertFalse(init.isStarted());
    }

    @Test
    void testStartIsIdempotentRegardingFuture() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        init.start();
        final Future<Integer> future = init.getFuture();
        init.start();
        assertSame(future, init.getFuture(), "A second start() call must not replace the existing Future");
    }
}
