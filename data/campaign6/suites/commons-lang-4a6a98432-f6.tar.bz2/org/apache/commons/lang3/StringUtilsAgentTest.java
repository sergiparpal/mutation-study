/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    // ---- abbreviate ----

    @Test
    public void testAbbreviate_basic() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
    }

    @Test
    public void testAbbreviate_tooSmallWidthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    public void testAbbreviate_withOffset() {
        assertNull(StringUtils.abbreviate(null, 5, 10));
        assertEquals("", StringUtils.abbreviate("", 0, 4));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", -1, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 0, 10));
        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 8, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 10, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 12, 10));
    }

    @Test
    public void testAbbreviate_withMarker() {
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", (String) null, 10));
        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("ab..", StringUtils.abbreviate("abcdefg", "..", 4));
    }

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    // ---- appendIfMissing ----

    @Test
    public void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, null));
        assertEquals("abc", StringUtils.appendIfMissing("abc", null));
        assertEquals("xyz", StringUtils.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
    }

    // ---- capitalize / uncapitalize ----

    @Test
    public void testCapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAT", StringUtils.capitalize("CAT"));
    }

    @Test
    public void testUncapitalize() {
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("cat"));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    // ---- center ----

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals("ab", StringUtils.center("ab", 2));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
    }

    // ---- chomp / chop ----

    @Test
    public void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc ", StringUtils.chomp("abc \r"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
    }

    @Test
    public void testChop() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("ab\n"));
    }

    // ---- compare ----

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("a", "b") < 0);
    }

    @Test
    public void testCompare_nullIsLess() {
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);
    }

    // ---- contains family ----

    @Test
    public void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "a"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsIgnoreCase() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertFalse(StringUtils.containsIgnoreCase("abc", null));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "z"));
    }

    @Test
    public void testContainsAny() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertFalse(StringUtils.containsAny("", 'a'));
        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", 'z', 'y'));
    }

    @Test
    public void testContainsNone() {
        assertTrue(StringUtils.containsNone(null, 'a'));
        assertTrue(StringUtils.containsNone("ab", (char[]) null));
        assertTrue(StringUtils.containsNone("ab", 'z'));
        assertFalse(StringUtils.containsNone("abc", 'c', 'z'));
    }

    @Test
    public void testContainsOnly() {
        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertFalse(StringUtils.containsOnly("ab", (char[]) null));
        assertTrue(StringUtils.containsOnly("", 'a'));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcd", 'a', 'b'));
    }

    @Test
    public void testContainsWhitespace() {
        assertFalse(StringUtils.containsWhitespace(""));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("a b"));
    }

    // ---- countMatches ----

    @Test
    public void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(3, StringUtils.countMatches("abcabcabc", 'a'));
        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "ab"));
    }

    // ---- defaultString / defaultIfBlank / defaultIfEmpty ----

    @Test
    public void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));
    }

    @Test
    public void testDefaultIfBlank() {
        assertEquals("NULL", StringUtils.defaultIfBlank((String) null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank(" ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NULL"));
    }

    @Test
    public void testDefaultIfEmpty() {
        assertEquals("NULL", StringUtils.defaultIfEmpty((String) null, "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals(" ", StringUtils.defaultIfEmpty(" ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
    }

    // ---- deleteWhitespace ----

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));
    }

    // ---- difference ----

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("", StringUtils.difference("abc", ""));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("", StringUtils.difference("abc", "ab"));
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "xyz"));
    }

    // ---- endsWithAny / startsWithAny ----

    @Test
    public void testEndsWithAny() {
        assertFalse(StringUtils.endsWithAny(null, "abc"));
        assertFalse(StringUtils.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz"));
        assertTrue(StringUtils.endsWithAny("abcxyz", (String) null, "xyz"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "abc"));
    }

    @Test
    public void testStartsWithAny() {
        assertFalse(StringUtils.startsWithAny(null, "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(StringUtils.startsWithAny("abcxyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz"));
    }

    // ---- equals / equalsIgnoreCase / equalsAny ----

    @Test
    public void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abcd"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    public void testEqualsAny() {
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
        assertFalse(StringUtils.equalsAny("abc"));
        assertTrue(StringUtils.equalsAny("abc", "abc", "xyz"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "mno"));
        assertTrue(StringUtils.equalsAny(null, (CharSequence) null));
    }

    // ---- firstNonBlank / firstNonEmpty ----

    @Test
    public void testFirstNonBlank() {
        assertNull(StringUtils.firstNonBlank());
        assertNull(StringUtils.firstNonBlank((String) null, "", " "));
        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));
    }

    @Test
    public void testFirstNonEmpty() {
        assertNull(StringUtils.firstNonEmpty());
        assertNull(StringUtils.firstNonEmpty((String) null, ""));
        assertEquals(" ", StringUtils.firstNonEmpty(null, "", " "));
    }

    // ---- getCommonPrefix ----

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix("abc", null));
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
    }

    // ---- getDigits ----

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1012", StringUtils.getDigits("age 10, score 12"));
    }

    // ---- getFuzzyDistance ----

    @Test
    public void testGetFuzzyDistance() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH);
            }
        });
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(0, StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Room", "o", Locale.ENGLISH));
        assertEquals(4, StringUtils.getFuzzyDistance("Workshop", "wo", Locale.ENGLISH));
    }

    // ---- getJaroWinklerDistance ----

    @Test
    public void testGetJaroWinklerDistance() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "a");
            }
        });
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("", ""), 0.0001);
        assertEquals(0.93, StringUtils.getJaroWinklerDistance("frog", "fog"), 0.0001);
        assertEquals(0.0, StringUtils.getJaroWinklerDistance("fly", "ant"), 0.0001);
        assertEquals(0.88, StringUtils.getJaroWinklerDistance("hello", "hallo"), 0.0001);
    }

    // ---- getLevenshteinDistance ----

    @Test
    public void testGetLevenshteinDistance_null() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(7, StringUtils.getLevenshteinDistance("", "aaapppp"));
        assertEquals(1, StringUtils.getLevenshteinDistance("hello", "hallo"));
        assertEquals(7, StringUtils.getLevenshteinDistance("hippo", "elephant"));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
    }

    @Test
    public void testGetLevenshteinDistance_threshold() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 0));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 8));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("aaapppp", "", 6));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
    }

    // ---- indexOf family ----

    @Test
    public void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab", 0));
    }

    @Test
    public void testIndexOf_char() {
        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'a'));
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
        assertEquals(-1, StringUtils.indexOf("aabaabaa", 'z'));
    }

    @Test
    public void testIndexOfAny() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a', 'b'));
        assertEquals(-1, StringUtils.indexOfAny("", 'a', 'b'));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", 'b', 'y'));
        assertEquals(-1, StringUtils.indexOfAny("aba", 'z'));
    }

    @Test
    public void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference(null, null));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference("", ""));
        assertEquals(0, StringUtils.indexOfDifference("abc", ""));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "a"));
        assertEquals(2, StringUtils.indexOfDifference("ab", "abxyz"));
        assertEquals(2, StringUtils.indexOfDifference("abcde", "abxyz"));
    }

    @Test
    public void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("", ""));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));
    }

    // ---- isAllBlank / isAllEmpty / isAnyBlank / isAnyEmpty / isNoneBlank / isNoneEmpty ----

    @Test
    public void testIsAllBlank() {
        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank((String) null));
        assertTrue(StringUtils.isAllBlank(null, " "));
        assertFalse(StringUtils.isAllBlank(null, "foo"));
        assertFalse(StringUtils.isAllBlank("", "bar"));
    }

    @Test
    public void testIsAnyBlank() {
        assertFalse(StringUtils.isAnyBlank());
        assertTrue(StringUtils.isAnyBlank((String) null));
        assertTrue(StringUtils.isAnyBlank(null, "foo"));
        assertTrue(StringUtils.isAnyBlank("", "bar"));
        assertFalse(StringUtils.isAnyBlank("foo", "bar"));
    }

    @Test
    public void testIsNoneBlank() {
        assertTrue(StringUtils.isNoneBlank());
        assertFalse(StringUtils.isNoneBlank((String) null));
        assertFalse(StringUtils.isNoneBlank(null, "foo"));
        assertTrue(StringUtils.isNoneBlank("foo", "bar"));
    }

    // ---- isAlpha / isAlphanumeric / isNumeric / isWhitespace ----

    @Test
    public void testIsAlpha() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));
    }

    @Test
    public void testIsAlphanumeric() {
        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    public void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));
    }

    @Test
    public void testIsWhitespace() {
        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace("abc"));
        assertFalse(StringUtils.isWhitespace(" ab"));
    }

    // ---- isMixedCase / isAllLowerCase / isAllUpperCase ----

    @Test
    public void testIsMixedCase() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
        assertFalse(StringUtils.isMixedCase("A"));
    }

    @Test
    public void testIsAllLowerCase() {
        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab c"));
        assertFalse(StringUtils.isAllLowerCase("ab1c"));
    }

    // ---- isBlank / isEmpty / isNotBlank / isNotEmpty ----

    @Test
    public void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("  "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" abc "));
    }

    @Test
    public void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));
    }

    // ---- join family ----

    @Test
    public void testJoin_objectArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] {"a"}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    public void testJoin_withSeparatorString() {
        assertNull(StringUtils.join((Object[]) null, "-"));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
    }

    @Test
    public void testJoin_iterable() {
        assertNull(StringUtils.join((Iterable<?>) null, ','));
        assertEquals("a;b;c", StringUtils.join(Arrays.asList("a", "b", "c"), ';'));
    }

    @Test
    public void testJoin_intArray() {
        assertEquals("1-2-3", StringUtils.join(new int[] {1, 2, 3}, '-'));
        assertEquals("2-3", StringUtils.join(new int[] {1, 2, 3}, '-', 1, 3));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a,b,c", StringUtils.joinWith(",", "a", "b", "c"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    // ---- lastIndexOf family ----

    @Test
    public void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(-1, StringUtils.lastIndexOf("abc", null));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));
    }

    @Test
    public void testLastOrdinalIndexOf() {
        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.lastOrdinalIndexOf(null, "a", 1));
    }

    // ---- left / right / mid ----

    @Test
    public void testLeft() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("", StringUtils.left("", 2));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testRight() {
        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("", StringUtils.right("", 2));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testMid() {
        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("", 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 4));
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    // ---- leftPad / rightPad ----

    @Test
    public void testLeftPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("   ", StringUtils.leftPad("", 3));
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
        assertEquals("bat", StringUtils.leftPad("bat", 3));
        assertEquals("bat", StringUtils.leftPad("bat", -1));
        assertEquals("xxbat", StringUtils.leftPad("bat", 5, 'x'));
        assertEquals("xyxybat", StringUtils.leftPad("bat", 7, "xy"));
    }

    @Test
    public void testRightPad() {
        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
        assertEquals("bat", StringUtils.rightPad("bat", 3));
        assertEquals("batxx", StringUtils.rightPad("bat", 5, 'x'));
        assertEquals("batxyx", StringUtils.rightPad("bat", 6, "xy"));
    }

    // ---- length ----

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    // ---- lowerCase / upperCase ----

    @Test
    public void testLowerUpperCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("", StringUtils.lowerCase(""));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
    }

    // ---- normalizeSpace ----

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("", StringUtils.normalizeSpace("    "));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    // ---- ordinalIndexOf ----

    @Test
    public void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("", "", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(2, StringUtils.ordinalIndexOf("aabaabaa", "b", 1));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "b", 2));
        assertEquals(0, StringUtils.ordinalIndexOf("ababab", "aba", 1));
        assertEquals(2, StringUtils.ordinalIndexOf("ababab", "aba", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("ababab", "aba", 3));
    }

    // ---- overlay ----

    @Test
    public void testOverlay() {
        assertNull(StringUtils.overlay(null, "x", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
        assertEquals("abzzzz", StringUtils.overlay("abcdef", "zzzz", 2, 8));
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    // ---- prependIfMissing ----

    @Test
    public void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, null));
        assertEquals("abc", StringUtils.prependIfMissing("abc", null));
        assertEquals("xyz", StringUtils.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
    }

    // ---- remove family ----

    @Test
    public void testRemove_char() {
        assertNull(StringUtils.remove((String) null, 'a'));
        assertEquals("", StringUtils.remove("", 'a'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("abc", StringUtils.remove("abc", 'z'));
    }

    @Test
    public void testRemove_string() {
        assertNull(StringUtils.remove((String) null, "a"));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("abc", StringUtils.remove("abc", null));
    }

    @Test
    public void testRemoveStart() {
        assertNull(StringUtils.removeStart(null, "www."));
        assertEquals("abc", StringUtils.removeStart("abc", null));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("abc", StringUtils.removeStart("abc", "www."));
    }

    @Test
    public void testRemoveEnd() {
        assertNull(StringUtils.removeEnd(null, ".com"));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("abc", StringUtils.removeEnd("abc", ".com"));
    }

    // ---- repeat ----

    @Test
    public void testRepeat_char() {
        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));
        assertEquals("", StringUtils.repeat('e', -2));
    }

    @Test
    public void testRepeat_string() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat("ab", -1));
    }

    @Test
    public void testRepeat_withSeparator() {
        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("", StringUtils.repeat("ab", "-", 0));
        assertEquals("ab", StringUtils.repeat("ab", "-", 1));
        assertEquals("ab-ab-ab", StringUtils.repeat("ab", "-", 3));
    }

    // ---- replace family ----

    @Test
    public void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("any", StringUtils.replace("any", "a", null));
        assertEquals("any", StringUtils.replace("any", "", "b"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
    }

    @Test
    public void testReplaceOnce() {
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
    }

    @Test
    public void testReplaceIgnoreCase() {
        assertEquals("zbz", StringUtils.replaceIgnoreCase("aba", "A", "z"));
    }

    @Test
    public void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, 'a', 'z'));
        assertEquals("jello", StringUtils.replaceChars("hello", 'h', 'j'));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yz"));
    }

    // ---- reverse ----

    @Test
    public void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    // ---- rotate ----

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", -7));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 9));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -9));
    }

    // ---- split family ----

    @Test
    public void testSplit_char() {
        assertNull(StringUtils.split(null, '.'));
        assertArrayEquals(new String[0], StringUtils.split("", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
        assertArrayEquals(new String[] {"a:b:c"}, StringUtils.split("a:b:c", '.'));
    }

    @Test
    public void testSplit_whitespace() {
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc def"));
        assertArrayEquals(new String[0], StringUtils.split(""));
    }

    @Test
    public void testSplit_separatorCharsMax() {
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":", 0));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
    }

    @Test
    public void testSplitPreserveAllTokens() {
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] {"", "a", "b", "c", ""}, StringUtils.splitPreserveAllTokens(".a.b.c.", '.'));
    }

    @Test
    public void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "."));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "cd-!-ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-", 2));
    }

    // ---- startsWith / endsWith ----

    @Test
    public void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertFalse(StringUtils.endsWith("abcdef", null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWith("ABCDEF", ""));
    }

    // ---- strip family ----

    @Test
    public void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip(" abc  ", " "));
    }

    @Test
    public void testStripToEmpty() {
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("", StringUtils.stripToEmpty("   "));
        assertEquals("abc", StringUtils.stripToEmpty(" abc "));
    }

    @Test
    public void testStripToNull() {
        assertNull(StringUtils.stripToNull(null));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull(" abc "));
    }

    @Test
    public void testStripStartStripEnd() {
        assertNull(StringUtils.stripStart(null, "x"));
        assertEquals("abcyx", StringUtils.stripStart("xxabcyx", "x"));
        assertNull(StringUtils.stripEnd(null, "x"));
        assertEquals("xyabc", StringUtils.stripEnd("xyabcxx", "x"));
    }

    // ---- substring family ----

    @Test
    public void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 1));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));
    }

    @Test
    public void testSubstring_startEnd() {
        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("bc", StringUtils.substring("abc", -2, 3));
    }

    @Test
    public void testSubstringBefore_After() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("", StringUtils.substringBefore("abc", "a"));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
    }

    @Test
    public void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("", ""));
        assertNull(StringUtils.substringBetween("", "tag"));
        assertEquals("", StringUtils.substringBetween("abc", ""));
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertEquals("abc", StringUtils.substringBetween("yabcz", "y", "z"));
        assertNull(StringUtils.substringBetween("yabcz", null, "z"));
    }

    // ---- swapCase ----

    @Test
    public void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("Th3 Quick Brown Fox", StringUtils.swapCase("tH3 qUICK bROWN fOX"));
    }

    // ---- trim ----

    @Test
    public void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("     "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    public void testTrimToEmptyToNull() {
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull(" abc "));
    }

    // ---- truncate ----

    @Test
    public void testTruncate_maxWidth() {
        assertNull(StringUtils.truncate(null, 0));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 3));
        assertEquals("", StringUtils.truncate("abcdefg", 0));
    }

    @Test
    public void testTruncate_maxWidthNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghij", -1);
            }
        });
    }

    @Test
    public void testTruncate_offsetAndWidth() {
        assertNull(StringUtils.truncate(null, 2, 4));
        assertEquals("", StringUtils.truncate("", 2, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("peach", StringUtils.truncate("raspberry peach", 10, 15));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghijklmno", 0, 10));
        assertEquals("bcdefghijk", StringUtils.truncate("abcdefghijklmno", 1, 10));
        assertEquals("klm", StringUtils.truncate("abcdefghijklmno", 10, 3));
        assertEquals("", StringUtils.truncate("abcdefghijklmno", 15, 1));
    }

    @Test
    public void testTruncate_negativeOffsetThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghij", -2, 4);
            }
        });
    }

    @Test
    public void testTruncate_negativeWidthThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghij", 3, -1);
            }
        });
    }

    // ---- unwrap / wrap / wrapIfMissing ----

    @Test
    public void testWrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("", StringUtils.wrap("", 'x'));
    }

    @Test
    public void testWrapIfMissing_char() {
        assertNull(StringUtils.wrapIfMissing(null, '"'));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("ab", '"'));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", '"'));
    }

    @Test
    public void testWrapIfMissing_string() {
        assertNull(StringUtils.wrapIfMissing(null, "x"));
        assertEquals("", StringUtils.wrapIfMissing("", "x"));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", (String) null));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", "x"));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("ab", "\""));
        assertEquals("\"ab\"", StringUtils.wrapIfMissing("\"ab\"", "\""));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", "/"));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("/a/b/c", "/"));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c/", "/"));
        assertEquals("/", StringUtils.wrapIfMissing("/", "/"));
    }

    @Test
    public void testUnwrap_char() {
        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("ab", StringUtils.unwrap("xabx", 'x'));
        assertEquals("abx", StringUtils.unwrap("abx", 'x'));
    }

    @Test
    public void testUnwrap_string() {
        assertNull(StringUtils.unwrap(null, "'"));
        assertEquals("abc", StringUtils.unwrap("'abc'", "'"));
    }

    // ---- toCodePoints / valueOf / toString ----

    @Test
    public void testToCodePoints() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
    }

    @Test
    public void testValueOf() {
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    // ---- toRootLowerCase / toRootUpperCase ----

    @Test
    public void testToRootLowerUpperCase() {
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }
}
