/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

class CSVParserAgentTest {

    @Test
    void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,25\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("name", parser.getHeaderNames().get(0));
            assertEquals("age", parser.getHeaderNames().get(1));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("25", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapReturnsCopyNotLive() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("c", 99);
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse(map2.containsKey("c"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoHeaderMapIsNull() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2,3\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDuplicateHeaderNameThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,a\n1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,\n1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setAllowMissingColumnNames(true)
                .get();
        final CSVParser parser = CSVParser.parse("a,\n1,2\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("a", parser.getHeaderNames().get(0));
            assertEquals("", parser.getHeaderNames().get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testCloseMakesParserClosedAndIteratorEmpty() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    void testIteratorThrowsAfterLastRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            final CSVRecord record = it.next();
            assertEquals("a", record.get(0));
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testRecordNumberIncrementsPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = parser.nextRecord();
            assertEquals(3, r3.getRecordNumber());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    @Test
    void testRecordNumberStartsAtBuilderValue() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(5)
                .get();
        try {
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(5, r1.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testNullStringConvertsToNull() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailingDelimiterDropsLastEmptyField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testCommentsAreCapturedOnRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("# a comment\na,b\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a comment", record.getComment());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderCommentCaptured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();
        final CSVParser parser = CSVParser.parse("# header comment\na,b\n1,2\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailerCommentCapturedAfterFullRead() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("a,b\n# trailer\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidInputThrowsCSVException() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final UncheckedIOException thrown = assertThrows(UncheckedIOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVParser parser = CSVParser.parse("\"unterminated", format);
                try {
                    parser.getRecords();
                } finally {
                    parser.close();
                }
            }
        });
        assertTrue(thrown.getCause() instanceof CSVException);
    }

    @Test
    void testParseNullStringThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseNullFileThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseFileFromDisk() throws IOException {
        final File tempFile = Files.createTempFile("csv-parser-agent-test", ".csv").toFile();
        tempFile.deleteOnExit();
        Files.write(tempFile.toPath(), "x,y\n1,2\n".getBytes(StandardCharsets.UTF_8));
        final CSVParser parser = CSVParser.parse(tempFile, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
        } finally {
            parser.close();
            Files.deleteIfExists(tempFile.toPath());
        }
    }

    @Test
    void testStreamProducesSameRecordsAsGetRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> streamed = parser.stream().collect(java.util.stream.Collectors.toList());
            assertEquals(2, streamed.size());
            assertEquals("1", streamed.get(0).get(0));
            assertEquals("3", streamed.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testMaxRowsLimitsRecordsReturned() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetRecordsOnClosedParserIsEmpty() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        parser.close();
        final List<CSVRecord> records = parser.getRecords();
        assertNotNull(records);
        assertTrue(records.isEmpty());
    }

    @Test
    void testIgnoreHeaderCaseMakesHeaderMapCaseInsensitive() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setIgnoreHeaderCase(true)
                .get();
        final CSVParser parser = CSVParser.parse("Name,Age\nJohn,25\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("John", record.get("name"));
            assertEquals("25", record.get("AGE"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testCurrentLineNumberAdvances() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }
}
