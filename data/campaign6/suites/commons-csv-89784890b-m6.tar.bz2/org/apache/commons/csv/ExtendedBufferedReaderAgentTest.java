/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    /**
     * A reader that only ever returns one character per {@code read} call, used to exercise the
     * "keep reading until full" looping logic in {@code read(char[], int, int)} and {@code peek(char[])}.
     */
    private static final class ChunkedReader extends Reader {

        private final String content;
        private int idx;

        ChunkedReader(final String content) {
            this.content = content;
        }

        @Override
        public void close() {
            // no resources to release
        }

        @Override
        public int read(final char[] cbuf, final int off, final int len) {
            if (idx >= content.length()) {
                return -1;
            }
            cbuf[off] = content.charAt(idx);
            idx++;
            return 1;
        }
    }

    @Test
    void testInitialState() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(Constants.UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals(0, reader.getLineNumber());
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testReadSingleCharUpdatesState() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals('a', reader.read());
        assertEquals('a', reader.getLastChar());
        assertEquals(1, reader.getPosition());
        assertEquals('b', reader.read());
        assertEquals('b', reader.getLastChar());
        assertEquals(2, reader.getPosition());
    }

    @Test
    void testReadSingleCharAtEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(-1, reader.read());
        assertEquals(-1, reader.getLastChar());
    }

    @Test
    void testReadArrayNormal() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        final char[] buf = new char[5];
        final int n = reader.read(buf, 0, 5);
        assertEquals(2, n);
        assertEquals('a', buf[0]);
        assertEquals('b', buf[1]);
        assertEquals('b', reader.getLastChar());
        assertEquals(2, reader.getPosition());
    }

    @Test
    void testReadArrayZeroLengthReturnsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        final char[] buf = new char[5];
        assertEquals(0, reader.read(buf, 0, 0));
        assertEquals(Constants.UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
    }

    @Test
    void testReadArrayAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        final char[] buf = new char[5];
        assertEquals(-1, reader.read(buf, 0, 5));
        assertEquals(-1, reader.getLastChar());
    }

    @Test
    void testReadArrayFillsFullArrayDespiteShortUnderlyingReads() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new ChunkedReader("abcde"));
        final char[] buf = new char[5];
        final int n = reader.read(buf, 0, 5);
        assertEquals(5, n);
        assertEquals("abcde", new String(buf, 0, n));
    }

    @Test
    void testPeekDoesNotConsume() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals('a', reader.peek());
        assertEquals(0, reader.getPosition());
        assertEquals('a', reader.read());
        assertEquals(1, reader.getPosition());
    }

    @Test
    void testPeekArrayDoesNotConsume() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        final char[] peekBuf = new char[5];
        final int pn = reader.peek(peekBuf);
        assertEquals(2, pn);
        assertEquals("ab", new String(peekBuf, 0, pn));
        assertEquals(0, reader.getPosition());
        assertEquals('a', reader.read());
        assertEquals(1, reader.getPosition());
    }

    @Test
    void testPeekArrayEmptyArrayReturnsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals(0, reader.peek(new char[0]));
        assertEquals(0, reader.getPosition());
    }

    @Test
    void testPeekArrayAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(-1, reader.peek(new char[5]));
    }

    @Test
    void testPeekArrayFillsFullArrayDespiteShortUnderlyingReads() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new ChunkedReader("abcde"));
        final char[] peekBuf = new char[5];
        final int pn = reader.peek(peekBuf);
        assertEquals(5, pn);
        assertEquals("abcde", new String(peekBuf, 0, pn));
        assertEquals(0, reader.getPosition());
    }

    @Test
    void testMarkAndReset() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\nb"));
        reader.read(); // 'a'
        reader.mark(10);
        reader.read(); // '\n'
        assertEquals(1, reader.getLineNumber());
        assertEquals(2, reader.getPosition());
        reader.reset();
        assertEquals('a', reader.getLastChar());
        assertEquals(1, reader.getPosition());
        assertEquals(1, reader.getLineNumber());
        assertEquals('\n', reader.read());
    }

    @Test
    void testGetLineNumberInitialAndMidLine() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0, reader.getLineNumber());
        reader.read();
        // Not yet at an EOL, so the line is counted as started.
        assertEquals(1, reader.getLineNumber());
    }

    @Test
    void testGetLineNumberCrLfCountsAsOneLine() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\r\nb"));
        reader.read(); // 'a'
        reader.read(); // '\r'
        assertEquals(1, reader.getLineNumber());
        reader.read(); // '\n' following '\r' must not count as a second line
        assertEquals(1, reader.getLineNumber());
    }

    @Test
    void testGetLineNumberAtEofWithoutTrailingEol() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a"));
        reader.read(); // 'a'
        assertEquals(1, reader.getLineNumber());
        assertEquals(-1, reader.read()); // EOF
        assertEquals(1, reader.getLineNumber());
    }

    @Test
    void testReadLineDropsTerminators() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\r\nline2\nline3"));
        assertEquals("line1", reader.readLine());
        assertEquals(1, reader.getLineNumber());
        assertEquals("line2", reader.readLine());
        assertEquals(2, reader.getLineNumber());
        assertEquals("line3", reader.readLine());
        assertEquals(3, reader.getLineNumber());
        assertNull(reader.readLine());
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        reader.close();
        assertEquals(-1, reader.getLastChar());
        assertThrows(IOException.class, reader::read);
    }

    @Test
    void testBytesReadIsZeroWithoutCharset() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testBytesReadIsZeroWhenTrackBytesIsFalse() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"), StandardCharsets.UTF_8, false);
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testBytesReadTracksUtf8EncodedLength() throws IOException {
        // 'a' is 1 byte in UTF-8, the Latin small letter e with acute is 2 bytes.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("aé"), StandardCharsets.UTF_8, true);
        reader.read();
        assertEquals(1, reader.getBytesRead());
        reader.read();
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testBytesReadTracksUtf8EncodedLengthAcrossArrayRead() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("aé"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[2];
        final int n = reader.read(buf, 0, 2);
        assertEquals(2, n);
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testBytesReadSubtractsRepeatedUtf16Bom() throws IOException {
        // Each call to the encoder on UTF-16 would prepend a 2-byte BOM; the per-char byte count
        // must not include that BOM on every single character read.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"), StandardCharsets.UTF_16, true);
        reader.read();
        assertEquals(2, reader.getBytesRead());
        reader.read();
        assertEquals(4, reader.getBytesRead());
    }

    @Test
    void testBytesReadForSurrogatePairInUtf8() throws IOException {
        // U+1F600 is encoded as a surrogate pair in UTF-16 chars and as 4 bytes in UTF-8.
        final String emoji = new String(Character.toChars(0x1F600));
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(emoji), StandardCharsets.UTF_8, true);
        reader.read(); // high surrogate alone contributes no bytes yet
        assertEquals(0, reader.getBytesRead());
        reader.read(); // low surrogate completes the pair
        assertEquals(4, reader.getBytesRead());
    }

    @Test
    void testUnpairedLowSurrogateThrowsCharacterCodingException() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\udc00"), StandardCharsets.UTF_8, true);
        assertThrows(CharacterCodingException.class, reader::read);
    }

    @Test
    void testReadArrayAfterEofMovesPositionBackward() throws IOException {
        // Reflects the reader's actual accounting: position is advanced by the return value of the
        // underlying read, including the -1 reported at end of stream.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        final char[] buf = new char[5];
        assertEquals(-1, reader.read(buf, 0, 5));
        assertEquals(-1, reader.getPosition());
    }
}
