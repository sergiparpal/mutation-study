/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
class ExtendedMessageFormatAgentTest {

    /**
     * Custom format that upper-cases its argument's string value.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    /**
     * Custom format that appends a fixed suffix (the factory "arguments") to its argument.
     */
    private static final class SuffixFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String suffix;

        SuffixFormat(final String suffix) {
            this.suffix = suffix;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj)).append(suffix);
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    /**
     * Registers "upper" (no style support) and "suffix" (style is the suffix text); anything
     * else is left to the standard {@link MessageFormat} machinery.
     */
    private static final class TestFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            if ("upper".equals(name)) {
                return new UpperCaseFormat();
            }
            if ("suffix".equals(name)) {
                return new SuffixFormat(arguments);
            }
            return null;
        }
    }

    private static Map<String, FormatFactory> registry() {
        final Map<String, FormatFactory> map = new HashMap<String, FormatFactory>();
        final FormatFactory factory = new TestFormatFactory();
        map.put("upper", factory);
        map.put("suffix", factory);
        return map;
    }

    // -------------------------------------------------------------- basics

    @Test
    void testSimplePatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    @Test
    void testStandardNumberFormatStillWorksWithRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,00.00}", registry());
        assertEquals("03.50", emf.format(new Object[] {3.5}));
    }

    @Test
    void testChoiceFormatFallback() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#no files|1#one file|1<{0} files}");
        assertEquals("no files", emf.format(new Object[] {0}));
        assertEquals("one file", emf.format(new Object[] {1}));
        assertEquals("3 files", emf.format(new Object[] {3}));
    }

    @Test
    void testExplicitLocaleIsStored() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null);
        assertNotNull(emf.getLocale());
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    // ------------------------------------------------------- custom formats

    @Test
    void testCustomFormatIsApplied() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testCustomFormatWithArguments() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,suffix,!!}", registry());
        assertEquals("abc!!", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testCustomFormatRoundTripsThroughToPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry());
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    void testMultipleFormatElementsMixCustomAndStandard() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} costs {1,number,0.00}", registry());
        assertEquals("ABC costs 3.50", emf.format(new Object[] {"abc", 3.5}));
    }

    @Test
    void testUnknownFormatNameFallsBackToPlainArgument() {
        // "bogus" is not in the registry and is not a standard MessageFormat type,
        // so the JDK MessageFormat itself must reject it.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,bogus}", registry());
            }
        });
    }

    // ------------------------------------------------------------- quoting

    @Test
    void testQuotedLiteralBracesAreNotFormatElements() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{'{0,upper}'}'", registry());
        assertEquals("{ABC}", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testDoubledQuoteIsLiteralApostrophe() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0,upper}", registry());
        assertEquals("it's ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper} and 'unterminated", registry());
            }
        });
    }

    // ----------------------------------------------------------- bad input

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", registry());
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{abc}", registry());
            }
        });
    }

    @Test
    void testUnreadableFormatElementThrows() {
        // Whitespace followed by something other than ',' or '}' after the argument index.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0 x}", registry());
            }
        });
    }

    @Test
    void testNegativeArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{-1}", registry());
            }
        });
    }

    // ------------------------------------------------------- applyPattern

    @Test
    void testApplyPatternChangesPatternAndFormatOutput() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", registry());
        assertEquals("first", emf.format(new Object[] {"first"}));
        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("SECOND", emf.format(new Object[] {"second"}));
    }

    // ------------------------------------------------------- equals/hashCode

    @Test
    void testEqualsReflexiveAndNull() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", registry());
        assertEquals(emf, emf);
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsSamePatternLocaleAndRegistry() {
        // Use a pattern whose format elements are all standard (JDK-provided) formats, since
        // the custom "upper"/"suffix" factories hand back a fresh Format instance on every
        // call and plain Format/Object equality is identity-based, which would make even two
        // otherwise-identical ExtendedMessageFormats compare unequal via MessageFormat's own
        // equals() long before ExtendedMessageFormat's additional registry/toPattern checks run.
        final Map<String, FormatFactory> shared = registry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,number,0.00}", Locale.US, shared);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,number,0.00}", Locale.US, shared);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testNotEqualsDifferentPattern() {
        final Map<String, FormatFactory> shared = registry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", Locale.US, shared);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,suffix,!!}", Locale.US, shared);
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testNotEqualsDifferentLocale() {
        final Map<String, FormatFactory> shared = registry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,number,0.00}", Locale.US, shared);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,number,0.00}", Locale.GERMANY, shared);
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testNotEqualsPlainMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        final MessageFormat plain = new MessageFormat("{0}");
        assertFalse(emf.equals(plain));
    }

    // -------------------------------------------- disabled mutator methods

    @Test
    void testSetFormatThrowsAndLeavesStateUnchanged() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testSetFormatByArgumentIndexThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrows() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    // ------------------------------------------------------------- misc

    @Test
    void testRepeatedArgumentIndexBothFormatted() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} / {0,upper}", registry());
        assertEquals("ABC / ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testIsExtendsMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf instanceof MessageFormat);
    }
}
