/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * A simple lower-casing format used to exercise the registry mechanism.
     */
    private static final class LowerFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toLowerCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    private static final class LowerFormatFactory implements FormatFactory {
        // Shared instance so that two ExtendedMessageFormat objects built from equal
        // patterns end up with equal (same-identity) underlying Format instances,
        // which java.text.MessageFormat.equals requires.
        private static final LowerFormat INSTANCE = new LowerFormat();

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return "lower".equals(name) ? INSTANCE : null;
        }
    }

    private Map<String, FormatFactory> registry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("lower", new LowerFormatFactory());
        return registry;
    }

    @Test
    void testSimplePatternWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    @Test
    void testNullPatternThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        // The error-handling code path for a malformed format element is only reachable
        // when a non-null registry forces custom pattern parsing.
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0", registry());
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0x}", registry());
                    }
                });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    void testUnmatchedBracesWithoutRegistryThrows() {
        // Without a registry, applyPattern delegates straight to java.text.MessageFormat.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    void testCustomFormatRegistryAppliedAndToPatternPreservesCustomDescription() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", registry());
        assertEquals("world", emf.format(new Object[] {"WORLD"}));
        assertEquals("{0,lower}", emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsBackToStandardFormat() {
        // "unknown" is not in the registry, so MessageFormat parses it as a standard
        // style/subformat token and fails validation for unsupported format type "unknown".
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknown}", registry());
            }
        });
    }

    @Test
    void testQuotedLiteralTextIsNotParsedAsFormatElement() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' and {1}", registry());
        final String formatted = emf.format(new Object[] {"ignored", "real"});
        assertEquals("{0} and real", formatted);
    }

    @Test
    void testUnmatchedQuoteTreatedAsClosedAtEndOfPattern() {
        // A trailing unmatched quote should not throw, mirroring MessageFormat's lenience.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("abc'def", registry());
        assertEquals("abcdef", emf.format(new Object[0]));
    }

    @Test
    void testMixedCustomAndStandardFormatElements() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower} and {1,number}", registry());
        final String result = emf.format(new Object[] {"MIXED", 42});
        assertEquals("mixed and 42", result);
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, null);
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, null);
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[0]);
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[0]);
            }
        });
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final Map<String, FormatFactory> sharedRegistry = registry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,lower}", Locale.US, sharedRegistry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,lower}", Locale.US, sharedRegistry);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsReturnsFalseForDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,lower}", registry());
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", registry());
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testEqualsReturnsFalseForNonExtendedMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals("not a format"));
    }

    @Test
    void testEqualsReturnsFalseForNull() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsReflexive() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    void testLocaleConstructorUsesProvidedLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,currency}", Locale.US, null);
        final String result = emf.format(new Object[] {1234.5});
        assertTrue(result.contains("$"));
    }

    @Test
    void testParseRoundTripsSimpleArguments() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{1}", registry());
        final Object[] parsed = emf.parse("foo-bar");
        assertEquals(2, parsed.length);
        assertEquals("foo", parsed[0]);
        assertEquals("bar", parsed[1]);
    }

    @Test
    void testChoiceFormatPatternPreservedInToPattern() {
        final String pattern = "{0,choice,0#no files|1#one file|1<{0,number} files}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry());
        assertEquals("no files", emf.format(new Object[] {0}));
        assertEquals("one file", emf.format(new Object[] {1}));
        assertEquals("3 files", emf.format(new Object[] {3}));
    }

    @Test
    void testEmptyPatternProducesEmptyOutput() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.format(new Object[0]));
        assertEquals("", emf.toPattern());
    }

    @Test
    void testWhitespaceAroundArgumentIndexIsIgnored() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0 , lower}", registry());
        assertEquals("abc", emf.format(new Object[] {"ABC"}));
    }

    @Test
    void testNullRegistryStillAllowsStandardFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US, null);
        assertEquals("7", emf.format(new Object[] {7}));
    }
}
