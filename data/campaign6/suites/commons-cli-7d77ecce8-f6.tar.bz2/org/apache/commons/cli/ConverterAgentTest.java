/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.junit.jupiter.api.Test;

public class ConverterAgentTest {

    @Test
    public void testDefaultReturnsSameString() throws Exception {
        final Object result = Converter.DEFAULT.apply("hello");
        assertEquals("hello", result);
    }

    @Test
    public void testDefaultWithNullReturnsNull() throws Exception {
        final Object result = Converter.DEFAULT.apply(null);
        assertEquals(null, result);
    }

    @Test
    public void testClassConverterValidClassName() throws Exception {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    public void testClassConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.Class");
            }
        });
    }

    @Test
    public void testFileConverterReturnsFile() throws Exception {
        final File file = Converter.FILE.apply("some-path.txt");
        assertEquals(new File("some-path.txt"), file);
    }

    @Test
    public void testFileConverterNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    public void testPathConverterReturnsPath() throws Exception {
        final Path path = Converter.PATH.apply("some-path.txt");
        assertEquals(Paths.get("some-path.txt"), path);
    }

    @Test
    public void testPathConverterInvalidPathThrows() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("bad\u0000path");
            }
        });
    }

    @Test
    public void testNumberConverterIntegerLikeReturnsLong() throws Exception {
        final Number number = Converter.NUMBER.apply("42");
        assertEquals(Long.valueOf(42L), number);
        assertTrue(number instanceof Long);
    }

    @Test
    public void testNumberConverterNegativeIntegerLikeReturnsLong() throws Exception {
        final Number number = Converter.NUMBER.apply("-7");
        assertEquals(Long.valueOf(-7L), number);
    }

    @Test
    public void testNumberConverterDecimalReturnsDouble() throws Exception {
        final Number number = Converter.NUMBER.apply("3.14");
        assertEquals(Double.valueOf(3.14), number);
        assertTrue(number instanceof Double);
    }

    @Test
    public void testNumberConverterInvalidThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    public void testNumberConverterEmptyStringThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("");
            }
        });
    }

    @Test
    public void testObjectConverterCreatesInstance() throws Exception {
        final Object object = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(object);
        assertEquals(Object.class, object.getClass());
    }

    @Test
    public void testObjectConverterUnknownClassThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.Class");
            }
        });
    }

    @Test
    public void testObjectConverterClassWithoutDefaultConstructorThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("java.lang.Integer");
            }
        });
    }

    @Test
    public void testUrlConverterReturnsUrl() throws Exception {
        final URL url = Converter.URL.apply("https://example.com/path");
        assertEquals("https://example.com/path", url.toString());
    }

    @Test
    public void testUrlConverterMalformedThrows() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    public void testDateConverterParsesRoundTrippedDate() throws Exception {
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        final Date original = format.parse("Mon Jan 01 10:30:00 GMT 2024");
        final String formatted = format.format(original);
        final Date parsed = Converter.DATE.apply(formatted);
        assertEquals(original, parsed);
    }

    @Test
    public void testDateConverterInvalidStringThrows() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("this is not a date");
            }
        });
    }

    @Test
    public void testDateConverterRejectsOutOfRangeDayStrictly() {
        // 2023 is not a leap year, so February only has 28 days; a lenient parser
        // would roll this over to March instead of rejecting it.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Thu Feb 30 00:00:00 GMT 2023");
            }
        });
    }

    @Test
    public void testApplyIsFunctionalAndPropagatesCheckedException() {
        final Converter<Integer, java.io.IOException> converter = new Converter<Integer, java.io.IOException>() {
            @Override
            public Integer apply(final String string) throws java.io.IOException {
                if ("fail".equals(string)) {
                    throw new java.io.IOException("boom");
                }
                return Integer.valueOf(string.length());
            }
        };
        try {
            final Integer length = converter.apply("abc");
            assertEquals(Integer.valueOf(3), length);
        } catch (final java.io.IOException e) {
            fail("Unexpected IOException");
        }
        assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                converter.apply("fail");
            }
        });
    }
}
