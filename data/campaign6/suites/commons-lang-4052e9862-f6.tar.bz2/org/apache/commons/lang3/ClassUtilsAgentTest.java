/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private interface Iface1 {
        // empty marker interface
    }

    private interface Iface2 extends Iface1 {
        // empty marker interface
    }

    private static class GrandParent implements Iface1 {
        // empty
    }

    private static class Parent extends GrandParent implements Iface2 {
        // empty
    }

    private static class Child extends Parent {
        // empty
    }

    public static class Outer {

        public static class PublicInner {
            // empty
        }

        @SuppressWarnings("unused")
        private static class PrivateInner {
            // empty
        }
    }

    //
    // comparator()
    //

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Boolean.class);
        list.add(Integer.class);
        Collections.sort(list, ClassUtils.comparator());
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    //
    // convertClassesToClassNames / convertClassNamesToClasses
    //

    @Test
    public void testConvertClassesToClassNames_nullInput() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClasses_nullInput() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("not.a.real.ClassName");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    //
    // getAbbreviatedName
    //

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    public void testGetAbbreviatedNameNonPositiveLengthHintThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -10);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameExamplesFromJavadoc() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    //
    // getAllInterfaces / getAllSuperclasses
    //

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfacesOrderAndDedup() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Child.class);
        assertEquals(2, interfaces.size());
        assertEquals(Iface2.class, interfaces.get(0));
        assertEquals(Iface1.class, interfaces.get(1));
    }

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclassesOrder() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Child.class);
        assertEquals(3, superclasses.size());
        assertEquals(Parent.class, superclasses.get(0));
        assertEquals(GrandParent.class, superclasses.get(1));
        assertEquals(Object.class, superclasses.get(2));
    }

    @Test
    public void testGetAllSuperclassesOfObjectIsEmpty() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    //
    // getCanonicalName
    //

    @Test
    public void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    public void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    //
    // getClass
    //

    @Test
    public void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("this.does.not.Exist");
            }
        });
    }

    @Test
    public void testGetClassPrimitive() throws ClassNotFoundException {
        assertSame(int.class, ClassUtils.getClass("int"));
        assertSame(void.class, ClassUtils.getClass("void"));
    }

    @Test
    public void testGetClassArraySyntaxes() throws ClassNotFoundException {
        assertSame(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertSame(int[].class, ClassUtils.getClass("[I"));
        assertSame(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassWhitespaceIsStripped() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClass(" java.lang . String "));
    }

    @Test
    public void testGetClassInnerClassWithDotNotation() throws ClassNotFoundException {
        assertSame(Outer.PublicInner.class, ClassUtils.getClass("org.apache.commons.lang3.ClassUtilsAgentTest.Outer.PublicInner"));
    }

    @Test
    public void testGetClassArrayDimensionOverLimitThrows() {
        final StringBuilder sb = new StringBuilder("int");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String tooManyDims = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                try {
                    ClassUtils.getClass(tooManyDims);
                } catch (final ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Test
    public void testGetClassNameTooLongThrows() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        sb.append("[]");
        final String tooLong = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                try {
                    ClassUtils.getClass(tooLong);
                } catch (final ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    //
    // getComponentType
    //

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        final Class<?> component = ClassUtils.getComponentType(String[].class);
        assertEquals(String.class, component);
    }

    //
    // getName / getSimpleName
    //

    @Test
    public void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
    }

    //
    // getPackageName / getPackageCanonicalName
    //

    @Test
    public void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObject() {
        assertEquals("DEFAULT", ClassUtils.getPackageName((Object) null, "DEFAULT"));
        assertEquals("java.lang", ClassUtils.getPackageName("hello", "DEFAULT"));
    }

    @Test
    public void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
        assertEquals("", ClassUtils.getPackageName("[I"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
    }

    //
    // getPrimitiveClass (package-private)
    //

    @Test
    public void testGetPrimitiveClass() {
        assertSame(Integer.TYPE, ClassUtils.getPrimitiveClass("int"));
        assertSame(Void.TYPE, ClassUtils.getPrimitiveClass("void"));
        assertNull(ClassUtils.getPrimitiveClass("not-a-primitive"));
        assertNull(ClassUtils.getPrimitiveClass(null));
    }

    //
    // getPublicMethod
    //

    @Test
    public void testGetPublicMethodOnPackagePrivateImplClass() throws Exception {
        final List<String> list = Collections.unmodifiableList(new ArrayList<String>());
        final Method method = ClassUtils.getPublicMethod(list.getClass(), "isEmpty");
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        final Object result = method.invoke(list);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    public void testGetPublicMethodNotFoundThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExist");
            }
        });
    }

    @Test
    public void testGetPublicMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "hashCode");
            }
        });
    }

    //
    // getShortClassName / getShortCanonicalName
    //

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("ClassUtilsAgentTest.Outer.PublicInner", ClassUtils.getShortClassName(Outer.PublicInner.class));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("DEFAULT", ClassUtils.getShortClassName((Object) null, "DEFAULT"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "DEFAULT"));
    }

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
    }

    @Test
    public void testGetShortCanonicalNameString() {
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("Entry", ClassUtils.getShortCanonicalName("java.util.Map.Entry"));
    }

    @Test
    public void testGetShortCanonicalNameInvalidInputThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getShortCanonicalName("[");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getShortCanonicalName("");
            }
        });
    }

    @Test
    public void testGetShortCanonicalNameObject() {
        assertEquals("DEFAULT", ClassUtils.getShortCanonicalName((Object) null, "DEFAULT"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hello", "DEFAULT"));
    }

    //
    // hierarchy
    //

    @Test
    public void testHierarchyExcludeInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class).iterator();
        assertEquals(Child.class, it.next());
        assertEquals(Parent.class, it.next());
        assertEquals(GrandParent.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class, ClassUtils.Interfaces.INCLUDE).iterator();
        assertEquals(Child.class, it.next());
        assertEquals(Parent.class, it.next());
        assertEquals(Iface2.class, it.next());
        assertEquals(Iface1.class, it.next());
        assertEquals(GrandParent.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class).iterator();
        it.next();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    @Test
    public void testHierarchyNullTypeProducesEmptyIterable() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(null).iterator();
        assertFalse(it.hasNext());
    }

    //
    // isAssignable
    //

    @Test
    public void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(double.class, int.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
    }

    @Test
    public void testIsAssignableNullHandling() {
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, (Class<?>) null));
    }

    @Test
    public void testIsAssignableSameType() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
        assertTrue(ClassUtils.isAssignable(Object.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignableArrayLengthMismatch() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { String.class }, new Class<?>[] { String.class, Integer.class }));
    }

    @Test
    public void testIsAssignableArrayMatching() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { Integer.class, String.class }, new Class<?>[] { int.class, Object.class }));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { Integer.class }, new Class<?>[] { int.class }, false));
    }

    //
    // isInnerClass / isPublic
    //

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Outer.PublicInner.class));
        assertTrue(ClassUtils.isInnerClass(Outer.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertTrue(ClassUtils.isPublic(Outer.class));
        assertFalse(ClassUtils.isPublic(Outer.PrivateInner.class));
    }

    @Test
    public void testIsPublicNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    //
    // isPrimitiveOrWrapper / isPrimitiveWrapper
    //

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    //
    // primitiveToWrapper / primitivesToWrappers
    //

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.primitivesToWrappers(empty));
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
    }

    //
    // wrapperToPrimitive / wrappersToPrimitives
    //

    @Test
    public void testWrapperToPrimitive() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        final Class<?>[] empty = new Class<?>[0];
        assertSame(empty, ClassUtils.wrappersToPrimitives(empty));
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
    }

    //
    // toClass
    //

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        final Class<?>[] result = ClassUtils.toClass();
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testToClass() {
        final Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, result);
    }

    //
    // constructor (deprecated, public on purpose)
    //

    @Test
    public void testPublicConstructor() {
        assertNotNull(new ClassUtils());
    }

    @Test
    public void testGetClassWithContextClassLoader() throws ClassNotFoundException {
        final Class<?> loaded = ClassUtils.getClass(Thread.currentThread().getContextClassLoader(), "java.lang.String");
        assertNotSame(null, loaded);
        assertEquals(String.class, loaded);
    }
}
