/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("  "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("a"));

        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("a"));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertNull(StringUtils.trimToNull(null));
        assertEquals("abc", StringUtils.trimToNull(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    void testEqualsAndEqualsIgnoreCase() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abcd"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "def"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertEquals(0, StringUtils.compare("a", "a"));

        assertEquals(0, StringUtils.compare(null, null, true));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("abcabc", "c"));
        assertEquals(5, StringUtils.indexOf("abcabc", "c", 3));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(5, StringUtils.lastIndexOf("abcabc", "c"));
        assertEquals(2, StringUtils.lastIndexOf("abcabc", "c", 4));

        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aBc", "B"));

        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOf("abc", "z"));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertFalse(StringUtils.contains(null, 'a'));
        assertTrue(StringUtils.contains("abc", 'b'));

        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));

        assertTrue(StringUtils.containsAny("abc", 'z', 'b'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'y'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));

        assertTrue(StringUtils.containsOnly("aabbcc", "abc"));
        assertFalse(StringUtils.containsOnly("aabbccd", "abc"));

        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace("a b"));
    }

    @Test
    void testStartsWithEndsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "def"));

        assertTrue(StringUtils.endsWith(null, null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));

        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "abc", "xyz"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("de", StringUtils.substring("abcde", -2));
        assertEquals("", StringUtils.substring("abc", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("abc", StringUtils.substring("abc", 0, 100));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "z"));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "z"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));

        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("abcb", StringUtils.substringBeforeLast("abcbc", "c"));

        assertEquals("b", StringUtils.substringBetween("yabcz", "a", "c"));
        assertNull(StringUtils.substringBetween("abc", "x"));
        assertEquals("b", StringUtils.substringBetween("abc", "a", "c"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 3));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("bc", StringUtils.mid("abc", 1, 3));
        assertEquals("ab", StringUtils.mid("abc", -1, 2));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyab", StringUtils.leftPad("ab", 4, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxy", StringUtils.rightPad("ab", 4, "xy"));

        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
    }

    @Test
    void testRepeatAndReverse() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("aaa", StringUtils.repeat('a', 3));
        assertEquals("", StringUtils.repeat('a', -1));
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
        assertEquals("", StringUtils.repeat("a", "-", 0));

        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));

        assertEquals("a-b-c", StringUtils.join(Arrays.asList("a", "b", "c"), "-"));
        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));

        assertArrayEquals(new String[] {"a", "", "b"}, StringUtils.splitPreserveAllTokens("a..b", '.'));

        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.splitByWholeSeparator("ab--cd", "--"));
        assertArrayEquals(new String[] {"ab", "", "cd"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab--cd", "-"));
    }

    @Test
    void testCaseConversion() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));

        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testIsAlphaNumericEtc() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2"));
        assertFalse(StringUtils.isAlpha("ab c"));

        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));

        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isWhitespace("   "));
        assertTrue(StringUtils.isWhitespace(""));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase(null));

        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase(""));

        assertTrue(StringUtils.isMixedCase("aB"));
        assertFalse(StringUtils.isMixedCase("ab"));
        assertFalse(StringUtils.isMixedCase(null));
    }

    @Test
    void testDefaultIfEmptyBlank() {
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));
        assertEquals("", StringUtils.defaultString(null));

        assertEquals("def", StringUtils.defaultIfEmpty(null, "def"));
        assertEquals("def", StringUtils.defaultIfEmpty("", "def"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "def"));

        assertEquals("def", StringUtils.defaultIfBlank(null, "def"));
        assertEquals("def", StringUtils.defaultIfBlank("  ", "def"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "def"));
    }

    @Test
    void testRemoveAndReplace() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("quim", StringUtils.remove("queeim", 'e'));
        assertEquals("abc", StringUtils.remove("abc", 'x'));

        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("qeim", StringUtils.remove("queeim", "ue"));

        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));

        assertNull(StringUtils.removeEnd(null, "a"));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));

        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("zzz", StringUtils.replace("aaa", "a", "z"));
        assertEquals("zaa", StringUtils.replace("aaa", "a", "z", 1));

        assertNull(StringUtils.replaceIgnoreCase(null, "a", "z"));
        assertEquals("zBz", StringUtils.replaceIgnoreCase("aBa", "a", "z"));

        assertNull(StringUtils.replaceOnce(null, "a", "z"));
        assertEquals("zaa", StringUtils.replaceOnce("aaa", "a", "z"));

        assertEquals("foo", StringUtils.replaceEach("hello", new String[] {"hello"}, new String[] {"foo"}));
    }

    @Test
    void testAbbreviateAndTruncate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertNull(StringUtils.truncate(null, 3));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });
    }

    @Test
    void testCountMatchesAndLength() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(3, StringUtils.countMatches("aaa", "a"));
        assertEquals(2, StringUtils.countMatches("abcabc", "abc"));

        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(3, StringUtils.countMatches("aaa", 'a'));

        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(5, StringUtils.getLevenshteinDistance("", "hippo"));
        assertEquals(1, StringUtils.getLevenshteinDistance("hippo", "hippoo"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(0, StringUtils.getLevenshteinDistance("same", "same"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });

        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog", 5));
        assertEquals(-1, StringUtils.getLevenshteinDistance("frog", "fog", 0));
    }

    @Test
    void testNormalizeSpaceAndDeleteWhitespace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));

        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));
    }

    @Test
    void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 10));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("", StringUtils.wrap("", '"'));

        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));

        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
    }

    @Test
    void testFirstNonBlankEmpty() {
        assertNull(StringUtils.firstNonBlank());
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "  ", "abc"));
        assertNull(StringUtils.firstNonBlank((String) null, (String) null));

        assertNull(StringUtils.firstNonEmpty());
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abc"));
    }

    @Test
    void testDifference() {
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("ty", StringUtils.difference("abc", "abty"));
    }

    @Test
    void testToCodePointsAndValueOf() {
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertNull(StringUtils.toCodePoints(null));

        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
    }

    @Test
    void testConstantsAreStable() {
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("", StringUtils.EMPTY);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
        assertSame(StringUtils.EMPTY, StringUtils.EMPTY);
    }
}
