/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    private interface ThrowingAction {
        void run() throws Exception;
    }

    private static void expectThrows(final Class<? extends Throwable> expected, final ThrowingAction action) {
        try {
            action.run();
        } catch (final Throwable t) {
            if (expected.isInstance(t)) {
                return;
            }
            fail("Expected " + expected.getName() + " but got " + t.getClass().getName());
        }
        fail("Expected " + expected.getName() + " but nothing was thrown");
    }

    // ---- constants ----

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    @Test
    void testConstructorExists() {
        assertTrue(new NumberUtils() instanceof NumberUtils);
    }

    // ---- compare ----

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ---- createBigDecimal ----

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createBigDecimal("");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createBigDecimal("   ");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ---- createBigInteger ----

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("12345"), NumberUtils.createBigInteger("12345"));
        assertEquals(new BigInteger("-12345"), NumberUtils.createBigInteger("-12345"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createBigInteger("");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ---- createDouble / createFloat ----

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.23d), NumberUtils.createDouble("1.23"));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.23f), NumberUtils.createFloat("1.23"));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    // ---- createInteger / createLong ----

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12345), NumberUtils.createInteger("12345"));
        assertEquals(Integer.valueOf(16), NumberUtils.createInteger("0x10"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12345L), NumberUtils.createLong("12345"));
        assertEquals(Long.valueOf(16L), NumberUtils.createLong("0x10"));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createLong("not a number");
            }
        });
    }

    // ---- createNumber ----

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    void testCreateNumberIntegral() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertEquals(Integer.valueOf(-12345), NumberUtils.createNumber("-12345"));
        final Number big = NumberUtils.createNumber("123456789012345678901234567890");
        assertEquals(new BigInteger("123456789012345678901234567890"), big);
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createNumber(String.valueOf(Long.MAX_VALUE)));
    }

    @Test
    void testCreateNumberHex() {
        assertEquals(Integer.valueOf(16), NumberUtils.createNumber("0x10"));
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), NumberUtils.createNumber("0x7fffffff"));
        assertEquals(Long.valueOf(2147483648L), NumberUtils.createNumber("0x80000000"));
        assertEquals(Long.valueOf(4294967295L), NumberUtils.createNumber("0xFFFFFFFFL"));
        assertEquals(new BigInteger("18446744073709551615"), NumberUtils.createNumber("0xFFFFFFFFFFFFFFFFL"));
        assertEquals(Integer.valueOf(-16), NumberUtils.createNumber("-0x10"));
        assertEquals(Integer.valueOf(26), NumberUtils.createNumber("#1A"));
    }

    @Test
    void testCreateNumberOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createNumber("010"));
        assertEquals(Integer.valueOf(0), NumberUtils.createNumber("00"));
        // documented: "09" is not a valid octal number
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("09");
            }
        });
    }

    @Test
    void testCreateNumberTypeQualifiers() {
        assertEquals(Long.valueOf(100L), NumberUtils.createNumber("100L"));
        assertEquals(Long.valueOf(100L), NumberUtils.createNumber("100l"));
        assertEquals(Float.valueOf(3.5f), NumberUtils.createNumber("3.5F"));
        assertEquals(Double.valueOf(3.5d), NumberUtils.createNumber("3.5D"));
        final Number bigLong = NumberUtils.createNumber("123456789012345678901234567890L");
        assertEquals(new BigInteger("123456789012345678901234567890"), bigLong);
    }

    @Test
    void testCreateNumberDecimalAndExponent() {
        assertEquals(Float.valueOf(3.0f), NumberUtils.createNumber("3.0"));
        assertEquals(Float.valueOf(0.5f), NumberUtils.createNumber(".5"));
        assertEquals(Float.valueOf(1.2e-5f), NumberUtils.createNumber("1.2e-5"));
        // too large for Float/Double, falls back to BigDecimal
        final Number huge = NumberUtils.createNumber("1e400");
        assertTrue(huge instanceof BigDecimal);
        assertEquals(new BigDecimal("1E+400"), huge);
    }

    @Test
    void testCreateNumberInvalid() {
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("--1");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("1.1.1");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("NaN");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("abcL");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                // a decimal value cannot have the 'L' (long) qualifier
                NumberUtils.createNumber("1.5L");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber(" 1");
            }
        });
        expectThrows(NumberFormatException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.createNumber("1 ");
            }
        });
    }

    // ---- isCreatable / isNumber ----

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("--1"));
        assertFalse(NumberUtils.isCreatable("1.1.1"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12345"));
        assertTrue(NumberUtils.isCreatable("1.5"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("010"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsNumberMatchesIsCreatable() {
        final String[] values = { null, "", "   ", "09", "--1", "abc", "12345", "-12345", "1.5", "0x1A", "010" };
        for (final String value : values) {
            assertEquals(NumberUtils.isCreatable(value), NumberUtils.isNumber(value), "mismatch for " + value);
        }
    }

    // ---- isDigits ----

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits("-1"));
        assertFalse(NumberUtils.isDigits("1.5"));
        assertFalse(NumberUtils.isDigits("abc"));
        assertTrue(NumberUtils.isDigits("12345"));
        assertTrue(NumberUtils.isDigits("0"));
    }

    // ---- isParsable ----

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("1.2.3"));
        assertFalse(NumberUtils.isParsable("abc"));
        assertTrue(NumberUtils.isParsable("1"));
        assertTrue(NumberUtils.isParsable("-1"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("07"));
    }

    // ---- max/min arrays ----

    @Test
    void testMaxMinByteArray() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 3, (byte) 2));
        assertEquals((byte) 5, NumberUtils.max(new byte[] { 5 }));
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max((byte[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max(new byte[0]);
            }
        });
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.min((byte[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMaxMinIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3, -2));
        assertEquals(-2, NumberUtils.min(1, 5, 3, -2));
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(1, NumberUtils.min(1, 5, 3));
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max((int[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMaxMinLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L, -2L));
        assertEquals(-2L, NumberUtils.min(1L, 5L, 3L, -2L));
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max((long[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    void testMaxMinShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max((short[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    void testMaxMinDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0001);
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0001);
        assertEquals(5.5d, NumberUtils.max(new double[] { 1.1d, 5.5d, 3.3d }), 0.0001);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max((double[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    void testMaxMinFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0001f);
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0001f);
        assertEquals(5.5f, NumberUtils.max(new float[] { 1.1f, 5.5f, 3.3f }), 0.0001f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        expectThrows(NullPointerException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.max((float[]) null);
            }
        });
        expectThrows(IllegalArgumentException.class, new ThrowingAction() {
            @Override
            public void run() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    // ---- toXxx(String) conversions ----

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
        assertEquals((byte) 9, NumberUtils.toByte(null, (byte) 9));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 9, NumberUtils.toShort("not a short", (short) 9));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(9, NumberUtils.toInt("abc", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(9L, NumberUtils.toLong("abc", 9L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
        assertEquals(9.9f, NumberUtils.toFloat("abc", 9.9f));
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
        assertEquals(9.9d, NumberUtils.toDouble("abc", 9.9d));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
    }

    // ---- toScaledBigDecimal ----

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("2.34"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.345")));
        assertEquals(new BigDecimal("2.36"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.355")));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.234"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("2.34"), NumberUtils.toScaledBigDecimal(Double.valueOf(2.345d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.5f)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("2.34"), NumberUtils.toScaledBigDecimal("2.345"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP));
    }
}
