/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface MarkerAnnotation {
        // marker only
    }

    public interface Greeter {
        String greet(String name);
    }

    public static class Base {
        @MarkerAnnotation
        public String annotated() {
            return "base";
        }

        public String overridden() {
            return "base-overridden";
        }

        public String add(final int a, final int b) {
            return "int:" + (a + b);
        }

        public String add(final Integer a, final Integer b) {
            return "Integer:" + (a + b);
        }

        public String varArgs(final String first, final int... numbers) {
            final StringBuilder sb = new StringBuilder(first);
            for (final int n : numbers) {
                sb.append(',').append(n);
            }
            return sb.toString();
        }

        protected String protectedMethod() {
            return "protected";
        }

        private String privateMethod(final String s) {
            return "private:" + s;
        }

        public static String staticMethod(final String s) {
            return "static:" + s;
        }

        private static String privateStaticMethod() {
            return "privateStatic";
        }
    }

    public static class Child extends Base implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hello, " + name;
        }

        @Override
        public String overridden() {
            return "child-overridden";
        }

        public int noSuchArgsMethod() {
            return 42;
        }
    }

    public static class Thrower {
        public void boom() {
            throw new IllegalStateException("boom");
        }
    }

    // --- getAccessibleMethod ---

    @Test
    public void testGetAccessibleMethod_publicMethod() throws Exception {
        final Method m = Child.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(m);
        assertNotNull(accessible);
        assertEquals("greet", accessible.getName());
    }

    @Test
    public void testGetAccessibleMethod_nullMethod() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethod_byNameAndParams() {
        final Method m = MethodUtils.getAccessibleMethod(Child.class, "greet", String.class);
        assertNotNull(m);
        assertEquals("greet", m.getName());
    }

    @Test
    public void testGetAccessibleMethod_byNameAndParams_notFound() {
        assertNull(MethodUtils.getAccessibleMethod(Child.class, "doesNotExist", String.class));
    }

    @Test
    public void testGetAccessibleMethod_nonPublicDeclaredMethodReturnsNull() throws Exception {
        final Method m = Base.class.getDeclaredMethod("privateMethod", String.class);
        assertNull(MethodUtils.getAccessibleMethod(Base.class, m));
    }

    // --- getAnnotation ---

    @Test
    public void testGetAnnotation_directlyPresent() throws Exception {
        final Method m = Base.class.getMethod("annotated");
        final MarkerAnnotation ann = MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false);
        assertNotNull(ann);
    }

    @Test
    public void testGetAnnotation_notPresentWithoutSearchSupers() throws Exception {
        final Method m = Child.class.getMethod("overridden");
        final MarkerAnnotation ann = MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false);
        assertNull(ann);
    }

    @Test
    public void testGetAnnotation_nullMethodThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, MarkerAnnotation.class, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotation_nullAnnotationClassThrows() throws Exception {
        final Method m = Base.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(m, null, false, false);
            }
        });
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    public void testGetMatchingAccessibleMethod_exactPrimitive() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Base.class, "add", int.class, int.class);
        assertNotNull(m);
        assertArrayEquals(new Class<?>[] {int.class, int.class}, m.getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleMethod_boxedMatchesWrapperOverload() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Base.class, "add", Integer.class, Integer.class);
        assertNotNull(m);
        assertArrayEquals(new Class<?>[] {Integer.class, Integer.class}, m.getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleMethod_notFound() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Base.class, "noSuchMethod", String.class));
    }

    // --- getMatchingMethod ---

    @Test
    public void testGetMatchingMethod_exactMatch() {
        final Method m = MethodUtils.getMatchingMethod(Base.class, "add", int.class, int.class);
        assertNotNull(m);
    }

    @Test
    public void testGetMatchingMethod_nullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "add", int.class, int.class);
            }
        });
    }

    @Test
    public void testGetMatchingMethod_emptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Base.class, "", int.class, int.class);
            }
        });
    }

    @Test
    public void testGetMatchingMethod_privateMethodFound() {
        final Method m = MethodUtils.getMatchingMethod(Base.class, "privateMethod", String.class);
        assertNotNull(m);
        assertEquals("privateMethod", m.getName());
    }

    // --- getMethodObject ---

    @Test
    public void testGetMethodObject_found() {
        final Method m = MethodUtils.getMethodObject(Child.class, "greet", String.class);
        assertNotNull(m);
    }

    @Test
    public void testGetMethodObject_nullCls() {
        assertNull(MethodUtils.getMethodObject(null, "greet", String.class));
    }

    @Test
    public void testGetMethodObject_nullName() {
        assertNull(MethodUtils.getMethodObject(Child.class, null, String.class));
    }

    @Test
    public void testGetMethodObject_notFound() {
        assertNull(MethodUtils.getMethodObject(Child.class, "nope"));
    }

    // --- getMethodsListWithAnnotation / getMethodsWithAnnotation ---

    @Test
    public void testGetMethodsListWithAnnotation_found() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Base.class, MarkerAnnotation.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsListWithAnnotation_noneFound() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Child.class, Deprecated.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotation_nullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, MarkerAnnotation.class);
            }
        });
    }

    @Test
    public void testGetMethodsWithAnnotation_returnsArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Base.class, MarkerAnnotation.class);
        assertEquals(1, methods.length);
    }

    // --- getOverrideHierarchy ---

    @Test
    public void testGetOverrideHierarchy() throws Exception {
        final Method childMethod = Child.class.getMethod("overridden");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(childMethod, Interfaces.EXCLUDE);
        assertTrue(hierarchy.contains(childMethod));
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchy_nullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE);
            }
        });
    }

    // --- invokeExactMethod ---

    @Test
    public void testInvokeExactMethod_noArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Child(), "noSuchArgsMethod");
        assertEquals(42, result);
    }

    @Test
    public void testInvokeExactMethod_withArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new Child(), "greet", "World");
        assertEquals("Hello, World", result);
    }

    @Test
    public void testInvokeExactMethod_noSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new Child(), "greet", 123);
            }
        });
    }

    @Test
    public void testInvokeExactMethod_invocationTargetException() {
        assertThrows(InvocationTargetException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(new Thrower(), "boom");
            }
        });
    }

    @Test
    public void testInvokeExactMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(null, "greet", "World");
            }
        });
    }

    // --- invokeExactStaticMethod ---

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Base.class, "staticMethod", "x");
        assertEquals("static:x", result);
    }

    @Test
    public void testInvokeExactStaticMethod_notStaticThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(Child.class, "greet", "World");
            }
        });
    }

    // --- invokeMethod ---

    @Test
    public void testInvokeMethod_matchingPrimitiveOverload() throws Exception {
        // Varargs args are boxed to Integer; the exact-match Integer overload wins.
        final Object result = MethodUtils.invokeMethod(new Base(), "add", 1, 2);
        assertEquals("Integer:3", result);
    }

    @Test
    public void testInvokeMethod_matchingPrimitiveOverloadViaParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Base(), "add", new Object[] {1, 2}, new Class<?>[] {int.class, int.class});
        assertEquals("int:3", result);
    }

    @Test
    public void testInvokeMethod_varArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Base(), "varArgs", "start", 1, 2, 3);
        assertEquals("start,1,2,3", result);
    }

    @Test
    public void testInvokeMethod_varArgsEmpty() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Base(), "varArgs", "only");
        assertEquals("only", result);
    }

    @Test
    public void testInvokeMethod_forceAccessProtected() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Base(), true, "protectedMethod");
        assertEquals("protected", result);
    }

    @Test
    public void testInvokeMethod_forceAccessPrivate() throws Exception {
        final Object result = MethodUtils.invokeMethod(new Base(), true, "privateMethod", "abc");
        assertEquals("private:abc", result);
    }

    @Test
    public void testInvokeMethod_withoutForceAccessPrivateThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new Base(), false, "privateMethod", "abc");
            }
        });
    }

    @Test
    public void testInvokeMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "greet", "World");
            }
        });
    }

    // --- invokeStaticMethod ---

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Base.class, "staticMethod", "y");
        assertEquals("static:y", result);
    }

    @Test
    public void testInvokeStaticMethod_privateStaticNotAccessibleThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Base.class, "privateStaticMethod");
            }
        });
    }

    @Test
    public void testInvokeStaticMethod_noSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Base.class, "nope");
            }
        });
    }

    // --- Constructor (deprecated, but public) ---

    @Test
    public void testConstructor() {
        assertNotNull(new MethodUtils());
    }
}
