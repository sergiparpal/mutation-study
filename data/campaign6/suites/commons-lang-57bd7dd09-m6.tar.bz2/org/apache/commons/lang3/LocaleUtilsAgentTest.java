/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    private static void assertInvalidLocale(final String str) {
        try {
            LocaleUtils.toLocale(str);
            fail("Expected IllegalArgumentException for input: " + str);
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    private static void assertUnmodifiable(final List<Locale> list) {
        try {
            list.add(Locale.FRANCE);
            fail("Expected list to be unmodifiable");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    void testConstructor() {
        assertNotNull(new LocaleUtils());
    }

    @Test
    void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        // Calling again must return the same cached instance.
        assertSame(list, LocaleUtils.availableLocaleList());
        assertUnmodifiable(list);
        // Verify the list is sorted by String representation.
        final List<String> asStrings = new ArrayList<String>();
        for (final Locale locale : list) {
            asStrings.add(locale.toString());
        }
        final List<String> sorted = new ArrayList<String>(asStrings);
        sorted.sort(null);
        assertEquals(sorted, asStrings);
    }

    @Test
    void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
        assertSame(set, LocaleUtils.availableLocaleSet());
        try {
            set.add(Locale.FRANCE);
            fail("Expected set to be unmodifiable");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
        assertEquals(new LinkedHashSet<Locale>(LocaleUtils.availableLocaleList()).size(), set.size());
    }

    @Test
    void testCountriesByLanguage_null() {
        assertTrue(LocaleUtils.countriesByLanguage(null).isEmpty());
    }

    @Test
    void testCountriesByLanguage_empty() {
        assertTrue(LocaleUtils.countriesByLanguage("").isEmpty());
    }

    @Test
    void testCountriesByLanguage_valid() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        for (final Locale locale : list) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
        // Result must be cached: same instance on second call.
        assertSame(list, LocaleUtils.countriesByLanguage("en"));
        assertUnmodifiable(list);
    }

    @Test
    void testCountriesByLanguage_invalidFormat() {
        // Too short to be an ISO 639 code.
        assertTrue(LocaleUtils.countriesByLanguage("e").isEmpty());
        // Uppercase is not a valid ISO 639 code.
        assertTrue(LocaleUtils.countriesByLanguage("EN").isEmpty());
        // Too long to be an ISO 639 code.
        assertTrue(LocaleUtils.countriesByLanguage("english").isEmpty());
    }

    @Test
    void testCountriesByLanguage_validFormatNoMatch() {
        // Well-formed 2 and 3 letter codes that are not real languages still yield an empty, non-null list.
        assertTrue(LocaleUtils.countriesByLanguage("zz").isEmpty());
        assertTrue(LocaleUtils.countriesByLanguage("aaa").isEmpty());
    }

    @Test
    void testLanguagesByCountry_null() {
        assertTrue(LocaleUtils.languagesByCountry(null).isEmpty());
    }

    @Test
    void testLanguagesByCountry_valid() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertFalse(list.isEmpty());
        assertTrue(list.contains(new Locale("en", "US")));
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
        assertSame(list, LocaleUtils.languagesByCountry("US"));
        assertUnmodifiable(list);
    }

    @Test
    void testLanguagesByCountry_numericAreaCode() {
        final List<Locale> list = LocaleUtils.languagesByCountry("001");
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("001", locale.getCountry());
        }
    }

    @Test
    void testLanguagesByCountry_invalidFormat() {
        // Lowercase is not a valid ISO 3166 country code.
        assertTrue(LocaleUtils.languagesByCountry("us").isEmpty());
        // Single digit is neither an alpha-2 country code nor a numeric-3 area code.
        assertTrue(LocaleUtils.languagesByCountry("1").isEmpty());
    }

    @Test
    void testLanguagesByCountry_emptyIsEmptyCountry() {
        // An empty country code is not rejected by validation; it searches for locales with an empty country.
        final List<Locale> list = LocaleUtils.languagesByCountry("");
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertTrue(locale.getCountry().isEmpty());
        }
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "YY")));
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(Locale.ROOT));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("en")));
    }

    @Test
    void testLocaleLookupList_null() {
        assertTrue(LocaleUtils.localeLookupList(null).isEmpty());
    }

    @Test
    void testLocaleLookupList_languageOnly() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("en"));
        assertEquals(1, list.size());
        assertEquals(new Locale("en"), list.get(0));
    }

    @Test
    void testLocaleLookupList_languageAndCountry() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA"));
        assertEquals(2, list.size());
        assertEquals(new Locale("fr", "CA"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
    }

    @Test
    void testLocaleLookupList_languageCountryVariant() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    void testLocaleLookupList_noCountryWithVariant() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "", "xxx"), new Locale("en"));
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "", "xxx"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
        assertEquals(new Locale("en"), list.get(2));
    }

    @Test
    void testLocaleLookupList_isUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.US);
        assertUnmodifiable(list);
    }

    @Test
    void testToLocale_LocaleArg() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
        assertSame(Locale.US, LocaleUtils.toLocale(Locale.US));
    }

    @Test
    void testToLocale_StringArg_null() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocale_StringArg_empty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    void testToLocale_StringArg_language() {
        assertEquals(new Locale("en"), LocaleUtils.toLocale("en"));
    }

    @Test
    void testToLocale_StringArg_languageAndCountry() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    void testToLocale_StringArg_numericAreaCode() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    void testToLocale_StringArg_languageCountryVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    void testToLocale_StringArg_countryOnly() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("GB"));
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("_GB"));
    }

    @Test
    void testToLocale_StringArg_countryAndVariant() {
        assertEquals(new Locale("", "GB", "P"), LocaleUtils.toLocale("_GB_P"));
    }

    @Test
    void testToLocale_StringArg_threeLetterLanguage() {
        assertEquals(new Locale("ace"), LocaleUtils.toLocale("ace"));
        assertEquals(new Locale("ace", "ID"), LocaleUtils.toLocale("ace_ID"));
    }

    @Test
    void testToLocale_StringArg_specialCases() {
        final Locale th = LocaleUtils.toLocale("th_TH_TH_#u-nu-thai");
        assertEquals("th", th.getLanguage());
        assertEquals("TH", th.getCountry());
        final Locale ja = LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese");
        assertEquals("ja", ja.getLanguage());
        assertEquals("JP", ja.getCountry());
    }

    @Test
    void testToLocale_StringArg_emptyCountryWithVariant() {
        // Double separator means an empty country segment with a non-empty variant, which is accepted.
        final Locale locale = LocaleUtils.toLocale("en__GB");
        assertEquals("en", locale.getLanguage());
        assertTrue(locale.getCountry().isEmpty());
        assertEquals("GB", locale.getVariant());
    }

    @Test
    void testToLocale_StringArg_tooShort() {
        assertInvalidLocale("a");
    }

    @Test
    void testToLocale_StringArg_invalidLowercaseVariantMarker() {
        assertInvalidLocale("en_g");
    }

    @Test
    void testToLocale_StringArg_trailingUnderscore() {
        assertInvalidLocale("en_GB_");
    }

    @Test
    void testToLocale_StringArg_noSeparator() {
        assertInvalidLocale("enGB");
        assertInvalidLocale("abcd");
    }

    @Test
    void testToLocale_StringArg_uppercaseLanguage() {
        assertInvalidLocale("EN_GB");
    }

    @Test
    void testToLocale_StringArg_lowercaseCountry() {
        assertInvalidLocale("en_gb");
    }

    @Test
    void testToLocale_StringArg_shortUnderscoreForm() {
        assertInvalidLocale("_G");
        assertInvalidLocale("_1B");
    }
}
