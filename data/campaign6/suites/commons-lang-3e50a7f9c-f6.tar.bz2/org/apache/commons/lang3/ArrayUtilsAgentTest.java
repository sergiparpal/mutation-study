/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
public class ArrayUtilsAgentTest {

    private static class Fixture {
        private final int value;

        Fixture(final int value) {
            this.value = value;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof Fixture && ((Fixture) obj).value == value;
        }

        @Override
        public int hashCode() {
            return value;
        }
    }

    // ---------------------------------------------------------------- add

    @Test
    public void testAddBoolean() {
        final boolean[] result = ArrayUtils.add(new boolean[] {true}, false);
        assertArrayEquals(new boolean[] {true, false}, result);
        assertArrayEquals(new boolean[] {true}, ArrayUtils.add((boolean[]) null, true));
    }

    @Test
    public void testAddIntAtIndex() {
        final int[] result = ArrayUtils.add(new int[] {1, 2, 3}, 1, 99);
        assertArrayEquals(new int[] {1, 99, 2, 3}, result);
    }

    @Test
    public void testAddIntAtIndexOutOfBounds() {
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(new int[] {1, 2, 3}, 4, 99));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(new int[] {1, 2, 3}, -1, 99));
    }

    @Test
    public void testAddObjectGeneric() {
        final String[] strings = {"a", "b"};
        final String[] result = ArrayUtils.add(strings, "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
        assertNotSame(strings, result);
    }

    @Test
    public void testAddObjectNullArrayNullElementThrows() {
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.add((Object[]) null, null));
    }

    // ------------------------------------------------------------- addAll

    @Test
    public void testAddAllIntArrays() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.addAll(new int[] {1, 2}, 3, 4));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll((int[]) null, 1, 2));
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
    }

    @Test
    public void testAddAllObjectArraysTypeMismatch() {
        final Number[] numbers = {Integer.valueOf(1)};
        final Number[] result = ArrayUtils.addAll(numbers, Double.valueOf(2.0));
        assertEquals(2, result.length);
    }

    // ----------------------------------------------------------- addFirst

    @Test
    public void testAddFirstInt() {
        assertArrayEquals(new int[] {9, 1, 2}, ArrayUtils.addFirst(new int[] {1, 2}, 9));
        assertArrayEquals(new int[] {9}, ArrayUtils.addFirst((int[]) null, 9));
    }

    // ------------------------------------------------------------- clone

    @Test
    public void testCloneNull() {
        assertNull(ArrayUtils.clone((Object[]) null));
        assertNull(ArrayUtils.clone((int[]) null));
    }

    @Test
    public void testCloneCopiesArray() {
        final int[] original = {1, 2, 3};
        final int[] copy = ArrayUtils.clone(original);
        assertArrayEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    public void testCloneEmpty() {
        final Object[] empty = {};
        final Object[] copy = ArrayUtils.clone(empty);
        assertNotNull(copy);
        assertEquals(0, copy.length);
    }

    // ------------------------------------------------------------- concat

    @Test
    public void testConcatIntArrays() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.concat(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0]));
        assertArrayEquals(new int[] {1}, ArrayUtils.concat(new int[] {1}, null));
    }

    // ----------------------------------------------------------- contains

    @Test
    public void testContainsObject() {
        final Object[] array = {"a", "b", null};
        assertTrue(ArrayUtils.contains(array, "a"));
        assertTrue(ArrayUtils.contains(array, null));
        assertFalse(ArrayUtils.contains(array, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    public void testContainsDoubleWithTolerance() {
        assertTrue(ArrayUtils.contains(new double[] {1.0, 2.0}, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(new double[] {1.0, 2.0}, 2.5, 0.1));
    }

    @Test
    public void testContainsAnyObject() {
        assertTrue(ArrayUtils.containsAny(new Object[] {"a", "b"}, "x", "b"));
        assertFalse(ArrayUtils.containsAny(new Object[] {"a", "b"}, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "x"));
    }

    // --------------------------------------------------------------- get

    @Test
    public void testGetWithDefault() {
        final String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0));
        assertEquals("def", ArrayUtils.get(array, 5, "def"));
        assertEquals("def", ArrayUtils.get((String[]) null, 0, "def"));
    }

    @Test
    public void testGetOutOfBoundsReturnsNull() {
        assertNull(ArrayUtils.get(new String[] {"a"}, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
    }

    // ---------------------------------------------- getComponentType/Length

    @Test
    public void testGetComponentType() {
        final String[] array = {"a"};
        assertEquals(String.class, ArrayUtils.getComponentType(array));
    }

    @Test
    public void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(2, ArrayUtils.getLength(new Object[] {"a", "b"}));
    }

    // ------------------------------------------------------------ hashCode

    @Test
    public void testHashCodeNullIsConsistent() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
    }

    @Test
    public void testHashCodeConsistentForEqualArrays() {
        final int[] a = {1, 2, 3};
        final int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    // ---------------------------------------------------------- indexesOf

    @Test
    public void testIndexesOfInt() {
        final BitSet set = ArrayUtils.indexesOf(new int[] {1, 2, 1, 3, 1}, 1);
        assertTrue(set.get(0));
        assertTrue(set.get(2));
        assertTrue(set.get(4));
        assertFalse(set.get(1));
        assertFalse(set.get(3));
    }

    @Test
    public void testIndexesOfNullArrayIsEmpty() {
        final BitSet set = ArrayUtils.indexesOf((int[]) null, 1);
        assertTrue(set.isEmpty());
    }

    // ----------------------------------------------------------- indexOf

    @Test
    public void testIndexOfObject() {
        final Object[] array = {"a", "b", "c"};
        assertEquals(1, ArrayUtils.indexOf(array, "b"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, "z"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((Object[]) null, "a"));
    }

    @Test
    public void testIndexOfWithStartIndexNegative() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
    }

    @Test
    public void testIndexOfWithStartIndexBeyondLength() {
        final int[] array = {1, 2, 3};
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 1, 10));
    }

    @Test
    public void testLastIndexOfObject() {
        final Object[] array = {"a", "b", "a"};
        assertEquals(2, ArrayUtils.lastIndexOf(array, "a"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((Object[]) null, "a"));
    }

    @Test
    public void testLastIndexOfStartIndexBeyondLengthClampsToEnd() {
        final int[] array = {1, 2, 3};
        assertEquals(2, ArrayUtils.lastIndexOf(array, 3, 50));
    }

    @Test
    public void testLastIndexOfNegativeStartIndex() {
        final int[] array = {1, 2, 3};
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 1, -1));
    }

    // ------------------------------------------------------------- insert

    @Test
    public void testInsertInt() {
        assertArrayEquals(new int[] {1, 4, 5, 2, 3}, ArrayUtils.insert(1, new int[] {1, 2, 3}, 4, 5));
    }

    @Test
    public void testInsertOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(5, new int[] {1, 2, 3}, 9));
    }

    @Test
    public void testInsertIntoNullArrayReturnsNull() {
        assertNull(ArrayUtils.insert(0, (int[]) null, 9));
    }

    // ----------------------------------------------------- isArrayIndexValid

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // -------------------------------------------------------- isEmpty/isNot

    @Test
    public void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    // ------------------------------------------------------------ isEquals

    @SuppressWarnings("deprecation")
    @Test
    public void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(new int[] {1}, null));
    }

    // -------------------------------------------------------- isSameLength

    @Test
    public void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, null));
    }

    // ---------------------------------------------------------- isSameType

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
    }

    @Test
    public void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(null, new int[0]));
    }

    // ----------------------------------------------------------- isSorted

    @Test
    public void testIsSortedInt() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
    }

    // ----------------------------------------------------------- newInstance

    @Test
    public void testNewInstance() {
        final Integer[] array = ArrayUtils.newInstance(Integer.class, 3);
        assertEquals(3, array.length);
        assertNull(array[0]);
    }

    // --------------------------------------------------------------- nullTo

    @Test
    public void testNullTo() {
        final String[] defaultArray = {"d"};
        assertSame(defaultArray, ArrayUtils.nullTo(null, defaultArray));
        final String[] array = {"a"};
        assertSame(array, ArrayUtils.nullTo(array, defaultArray));
    }

    // ----------------------------------------------------------- nullToEmpty

    @Test
    public void testNullToEmptyInt() {
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = {1, 2};
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    public void testNullToEmptyObjectArray() {
        assertArrayEquals(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
    }

    // -------------------------------------------------------------- remove

    @Test
    public void testRemoveInt() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.remove(new int[] {1, 2, 3}, 0));
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.remove(new int[] {1, 2, 3}, 1));
    }

    @Test
    public void testRemoveOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(new int[] {1, 2, 3}, 3));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(new int[] {1, 2, 3}, -1));
    }

    @Test
    public void testRemoveNullArrayThrows() {
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove((int[]) null, 0));
    }

    // ------------------------------------------------------------ removeAll

    @Test
    public void testRemoveAllInt() {
        assertArrayEquals(new int[] {2}, ArrayUtils.removeAll(new int[] {1, 2, 3}, 0, 2));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.removeAll(new int[] {1, 2, 3}));
    }

    @Test
    public void testRemoveAllIndexOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.removeAll(new int[] {1, 2, 3}, 5));
    }

    // ----------------------------------------------- removeAllOccurrences(s)

    @Test
    public void testRemoveAllOccurrencesInt() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1));
    }

    @Test
    public void testRemoveAllOccurencesMatchesRemoveAllOccurrences() {
        final int[] array = {1, 2, 1, 3, 1};
        assertArrayEquals(ArrayUtils.removeAllOccurrences(array, 1), ArrayUtils.removeAllOccurences(array, 1));
    }

    // ------------------------------------------------------------- removeEl

    @Test
    public void testRemoveElement() {
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.removeElement(new int[] {1, 2, 3}, 2));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.removeElement(new int[] {1, 2, 3}, 9));
    }

    @Test
    public void testRemoveElements() {
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.removeElements(new int[] {1, 2, 3}, 2));
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.removeElements(new int[] {1, 2, 3}));
    }

    @Test
    public void testRemoveElementsOnlyRemovesOnePerOccurrence() {
        assertArrayEquals(new int[] {2}, ArrayUtils.removeElements(new int[] {1, 2, 1}, 1, 1));
    }

    // -------------------------------------------------------------- reverse

    @Test
    public void testReverseFullArray() {
        final int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testReversePartialArray() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseNullArrayDoesNotThrow() {
        ArrayUtils.reverse((int[]) null);
    }

    // ---------------------------------------------------------------- shift

    @Test
    public void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] {4, 5, 1, 2, 3}, array);
    }

    @Test
    public void testShiftNegativeOffset() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, -2);
        assertArrayEquals(new int[] {3, 4, 5, 1, 2}, array);
    }

    @Test
    public void testShiftOnNullArrayDoesNotThrow() {
        ArrayUtils.shift((int[]) null, 2);
    }

    // ------------------------------------------------------------ startsWith

    @Test
    public void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[0]));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, new byte[] {1, 2}));
    }

    // ------------------------------------------------------------- subarray

    @Test
    public void testSubarray() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(new int[] {1, 2, 3, 4}, 1, 3));
        assertArrayEquals(new int[0], ArrayUtils.subarray(new int[] {1, 2, 3}, 2, 2));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSubarrayClampsOutOfRangeIndices() {
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.subarray(new int[] {1, 2, 3}, -5, 100));
    }

    @Test
    public void testSubarrayStartGreaterThanEndYieldsEmpty() {
        assertArrayEquals(new int[0], ArrayUtils.subarray(new int[] {1, 2, 3}, 2, 1));
    }

    // ---------------------------------------------------------------- swap

    @Test
    public void testSwap() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testSwapRangeWithLength() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 2, 2);
        assertArrayEquals(new int[] {3, 4, 1, 2}, array);
    }

    @Test
    public void testSwapOnNullArrayDoesNotThrow() {
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    public void testSwapOutOfBoundsIsNoOp() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, array);
    }

    // -------------------------------------------------------------- toArray

    @Test
    public void testToArray() {
        final String[] result = ArrayUtils.toArray("a", "b");
        assertArrayEquals(new String[] {"a", "b"}, result);
    }

    // --------------------------------------------------------------- toMap

    @Test
    public void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    public void testToMapInvalidEntryThrows() {
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] {new Object[] {"onlyone"}}));
    }

    // --------------------------------------------------------------- toObject

    @Test
    public void testToObjectInt() {
        final Integer[] result = ArrayUtils.toObject(new int[] {1, 2, 3});
        assertArrayEquals(new Integer[] {1, 2, 3}, result);
    }

    @Test
    public void testToObjectBoolean() {
        final Boolean[] result = ArrayUtils.toObject(new boolean[] {true, false});
        assertArrayEquals(new Boolean[] {Boolean.TRUE, Boolean.FALSE}, result);
    }

    // -------------------------------------------------------------- toPrim

    @Test
    public void testToPrimitiveInt() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] {1, 2, 3});
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testToPrimitiveIntNullElementThrows() {
        assertThrows(NullPointerException.class, () -> ArrayUtils.toPrimitive(new Integer[] {1, null}));
    }

    @Test
    public void testToPrimitiveIntWithDefaultForNull() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, -1);
        assertArrayEquals(new int[] {1, -1, 3}, result);
    }

    // -------------------------------------------------------------- toString

    @Test
    public void testToStringNull() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("empty", ArrayUtils.toString(null, "empty"));
    }

    @Test
    public void testToStringArrayContent() {
        final String result = ArrayUtils.toString(new int[] {1, 2, 3});
        assertTrue(result.contains("1"));
        assertTrue(result.contains("2"));
        assertTrue(result.contains("3"));
    }

    @Test
    public void testToStringArrayMethod() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {"a", 1, null});
        assertArrayEquals(new String[] {"a", "1", "null"}, result);
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    public void testToStringArrayWithValueForNullElements() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {null, "x"}, "NIL");
        assertArrayEquals(new String[] {"NIL", "x"}, result);
    }

    // ------------------------------------------------------------- EMPTY_*

    @Test
    public void testEmptyConstants() {
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    // ------------------------------------------------------- custom fixture

    @Test
    public void testContainsWithCustomEquals() {
        final Fixture[] array = {new Fixture(1), new Fixture(2)};
        assertTrue(ArrayUtils.contains(array, new Fixture(2)));
        assertFalse(ArrayUtils.contains(array, new Fixture(3)));
    }
}
