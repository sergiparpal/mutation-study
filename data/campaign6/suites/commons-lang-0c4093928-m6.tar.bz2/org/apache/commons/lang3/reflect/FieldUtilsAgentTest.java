/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FieldUtils}.
 */
public class FieldUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    @interface Marker {
    }

    interface IfaceA {
        String IFACE_FIELD = "ifaceA";
    }

    interface IfaceB {
        String IFACE_FIELD = "ifaceB";
    }

    static class Base {
        public static String staticPublic = "basePublicStatic";
        public final String publicField = "basePublic";
        protected String protectedField = "baseProtected";
        @SuppressWarnings("unused")
        private String privateField = "basePrivate";
        @Marker
        public String annotatedField = "annotated";
    }

    static class Sub extends Base implements IfaceA {
        public String subPublic = "subPublic";
    }

    static class AmbiguousSub implements IfaceA, IfaceB {
    }

    static class HasFinalStatic {
        static final int CONST = 42;
    }

    static class HasTypedField {
        public int number = 1;
    }

    // ---- getAllFields / getAllFieldsList ----

    @Test
    public void testGetAllFieldsIncludesInheritedAndOwn() {
        final Field[] fields = FieldUtils.getAllFields(Sub.class);
        final List<Field> list = FieldUtils.getAllFieldsList(Sub.class);
        assertEquals(list.size(), fields.length);
        boolean foundSubPublic = false;
        boolean foundPrivateBase = false;
        for (final Field f : fields) {
            if (f.getName().equals("subPublic")) {
                foundSubPublic = true;
            }
            if (f.getName().equals("privateField")) {
                foundPrivateBase = true;
            }
        }
        assertTrue(foundSubPublic);
        assertTrue(foundPrivateBase);
    }

    @Test
    public void testGetAllFieldsNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.getAllFields(null);
            }
        });
    }

    @Test
    public void testGetAllFieldsListOnObjectHasNoFields() {
        final List<Field> list = FieldUtils.getAllFieldsList(Object.class);
        assertTrue(list.isEmpty());
    }

    // ---- getDeclaredField ----

    @Test
    public void testGetDeclaredFieldPublicFound() {
        final Field field = FieldUtils.getDeclaredField(Base.class, "staticPublic");
        assertNotNull(field);
        assertEquals("staticPublic", field.getName());
    }

    @Test
    public void testGetDeclaredFieldPrivateWithoutForceAccessIsNull() {
        final Field field = FieldUtils.getDeclaredField(Base.class, "privateField");
        assertNull(field);
    }

    @Test
    public void testGetDeclaredFieldPrivateWithForceAccess() {
        final Field field = FieldUtils.getDeclaredField(Base.class, "privateField", true);
        assertNotNull(field);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetDeclaredFieldDoesNotSearchSuperclass() {
        // subPublic is declared on Sub, not Base; querying Base must not find it
        final Field field = FieldUtils.getDeclaredField(Sub.class, "staticPublic");
        assertNull(field);
    }

    @Test
    public void testGetDeclaredFieldUnknownNameIsNull() {
        final Field field = FieldUtils.getDeclaredField(Base.class, "doesNotExist");
        assertNull(field);
    }

    @Test
    public void testGetDeclaredFieldBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.getDeclaredField(Base.class, "  ");
            }
        });
    }

    @Test
    public void testGetDeclaredFieldNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.getDeclaredField(null, "x");
            }
        });
    }

    // ---- getField ----

    @Test
    public void testGetFieldFindsInheritedProtectedWithForceAccess() {
        final Field field = FieldUtils.getField(Sub.class, "protectedField", true);
        assertNotNull(field);
        assertEquals(Base.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldWithoutForceAccessDoesNotFindNonPublic() {
        final Field field = FieldUtils.getField(Sub.class, "protectedField", false);
        assertNull(field);
    }

    @Test
    public void testGetFieldFindsPublicOnSubclass() {
        final Field field = FieldUtils.getField(Sub.class, "subPublic");
        assertNotNull(field);
        assertEquals("subPublic", field.getName());
    }

    @Test
    public void testGetFieldFindsInterfaceField() {
        final Field field = FieldUtils.getField(Sub.class, "IFACE_FIELD");
        assertNotNull(field);
        assertEquals(IfaceA.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldAmbiguousInterfaceFieldThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.getField(AmbiguousSub.class, "IFACE_FIELD");
            }
        });
    }

    @Test
    public void testGetFieldUnknownIsNull() {
        final Field field = FieldUtils.getField(Sub.class, "doesNotExist");
        assertNull(field);
    }

    @Test
    public void testGetFieldBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.getField(Sub.class, "");
            }
        });
    }

    // ---- annotations ----

    @Test
    public void testGetFieldsWithAnnotationFindsAnnotated() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(Base.class, Marker.class);
        assertEquals(1, fields.length);
        assertEquals("annotatedField", fields[0].getName());
        final List<Field> list = FieldUtils.getFieldsListWithAnnotation(Base.class, Marker.class);
        assertEquals(1, list.size());
    }

    @Test
    public void testGetFieldsWithAnnotationNoneFound() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(HasTypedField.class, Marker.class);
        assertEquals(0, fields.length);
    }

    @Test
    public void testGetFieldsWithAnnotationNullAnnotationThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.getFieldsWithAnnotation(Base.class, null);
            }
        });
    }

    // ---- read methods ----

    @Test
    public void testReadDeclaredFieldPublic() throws IllegalAccessException {
        final Sub sub = new Sub();
        final Object value = FieldUtils.readDeclaredField(sub, "subPublic");
        assertEquals("subPublic", value);
    }

    @Test
    public void testReadDeclaredFieldMissingThrows() {
        final Sub sub = new Sub();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readDeclaredField(sub, "protectedField");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldNullTargetThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readDeclaredField(null, "x");
            }
        });
    }

    @Test
    public void testReadDeclaredFieldWithForceAccess() throws IllegalAccessException {
        final Base base = new Base();
        final Object value = FieldUtils.readDeclaredField(base, "privateField", true);
        assertEquals("basePrivate", value);
    }

    @Test
    public void testReadDeclaredStaticField() throws IllegalAccessException {
        final Object value = FieldUtils.readDeclaredStaticField(Base.class, "staticPublic");
        assertEquals("basePublicStatic", value);
    }

    @Test
    public void testReadField() throws IllegalAccessException {
        final Sub sub = new Sub();
        final Object value = FieldUtils.readField(sub, "publicField");
        assertEquals("basePublic", value);
    }

    @Test
    public void testReadFieldViaFieldObject() throws IllegalAccessException {
        final Field field = FieldUtils.getField(Sub.class, "subPublic");
        final Sub sub = new Sub();
        assertEquals("subPublic", FieldUtils.readField(field, sub));
    }

    @Test
    public void testReadFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readField((Field) null, new Object());
            }
        });
    }

    @Test
    public void testReadStaticField() throws IllegalAccessException {
        final Field field = FieldUtils.getField(Base.class, "staticPublic");
        final Object value = FieldUtils.readStaticField(field);
        assertEquals("basePublicStatic", value);
    }

    @Test
    public void testReadStaticFieldByNameAndClass() throws IllegalAccessException {
        final Object value = FieldUtils.readStaticField(Base.class, "staticPublic");
        assertEquals("basePublicStatic", value);
    }

    @Test
    public void testReadStaticFieldOnNonStaticThrows() {
        final Field field = FieldUtils.getField(Base.class, "publicField");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readStaticField(field);
            }
        });
    }

    @Test
    public void testReadStaticFieldNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.readStaticField((Field) null);
            }
        });
    }

    // ---- write methods ----

    @Test
    public void testWriteFieldChangesValue() throws IllegalAccessException {
        final HasTypedField target = new HasTypedField();
        FieldUtils.writeField(target, "number", 99);
        assertEquals(99, target.number);
    }

    @Test
    public void testWriteFieldNotAssignableThrows() {
        final HasTypedField target = new HasTypedField();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeField(target, "number", "not an int");
            }
        });
    }

    @Test
    public void testWriteFieldStaticFinalThrows() throws NoSuchFieldException {
        // static final fields cannot be set even with forceAccess/setAccessible(true)
        final Field field = HasFinalStatic.class.getDeclaredField("CONST");
        field.setAccessible(true);
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeField(field, (Object) null, 100, true);
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldPrivateWithForceAccess() throws IllegalAccessException {
        final Base target = new Base();
        FieldUtils.writeDeclaredField(target, "privateField", "updated", true);
        assertEquals("updated", FieldUtils.readDeclaredField(target, "privateField", true));
    }

    @Test
    public void testWriteDeclaredFieldMissingThrows() {
        final Base target = new Base();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeDeclaredField(target, "noSuchField", "x");
            }
        });
    }

    @Test
    public void testWriteStaticField() throws IllegalAccessException {
        FieldUtils.writeStaticField(Base.class, "staticPublic", "changedStatic");
        try {
            assertEquals("changedStatic", FieldUtils.readStaticField(Base.class, "staticPublic"));
        } finally {
            FieldUtils.writeStaticField(Base.class, "staticPublic", "basePublicStatic");
        }
    }

    @Test
    public void testWriteStaticFieldNonStaticThrows() {
        final Field field = FieldUtils.getField(Base.class, "publicField");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IllegalAccessException {
                FieldUtils.writeStaticField(field, "x");
            }
        });
    }

    @Test
    public void testWriteDeclaredStaticField() throws IllegalAccessException {
        FieldUtils.writeDeclaredStaticField(Base.class, "staticPublic", "declStatic");
        try {
            assertEquals("declStatic", FieldUtils.readDeclaredStaticField(Base.class, "staticPublic"));
        } finally {
            FieldUtils.writeDeclaredStaticField(Base.class, "staticPublic", "basePublicStatic");
        }
    }

    // ---- removeFinalModifier ----

    @Test
    public void testRemoveFinalModifierRemovesFinal() throws NoSuchFieldException {
        final Field field = HasFinalStatic.class.getDeclaredField("CONST");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @Test
    public void testRemoveFinalModifierNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                FieldUtils.removeFinalModifier(null);
            }
        });
    }

    @Test
    public void testRemoveFinalModifierNonFinalFieldIsNoOp() throws NoSuchFieldException {
        final Field field = HasTypedField.class.getDeclaredField("number");
        assertFalse(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }
}
