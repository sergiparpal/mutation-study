/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * A trivial custom {@link Format} that upper-cases its argument.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof UpperCaseFormat;
        }

        @Override
        public int hashCode() {
            return UpperCaseFormat.class.hashCode();
        }
    }

    /**
     * Factory that only recognizes format name "upper", regardless of style arguments.
     */
    private static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return "upper".equals(name) ? new UpperCaseFormat() : null;
        }
    }

    /**
     * Factory that recognizes any format name and records the arguments it was invoked with.
     */
    private static final class RecordingFormatFactory implements FormatFactory {
        private String lastName;
        private String lastArguments;
        private Locale lastLocale;

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            this.lastName = name;
            this.lastArguments = arguments;
            this.lastLocale = locale;
            return new UpperCaseFormat();
        }
    }

    private Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testDefaultConstructorUsesDefaultLocaleAndFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("{0}", emf.toPattern());
        assertEquals("foo", emf.format(new Object[] {"foo"}));
    }

    @Test
    void testLocaleConstructorSetsLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    @Test
    void testNullLocaleDefaultsToSystemDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testNullPatternThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    void testSimplePatternRoundTripWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}, {1}", Locale.US);
        assertEquals("{0}, {1}", emf.toPattern());
        assertEquals("a, b", emf.format(new Object[] {"a", "b"}));
    }

    @Test
    void testStandardFormatWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
        assertEquals("{0,number,integer}", emf.toPattern());
    }

    @Test
    void testCustomFormatRegistryBasic() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    void testCustomFormatArgumentsAreSplitFromName() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("custom", factory);
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,custom,styleArg}", Locale.US, registry);
        assertEquals("custom", factory.lastName);
        assertEquals("styleArg", factory.lastArguments);
        assertEquals(Locale.US, factory.lastLocale);
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testCustomFormatNameWithLeadingWhitespaceIsTrimmed() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0, upper}", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    /**
     * Per the class Javadoc, "format-name ... values are trimmed of surrounding whitespace".
     * Here the format name has no style arguments but trailing whitespace before the closing
     * brace, so it should still resolve to the registered "upper" factory.
     *
     * BUG: {@link ExtendedMessageFormat#getFormat(String)} only trims the format name when a
     * style-argument separator is present; otherwise it uses the raw (untrimmed) description as
     * the registry lookup key, so the trailing space causes the lookup to fail and the pattern
     * falls through to {@link MessageFormat}, which doesn't recognize "upper " either.
     */
    @Test
    void testCustomFormatNameWithTrailingWhitespaceIsTrimmed() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper }", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testMixedCustomAndStandardFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} and {1,number,integer}", Locale.US, upperRegistry());
        assertEquals("HI and 42", emf.format(new Object[] {"hi", Integer.valueOf(42)}));
        assertEquals("{0,upper} and {1,number,integer}", emf.toPattern());
    }

    @Test
    void testRegistryOverridesStandardFormatName() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("number", new FormatFactory() {
            @Override
            public Format getFormat(final String name, final String arguments, final Locale locale) {
                return new UpperCaseFormat();
            }
        });
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, registry);
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testLiteralQuotedBraceIsNotTreatedAsFormatElement() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' literal", Locale.US, upperRegistry());
        assertEquals("{0} literal", emf.format(new Object[] {"x"}));
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("'abc", Locale.US, registry);
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated quoted string"));
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", Locale.US, registry);
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testInvalidNonDigitArgumentIndexThrows() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{a}", Locale.US, registry);
            }
        });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    void testNegativeArgumentIndexThrows() {
        final Map<String, FormatFactory> registry = upperRegistry();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{-1}", Locale.US, registry);
            }
        });
    }

    @Test
    void testMultiDigitArgumentIndex() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{10}", Locale.US, upperRegistry());
        final Object[] values = new Object[11];
        values[10] = "val";
        assertEquals("val", emf.format(values));
        assertEquals("{10}", emf.toPattern());
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsWithDifferentPattern() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US, registry);
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsWithDifferentClassReturnsFalse() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        final MessageFormat plain = new MessageFormat("{0}", Locale.US);
        assertFalse(emf.equals(plain));
    }

    @Test
    void testEqualsWithNullReturnsFalse() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsIsReflexive() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(emf.equals(emf));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testApplyPatternCanBeInvokedAgainToChangePattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, upperRegistry());
        assertEquals("first", emf.format(new Object[] {"first"}));
        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("SECOND", emf.format(new Object[] {"second"}));
    }
}
