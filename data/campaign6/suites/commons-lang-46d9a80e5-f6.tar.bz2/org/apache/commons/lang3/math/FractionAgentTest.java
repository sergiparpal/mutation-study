/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    @Test
    public void testGetFractionTwoArgsNormalizesSign() {
        final Fraction f = Fraction.getFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionTwoArgsNotReduced() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionNegativeDenominatorOverflow() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -5);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsWholeNumberNegative() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsWholeNumberPositive() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionThreeArgsNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -1, 7);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, -7);
            }
        });
    }

    @Test
    public void testGetFractionThreeArgsZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionDoubleSimple() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((double) Integer.MAX_VALUE + 10d);
            }
        });
    }

    @Test
    public void testGetFractionStringSimpleWhole() {
        final Fraction f = Fraction.getFraction("7");
        assertEquals(7, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringYZ() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringXYZ() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringInvalidXYZThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3-7");
            }
        });
    }

    @Test
    public void testGetReducedFractionReduces() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorNormalized() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(4, -8);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testAbsPositive() {
        final Fraction f = Fraction.getFraction(3, 5);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-3, 5);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(5, abs.getDenominator());
    }

    @Test
    public void testAbsMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.abs();
            }
        });
    }

    @Test
    public void testAddSimple() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAddZeroIdentity() {
        final Fraction a = Fraction.getFraction(2, 5);
        final Fraction result = a.add(Fraction.ZERO);
        assertEquals(2, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testAddNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.ONE;
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.add(b);
            }
        });
    }

    @Test
    public void testSubtractSimple() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.subtract(null);
            }
        });
    }

    @Test
    public void testMultiplyBySimple() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction result = a.multiplyBy(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testMultiplyByNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.multiplyBy(null);
            }
        });
    }

    @Test
    public void testDivideBySimple() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.divideBy(b);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.divideBy(null);
            }
        });
    }

    @Test
    public void testInvertSimple() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction result = a.invert();
        assertEquals(7, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction a = Fraction.getFraction(-3, 7);
        final Fraction result = a.invert();
        assertEquals(-7, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvertMinValueThrows() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.invert();
            }
        });
    }

    @Test
    public void testNegateSimple() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction result = a.negate();
        assertEquals(-3, result.getNumerator());
        assertEquals(7, result.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.negate();
            }
        });
    }

    @Test
    public void testPowZero() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(Fraction.ONE, a.pow(0));
    }

    @Test
    public void testPowZeroOnZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOne() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(a, a.pow(1));
    }

    @Test
    public void testPowPositive() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testCompareToEqualValues() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareToLessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareToNullThrows() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.compareTo(null);
            }
        });
    }

    @Test
    public void testEqualsNotReducedDifferent() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a, b);
    }

    @Test
    public void testEqualsSameValues() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsNull() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals("1/2"));
    }

    @Test
    public void testReduceSimplifies() {
        final Fraction a = Fraction.getFraction(2, 4);
        final Fraction result = a.reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertSame(a, a.reduce());
    }

    @Test
    public void testReduceZeroNumeratorNotZeroInstance() {
        final Fraction a = Fraction.getFraction(0, 5);
        final Fraction result = a.reduce();
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testGetProperNumeratorAndWholePositive() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals(1, a.getProperWhole());
        assertEquals(3, a.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals(-1, a.getProperWhole());
        assertEquals(3, a.getProperNumerator());
    }

    @Test
    public void testIntValueTruncates() {
        final Fraction a = Fraction.getFraction(7, 2);
        assertEquals(3, a.intValue());
    }

    @Test
    public void testIntValueNegativeTruncatesTowardZero() {
        final Fraction a = Fraction.getFraction(-7, 2);
        assertEquals(-3, a.intValue());
    }

    @Test
    public void testLongValue() {
        final Fraction a = Fraction.getFraction(7, 2);
        assertEquals(3L, a.longValue());
    }

    @Test
    public void testFloatValue() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertEquals(0.5f, a.floatValue(), 0.0f);
    }

    @Test
    public void testDoubleValue() {
        final Fraction a = Fraction.getFraction(1, 4);
        assertEquals(0.25d, a.doubleValue(), 0.0d);
    }

    @Test
    public void testToStringFormat() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals("3/7", a.toString());
    }

    @Test
    public void testToStringNotReduced() {
        final Fraction a = Fraction.getFraction(2, 4);
        assertEquals("2/4", a.toString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringWholeOne() {
        final Fraction a = Fraction.getFraction(4, 4);
        assertEquals("1", a.toProperString());
    }

    @Test
    public void testToProperStringNegativeOne() {
        final Fraction a = Fraction.getFraction(-4, 4);
        assertEquals("-1", a.toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", a.toProperString());
    }

    @Test
    public void testToProperStringNegativeProperFraction() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", a.toProperString());
    }

    @Test
    public void testToProperStringLessThanOne() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals("3/7", a.toProperString());
    }

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }
}
