/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    public interface Greeter {
        String greet();
    }

    static class GreeterImpl implements Greeter {
        @Override
        public String greet() {
            return "hi";
        }
    }

    private static class PrivateNested {
        // empty
    }

    interface Foo {
        // empty
    }

    interface Bar extends Foo {
        // empty
    }

    static class Base implements Bar {
        // empty
    }

    static class Derived extends Base {
        // empty
    }

    // -------------------- getAbbreviatedName --------------------

    @Test
    void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
    }

    @Test
    void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    void testGetAbbreviatedNameVariants() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
    }

    @Test
    void testGetAbbreviatedNameInvalidLength() {
        assertThrows(IllegalArgumentException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() {
                ClassUtils.getAbbreviatedName("abc", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() {
                ClassUtils.getAbbreviatedName("abc", -1);
            }
        });
    }

    // -------------------- convertClassesToClassNames --------------------

    @Test
    void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    void testConvertClassesToClassNamesClassCastException() {
        final List rawList = new ArrayList();
        rawList.add("not a class");
        assertThrows(ClassCastException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() {
                ClassUtils.convertClassesToClassNames(rawList);
            }
        });
    }

    // -------------------- convertClassNamesToClasses --------------------

    @Test
    void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("no.such.ClassExists");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    void testConvertClassNamesToClassesClassCastException() {
        final List rawList = new ArrayList();
        rawList.add(Integer.valueOf(1));
        assertThrows(ClassCastException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() {
                ClassUtils.convertClassNamesToClasses(rawList);
            }
        });
    }

    // -------------------- getAllInterfaces / getAllSuperclasses --------------------

    @Test
    void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Derived.class);
        assertEquals(2, interfaces.size());
        assertEquals(Bar.class, interfaces.get(0));
        assertEquals(Foo.class, interfaces.get(1));
    }

    @Test
    void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Derived.class);
        assertEquals(2, superclasses.size());
        assertEquals(Base.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    // -------------------- getCanonicalName --------------------

    @Test
    void testGetCanonicalName() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello", "N/A"));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
    }

    // -------------------- getClass --------------------

    @Test
    void testGetClassPrimitiveAndArray() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
        assertEquals(int[].class, ClassUtils.getClass("int[]"));
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
    }

    @Test
    void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getClass("no.such.ClassExists");
            }
        });
    }

    @Test
    void testGetClassNullPointer() {
        assertThrows(NullPointerException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassEmptyName() {
        assertThrows(IllegalArgumentException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getClass("");
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensionsEncoded() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.Object;");
        final String badName = sb.toString();
        assertThrows(IllegalArgumentException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getClass(badName);
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensionsBracketForm() {
        final StringBuilder sb = new StringBuilder("java.lang.Object");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String badName = sb.toString();
        assertThrows(IllegalArgumentException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getClass(badName);
            }
        });
    }

    @Test
    void testGetClassNameTooLong() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        final String longName = sb.toString();
        assertThrows(IllegalArgumentException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getClass(longName);
            }
        });
    }

    // -------------------- getComponentType --------------------

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
        assertNull(ClassUtils.getComponentType((Class<String[]>) null));
    }

    // -------------------- getName --------------------

    @Test
    void testGetName() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("N/A", ClassUtils.getName((Class<?>) null, "N/A"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
        assertEquals("N/A", ClassUtils.getName((Object) null, "N/A"));
    }

    // -------------------- getPackageCanonicalName / getPackageName --------------------

    @Test
    void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName(int[].class));
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("NoPackageClass"));
    }

    // -------------------- getPublicMethod --------------------

    @Test
    void testGetPublicMethod() throws Exception {
        final Method method = ClassUtils.getPublicMethod(GreeterImpl.class, "greet");
        assertTrue(ClassUtils.isPublic(method.getDeclaringClass()));
        assertEquals(Greeter.class, method.getDeclaringClass());
        assertEquals("hi", method.invoke(new GreeterImpl()));
    }

    @Test
    void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.getPublicMethod(GreeterImpl.class, "doesNotExist");
            }
        });
    }

    // -------------------- getShortCanonicalName --------------------

    @Test
    void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("N/A", ClassUtils.getShortCanonicalName((Object) null, "N/A"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
    }

    // -------------------- getShortClassName --------------------

    @Test
    void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
    }

    @Test
    void testGetShortClassNameObject() {
        assertEquals("N/A", ClassUtils.getShortClassName((Object) null, "N/A"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "N/A"));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    @Test
    void testGetShortClassNameAnonymous() {
        final Runnable r = new Runnable() {
            @Override
            public void run() {
                // empty
            }
        };
        final String shortName = ClassUtils.getShortClassName(r.getClass());
        assertTrue(shortName.startsWith("ClassUtilsAgentTest."), shortName);
        final String suffix = shortName.substring("ClassUtilsAgentTest.".length());
        assertTrue(suffix.length() > 0 && Character.isDigit(suffix.charAt(0)), shortName);
    }

    // -------------------- getSimpleName --------------------

    @Test
    void testGetSimpleName() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("N/A", ClassUtils.getSimpleName((Class<?>) null, "N/A"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
        assertEquals("N/A", ClassUtils.getSimpleName((Object) null, "N/A"));
    }

    // -------------------- hierarchy --------------------

    @Test
    void testHierarchyExcludeInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Derived.class).iterator();
        assertTrue(it.hasNext());
        assertEquals(Derived.class, it.next());
        assertTrue(it.hasNext());
        assertEquals(Base.class, it.next());
        assertTrue(it.hasNext());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(Derived.class, ClassUtils.Interfaces.INCLUDE)) {
            classes.add(c);
        }
        assertEquals(Derived.class, classes.get(0));
        assertTrue(classes.contains(Base.class));
        assertTrue(classes.contains(Object.class));
        assertTrue(classes.contains(Bar.class));
        assertTrue(classes.contains(Foo.class));
    }

    // -------------------- isAssignable --------------------

    @Test
    void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, float.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(int.class, boolean.class));
        assertTrue(ClassUtils.isAssignable(long.class, float.class));
        assertTrue(ClassUtils.isAssignable(long.class, double.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, float.class));
        assertTrue(ClassUtils.isAssignable(float.class, double.class));
        assertTrue(ClassUtils.isAssignable(char.class, int.class));
        assertTrue(ClassUtils.isAssignable(short.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertTrue(ClassUtils.isAssignable(byte.class, double.class));
    }

    @Test
    void testIsAssignableNulls() {
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(Object.class, null));
    }

    @Test
    void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
    }

    @Test
    void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { String.class }, new Class<?>[] { String.class, Integer.class }));
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { String.class, int.class }, String.class, long.class));
    }

    // -------------------- isInnerClass --------------------

    @Test
    void testIsInnerClass() {
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertFalse(ClassUtils.isInnerClass(null));
    }

    // -------------------- isPrimitiveOrWrapper / isPrimitiveWrapper --------------------

    @Test
    void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    // -------------------- isPublic --------------------

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateNested.class));
    }

    @Test
    void testIsPublicNullPointer() {
        assertThrows(NullPointerException.class, new ThrowingRunnableAdapter() {
            @Override
            void run() throws Exception {
                ClassUtils.isPublic(null);
            }
        });
    }

    // -------------------- primitiveToWrapper / primitivesToWrappers --------------------

    @Test
    void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        assertArrayEquals(new Class<?>[] { Integer.class, String.class }, ClassUtils.primitivesToWrappers(int.class, String.class));
    }

    // -------------------- wrapperToPrimitive / wrappersToPrimitives --------------------

    @Test
    void testWrapperToPrimitive() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertArrayEquals(new Class<?>[] { int.class, null }, ClassUtils.wrappersToPrimitives(Integer.class, String.class));
    }

    // -------------------- toClass --------------------

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        assertArrayEquals(new Class<?>[] { String.class, Integer.class, null }, ClassUtils.toClass("a", 1, null));
    }

    // -------------------- comparator --------------------

    @Test
    void testComparator() {
        final java.util.Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertTrue(comparator.compare(Integer.class, String.class) < 0);
        assertTrue(comparator.compare(String.class, Integer.class) > 0);
        assertEquals(0, comparator.compare(String.class, String.class));
    }

    /**
     * Adapter allowing checked exceptions inside {@code assertThrows} without lambdas.
     */
    private abstract static class ThrowingRunnableAdapter implements org.junit.jupiter.api.function.Executable {

        abstract void run() throws Exception;

        @Override
        public void execute() throws Throwable {
            run();
        }
    }
}
