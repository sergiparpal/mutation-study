/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MultilineRecursiveToStringStyle}. Self-contained: defines its own fixtures and
 * does not rely on any other test class.
 */
class MultilineRecursiveToStringStyleAgentTest {

    static class Job {
        String title;
    }

    static class Person {
        String name;
        int age;
        boolean smoker;
        Job job;
    }

    private static final String NL = System.lineSeparator();

    private final Integer base = Integer.valueOf(5);

    private final String baseStr = base.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(base));

    @Test
    void testAppendSuper() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .appendSuper("Integer@8888[]")
                .append("a", "hello")
                .toString();
        assertEquals(baseStr + "[" + NL + "  a=hello" + NL + "]", result);
    }

    @Test
    void testBlank() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(baseStr + "[" + NL + "  " + NL + "]", result);
    }

    @Test
    void testBooleanArray() {
        final boolean[] array = {true, false, true};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append(array).toString();
        assertEquals(baseStr + "[" + NL
                + "  {" + NL
                + "    true," + NL
                + "    false," + NL
                + "    true" + NL
                + "  }" + NL
                + "]", result);
    }

    @Test
    void testEmptyObjectArray() {
        final Object[] array = new Object[0];
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append(array).toString();
        assertEquals(baseStr + "[" + NL
                + "  {" + NL
                + "    " + NL
                + "  }" + NL
                + "]", result);
    }

    @Test
    void testIndentRestoredAfterArray() {
        final int[] array = {7, 8};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("arr", array)
                .append("b", 3L)
                .toString();
        assertEquals(baseStr + "[" + NL
                + "  arr={" + NL
                + "    7," + NL
                + "    8" + NL
                + "  }," + NL
                + "  b=3" + NL
                + "]", result);
    }

    @Test
    void testListNoDetailVersusDetail() {
        final ArrayList<Object> emptyList = new ArrayList<Object>();
        final String noDetail = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("a", emptyList, false).toString();
        assertEquals(baseStr + "[" + NL + "  a=<size=0>" + NL + "]", noDetail);

        final String detail = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("a", emptyList, true).toString();
        final String listStr = "java.util.ArrayList@" + Integer.toHexString(System.identityHashCode(emptyList));
        assertEquals(baseStr + "[" + NL
                + "  a=" + listStr + "{" + NL
                + "    " + NL
                + "  }" + NL
                + "]", detail);
    }

    @Test
    void testLong() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("a", 3L).toString();
        assertEquals(baseStr + "[" + NL + "  a=3" + NL + "]", result);
    }

    @Test
    void testLongArray() {
        final long[] array = {1, 2, -3, 4};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append(array).toString();
        assertEquals(baseStr + "[" + NL
                + "  {" + NL
                + "    1," + NL
                + "    2," + NL
                + "    -3," + NL
                + "    4" + NL
                + "  }" + NL
                + "]", result);
    }

    @Test
    void testLongArrayArray() {
        final long[][] array = {{1, 2}, null, {5}};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append(array).toString();
        assertEquals(baseStr + "[" + NL
                + "  {" + NL
                + "    {" + NL
                + "      1," + NL
                + "      2" + NL
                + "    }," + NL
                + "    <null>," + NL
                + "    {" + NL
                + "      5" + NL
                + "    }" + NL
                + "  }" + NL
                + "]", result);
    }

    @Test
    void testMultipleFields() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("a", 3L)
                .append("b", 4L)
                .toString();
        assertEquals(baseStr + "[" + NL + "  a=3," + NL + "  b=4" + NL + "]", result);
    }

    @Test
    void testNamedNullObject() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("a", (Object) null).toString();
        assertEquals(baseStr + "[" + NL + "  a=<null>" + NL + "]", result);
    }

    @Test
    void testNullObject() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append((Object) null).toString();
        assertEquals(baseStr + "[" + NL + "  <null>" + NL + "]", result);
    }

    @Test
    void testObjectArray() {
        final Object[] array = {null, base, new int[] {3, 6}};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append(array).toString();
        assertEquals(baseStr + "[" + NL
                + "  {" + NL
                + "    <null>," + NL
                + "    5," + NL
                + "    {" + NL
                + "      3," + NL
                + "      6" + NL
                + "    }" + NL
                + "  }" + NL
                + "]", result);
    }

    @Test
    void testPerson() {
        final Person p = new Person();
        p.name = "John Doe";
        p.age = 33;
        p.smoker = false;
        p.job = new Job();
        p.job.title = "Manager";
        final String personStr = p.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p));
        final String jobStr = p.job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p.job));
        final ReflectionToStringBuilder builder = new ReflectionToStringBuilder(p, new MultilineRecursiveToStringStyle());
        final String result = builder.toString();
        assertEquals(personStr + "[" + NL
                + "  age=33," + NL
                + "  job=" + jobStr + "[" + NL
                + "    title=Manager" + NL
                + "  ]," + NL
                + "  name=John Doe," + NL
                + "  smoker=false" + NL
                + "]", result);
    }

    @Test
    void testPlainObjectValueNotExploded() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("a", (Object) Integer.valueOf(7)).toString();
        assertEquals(baseStr + "[" + NL + "  a=7" + NL + "]", result);
    }

    @Test
    void testPlainStringValueNotExploded() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("a", "hello").toString();
        assertEquals(baseStr + "[" + NL + "  a=hello" + NL + "]", result);
    }

    @Test
    void testRepeatedUseOfSameStyleProducesConsistentIndent() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final String first = new ToStringBuilder(base, style).append("a", 1L).toString();
        final String second = new ToStringBuilder(base, style).append("a", 1L).toString();
        assertEquals(baseStr + "[" + NL + "  a=1" + NL + "]", first);
        assertEquals(first, second);
    }

    @Test
    void testSerializable() throws IOException, ClassNotFoundException {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        assertTrue(style instanceof Serializable);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(style);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final Object deserialized = ois.readObject();
        ois.close();
        assertNotNull(deserialized);
        assertTrue(deserialized instanceof MultilineRecursiveToStringStyle);
        final String result = new ToStringBuilder(base, (MultilineRecursiveToStringStyle) deserialized)
                .append("a", 3L).toString();
        assertEquals(baseStr + "[" + NL + "  a=3" + NL + "]", result);
    }

}
