/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

public class ValidateAgentTest {

    @Test
    public void testExclusiveBetweenDoubleValid() {
        Validate.exclusiveBetween(0.1, 2.1, 1.1);
    }

    @Test
    public void testExclusiveBetweenDoubleBoundaryFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.exclusiveBetween(0.1, 2.1, 0.1));
        assertTrue(ex.getMessage().contains("0.1"));
    }

    @Test
    public void testExclusiveBetweenDoubleNaNFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.exclusiveBetween(0.1, 2.1, Double.NaN));
    }

    @Test
    public void testExclusiveBetweenDoubleWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.exclusiveBetween(0.1, 2.1, 2.1, "custom message"));
        assertEquals("custom message", ex.getMessage());
    }

    @Test
    public void testExclusiveBetweenLongValid() {
        Validate.exclusiveBetween(0L, 2L, 1L);
    }

    @Test
    public void testExclusiveBetweenLongUpperBoundaryFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.exclusiveBetween(0L, 2L, 2L));
    }

    @Test
    public void testExclusiveBetweenLongWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.exclusiveBetween(0L, 2L, 0L, "not in range"));
        assertEquals("not in range", ex.getMessage());
    }

    @Test
    public void testExclusiveBetweenComparableValid() {
        Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(1));
    }

    @Test
    public void testExclusiveBetweenComparableBoundaryFails() {
        assertThrows(IllegalArgumentException.class,
                () -> Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(2)));
    }

    @Test
    public void testExclusiveBetweenComparableWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(2), "bad %s", "value"));
        assertEquals("bad value", ex.getMessage());
    }

    @Test
    public void testFiniteValid() {
        Validate.finite(1.0);
    }

    @Test
    public void testFiniteNaNFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.finite(Double.NaN));
        assertNotNull(ex.getMessage());
    }

    @Test
    public void testFiniteInfiniteFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.finite(Double.POSITIVE_INFINITY));
    }

    @Test
    public void testFiniteWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.finite(Double.NEGATIVE_INFINITY, "bad value %s", "x"));
        assertEquals("bad value x", ex.getMessage());
    }

    @Test
    public void testInclusiveBetweenDoubleValidAtBoundary() {
        Validate.inclusiveBetween(0.1, 2.1, 0.1);
        Validate.inclusiveBetween(0.1, 2.1, 2.1);
    }

    @Test
    public void testInclusiveBetweenDoubleOutOfRangeFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.inclusiveBetween(0.1, 2.1, 3.0));
    }

    @Test
    public void testInclusiveBetweenDoubleNaNFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.inclusiveBetween(0.1, 2.1, Double.NaN));
    }

    @Test
    public void testInclusiveBetweenDoubleWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.inclusiveBetween(0.1, 2.1, 3.0, "range message"));
        assertEquals("range message", ex.getMessage());
    }

    @Test
    public void testInclusiveBetweenLongValidAtBoundary() {
        Validate.inclusiveBetween(0L, 2L, 0L);
        Validate.inclusiveBetween(0L, 2L, 2L);
    }

    @Test
    public void testInclusiveBetweenLongOutOfRangeFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.inclusiveBetween(0L, 2L, 3L));
    }

    @Test
    public void testInclusiveBetweenLongWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.inclusiveBetween(0L, 2L, 3L, "range"));
        assertEquals("range", ex.getMessage());
    }

    @Test
    public void testInclusiveBetweenComparableValid() {
        Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(0));
    }

    @Test
    public void testInclusiveBetweenComparableOutOfRangeFails() {
        assertThrows(IllegalArgumentException.class,
                () -> Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3)));
    }

    @Test
    public void testInclusiveBetweenComparableWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3), "bad %s", "value"));
        assertEquals("bad value", ex.getMessage());
    }

    @Test
    public void testIsAssignableFromValid() {
        Validate.isAssignableFrom(Number.class, Integer.class);
    }

    @Test
    public void testIsAssignableFromFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isAssignableFrom(String.class, Integer.class));
        assertTrue(ex.getMessage().contains("Integer"));
        assertTrue(ex.getMessage().contains("String"));
    }

    @Test
    public void testIsAssignableFromWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isAssignableFrom(String.class, Integer.class, "cannot assign %s", "here"));
        assertEquals("cannot assign here", ex.getMessage());
    }

    @Test
    public void testIsInstanceOfValid() {
        Validate.isInstanceOf(Number.class, Integer.valueOf(1));
    }

    @Test
    public void testIsInstanceOfFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isInstanceOf(Number.class, "not a number"));
        assertTrue(ex.getMessage().contains("Number"));
    }

    @Test
    public void testIsInstanceOfNullObjectFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.isInstanceOf(Number.class, null));
    }

    @Test
    public void testIsInstanceOfWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isInstanceOf(Number.class, "x", "wrong type %s", "here"));
        assertEquals("wrong type here", ex.getMessage());
    }

    @Test
    public void testIsTrueValid() {
        Validate.isTrue(true);
    }

    @Test
    public void testIsTrueFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.isTrue(false));
        assertEquals("The validated expression is false", ex.getMessage());
    }

    @Test
    public void testIsTrueWithDoubleValue() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isTrue(false, "value must be > 0: %s", 1.5));
        assertEquals("value must be > 0: 1.5", ex.getMessage());
    }

    @Test
    public void testIsTrueWithLongValue() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isTrue(false, "value must be > 0: %s", 5L));
        assertEquals("value must be > 0: 5", ex.getMessage());
    }

    @Test
    public void testIsTrueWithVarargs() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isTrue(false, "between %d and %d", 1, 10));
        assertEquals("between 1 and 10", ex.getMessage());
    }

    @Test
    public void testIsTrueWithSupplier() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.isTrue(false, () -> "supplied message"));
        assertEquals("supplied message", ex.getMessage());
    }

    @Test
    public void testIsTrueWithSupplierValidDoesNotInvokeSupplier() {
        final boolean[] invoked = {false};
        Validate.isTrue(true, () -> {
            invoked[0] = true;
            return "unused";
        });
        assertTrue(!invoked[0]);
    }

    @Test
    public void testMatchesPatternValid() {
        Validate.matchesPattern("hi", "[a-z]*");
    }

    @Test
    public void testMatchesPatternFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.matchesPattern("Hi", "[a-z]*"));
        assertTrue(ex.getMessage().contains("Hi"));
    }

    @Test
    public void testMatchesPatternWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.matchesPattern("Hi", "[a-z]*", "no match %s", "here"));
        assertEquals("no match here", ex.getMessage());
    }

    @Test
    public void testNoNullElementsIterableValid() {
        final List<String> list = new ArrayList<>();
        list.add("a");
        list.add("b");
        final List<String> result = Validate.noNullElements(list);
        assertSame(list, result);
    }

    @Test
    public void testNoNullElementsIterableNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.noNullElements((List<String>) null));
    }

    @Test
    public void testNoNullElementsIterableContainsNullFails() {
        final List<String> list = new ArrayList<>();
        list.add("a");
        list.add(null);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.noNullElements(list));
        assertEquals("The validated collection contains null element at index: 0", ex.getMessage());
    }

    @Test
    public void testNoNullElementsIterableWithMessage() {
        final List<String> list = new ArrayList<>();
        list.add(null);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.noNullElements(list, "null at %d"));
        assertEquals("null at 0", ex.getMessage());
    }

    @Test
    public void testNoNullElementsArrayValid() {
        final String[] array = {"a", "b"};
        final String[] result = Validate.noNullElements(array);
        assertSame(array, result);
    }

    @Test
    public void testNoNullElementsArrayNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.noNullElements((String[]) null));
    }

    @Test
    public void testNoNullElementsArrayContainsNullFails() {
        final String[] array = {"a", null, "c"};
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.noNullElements(array));
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    public void testNoNullElementsArrayWithMessage() {
        final String[] array = {null};
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.noNullElements(array, "null element at %d"));
        assertEquals("null element at 0", ex.getMessage());
    }

    @Test
    public void testNotBlankValid() {
        final String result = Validate.notBlank("abc");
        assertEquals("abc", result);
    }

    @Test
    public void testNotBlankNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.notBlank((String) null));
    }

    @Test
    public void testNotBlankEmptyFails() {
        assertThrows(IllegalArgumentException.class, () -> Validate.notBlank(""));
    }

    @Test
    public void testNotBlankWhitespaceFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notBlank("   "));
        assertEquals("The validated character sequence is blank", ex.getMessage());
    }

    @Test
    public void testNotBlankWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notBlank(" ", "blank!"));
        assertEquals("blank!", ex.getMessage());
    }

    @Test
    public void testNotEmptyCollectionValid() {
        final List<String> list = new ArrayList<>();
        list.add("a");
        final List<String> result = Validate.notEmpty(list);
        assertSame(list, result);
    }

    @Test
    public void testNotEmptyCollectionNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.notEmpty((List<String>) null));
    }

    @Test
    public void testNotEmptyCollectionEmptyFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notEmpty(new ArrayList<String>()));
        assertEquals("The validated collection is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyCollectionWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.notEmpty(new ArrayList<String>(), "collection empty"));
        assertEquals("collection empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyMapValid() {
        final Map<String, String> map = new HashMap<>();
        map.put("k", "v");
        final Map<String, String> result = Validate.notEmpty(map);
        assertSame(map, result);
    }

    @Test
    public void testNotEmptyMapNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.notEmpty((Map<String, String>) null));
    }

    @Test
    public void testNotEmptyMapEmptyFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notEmpty(new HashMap<String, String>()));
        assertEquals("The validated map is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyMapWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> Validate.notEmpty(new HashMap<String, String>(), "map empty"));
        assertEquals("map empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyCharSequenceValid() {
        final String result = Validate.notEmpty("abc");
        assertEquals("abc", result);
    }

    @Test
    public void testNotEmptyCharSequenceNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.notEmpty((String) null));
    }

    @Test
    public void testNotEmptyCharSequenceEmptyFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notEmpty(""));
        assertEquals("The validated character sequence is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyCharSequenceWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notEmpty("", "string empty"));
        assertEquals("string empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyArrayValid() {
        final String[] array = {"a"};
        final String[] result = Validate.notEmpty(array);
        assertSame(array, result);
    }

    @Test
    public void testNotEmptyArrayNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.notEmpty((String[]) null));
    }

    @Test
    public void testNotEmptyArrayEmptyFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notEmpty(new String[0]));
        assertEquals("The validated array is empty", ex.getMessage());
    }

    @Test
    public void testNotEmptyArrayWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notEmpty(new String[0], "array empty"));
        assertEquals("array empty", ex.getMessage());
    }

    @Test
    public void testNotNaNValid() {
        Validate.notNaN(1.0);
    }

    @Test
    public void testNotNaNFails() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notNaN(Double.NaN));
        assertEquals("The validated value is not a number", ex.getMessage());
    }

    @Test
    public void testNotNaNWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> Validate.notNaN(Double.NaN, "not a number: %s", "x"));
        assertEquals("not a number: x", ex.getMessage());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testNotNullDeprecatedValid() {
        final String obj = "value";
        final String result = Validate.notNull(obj);
        assertSame(obj, result);
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testNotNullDeprecatedNullFails() {
        final NullPointerException ex = assertThrows(NullPointerException.class, () -> Validate.notNull((String) null));
        assertEquals("The validated object is null", ex.getMessage());
    }

    @Test
    public void testNotNullWithMessageValid() {
        final String obj = "value";
        final String result = Validate.notNull(obj, "should not be null");
        assertSame(obj, result);
    }

    @Test
    public void testNotNullWithMessageNullFails() {
        final NullPointerException ex = assertThrows(NullPointerException.class, () -> Validate.notNull((String) null, "must not be null: %s", "x"));
        assertEquals("must not be null: x", ex.getMessage());
    }

    @Test
    public void testValidIndexCollectionValid() {
        final List<String> list = new ArrayList<>();
        list.add("a");
        list.add("b");
        final List<String> result = Validate.validIndex(list, 1);
        assertSame(list, result);
    }

    @Test
    public void testValidIndexCollectionNegativeFails() {
        final List<String> list = new ArrayList<>();
        list.add("a");
        assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex(list, -1));
    }

    @Test
    public void testValidIndexCollectionTooLargeFails() {
        final List<String> list = new ArrayList<>();
        list.add("a");
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex(list, 1));
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    public void testValidIndexCollectionNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.validIndex((List<String>) null, 0));
    }

    @Test
    public void testValidIndexCollectionWithMessage() {
        final List<String> list = new ArrayList<>();
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex(list, 0, "bad index %d", 0));
        assertEquals("bad index 0", ex.getMessage());
    }

    @Test
    public void testValidIndexCharSequenceValid() {
        final String str = "abc";
        final String result = Validate.validIndex(str, 2);
        assertSame(str, result);
    }

    @Test
    public void testValidIndexCharSequenceNegativeFails() {
        assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex("abc", -1));
    }

    @Test
    public void testValidIndexCharSequenceTooLargeFails() {
        assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex("abc", 3));
    }

    @Test
    public void testValidIndexCharSequenceNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.validIndex((String) null, 0));
    }

    @Test
    public void testValidIndexCharSequenceWithMessage() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex("abc", 3, "bad char index"));
        assertEquals("bad char index", ex.getMessage());
    }

    @Test
    public void testValidIndexArrayValid() {
        final String[] array = {"a", "b"};
        final String[] result = Validate.validIndex(array, 1);
        assertSame(array, result);
    }

    @Test
    public void testValidIndexArrayNegativeFails() {
        assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex(new String[] {"a"}, -1));
    }

    @Test
    public void testValidIndexArrayTooLargeFails() {
        assertThrows(IndexOutOfBoundsException.class, () -> Validate.validIndex(new String[] {"a"}, 1));
    }

    @Test
    public void testValidIndexArrayNullFails() {
        assertThrows(NullPointerException.class, () -> Validate.validIndex((String[]) null, 0));
    }

    @Test
    public void testValidIndexArrayWithMessage() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class,
                () -> Validate.validIndex(new String[] {"a"}, 1, "bad array index"));
        assertEquals("bad array index", ex.getMessage());
    }

    @Test
    public void testValidStateValid() {
        Validate.validState(true);
    }

    @Test
    public void testValidStateFails() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class, () -> Validate.validState(false));
        assertEquals("The validated state is false", ex.getMessage());
    }

    @Test
    public void testValidStateWithMessage() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class, () -> Validate.validState(false, "bad state %s", "here"));
        assertEquals("bad state here", ex.getMessage());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructor() {
        assertNotNull(new Validate());
    }

    @Test
    public void testIsAssignableFromReturnsNothingButArrayComparisonSanity() {
        final Integer[] array = {1, 2, 3};
        assertArrayEquals(array, Validate.noNullElements(array));
    }
}
