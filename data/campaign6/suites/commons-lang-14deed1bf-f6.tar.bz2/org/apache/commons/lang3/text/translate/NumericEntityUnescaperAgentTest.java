/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testExplicitOptionIsSet() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalEntityWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#65;"));
        assertEquals("Test A end", neu.translate("Test &#65; end"));
    }

    @Test
    void testHexEntityLowerAndUpperX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#x41;"));
        assertEquals("A", neu.translate("&#X41;"));
    }

    @Test
    void testHexEntityMixedCaseDigits() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("ÿ", neu.translate("&#xfF;"));
    }

    @Test
    void testSupplementaryUnescaping() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#68642;";
        final String expected = "𐰢";
        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testBoundaryAtMaxBasicMultilingualCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        // 0xFFFF (65535) is the last code point that must be written as a single char,
        // not as a surrogate pair.
        final String result = neu.translate("&#65535;");
        assertEquals(1, result.length());
        assertEquals(0xFFFF, result.charAt(0));
    }

    @Test
    void testBoundaryJustAboveMaxBasicMultilingualCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        // 0x10000 (65536) is the first code point requiring a surrogate pair.
        final String result = neu.translate("&#65536;");
        assertEquals(2, result.length());
        assertEquals(0x10000, result.codePointAt(0));
    }

    @Test
    void testMissingSemicolonDefaultIgnoresEntity() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#x30 not test";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testMissingSemicolonOptionalConsumesEntity() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final String input = "Test &#x30 not test";
        final String expected = "Test 0 not test";
        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testMissingSemicolonErrorOptionThrows() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final String input = "Test &#x30 not test";
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                neu.translate(input);
            }
        });
    }

    @Test
    void testOutOfBoundsTrailingAmpersandSequencesAreIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test &", neu.translate("Test &"));
        assertEquals("Test &#", neu.translate("Test &#"));
        assertEquals("Test &#x", neu.translate("Test &#x"));
        assertEquals("Test &#X", neu.translate("Test &#X"));
    }

    @Test
    void testHexPrefixWithNoDigitsAtAll() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        // "&#x" followed immediately by ';', with no hex digits in between: unparsable, left as-is.
        final String input = "Test &#x; end";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testDecimalPrefixWithNoDigitsAtAll() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#; end";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testNonNumericCharactersAfterAmpersandHashAreIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        // Not numeric at all: no digits can be scanned, the number format fails and the
        // literal text is preserved.
        final String input = "Test &#abc; end";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testNumberTooLargeToParseAsIntIsIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        // Overflows Integer.parseInt range: NumberFormatException is caught internally and the
        // entity is left untouched.
        final String input = "Test &#99999999999999; end";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testNoLeadingAmpersandIsUntouched() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "#65;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testEmptyStringIsUnchanged() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("", neu.translate(""));
    }

    @Test
    void testNullInputReturnsNull() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals(null, neu.translate((CharSequence) null));
    }

    @Test
    void testMultipleEntitiesInOneString() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("AB", neu.translate("&#65;&#66;"));
        assertEquals("A-B", neu.translate("&#65;-&#66;"));
    }

    @Test
    void testTranslateAtIndexReturnsConsumedCodePointCount() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#65;", 0, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateAtIndexForHexReturnsConsumedCodePointCount() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#x41;", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateAtIndexReturnsZeroWhenNotAnEntity() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("hello", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testOutOfRangeCodePointIsIgnoredNotThrown() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        // 2000000000 is a syntactically valid decimal number (parses fine as an int) but it is
        // far beyond the maximum Unicode code point (0x10FFFF). Like any other unparsable or
        // out-of-range entity, this should be left in the output untouched rather than causing
        // an unchecked exception to escape from translate().
        final String input = "Test &#2000000000; end";
        assertEquals(input, neu.translate(input));
    }

}
