/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.mutable.MutableBoolean;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RecursiveToStringStyle}.
 */
class RecursiveToStringStyleAgentTest {

    static class Job {
        String title;

        Job(final String title) {
            this.title = title;
        }
    }

    static class Person {
        String name;
        int age;
        Job job;

        Person(final String name, final int age) {
            this.name = name;
            this.age = age;
        }
    }

    private String classPrefix(final Object object) {
        return object.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(object));
    }

    // -- accept(Class) -------------------------------------------------

    @Test
    void testAcceptRejectsPrimitiveWrappers() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(Boolean.class));
        assertFalse(style.accept(Byte.class));
        assertFalse(style.accept(Character.class));
        assertFalse(style.accept(Short.class));
        assertFalse(style.accept(Integer.class));
        assertFalse(style.accept(Long.class));
        assertFalse(style.accept(Float.class));
        assertFalse(style.accept(Double.class));
    }

    @Test
    void testAcceptRejectsString() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(String.class));
    }

    @Test
    void testAcceptRejectsNumberSubclasses() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(BigDecimal.class));
        assertFalse(style.accept(BigInteger.class));
    }

    @Test
    void testAcceptRejectsAtomicBoolean() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(AtomicBoolean.class));
    }

    @Test
    void testAcceptRejectsMutableBoolean() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(MutableBoolean.class));
    }

    @Test
    void testAcceptAllowsOtherClasses() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertTrue(style.accept(Object.class));
        assertTrue(style.accept(ArrayList.class));
        assertTrue(style.accept(Person.class));
        assertTrue(style.accept(Job.class));
    }

    // -- appendDetail(StringBuffer, String, Object) --------------------

    @Test
    void testAppendDetailObjectNull() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", (Object) null);
        assertEquals("null", buffer.toString());
    }

    @Test
    void testAppendDetailObjectStringIsNotRecursed() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", "abc");
        assertEquals("abc", buffer.toString());
    }

    @Test
    void testAppendDetailObjectNumberIsNotRecursed() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", Integer.valueOf(42));
        assertEquals("42", buffer.toString());
    }

    @Test
    void testAppendDetailObjectAtomicBooleanIsNotRecursed() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final AtomicBoolean value = new AtomicBoolean(true);
        style.appendDetail(buffer, "field", value);
        assertEquals(String.valueOf(value), buffer.toString());
    }

    @Test
    void testAppendDetailObjectCustomTypeIsRecursed() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final Job job = new Job("Manager");
        style.appendDetail(buffer, "job", job);
        final String expected = ReflectionToStringBuilder.toString(job, style);
        assertEquals(expected, buffer.toString());
        assertTrue(buffer.toString().contains("title=Manager"));
        assertTrue(buffer.toString().startsWith(classPrefix(job)));
    }

    @Test
    void testAppendDetailObjectNestedCustomType() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final Person person = new Person("Stephen", 29);
        person.job = new Job("Manager");
        final String result = ReflectionToStringBuilder.toString(person, style);
        assertTrue(result.startsWith(classPrefix(person)));
        assertTrue(result.contains("name=Stephen"));
        assertTrue(result.contains("age=29"));
        assertTrue(result.contains("job=" + classPrefix(person.job) + "[title=Manager]"));
    }

    // -- appendDetail(StringBuffer, String, Collection) -----------------

    @Test
    void testAppendDetailCollectionNullThrows() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                style.appendDetail(buffer, "field", (List<?>) null);
            }
        });
    }

    @Test
    void testAppendDetailCollectionEmpty() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<String> coll = new ArrayList<String>();
        style.appendDetail(buffer, "field", coll);
        assertEquals(classPrefix(coll) + "{}", buffer.toString());
    }

    @Test
    void testAppendDetailCollectionOfPlainValues() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<String> coll = Arrays.asList("a", "b");
        style.appendDetail(buffer, "field", coll);
        assertEquals(classPrefix(coll) + "{a,b}", buffer.toString());
    }

    @Test
    void testAppendDetailCollectionOfCustomObjectsIsRecursed() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final Job job = new Job("Engineer");
        final List<Job> coll = Arrays.asList(job);
        style.appendDetail(buffer, "field", coll);
        final String expected = classPrefix(coll) + "{" + classPrefix(job) + "[title=Engineer]}";
        assertEquals(expected, buffer.toString());
    }

    // -- end-to-end usage via ReflectionToStringBuilder -----------------

    @Test
    void testToStringEndToEnd() {
        final Person person = new Person("Douglas Adams", 42);
        final String result = new ReflectionToStringBuilder(person, new RecursiveToStringStyle()).toString();
        assertEquals(classPrefix(person) + "[age=42,job=<null>,name=Douglas Adams]", result);
    }
}
