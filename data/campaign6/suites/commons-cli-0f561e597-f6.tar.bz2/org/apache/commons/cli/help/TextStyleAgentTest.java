/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class TextStyleAgentTest {

    @Test
    void testUnsetMaxWidthIsIntegerMaxValue() {
        assertEquals(Integer.MAX_VALUE, TextStyle.UNSET_MAX_WIDTH);
    }

    @Test
    void testDefaultConstantHasDocumentedDefaults() {
        final TextStyle style = TextStyle.DEFAULT;
        assertEquals(TextStyle.Alignment.LEFT, style.getAlignment());
        assertEquals(0, style.getLeftPad());
        assertEquals(0, style.getIndent());
        assertTrue(style.isScalable());
        assertEquals(0, style.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, style.getMaxWidth());
    }

    @Test
    void testBuilderDefaults() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertEquals(0, builder.getLeftPad());
        assertEquals(0, builder.getIndent());
        assertTrue(builder.isScalable());
        assertEquals(0, builder.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, builder.getMaxWidth());
    }

    @Test
    void testBuilderCreatesNewInstanceEachCall() {
        final TextStyle.Builder a = TextStyle.builder();
        final TextStyle.Builder b = TextStyle.builder();
        assertNotSame(a, b);
    }

    @Test
    void testBuilderSettersReturnThisAndAreReflectedInGetters() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setAlignment(TextStyle.Alignment.RIGHT));
        assertSame(builder, builder.setLeftPad(3));
        assertSame(builder, builder.setIndent(4));
        assertSame(builder, builder.setMinWidth(5));
        assertSame(builder, builder.setMaxWidth(20));
        assertSame(builder, builder.setScalable(false));

        assertEquals(3, builder.getLeftPad());
        assertEquals(4, builder.getIndent());
        assertEquals(5, builder.getMinWidth());
        assertEquals(20, builder.getMaxWidth());
        assertFalse(builder.isScalable());
    }

    @Test
    void testBuilderGetBuildsTextStyleWithConfiguredValues() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setLeftPad(3).setIndent(4).setMinWidth(5).setMaxWidth(20)
                .setScalable(false).get();
        assertEquals(TextStyle.Alignment.RIGHT, style.getAlignment());
        assertEquals(3, style.getLeftPad());
        assertEquals(4, style.getIndent());
        assertEquals(5, style.getMinWidth());
        assertEquals(20, style.getMaxWidth());
        assertFalse(style.isScalable());
    }

    @Test
    void testBuilderGetReturnsNewInstanceEachCall() {
        final TextStyle.Builder builder = TextStyle.builder();
        final TextStyle first = builder.get();
        final TextStyle second = builder.get();
        assertNotSame(first, second);
    }

    @Test
    void testSetTextStyleCopiesAllProperties() {
        final TextStyle source = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setLeftPad(7).setIndent(8).setMinWidth(9).setMaxWidth(40)
                .setScalable(false).get();
        final TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setTextStyle(source));
        final TextStyle copy = builder.get();

        assertEquals(source.getAlignment(), copy.getAlignment());
        assertEquals(source.getLeftPad(), copy.getLeftPad());
        assertEquals(source.getIndent(), copy.getIndent());
        assertEquals(source.getMinWidth(), copy.getMinWidth());
        assertEquals(source.getMaxWidth(), copy.getMaxWidth());
        assertEquals(source.isScalable(), copy.isScalable());
        assertNotSame(source, copy);
    }

    @Test
    void testSetTextStyleOverwritesPreviouslySetValues() {
        final TextStyle source = TextStyle.DEFAULT;
        final TextStyle.Builder builder = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setLeftPad(99).setIndent(99).setMinWidth(99)
                .setMaxWidth(99).setScalable(false);
        builder.setTextStyle(source);
        final TextStyle result = builder.get();
        assertEquals(TextStyle.Alignment.LEFT, result.getAlignment());
        assertEquals(0, result.getLeftPad());
        assertEquals(0, result.getIndent());
        assertEquals(0, result.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, result.getMaxWidth());
        assertTrue(result.isScalable());
    }

    @Test
    void testAlignmentEnumValues() {
        final TextStyle.Alignment[] values = TextStyle.Alignment.values();
        assertEquals(3, values.length);
        assertEquals(TextStyle.Alignment.LEFT, values[0]);
        assertEquals(TextStyle.Alignment.CENTER, values[1]);
        assertEquals(TextStyle.Alignment.RIGHT, values[2]);
        assertEquals(TextStyle.Alignment.LEFT, TextStyle.Alignment.valueOf("LEFT"));
    }

    @Test
    void testToStringFormatForDefault() {
        assertEquals("TextStyle{LEFT, l:0, i:0, true, min:0, max:unset}", TextStyle.DEFAULT.toString());
    }

    @Test
    void testToStringFormatForConfiguredStyle() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setLeftPad(2).setIndent(3).setMinWidth(4).setMaxWidth(50)
                .setScalable(false).get();
        assertEquals("TextStyle{RIGHT, l:2, i:3, false, min:4, max:50}", style.toString());
    }

    // --- pad() ---

    @Test
    void testPadReturnsUnchangedWhenTextLongerThanMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence result = style.pad(false, "abcdefgh");
        assertEquals("abcdefgh", result.toString());
    }

    @Test
    void testPadReturnsUnchangedWhenTextLengthEqualsMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence result = style.pad(false, "abcde");
        assertEquals("abcde", result.toString());
    }

    @Test
    void testPadLeftAlignmentWithUnsetMaxWidthAndNoIndentReturnsTextUnchanged() {
        final TextStyle style = TextStyle.DEFAULT;
        assertEquals("abc", style.pad(false, "abc").toString());
        assertEquals("abc", style.pad(true, "abc").toString());
    }

    @Test
    void testPadLeftAlignmentWithUnsetMaxWidthAddsIndentOnlyWhenRequested() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(3).get();
        assertEquals("abc", style.pad(false, "abc").toString());
        assertEquals("   abc", style.pad(true, "abc").toString());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthPadsOnTheRight() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("abc       ", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadRightAlignmentWithMaxWidthPadsOnTheLeft() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("       abc", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthAndIndentInsertsIndentBeforeText() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals("  abc     ", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthAndIndentIgnoredWhenAddIndentFalse() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("abc       ", result.toString());
        assertEquals(10, result.length());
    }

    @Test
    void testPadWithIndentLargerThanAvailableSpaceDoesNotOverflow() {
        // maxWidth - text.length() == 2, which is not greater than indent (5), so the
        // implementation falls back to padding without the indent rather than overflowing.
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(5).setIndent(5).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals(5, result.length());
        assertEquals("abc  ", result.toString());
    }

    @Test
    void testPadCenterAlignmentWithUnsetMaxWidthAndNoIndentReturnsTextUnchanged() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).get();
        assertEquals("abc", style.pad(false, "abc").toString());
    }

    @Test
    void testPadCenterAlignmentWithUnsetMaxWidthSplitsIndentAroundText() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(4).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals("  abc  ", result.toString());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthSplitsPaddingEvenly() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(11).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals("    abc    ", result.toString());
        assertEquals(11, result.length());
    }

    @Test
    void testPadCenterAlignmentWithOddPaddingPutsExtraSpaceOnRight() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abc");
        assertEquals(10, result.length());
        // total padding is 7: 3 on the left, 4 on the right
        assertEquals("   abc    ", result.toString());
    }

    @Test
    void testPadWithEmptyText() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(5).get();
        final CharSequence result = style.pad(false, "");
        assertEquals("     ", result.toString());
        assertEquals(5, result.length());
    }

    @Test
    void testPadDoesNotUseMinWidth() {
        // minWidth is stored on the style but pad() has no mechanism to pad up to it;
        // a short string with only minWidth set should come back unchanged.
        final TextStyle style = TextStyle.builder().setMinWidth(20).get();
        assertEquals("abc", style.pad(false, "abc").toString());
    }
}
