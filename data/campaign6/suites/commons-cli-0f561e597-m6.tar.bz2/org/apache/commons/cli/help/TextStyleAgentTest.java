/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class TextStyleAgentTest {

    @Test
    void testAlignmentEnum() {
        final TextStyle.Alignment[] values = TextStyle.Alignment.values();
        assertEquals(3, values.length);
        assertEquals(TextStyle.Alignment.LEFT, TextStyle.Alignment.valueOf("LEFT"));
        assertEquals(TextStyle.Alignment.CENTER, TextStyle.Alignment.valueOf("CENTER"));
        assertEquals(TextStyle.Alignment.RIGHT, TextStyle.Alignment.valueOf("RIGHT"));
    }

    @Test
    void testUnsetMaxWidthConstant() {
        assertEquals(Integer.MAX_VALUE, TextStyle.UNSET_MAX_WIDTH);
    }

    @Test
    void testBuilderDefaults() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertEquals(TextStyle.Alignment.LEFT, builder.get().getAlignment());
        assertEquals(0, builder.getLeftPad());
        assertEquals(0, builder.getIndent());
        assertEquals(0, builder.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, builder.getMaxWidth());
        assertTrue(builder.isScalable());
    }

    @Test
    void testDefaultConstant() {
        final TextStyle style = TextStyle.DEFAULT;
        assertNotNull(style);
        assertEquals(TextStyle.Alignment.LEFT, style.getAlignment());
        assertEquals(0, style.getLeftPad());
        assertEquals(0, style.getIndent());
        assertEquals(0, style.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, style.getMaxWidth());
        assertTrue(style.isScalable());
    }

    @Test
    void testBuilderSettersAndGettersFluent() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setAlignment(TextStyle.Alignment.RIGHT));
        assertSame(builder, builder.setLeftPad(3));
        assertSame(builder, builder.setIndent(4));
        assertSame(builder, builder.setMinWidth(5));
        assertSame(builder, builder.setMaxWidth(20));
        assertSame(builder, builder.setScalable(false));

        assertEquals(3, builder.getLeftPad());
        assertEquals(4, builder.getIndent());
        assertEquals(5, builder.getMinWidth());
        assertEquals(20, builder.getMaxWidth());
        assertFalse(builder.isScalable());
    }

    @Test
    void testBuilderGetBuildsTextStyleWithSpecifiedValues() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setLeftPad(3).setIndent(4).setMinWidth(5).setMaxWidth(20)
                .setScalable(false).get();
        assertEquals(TextStyle.Alignment.RIGHT, style.getAlignment());
        assertEquals(3, style.getLeftPad());
        assertEquals(4, style.getIndent());
        assertEquals(5, style.getMinWidth());
        assertEquals(20, style.getMaxWidth());
        assertFalse(style.isScalable());
    }

    @Test
    void testBuilderSetTextStyleCopiesAllProperties() {
        final TextStyle source = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setLeftPad(7).setIndent(8).setMinWidth(9).setMaxWidth(30)
                .setScalable(false).get();

        final TextStyle.Builder target = TextStyle.builder();
        assertSame(target, target.setTextStyle(source));

        assertEquals(30, target.getMaxWidth());
        assertEquals(9, target.getMinWidth());
        assertEquals(8, target.getIndent());
        assertEquals(7, target.getLeftPad());
        assertFalse(target.isScalable());

        final TextStyle copy = target.get();
        assertEquals(source.getAlignment(), copy.getAlignment());
        assertEquals(source.getLeftPad(), copy.getLeftPad());
        assertEquals(source.getIndent(), copy.getIndent());
        assertEquals(source.getMinWidth(), copy.getMinWidth());
        assertEquals(source.getMaxWidth(), copy.getMaxWidth());
        assertEquals(source.isScalable(), copy.isScalable());
    }

    @Test
    void testBuilderIsReusableAfterGet() {
        final TextStyle.Builder builder = TextStyle.builder().setLeftPad(2);
        final TextStyle first = builder.get();
        builder.setLeftPad(9);
        final TextStyle second = builder.get();

        assertEquals(2, first.getLeftPad());
        assertEquals(9, second.getLeftPad());
    }

    @Test
    void testPadTextLongerThanMaxWidthReturnedUnchanged() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence text = "abcdefgh";
        assertSame(text, style.pad(false, text));
    }

    @Test
    void testPadTextEqualToMaxWidthReturnedUnchanged() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence text = "abcde";
        assertSame(text, style.pad(false, text));
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthNoIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(4).get();
        assertEquals("abc", style.pad(false, "abc"));
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(4).get();
        assertEquals("    abc", style.pad(true, "abc"));
    }

    @Test
    void testPadRightAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setIndent(3).get();
        assertEquals("   abc", style.pad(true, "abc"));
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthAndIndentFitsWithinRemainder() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(true, "abcde");
        assertEquals("  abcde   ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthIndentLargerThanRemainderOmitsIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(5).get();
        final CharSequence result = style.pad(true, "abcdefgh");
        assertEquals("abcdefgh  ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthNoIndentRequested() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(false, "abcde");
        assertEquals("abcde     ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadRightAlignmentWithMaxWidthAndIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setMaxWidth(10).setIndent(2).get();
        final CharSequence result = style.pad(true, "abcde");
        assertEquals("     abcde", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthNoIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(5).get();
        assertEquals("abc", style.pad(false, "abc"));
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(5).get();
        final CharSequence result = style.pad(true, "abc");
        assertEquals("  abc   ", result);
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthEvenPadding() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abcd");
        assertEquals("   abcd   ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthOddPadding() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(10).get();
        final CharSequence result = style.pad(false, "abcde");
        assertEquals("  abcde   ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testToStringContainsFieldValues() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setLeftPad(2).setIndent(3).setMinWidth(4).setMaxWidth(50)
                .setScalable(false).get();
        final String text = style.toString();
        assertTrue(text.contains("RIGHT"));
        assertTrue(text.contains("l:2"));
        assertTrue(text.contains("i:3"));
        assertTrue(text.contains("false"));
        assertTrue(text.contains("min:4"));
        assertTrue(text.contains("max:50"));
    }

    @Test
    void testToStringUnsetMaxWidthShowsUnset() {
        final TextStyle style = TextStyle.DEFAULT;
        assertTrue(style.toString().contains("max:unset"));
    }
}
