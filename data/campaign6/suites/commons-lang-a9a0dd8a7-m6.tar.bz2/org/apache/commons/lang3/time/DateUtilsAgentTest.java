/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class DateUtilsAgentTest {

    private Date makeDate(final int year, final int month, final int day, final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    @Test
    void testAddDays() {
        final Date date = makeDate(2020, Calendar.JANUARY, 31, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 1);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        // original unchanged
        final Calendar origCal = Calendar.getInstance();
        origCal.setTime(date);
        assertEquals(31, origCal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddDaysNegativeAmount() {
        final Date date = makeDate(2020, Calendar.MARCH, 1, 0, 0, 0, 0);
        final Date result = DateUtils.addDays(date, -1);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(29, cal.get(Calendar.DAY_OF_MONTH)); // 2020 is a leap year
    }

    @Test
    void testAddNullDateThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addDays(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addHours(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addMinutes(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addMonths(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addSeconds(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addWeeks(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addYears(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.addMilliseconds(null, 1);
            }
        });
    }

    @Test
    void testAddWeeksAndMonthsAndYears() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar expectedWeeks = Calendar.getInstance();
        expectedWeeks.setTime(date);
        expectedWeeks.add(Calendar.WEEK_OF_YEAR, 2);
        assertEquals(expectedWeeks.getTime(), DateUtils.addWeeks(date, 2));

        final Calendar expectedMonths = Calendar.getInstance();
        expectedMonths.setTime(date);
        expectedMonths.add(Calendar.MONTH, 5);
        assertEquals(expectedMonths.getTime(), DateUtils.addMonths(date, 5));

        final Calendar expectedYears = Calendar.getInstance();
        expectedYears.setTime(date);
        expectedYears.add(Calendar.YEAR, 3);
        assertEquals(expectedYears.getTime(), DateUtils.addYears(date, 3));
    }

    @Test
    void testCeilingDate() {
        final Date date = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date ceilHour = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(ceilHour);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));

        final Date ceilMonth = DateUtils.ceiling(date, Calendar.MONTH);
        final Calendar cal2 = Calendar.getInstance();
        cal2.setTime(ceilMonth);
        assertEquals(Calendar.APRIL, cal2.get(Calendar.MONTH));
        assertEquals(1, cal2.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testCeilingAlreadyExactIsUnchanged() {
        final Date date = makeDate(2020, Calendar.JUNE, 1, 0, 0, 0, 0);
        final Date result = DateUtils.ceiling(date, Calendar.DATE);
        assertEquals(date, result);
    }

    @Test
    void testCeilingCalendarAndObjectOverloads() {
        final Date date = makeDate(2020, Calendar.JUNE, 1, 10, 30, 0, 0);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        final Calendar ceilCal = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(11, ceilCal.get(Calendar.HOUR_OF_DAY));

        final Date ceilViaObjectDate = DateUtils.ceiling((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(DateUtils.ceiling(date, Calendar.HOUR_OF_DAY), ceilViaObjectDate);

        final Date ceilViaObjectCal = DateUtils.ceiling((Object) cal, Calendar.HOUR_OF_DAY);
        assertEquals(ceilCal.getTime(), ceilViaObjectCal);
    }

    @Test
    void testCeilingNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.ceiling((Date) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.ceiling((Calendar) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.ceiling((Object) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testCeilingInvalidObjectTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.ceiling("not-a-date", Calendar.YEAR);
            }
        });
    }

    @Test
    void testCeilingUnsupportedFieldThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.ceiling(new Date(), -9999);
            }
        });
    }

    @Test
    void testGetFragmentInDays() {
        final Date date = makeDate(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(59, DateUtils.getFragmentInDays(date, Calendar.YEAR));
        assertEquals(28, DateUtils.getFragmentInDays(date, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInDays(date, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInHours() {
        final Date date = makeDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(date, Calendar.DAY_OF_YEAR));
        assertEquals(127, DateUtils.getFragmentInHours(date, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInHours(date, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInMinutesSecondsMillis() {
        final Date date = makeDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7635, DateUtils.getFragmentInMinutes(date, Calendar.MONTH));
        assertEquals(26110, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(date, Calendar.MINUTE));
    }

    @Test
    void testGetFragmentUnsupportedThrows() {
        final Date date = new Date();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays(date, -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays(Calendar.getInstance(), -1);
            }
        });
    }

    @Test
    void testGetFragmentNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testIsSameDay() {
        final Date date1 = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date date2 = makeDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date date3 = makeDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(date1, date2));
        assertFalse(DateUtils.isSameDay(date1, date3));

        final Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        final Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
    }

    @Test
    void testIsSameDayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameDay((Date) null, new Date());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameDay(new Date(), (Date) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameDay((Calendar) null, Calendar.getInstance());
            }
        });
    }

    @Test
    void testIsSameInstant() {
        final Date date1 = new Date(1000L);
        final Date date2 = new Date(1000L);
        final Date date3 = new Date(2000L);
        assertTrue(DateUtils.isSameInstant(date1, date2));
        assertFalse(DateUtils.isSameInstant(date1, date3));

        final Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        final Calendar cal2 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        cal2.setTime(date2);
        assertTrue(DateUtils.isSameInstant(cal1, cal2));
    }

    @Test
    void testIsSameInstantNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameInstant((Date) null, new Date());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            }
        });
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar cal1 = Calendar.getInstance();
        cal1.set(2008, Calendar.JUNE, 1, 8, 15, 14);
        cal1.set(Calendar.MILLISECOND, 231);
        final Calendar cal2 = (Calendar) cal1.clone();
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));

        cal2.add(Calendar.MILLISECOND, 1);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal2));
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarClass() {
        final Calendar cal1 = Calendar.getInstance();
        cal1.set(2008, Calendar.JUNE, 1, 8, 15, 14);
        cal1.set(Calendar.MILLISECOND, 231);
        final Calendar gregorian = new java.util.GregorianCalendar();
        gregorian.setTime(cal1.getTime());
        // Same values, but ensure the same-class branch works as expected.
        assertTrue(DateUtils.isSameLocalTime(cal1, gregorian) || cal1.getClass() != gregorian.getClass());
    }

    @Test
    void testIsSameLocalTimeNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameLocalTime(null, Calendar.getInstance());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.isSameLocalTime(Calendar.getInstance(), null);
            }
        });
    }

    @Test
    void testIterator() throws ParseException {
        final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        final Date focus = fmt.parse("2002-07-04"); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            final Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertNotNull(first);
        assertNotNull(last);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertTrue(count > 0);
    }

    @Test
    void testIteratorExhaustedThrowsNoSuchElement() throws ParseException {
        final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        final Date focus = fmt.parse("2002-07-04");
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final Iterator<Calendar> it = DateUtils.iterator(Calendar.getInstance(), DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    void testIteratorInvalidRangeStyleThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.iterator(Calendar.getInstance(), 9999);
            }
        });
    }

    @Test
    void testIteratorNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorInvalidObjectTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.iterator("not-a-date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorObjectOverloadDispatches() {
        final Calendar cal = Calendar.getInstance();
        final Iterator<?> it = DateUtils.iterator((Object) cal, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    @Test
    void testParseDate() throws ParseException {
        final Date result = DateUtils.parseDate("2020-06-15", "yyyy-MM-dd");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateWithLocale() throws ParseException {
        final Date result = DateUtils.parseDate("2020-06-15", Locale.US, "yyyy-MM-dd");
        assertNotNull(result);
    }

    @Test
    void testParseDateTriesMultiplePatterns() throws ParseException {
        final Date result = DateUtils.parseDate("15.06.2020", "yyyy-MM-dd", "dd.MM.yyyy");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNoMatchingPatternThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNoPatternsThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2020-06-15");
            }
        });
    }

    @Test
    void testParseDateNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2020-06-15", (String[]) null);
            }
        });
    }

    @Test
    void testParseDateLeniency() throws ParseException {
        // lenient parsing allows an out-of-range day to roll over
        final Date result = DateUtils.parseDate("2020-02-942", "yyyy-MM-dd");
        assertNotNull(result);
    }

    @Test
    void testParseDateStrictlyRejectsLeniencyRollover() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("2020-02-942", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateStrictlyValid() throws ParseException {
        final Date result = DateUtils.parseDateStrictly("2020-06-15", "yyyy-MM-dd");
        assertNotNull(result);
    }

    @Test
    void testParseDateStrictlyNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testRoundDate() {
        final Date date = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date rounded = DateUtils.round(date, Calendar.HOUR_OF_DAY);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(rounded);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test
    void testRoundDateDownRoundsToSameValue() {
        final Date date = makeDate(2002, Calendar.MARCH, 28, 13, 20, 1, 231);
        final Date rounded = DateUtils.round(date, Calendar.HOUR_OF_DAY);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(rounded);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundCalendarAndObjectOverloads() {
        final Date date = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        final Calendar roundedCal = DateUtils.round(cal, Calendar.HOUR_OF_DAY);
        assertEquals(14, roundedCal.get(Calendar.HOUR_OF_DAY));

        final Date roundedViaObject = DateUtils.round((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(DateUtils.round(date, Calendar.HOUR_OF_DAY), roundedViaObject);

        final Date roundedViaObjectCal = DateUtils.round((Object) cal, Calendar.HOUR_OF_DAY);
        assertEquals(roundedCal.getTime(), roundedViaObjectCal);
    }

    @Test
    void testRoundNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.round((Date) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.round((Calendar) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.round((Object) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testRoundInvalidObjectTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.round(42, Calendar.YEAR);
            }
        });
    }

    @Test
    void testRoundUnsupportedFieldThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.round(new Date(), -9999);
            }
        });
    }

    @Test
    void testRoundYearOver280MillionThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.round(cal, Calendar.MONTH);
            }
        });
    }

    @Test
    void testSetDaysHoursMinutesSecondsMillisYears() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date withDay = DateUtils.setDays(date, 15);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(withDay);
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));

        final Date withHour = DateUtils.setHours(date, 5);
        cal.setTime(withHour);
        assertEquals(5, cal.get(Calendar.HOUR_OF_DAY));

        final Date withMinute = DateUtils.setMinutes(date, 45);
        cal.setTime(withMinute);
        assertEquals(45, cal.get(Calendar.MINUTE));

        final Date withSecond = DateUtils.setSeconds(date, 30);
        cal.setTime(withSecond);
        assertEquals(30, cal.get(Calendar.SECOND));

        final Date withMillis = DateUtils.setMilliseconds(date, 500);
        cal.setTime(withMillis);
        assertEquals(500, cal.get(Calendar.MILLISECOND));

        final Date withMonth = DateUtils.setMonths(date, 5);
        cal.setTime(withMonth);
        assertEquals(5, cal.get(Calendar.MONTH));

        final Date withYear = DateUtils.setYears(date, 1999);
        cal.setTime(withYear);
        assertEquals(1999, cal.get(Calendar.YEAR));
    }

    @Test
    void testSetDaysOutOfRangeThrows() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setDays(date, 32);
            }
        });
    }

    @Test
    void testSetHoursOutOfRangeThrows() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setHours(date, 24);
            }
        });
    }

    @Test
    void testSetMinutesOutOfRangeThrows() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setMinutes(date, 60);
            }
        });
    }

    @Test
    void testSetSecondsOutOfRangeThrows() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setSeconds(date, 60);
            }
        });
    }

    @Test
    void testSetMillisecondsOutOfRangeThrows() {
        final Date date = makeDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setMilliseconds(date, 1000);
            }
        });
    }

    @Test
    void testSetNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setDays(null, 1);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.setHours(null, 1);
            }
        });
    }

    @Test
    void testToCalendar() {
        final Date date = new Date();
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = new Date();
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(date, cal.getTime());
        assertEquals(tz, cal.getTimeZone());
    }

    @Test
    void testToCalendarWithTimeZoneNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.toCalendar(new Date(), null);
            }
        });
    }

    @Test
    void testToLocalDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, tz);
        assertEquals(1970, ldt.getYear());
        assertEquals(1, ldt.getMonthValue());
        assertEquals(1, ldt.getDayOfMonth());
        assertEquals(0, ldt.getHour());
    }

    @Test
    void testToLocalDateTimeDefaultTimeZone() {
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date);
        assertNotNull(ldt);
    }

    @Test
    void testToOffsetDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, tz);
        assertEquals(1970, odt.getYear());
    }

    @Test
    void testToOffsetDateTimeDefaultTimeZone() {
        final Date date = new Date(0L);
        assertNotNull(DateUtils.toOffsetDateTime(date));
    }

    @Test
    void testToZonedDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, tz);
        assertEquals(1970, zdt.getYear());
    }

    @Test
    void testToZonedDateTimeDefaultTimeZone() {
        final Date date = new Date(0L);
        assertNotNull(DateUtils.toZonedDateTime(date));
    }

    @Test
    void testTruncateDate() {
        final Date date = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date truncated = DateUtils.truncate(date, Calendar.HOUR_OF_DAY);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(truncated);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));

        final Date truncatedMonth = DateUtils.truncate(date, Calendar.MONTH);
        cal.setTime(truncatedMonth);
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    @Test
    void testTruncateCalendarAndObjectOverloads() {
        final Date date = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        final Calendar truncatedCal = DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
        assertEquals(13, truncatedCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, truncatedCal.get(Calendar.MINUTE));

        final Date truncatedViaObject = DateUtils.truncate((Object) date, Calendar.HOUR_OF_DAY);
        assertEquals(DateUtils.truncate(date, Calendar.HOUR_OF_DAY), truncatedViaObject);

        final Date truncatedViaObjectCal = DateUtils.truncate((Object) cal, Calendar.HOUR_OF_DAY);
        assertEquals(truncatedCal.getTime(), truncatedViaObjectCal);
    }

    @Test
    void testTruncateNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncate((Date) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncate((Calendar) null, Calendar.YEAR);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncate((Object) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testTruncateInvalidObjectTypeThrows() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncate(3.14, Calendar.YEAR);
            }
        });
    }

    @Test
    void testTruncateUnsupportedFieldThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncate(new Date(), -9999);
            }
        });
    }

    @Test
    void testTruncatedCompareTo() {
        final Date date1 = makeDate(2020, Calendar.JUNE, 1, 10, 0, 0, 0);
        final Date date2 = makeDate(2020, Calendar.JUNE, 1, 18, 0, 0, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(date1, date2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(date1, date2, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(date2, date1, Calendar.HOUR_OF_DAY) > 0);

        final Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        final Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        assertEquals(0, DateUtils.truncatedCompareTo(cal1, cal2, Calendar.DATE));
    }

    @Test
    void testTruncatedEquals() {
        final Date date1 = makeDate(2020, Calendar.JUNE, 1, 10, 0, 0, 0);
        final Date date2 = makeDate(2020, Calendar.JUNE, 1, 18, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(date1, date2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(date1, date2, Calendar.HOUR_OF_DAY));

        final Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        final Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        assertTrue(DateUtils.truncatedEquals(cal1, cal2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(cal1, cal2, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncatedCompareToNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncatedCompareTo((Date) null, new Date(), Calendar.DATE);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.truncatedCompareTo(new Date(), (Date) null, Calendar.DATE);
            }
        });
    }

    @Test
    void testConstantsValues() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    void testPublicConstructorIsUsable() {
        assertNotNull(new DateUtils());
    }
}
