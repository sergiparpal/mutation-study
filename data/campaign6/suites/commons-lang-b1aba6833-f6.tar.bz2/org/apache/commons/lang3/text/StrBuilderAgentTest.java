/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
@SuppressWarnings("deprecation")
class StrBuilderAgentTest {

    /** A Readable that is neither a Reader nor a CharBuffer, to exercise the generic branch of readFrom. */
    private static final class ChunkedReadable implements Readable {
        private final char[] data;
        private int pos;
        private final int chunk;

        ChunkedReadable(final String s, final int chunk) {
            this.data = s.toCharArray();
            this.chunk = chunk;
        }

        @Override
        public int read(final CharBuffer cb) {
            if (pos >= data.length) {
                return -1;
            }
            final int n = Math.min(Math.min(cb.remaining(), data.length - pos), chunk);
            cb.put(data, pos, n);
            pos += n;
            return n;
        }
    }

    // ---- constructors ----

    @Test
    void testConstructorDefault() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    void testConstructorCapacityNonPositiveDefaultsTo32() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
    }

    @Test
    void testConstructorCapacityPositive() {
        assertEquals(10, new StrBuilder(10).capacity());
    }

    @Test
    void testConstructorFromNullString() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    void testConstructorFromString() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(3, sb.length());
        assertEquals(35, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    // ---- append ----

    @Test
    void testAppendCharArrayNullCallsAppendNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());
        sb.setNullText("NULL");
        sb.append((char[]) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testAppendCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = {'a', 'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, -1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 4, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 1, 3));
        sb.append(chars, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    void testAppendCharSequenceDelegatesByRuntimeType() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) new StringBuilder("sb"));
        sb.append((CharSequence) new StringBuffer("buf"));
        sb.append((CharSequence) new StrBuilder("strb"));
        sb.append((CharSequence) "plain");
        assertEquals("sbbufstrbplain", sb.toString());
    }

    @Test
    void testAppendCharSequenceNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals("", sb.toString());
    }

    @Test
    void testAppendCharBufferArrayBackedAndWrapped() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello".toCharArray()));
        assertEquals("hello", sb.toString());
        // CharBuffer.wrap(CharSequence) is not array-backed: exercises the toString() fallback branch.
        final CharBuffer nonArray = CharBuffer.wrap((CharSequence) "world");
        sb.append(nonArray);
        assertEquals("helloworld", sb.toString());
    }

    @Test
    void testAppendCharBufferRangeNonArrayBacked() {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer nonArray = CharBuffer.wrap((CharSequence) "abcdef");
        sb.append(nonArray, 1, 3);
        assertEquals("bcd", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(CharBuffer.wrap((CharSequence) "abc"), -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(CharBuffer.wrap((CharSequence) "abc"), 0, 5));
    }

    @Test
    void testAppendObjectNullAndNonNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
        sb.append(Integer.valueOf(42));
        assertEquals("42", sb.toString());
    }

    @Test
    void testAppendPrimitives() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append('!').append(1).append(2L).append(1.5f).append(2.5d);
        assertEquals("true!121.52.5", sb.toString());
    }

    @Test
    void testAppendFormat() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%d-%s", 1, "x");
        assertEquals("1-x", sb.toString());
    }

    @Test
    void testAppendStrBuilderRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder src = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(src, -1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(src, 0, 100));
        sb.append(src, 1, 3);
        assertEquals("bcd", sb.toString());
        sb.append((StrBuilder) null);
        assertEquals("bcd", sb.toString());
    }

    // ---- appendln / appendNewLine ----

    @Test
    void testAppendNewLineDefaultUsesSystemLineSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendln("x");
        assertEquals("x" + System.lineSeparator(), sb.toString());
    }

    @Test
    void testAppendNewLineCustom() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<NL>");
        assertEquals("<NL>", sb.getNewLineText());
        sb.appendln("x");
        assertEquals("x<NL>", sb.toString());
        sb.setNewLineText(null);
        assertNotNull(sb); // setter returns this via chaining elsewhere; just ensure no exception
    }

    // ---- fixed width padding ----

    @Test
    void testAppendFixedWidthPadLeftTruncatesLeftSide() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("123456", 3, '0');
        // Javadoc: "If the formatted value is larger than the length, the left-hand side is lost" -> keep rightmost 3 chars.
        assertEquals("456", sb.toString());
    }

    @Test
    void testAppendFixedWidthPadLeftPadsWhenShorter() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("7", 4, '0');
        assertEquals("0007", sb.toString());
    }

    @Test
    void testAppendFixedWidthPadLeftNonPositiveWidthNoEffect() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abc", 0, '0');
        sb.appendFixedWidthPadLeft("abc", -3, '0');
        assertEquals("", sb.toString());
    }

    @Test
    void testAppendFixedWidthPadLeftObjectNullUsesNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NA");
        sb.appendFixedWidthPadLeft((Object) null, 4, '-');
        assertEquals("--NA", sb.toString());
    }

    @Test
    void testAppendFixedWidthPadRightTruncatesRightSide() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("123456", 3, '0');
        assertEquals("123", sb.toString());
    }

    @Test
    void testAppendFixedWidthPadRightPadsWhenShorter() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("7", 4, '0');
        assertEquals("7000", sb.toString());
    }

    // ---- padding ----

    @Test
    void testAppendPaddingNegativeNoEffectZeroNoop() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendPadding(-3, '*');
        assertEquals("x", sb.toString());
        sb.appendPadding(0, '*');
        assertEquals("x", sb.toString());
        sb.appendPadding(3, '*');
        assertEquals("x***", sb.toString());
    }

    // ---- separators ----

    @Test
    void testAppendSeparatorCharOnlyWhenNonEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(',');
        assertEquals("a,", sb.toString());
    }

    @Test
    void testAppendSeparatorCharStandardOrDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.append("a");
        sb.appendSeparator(',', ';');
        assertEquals(";a,", sb.toString());
    }

    @Test
    void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    void testAppendSeparatorStringNullHasNoEffect() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    void testAppendSeparatorStringLoopIndexNullSeparatorNoEffect() {
        final StrBuilder sb = new StrBuilder();
        sb.append("x");
        sb.appendSeparator((String) null, 1);
        assertEquals("x", sb.toString());
        sb.appendSeparator(",", 1);
        assertEquals("x,", sb.toString());
        sb.appendSeparator(",", 0);
        assertEquals("x,", sb.toString());
    }

    @Test
    void testAppendSeparatorStringStandardOrDefaultNullMeansNoSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", null);
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(" and", " where");
        assertEquals("a and", sb.toString());
    }

    // ---- appendAll / appendWithSeparators ----

    @Test
    void testAppendAllIterableIteratorArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) null);
        assertEquals("", sb.toString());
        sb.appendAll(Arrays.asList("a", "b", "c"));
        assertEquals("abc", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendAll((Iterator<?>) null);
        assertEquals("", sb2.toString());
        sb2.appendAll(Arrays.asList(1, 2).iterator());
        assertEquals("12", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        sb3.appendAll();
        assertEquals("", sb3.toString());
        sb3.appendAll("x", "y");
        assertEquals("xy", sb3.toString());
    }

    @Test
    void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("", sb.toString());
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb2.toString());
    }

    @Test
    void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Iterator<?>) null, ",");
        assertEquals("", sb.toString());
        final List<String> list = Arrays.asList("a", "b");
        sb.appendWithSeparators(list.iterator(), "-");
        assertEquals("a-b", sb.toString());
    }

    @Test
    void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Object[]) null, ",");
        assertEquals("", sb.toString());
        sb.appendWithSeparators(new Object[0], ",");
        assertEquals("", sb.toString());
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, "-");
        assertEquals("a-b-c", sb.toString());
    }

    // ---- appendTo ----

    @Test
    void testAppendToWriterStringBuilderStringBufferCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");

        final StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.toString());

        final StringBuilder targetSb = new StringBuilder();
        sb.appendTo(targetSb);
        assertEquals("hello", targetSb.toString());

        final StringBuffer targetBuf = new StringBuffer();
        sb.appendTo(targetBuf);
        assertEquals("hello", targetBuf.toString());

        final CharBuffer targetCb = CharBuffer.allocate(10);
        sb.appendTo(targetCb);
        targetCb.flip();
        assertEquals("hello", targetCb.toString());
    }

    @Test
    void testAppendToGenericAppendableFallback() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StrBuilder target = new StrBuilder();
        // StrBuilder is an Appendable that is not Writer/StringBuilder/StringBuffer/CharBuffer,
        // so appendTo must fall back to appendable.append(this).
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    // ---- views: asReader / asWriter / asTokenizer ----

    @Test
    void testAsReaderReadSingleCharsAndEof() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        assertTrue(reader.ready());
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertFalse(reader.ready());
        assertEquals(-1, reader.read());
    }

    @Test
    void testAsReaderBulkReadAndMarkReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final char[] buf = new char[4];
        assertTrue(reader.markSupported());
        reader.mark(0);
        final int n1 = reader.read(buf, 0, 4);
        assertEquals(4, n1);
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd'}, buf);
        final int n2 = reader.read(buf, 0, 4);
        assertEquals(2, n2); // only "ef" left, even though 4 requested
        assertEquals(-1, reader.read(buf, 0, 4));
        reader.reset();
        assertEquals('a', reader.read());
    }

    @Test
    void testAsReaderReadBoundsAndSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final char[] buf = new char[4];
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, -1, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, 0, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, 5, 2));
        assertEquals(0, reader.read(buf, 0, 0));
        final long skipped = reader.skip(2);
        assertEquals(2, skipped);
        assertEquals('c', reader.read());
    }

    @Test
    void testAsReaderSharesBufferWithBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("a");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals(-1, reader.read());
        sb.append("bc");
        assertTrue(reader.ready());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
    }

    @Test
    void testAsWriterWritesIntoBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write('a');
        writer.write("bc");
        writer.write("wxyz", 1, 2);
        writer.write(new char[] {'1', '2', '3'});
        writer.write(new char[] {'7', '8', '9'}, 1, 2);
        writer.flush();
        writer.close();
        assertEquals("abcxy12389", sb.toString());
    }

    @Test
    void testAsTokenizerTokenizesBuilderContent() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokenizer.getTokenArray());
    }

    // ---- build / capacity ----

    @Test
    void testBuildReturnsToString() {
        final StrBuilder sb = new StrBuilder("hi");
        assertEquals(sb.toString(), sb.build());
    }

    @Test
    void testCapacityEnsureCapacityMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(3); // smaller than current capacity: no-op
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(20);
        assertTrue(sb.capacity() >= 20);
        sb.append("hi");
        sb.minimizeCapacity();
        assertEquals(2, sb.capacity());
        assertEquals("hi", sb.toString());
    }

    // ---- charAt / setCharAt / deleteCharAt ----

    @Test
    void testCharAtBounds() {
        final StrBuilder sb = new StrBuilder("ab");
        assertEquals('a', sb.charAt(0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(2));
    }

    @Test
    void testSetCharAtBounds() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setCharAt(1, 'z');
        assertEquals("az", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(2, 'x'));
    }

    @Test
    void testDeleteCharAtBounds() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(2));
    }

    // ---- clear ----

    @Test
    void testClear() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.clear();
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    // ---- contains ----

    @Test
    void testContainsCharStringMatcher() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
        assertTrue(sb.contains("bc"));
        assertFalse(sb.contains("zz"));
        assertTrue(sb.contains(StrMatcher.charMatcher('a')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    // ---- delete ----

    @Test
    void testDeleteRangeBasic() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    void testDeleteEndIndexTooLargeClampedToEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(4, 1000);
        assertEquals("abcd", sb.toString());
    }

    @Test
    void testDeleteInvalidRangeThrows() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(4, 2));
    }

    @Test
    void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("aabaaacdef");
        sb.deleteAll('a');
        assertEquals("bcdef", sb.toString());
    }

    @Test
    void testDeleteAllStringNullNoAction() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll((String) null);
        assertEquals("abcabc", sb.toString());
        sb.deleteAll("bc");
        assertEquals("aa", sb.toString());
    }

    @Test
    void testDeleteFirstCharAndString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('b');
        assertEquals("acabc", sb.toString());
        final StrBuilder sb2 = new StrBuilder("abcabc");
        sb2.deleteFirst("bc");
        assertEquals("aabc", sb2.toString());
        sb2.deleteFirst((String) null);
        assertEquals("aabc", sb2.toString());
    }

    @Test
    void testDeleteFirstAndAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1a2a3");
        sb.deleteFirst(StrMatcher.charMatcher('a'));
        assertEquals("1a2a3", sb.toString());
        sb.deleteAll(StrMatcher.charMatcher('a'));
        assertEquals("123", sb.toString());
    }

    // ---- starts/ends with ----

    @Test
    void testStartsWithAndEndsWithNullAndEmpty() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.startsWith(null));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.startsWith(""));
        assertTrue(sb.endsWith(""));
        assertTrue(sb.startsWith("ab"));
        assertFalse(sb.startsWith("bc"));
        assertTrue(sb.endsWith("bc"));
        assertFalse(sb.endsWith("ab"));
        assertFalse(sb.startsWith("abcd"));
        assertFalse(sb.endsWith("abcd"));
    }

    // ---- equals / equalsIgnoreCase / hashCode ----

    @Test
    void testEqualsObjectHandlesNullAndWrongType() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.equals(null));
        assertFalse(sb.equals("abc"));
        assertTrue(sb.equals(sb));
    }

    @Test
    void testEqualsStrBuilderOverloadNullSafe() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.equals((StrBuilder) null));
        assertTrue(sb.equals(new StrBuilder("abc")));
        assertFalse(sb.equals(new StrBuilder("abd")));
        assertFalse(sb.equals(new StrBuilder("ab")));
    }

    @Test
    void testEqualsIgnoreCaseMatchesCaseInsensitively() {
        final StrBuilder sb = new StrBuilder("AbC");
        assertTrue(sb.equalsIgnoreCase(new StrBuilder("abc")));
        assertFalse(sb.equalsIgnoreCase(new StrBuilder("abd")));
        assertTrue(sb.equalsIgnoreCase(sb));
    }

    @Test
    void testEqualsIgnoreCaseNullReturnsFalseAsDocumented() {
        // Javadoc: "@param other The object to check, null returns false."
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.equalsIgnoreCase(null));
    }

    @Test
    void testHashCodeConsistentWithEqualContent() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    // ---- getChars ----

    @Test
    void testGetCharsDestinationArrayNullOrTooSmallCreatesNewArray() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result1 = sb.getChars(null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result1);

        final char[] tooSmall = new char[1];
        final char[] result2 = sb.getChars(tooSmall);
        assertNotSame(tooSmall, result2);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result2);

        final char[] bigEnough = new char[5];
        final char[] result3 = sb.getChars(bigEnough);
        assertSame(bigEnough, result3);
        assertEquals('a', bigEnough[0]);
        assertEquals('b', bigEnough[1]);
        assertEquals('c', bigEnough[2]);
    }

    @Test
    void testGetCharsRangeBoundsInvalid() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[10];
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 3, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 100, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(3, 1, dest, 0));
        sb.getChars(1, 3, dest, 0);
        assertEquals('b', dest[0]);
        assertEquals('c', dest[1]);
    }

    // ---- nullText ----

    @Test
    void testGetSetNullTextEmptyBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(null, sb.getNullText());
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.setNullText("");
        assertEquals(null, sb.getNullText());
    }

    // ---- indexOf ----

    @Test
    void testIndexOfCharWithStartIndex() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('z'));
        assertEquals(-1, sb.indexOf('a', 100));
        assertEquals(0, sb.indexOf('a', -5));
    }

    @Test
    void testIndexOfStringNullAndStartIndex() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(-1, sb.indexOf((String) null));
        assertEquals(0, sb.indexOf("abc"));
        assertEquals(3, sb.indexOf("abc", 1));
        assertEquals(-1, sb.indexOf("xyz"));
    }

    @Test
    void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf(StrMatcher.charMatcher('b')));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
        assertEquals(4, sb.indexOf(StrMatcher.charMatcher('b'), 2));
    }

    // ---- insert ----

    @Test
    void testInsertBoundaryInvalidIndexThrows() {
        final StrBuilder sb = new StrBuilder("ab");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, "x"));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(3, "x"));
        sb.insert(2, "x"); // insert at end is valid
        assertEquals("abx", sb.toString());
    }

    @Test
    void testInsertVariousTypes() {
        final StrBuilder sb = new StrBuilder("[]");
        sb.insert(1, true);
        assertEquals("[true]", sb.toString());

        final StrBuilder sb2 = new StrBuilder("[]");
        sb2.insert(1, 'x');
        assertEquals("[x]", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("[]");
        sb3.insert(1, new char[] {'a', 'b'});
        assertEquals("[ab]", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("[]");
        sb4.insert(1, new char[] {'a', 'b', 'c'}, 1, 2);
        assertEquals("[bc]", sb4.toString());

        final StrBuilder sb5 = new StrBuilder("[]");
        sb5.insert(1, 42);
        assertEquals("[42]", sb5.toString());

        final StrBuilder sb6 = new StrBuilder("[]");
        sb6.setNullText("NULL");
        sb6.insert(1, (Object) null);
        assertEquals("[NULL]", sb6.toString());

        final StrBuilder sb7 = new StrBuilder("[]");
        sb7.insert(1, (String) null);
        assertEquals("[]", sb7.toString());
    }

    @Test
    void testInsertCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder("[]");
        final char[] chars = {'a', 'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, 0, 10));
    }

    // ---- isEmpty / isNotEmpty / length / size ----

    @Test
    void testIsEmptyIsNotEmptyLengthSize() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        assertEquals(0, sb.length());
        assertEquals(0, sb.size());
        sb.append("abc");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
        assertEquals(3, sb.length());
        assertEquals(3, sb.size());
    }

    // ---- lastIndexOf ----

    @Test
    void testLastIndexOfCharStringMatcher() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf('a'));
        assertEquals(0, sb.lastIndexOf('a', 2));
        assertEquals(-1, sb.lastIndexOf('z'));
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
        assertEquals(4, sb.lastIndexOf(StrMatcher.charMatcher('b')));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    // ---- leftString / midString / rightString ----

    @Test
    void testLeftStringEdgeCases() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.leftString(-1));
        assertEquals("", sb.leftString(0));
        assertEquals("abc", sb.leftString(3));
        assertEquals("abcdef", sb.leftString(100));
    }

    @Test
    void testRightStringEdgeCases() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.rightString(-1));
        assertEquals("", sb.rightString(0));
        assertEquals("def", sb.rightString(3));
        assertEquals("abcdef", sb.rightString(100));
    }

    @Test
    void testMidStringEdgeCases() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.midString(0, -1));
        assertEquals("", sb.midString(0, 0));
        assertEquals("abc", sb.midString(-5, 3)); // negative index treated as zero
        assertEquals("cde", sb.midString(2, 3));
        assertEquals("def", sb.midString(3, 100)); // insufficient chars: return as much as possible
        assertEquals("", sb.midString(100, 3)); // index beyond size
    }

    // ---- readFrom ----

    @Test
    void testReadFromReaderAppendsAllContent() throws IOException {
        final StrBuilder sb = new StrBuilder("pre-");
        final int read = sb.readFrom(new java.io.StringReader("abc"));
        assertEquals(3, read);
        assertEquals("pre-abc", sb.toString());
    }

    @Test
    void testReadFromCharBufferAppendsRemaining() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("hello world".toCharArray());
        cb.position(6); // only "world" remains
        final int read = sb.readFrom(cb);
        assertEquals(5, read);
        assertEquals("world", sb.toString());
    }

    @Test
    void testReadFromGenericReadableAppendsAllContentAcrossMultipleReads() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new ChunkedReadable("abcdefghij", 3));
        assertEquals(10, read);
        assertEquals("abcdefghij", sb.toString());
    }

    // ---- replace ----

    @Test
    void testReplaceRangeGrowShrinkEqualLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ"); // grow: removes 2 chars, inserts 3
        assertEquals("aXYZdef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcdef");
        sb2.replace(1, 5, "Z"); // shrink: removes 4 chars, inserts 1
        assertEquals("aZf", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abcdef");
        sb3.replace(1, 3, "XY"); // same length
        assertEquals("aXYdef", sb3.toString());
    }

    @Test
    void testReplaceRangeNullMeansDelete() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    void testReplaceRangeEndIndexClampedAndInvalidStart() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(4, 1000, "Z");
        assertEquals("abcdZ", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.replace(-1, 2, "Z"));
    }

    @Test
    void testReplaceAllCharAndString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceAll('a', 'X');
        assertEquals("XbXbXb", sb.toString());

        final StrBuilder sb2 = new StrBuilder("one two one two");
        sb2.replaceAll("one", "1");
        assertEquals("1 two 1 two", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("aaa");
        sb3.replaceAll("a", null); // null replacement treated as empty string
        assertEquals("", sb3.toString());
    }

    @Test
    void testReplaceFirstCharAndString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceFirst('a', 'X');
        assertEquals("Xbabab", sb.toString());

        final StrBuilder sb2 = new StrBuilder("one two one two");
        sb2.replaceFirst("one", "1");
        assertEquals("1 two one two", sb2.toString());
    }

    @Test
    void testReplaceAllAndFirstWithMatcher() {
        final StrBuilder sb = new StrBuilder("a1a2a3");
        sb.replaceFirst(StrMatcher.charMatcher('a'), "_");
        assertEquals("_1a2a3", sb.toString());

        final StrBuilder sb2 = new StrBuilder("a1a2a3");
        sb2.replaceAll(StrMatcher.charMatcher('a'), "_");
        assertEquals("_1_2_3", sb2.toString());
    }

    // ---- reverse ----

    @Test
    void testReverseSimple() {
        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    @Test
    void testReverseEmptyAndSingleChar() {
        final StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
        final StrBuilder sb2 = new StrBuilder("a");
        sb2.reverse();
        assertEquals("a", sb2.toString());
    }

    @Test
    void testReverseKeepsSurrogatePairsIntact() {
        // U+1F600 (grinning face) is a single code point encoded as a surrogate pair in UTF-16.
        final String emoji = new String(Character.toChars(0x1F600));
        final StrBuilder sb = new StrBuilder("a" + emoji + "b");
        sb.reverse();
        assertEquals("b" + emoji + "a", sb.toString());
        // The reversed string must still decode as a single supplementary code point, not two lone surrogates.
        assertEquals(1, sb.toString().substring(1, 3).codePointCount(0, 2));
    }

    // ---- setLength ----

    @Test
    void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    void testSetLengthShrinkAndGrow() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());

        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('a', sb.charAt(0));
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));
    }

    // ---- subSequence ----

    @Test
    void testSubSequenceBoundsAndContent() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.subSequence(1, 4).toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(4, 2));
    }

    // ---- substring ----

    @Test
    void testSubstringOneArgAndTwoArgAndClamping() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
        assertEquals("cd", sb.substring(2, 4));
        assertEquals("cdef", sb.substring(2, 1000)); // endIndex too large treated as end of string
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(4, 2));
    }

    // ---- toCharArray ----

    @Test
    void testToCharArrayEmptyAndNonEmpty() {
        final StrBuilder sbEmpty = new StrBuilder();
        assertArrayEquals(new char[0], sbEmpty.toCharArray());

        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd', 'e', 'f'}, sb.toCharArray());
        assertArrayEquals(new char[] {'c', 'd'}, sb.toCharArray(2, 4));
        assertArrayEquals(new char[] {'c', 'd', 'e', 'f'}, sb.toCharArray(2, 1000));
        assertArrayEquals(new char[0], sb.toCharArray(2, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.toCharArray(-1, 2));
    }

    // ---- toString / toStringBuffer / toStringBuilder ----

    @Test
    void testToStringIsIndependentCopy() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    void testToStringBufferAndToStringBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.toStringBuffer().toString());
        assertEquals("abc", sb.toStringBuilder().toString());
    }

    // ---- trim ----

    @Test
    void testTrimRemovesLeadingAndTrailingWhitespace() {
        final StrBuilder sb = new StrBuilder("  hello world  ");
        sb.trim();
        assertEquals("hello world", sb.toString());
    }

    @Test
    void testTrimAllWhitespaceBecomesEmpty() {
        final StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    void testTrimNoWhitespaceUnchanged() {
        final StrBuilder sb = new StrBuilder("hello");
        sb.trim();
        assertEquals("hello", sb.toString());
    }
}
