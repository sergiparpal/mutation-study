/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.Collection;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ThreadUtils}.
 */
public class ThreadUtilsAgentTest {

    /**
     * A thread that blocks on a latch until released, so it stays "active" (and
     * enumerable) for the duration of a test.
     */
    private static final class ParkedThread {
        private final CountDownLatch startedLatch = new CountDownLatch(1);
        private final CountDownLatch releaseLatch = new CountDownLatch(1);
        private final Thread thread;

        ParkedThread(final ThreadGroup group, final String name) {
            thread = new Thread(group, new Runnable() {
                @Override
                public void run() {
                    startedLatch.countDown();
                    try {
                        releaseLatch.await();
                    } catch (final InterruptedException ignore) {
                        // exit
                    }
                }
            }, name);
        }

        void start() throws InterruptedException {
            thread.start();
            startedLatch.await();
        }

        void release() throws InterruptedException {
            releaseLatch.countDown();
            thread.join(5000);
        }

        Thread get() {
            return thread;
        }
    }

    private ThreadGroup testGroup;

    @AfterEach
    public void tearDown() {
        if (testGroup != null && testGroup.activeCount() == 0) {
            try {
                testGroup.destroy();
            } catch (final IllegalThreadStateException ignore) {
                // still has threads, leave it
            }
        }
    }

    private ThreadGroup newTestGroup() {
        testGroup = new ThreadGroup("ThreadUtilsAgentTest-group-" + UUID.randomUUID());
        return testGroup;
    }

    // --- getSystemThreadGroup / getAllThreadGroups / getAllThreads ---

    @Test
    public void testGetSystemThreadGroupHasNoParent() {
        final ThreadGroup systemGroup = ThreadUtils.getSystemThreadGroup();
        assertNotNull(systemGroup);
        assertNull(systemGroup.getParent());
    }

    @Test
    public void testGetAllThreadsContainsCurrentThread() {
        final Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertTrue(threads.contains(Thread.currentThread()));
    }

    @Test
    public void testGetAllThreadsIsUnmodifiable() {
        final Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                threads.add(Thread.currentThread());
            }
        });
    }

    @Test
    public void testGetAllThreadGroupsExcludesSystemGroup() {
        final Collection<ThreadGroup> groups = ThreadUtils.getAllThreadGroups();
        assertFalse(groups.contains(ThreadUtils.getSystemThreadGroup()));
    }

    @Test
    public void testGetAllThreadGroupsContainsCreatedGroup() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final ParkedThread parked = new ParkedThread(group, "irrelevant-" + UUID.randomUUID());
        parked.start();
        try {
            final Collection<ThreadGroup> groups = ThreadUtils.getAllThreadGroups();
            assertTrue(groups.contains(group));
        } finally {
            parked.release();
        }
    }

    // --- findThreadById(long) ---

    @Test
    public void testFindThreadByIdZeroThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadById(0);
            }
        });
    }

    @Test
    public void testFindThreadByIdNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadById(-1);
            }
        });
    }

    @Test
    public void testFindThreadByIdFindsCurrentThread() {
        final Thread current = Thread.currentThread();
        final Thread found = ThreadUtils.findThreadById(current.getId());
        assertEquals(current, found);
    }

    @Test
    public void testFindThreadByIdNotFoundReturnsNull() {
        // A thread id that is exceedingly unlikely to be in use.
        final Thread found = ThreadUtils.findThreadById(Long.MAX_VALUE - 1);
        assertNull(found);
    }

    // --- findThreadById(long, String) ---

    @Test
    public void testFindThreadByIdAndGroupNameNullGroupNameThrowsNpe() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadById(id, (String) null);
            }
        });
    }

    @Test
    public void testFindThreadByIdAndGroupNameMatch() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final ParkedThread parked = new ParkedThread(group, "name-" + UUID.randomUUID());
        parked.start();
        try {
            final Thread found = ThreadUtils.findThreadById(parked.get().getId(), group.getName());
            assertEquals(parked.get(), found);
        } finally {
            parked.release();
        }
    }

    @Test
    public void testFindThreadByIdAndGroupNameMismatchReturnsNull() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final ParkedThread parked = new ParkedThread(group, "name-" + UUID.randomUUID());
        parked.start();
        try {
            final Thread found = ThreadUtils.findThreadById(parked.get().getId(), "no-such-group-" + UUID.randomUUID());
            assertNull(found);
        } finally {
            parked.release();
        }
    }

    // --- findThreadById(long, ThreadGroup) ---

    @Test
    public void testFindThreadByIdAndGroupNullGroupThrowsNpe() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadById(id, (ThreadGroup) null);
            }
        });
    }

    @Test
    public void testFindThreadByIdAndGroupMatch() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final ParkedThread parked = new ParkedThread(group, "name-" + UUID.randomUUID());
        parked.start();
        try {
            final Thread found = ThreadUtils.findThreadById(parked.get().getId(), group);
            assertEquals(parked.get(), found);
        } finally {
            parked.release();
        }
    }

    @Test
    public void testFindThreadByIdAndGroupMismatchReturnsNull() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final ThreadGroup otherGroup = new ThreadGroup("ThreadUtilsAgentTest-other-" + UUID.randomUUID());
        final ParkedThread parked = new ParkedThread(group, "name-" + UUID.randomUUID());
        parked.start();
        try {
            final Thread found = ThreadUtils.findThreadById(parked.get().getId(), otherGroup);
            assertNull(found);
        } finally {
            parked.release();
            otherGroup.destroy();
        }
    }

    // --- findThreads(Predicate<Thread>) / findThreads(ThreadGroup, boolean, Predicate) ---

    @Test
    public void testFindThreadsNullPredicateThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreads((Predicate<Thread>) null);
            }
        });
    }

    @Test
    public void testFindThreadsWithGroupNullGroupThrowsNpe() {
        final Predicate<Thread> alwaysTrue = new Predicate<Thread>() {
            @Override
            public boolean test(final Thread t) {
                return true;
            }
        };
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreads(null, true, alwaysTrue);
            }
        });
    }

    @Test
    public void testFindThreadsWithGroupNullPredicateThrowsNpe() {
        final ThreadGroup group = newTestGroup();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreads(group, true, (Predicate<Thread>) null);
            }
        });
    }

    @Test
    public void testFindThreadsMatchesByPredicate() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(group, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreads(new Predicate<Thread>() {
                @Override
                public boolean test(final Thread t) {
                    return t != null && name.equals(t.getName());
                }
            });
            assertEquals(1, found.size());
            assertTrue(found.contains(parked.get()));
        } finally {
            parked.release();
        }
    }

    @Test
    public void testFindThreadsNoMatchReturnsEmpty() {
        final Collection<Thread> found = ThreadUtils.findThreads(new Predicate<Thread>() {
            @Override
            public boolean test(final Thread t) {
                return false;
            }
        });
        assertTrue(found.isEmpty());
    }

    @Test
    public void testFindThreadsResultIsUnmodifiable() {
        final Collection<Thread> found = ThreadUtils.findThreads(new Predicate<Thread>() {
            @Override
            public boolean test(final Thread t) {
                return true;
            }
        });
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                found.clear();
            }
        });
    }

    @Test
    public void testFindThreadsNonRecursiveExcludesSubgroup() throws InterruptedException {
        final ThreadGroup parent = newTestGroup();
        final ThreadGroup child = new ThreadGroup(parent, "child-" + UUID.randomUUID());
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(child, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreads(parent, false, new Predicate<Thread>() {
                @Override
                public boolean test(final Thread t) {
                    return true;
                }
            });
            assertFalse(found.contains(parked.get()));
            final Collection<Thread> foundRecursive = ThreadUtils.findThreads(parent, true, new Predicate<Thread>() {
                @Override
                public boolean test(final Thread t) {
                    return true;
                }
            });
            assertTrue(foundRecursive.contains(parked.get()));
        } finally {
            parked.release();
            child.destroy();
        }
    }

    // --- findThreadsByName ---

    @Test
    public void testFindThreadsByNameNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadsByName(null);
            }
        });
    }

    @Test
    public void testFindThreadsByNameMatchesCurrentThread() {
        final Thread current = Thread.currentThread();
        final Collection<Thread> found = ThreadUtils.findThreadsByName(current.getName());
        assertTrue(found.contains(current));
    }

    @Test
    public void testFindThreadsByNameNoMatchReturnsEmpty() {
        final Collection<Thread> found = ThreadUtils.findThreadsByName("no-such-thread-" + UUID.randomUUID());
        assertTrue(found.isEmpty());
    }

    @Test
    public void testFindThreadsByNameAndGroupNameNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadsByName(null, "someGroup");
            }
        });
    }

    @Test
    public void testFindThreadsByNameAndGroupNameNullGroupNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadsByName("someThread", (String) null);
            }
        });
    }

    @Test
    public void testFindThreadsByNameAndGroupNameMatch() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(group, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreadsByName(name, group.getName());
            assertEquals(1, found.size());
            assertTrue(found.contains(parked.get()));
        } finally {
            parked.release();
        }
    }

    @Test
    public void testFindThreadsByNameAndGroupNameMismatchReturnsEmpty() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(group, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreadsByName(name, "no-such-group-" + UUID.randomUUID());
            assertTrue(found.isEmpty());
        } finally {
            parked.release();
        }
    }

    @Test
    public void testFindThreadsByNameAndGroupNullGroupThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadsByName("someThread", (ThreadGroup) null);
            }
        });
    }

    @Test
    public void testFindThreadsByNameAndGroupMatch() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(group, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreadsByName(name, group);
            assertEquals(1, found.size());
            assertTrue(found.contains(parked.get()));
        } finally {
            parked.release();
        }
    }

    // --- findThreadGroups ---

    @Test
    public void testFindThreadGroupsNullPredicateThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadGroups((Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    public void testFindThreadGroupsWithGroupNullGroupThrowsNpe() {
        final Predicate<ThreadGroup> alwaysTrue = new Predicate<ThreadGroup>() {
            @Override
            public boolean test(final ThreadGroup g) {
                return true;
            }
        };
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadGroups(null, true, alwaysTrue);
            }
        });
    }

    @Test
    public void testFindThreadGroupsWithGroupNullPredicateThrowsNpe() {
        final ThreadGroup group = newTestGroup();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadGroups(group, true, (Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    public void testFindThreadGroupsMatchesByPredicate() {
        final ThreadGroup group = newTestGroup();
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(new Predicate<ThreadGroup>() {
            @Override
            public boolean test(final ThreadGroup g) {
                return g == group;
            }
        });
        assertEquals(1, found.size());
        assertTrue(found.contains(group));
    }

    @Test
    public void testFindThreadGroupsResultIsUnmodifiable() {
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(new Predicate<ThreadGroup>() {
            @Override
            public boolean test(final ThreadGroup g) {
                return true;
            }
        });
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                found.clear();
            }
        });
    }

    @Test
    public void testFindThreadGroupsNonRecursiveExcludesGrandchildSubgroup() {
        final ThreadGroup parent = newTestGroup();
        final ThreadGroup child = new ThreadGroup(parent, "child-" + UUID.randomUUID());
        final ThreadGroup grandchild = new ThreadGroup(child, "grandchild-" + UUID.randomUUID());
        try {
            final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(parent, false, new Predicate<ThreadGroup>() {
                @Override
                public boolean test(final ThreadGroup g) {
                    return true;
                }
            });
            assertTrue(found.contains(child));
            assertFalse(found.contains(grandchild));
            final Collection<ThreadGroup> foundRecursive = ThreadUtils.findThreadGroups(parent, true, new Predicate<ThreadGroup>() {
                @Override
                public boolean test(final ThreadGroup g) {
                    return true;
                }
            });
            assertTrue(foundRecursive.contains(child));
            assertTrue(foundRecursive.contains(grandchild));
        } finally {
            grandchild.destroy();
            child.destroy();
        }
    }

    // --- findThreadGroupsByName ---

    @Test
    public void testFindThreadGroupsByNameNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ThreadUtils.findThreadGroupsByName(null);
            }
        });
    }

    @Test
    public void testFindThreadGroupsByNameMatch() {
        final ThreadGroup group = newTestGroup();
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName(group.getName());
        assertEquals(1, found.size());
        assertTrue(found.contains(group));
    }

    @Test
    public void testFindThreadGroupsByNameNoMatchReturnsEmpty() {
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName("no-such-group-" + UUID.randomUUID());
        assertTrue(found.isEmpty());
    }

    // --- ThreadIdPredicate ---

    @Test
    public void testThreadIdPredicateZeroThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new ThreadUtils.ThreadIdPredicate(0);
            }
        });
    }

    @Test
    public void testThreadIdPredicateNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new ThreadUtils.ThreadIdPredicate(-5);
            }
        });
    }

    @Test
    public void testThreadIdPredicateMatchesOnlyGivenId() {
        final Thread current = Thread.currentThread();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(current.getId());
        assertTrue(predicate.test(current));
        assertFalse(predicate.test(new Thread()));
    }

    @Test
    public void testThreadIdPredicateNullThreadReturnsFalse() {
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(1);
        assertFalse(predicate.test(null));
    }

    // --- NamePredicate ---

    @Test
    public void testNamePredicateNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new ThreadUtils.NamePredicate(null);
            }
        });
    }

    @Test
    public void testNamePredicateMatchesThreadByName() {
        final String name = "name-" + UUID.randomUUID();
        final Thread thread = new Thread(name);
        final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(name);
        assertTrue(predicate.test(thread));
        assertFalse(predicate.test(new Thread("different-" + UUID.randomUUID())));
        assertFalse(predicate.test((Thread) null));
    }

    @Test
    public void testNamePredicateMatchesThreadGroupByName() {
        final String name = "group-" + UUID.randomUUID();
        final ThreadGroup group = new ThreadGroup(name);
        try {
            final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(name);
            assertTrue(predicate.test(group));
            assertFalse(predicate.test(new ThreadGroup("different-" + UUID.randomUUID())));
            assertFalse(predicate.test((ThreadGroup) null));
        } finally {
            group.destroy();
        }
    }

    // --- ALWAYS_TRUE_PREDICATE ---

    @Test
    public void testAlwaysTruePredicateThread() {
        final ThreadUtils.ThreadPredicate predicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(predicate.test(Thread.currentThread()));
        assertTrue(predicate.test(null));
    }

    @Test
    public void testAlwaysTruePredicateThreadGroup() {
        final ThreadUtils.ThreadGroupPredicate predicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(predicate.test(ThreadUtils.getSystemThreadGroup()));
        assertTrue(predicate.test(null));
    }

    // --- deprecated overloads delegate correctly ---

    @Test
    public void testDeprecatedFindThreadsThreadPredicateDelegates() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(group, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreads(new ThreadUtils.NamePredicate(name));
            assertEquals(1, found.size());
            assertTrue(found.contains(parked.get()));
        } finally {
            parked.release();
        }
    }

    @Test
    public void testDeprecatedFindThreadsWithGroupThreadPredicateDelegates() throws InterruptedException {
        final ThreadGroup group = newTestGroup();
        final String name = "name-" + UUID.randomUUID();
        final ParkedThread parked = new ParkedThread(group, name);
        parked.start();
        try {
            final Collection<Thread> found = ThreadUtils.findThreads(group, true, new ThreadUtils.NamePredicate(name));
            assertEquals(1, found.size());
            assertTrue(found.contains(parked.get()));
        } finally {
            parked.release();
        }
    }

    @Test
    public void testDeprecatedFindThreadGroupsThreadGroupPredicateDelegates() {
        final ThreadGroup group = newTestGroup();
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(new ThreadUtils.NamePredicate(group.getName()));
        assertEquals(1, found.size());
        assertTrue(found.contains(group));
    }

    @Test
    public void testDeprecatedFindThreadGroupsWithGroupThreadGroupPredicateDelegates() {
        final ThreadGroup parent = newTestGroup();
        final ThreadGroup child = new ThreadGroup(parent, "child-" + UUID.randomUUID());
        try {
            final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(parent, true, new ThreadUtils.NamePredicate(child.getName()));
            assertEquals(1, found.size());
            assertTrue(found.contains(child));
        } finally {
            child.destroy();
        }
    }

    // --- join ---

    @Test
    public void testJoinWaitsForThreadToFinish() throws InterruptedException {
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(50);
                } catch (final InterruptedException ignore) {
                    // ignore
                }
            }
        });
        thread.start();
        ThreadUtils.join(thread, Duration.ofSeconds(5));
        assertFalse(thread.isAlive());
    }

    @Test
    public void testJoinOnAlreadyFinishedThreadReturnsImmediately() throws InterruptedException {
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                // no-op, finishes immediately
            }
        });
        thread.start();
        thread.join();
        final long start = System.nanoTime();
        ThreadUtils.join(thread, Duration.ofSeconds(5));
        final long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        assertFalse(thread.isAlive());
        assertTrue(elapsedMillis < 2000, "join on a finished thread should return promptly, took " + elapsedMillis + "ms");
    }

    // --- sleep / sleepQuietly ---

    @Test
    public void testSleepSleepsAtLeastTheGivenDuration() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ofMillis(100));
        final long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        assertTrue(elapsedMillis >= 90, "slept only " + elapsedMillis + "ms");
    }

    @Test
    public void testSleepZeroDurationReturnsPromptly() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ZERO);
        final long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        assertTrue(elapsedMillis < 2000, "took " + elapsedMillis + "ms");
    }

    @Test
    public void testSleepPropagatesInterruptedException() throws InterruptedException {
        final Thread[] holder = new Thread[1];
        final boolean[] interrupted = new boolean[1];
        final CountDownLatch startedLatch = new CountDownLatch(1);
        final CountDownLatch doneLatch = new CountDownLatch(1);
        final Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                startedLatch.countDown();
                try {
                    ThreadUtils.sleep(Duration.ofSeconds(10));
                } catch (final InterruptedException expected) {
                    interrupted[0] = true;
                } finally {
                    doneLatch.countDown();
                }
            }
        });
        holder[0] = worker;
        worker.start();
        startedLatch.await();
        Thread.sleep(50);
        worker.interrupt();
        final boolean completed = doneLatch.await(5, TimeUnit.SECONDS);
        assertTrue(completed, "worker thread did not finish in time");
        assertTrue(interrupted[0], "sleep() should throw InterruptedException when interrupted");
    }

    @Test
    public void testSleepQuietlyDoesNotThrowWhenInterrupted() throws InterruptedException {
        final boolean[] threwException = new boolean[1];
        final CountDownLatch startedLatch = new CountDownLatch(1);
        final CountDownLatch doneLatch = new CountDownLatch(1);
        final Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                startedLatch.countDown();
                try {
                    ThreadUtils.sleepQuietly(Duration.ofSeconds(10));
                } catch (final RuntimeException unexpected) {
                    threwException[0] = true;
                } finally {
                    doneLatch.countDown();
                }
            }
        });
        worker.start();
        startedLatch.await();
        final long start = System.nanoTime();
        Thread.sleep(50);
        worker.interrupt();
        final boolean completed = doneLatch.await(5, TimeUnit.SECONDS);
        final long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        assertTrue(completed, "worker thread did not finish in time");
        assertFalse(threwException[0], "sleepQuietly() must not propagate InterruptedException");
        assertTrue(elapsedMillis < 9000, "sleepQuietly() should have returned early after interrupt, took " + elapsedMillis + "ms");
    }

    @Test
    public void testSleepQuietlySleepsAtLeastTheGivenDurationWhenUninterrupted() {
        final long start = System.nanoTime();
        ThreadUtils.sleepQuietly(Duration.ofMillis(100));
        final long elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);
        assertTrue(elapsedMillis >= 90, "slept only " + elapsedMillis + "ms");
    }

    // --- constructor ---

    @Test
    public void testConstructorIsPublic() {
        final ThreadUtils instance = new ThreadUtils();
        assertNotNull(instance);
    }
}
