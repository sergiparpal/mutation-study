/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link BitField}.
 */
class BitFieldAgentTest {

    private static final BitField BF_MULTI = new BitField(0x3F80);
    private static final BitField BF_SIMPLE = new BitField(0x3F80);
    private static final BitField BF_SINGLE = new BitField(0x4000);
    private static final BitField BF_ZERO = new BitField(0);

    @Test
    void testClearInt() {
        assertEquals(0xFFFFC07F, BF_MULTI.clear(-1));
        assertEquals(0xFFFFBFFF, BF_SINGLE.clear(-1));
        assertEquals(0xFFFFFFFF, BF_ZERO.clear(-1));
        assertEquals(0, BF_MULTI.clear(0x3F80));
    }

    @Test
    void testClearByte() {
        final BitField field = new BitField(0x40); // bit 6
        assertEquals((byte) 0xBF, field.clearByte((byte) 0xFF));
        assertEquals(0, field.clearByte((byte) 0x40));
    }

    @Test
    void testClearShort() {
        assertEquals((short) 0xC07F, BF_MULTI.clearShort((short) -1));
        assertEquals((short) 0xBFFF, BF_SINGLE.clearShort((short) -1));
        assertEquals((short) 0xFFFF, BF_ZERO.clearShort((short) -1));
    }

    @Test
    void testGetRawValue() {
        assertEquals(0x3F80, BF_MULTI.getRawValue(-1));
        assertEquals(0, BF_MULTI.getRawValue(0));
        assertEquals(0x4000, BF_SINGLE.getRawValue(-1));
        assertEquals(0, BF_ZERO.getRawValue(-1));
        assertEquals(0x1200, new BitField(0xFF00).getRawValue(0x1234));
    }

    @Test
    void testGetShortRawValue() {
        assertEquals((short) 0x3F80, BF_MULTI.getShortRawValue((short) -1));
        assertEquals((short) 0, BF_MULTI.getShortRawValue((short) 0));
        assertEquals((short) 0x4000, BF_SINGLE.getShortRawValue((short) -1));
    }

    @Test
    void testGetShortValue() {
        final BitField field = new BitField(0xFF00);
        assertEquals((short) 0x12, field.getShortValue((short) 0x1234));
    }

    @Test
    void testGetValue() {
        final BitField field = new BitField(0xFF00); // bits 8-15
        assertEquals(0x12, field.getValue(0x1234));
        assertEquals(0, field.getValue(0x00FF));
    }

    @Test
    void testGetValueNegativeAfterShift() {
        // high-bit mask: shifting right should sign-extend because getValue uses >> not >>>
        final BitField field = new BitField(0x80000000);
        assertEquals(-1, field.getValue(0xFFFFFFFF));
        assertEquals(-1, field.getValue(0x80000000));
    }

    @Test
    void testIsAllSet() {
        final BitField field = new BitField(0x3000); // bits 12-13
        assertTrue(field.isAllSet(0x3000));
        assertFalse(field.isAllSet(0x1000));
        assertTrue(field.isAllSet(-1));
    }

    @Test
    void testIsSet() {
        final BitField field = new BitField(0x3000);
        assertTrue(field.isSet(0x3000));
        assertTrue(field.isSet(0x1000));
        assertFalse(field.isSet(0x0FFF));
    }

    @Test
    void testSetInt() {
        final BitField field = new BitField(0x1000);
        assertEquals(0x1000, field.set(0));
        assertEquals(-1, new BitField(0xFFFFFFFF).set(0));
        assertEquals(0x1234 | 0x1000, field.set(0x1234));
    }

    @Test
    void testSetBoolean() {
        final BitField field = new BitField(0x1000);
        assertEquals(0x1000, field.setBoolean(0, true));
        assertEquals(0, field.setBoolean(0x1000, false));
    }

    @Test
    void testSetByte() {
        final BitField field = new BitField(0x40);
        assertEquals((byte) 0x40, field.setByte((byte) 0));
    }

    @Test
    void testSetByteBoolean() {
        final BitField field = new BitField(0x40);
        assertEquals((byte) 0x40, field.setByteBoolean((byte) 0, true));
        assertEquals((byte) 0, field.setByteBoolean((byte) 0x40, false));
    }

    @Test
    void testSetShort() {
        final BitField field = new BitField(0x4000);
        assertEquals((short) 0x4000, field.setShort((short) 0));
    }

    @Test
    void testSetShortBoolean() {
        final BitField field = new BitField(0x4000);
        assertEquals((short) 0x4000, field.setShortBoolean((short) 0, true));
        assertEquals((short) 0, field.setShortBoolean((short) 0x4000, false));
    }

    @Test
    void testSetShortValue() {
        final BitField field = new BitField(0xFF00);
        assertEquals((short) 0x3400, field.setShortValue((short) 0x1200, (short) 0x34));
    }

    @Test
    void testSetValue() {
        final BitField field = new BitField(0xFF00); // bits 8-15
        assertEquals(0x3400, field.setValue(0x1200, 0x34));
        // value bits beyond the mask width must be discarded, not spill into other bits
        assertEquals(0x3400, field.setValue(0x1200, 0x10034));
    }

    @Test
    void testSetValueMultipleBits() {
        final BitField field = new BitField(0xF0F0);
        final int holder = 0xAAAA;
        final int newValue = 0x55;
        final int result = field.setValue(holder, newValue);
        assertEquals(holder & ~0xF0F0 | newValue << 4 & 0xF0F0, result);
    }

    @Test
    void testZeroMaskIsNoOp() {
        assertEquals(1234, BF_ZERO.set(1234));
        assertEquals(1234, BF_ZERO.clear(1234));
        assertEquals(0, BF_ZERO.getValue(1234));
        assertFalse(BF_ZERO.isSet(1234));
        // all-zero-mask "isAllSet" is vacuously true since (holder & 0) == 0 always
        assertTrue(BF_ZERO.isAllSet(1234));
    }

    @Test
    void testShiftCountForSingleHighBit() {
        final BitField field = new BitField(0x80000000); // highest bit of int
        assertEquals(-1, field.getValue(0x80000000));
        assertTrue(field.isSet(0x80000000));
        assertEquals(0x80000000, field.set(0));
        assertEquals(0, field.clear(0x80000000));
    }

    @Test
    void testConsistencyBetweenMultiInstances() {
        // BF_MULTI and BF_SIMPLE share the same mask, must behave identically
        final int holder = 0x1234;
        assertEquals(BF_MULTI.getValue(holder), BF_SIMPLE.getValue(holder));
        assertEquals(BF_MULTI.set(holder), BF_SIMPLE.set(holder));
        assertEquals(BF_MULTI.clear(holder), BF_SIMPLE.clear(holder));
    }
}
