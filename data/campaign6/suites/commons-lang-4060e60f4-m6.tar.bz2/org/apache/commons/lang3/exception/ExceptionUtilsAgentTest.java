/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExceptionUtils}.
 */
class ExceptionUtilsAgentTest {

    /**
     * A throwable whose cause is a mutable field instead of the real Throwable cause, so that
     * recursive cause chains can be built without going through {@link Throwable#initCause}.
     */
    private static class MutableCauseException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        private Throwable myCause;

        MutableCauseException(final String message) {
            super(message);
        }

        void setMyCause(final Throwable cause) {
            this.myCause = cause;
        }

        @Override
        public synchronized Throwable getCause() {
            return myCause;
        }
    }

    /**
     * Mimics pre-JDK-1.4 wrapper exceptions that expose their wrapped exception through a
     * custom accessor method instead of overriding {@link Throwable#getCause()}.
     */
    private static class LegacyWrapperException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable target;

        LegacyWrapperException(final String message, final Throwable target) {
            super(message);
            this.target = target;
        }

        public Throwable getTargetException() {
            return target;
        }
    }

    private static class CustomCauseMethodException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable wrapped;

        CustomCauseMethodException(final String message, final Throwable wrapped) {
            super(message);
            this.wrapped = wrapped;
        }

        public Throwable getMyWrapped() {
            return wrapped;
        }
    }

    /**
     * Has both a real {@link Throwable} cause and a legacy accessor exposing a different
     * throwable, to verify that the real cause takes priority.
     */
    private static class DualCauseException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable legacyTarget;

        DualCauseException(final String message, final Throwable realCause, final Throwable legacyTarget) {
            super(message, realCause);
            this.legacyTarget = legacyTarget;
        }

        public Throwable getTargetException() {
            return legacyTarget;
        }
    }

    @Test
    void testAsRuntimeException() {
        final IOException io = new IOException("asRuntimeException-io");
        try {
            ExceptionUtils.<RuntimeException>asRuntimeException(io);
            fail("Expected the original checked exception to be thrown");
        } catch (final Throwable t) {
            assertSame(io, t);
        }
    }

    @Test
    void testForEach() {
        final NumberFormatException c3 = new NumberFormatException("c3");
        final IllegalArgumentException c2 = new IllegalArgumentException("c2", c3);
        final RuntimeException c1 = new RuntimeException("c1", c2);
        final List<Throwable> collected = new ArrayList<>();
        ExceptionUtils.forEach(c1, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                collected.add(t);
            }
        });
        assertEquals(Arrays.asList(c1, c2, c3), collected);
    }

    @Test
    void testForEachNullThrowable() {
        final List<Throwable> collected = new ArrayList<>();
        ExceptionUtils.forEach(null, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                collected.add(t);
            }
        });
        assertTrue(collected.isEmpty());
    }

    @Test
    void testGetCauseNullThrowable() {
        assertNull(ExceptionUtils.getCause(null));
        assertNull(ExceptionUtils.getCause(null, new String[] {"getTargetException"}));
    }

    @Test
    void testGetCauseRealCauseTakesPriority() {
        final IOException real = new IOException("real-cause");
        final IllegalStateException legacy = new IllegalStateException("legacy-target");
        final DualCauseException wrapper = new DualCauseException("outer", real, legacy);
        // The real Throwable.getCause() must win over the legacy getTargetException() accessor.
        assertSame(real, ExceptionUtils.getCause(wrapper));
    }

    @Test
    void testGetCauseUsesLegacyAccessorMethod() {
        final IllegalStateException target = new IllegalStateException("legacy-target");
        final LegacyWrapperException wrapper = new LegacyWrapperException("outer", target);
        assertSame(target, ExceptionUtils.getCause(wrapper));
    }

    @Test
    void testGetCauseWithCustomMethodNames() {
        final IllegalStateException wrapped = new IllegalStateException("custom-wrapped");
        final CustomCauseMethodException ex = new CustomCauseMethodException("outer", wrapped);
        assertNull(ExceptionUtils.getCause(ex));
        assertSame(wrapped, ExceptionUtils.getCause(ex, new String[] {"getMyWrapped"}));
    }

    @Test
    void testGetCauseWithMethodNamesIgnoresNullEntries() {
        final IllegalStateException target = new IllegalStateException("ignore-null-entry");
        final LegacyWrapperException wrapper = new LegacyWrapperException("outer", target);
        assertSame(target, ExceptionUtils.getCause(wrapper, new String[] {null, "getTargetException"}));
    }

    @Test
    void testGetCauseWithMethodNamesNoMatch() {
        final LegacyWrapperException wrapper = new LegacyWrapperException("outer", new IllegalStateException("x"));
        assertNull(ExceptionUtils.getCause(wrapper, new String[] {"noSuchMethodHere"}));
    }

    @Test
    void testGetDefaultCauseMethodNames() {
        final String[] names1 = ExceptionUtils.getDefaultCauseMethodNames();
        assertTrue(names1.length > 0);
        assertTrue(Arrays.asList(names1).contains("getCause"));
        assertTrue(Arrays.asList(names1).contains("getTargetException"));
        // Returned array must be a clone: mutating it must not affect later calls.
        names1[0] = "MODIFIED";
        final String[] names2 = ExceptionUtils.getDefaultCauseMethodNames();
        assertEquals("getCause", names2[0]);
    }

    @Test
    void testGetMessageNullThrowable() {
        assertEquals("", ExceptionUtils.getMessage((Throwable) null));
    }

    @Test
    void testGetMessageWithMessage() {
        assertEquals("IllegalStateException: boom", ExceptionUtils.getMessage(new IllegalStateException("boom")));
    }

    @Test
    void testGetMessageWithoutMessage() {
        assertEquals("RuntimeException: ", ExceptionUtils.getMessage(new RuntimeException()));
    }

    @Test
    void testGetRootCauseNullThrowable() {
        assertNull(ExceptionUtils.getRootCause(null));
    }

    @Test
    void testGetRootCauseNoCause() {
        final RuntimeException single = new RuntimeException("alone");
        assertSame(single, ExceptionUtils.getRootCause(single));
    }

    @Test
    void testGetRootCauseChain() {
        final NumberFormatException root = new NumberFormatException("root");
        final IllegalArgumentException middle = new IllegalArgumentException("middle", root);
        final RuntimeException top = new RuntimeException("top", middle);
        assertSame(root, ExceptionUtils.getRootCause(top));
    }

    @Test
    void testGetRootCauseHandlesCycle() {
        final MutableCauseException a = new MutableCauseException("a");
        final MutableCauseException b = new MutableCauseException("b");
        a.setMyCause(b);
        b.setMyCause(a);
        // The cycle is detected: the element right before the repeat is the "root".
        assertSame(b, ExceptionUtils.getRootCause(a));
    }

    @Test
    void testGetRootCauseMessageNullThrowable() {
        assertEquals("", ExceptionUtils.getRootCauseMessage(null));
    }

    @Test
    void testGetRootCauseMessage() {
        final NumberFormatException root = new NumberFormatException("bad-number");
        final RuntimeException top = new RuntimeException("top", root);
        assertEquals("NumberFormatException: bad-number", ExceptionUtils.getRootCauseMessage(top));
    }

    @Test
    void testGetRootCauseMessageNoCause() {
        final RuntimeException single = new RuntimeException("solo");
        assertEquals("RuntimeException: solo", ExceptionUtils.getRootCauseMessage(single));
    }

    private static Throwable[] buildWrappedPair(final List<Throwable> outChain) {
        Throwable inner = null;
        Throwable outer = null;
        try {
            try {
                throw new IllegalArgumentException("inner-cause");
            } catch (final IllegalArgumentException e) {
                inner = e;
                throw new IllegalStateException("outer-wrap", e);
            }
        } catch (final IllegalStateException e) {
            outer = e;
        }
        outChain.add(inner);
        outChain.add(outer);
        return new Throwable[] {inner, outer};
    }

    @Test
    void testGetRootCauseStackTraceListNullThrowable() {
        assertTrue(ExceptionUtils.getRootCauseStackTraceList(null).isEmpty());
    }

    @Test
    void testGetRootCauseStackTraceList() {
        final List<Throwable> chain = new ArrayList<>();
        final Throwable[] pair = buildWrappedPair(chain);
        final Throwable inner = pair[0];
        final Throwable outer = pair[1];
        final List<String> frames = ExceptionUtils.getRootCauseStackTraceList(outer);
        assertFalse(frames.isEmpty());
        assertEquals(inner.toString(), frames.get(0));
        assertTrue(frames.contains(ExceptionUtils.WRAPPED_MARKER + outer.toString()));
    }

    @Test
    void testGetRootCauseStackTraceArrayNullThrowable() {
        assertEquals(0, ExceptionUtils.getRootCauseStackTrace(null).length);
    }

    @Test
    void testGetRootCauseStackTraceArray() {
        final List<Throwable> chain = new ArrayList<>();
        final Throwable[] pair = buildWrappedPair(chain);
        final Throwable inner = pair[0];
        final String[] frames = ExceptionUtils.getRootCauseStackTrace(pair[1]);
        assertTrue(frames.length > 0);
        assertEquals(inner.toString(), frames[0]);
    }

    @Test
    void testGetStackFramesStringNullSafeOnEmpty() {
        assertEquals(0, ExceptionUtils.getStackFrames("").length);
    }

    @Test
    void testGetStackFramesThrowableNull() {
        assertArrayEquals(new String[0], ExceptionUtils.getStackFrames((Throwable) null));
    }

    @Test
    void testGetStackFramesThrowable() {
        final Throwable t = new RuntimeException("frames");
        final String[] frames = ExceptionUtils.getStackFrames(t);
        assertTrue(frames.length > 0);
        assertTrue(frames[0].contains("RuntimeException"));
    }

    @Test
    void testGetStackTraceNullThrowable() {
        assertEquals("", ExceptionUtils.getStackTrace(null));
    }

    @Test
    void testGetStackTrace() {
        Throwable t;
        try {
            throw new RuntimeException("stack-trace-boom");
        } catch (final RuntimeException e) {
            t = e;
        }
        final String trace = ExceptionUtils.getStackTrace(t);
        assertTrue(trace.contains("RuntimeException"));
        assertTrue(trace.contains("stack-trace-boom"));
    }

    @Test
    void testGetThrowableCount() {
        assertEquals(0, ExceptionUtils.getThrowableCount(null));
        assertEquals(1, ExceptionUtils.getThrowableCount(new RuntimeException("solo")));
        final RuntimeException top = new RuntimeException("top", new IllegalStateException("mid", new IOException("bottom")));
        assertEquals(3, ExceptionUtils.getThrowableCount(top));
    }

    @Test
    void testGetThrowableListNullThrowable() {
        assertTrue(ExceptionUtils.getThrowableList(null).isEmpty());
    }

    @Test
    void testGetThrowableListChain() {
        final IOException bottom = new IOException("bottom");
        final IllegalStateException mid = new IllegalStateException("mid", bottom);
        final RuntimeException top = new RuntimeException("top", mid);
        assertEquals(Arrays.asList(top, mid, bottom), ExceptionUtils.getThrowableList(top));
    }

    @Test
    void testGetThrowableListDetectsCycleByIdentity() {
        final MutableCauseException a = new MutableCauseException("a");
        final MutableCauseException b = new MutableCauseException("b");
        a.setMyCause(b);
        b.setMyCause(a);
        final List<Throwable> list = ExceptionUtils.getThrowableList(a);
        assertEquals(2, list.size());
        assertSame(a, list.get(0));
        assertSame(b, list.get(1));
    }

    @Test
    void testGetThrowablesNullThrowable() {
        assertEquals(0, ExceptionUtils.getThrowables(null).length);
    }

    @Test
    void testGetThrowablesChain() {
        final IOException bottom = new IOException("bottom");
        final RuntimeException top = new RuntimeException("top", bottom);
        final Throwable[] throwables = ExceptionUtils.getThrowables(top);
        assertArrayEquals(new Throwable[] {top, bottom}, throwables);
    }

    @Test
    void testHasCauseWithUndeclaredThrowableException() {
        final IOException cause = new IOException("wrapped");
        final UndeclaredThrowableException ute = new UndeclaredThrowableException(cause);
        assertTrue(ExceptionUtils.hasCause(ute, IOException.class));
        assertFalse(ExceptionUtils.hasCause(ute, IllegalStateException.class));
    }

    @Test
    void testHasCauseDirect() {
        final RuntimeException direct = new RuntimeException("direct");
        assertTrue(ExceptionUtils.hasCause(direct, RuntimeException.class));
        assertFalse(ExceptionUtils.hasCause(direct, IOException.class));
    }

    private static Throwable buildNonSubclassChain() {
        final NumberFormatException c3 = new NumberFormatException("c3");
        final RuntimeException c2 = new RuntimeException("c2", c3);
        return new RuntimeException("c1", c2);
    }

    @Test
    void testIndexOfThrowableExactMatchOnly() {
        final Throwable c1 = buildNonSubclassChain();
        // No exact IllegalArgumentException instance exists (only its subclass NumberFormatException).
        assertEquals(-1, ExceptionUtils.indexOfThrowable(c1, IllegalArgumentException.class));
        assertEquals(2, ExceptionUtils.indexOfThrowable(c1, NumberFormatException.class));
    }

    @Test
    void testIndexOfThrowableNullInputs() {
        final Throwable c1 = buildNonSubclassChain();
        assertEquals(-1, ExceptionUtils.indexOfThrowable(null, RuntimeException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(c1, null));
    }

    @Test
    void testIndexOfThrowableWithFromIndex() {
        final Throwable c1 = buildNonSubclassChain();
        assertEquals(-1, ExceptionUtils.indexOfThrowable(c1, NumberFormatException.class, 3));
        assertEquals(2, ExceptionUtils.indexOfThrowable(c1, NumberFormatException.class, -5));
    }

    @Test
    void testIndexOfTypeMatchesSubclasses() {
        final Throwable c1 = buildNonSubclassChain();
        assertEquals(2, ExceptionUtils.indexOfType(c1, IllegalArgumentException.class));
    }

    @Test
    void testIndexOfTypeWithFromIndex() {
        final Throwable c1 = buildNonSubclassChain();
        assertEquals(-1, ExceptionUtils.indexOfType(c1, IllegalArgumentException.class, 3));
        assertEquals(2, ExceptionUtils.indexOfType(c1, IllegalArgumentException.class, -1));
    }

    @Test
    void testIsChecked() {
        assertFalse(ExceptionUtils.isChecked(null));
        assertTrue(ExceptionUtils.isChecked(new IOException()));
        assertFalse(ExceptionUtils.isChecked(new RuntimeException()));
        assertFalse(ExceptionUtils.isChecked(new Error()));
    }

    @Test
    void testIsUnchecked() {
        assertFalse(ExceptionUtils.isUnchecked(null));
        assertTrue(ExceptionUtils.isUnchecked(new RuntimeException()));
        assertTrue(ExceptionUtils.isUnchecked(new Error()));
        assertFalse(ExceptionUtils.isUnchecked(new Exception()));
    }

    @Test
    void testPrintRootCauseStackTraceNullThrowableIsNoOp() {
        // Must not throw even though both arguments are effectively unusable.
        ExceptionUtils.printRootCauseStackTrace(null, (PrintStream) null);
        ExceptionUtils.printRootCauseStackTrace(null, (PrintWriter) null);
    }

    @Test
    void testPrintRootCauseStackTraceNullStreamThrowsNpe() {
        final Throwable t = new RuntimeException("npe-check");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(t, (PrintStream) null);
            }
        });
    }

    @Test
    void testPrintRootCauseStackTraceNullWriterThrowsNpe() {
        final Throwable t = new RuntimeException("npe-check-writer");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(t, (PrintWriter) null);
            }
        });
    }

    @Test
    void testPrintRootCauseStackTraceToPrintStream() {
        final List<Throwable> chain = new ArrayList<>();
        final Throwable[] pair = buildWrappedPair(chain);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        ExceptionUtils.printRootCauseStackTrace(pair[1], ps);
        ps.flush();
        final String output = baos.toString();
        assertTrue(output.contains(pair[0].toString()));
        assertTrue(output.contains(ExceptionUtils.WRAPPED_MARKER + pair[1].toString()));
    }

    @Test
    void testPrintRootCauseStackTraceToPrintWriter() {
        final List<Throwable> chain = new ArrayList<>();
        final Throwable[] pair = buildWrappedPair(chain);
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        ExceptionUtils.printRootCauseStackTrace(pair[1], pw);
        pw.flush();
        final String output = sw.toString();
        assertTrue(output.contains(pair[0].toString()));
        assertTrue(output.contains(ExceptionUtils.WRAPPED_MARKER + pair[1].toString()));
    }

    @Test
    void testPrintRootCauseStackTraceDefaultSystemErr() {
        final PrintStream originalErr = System.err;
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        System.setErr(new PrintStream(baos));
        try {
            ExceptionUtils.printRootCauseStackTrace(new RuntimeException("to-system-err"));
        } finally {
            System.setErr(originalErr);
        }
        assertTrue(baos.toString().contains("to-system-err"));
    }

    @Test
    void testRemoveCommonFramesNullArgumentsThrowNpe() {
        final List<String> frames = new ArrayList<>();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(null, frames);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(frames, null);
            }
        });
    }

    @Test
    void testRemoveCommonFrames() {
        final List<String> causeFrames = new ArrayList<>(Arrays.asList(
                "at a.b.c(C.java:1)",
                "at a.b.d(D.java:2)",
                "at a.b.e(E.java:3)"));
        final List<String> wrapperFrames = new ArrayList<>(Arrays.asList(
                "at x.y.z(Z.java:9)",
                "at a.b.d(D.java:2)",
                "at a.b.e(E.java:3)"));
        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);
        assertEquals(Arrays.asList("at a.b.c(C.java:1)"), causeFrames);
    }

    @Test
    void testRemoveCommonFramesNoOverlap() {
        final List<String> causeFrames = new ArrayList<>(Arrays.asList("at a.b.c(C.java:1)"));
        final List<String> wrapperFrames = new ArrayList<>(Arrays.asList("at x.y.z(Z.java:9)"));
        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);
        assertEquals(Arrays.asList("at a.b.c(C.java:1)"), causeFrames);
    }

    @Test
    void testRethrow() {
        final IOException io = new IOException("rethrow-io");
        try {
            ExceptionUtils.<Object>rethrow(io);
            fail("Expected the original checked exception to be thrown");
        } catch (final Throwable t) {
            assertSame(io, t);
        }
    }

    @Test
    void testStreamNullThrowable() {
        final Stream<Throwable> empty = ExceptionUtils.stream(null);
        assertEquals(0, empty.count());
    }

    @Test
    void testStreamChain() {
        final IOException bottom = new IOException("bottom");
        final RuntimeException top = new RuntimeException("top", bottom);
        final List<Throwable> list = ExceptionUtils.stream(top).collect(Collectors.toList());
        assertEquals(Arrays.asList(top, bottom), list);
    }

    @Test
    void testThrowableOfThrowableExactMatchOnly() {
        final Throwable c1 = buildNonSubclassChain();
        assertNull(ExceptionUtils.throwableOfThrowable(c1, IllegalArgumentException.class));
        final NumberFormatException found = ExceptionUtils.throwableOfThrowable(c1, NumberFormatException.class);
        assertNotNull(found);
        assertSame(found, ExceptionUtils.getThrowables(c1)[2]);
    }

    @Test
    void testThrowableOfThrowableNullInputsAndFromIndex() {
        final Throwable c1 = buildNonSubclassChain();
        assertNull(ExceptionUtils.throwableOfThrowable(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(c1, null));
        assertNull(ExceptionUtils.throwableOfThrowable(c1, NumberFormatException.class, 3));
        assertNotNull(ExceptionUtils.throwableOfThrowable(c1, NumberFormatException.class, -1));
    }

    @Test
    void testThrowableOfTypeMatchesSubclasses() {
        final Throwable c1 = buildNonSubclassChain();
        final IllegalArgumentException found = ExceptionUtils.throwableOfType(c1, IllegalArgumentException.class);
        assertNotNull(found);
        assertTrue(found instanceof NumberFormatException);
    }

    @Test
    void testThrowableOfTypeWithFromIndex() {
        final Throwable c1 = buildNonSubclassChain();
        assertNull(ExceptionUtils.throwableOfType(c1, IllegalArgumentException.class, 3));
        assertNotNull(ExceptionUtils.throwableOfType(c1, IllegalArgumentException.class, -1));
    }

    @Test
    void testThrowUncheckedWithRuntimeExceptionThrowsOriginal() {
        final RuntimeException re = new IllegalStateException("throw-unchecked-re");
        try {
            ExceptionUtils.throwUnchecked(re);
            fail("Expected the RuntimeException to be thrown");
        } catch (final Throwable t) {
            assertSame(re, t);
        }
    }

    @Test
    void testThrowUncheckedWithErrorThrowsOriginal() {
        final Error err = new AssertionError("throw-unchecked-error");
        try {
            ExceptionUtils.throwUnchecked(err);
            fail("Expected the Error to be thrown");
        } catch (final Throwable t) {
            assertSame(err, t);
        }
    }

    @Test
    void testThrowUncheckedWithCheckedExceptionReturnsUnchanged() {
        final Exception checked = new IOException("throw-unchecked-checked");
        final Throwable result = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, result);
    }

    @Test
    void testThrowUncheckedWithNullReturnsNull() {
        final Throwable nullThrowable = null;
        assertNull(ExceptionUtils.throwUnchecked(nullThrowable));
    }

    @Test
    void testWrapAndThrowWithCheckedExceptionWraps() {
        final IOException io = new IOException("wrap-and-throw-io");
        try {
            ExceptionUtils.<Object>wrapAndThrow(io);
            fail("Expected an UndeclaredThrowableException to be thrown");
        } catch (final UndeclaredThrowableException ute) {
            assertSame(io, ute.getCause());
        }
    }

    @Test
    void testWrapAndThrowWithUncheckedExceptionPassesThrough() {
        final IllegalStateException ise = new IllegalStateException("wrap-and-throw-ise");
        try {
            ExceptionUtils.<Object>wrapAndThrow(ise);
            fail("Expected the original unchecked exception to be thrown");
        } catch (final RuntimeException e) {
            assertSame(ise, e);
        }
    }

    @Test
    void testPublicConstructor() {
        assertNotNull(new ExceptionUtils());
    }
}
