/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testIsCommentStart() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("a,b", format);
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
        lexer.close();
    }

    @Test
    void testIsCommentStartDisabled() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        assertFalse(lexer.isCommentStart('#'));
        lexer.close();
    }

    @Test
    void testIsEscape() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a,b", format);
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
        lexer.close();
    }

    @Test
    void testIsQuoteChar() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        lexer.close();
    }

    @Test
    void testIsEndOfFile() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));
        lexer.close();
    }

    @Test
    void testIsStartOfLine() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        lexer.close();
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(",,", CSVFormat.DEFAULT);
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('a'));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiChar() throws IOException {
        // The first char of a multi-char delimiter is passed as ch; the remainder is peeked from the reader.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(": rest", format);
        assertTrue(lexer.isDelimiter(':'));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharNoMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a rest", format);
        assertFalse(lexer.isDelimiter(':'));
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiter() throws IOException {
        // isEscapeDelimiter() peeks the pattern delimiter[0], escape, delimiter[1], ... assuming the
        // leading escape character has already been consumed by the caller.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final Lexer lexer = createLexer(":!:rest", format);
        assertTrue(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterNoMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final Lexer lexer = createLexer("abcdef", format);
        assertFalse(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testGetFirstEolInitiallyNull() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        assertNull(lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineLf() throws IOException {
        final Lexer lexer = createLexer("a\nb", CSVFormat.DEFAULT);
        assertFalse(lexer.readEndOfLine('a'));
        assertTrue(lexer.readEndOfLine(Constants.LF));
        assertEquals("\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineCr() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineCrLf() throws IOException {
        // Reader positioned so peek() sees LF after we pass CR
        final Lexer lexer = createLexer("\nrest", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals(Constants.CRLF, lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testGetBytesReadCharacterPositionAndLineNumber() throws IOException {
        final Lexer lexer = createLexer("a,b\nc,d", CSVFormat.DEFAULT);
        assertEquals(0, lexer.getCharacterPosition());
        assertEquals(0, lexer.getCurrentLineNumber());
        final Token token = new Token();
        lexer.nextToken(token);
        assertTrue(lexer.getCharacterPosition() > 0);
        lexer.close();
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testNextTokenSimpleRecord() throws IOException {
        final Lexer lexer = createLexer("a,b,c", CSVFormat.DEFAULT);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("c", token.content.toString());
        assertTrue(token.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenEmptyInputIsEof() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testNextTokenMultipleRecords() throws IOException {
        final Lexer lexer = createLexer("a,b\nc,d", CSVFormat.DEFAULT);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("c", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("d", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenQuotedValue() throws IOException {
        final Lexer lexer = createLexer("\"a,b\",c", CSVFormat.DEFAULT);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());
        assertTrue(token.isQuoted);

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenQuotedValueWithEscapedQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"\"b\"", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a\"b", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenUnterminatedQuoteThrows() throws IOException {
        final Lexer lexer = createLexer("\"a,b", CSVFormat.DEFAULT);
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        assertTrue(e.getMessage().contains("EOF"));
        lexer.close();
    }

    @Test
    void testNextTokenUnterminatedQuoteLenientEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"a,b", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a,b", token.content.toString());
        assertTrue(token.isReady);
        lexer.close();
    }

    @Test
    void testNextTokenInvalidCharAfterEncapsulatedTokenThrows() throws IOException {
        final Lexer lexer = createLexer("\"a\"b,c", CSVFormat.DEFAULT);
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        lexer.close();
    }

    @Test
    void testNextTokenTrailingDataAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"a\"b,c", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("ab", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenCommentLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("# a comment\na,b", format);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenCommentWithNoTrailingNewlineIsEof() throws IOException {
        // No newline after the marker means readLine() returns null, so there is no comment content to report.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    @Test
    void testNextTokenCommentEmptyContent() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#\na,b", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenIgnoreEmptyLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\na,b", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenIgnoreEmptyLinesAllBlankYieldsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\n\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    @Test
    void testNextTokenNotIgnoringEmptyLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer("\na,b", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testNextTokenIgnoreSurroundingSpaces() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer("  a  ,  b  ", format);
        Token token = lexer.nextToken(new Token());
        assertEquals("a", token.content.toString());

        token = lexer.nextToken(new Token());
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testNextTokenEscapedCharacter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\,b,c", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());
        lexer.close();
    }

    @Test
    void testReadEscapeSpecialChars() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        Lexer lexer = createLexer("r", format);
        assertEquals(Constants.CR, lexer.readEscape());
        lexer.close();

        lexer = createLexer("n", format);
        assertEquals(Constants.LF, lexer.readEscape());
        lexer.close();

        lexer = createLexer("t", format);
        assertEquals(Constants.TAB, lexer.readEscape());
        lexer.close();

        lexer = createLexer("b", format);
        assertEquals(Constants.BACKSPACE, lexer.readEscape());
        lexer.close();

        lexer = createLexer("f", format);
        assertEquals(Constants.FF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeUnexpectedCharReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("x", format);
        assertEquals(EOF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeAtEndOfFileThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("", format);
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        lexer.close();
    }

    @Test
    void testTrimTrailingSpaces() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        final StringBuilder sb = new StringBuilder("hello   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("hello", sb.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals(0, allSpaces.length());

        final StringBuilder noSpaces = new StringBuilder("hello");
        lexer.trimTrailingSpaces(noSpaces);
        assertEquals("hello", noSpaces.toString());
        lexer.close();
    }
}
