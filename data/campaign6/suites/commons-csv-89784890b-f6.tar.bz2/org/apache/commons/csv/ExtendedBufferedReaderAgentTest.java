/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("xyz"));
        assertEquals(UNDEFINED, r.getLastChar());
        assertEquals(0, r.getPosition());
        assertEquals(0, r.getLineNumber());
        assertEquals(0, r.getBytesRead());
    }

    @Test
    void testReadSingleCharAdvancesPositionAndLastChar() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals('a', r.read());
        assertEquals('a', r.getLastChar());
        assertEquals(1, r.getPosition());
        assertEquals('b', r.read());
        assertEquals('b', r.getLastChar());
        assertEquals(2, r.getPosition());
    }

    @Test
    void testReadReturnsEofAtEndAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("a"));
        assertEquals('a', r.read());
        assertEquals(EOF, r.read());
        assertEquals(EOF, r.getLastChar());
    }

    @Test
    void testPeekDoesNotConsumeCharacter() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("hi"));
        assertEquals('h', r.peek());
        // peek must not advance position or update lastChar
        assertEquals(UNDEFINED, r.getLastChar());
        assertEquals(0, r.getPosition());
        assertEquals('h', r.read());
        assertEquals('i', r.read());
        assertEquals(EOF, r.read());
    }

    @Test
    void testPeekAtEofReturnsEofWithoutConsuming() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(EOF, r.peek());
        assertEquals(UNDEFINED, r.getLastChar());
        assertEquals(0, r.getPosition());
    }

    @Test
    void testLineNumberTracksLfCrAndCrLf() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("a\nb\rc\r\nd"));
        assertEquals(0, r.getLineNumber());
        r.read(); // a: in progress on line 1
        assertEquals(1, r.getLineNumber());
        r.read(); // \n: completes line 1
        assertEquals(1, r.getLineNumber());
        r.read(); // b: in progress on line 2
        assertEquals(2, r.getLineNumber());
        r.read(); // \r: completes line 2
        assertEquals(2, r.getLineNumber());
        r.read(); // c: in progress on line 3
        assertEquals(3, r.getLineNumber());
        r.read(); // \r (first half of \r\n): completes line 3
        assertEquals(3, r.getLineNumber());
        r.read(); // \n (second half of \r\n) must NOT count as a second EOL
        assertEquals(3, r.getLineNumber());
        r.read(); // d: in progress on line 4
        assertEquals(4, r.getLineNumber());
    }

    @Test
    void testLineNumberForUnterminatedFinalLine() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"));
        r.read();
        r.read();
        r.read();
        assertEquals(1, r.getLineNumber());
        assertEquals(EOF, r.read());
        // Reaching EOF completes the trailing line that has no terminator.
        assertEquals(1, r.getLineNumber());
    }

    @Test
    void testLineNumberForEmptyStreamIsZero() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(EOF, r.read());
        // Nothing was ever read, so there is no line to count.
        assertEquals(0, r.getLineNumber());
    }

    @Test
    void testBulkReadFillsBufferAndAdvancesState() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("hello\nworld"));
        final char[] buf = new char[20];
        final int n = r.read(buf, 0, 20);
        assertEquals(11, n);
        assertEquals("hello\nworld", new String(buf, 0, n));
        assertEquals(11, r.getPosition());
        assertEquals('d', r.getLastChar());
        assertEquals(2, r.getLineNumber());
    }

    @Test
    void testBulkReadIntoOffsetPortionOfBuffer() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("xyz"));
        final char[] buf = new char[10];
        final int n = r.read(buf, 3, 3);
        assertEquals(3, n);
        assertEquals("xyz", new String(buf, 3, n));
        assertEquals(3, r.getPosition());
    }

    @Test
    void testBulkReadZeroLengthIsNoOp() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("hello"));
        final char[] buf = new char[10];
        final int n = r.read(buf, 0, 0);
        assertEquals(0, n);
        assertEquals(UNDEFINED, r.getLastChar());
        assertEquals(0, r.getPosition());
    }

    @Test
    void testBulkReadNegativeLengthThrows() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abcdef"));
        final char[] buf = new char[10];
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                r.read(buf, 0, -1);
            }
        });
    }

    @Test
    void testBulkReadAtEofReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("ab"));
        final char[] buf = new char[10];
        final int first = r.read(buf, 0, 10);
        assertEquals(2, first);
        final long positionAfterFirstRead = r.getPosition();
        final int second = r.read(buf, 0, 10);
        assertEquals(EOF, second);
        assertEquals(EOF, r.getLastChar());
        // Reading at EOF consumed nothing more, so the position must not move.
        assertEquals(positionAfterFirstRead, r.getPosition());
    }

    @Test
    void testBulkReadLineNumberConsistentWithSingleCharReadAtEof() throws IOException {
        // Reading the same unterminated final line via single-char read() reports line 1 at EOF.
        final ExtendedBufferedReader single = new ExtendedBufferedReader(new StringReader("abc"));
        single.read();
        single.read();
        single.read();
        single.read(); // triggers EOF
        final long expected = single.getLineNumber();
        assertEquals(1, expected);

        // The bulk read() API must report the same line number once it reaches EOF on equivalent input.
        final ExtendedBufferedReader bulk = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[10];
        bulk.read(buf, 0, 10);
        bulk.read(buf, 0, 10); // triggers EOF
        assertEquals(expected, bulk.getLineNumber());
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("0123456789"));
        r.read();
        r.read();
        r.mark(10);
        final long markedPosition = r.getPosition();
        final int markedLastChar = r.getLastChar();
        r.read();
        r.read();
        assertEquals(markedPosition + 2, r.getPosition());
        r.reset();
        assertEquals(markedPosition, r.getPosition());
        assertEquals(markedLastChar, r.getLastChar());
        // Reading again after reset must replay the characters following the mark.
        assertEquals('2', r.read());
    }

    @Test
    void testResetWithoutMarkThrows() {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abcdef"));
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                r.reset();
            }
        });
    }

    @Test
    void testCloseSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"));
        r.read();
        r.close();
        assertEquals(EOF, r.getLastChar());
    }

    @Test
    void testCloseThenReadThrows() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"));
        r.close();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                r.read();
            }
        });
    }

    @Test
    void testReadLineDropsLfTerminator() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("line1\nline2"));
        assertEquals("line1", r.readLine());
        assertEquals(1, r.getLineNumber());
        assertEquals("line2", r.readLine());
        assertNull(r.readLine());
    }

    @Test
    void testReadLineDropsCrLfTerminatorAsOneEol() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("line1\r\nline2\nline3"));
        assertEquals("line1", r.readLine());
        assertEquals(1, r.getLineNumber());
        assertEquals("line2", r.readLine());
        assertEquals(2, r.getLineNumber());
        assertEquals("line3", r.readLine());
        assertEquals(3, r.getLineNumber());
        assertNull(r.readLine());
    }

    @Test
    void testReadLineOnEmptyStreamReturnsNull() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader(""));
        assertNull(r.readLine());
    }

    @Test
    void testReadLineOnBlankLineReturnsEmptyString() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("\nabc"));
        assertEquals("", r.readLine());
        assertEquals("abc", r.readLine());
    }

    @Test
    void testGetBytesReadIsZeroWithoutCharset() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"));
        r.read();
        r.read();
        r.read();
        assertEquals(0, r.getBytesRead());
    }

    @Test
    void testGetBytesReadIsZeroWhenTrackingDisabled() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        r.read();
        r.read();
        r.read();
        assertEquals(0, r.getBytesRead());
    }

    @Test
    void testGetBytesReadWithAsciiUtf8Charset() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        r.read();
        r.read();
        r.read();
        assertEquals(3, r.getBytesRead());
    }

    @Test
    void testGetBytesReadWithSurrogatePairUtf8() throws IOException {
        // U+1F600 GRINNING FACE is a surrogate pair in UTF-16 and encodes to 4 bytes in UTF-8.
        final String emoji = new String(Character.toChars(0x1F600));
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader(emoji), StandardCharsets.UTF_8, true);
        r.read(); // high surrogate: contributes no bytes on its own
        assertEquals(0, r.getBytesRead());
        r.read(); // low surrogate: completes the pair
        assertEquals(4, r.getBytesRead());
    }

    @Test
    void testGetBytesReadViaBulkReadWithUtf8Charset() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[10];
        final int n = r.read(buf, 0, 10);
        assertEquals(3, n);
        assertEquals(3, r.getBytesRead());
    }

    @Test
    void testBytesReadRestoredOnReset() throws IOException {
        final ExtendedBufferedReader r = new ExtendedBufferedReader(new StringReader("ab\ncd"), StandardCharsets.UTF_8, true);
        r.read();
        r.read();
        r.read();
        r.mark(10);
        final long bytesAtMark = r.getBytesRead();
        assertEquals(3, bytesAtMark);
        r.read();
        r.read();
        assertTrue(r.getBytesRead() > bytesAtMark);
        r.reset();
        assertEquals(bytesAtMark, r.getBytesRead());
    }
}
