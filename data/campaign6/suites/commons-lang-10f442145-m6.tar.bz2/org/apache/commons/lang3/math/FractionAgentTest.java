/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link Fraction}.
 */
public class FractionAgentTest {

    @Test
    public void testGetFractionIntInt_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntInt_notReduced() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_overflowOnNegateThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -7));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, Integer.MIN_VALUE));
    }

    @Test
    public void testGetReducedFraction_basic() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorNormalizesToZero() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testGetReducedFraction_minValueDenominatorEvenNumerator() {
        final Fraction f = Fraction.getReducedFraction(2, Integer.MIN_VALUE);
        assertEquals(-1, f.getNumerator());
        assertEquals(1073741824, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator_basic() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator_negativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, -7));
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -3, 7));
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, 0));
    }

    @Test
    public void testGetFractionWholeNumeratorDenominator_overflowThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, Integer.MAX_VALUE, 1));
    }

    @Test
    public void testGetFractionDouble_basic() {
        final Fraction f = Fraction.getFraction(1.0d / 3.0d);
        assertEquals(1, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_zero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_negative() {
        final Fraction f = Fraction.getFraction(-0.5d);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_NaNThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction((double) Integer.MAX_VALUE + 1.0d));
    }

    @Test
    public void testGetFractionString_wholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_simpleFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_mixedFraction() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_doubleFormat() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionString_nullThrowsNPE() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionString_malformedMixedThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3-7"));
    }

    @Test
    public void testGetFractionString_malformedThrowsNFE() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testConstants() {
        assertEquals(Fraction.getFraction(0, 1), Fraction.ZERO);
        assertEquals(Fraction.getFraction(1, 1), Fraction.ONE);
        assertEquals(Fraction.getFraction(1, 2), Fraction.ONE_HALF);
        assertEquals(Fraction.getFraction(1, 3), Fraction.ONE_THIRD);
        assertEquals(Fraction.getFraction(2, 3), Fraction.TWO_THIRDS);
        assertEquals(Fraction.getFraction(1, 4), Fraction.ONE_QUARTER);
        assertEquals(Fraction.getFraction(2, 4), Fraction.TWO_QUARTERS);
        assertEquals(Fraction.getFraction(3, 4), Fraction.THREE_QUARTERS);
        assertEquals(Fraction.getFraction(1, 5), Fraction.ONE_FIFTH);
        assertEquals(Fraction.getFraction(2, 5), Fraction.TWO_FIFTHS);
        assertEquals(Fraction.getFraction(3, 5), Fraction.THREE_FIFTHS);
        assertEquals(Fraction.getFraction(4, 5), Fraction.FOUR_FIFTHS);
    }

    @Test
    public void testAbs_positive() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbs_negative() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAdd_basic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAdd_zeroIdentity() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(a, Fraction.ZERO.add(a));
        assertSame(a, a.add(Fraction.ZERO));
    }

    @Test
    public void testAdd_nullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.add(null));
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction a = Fraction.getFraction(1, Integer.MAX_VALUE);
        final Fraction b = Fraction.getFraction(1, Integer.MAX_VALUE - 1);
        assertThrows(ArithmeticException.class, () -> a.add(b));
    }

    @Test
    public void testAdd_sameDenominatorCommonGcd() {
        // denominators share a gcd > 1 so the BigInteger path is exercised
        final Fraction a = Fraction.getFraction(1, 6);
        final Fraction b = Fraction.getFraction(1, 4);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(12, result.getDenominator());
    }

    @Test
    public void testSubtract_basic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtract_nullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.subtract(null));
    }

    @Test
    public void testSubtract_zeroFractionReturnsThis() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertSame(a, a.subtract(Fraction.ZERO));
    }

    @Test
    public void testMultiplyBy_basic() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction result = a.multiplyBy(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyBy_zero() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertSame(Fraction.ZERO, a.multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyBy_nullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.multiplyBy(null));
    }

    @Test
    public void testMultiplyBy_overflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> a.multiplyBy(b));
    }

    @Test
    public void testDivideBy_basic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.divideBy(b);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideBy_zeroThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, () -> a.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideBy_nullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.divideBy(null));
    }

    @Test
    public void testInvert_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction inverted = f.invert();
        assertEquals(7, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvert_negative() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction inverted = f.invert();
        assertEquals(-7, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.ZERO.invert());
    }

    @Test
    public void testInvert_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    @Test
    public void testNegate_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction negated = f.negate();
        assertEquals(-3, negated.getNumerator());
        assertEquals(7, negated.getDenominator());
    }

    @Test
    public void testNegate_minValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    @Test
    public void testPow_zeroPowerReturnsOne() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(Fraction.ONE, f.pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPow_onePowerReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPow_positivePower() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPow_negativePower() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPow_minValuePower() {
        // Integer.MIN_VALUE can't be negated directly; pow() must handle it via invert().pow(2).pow(-(power/2))
        final Fraction f = Fraction.getFraction(1, 1);
        assertEquals(Fraction.ONE, f.pow(Integer.MIN_VALUE));
        // the power magnitude is far beyond int range for this base, so the overflow check must fire
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(3, 2).pow(Integer.MIN_VALUE));
    }

    @Test
    public void testReduce_basic() {
        final Fraction f = Fraction.getFraction(2, 4);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduce_alreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduce_zeroNumeratorReturnsZero() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertSame(Fraction.ZERO, f.reduce());
    }

    @Test
    public void testCompareTo_equalValues() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareTo_lessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareTo_sameInstance() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareTo_nullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertThrows(NullPointerException.class, () -> a.compareTo(null));
    }

    @Test
    public void testEquals_sameValue() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
    }

    @Test
    public void testEquals_unreducedNotEqual() {
        // equals treats 1/2 and 2/4 as different, unlike compareTo
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertFalse(a.equals(b));
        assertNotEquals(0, a.compareTo(b) == 0 ? 1 : 0);
    }

    @Test
    public void testEquals_null() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals(null));
    }

    @Test
    public void testEquals_differentType() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals("1/2"));
    }

    @Test
    public void testEquals_reflexive() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertTrue(a.equals(a));
    }

    @Test
    public void testHashCode_equalObjectsHaveEqualHashCodes() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
        assertEquals(0, Fraction.getFraction(1, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.75f, Fraction.getFraction(3, 4).floatValue(), 0.0001f);
    }

    @Test
    public void testDoubleValue() {
        assertEquals(0.75d, Fraction.getFraction(3, 4).doubleValue(), 0.0001d);
    }

    @Test
    public void testGetProperNumerator() {
        assertEquals(3, Fraction.getFraction(7, 4).getProperNumerator());
        assertEquals(3, Fraction.getFraction(-7, 4).getProperNumerator());
        assertEquals(0, Fraction.getFraction(8, 4).getProperNumerator());
    }

    @Test
    public void testGetProperWhole() {
        assertEquals(1, Fraction.getFraction(7, 4).getProperWhole());
        assertEquals(-1, Fraction.getFraction(-7, 4).getProperWhole());
        assertEquals(0, Fraction.getFraction(3, 4).getProperWhole());
    }

    @Test
    public void testToString_cachedAndCorrect() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toString());
        assertSame(f.toString(), f.toString());
    }

    @Test
    public void testToProperString_wholeNumber() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperString_negativeOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperString_zero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperString_improperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperString_negativeImproperFraction() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperString_simpleFraction() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToProperString_minValueNumerator() {
        // numerator == Integer.MIN_VALUE exercises the magnitude-comparison branch guarding against overflow
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 2);
        assertEquals("-1073741824", f.toProperString());
    }

    @Test
    public void testToProperString_cached() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertSame(f.toProperString(), f.toProperString());
    }
}
