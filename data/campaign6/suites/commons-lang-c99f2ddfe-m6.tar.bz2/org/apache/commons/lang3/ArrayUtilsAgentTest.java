/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));
    }

    @Test
    void testAddIntPrimitive() {
        final int[] result = ArrayUtils.add(new int[] { 1, 2 }, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);

        final int[] fromNull = ArrayUtils.add((int[]) null, 7);
        assertArrayEquals(new int[] { 7 }, fromNull);
    }

    @Test
    void testAddIntAtIndex() {
        final int[] result = ArrayUtils.add(new int[] { 1, 3 }, 1, 2);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, 5, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, -1, 9);
            }
        });
    }

    @Test
    void testAddObjectGeneric() {
        final String[] result = ArrayUtils.add(new String[] { "a", "b" }, "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);

        final Integer[] fromNull = ArrayUtils.add((Integer[]) null, Integer.valueOf(5));
        assertArrayEquals(new Integer[] { Integer.valueOf(5) }, fromNull);
    }

    @Test
    void testAddAllPrimitiveAndNullCombinations() {
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.addAll(new int[] { 1, 2 }, 3, 4));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll(new int[] { 1, 2 }, (int[]) null));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll((int[]) null, 1, 2));
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
    }

    @Test
    void testAddFirst() {
        final int[] result = ArrayUtils.addFirst(new int[] { 2, 3 }, 1);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);

        final int[] fromNull = ArrayUtils.addFirst((int[]) null, 9);
        assertArrayEquals(new int[] { 9 }, fromNull);
    }

    @Test
    void testCloneNullAndValue() {
        assertNull(ArrayUtils.clone((int[]) null));
        final int[] original = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);

        assertNull(ArrayUtils.clone((Object[]) null));
        final String[] originalObj = { "a", "b" };
        final String[] clonedObj = ArrayUtils.clone(originalObj);
        assertArrayEquals(originalObj, clonedObj);
        assertTrue(originalObj != clonedObj);
    }

    @Test
    void testConcat() {
        final int[] result = ArrayUtils.concat(new int[] { 1, 2 }, new int[] { 3 }, new int[] { 4, 5 });
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, result);

        assertArrayEquals(new int[0], ArrayUtils.concat((int[]) null));
        assertArrayEquals(new int[] { 1 }, ArrayUtils.concat(new int[] { 1 }));
    }

    @Test
    void testContains() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final Object[] objArray = { "a", null, "b" };
        assertTrue(ArrayUtils.contains(objArray, null));
        assertTrue(ArrayUtils.contains(objArray, "b"));
        assertFalse(ArrayUtils.contains(objArray, "z"));
    }

    @Test
    void testContainsAny() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.containsAny(array, 5, 2));
        assertFalse(ArrayUtils.containsAny(array, 7, 8));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
    }

    @Test
    void testGetAndDefault() {
        final String[] array = { "a", "b", "c" };
        assertEquals("b", ArrayUtils.get(array, 1));
        assertNull(ArrayUtils.get(array, 10));
        assertNull(ArrayUtils.get((String[]) null, 0));

        assertEquals("z", ArrayUtils.get(array, 10, "z"));
        assertEquals("a", ArrayUtils.get(array, 0, "z"));
        assertEquals("z", ArrayUtils.get(array, -1, "z"));
    }

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((Object[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new Object[] { "x" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] { "x" }, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] { "x" }, -1));
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertNull(ArrayUtils.getComponentType((Object[]) null));
    }

    @Test
    void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[0]));
        assertEquals(2, ArrayUtils.getDimensions(new int[0][0]));
        assertEquals(3, ArrayUtils.getDimensions(new String[0][0][0]));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array = { 1, 2, 3 };
        assertEquals(ArrayUtils.hashCode(array), ArrayUtils.hashCode(new int[] { 1, 2, 3 }));
        assertTrue(ArrayUtils.hashCode(array) != ArrayUtils.hashCode(new int[] { 3, 2, 1 }));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet expected = new BitSet();
        expected.set(0);
        expected.set(2);
        expected.set(4);
        assertEquals(expected, ArrayUtils.indexesOf(array, 1));

        final BitSet empty = new BitSet();
        assertEquals(empty, ArrayUtils.indexesOf(array, 9));
        assertEquals(empty, ArrayUtils.indexesOf((int[]) null, 1));
    }

    @Test
    void testIndexOfBoundaries() {
        final int[] array = { 10, 20, 30 };
        assertEquals(0, ArrayUtils.indexOf(array, 10));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 99));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 10));
        assertEquals(1, ArrayUtils.indexOf(array, 20, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 10, 1));
        // negative startIndex is treated as 0
        assertEquals(0, ArrayUtils.indexOf(array, 10, -5));
        // startIndex beyond length yields not found
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 10, 50));
    }

    @Test
    void testLastIndexOfBoundaries() {
        final int[] array = { 10, 20, 10, 30 };
        assertEquals(2, ArrayUtils.lastIndexOf(array, 10));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 99));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 10));
        // startIndex beyond length is clamped to length - 1
        assertEquals(2, ArrayUtils.lastIndexOf(array, 10, 100));
        // negative startIndex yields not found
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 10, -1));
    }

    @Test
    void testInsert() {
        final int[] result = ArrayUtils.insert(1, new int[] { 1, 4 }, 2, 3);
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, result);

        assertNull(ArrayUtils.insert(0, (int[]) null, 1));

        final int[] unchanged = ArrayUtils.insert(1, new int[] { 1, 2 });
        assertArrayEquals(new int[] { 1, 2 }, unchanged);

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(5, new int[] { 1, 2 }, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new int[] { 1, 2 }, 9);
            }
        });
    }

    @Test
    void testInsertGenericType() {
        final String[] result = ArrayUtils.insert(1, new String[] { "a", "d" }, "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c", "d" }, result);
        assertNull(ArrayUtils.insert(0, (String[]) null, "x"));
    }

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1 }, new int[] { 3, 4 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1 }, (int[]) null));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    @Test
    void testIsSortedPrimitiveAndGeneric() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));

        assertTrue(ArrayUtils.isSorted(new String[] { "a", "b", "c" }));
        assertFalse(ArrayUtils.isSorted(new String[] { "c", "b", "a" }));
    }

    @Test
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(new int[] { 1 }, null));
    }

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertEquals(String.class, array.getClass().getComponentType());
    }

    @Test
    void testNullToEmptyPrimitiveAndObject() {
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] original = { 1, 2 };
        assertSame(original, ArrayUtils.nullToEmpty(original));

        assertArrayEquals(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        final String[] originalStrings = { "x" };
        assertSame(originalStrings, ArrayUtils.nullToEmpty(originalStrings));
    }

    @Test
    void testNullToEmptyGenericWithType() {
        final String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);

        final String[] original = { "a" };
        assertSame(original, ArrayUtils.nullToEmpty(original, String[].class));
    }

    @Test
    void testRemoveIndexBoundaries() {
        final int[] result = ArrayUtils.remove(new int[] { 1, 2, 3 }, 1);
        assertArrayEquals(new int[] { 1, 3 }, result);

        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2, 3 }, 3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2, 3 }, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    void testRemoveAllIndices() {
        final int[] result = ArrayUtils.removeAll(new int[] { 1, 2, 3, 4, 5 }, 1, 3);
        assertArrayEquals(new int[] { 1, 3, 5 }, result);

        final int[] unchanged = ArrayUtils.removeAll(new int[] { 1, 2 });
        assertArrayEquals(new int[] { 1, 2 }, unchanged);
    }

    @Test
    void testRemoveElement() {
        final int[] result = ArrayUtils.removeElement(new int[] { 1, 2, 3 }, 2);
        assertArrayEquals(new int[] { 1, 3 }, result);

        // value not present returns an equal copy
        final int[] notFound = ArrayUtils.removeElement(new int[] { 1, 2, 3 }, 9);
        assertArrayEquals(new int[] { 1, 2, 3 }, notFound);
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] { 1, 2, 1, 3, 1 }, 1);
        assertArrayEquals(new int[] { 2, 3 }, result);

        final int[] none = ArrayUtils.removeAllOccurrences(new int[] { 2, 3 }, 1);
        assertArrayEquals(new int[] { 2, 3 }, none);
    }

    @Test
    void testReverseFullAndRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 5, 4, 3, 2, 1 }, array);

        final int[] rangeArray = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(rangeArray, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, rangeArray);

        // null array is a no-op, must not throw
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testShift() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);

        final int[] empty = {};
        ArrayUtils.shift(empty, 3);
        assertArrayEquals(new int[0], empty);

        // null array is a no-op, must not throw
        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    void testSwapBasicAndOutOfRange() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] untouched = { 1, 2, 3 };
        ArrayUtils.swap(untouched, 0, 10);
        assertArrayEquals(new int[] { 1, 2, 3 }, untouched);

        // null array is a no-op, must not throw
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testSubarrayBoundaries() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertArrayEquals(array, ArrayUtils.subarray(array, -2, 10));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2 }, new byte[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.startsWith(null, new byte[] { 1 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, null));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2 }, new byte[] { 1, 2 }));
    }

    @Test
    void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new Object[] { new Object[] { "k1", "v1" }, new Object[] { "k2", "v2" } });
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));

        assertNull(ArrayUtils.toMap(null));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] { new Object[] { "onlyOneElement" } });
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] { "notAMapEntryOrArray" });
            }
        });
    }

    @Test
    void testToObjectAndToPrimitiveInt() {
        final Integer[] objects = ArrayUtils.toObject(new int[] { 1, 2, 3 });
        assertArrayEquals(new Integer[] { 1, 2, 3 }, objects);

        final int[] primitives = ArrayUtils.toPrimitive(new Integer[] { 1, 2, 3 });
        assertArrayEquals(new int[] { 1, 2, 3 }, primitives);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] { 1, null, 3 });
            }
        });

        final int[] withDefault = ArrayUtils.toPrimitive(new Integer[] { 1, null, 3 }, -1);
        assertArrayEquals(new int[] { 1, -1, 3 }, withDefault);
    }

    @Test
    void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { 1, "two", null });
        assertEquals("1", result[0]);
        assertEquals("two", result[1]);
        assertEquals("null", result[2]);

        final String[] withDefault = ArrayUtils.toStringArray(new Object[] { 1, null }, "N/A");
        assertEquals("1", withDefault[0]);
        assertEquals("N/A", withDefault[1]);
    }

    @Test
    void testToStringForArray() {
        assertEquals("{}", ArrayUtils.toString(new int[0]));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] { 1, 2, 3 }));
    }
}
