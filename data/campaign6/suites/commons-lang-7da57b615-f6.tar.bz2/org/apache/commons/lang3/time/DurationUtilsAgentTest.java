/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    private static final class IoException extends Exception {
        private static final long serialVersionUID = 1L;

        IoException(final String message) {
            super(message);
        }
    }

    @Test
    void testAccept_nullConsumer_doesNothing() throws Throwable {
        // Should not throw even though duration is non-null.
        DurationUtils.accept(null, Duration.ofMillis(5));
    }

    @Test
    void testAccept_nullDuration_doesNotInvokeConsumer() throws Throwable {
        final boolean[] called = { false };
        final FailableBiConsumer<Long, Integer, Throwable> consumer = new FailableBiConsumer<Long, Integer, Throwable>() {
            @Override
            public void accept(final Long t, final Integer u) {
                called[0] = true;
            }
        };
        DurationUtils.accept(consumer, null);
        assertFalse(called[0]);
    }

    @Test
    void testAccept_invokesConsumerWithMillisAndNanos() throws Throwable {
        final long[] millisHolder = { -1 };
        final int[] nanosHolder = { -1 };
        final Duration duration = Duration.ofSeconds(1, 1_500_000L); // 1.0015 seconds
        final FailableBiConsumer<Long, Integer, Throwable> consumer = new FailableBiConsumer<Long, Integer, Throwable>() {
            @Override
            public void accept(final Long t, final Integer u) {
                millisHolder[0] = t.longValue();
                nanosHolder[0] = u.intValue();
            }
        };
        DurationUtils.accept(consumer, duration);
        assertEquals(duration.toMillis(), millisHolder[0]);
        assertEquals(DurationUtils.getNanosOfMilli(duration), nanosHolder[0]);
        assertEquals(500_000, nanosHolder[0]);
    }

    @Test
    void testAccept_propagatesException() {
        final FailableBiConsumer<Long, Integer, IoException> consumer = new FailableBiConsumer<Long, Integer, IoException>() {
            @Override
            public void accept(final Long t, final Integer u) throws IoException {
                throw new IoException("boom");
            }
        };
        final IoException e = assertThrows(IoException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.accept(consumer, Duration.ofMillis(1));
            }
        });
        assertEquals("boom", e.getMessage());
    }

    @Test
    void testGet_emptyKeyUsesDefault() {
        final Duration d = DurationUtils.get("", ChronoUnit.SECONDS, 42);
        assertEquals(Duration.ofSeconds(42), d);
    }

    @Test
    void testGet_nullKeyUsesDefault() {
        final Duration d = DurationUtils.get(null, ChronoUnit.SECONDS, 7);
        assertEquals(Duration.ofSeconds(7), d);
    }

    @Test
    void testGet_missingPropertyUsesDefault() {
        final String key = "DurationUtilsAgentTest.missing." + System.nanoTime();
        final Duration d = DurationUtils.get(key, ChronoUnit.MILLIS, 123);
        assertEquals(Duration.ofMillis(123), d);
    }

    @Test
    void testGet_propertySetOverridesDefault() {
        final String key = "DurationUtilsAgentTest.set." + System.nanoTime();
        System.setProperty(key, "99");
        try {
            final Duration d = DurationUtils.get(key, ChronoUnit.SECONDS, 1);
            assertEquals(Duration.ofSeconds(99), d);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    void testGetMillis_defaultAndOverride() {
        final String key = "DurationUtilsAgentTest.millis." + System.nanoTime();
        assertEquals(Duration.ofMillis(500), DurationUtils.getMillis(key, 500));
        System.setProperty(key, "250");
        try {
            assertEquals(Duration.ofMillis(250), DurationUtils.getMillis(key, 500));
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    void testGetSeconds_defaultAndOverride() {
        final String key = "DurationUtilsAgentTest.seconds." + System.nanoTime();
        assertEquals(Duration.ofSeconds(5), DurationUtils.getSeconds(key, 5));
        System.setProperty(key, "11");
        try {
            assertEquals(Duration.ofSeconds(11), DurationUtils.getSeconds(key, 5));
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    void testGetNanosOfMilli_nullDurationIsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testGetNanosOfMilli_wholeMilliIsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofMillis(7)));
    }

    @Test
    void testGetNanosOfMilli_partialNanos() {
        final Duration duration = Duration.ofSeconds(0, 1_500_000L);
        assertEquals(500_000, DurationUtils.getNanosOfMilli(duration));
    }

    @Test
    void testGetNanosOfMiili_delegatesToGetNanosOfMilli() {
        final Duration duration = Duration.ofSeconds(2, 250_000L);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
        assertEquals(250_000, DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testIsPositive_positiveDuration() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
    }

    @Test
    void testIsPositive_zeroDuration() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    void testIsPositive_negativeDuration() {
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    @Test
    void testOfConsumer_measuresElapsedTimeAndPassesStartInstant() throws Throwable {
        final Instant[] startHolder = { null };
        final Duration result = DurationUtils.of(new FailableConsumer<Instant, Throwable>() {
            @Override
            public void accept(final Instant start) throws InterruptedException {
                startHolder[0] = start;
                Thread.sleep(5);
            }
        });
        assertNotNull(startHolder[0]);
        assertNotNull(result);
        assertFalse(result.isNegative());
    }

    @Test
    void testOfConsumer_propagatesException() {
        final IoException e = assertThrows(IoException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, IoException>() {
                    @Override
                    public void accept(final Instant start) throws IoException {
                        throw new IoException("consumer failed");
                    }
                });
            }
        });
        assertEquals("consumer failed", e.getMessage());
    }

    @Test
    void testOfRunnable_measuresElapsedTime() throws Throwable {
        final boolean[] ran = { false };
        final Duration result = DurationUtils.of(new FailableRunnable<Throwable>() {
            @Override
            public void run() throws InterruptedException {
                ran[0] = true;
                Thread.sleep(5);
            }
        });
        assertTrue(ran[0]);
        assertNotNull(result);
        assertFalse(result.isNegative());
    }

    @Test
    void testOfRunnable_propagatesException() {
        final IoException e = assertThrows(IoException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<IoException>() {
                    @Override
                    public void run() throws IoException {
                        throw new IoException("runnable failed");
                    }
                });
            }
        });
        assertEquals("runnable failed", e.getMessage());
    }

    @Test
    void testSince_returnsPositiveDurationForPastInstant() {
        final Instant past = Instant.now().minusSeconds(1);
        final Duration result = DurationUtils.since(past);
        assertFalse(result.isNegative());
        assertTrue(result.toMillis() >= 900, "Expected at least ~1 second, got " + result);
    }

    @Test
    void testToChronoUnit_mapsAllTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnit_nullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    @Test
    void testToDuration_convertsAmountAndUnit() {
        assertEquals(Duration.ofSeconds(5), DurationUtils.toDuration(5, TimeUnit.SECONDS));
        assertEquals(Duration.ofMillis(250), DurationUtils.toDuration(250, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ofMinutes(-3), DurationUtils.toDuration(-3, TimeUnit.MINUTES));
        assertEquals(Duration.ZERO, DurationUtils.toDuration(0, TimeUnit.HOURS));
    }

    @Test
    void testToMillisInt_null_throwsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testToMillisInt_withinRange() {
        assertEquals(500, DurationUtils.toMillisInt(Duration.ofMillis(500)));
        assertEquals(-500, DurationUtils.toMillisInt(Duration.ofMillis(-500)));
        assertEquals(0, DurationUtils.toMillisInt(Duration.ZERO));
    }

    @Test
    void testToMillisInt_clampsAboveIntMax() {
        final Duration duration = Duration.ofMillis((long) Integer.MAX_VALUE + 1000L);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisInt_clampsBelowIntMin() {
        final Duration duration = Duration.ofMillis((long) Integer.MIN_VALUE - 1000L);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisLong_null_throwsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisLong(null);
            }
        });
    }

    @Test
    void testToMillisLong_withinRange() {
        assertEquals(1234L, DurationUtils.toMillisLong(Duration.ofMillis(1234)));
        assertEquals(-1234L, DurationUtils.toMillisLong(Duration.ofMillis(-1234)));
    }

    @Test
    void testToMillisLong_clampsOnPositiveOverflow() {
        // Duration.toMillis() internally multiplies seconds by 1000, which overflows for Long.MAX_VALUE seconds.
        final Duration duration = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    void testToMillisLong_clampsOnNegativeOverflow() {
        final Duration duration = Duration.ofSeconds(Long.MIN_VALUE);
        assertTrue(duration.isNegative());
        assertEquals(Long.MIN_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    void testZeroIfNull_nullReturnsZero() {
        assertSame(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNull_nonNullReturnsSameInstance() {
        final Duration duration = Duration.ofMinutes(3);
        assertSame(duration, DurationUtils.zeroIfNull(duration));
    }
}
