/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

class NumberUtilsAgentTest {

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    void testCreateBigDecimalEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    @Test
    void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("255"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    @Test
    void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
    }

    @Test
    void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    void testCreateLongValid() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("  ");
            }
        });
    }

    @Test
    void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    void testCreateNumberLongRange() {
        final Number n = NumberUtils.createNumber("123456789012345");
        assertTrue(n instanceof Long);
        assertEquals(123456789012345L, n.longValue());
    }

    @Test
    void testCreateNumberBigIntegerRange() {
        final Number n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n instanceof BigInteger);
    }

    @Test
    void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    void testCreateNumberLongSuffixNonDigitThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    @Test
    void testCreateNumberHexInteger() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    void testCreateNumberHexLongSuffix() {
        final Number n = NumberUtils.createNumber("0xFFL");
        assertTrue(n instanceof Long);
        assertEquals(255L, n.longValue());
    }

    @Test
    void testCreateNumberDoubleExponent() {
        final Number n = NumberUtils.createNumber("1.5e10");
        assertTrue(n instanceof Double || n instanceof Float);
        assertEquals(1.5e10, n.doubleValue(), 1.0);
    }

    @Test
    void testCreateNumberInvalidDoubleExponentThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5e1.0e2");
            }
        });
    }

    @Test
    void testIsCreatableNull() {
        assertFalse(NumberUtils.isCreatable(null));
    }

    @Test
    void testIsCreatableEmpty() {
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
    }

    @Test
    void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    void testIsCreatableDecimalLeadingZero() {
        assertTrue(NumberUtils.isCreatable("0.1"));
    }

    @Test
    void testIsDigitsNull() {
        assertFalse(NumberUtils.isDigits(null));
    }

    @Test
    void testIsDigitsEmpty() {
        assertFalse(NumberUtils.isDigits(""));
    }

    @Test
    void testIsDigitsTrue() {
        assertTrue(NumberUtils.isDigits("12345"));
    }

    @Test
    void testIsDigitsFalse() {
        assertFalse(NumberUtils.isDigits("12a45"));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsNumberDelegatesToIsCreatable() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber(""));
    }

    @Test
    void testIsParsableNull() {
        assertFalse(NumberUtils.isParsable(null));
    }

    @Test
    void testIsParsableEmpty() {
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    void testIsParsableInteger() {
        assertTrue(NumberUtils.isParsable("123"));
    }

    @Test
    void testIsParsableDouble() {
        assertTrue(NumberUtils.isParsable("1.5e10"));
    }

    @Test
    void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("0x1A"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMaxByteThreeParam() {
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 9, (byte) 3));
        assertEquals((byte) 9, NumberUtils.max((byte) 9, (byte) 1, (byte) 3));
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 3, (byte) 9));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    void testMaxDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMaxDoubleThreeParam() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    void testMaxFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMaxFloatThreeParam() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(1, 9, 3));
    }

    @Test
    void testMaxIntThreeParam() {
        assertEquals(9, NumberUtils.max(1, 9, 3));
        assertEquals(9, NumberUtils.max(9, 1, 3));
        assertEquals(9, NumberUtils.max(1, 3, 9));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 3L));
    }

    @Test
    void testMaxLongThreeParam() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 3L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 3));
    }

    @Test
    void testMaxShortThreeParam() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 3));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMinByteThreeParam() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 9, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 9, (byte) 1, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 9, (byte) 3, (byte) 1));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    void testMinDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMinDoubleThreeParam() {
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0d);
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    void testMinFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMinFloatThreeParam() {
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0f);
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 9, 3));
    }

    @Test
    void testMinIntThreeParam() {
        assertEquals(1, NumberUtils.min(1, 9, 3));
        assertEquals(1, NumberUtils.min(9, 1, 3));
        assertEquals(1, NumberUtils.min(9, 3, 1));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 3L));
    }

    @Test
    void testMinLongThreeParam() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 3L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 3));
    }

    @Test
    void testMinShortThreeParam() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 3));
    }

    @Test
    void testToByteNull() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
    }

    @Test
    void testToByteEmpty() {
        assertEquals((byte) 0, NumberUtils.toByte(""));
    }

    @Test
    void testToByteValid() {
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
    }

    @Test
    void testToDoubleBigDecimalNull() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
    }

    @Test
    void testToDoubleBigDecimalValid() {
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToDoubleStringNull() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
    }

    @Test
    void testToDoubleStringEmpty() {
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
    }

    @Test
    void testToDoubleStringValid() {
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    void testToFloatNull() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
    }

    @Test
    void testToFloatEmpty() {
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
    }

    @Test
    void testToFloatValid() {
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    @Test
    void testToIntNull() {
        assertEquals(0, NumberUtils.toInt(null));
    }

    @Test
    void testToIntEmpty() {
        assertEquals(0, NumberUtils.toInt(""));
    }

    @Test
    void testToIntValid() {
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
    }

    @Test
    void testToLongNull() {
        assertEquals(0L, NumberUtils.toLong(null));
    }

    @Test
    void testToLongEmpty() {
        assertEquals(0L, NumberUtils.toLong(""));
    }

    @Test
    void testToLongValid() {
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    @Test
    void testToScaledBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    void testToScaledBigDecimalDefaultScale() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.5")));
    }

    @Test
    void testToScaledBigDecimalWithScaleAndRoundingMode() {
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalNullRoundingModeDefaultsToHalfEven() {
        assertEquals(new BigDecimal("2.5"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 1, null));
    }

    @Test
    void testToScaledBigDecimalDoubleNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
    }

    @Test
    void testToScaledBigDecimalDoubleValid() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.5d)));
    }

    @Test
    void testToScaledBigDecimalFloatNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
    }

    @Test
    void testToScaledBigDecimalFloatValid() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.5f)));
    }

    @Test
    void testToScaledBigDecimalStringNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    void testToScaledBigDecimalStringValid() {
        assertEquals(new BigDecimal("1.50"), NumberUtils.toScaledBigDecimal("1.5"));
    }

    @Test
    void testToShortNull() {
        assertEquals((short) 0, NumberUtils.toShort(null));
    }

    @Test
    void testToShortEmpty() {
        assertEquals((short) 0, NumberUtils.toShort(""));
    }

    @Test
    void testToShortValid() {
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
    }

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    @Test
    @SuppressWarnings("deprecation")
    void testConstructorExists() {
        assertEquals(NumberUtils.class, new NumberUtils().getClass());
    }
}
