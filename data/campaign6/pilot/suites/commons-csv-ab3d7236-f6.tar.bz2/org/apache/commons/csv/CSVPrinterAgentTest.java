/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

class CSVPrinterAgentTest {

    /** Appendable that also implements Closeable and Flushable, tracking calls, for close()/flush() tests. */
    private static final class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean flushed;
        private boolean closed;

        @Override
        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public void close() throws IOException {
            closed = true;
        }

        @Override
        public void flush() throws IOException {
            flushed = true;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    /** Appendable whose append() always fails, to verify IOException propagation. */
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }
    }

    @Test
    void constructorNullAppendableThrowsNPE() {
        assertThrows(NullPointerException.class, () -> new CSVPrinter(null, CSVFormat.DEFAULT));
    }

    @Test
    void constructorNullFormatThrowsNPE() {
        assertThrows(NullPointerException.class, () -> new CSVPrinter(new StringBuilder(), null));
    }

    @Test
    void getOutReturnsSameInstance() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertSame(sb, printer.getOut());
    }

    @Test
    void recordCountStartsAtZero() throws IOException {
        final CSVPrinter printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void constructorWithHeaderPrintsHeaderLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        new CSVPrinter(sb, format);
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void constructorWithHeaderDoesNotCountAsRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        // getRecordCount() javadoc: "this does not include comments or headers".
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void constructorSkipHeaderRecordDoesNotPrintHeader() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).get();
        new CSVPrinter(sb, format);
        assertEquals("", sb.toString());
    }

    @Test
    void constructorWithHeaderCommentsPrintsComments() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("c1", "c2").get();
        new CSVPrinter(sb, format);
        assertEquals("# c1\r\n# c2\r\n", sb.toString());
    }

    @Test
    void printSimpleValues() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        printer.println();
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void printValueNeedingQuotingIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    void printNullValuePrintsEmptyByDefault() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print(null);
        printer.print("x");
        assertEquals(",x", sb.toString());
    }

    @Test
    void printCommentDoesNothingWhenMarkerNotSet() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("hello");
        assertEquals("", sb.toString());
    }

    @Test
    void printCommentNullDoesNothingEvenWhenMarkerSet() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment(null);
        assertEquals("", sb.toString());
    }

    @Test
    void printCommentSingleLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("hello world");
        assertEquals("# hello world\r\n", sb.toString());
    }

    @Test
    void printCommentMultiLineSplitsIntoMultipleCommentLines() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    void printCommentDoesNotCountAsRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("hello");
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void printlnDoesNotIncrementRecordCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        printer.println();
        assertEquals(0, printer.getRecordCount());
        assertEquals("\r\n\r\n", sb.toString());
    }

    @Test
    void printRecordVarargsWritesDelimitedLineAndIncrementsCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("1", "2", "3");
        assertEquals("1,2,3\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordIterableWritesDelimitedLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordEmptyVarargsPrintsJustSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordMultipleCallsAccumulateCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a");
        printer.printRecord("b");
        printer.printRecord("c");
        assertEquals("a\r\nb\r\nc\r\n", sb.toString());
        assertEquals(3, printer.getRecordCount());
    }

    @Test
    void printRecordsVarargsWithNestedArraysPrintsMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "A", "B", "C" }, (Object) new String[] { "1", "2", "3" });
        assertEquals("A,B,C\r\n1,2,3\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordsIterableFlatPrintsSingleRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> flat = new ArrayList<String>();
        flat.add("a");
        flat.add("b");
        printer.printRecords(flat);
        assertEquals("a,b\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordsIterableOfIterablesPrintsOneRecordPerNestedElement() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<List<String>> data = new ArrayList<List<String>>();
        data.add(Arrays.asList("A", "B"));
        data.add(Arrays.asList("1", "2"));
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordStreamWritesSingleRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Stream.of("p", "q"));
        assertEquals("p,q\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordsStreamWithNestedArraysPrintsMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Stream.of(new String[] { "A", "B" }, new String[] { "1", "2" }));
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printPropagatesIOExceptionFromAppendable() {
        final ThrowingAppendable appendable = new ThrowingAppendable();
        assertThrows(IOException.class, () -> {
            final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
            printer.print("x");
        });
    }

    @Test
    void flushDelegatesToFlushableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.flushed);
        printer.flush();
        assertTrue(appendable.flushed);
    }

    @Test
    void closeWithoutAutoFlushDoesNotFlushButDoesClose() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
        assertFalse(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    void closeWithAutoFlushFormatFlushesBeforeClosing() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.close();
        assertTrue(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    void closeWithExplicitFlushFlagFlushesEvenWithoutAutoFlush() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(true);
        assertTrue(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    void closeOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.close();
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void printHeadersWritesColumnLabelsFromResultSetMetaData() throws Exception {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("col1");
        when(metaData.getColumnLabel(2)).thenReturn("col2");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printHeaders(resultSet);
        assertEquals("col1,col2\r\n", sb.toString());
        // Header printing must not count as a data record.
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void printRecordsResultSetWritesEachRowAndIncrementsCount() throws Exception {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(resultSet.next()).thenReturn(true, true, false);
        when(resultSet.getRow()).thenReturn(1, 2);
        when(resultSet.getObject(1)).thenReturn("1", "2");
        when(resultSet.getObject(2)).thenReturn("a", "b");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(resultSet);
        assertEquals("1,a\r\n2,b\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordsResultSetWithHeaderFlagPrintsHeaderThenRows() throws Exception {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("col");
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getRow()).thenReturn(1);
        when(resultSet.getObject(1)).thenReturn("val");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(resultSet, true);
        assertEquals("col\r\nval\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }
}
