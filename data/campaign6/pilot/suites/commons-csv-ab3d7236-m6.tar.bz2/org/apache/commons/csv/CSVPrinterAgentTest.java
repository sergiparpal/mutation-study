/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

public class CSVPrinterAgentTest {

    /**
     * Appendable that also tracks flush()/close() invocations, for tests that need to observe
     * those calls without depending on StringWriter's (silent) behavior.
     */
    private static final class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private int flushCount;
        private int closeCount;
        private boolean closed;

        @Override
        public Appendable append(final CharSequence csq) {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public Appendable append(final char c) {
            sb.append(c);
            return this;
        }

        @Override
        public void flush() {
            flushCount++;
        }

        @Override
        public void close() {
            closeCount++;
            closed = true;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    /** Appendable whose append() always fails, to verify IOException propagation. */
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }
    }

    @Test
    public void testConstructorNullAppendableThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testConstructorNullFormatThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringWriter(), null);
            }
        });
    }

    @Test
    public void testConstructorWritesHeaderImmediately() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("A,B\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testConstructorSkipHeaderRecordDoesNotWriteHeader() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").setSkipHeaderRecord(true).get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testConstructorWritesHeaderComments() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("line1", "line2").get();
        new CSVPrinter(sw, format);
        assertEquals("# line1\r\n# line2\r\n", sw.toString());
    }

    @Test
    public void testPrintSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sw.toString());
    }

    @Test
    public void testPrintNullValueIsEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintValueRequiringQuoting() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
    }

    @Test
    public void testPrintCommentNoOpWhenMarkerNotSet() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentNullIsNoOp() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentWithMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sw.toString());
    }

    @Test
    public void testPrintCommentMultilineSplitsLines() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sw.toString());
    }

    @Test
    public void testPrintCommentEmptyStringStillWritesMarker() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("");
        assertEquals("# \r\n", sw.toString());
    }

    @Test
    public void testPrintlnWritesSeparatorAndResetsNewRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a\r\nb", sw.toString());
    }

    @Test
    public void testGetOutReturnsSameAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
    }

    @Test
    public void testRecordCountInitiallyZero() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testRecordCountIgnoresCommentsAndPrintCalls() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("not a record");
        printer.print("value only, no record end");
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordEmptyVarargsStillEndsRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final Stream<String> stream = Arrays.asList("1", "2", "3").stream();
        printer.printRecord(stream);
        assertEquals("1,2,3\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsVarargsFlatTreatsEachElementAsOwnRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords("a", "b");
        assertEquals("a\r\nb\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsVarargsWithNestedArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "A", "B" }, (Object) new String[] { "1", "2" });
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsIterableWithNestedCollections() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object> data = new ArrayList<Object>();
        data.add(new String[] { "A", "B", "C" });
        data.add(Arrays.asList("1", "2", "3"));
        printer.printRecords(data);
        assertEquals("A,B,C\r\n1,2,3\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final Stream<Object> stream = Arrays.<Object>asList(new String[] { "A", "B" }, new String[] { "1", "2" }).stream();
        printer.printRecords(stream);
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsResultSet() throws Exception {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(resultSet.next()).thenReturn(true, true, false);
        when(resultSet.getRow()).thenReturn(1, 2);
        when(resultSet.getObject(1)).thenReturn("r1c1", "r2c1");
        when(resultSet.getObject(2)).thenReturn("r1c2", "r2c2");
        printer.printRecords(resultSet);
        assertEquals("r1c1,r1c2\r\nr2c1,r2c2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsResultSetWithHeaderTrue() throws Exception {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("COL1");
        when(metaData.getColumnLabel(2)).thenReturn("COL2");
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getRow()).thenReturn(1);
        when(resultSet.getObject(1)).thenReturn("v1");
        when(resultSet.getObject(2)).thenReturn("v2");
        printer.printRecords(resultSet, true);
        assertEquals("COL1,COL2\r\nv1,v2\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsResultSetWithHeaderFalseSkipsHeader() throws Exception {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(resultSet.next()).thenReturn(false);
        printer.printRecords(resultSet, false);
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintHeaders() throws Exception {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("NAME");
        when(metaData.getColumnLabel(2)).thenReturn("AGE");
        printer.printHeaders(resultSet);
        assertEquals("NAME,AGE\r\n", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testFlushDelegatesToFlushable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.flush();
        assertEquals(1, appendable.flushCount);
    }

    @Test
    public void testCloseWithoutAutoFlushDoesNotFlushButCloses() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
        assertEquals(0, appendable.flushCount);
        assertEquals(1, appendable.closeCount);
        assertTrue(appendable.closed);
    }

    @Test
    public void testCloseWithExplicitFlushTrueFlushesBeforeClosing() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(true);
        assertEquals(1, appendable.flushCount);
        assertEquals(1, appendable.closeCount);
    }

    @Test
    public void testCloseWithAutoFlushFormatFlushesEvenWithoutExplicitFlag() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.close();
        assertEquals(1, appendable.flushCount);
    }

    @Test
    public void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a");
        printer.close();
        assertEquals("a\r\n", sb.toString());
    }

    @Test
    public void testPrintPropagatesIOException() {
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVPrinter printer = new CSVPrinter(new ThrowingAppendable(), CSVFormat.DEFAULT);
                printer.print("boom");
            }
        });
    }

    @Test
    public void testPrintRecordPropagatesIOException() {
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVPrinter printer = new CSVPrinter(new ThrowingAppendable(), CSVFormat.DEFAULT);
                printer.printRecord("a", "b");
            }
        });
    }

    @Test
    public void testNewRecordFlagAfterPrintCommentAllowsFollowingValueWithoutLeadingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("c");
        printer.print("value");
        assertEquals("# c\r\nvalue", sw.toString());
    }

    @Test
    public void testPrintCommentAfterPartialRecordStartsNewLineFirst() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.printComment("c");
        assertEquals("a\r\n# c\r\n", sw.toString());
        assertFalse(printer.getOut().toString().isEmpty());
    }
}
