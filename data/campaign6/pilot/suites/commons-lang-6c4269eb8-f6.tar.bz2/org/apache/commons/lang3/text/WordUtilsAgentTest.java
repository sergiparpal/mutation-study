/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link WordUtils}.
 */
class WordUtilsAgentTest {

    // --- capitalize(String) ---

    @Test
    void testCapitalizeNull() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    void testCapitalizeEmpty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    void testCapitalizeBasic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    void testCapitalizeSingleWord() {
        assertEquals("Hello", WordUtils.capitalize("hello"));
    }

    @Test
    void testCapitalizeMultipleWhitespaceKinds() {
        assertEquals("Foo\tBar\nBaz", WordUtils.capitalize("foo\tbar\nbaz"));
    }

    // --- capitalize(String, char...) ---

    @Test
    void testCapitalizeWithDelimitersNull() {
        assertNull(WordUtils.capitalize(null, ' '));
    }

    @Test
    void testCapitalizeWithEmptyDelimiterArrayReturnsUnchanged() {
        final String str = "i am fine";
        assertEquals(str, WordUtils.capitalize(str, new char[0]));
    }

    @Test
    void testCapitalizeWithNullDelimitersUsesWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    void testCapitalizeWithCustomDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    // --- capitalizeFully(String) ---

    @Test
    void testCapitalizeFullyNull() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    void testCapitalizeFullyEmpty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    void testCapitalizeFullyBasic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // --- capitalizeFully(String, char...) ---

    @Test
    void testCapitalizeFullyWithNullDelimitersUsesWhitespace() {
        // null delimiters means whitespace-only, so the '.' is not a word boundary here
        assertEquals("I Am.fine", WordUtils.capitalizeFully("i aM.fine", (char[]) null));
    }

    @Test
    void testCapitalizeFullyWithEmptyDelimiterArrayReturnsUnchanged() {
        final String str = "i aM.fine";
        assertEquals(str, WordUtils.capitalizeFully(str, new char[0]));
    }

    @Test
    void testCapitalizeFullyWithCustomDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    // --- containsAllWords ---

    @Test
    void testContainsAllWordsNullWord() {
        assertFalse(WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    void testContainsAllWordsEmptyWord() {
        assertFalse(WordUtils.containsAllWords("", "ab"));
    }

    @Test
    void testContainsAllWordsNullWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    void testContainsAllWordsEmptyWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", new CharSequence[0]));
    }

    @Test
    void testContainsAllWordsPartialSubstringNotWord() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    void testContainsAllWordsAllPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    void testContainsAllWordsOneMissing() {
        assertFalse(WordUtils.containsAllWords("abc def", "def", "xyz"));
    }

    @Test
    void testContainsAllWordsBlankSearchWord() {
        assertFalse(WordUtils.containsAllWords("abc def", "abc", " "));
    }

    // --- initials(String) ---

    @Test
    void testInitialsNull() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    void testInitialsEmpty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    void testInitialsBasic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    void testInitialsWithDotNotWhitespace() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    @Test
    void testInitialsSingleWord() {
        assertEquals("H", WordUtils.initials("Hello"));
    }

    // --- initials(String, char...) ---

    @Test
    void testInitialsWithDelimitersNull() {
        assertNull(WordUtils.initials(null, ' '));
    }

    @Test
    void testInitialsWithEmptyDelimiterArrayReturnsEmptyString() {
        assertEquals("", WordUtils.initials("Ben J.Lee", new char[0]));
    }

    @Test
    void testInitialsWithNullDelimitersUsesWhitespace() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee", (char[]) null));
    }

    @Test
    void testInitialsWithCustomDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    void testInitialsWithSupplementaryCodePoint() {
        // supplementary character (surrogate pair) should be kept together as one initial
        final String str = "𐌀 Lee";
        final String result = WordUtils.initials(str);
        assertEquals("𐌀L", result);
    }

    // --- swapCase ---

    @Test
    void testSwapCaseNull() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    void testSwapCaseEmpty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    void testSwapCaseBasic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testSwapCaseLeadingLowercaseBecomesTitleCaseRestUppercase() {
        // first char of each word after whitespace/start -> title case, other lowercase chars -> upper case
        assertEquals("HELLO WORLD", WordUtils.swapCase("hello world"));
    }

    @Test
    void testSwapCaseNonLetterCharactersUnchanged() {
        assertEquals("123 !@#", WordUtils.swapCase("123 !@#"));
    }

    // --- uncapitalize(String) ---

    @Test
    void testUncapitalizeNull() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    void testUncapitalizeEmpty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    void testUncapitalizeBasic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // --- uncapitalize(String, char...) ---

    @Test
    void testUncapitalizeWithNullDelimitersUsesWhitespace() {
        // null delimiters means whitespace-only, so the '.' is not a word boundary here
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    void testUncapitalizeWithEmptyDelimiterArrayReturnsUnchanged() {
        final String str = "I AM.FINE";
        assertEquals(str, WordUtils.uncapitalize(str, new char[0]));
    }

    @Test
    void testUncapitalizeWithCustomDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    // --- wrap(String, int) ---

    @Test
    void testWrapNull() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    void testWrapEmpty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    void testWrapBasic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    void testWrapLongWordNotWrappedByDefault() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    void testWrapLongWordWrappedWhenRequested() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        // wrapLength=20 is "the column to wrap the words at": each wrapped chunk of the long
        // word must be exactly 20 columns, i.e. "https://commons.apac" (20 chars) then "he.org".
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    void testWrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("ab cd", 0, "\n", false);
        assertEquals("ab\ncd", result);
    }

    @Test
    void testWrapCustomNewLineString() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    // --- wrap(String, int, String, boolean, String) ---

    @Test
    void testWrapOnCustomPattern() {
        assertEquals("flammable\ninflammable", WordUtils.wrap("flammable/inflammable", 20, "\n", true, "/"));
    }

    @Test
    void testWrapOnBlankDefaultsToSpace() {
        final String input = "ab cd ef";
        assertEquals("ab\ncd\nef", WordUtils.wrap(input, 2, "\n", false, " "));
    }

    @Test
    void testWrapOnNullDefaultsToSpace() {
        final String input = "ab cd ef";
        assertEquals("ab\ncd\nef", WordUtils.wrap(input, 2, "\n", false, null));
    }

    @Test
    void testWrapNoWrapNeededShortString() {
        assertEquals("short", WordUtils.wrap("short", 20));
    }

    // --- constructor ---

    @Test
    void testPublicConstructor() {
        assertNotNull(new WordUtils());
    }
}
