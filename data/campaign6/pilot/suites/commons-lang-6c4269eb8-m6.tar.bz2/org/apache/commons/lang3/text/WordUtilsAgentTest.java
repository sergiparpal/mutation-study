/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link WordUtils}.
 */
public class WordUtilsAgentTest {

    // ---- capitalize(String) ----

    @Test
    public void testCapitalize_null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    public void testCapitalize_singleChar() {
        assertEquals("A", WordUtils.capitalize("a"));
    }

    @Test
    public void testCapitalize_withDelimiters() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", '.'));
    }

    @Test
    public void testCapitalize_nullDelimiters() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalize_emptyDelimiters() {
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalize(str, new char[0]));
    }

    // ---- capitalizeFully(String) ----

    @Test
    public void testCapitalizeFully_null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    @Test
    public void testCapitalizeFully_withDelimiters() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", '.'));
    }

    @Test
    public void testCapitalizeFully_emptyDelimiters() {
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalizeFully(str, new char[0]));
    }

    // ---- containsAllWords(CharSequence, CharSequence...) ----

    @Test
    public void testContainsAllWords_nullWord() {
        assertFalse(WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_emptyWord() {
        assertFalse(WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_nullWords() {
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_emptyWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def"));
    }

    @Test
    public void testContainsAllWords_substringDoesNotCount() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_allPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    public void testContainsAllWords_onePresentOneMissing() {
        assertFalse(WordUtils.containsAllWords("abc def", "abc", "xyz"));
    }

    @Test
    public void testContainsAllWords_blankSearchWord() {
        assertFalse(WordUtils.containsAllWords("abc def", "abc", " "));
    }

    // ---- initials(String) ----

    @Test
    public void testInitials_null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_dotNotDelimiterByDefault() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    @Test
    public void testInitials_withDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", ' ', '.'));
    }

    @Test
    public void testInitials_emptyDelimiterArray() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    @Test
    public void testInitials_nullDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitials_surrogatePairPreserved() {
        // high surrogate + low surrogate forming a single supplementary code point word
        final String supplementary = "😀 abc def";
        final String result = WordUtils.initials(supplementary);
        assertEquals(4, result.length());
        assertEquals(supplementary.charAt(0), result.charAt(0));
        assertEquals(supplementary.charAt(1), result.charAt(1));
        assertEquals('a', result.charAt(2));
        assertEquals('d', result.charAt(3));
    }

    // ---- swapCase(String) ----

    @Test
    public void testSwapCase_null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testSwapCase_nonLetterUnchanged() {
        assertEquals("123 !@#", WordUtils.swapCase("123 !@#"));
    }

    // ---- uncapitalize(String) ----

    @Test
    public void testUncapitalize_null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    @Test
    public void testUncapitalize_withDelimiters() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", '.'));
    }

    @Test
    public void testUncapitalize_emptyDelimiters() {
        final String str = "I Am Fine";
        assertSame(str, WordUtils.uncapitalize(str, new char[0]));
    }

    @Test
    public void testUncapitalize_nullDelimiters() {
        assertEquals("i am fine", WordUtils.uncapitalize("I Am Fine", (char[]) null));
    }

    // ---- wrap(String, int) ----

    @Test
    public void testWrap_null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap_empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_shortStringUnchanged() {
        assertEquals("short", WordUtils.wrap("short", 20));
    }

    @Test
    public void testWrap_zeroWrapLengthTreatedAsOne() {
        assertEquals(WordUtils.wrap("ab cd", 1), WordUtils.wrap("ab cd", 0));
    }

    @Test
    public void testWrap_negativeWrapLengthTreatedAsOne() {
        assertEquals(WordUtils.wrap("ab cd", 1), WordUtils.wrap("ab cd", -10));
    }

    // ---- wrap(String, int, String, boolean) ----

    @Test
    public void testWrapWithNewLineAndLongWords_customNewLine() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    public void testWrapWithNewLineAndLongWords_nullNewLineUsesSystemDefault() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, null, false));
    }

    @Test
    public void testWrapWithNewLineAndLongWords_longWordNotWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    public void testWrapWithNewLineAndLongWords_longWordWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    // ---- wrap(String, int, String, boolean, String) ----

    @Test
    public void testWrapFull_customWrapOn() {
        final String input = "flammable/inflammable";
        final String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    public void testWrapFull_blankWrapOnDefaultsToSpace() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of\ntext that is going\nto be wrapped after\n20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false, ""));
    }

    @Test
    public void testWrapFull_nullWrapOnDefaultsToSpace() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of\ntext that is going\nto be wrapped after\n20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false, null));
    }

    @Test
    public void testWrapFull_nullInput() {
        assertNull(WordUtils.wrap(null, 20, "\n", false, " "));
    }

    // ---- constructor ----

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new WordUtils());
    }
}
