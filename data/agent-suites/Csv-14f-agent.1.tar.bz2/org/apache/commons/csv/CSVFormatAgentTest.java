/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.sql.ResultSet;
import java.util.List;

import org.junit.Test;

/**
 * Additional tests for {@link CSVFormat}, focusing on the public API: predefined formats, the
 * {@code newFormat}/{@code valueOf} factories, the immutable {@code withXxx} builders (including their
 * validation), {@code equals}/{@code hashCode}/{@code toString}, and the {@code format}/{@code print}/{@code parse}
 * behavior.
 */
public class CSVFormatAgentTest {

    /** Mirrors the helper used by the existing CSVFormatTest: checks both directions. */
    private static void assertNotEquals(final Object a, final Object b) {
        assertFalse(a.equals(b));
        assertFalse(b.equals(a));
    }

    public enum HeaderEnum {
        Alpha, Beta, Gamma
    }

    public enum EmptyEnum {
    }

    // ----------------------------------------------------------------------------------------------
    // Predefined formats
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
    }

    @Test
    public void testRfc4180FormatProperties() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getQuoteMode());
        assertEquals("\r\n", format.getRecordSeparator());
        // RFC4180 differs from DEFAULT only by not ignoring empty lines.
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testMySqlFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals('\t', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
        assertEquals("\\N", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals("\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfFormatProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals('\t', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadFormatProperties() {
        final CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals('|', format.getDelimiter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormatProperties() {
        final CSVFormat format = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    // ----------------------------------------------------------------------------------------------
    // Predefined enum and valueOf
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testPredefinedEnumReturnsMatchingConstant() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertSame(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertSame(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertSame(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertSame(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertSame(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertSame(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
    }

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertSame(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValueOfWithUnknownNameThrows() {
        CSVFormat.valueOf("ThisFormatDoesNotExist");
    }

    // ----------------------------------------------------------------------------------------------
    // newFormat
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testNewFormatInitializesEverythingElseToNullOrFalse() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatWithLfDelimiterThrows() {
        CSVFormat.newFormat('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatWithCrDelimiterThrows() {
        CSVFormat.newFormat('\r');
    }

    // ----------------------------------------------------------------------------------------------
    // withXxx builders: happy path + immutability
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testWithDelimiterReturnsNewInstanceAndLeavesOriginalUnchanged() {
        final CSVFormat modified = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', modified.getDelimiter());
        assertEquals("original must be immutable", ',', CSVFormat.DEFAULT.getDelimiter());
        assertNotSame(CSVFormat.DEFAULT, modified);
    }

    @Test
    public void testWithMethodsChainAndDoNotMutateOriginal() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.withDelimiter(';').withTrim().withNullString("NIL");
        assertEquals(';', modified.getDelimiter());
        assertTrue(modified.getTrim());
        assertEquals("NIL", modified.getNullString());
        // original still has its defaults
        assertEquals(',', original.getDelimiter());
        assertFalse(original.getTrim());
        assertNull(original.getNullString());
    }

    @Test
    public void testWithQuoteCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());
    }

    @Test
    public void testWithQuoteDisabledByNull() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void testWithCommentMarkerCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    public void testWithCommentMarkerDisabledByNull() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
    }

    @Test
    public void testWithEscapeCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('&');
        assertEquals(Character.valueOf('&'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    public void testWithEscapeDisabledByNull() {
        final CSVFormat format = CSVFormat.MYSQL.withEscape((Character) null);
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithNullStringDisabledByNull() {
        final CSVFormat format = CSVFormat.MYSQL.withNullString(null);
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
    }

    @Test
    public void testWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
        assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
    }

    @Test
    public void testWithQuoteModeNoneRequiresEscapeCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        assertEquals("\r\n", CSVFormat.newFormat(',').withRecordSeparator("\r\n").getRecordSeparator());
    }

    @Test
    public void testWithSkipHeaderRecordToggles() {
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(true).withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithIgnoreEmptyLinesToggles() {
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).withIgnoreEmptyLines().getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesToggles() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).withIgnoreSurroundingSpaces(false)
                .getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithIgnoreHeaderCaseToggles() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    public void testWithTrailingDelimiterToggles() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(true).withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithTrimToggles() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(true).withTrim(false).getTrim());
    }

    @Test
    public void testWithAllowMissingColumnNamesToggles() {
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).withAllowMissingColumnNames(false)
                .getAllowMissingColumnNames());
    }

    // ----------------------------------------------------------------------------------------------
    // withXxx builders: validation / error cases
    // ----------------------------------------------------------------------------------------------

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterCrThrows() {
        CSVFormat.DEFAULT.withDelimiter('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterLfThrows() {
        CSVFormat.DEFAULT.withDelimiter('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteLineBreakThrows() {
        CSVFormat.DEFAULT.withQuote('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerLineBreakThrows() {
        CSVFormat.DEFAULT.withCommentMarker('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeLineBreakThrows() {
        CSVFormat.DEFAULT.withEscape('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteSameAsDelimiterThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withQuote('!');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEscapeSameAsDelimiterThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withEscape('!');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCommentMarkerSameAsDelimiterThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withCommentMarker('!');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteSameAsCommentMarkerThrows() {
        CSVFormat.DEFAULT.withQuote('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEscapeSameAsCommentMarkerThrows() {
        CSVFormat.DEFAULT.withEscape('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteModeNoneWithoutEscapeThrows() {
        CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderEntriesThrow() {
        CSVFormat.DEFAULT.withHeader("A", "B", "A");
    }

    // ----------------------------------------------------------------------------------------------
    // Header handling
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testWithHeaderCopiesInputAndOutput() {
        final String[] source = {"one", "two", "three"};
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(source);
        assertArrayEquals(source, format.getHeader());
        assertNotSame(source, format.getHeader());

        // Mutating the source array does not affect the stored header.
        source[0] = "mutated";
        assertArrayEquals(new String[] {"one", "two", "three"}, format.getHeader());

        // Mutating the returned array does not affect the stored header.
        final String[] returned = format.getHeader();
        returned[1] = "mutated";
        assertArrayEquals(new String[] {"one", "two", "three"}, format.getHeader());
    }

    @Test
    public void testWithHeaderNullDisablesHeader() {
        assertNull(CSVFormat.DEFAULT.withHeader((String[]) null).getHeader());
    }

    @Test
    public void testWithHeaderNoArgsProducesEmptyHeader() {
        final String[] header = CSVFormat.DEFAULT.withHeader().getHeader();
        assertEquals(0, header.length);
    }

    @Test
    public void testWithHeaderFromEnum() {
        assertArrayEquals(new String[] {"Alpha", "Beta", "Gamma"},
                CSVFormat.DEFAULT.withHeader(HeaderEnum.class).getHeader());
    }

    @Test
    public void testWithHeaderFromEmptyEnum() {
        assertEquals(0, CSVFormat.DEFAULT.withHeader(EmptyEnum.class).getHeader().length);
    }

    @Test
    public void testWithHeaderFromNullEnumDisablesHeader() {
        assertNull(CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null).getHeader());
    }

    @Test
    public void testWithHeaderFromNullResultSetDisablesHeader() throws Exception {
        assertNull(CSVFormat.DEFAULT.withHeader((ResultSet) null).getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testHeaderCommentsNullByDefault() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    public void testWithHeaderCommentsStringifiesAndCopies() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("comment 1", Integer.valueOf(2));
        assertArrayEquals(new String[] {"comment 1", "2"}, format.getHeaderComments());

        final String[] returned = format.getHeaderComments();
        returned[0] = "mutated";
        assertArrayEquals(new String[] {"comment 1", "2"}, format.getHeaderComments());
        assertNotSame(format.getHeaderComments(), format.getHeaderComments());
    }

    // ----------------------------------------------------------------------------------------------
    // equals / hashCode
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuote('"').withHeader("a", "b");
        assertEquals(format, format);
        assertEquals(format.hashCode(), format.hashCode());
    }

    @Test
    public void testEqualsRejectsNullAndForeignTypes() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertFalse(format.equals(null));
        assertFalse(format.equals("not a CSVFormat"));
        assertFalse(format.equals(Integer.valueOf(42)));
    }

    @Test
    public void testEqualFormatsHaveEqualHashCodes() {
        final CSVFormat a = CSVFormat.DEFAULT.withDelimiter(';').withHeader("x", "y").withNullString("NULL");
        final CSVFormat b = CSVFormat.DEFAULT.withDelimiter(';').withHeader("x", "y").withNullString("NULL");
        assertEquals(a, b);
        assertEquals(b, a);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotSame(a, b);
    }

    @Test
    public void testNotEqualWhenDelimiterDiffers() {
        assertNotEquals(CSVFormat.newFormat(','), CSVFormat.newFormat(';'));
    }

    @Test
    public void testNotEqualWhenQuoteCharacterDiffers() {
        assertNotEquals(CSVFormat.newFormat(',').withQuote('"'), CSVFormat.newFormat(',').withQuote('\''));
    }

    @Test
    public void testNotEqualWhenHeaderOrderDiffers() {
        assertNotEquals(CSVFormat.DEFAULT.withHeader("a", "b"), CSVFormat.DEFAULT.withHeader("b", "a"));
    }

    @Test
    public void testNotEqualWhenRecordSeparatorDiffers() {
        assertNotEquals(CSVFormat.newFormat(',').withRecordSeparator('\r'),
                CSVFormat.newFormat(',').withRecordSeparator('\n'));
    }

    @Test
    public void testNotEqualWhenNullStringDiffers() {
        assertNotEquals(CSVFormat.DEFAULT.withNullString("null"), CSVFormat.DEFAULT.withNullString("---"));
    }

    @Test
    public void testEqualWhenBothHaveNoQuote() {
        assertEquals(CSVFormat.newFormat(',').withQuote((Character) null),
                CSVFormat.newFormat(',').withQuote((Character) null));
    }

    @Test
    public void testNotEqualWhenOnlyOneHasQuote() {
        final CSVFormat noQuote = CSVFormat.newFormat(',').withQuote((Character) null);
        assertNotEquals(noQuote, noQuote.withQuote('#'));
    }

    // ----------------------------------------------------------------------------------------------
    // toString
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testToStringOfDefault() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s, s.startsWith("Delimiter=<,>"));
        assertTrue(s, s.contains("QuoteChar=<\">"));
        assertTrue(s, s.contains("RecordSeparator=<"));
        assertTrue(s, s.contains("EmptyLines:ignored"));
        assertTrue(s, s.contains("SkipHeaderRecord:false"));
        assertFalse(s, s.contains("Escape=<"));
        assertFalse(s, s.contains("CommentStart=<"));
        assertFalse(s, s.contains("NullString=<"));
    }

    @Test
    public void testToStringIncludesOptionalSettings() {
        final String s = CSVFormat.DEFAULT
                .withCommentMarker('#')
                .withEscape('!')
                .withNullString("NULL")
                .withHeader("h1", "h2")
                .toString();
        assertTrue(s, s.contains("CommentStart=<#>"));
        assertTrue(s, s.contains("Escape=<!>"));
        assertTrue(s, s.contains("NullString=<NULL>"));
        assertTrue(s, s.contains("Header:[h1, h2]"));
    }

    // ----------------------------------------------------------------------------------------------
    // format(Object...)
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testFormatWithNoValuesReturnsEmptyString() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    public void testFormatUsesCustomDelimiter() {
        assertEquals("a;b;c", CSVFormat.DEFAULT.withDelimiter(';').format("a", "b", "c"));
    }

    @Test
    public void testFormatWithQuoteModeAllQuotesEveryField() {
        assertEquals("\"a\",\"b\"", CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).format("a", "b"));
    }

    @Test
    public void testFormatWithQuoteModeNonNumericLeavesNumbersUnquoted() {
        assertEquals("\"a\",1",
                CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC).format("a", Integer.valueOf(1)));
    }

    @Test
    public void testFormatNullWithoutNullStringYieldsEmptyField() {
        assertEquals("a,,c", CSVFormat.DEFAULT.format("a", null, "c"));
    }

    @Test
    public void testFormatNullWithNullString() {
        assertEquals("a,N/A,c", CSVFormat.DEFAULT.withNullString("N/A").format("a", null, "c"));
    }

    @Test
    public void testFormatNullIsEmittedVerbatimNotEscaped() {
        // A null value is written as the null-string as-is, even when an escape character is configured.
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('\\').withNullString("\\N");
        assertEquals("\\N", format.format((Object) null));
    }

    // ----------------------------------------------------------------------------------------------
    // print / println / printRecord to an Appendable
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testPrintValueAsFirstFieldOfRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("hello", sb, true);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testPrintValuePrependsDelimiterWhenNotNewRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("x", sb, false);
        assertEquals(",x", sb.toString());
    }

    @Test
    public void testPrintDoublesEmbeddedQuoteAndEncapsulates() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a\"b", sb, true);
        assertEquals("\"a\"\"b\"", sb.toString());
    }

    @Test
    public void testPrintNullUsesNullString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withNullString("NIL").print(null, sb, true);
        assertEquals("NIL", sb.toString());
    }

    @Test
    public void testPrintTrimsWhenTrimEnabled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withTrim().print("  padded  ", sb, true);
        assertEquals("padded", sb.toString());
    }

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withTrailingDelimiter().println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordWritesValuesFollowedBySeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testPrintReturnsUsablePrinter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        try (CSVPrinter printer = CSVFormat.DEFAULT.print(sb)) {
            printer.printRecord("x", "y");
        }
        assertEquals("x,y\r\n", sb.toString());
    }

    // ----------------------------------------------------------------------------------------------
    // parse(Reader)
    // ----------------------------------------------------------------------------------------------

    @Test
    public void testParseReadsAllRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\nd,e,f\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(0).get(2));
            assertEquals("d", records.get(1).get(0));
            assertEquals("f", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithConfiguredHeaderMakesRecordsAddressableByName() throws IOException {
        final CSVParser parser =
                CSVFormat.DEFAULT.withHeader("A", "B").parse(new StringReader("1,2\r\n3,4\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("4", records.get(1).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseEmptyInputYieldsNoRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader(""));
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithIgnoreSurroundingSpacesStripsSpacesAroundValues() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces()
                .parse(new StringReader("  a  ,  b  "));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }
}
