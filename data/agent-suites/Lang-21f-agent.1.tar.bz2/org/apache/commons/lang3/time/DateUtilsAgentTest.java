/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import junit.framework.TestCase;

/**
 * Independent unit tests for {@link org.apache.commons.lang3.time.DateUtils}.
 *
 * <p>These exercise the public API surface directly: happy-path behaviour,
 * documented boundary conditions and the documented error cases (null
 * arguments, unsupported fields, wrong argument types, ...).  Assertions are
 * made on the returned values and on observable state (for example that the
 * argument passed in is never mutated), not merely that no exception was
 * thrown.</p>
 */
public class DateUtilsAgentTest extends TestCase {

    /** Pattern shared with {@code DateUtilsRoundingTest}. */
    private DateFormat parser;

    /** "March 28, 2002 13:45:01.231" - the value used by most rounding tests. */
    private static final String DT = "March 28, 2002 13:45:01.231";

    /** "June 1, 2008 8:15:14.231" - the value used by most add/set tests. */
    private static final String BASE = "June 1, 2008 8:15:14.231";

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        parser = new SimpleDateFormat("MMM dd, yyyy H:mm:ss.SSS", Locale.ENGLISH);
    }

    private Date parse(String dateStr) {
        try {
            return parser.parse(dateStr);
        } catch (ParseException ex) {
            throw new RuntimeException("bad test input: " + dateStr, ex);
        }
    }

    private static Calendar calendarOf(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    //-----------------------------------------------------------------------
    public void testConstructor() {
        assertNotNull(new DateUtils());
        Constructor<?>[] cons = DateUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(DateUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(DateUtils.class.getModifiers()));
    }

    public void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60L * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60L * 60L * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24L * 60L * 60L * 1000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals("GMT", DateUtils.UTC_TIME_ZONE.getID());
    }

    //-----------------------------------------------------------------------
    // isSameDay
    //-----------------------------------------------------------------------
    public void testIsSameDayDate() {
        Date d1 = parse("March 28, 2002 13:45:01.231");
        Date sameDayEarlier = parse("March 28, 2002 06:01:02.098");
        assertTrue(DateUtils.isSameDay(d1, sameDayEarlier));

        assertFalse(DateUtils.isSameDay(d1, parse("March 12, 2002 13:45:01.231")));
        // same day-of-month and month but a different year
        assertFalse(DateUtils.isSameDay(d1, parse("March 28, 2001 13:45:01.231")));

        try {
            DateUtils.isSameDay((Date) null, d1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameDay(d1, (Date) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIsSameDayCalendar() {
        Calendar c1 = Calendar.getInstance();
        c1.set(2002, Calendar.MARCH, 28, 13, 45, 1);
        Calendar c2 = Calendar.getInstance();
        c2.set(2002, Calendar.MARCH, 28, 6, 1, 2);
        assertTrue(DateUtils.isSameDay(c1, c2));

        c2.set(2002, Calendar.MARCH, 27, 6, 1, 2);
        assertFalse(DateUtils.isSameDay(c1, c2));

        try {
            DateUtils.isSameDay((Calendar) null, (Calendar) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameInstant
    //-----------------------------------------------------------------------
    public void testIsSameInstantDate() {
        assertTrue(DateUtils.isSameInstant(new Date(123456789L), new Date(123456789L)));
        assertFalse(DateUtils.isSameInstant(new Date(123456789L), new Date(123456790L)));

        try {
            DateUtils.isSameInstant((Date) null, new Date());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIsSameInstantCalendar() {
        Calendar plus1 = new GregorianCalendar(TimeZone.getTimeZone("GMT+1"));
        plus1.set(2004, Calendar.JULY, 9, 13, 45, 0);
        plus1.set(Calendar.MILLISECOND, 0);
        Calendar minus1 = new GregorianCalendar(TimeZone.getTimeZone("GMT-1"));
        minus1.set(2004, Calendar.JULY, 9, 11, 45, 0);
        minus1.set(Calendar.MILLISECOND, 0);

        // 13:45 at GMT+1 is the same instant as 11:45 at GMT-1
        assertTrue(DateUtils.isSameInstant(plus1, minus1));
        // ... but not the same local (wall clock) time
        assertFalse(DateUtils.isSameLocalTime(plus1, minus1));

        minus1.set(Calendar.MILLISECOND, 1);
        assertFalse(DateUtils.isSameInstant(plus1, minus1));

        try {
            DateUtils.isSameInstant((Calendar) null, plus1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameLocalTime
    //-----------------------------------------------------------------------
    public void testIsSameLocalTimeCalendar() {
        Calendar plus1 = new GregorianCalendar(TimeZone.getTimeZone("GMT+1"));
        plus1.set(2004, Calendar.JULY, 9, 13, 45, 0);
        plus1.set(Calendar.MILLISECOND, 0);
        Calendar minus1 = new GregorianCalendar(TimeZone.getTimeZone("GMT-1"));
        minus1.set(2004, Calendar.JULY, 9, 13, 45, 0);
        minus1.set(Calendar.MILLISECOND, 0);
        // identical wall-clock fields and identical concrete Calendar type
        assertTrue(DateUtils.isSameLocalTime(plus1, minus1));

        // 1am and 1pm share Calendar.HOUR but differ in Calendar.HOUR_OF_DAY
        Calendar am = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        am.set(2004, Calendar.JULY, 9, 1, 45, 0);
        am.set(Calendar.MILLISECOND, 0);
        Calendar pm = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        pm.set(2004, Calendar.JULY, 9, 13, 45, 0);
        pm.set(Calendar.MILLISECOND, 0);
        assertFalse(DateUtils.isSameLocalTime(am, pm));

        // same fields but different concrete Calendar type
        Calendar base = new GregorianCalendar();
        base.setTime(new Date(1157880845000L));
        Calendar subclass = new GregorianCalendar() {
            private static final long serialVersionUID = 1L;
        };
        subclass.setTime(new Date(1157880845000L));
        assertFalse(DateUtils.isSameLocalTime(base, subclass));

        try {
            DateUtils.isSameLocalTime(null, plus1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // parseDate / parseDateStrictly
    //-----------------------------------------------------------------------
    public void testParseDate() throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(1972, Calendar.NOVEMBER, 3);
        Date expected = cal.getTime();

        assertEquals(expected, DateUtils.parseDate("1972-11-03", "yyyy-MM-dd"));
        // the first pattern does not match, the second one does
        assertEquals(expected, DateUtils.parseDate("1972-11-03", "yyyy/MM/dd", "yyyy-MM-dd"));
    }

    public void testParseDateNoMatchingPattern() {
        try {
            DateUtils.parseDate("PURPLE", "yyyy/MM/dd");
            fail("expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    public void testParseDateNoPatternsSupplied() {
        try {
            DateUtils.parseDate("1972-11-03");
            fail("expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    public void testParseDateNullArguments() throws Exception {
        try {
            DateUtils.parseDate(null, "yyyy-MM-dd");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.parseDate("1972-11-03", (String[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testParseDateLenientVersusStrict() throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(1970, Calendar.JANUARY, 42);
        Date rolledOver = cal.getTime();

        // lenient parsing rolls the out-of-range day into the next month
        assertEquals(rolledOver, DateUtils.parseDate("1970-01-42", "yyyy-MM-dd"));

        // strict parsing rejects the same input
        try {
            DateUtils.parseDateStrictly("1970-01-42", "yyyy-MM-dd");
            fail("expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // addXxx
    //-----------------------------------------------------------------------
    public void testAddYears() {
        Date base = parse(BASE);
        Date result = DateUtils.addYears(base, 2);
        assertEquals(parse("June 1, 2010 8:15:14.231"), result);
        assertNotSame(base, result);
        assertEquals("argument must not be mutated", parse(BASE), base);
        assertEquals(parse("June 1, 2006 8:15:14.231"), DateUtils.addYears(base, -2));
        assertEquals(parse(BASE), DateUtils.addYears(base, 0));
    }

    public void testAddMonths() {
        Date base = parse(BASE);
        assertEquals(parse("July 1, 2008 8:15:14.231"), DateUtils.addMonths(base, 1));
        assertEquals(parse("May 1, 2008 8:15:14.231"), DateUtils.addMonths(base, -1));
        // rolls across the year boundary
        assertEquals(parse("January 1, 2009 8:15:14.231"), DateUtils.addMonths(base, 7));
    }

    public void testAddWeeks() {
        Date base = parse(BASE);
        assertEquals(parse("June 8, 2008 8:15:14.231"), DateUtils.addWeeks(base, 1));
        assertEquals(parse("May 25, 2008 8:15:14.231"), DateUtils.addWeeks(base, -1));
    }

    public void testAddDays() {
        Date base = parse(BASE);
        assertEquals(parse("June 2, 2008 8:15:14.231"), DateUtils.addDays(base, 1));
        assertEquals(parse("May 31, 2008 8:15:14.231"), DateUtils.addDays(base, -1));
    }

    public void testAddHours() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 9:15:14.231"), DateUtils.addHours(base, 1));
        // rolls back across midnight
        assertEquals(parse("May 31, 2008 23:15:14.231"), DateUtils.addHours(base, -9));
    }

    public void testAddMinutes() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 8:16:14.231"), DateUtils.addMinutes(base, 1));
        assertEquals(parse("June 1, 2008 7:15:14.231"), DateUtils.addMinutes(base, -60));
    }

    public void testAddSeconds() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 8:15:15.231"), DateUtils.addSeconds(base, 1));
        assertEquals(parse("June 1, 2008 8:14:14.231"), DateUtils.addSeconds(base, -60));
    }

    public void testAddMilliseconds() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 8:15:14.232"), DateUtils.addMilliseconds(base, 1));
        assertEquals(parse("June 1, 2008 8:15:14.031"), DateUtils.addMilliseconds(base, -200));
    }

    public void testAddMethodsRejectNull() {
        try { DateUtils.addYears(null, 1); fail("addYears"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addMonths(null, 1); fail("addMonths"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addWeeks(null, 1); fail("addWeeks"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addDays(null, 1); fail("addDays"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addHours(null, 1); fail("addHours"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addMinutes(null, 1); fail("addMinutes"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addSeconds(null, 1); fail("addSeconds"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addMilliseconds(null, 1); fail("addMilliseconds"); } catch (IllegalArgumentException ex) { /* expected */ }
    }

    //-----------------------------------------------------------------------
    // setXxx (uses a non-lenient calendar internally)
    //-----------------------------------------------------------------------
    public void testSetYears() {
        Date base = parse(BASE);
        Date result = DateUtils.setYears(base, 2000);
        assertEquals(parse("June 1, 2000 8:15:14.231"), result);
        assertNotSame(base, result);
        assertEquals("argument must not be mutated", parse(BASE), base);
    }

    public void testSetMonths() {
        Date base = parse(BASE);
        assertEquals(parse("January 1, 2008 8:15:14.231"), DateUtils.setMonths(base, Calendar.JANUARY));
        assertEquals(parse("December 1, 2008 8:15:14.231"), DateUtils.setMonths(base, Calendar.DECEMBER));
        try {
            DateUtils.setMonths(base, 12);
            fail("expected IllegalArgumentException for out-of-range month");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testSetDays() {
        Date base = parse(BASE);
        assertEquals(parse("June 30, 2008 8:15:14.231"), DateUtils.setDays(base, 30));
        try {
            DateUtils.setDays(base, 32);
            fail("expected IllegalArgumentException for out-of-range day");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.setDays(base, 0);
            fail("expected IllegalArgumentException for out-of-range day");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testSetHours() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 0:15:14.231"), DateUtils.setHours(base, 0));
        assertEquals(parse("June 1, 2008 23:15:14.231"), DateUtils.setHours(base, 23));
        try {
            DateUtils.setHours(base, 24);
            fail("expected IllegalArgumentException for out-of-range hour");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testSetMinutes() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 8:00:14.231"), DateUtils.setMinutes(base, 0));
        try {
            DateUtils.setMinutes(base, 60);
            fail("expected IllegalArgumentException for out-of-range minute");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testSetSeconds() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 8:15:00.231"), DateUtils.setSeconds(base, 0));
        try {
            DateUtils.setSeconds(base, 60);
            fail("expected IllegalArgumentException for out-of-range second");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testSetMilliseconds() {
        Date base = parse(BASE);
        assertEquals(parse("June 1, 2008 8:15:14.000"), DateUtils.setMilliseconds(base, 0));
        assertEquals(parse("June 1, 2008 8:15:14.999"), DateUtils.setMilliseconds(base, 999));
        try {
            DateUtils.setMilliseconds(base, 1000);
            fail("expected IllegalArgumentException for out-of-range millisecond");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testSetMethodsRejectNull() {
        try { DateUtils.setYears(null, 1); fail("setYears"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.setMonths(null, 1); fail("setMonths"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.setDays(null, 1); fail("setDays"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.setHours(null, 1); fail("setHours"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.setMinutes(null, 1); fail("setMinutes"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.setSeconds(null, 1); fail("setSeconds"); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.setMilliseconds(null, 1); fail("setMilliseconds"); } catch (IllegalArgumentException ex) { /* expected */ }
    }

    //-----------------------------------------------------------------------
    // toCalendar
    //-----------------------------------------------------------------------
    public void testToCalendar() {
        Date date = parse(BASE);
        Calendar cal = DateUtils.toCalendar(date);
        assertNotNull(cal);
        assertEquals(date, cal.getTime());
        assertEquals(date.getTime(), cal.getTimeInMillis());
    }

    public void testToCalendarNull() {
        try {
            DateUtils.toCalendar(null);
            fail("expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // round
    //-----------------------------------------------------------------------
    public void testRoundDate() {
        Date base = parse(DT);
        assertEquals(parse("March 28, 2002 13:45:01.000"), DateUtils.round(base, Calendar.SECOND));
        assertEquals(parse("March 28, 2002 13:45:00.000"), DateUtils.round(base, Calendar.MINUTE));
        assertEquals(parse("March 28, 2002 14:00:00.000"), DateUtils.round(base, Calendar.HOUR));
        assertEquals(parse("March 29, 2002 00:00:00.000"), DateUtils.round(base, Calendar.DATE));
        assertEquals(parse("April 1, 2002 00:00:00.000"), DateUtils.round(base, Calendar.MONTH));
        assertEquals(parse("January 1, 2002 00:00:00.000"), DateUtils.round(base, Calendar.YEAR));
        // October rounds the year up
        assertEquals(parse("January 1, 2003 00:00:00.000"),
                DateUtils.round(parse("October 28, 2002 13:45:01.231"), Calendar.YEAR));

        assertNotSame(base, DateUtils.round(base, Calendar.SECOND));
        assertEquals("argument must not be mutated", parse(DT), base);
    }

    public void testRoundHalfMillisecondBoundary() {
        // strictly below 500ms rounds down, 500ms and above rounds up
        assertEquals(parse("March 28, 2002 13:45:01.000"),
                DateUtils.round(parse("March 28, 2002 13:45:01.499"), Calendar.SECOND));
        assertEquals(parse("March 28, 2002 13:45:02.000"),
                DateUtils.round(parse("March 28, 2002 13:45:01.500"), Calendar.SECOND));
    }

    public void testRoundCalendar() {
        Calendar base = calendarOf(parse(DT));
        long originalMillis = base.getTimeInMillis();

        Calendar rounded = DateUtils.round(base, Calendar.HOUR);
        assertEquals(parse("March 28, 2002 14:00:00.000"), rounded.getTime());
        assertNotSame(base, rounded);
        assertEquals("argument calendar must not be mutated", originalMillis, base.getTimeInMillis());
    }

    public void testRoundObject() {
        Date date = parse(DT);
        Calendar cal = calendarOf(date);
        Date expected = parse("March 28, 2002 14:00:00.000");
        assertEquals(expected, DateUtils.round((Object) date, Calendar.HOUR));
        assertEquals(expected, DateUtils.round((Object) cal, Calendar.HOUR));
    }

    //-----------------------------------------------------------------------
    // truncate
    //-----------------------------------------------------------------------
    public void testTruncateDate() {
        Date base = parse(DT);
        assertEquals(parse("March 28, 2002 13:45:01.000"), DateUtils.truncate(base, Calendar.SECOND));
        assertEquals(parse("March 28, 2002 13:45:00.000"), DateUtils.truncate(base, Calendar.MINUTE));
        assertEquals(parse("March 28, 2002 13:00:00.000"), DateUtils.truncate(base, Calendar.HOUR));
        assertEquals(parse("March 28, 2002 00:00:00.000"), DateUtils.truncate(base, Calendar.DATE));
        assertEquals(parse("March 1, 2002 00:00:00.000"), DateUtils.truncate(base, Calendar.MONTH));
        assertEquals(parse("January 1, 2002 00:00:00.000"), DateUtils.truncate(base, Calendar.YEAR));
        assertEquals(parse("March 28, 2002 12:00:00.000"), DateUtils.truncate(base, Calendar.AM_PM));
        assertEquals(parse("March 16, 2002 00:00:00.000"), DateUtils.truncate(base, DateUtils.SEMI_MONTH));

        assertEquals("argument must not be mutated", parse(DT), base);
    }

    public void testTruncateCalendar() {
        Calendar base = calendarOf(parse(DT));
        long originalMillis = base.getTimeInMillis();

        Calendar truncated = DateUtils.truncate(base, Calendar.HOUR);
        assertEquals(parse("March 28, 2002 13:00:00.000"), truncated.getTime());
        assertNotSame(base, truncated);
        assertEquals("argument calendar must not be mutated", originalMillis, base.getTimeInMillis());
    }

    public void testTruncateObject() {
        Date date = parse(DT);
        Calendar cal = calendarOf(date);
        Date expected = parse("March 28, 2002 13:00:00.000");
        assertEquals(expected, DateUtils.truncate((Object) date, Calendar.HOUR));
        assertEquals(expected, DateUtils.truncate((Object) cal, Calendar.HOUR));
    }

    //-----------------------------------------------------------------------
    // ceiling
    //-----------------------------------------------------------------------
    public void testCeilingDate() {
        Date base = parse(DT);
        assertEquals(parse("March 28, 2002 13:45:02.000"), DateUtils.ceiling(base, Calendar.SECOND));
        assertEquals(parse("March 28, 2002 13:46:00.000"), DateUtils.ceiling(base, Calendar.MINUTE));
        assertEquals(parse("March 28, 2002 14:00:00.000"), DateUtils.ceiling(base, Calendar.HOUR));
        assertEquals(parse("March 29, 2002 00:00:00.000"), DateUtils.ceiling(base, Calendar.DATE));
        assertEquals(parse("April 1, 2002 00:00:00.000"), DateUtils.ceiling(base, Calendar.MONTH));
        assertEquals(parse("January 1, 2003 00:00:00.000"), DateUtils.ceiling(base, Calendar.YEAR));
        assertEquals(parse("March 29, 2002 00:00:00.000"), DateUtils.ceiling(base, Calendar.AM_PM));

        assertEquals("argument must not be mutated", parse(DT), base);
    }

    public void testCeilingCalendar() {
        Calendar base = calendarOf(parse(DT));
        long originalMillis = base.getTimeInMillis();

        Calendar ceiled = DateUtils.ceiling(base, Calendar.HOUR);
        assertEquals(parse("March 28, 2002 14:00:00.000"), ceiled.getTime());
        assertNotSame(base, ceiled);
        assertEquals("argument calendar must not be mutated", originalMillis, base.getTimeInMillis());
    }

    public void testCeilingObject() {
        Date date = parse(DT);
        Calendar cal = calendarOf(date);
        Date expected = parse("March 28, 2002 14:00:00.000");
        assertEquals(expected, DateUtils.ceiling((Object) date, Calendar.HOUR));
        assertEquals(expected, DateUtils.ceiling((Object) cal, Calendar.HOUR));
    }

    //-----------------------------------------------------------------------
    // round / truncate / ceiling - error handling
    //-----------------------------------------------------------------------
    public void testModifyMethodsRejectNull() {
        try { DateUtils.round((Date) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.round((Calendar) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.round((Object) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate((Date) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate((Calendar) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate((Object) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.ceiling((Date) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.ceiling((Calendar) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.ceiling((Object) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
    }

    public void testModifyMethodsRejectWrongType() {
        try { DateUtils.round("not a date", Calendar.SECOND); fail(); } catch (ClassCastException ex) { /* expected */ }
        try { DateUtils.truncate("not a date", Calendar.SECOND); fail(); } catch (ClassCastException ex) { /* expected */ }
        try { DateUtils.ceiling("not a date", Calendar.SECOND); fail(); } catch (ClassCastException ex) { /* expected */ }
    }

    public void testModifyMethodsRejectUnsupportedField() {
        Date base = parse(DT);
        try { DateUtils.round(base, -999); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate(base, -999); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.ceiling(base, -999); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
    }

    //-----------------------------------------------------------------------
    // iterator
    //-----------------------------------------------------------------------
    public void testIteratorWeekSunday() {
        Calendar focus = calendarOf(parse("July 4, 2002 12:00:00.000")); // a Thursday

        Iterator<?> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            Calendar day = (Calendar) it.next();
            if (first == null) {
                first = day;
            }
            last = day;
            count++;
        }
        assertEquals(7, count);
        assertEquals(parse("June 30, 2002 00:00:00.000"), first.getTime());
        assertEquals(parse("July 6, 2002 00:00:00.000"), last.getTime());

        try {
            it.next();
            fail("expected NoSuchElementException");
        } catch (NoSuchElementException ex) {
            // expected
        }
    }

    public void testIteratorWeekMondayFromDate() {
        Iterator<?> it = DateUtils.iterator(parse("July 4, 2002 12:00:00.000"),
                DateUtils.RANGE_WEEK_MONDAY);
        Calendar first = (Calendar) it.next();
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(parse("July 1, 2002 00:00:00.000"), first.getTime());
        assertEquals(parse("July 7, 2002 00:00:00.000"), last.getTime());
    }

    public void testIteratorRemoveUnsupported() {
        Iterator<?> it = DateUtils.iterator(parse("July 4, 2002 12:00:00.000"),
                DateUtils.RANGE_WEEK_CENTER);
        assertTrue(it.hasNext());
        it.next();
        try {
            it.remove();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    public void testIteratorErrors() {
        Calendar focus = calendarOf(parse("July 4, 2002 12:00:00.000"));
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("null Date");
        } catch (IllegalArgumentException ex) { /* expected */ }
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("null Calendar");
        } catch (IllegalArgumentException ex) { /* expected */ }
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("null Object");
        } catch (IllegalArgumentException ex) { /* expected */ }
        try {
            DateUtils.iterator(focus, -1);
            fail("invalid range style");
        } catch (IllegalArgumentException ex) { /* expected */ }
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("wrong type");
        } catch (ClassCastException ex) { /* expected */ }
    }

    //-----------------------------------------------------------------------
    // getFragmentInXxx
    //-----------------------------------------------------------------------
    private Date fragmentDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        cal.set(Calendar.MILLISECOND, 538);
        return cal.getTime();
    }

    public void testGetFragmentInMilliseconds() {
        Date date = fragmentDate();
        Calendar cal = calendarOf(date);

        assertEquals(538L, DateUtils.getFragmentInMilliseconds(date, Calendar.SECOND));
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(10L * DateUtils.MILLIS_PER_SECOND + 538L,
                DateUtils.getFragmentInMilliseconds(date, Calendar.MINUTE));
        assertEquals(15L * DateUtils.MILLIS_PER_MINUTE + 10L * DateUtils.MILLIS_PER_SECOND + 538L,
                DateUtils.getFragmentInMilliseconds(date, Calendar.HOUR_OF_DAY));
        // a millisecond cannot be broken down into milliseconds
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(date, Calendar.MILLISECOND));
    }

    public void testGetFragmentInSeconds() {
        Date date = fragmentDate();
        Calendar cal = calendarOf(date);

        assertEquals(10L, DateUtils.getFragmentInSeconds(date, Calendar.MINUTE));
        assertEquals(10L, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
        assertEquals(7L * 3600L + 15L * 60L + 10L,
                DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
        assertEquals(0L, DateUtils.getFragmentInSeconds(date, Calendar.SECOND));
    }

    public void testGetFragmentInMinutes() {
        Date date = fragmentDate();
        Calendar cal = calendarOf(date);

        assertEquals(15L, DateUtils.getFragmentInMinutes(date, Calendar.HOUR_OF_DAY));
        assertEquals(15L, DateUtils.getFragmentInMinutes(cal, Calendar.HOUR_OF_DAY));
        assertEquals(7L * 60L + 15L, DateUtils.getFragmentInMinutes(date, Calendar.DATE));
        assertEquals(0L, DateUtils.getFragmentInMinutes(date, Calendar.MINUTE));
    }

    public void testGetFragmentInHours() {
        Date date = fragmentDate();
        Calendar cal = calendarOf(date);

        assertEquals(7L, DateUtils.getFragmentInHours(date, Calendar.DATE));
        assertEquals(7L, DateUtils.getFragmentInHours(cal, Calendar.DATE));
        // day-of-month 6 contributes 6*24 hours when the fragment is the month
        assertEquals(6L * 24L + 7L, DateUtils.getFragmentInHours(date, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInHours(date, Calendar.HOUR_OF_DAY));
    }

    public void testGetFragmentInDays() {
        Date date = fragmentDate();
        Calendar cal = calendarOf(date);

        assertEquals(6L, DateUtils.getFragmentInDays(date, Calendar.MONTH));
        assertEquals(6L, DateUtils.getFragmentInDays(cal, Calendar.MONTH));
        assertEquals(6L, DateUtils.getFragmentInDays(date, Calendar.YEAR));
        assertEquals(0L, DateUtils.getFragmentInDays(date, Calendar.DATE));
    }

    public void testGetFragmentRejectsNull() {
        try { DateUtils.getFragmentInMilliseconds((Date) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.getFragmentInSeconds((Calendar) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.getFragmentInMinutes((Date) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.getFragmentInHours((Calendar) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.getFragmentInDays((Date) null, Calendar.SECOND); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
    }

    public void testGetFragmentRejectsUnsupportedFragment() {
        Date date = fragmentDate();
        Calendar cal = calendarOf(date);
        // Calendar.ERA == 0 is not a supported fragment
        try { DateUtils.getFragmentInMilliseconds(date, 0); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.getFragmentInDays(cal, 0); fail(); } catch (IllegalArgumentException ex) { /* expected */ }
    }

    //-----------------------------------------------------------------------
    // truncatedEquals / truncatedCompareTo
    //-----------------------------------------------------------------------
    public void testTruncatedEqualsAndCompareToDate() {
        Date d1 = parse("March 28, 2002 13:45:01.231");
        Date d2 = parse("March 28, 2002 13:45:59.999");

        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.SECOND));
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.MINUTE));
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR));

        assertTrue(DateUtils.truncatedCompareTo(d1, d2, Calendar.SECOND) < 0);
        assertTrue(DateUtils.truncatedCompareTo(d2, d1, Calendar.SECOND) > 0);
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.MINUTE));
    }

    public void testTruncatedEqualsAndCompareToCalendar() {
        Calendar c1 = calendarOf(parse("March 28, 2002 13:45:01.231"));
        Calendar c2 = calendarOf(parse("March 28, 2002 13:45:59.999"));

        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.SECOND));
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.MINUTE));
        assertTrue(DateUtils.truncatedCompareTo(c1, c2, Calendar.SECOND) < 0);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.MINUTE));
    }

    public void testTruncatedEqualsRejectsNull() {
        Date d = parse(DT);
        try {
            DateUtils.truncatedEquals((Date) null, d, Calendar.SECOND);
            fail("null Date");
        } catch (IllegalArgumentException ex) { /* expected */ }
        try {
            DateUtils.truncatedEquals((Calendar) null, Calendar.getInstance(), Calendar.SECOND);
            fail("null Calendar");
        } catch (IllegalArgumentException ex) { /* expected */ }
        try {
            DateUtils.truncatedCompareTo((Date) null, d, Calendar.SECOND);
            fail("null Date");
        } catch (IllegalArgumentException ex) { /* expected */ }
    }
}
