package org.apache.commons.cli;

import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Comparator;

/**
 * Self-contained JUnit 3 tests for {@link HelpFormatter}, based solely on the
 * documented contract in api/org/apache/commons/cli/HelpFormatter.html.
 */
public class HelpFormatterAgentTest extends TestCase {

    private HelpFormatter formatter;

    protected void setUp() throws Exception {
        super.setUp();
        formatter = new HelpFormatter();
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private static String[] splitLines(String s) {
        return s.split("\r\n|\n|\r");
    }

    // ------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------

    public void testConstantValues() {
        assertEquals(74, HelpFormatter.DEFAULT_WIDTH);
        assertEquals(1, HelpFormatter.DEFAULT_LEFT_PAD);
        assertEquals(3, HelpFormatter.DEFAULT_DESC_PAD);
        assertEquals("usage: ", HelpFormatter.DEFAULT_SYNTAX_PREFIX);
        assertEquals("-", HelpFormatter.DEFAULT_OPT_PREFIX);
        assertEquals("--", HelpFormatter.DEFAULT_LONG_OPT_PREFIX);
        assertEquals(" ", HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR);
        assertEquals("arg", HelpFormatter.DEFAULT_ARG_NAME);
    }

    // ------------------------------------------------------------------
    // Default state after construction (names/docs of DEFAULT_* constants
    // explicitly describe them as the defaults used by a new instance)
    // ------------------------------------------------------------------

    public void testDefaultConstructorState() {
        assertEquals(HelpFormatter.DEFAULT_WIDTH, formatter.getWidth());
        assertEquals(HelpFormatter.DEFAULT_LEFT_PAD, formatter.getLeftPadding());
        assertEquals(HelpFormatter.DEFAULT_DESC_PAD, formatter.getDescPadding());
        assertEquals(HelpFormatter.DEFAULT_SYNTAX_PREFIX, formatter.getSyntaxPrefix());
        assertEquals(HelpFormatter.DEFAULT_OPT_PREFIX, formatter.getOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_PREFIX, formatter.getLongOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR, formatter.getLongOptSeparator());
        assertEquals(HelpFormatter.DEFAULT_ARG_NAME, formatter.getArgName());
        assertNotNull(formatter.getNewLine());
        assertNotNull(formatter.getOptionComparator());
    }

    // ------------------------------------------------------------------
    // Simple setter/getter round trips
    // ------------------------------------------------------------------

    public void testSetGetWidth() {
        formatter.setWidth(50);
        assertEquals(50, formatter.getWidth());
        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());
        formatter.setWidth(-5);
        assertEquals(-5, formatter.getWidth());
    }

    public void testSetGetLeftPadding() {
        formatter.setLeftPadding(4);
        assertEquals(4, formatter.getLeftPadding());
        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());
    }

    public void testSetGetDescPadding() {
        formatter.setDescPadding(7);
        assertEquals(7, formatter.getDescPadding());
        formatter.setDescPadding(0);
        assertEquals(0, formatter.getDescPadding());
    }

    public void testSetGetSyntaxPrefix() {
        formatter.setSyntaxPrefix("call: ");
        assertEquals("call: ", formatter.getSyntaxPrefix());
    }

    public void testSetGetNewLine() {
        formatter.setNewLine("\r\n");
        assertEquals("\r\n", formatter.getNewLine());
        formatter.setNewLine("\n");
        assertEquals("\n", formatter.getNewLine());
    }

    public void testSetGetOptPrefix() {
        formatter.setOptPrefix("/");
        assertEquals("/", formatter.getOptPrefix());
    }

    public void testSetGetLongOptPrefix() {
        formatter.setLongOptPrefix("++");
        assertEquals("++", formatter.getLongOptPrefix());
    }

    public void testSetGetLongOptSeparator() {
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR, formatter.getLongOptSeparator());
        formatter.setLongOptSeparator("=");
        assertEquals("=", formatter.getLongOptSeparator());
    }

    public void testSetGetArgName() {
        formatter.setArgName("value");
        assertEquals("value", formatter.getArgName());
    }

    // ------------------------------------------------------------------
    // optionComparator: documented default is "case-insensitive alphabetical
    // sorting by option key"; setOptionComparator(null) "will set the
    // ordering to the default mode".
    // ------------------------------------------------------------------

    public void testOptionComparatorDefaultIsCaseInsensitiveAlphabetical() {
        Options options = new Options();
        options.addOption("B", false, "Beta option");
        options.addOption("a", false, "Alpha option");

        StringBuffer rendered = formatter.renderOptions(
                new StringBuffer(), 80, options, 1, 3);
        String text = rendered.toString();

        int idxA = text.indexOf("-a");
        int idxB = text.indexOf("-B");
        assertTrue("expected both options rendered", idxA >= 0 && idxB >= 0);
        assertTrue("expected case-insensitive alphabetical order (a before B)", idxA < idxB);
    }

    public void testOptionComparatorCustomAndNullReset() {
        Options options = new Options();
        options.addOption("b", false, "Beta option");
        options.addOption("a", false, "Alpha option");

        // default: alphabetical, a before b
        String defaultOrder = formatter.renderOptions(new StringBuffer(), 80, options, 1, 3).toString();
        assertTrue(defaultOrder.indexOf("-a") < defaultOrder.indexOf("-b"));

        Comparator reverse = new Comparator() {
            public int compare(Object o1, Object o2) {
                Option opt1 = (Option) o1;
                Option opt2 = (Option) o2;
                return opt2.getOpt().compareTo(opt1.getOpt());
            }
        };
        formatter.setOptionComparator(reverse);
        assertSame(reverse, formatter.getOptionComparator());

        String reversedOrder = formatter.renderOptions(new StringBuffer(), 80, options, 1, 3).toString();
        assertTrue(reversedOrder.indexOf("-b") < reversedOrder.indexOf("-a"));

        formatter.setOptionComparator(null);
        String resetOrder = formatter.renderOptions(new StringBuffer(), 80, options, 1, 3).toString();
        assertTrue("null comparator should reset to default alphabetical order",
                resetOrder.indexOf("-a") < resetOrder.indexOf("-b"));
    }

    // ------------------------------------------------------------------
    // createPadding(int): "Return a String of padding of length len."
    // ------------------------------------------------------------------

    public void testCreatePadding() {
        assertEquals("", formatter.createPadding(0));

        String padding = formatter.createPadding(5);
        assertEquals(5, padding.length());
        assertEquals(0, padding.trim().length());
    }

    // ------------------------------------------------------------------
    // rtrim(String): "Remove the trailing whitespace from the specified
    // String."
    // ------------------------------------------------------------------

    public void testRtrim() {
        assertEquals("hello", formatter.rtrim("hello   "));
        assertEquals("hello", formatter.rtrim("hello"));
        assertEquals("", formatter.rtrim(""));
        assertEquals("", formatter.rtrim("   "));
        assertEquals("  hello", formatter.rtrim("  hello  "));
        assertEquals("a\tb", formatter.rtrim("a\tb\t"));
    }

    // ------------------------------------------------------------------
    // findWrapPos(String text, int width, int startPos)
    // ------------------------------------------------------------------

    public void testFindWrapPosNoWrapNeededWhenTextFitsExactly() {
        // "hello" has length 5, width 5 starting at 0: no whitespace at all,
        // so the implied wrap position equals text.length() -> documented
        // as returning -1 ("at the end of the text").
        assertEquals(-1, formatter.findWrapPos("hello", 5, 0));
    }

    public void testFindWrapPosHardBreakWhenNoWhitespaceAvailable() {
        // No whitespace anywhere in the text and text is longer than the
        // window, so the wrap position is exactly startPos + width.
        assertEquals(4, formatter.findWrapPos("abcdefghij", 4, 0));
    }

    public void testFindWrapPosPicksLastWhitespaceBeforeBoundary() {
        // "a b cdefgh": whitespace at index 1 and 3; boundary is 6, so the
        // last (rightmost) whitespace strictly before 6 is index 3.
        assertEquals(3, formatter.findWrapPos("a b cdefgh", 6, 0));
    }

    public void testFindWrapPosWithNonZeroStartPos() {
        // "xxxx aaa bbb": whitespace at index 4 and 8; startPos=5, width=5
        // gives boundary 10, so the wrap position is index 8.
        assertEquals(8, formatter.findWrapPos("xxxx aaa bbb", 5, 5));
    }

    // ------------------------------------------------------------------
    // renderWrappedText(StringBuffer, int width, int nextLineTabStop,
    // String text)
    // ------------------------------------------------------------------

    public void testRenderWrappedTextAppendsWithoutWrappingWhenTextFits() {
        StringBuffer sb = new StringBuffer("PRE:");
        StringBuffer result = formatter.renderWrappedText(sb, 20, 0, "short");
        assertSame(sb, result);
        assertEquals("PRE:short", result.toString());
    }

    public void testRenderWrappedTextWrapsAndPreservesContent() {
        String original = "alpha beta gamma delta epsilon zeta eta theta";
        StringBuffer result = formatter.renderWrappedText(new StringBuffer(), 10, 0, original);
        String rendered = result.toString();

        String[] lines = splitLines(rendered);
        assertTrue("expected the text to be wrapped onto multiple lines", lines.length > 1);

        StringBuffer rebuilt = new StringBuffer();
        for (int i = 0; i < lines.length; i++) {
            String trimmed = lines[i].trim();
            assertTrue("line should respect the requested width: [" + lines[i] + "]",
                    lines[i].length() <= 10);
            if (trimmed.length() > 0) {
                if (rebuilt.length() > 0) {
                    rebuilt.append(' ');
                }
                rebuilt.append(trimmed);
            }
        }
        assertEquals(original, rebuilt.toString());
    }

    public void testRenderWrappedTextIndentsContinuationLines() {
        String original = "alpha beta gamma delta epsilon zeta eta theta";
        StringBuffer result = formatter.renderWrappedText(new StringBuffer(), 10, 4, original);
        String[] lines = splitLines(result.toString());
        assertTrue(lines.length > 1);

        String padding = formatter.createPadding(4);
        for (int i = 1; i < lines.length; i++) {
            assertTrue("continuation line should start with next-line-tab-stop padding: [" + lines[i] + "]",
                    lines[i].startsWith(padding));
        }
    }

    // ------------------------------------------------------------------
    // renderOptions(StringBuffer, int width, Options, int leftPad, int descPad)
    // ------------------------------------------------------------------

    public void testRenderOptionsReturnsSameBufferAndIncludesFlagsAndDescriptions() {
        Options options = new Options();
        options.addOption("a", false, "Alpha option description");

        StringBuffer sb = new StringBuffer();
        StringBuffer result = formatter.renderOptions(sb, 80, options, 1, 3);

        assertSame(sb, result);
        String text = result.toString();
        assertTrue(text.indexOf("-a") >= 0);
        assertTrue(text.indexOf("Alpha option description") >= 0);
    }

    public void testRenderOptionsIncludesLongOptionWithPrefix() {
        Options options = new Options();
        options.addOption("c", "ccc", false, "Long option description");

        String text = formatter.renderOptions(new StringBuffer(), 80, options, 1, 3).toString();
        assertTrue(text.indexOf(formatter.getLongOptPrefix() + "ccc") >= 0);
    }

    // ------------------------------------------------------------------
    // printOptions(PrintWriter, int width, Options, int leftPad, int descPad)
    // ------------------------------------------------------------------

    public void testPrintOptionsWritesOnlyTheOptionsSection() {
        Options options = new Options();
        options.addOption("a", false, "Alpha option description");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printOptions(pw, 80, options, 1, 3);
        pw.flush();

        String text = sw.toString();
        assertTrue(text.indexOf("-a") >= 0);
        assertTrue(text.indexOf("Alpha option description") >= 0);
        assertTrue("printOptions should not include a usage line",
                text.indexOf(formatter.getSyntaxPrefix()) < 0);
    }

    // ------------------------------------------------------------------
    // printUsage
    // ------------------------------------------------------------------

    public void testPrintUsageWritesSyntaxPrefixedLine() {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printUsage(pw, 80, "myapp -a -b");
        pw.flush();

        String expected = formatter.getSyntaxPrefix() + "myapp -a -b" + formatter.getNewLine();
        assertEquals(expected, sw.toString());
    }

    public void testPrintUsageWithOptionsIncludesAppNameAndOptionFlag() {
        Options options = new Options();
        options.addOption("a", false, "Alpha option description");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printUsage(pw, 80, "myapp", options);
        pw.flush();

        String text = sw.toString();
        assertTrue(text.startsWith(formatter.getSyntaxPrefix() + "myapp"));
        assertTrue(text.indexOf("-a") >= 0);
    }

    // ------------------------------------------------------------------
    // printWrapped
    // ------------------------------------------------------------------

    public void testPrintWrappedShortTextIsUnchanged() {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printWrapped(pw, 40, "short text");
        pw.flush();

        assertEquals("short text", sw.toString().trim());
    }

    public void testPrintWrappedLongTextIsWrappedWithoutDataLoss() {
        String original = "alpha beta gamma delta epsilon zeta eta theta";
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printWrapped(pw, 10, original);
        pw.flush();

        String[] lines = splitLines(sw.toString());
        StringBuffer rebuilt = new StringBuffer();
        for (int i = 0; i < lines.length; i++) {
            String trimmed = lines[i].trim();
            if (trimmed.length() > 0) {
                if (rebuilt.length() > 0) {
                    rebuilt.append(' ');
                }
                rebuilt.append(trimmed);
            }
        }
        assertEquals(original, rebuilt.toString());
    }

    // ------------------------------------------------------------------
    // printHelp
    // ------------------------------------------------------------------

    public void testPrintHelpToSystemOutIncludesUsageAndOptions() {
        Options options = new Options();
        options.addOption("a", false, "Alpha option description");

        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        String text;
        try {
            System.setOut(new PrintStream(baos));
            formatter.printHelp("myapp", options);
        } finally {
            System.setOut(originalOut);
        }
        text = baos.toString();

        assertEquals(0, text.indexOf(formatter.getSyntaxPrefix() + "myapp"));
        assertTrue(text.indexOf("-a") > 0);
        assertTrue(text.indexOf("Alpha option description") > 0);
    }

    public void testPrintHelpAutoUsageFalseDoesNotAppendFlagsToUsageLine() {
        Options options = new Options();
        options.addOption("a", false, "Alpha option description");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printHelp(pw, 80, "myapp", "", options, 1, 3, "", false);
        pw.flush();
        String text = sw.toString();

        int idx = text.indexOf(formatter.getSyntaxPrefix());
        assertTrue(idx >= 0);
        int lineEnd = text.indexOf('\n', idx);
        if (lineEnd < 0) {
            lineEnd = text.length();
        }
        String usageLine = text.substring(idx, lineEnd).trim();
        assertEquals((formatter.getSyntaxPrefix() + "myapp").trim(), usageLine);

        // the option is still listed later, in the options section
        assertTrue(text.indexOf("-a") > idx);
    }

    public void pruned_testPrintHelpOrdersUsageHeaderOptionsFooter() {
        Options options = new Options();
        options.addOption("a", false, "Alpha option description");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        formatter.printHelp(pw, 80, "myapp", "HEADERTEXT", options, 1, 3, "FOOTERTEXT", true);
        pw.flush();
        String text = sw.toString();

        int idxUsage = text.indexOf(formatter.getSyntaxPrefix());
        int idxHeader = text.indexOf("HEADERTEXT");
        int idxFlag = text.indexOf("-a");
        int idxDesc = text.indexOf("Alpha option description");
        int idxFooter = text.indexOf("FOOTERTEXT");

        assertTrue(idxUsage >= 0);
        assertTrue(idxHeader > idxUsage);
        assertTrue(idxFlag > idxHeader);
        assertTrue(idxDesc >= idxFlag);
        assertTrue(idxFooter > idxDesc);
    }

    public void pruned_testPrintHelpThrowsIllegalStateExceptionWhenNoRoomToPrintLine() {
        Options options = new Options();
        options.addOption("a", false, "Some description text that is fairly long");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        try {
            formatter.printHelp(pw, 1, "x", "", options, 5, 3, "");
            fail("expected IllegalStateException when there is no room to print a line");
        } catch (IllegalStateException expected) {
            // documented behavior
        }
    }
}
