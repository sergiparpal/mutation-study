package org.apache.commons.lang;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.Test;

/**
 * Self-contained JUnit 4 tests for {@link org.apache.commons.lang.StringEscapeUtils}.
 *
 * <p>Every expectation below is derived from the published javadoc contract shipped
 * in {@code api/org/apache/commons/lang/StringEscapeUtils.html}. Where the javadoc
 * flags behaviour as unstable (for example the {@code \\u} escaping of non-ASCII
 * characters by {@code escapeXml}/{@code unescapeXml}) no exact value is asserted.</p>
 *
 * <p>The source is kept pure ASCII; the few non-ASCII characters that the contract
 * mentions ("funky accents") are built from their code points via {@link #ch(int)}.</p>
 */
public class StringEscapeUtilsAgentTest {

    /** LATIN SMALL LETTER E WITH ACUTE. */
    private static final String E_ACUTE = ch(0x00E9);
    /** LATIN SMALL LETTER E WITH GRAVE. */
    private static final String E_GRAVE = ch(0x00E8);
    /** LATIN SMALL LETTER C WITH CEDILLA. */
    private static final String C_CEDIL = ch(0x00E7);
    /** COPYRIGHT SIGN. */
    private static final String COPYRIGHT = ch(0x00A9);

    /** Builds a one-character String from a code point, keeping this file ASCII-only. */
    private static String ch(int codePoint) {
        return String.valueOf((char) codePoint);
    }

    /**
     * A {@link Writer} whose every write fails, used to observe that the documented
     * {@link java.io.IOException} really propagates from the underlying writer.
     * Declared here so this test class needs no external helper.
     */
    private static final class BrokenWriter extends Writer {
        @Override
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("BrokenWriter: write refused");
        }
        @Override
        public void flush() throws IOException {
            throw new IOException("BrokenWriter: flush refused");
        }
        @Override
        public void close() throws IOException {
            throw new IOException("BrokenWriter: close refused");
        }
    }

    // ================================================================
    // escapeJava(String)
    // ================================================================

    @Test
    public void escapeJava_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.escapeJava((String) null));
    }

    @Test
    public void escapeJava_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    @Test
    public void escapeJava_plainText_isUnchanged() {
        assertEquals("Hello World 123", StringEscapeUtils.escapeJava("Hello World 123"));
    }

    @Test
    public void escapeJava_tabBecomesBackslashT() {
        // javadoc: "So a tab becomes the characters '\\' and 't'."
        assertEquals("\\t", StringEscapeUtils.escapeJava("\t"));
    }

    @Test
    public void escapeJava_carriageReturnBecomesBackslashR() {
        // javadoc: "Deals correctly with quotes and control-chars (tab, backslash, cr, ff, etc.)"
        assertEquals("\\r", StringEscapeUtils.escapeJava("\r"));
    }

    @Test
    public void escapeJava_newlineBecomesBackslashN() {
        assertEquals("\\n", StringEscapeUtils.escapeJava("\n"));
    }

    @Test
    public void escapeJava_formFeedBecomesBackslashF() {
        // javadoc lists "ff" (form feed) as one of the handled control chars.
        assertEquals("\\f", StringEscapeUtils.escapeJava("\f"));
    }

    @Test
    public void escapeJava_backslashIsDoubled() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    @Test
    public void escapeJava_doubleQuoteIsEscaped() {
        // javadoc example: He didn't say, "Stop!"  ->  He didn't say, \"Stop!\"
        assertEquals("\\\"", StringEscapeUtils.escapeJava("\""));
    }

    @Test
    public void escapeJava_singleQuoteIsNotEscaped() {
        // javadoc: "The only difference between Java strings and JavaScript strings
        // is that in JavaScript, a single quote must be escaped."
        assertEquals("'", StringEscapeUtils.escapeJava("'"));
    }

    @Test
    public void escapeJava_javadocExample() {
        assertEquals("He didn't say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    // ================================================================
    // escapeJava(Writer, String)
    // ================================================================

    @Test
    public void escapeJavaWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, "a\tb\"c\\d");
        assertEquals(StringEscapeUtils.escapeJava("a\tb\"c\\d"), writer.toString());
        assertEquals("a\\tb\\\"c\\\\d", writer.toString());
    }

    @Test
    public void escapeJavaWriter_nullString_writesNothing() throws IOException {
        // javadoc: "A null string input has no effect."
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void escapeJavaWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.escapeJava((Writer) null, "data");
            fail("expected IllegalArgumentException when the Writer is null");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void escapeJavaWriter_propagatesWriterIOException() {
        try {
            StringEscapeUtils.escapeJava(new BrokenWriter(), "data");
            fail("expected IOException to propagate from the underlying Writer");
        } catch (IOException expected) {
            // documented contract
        }
    }

    // ================================================================
    // escapeJavaScript(String)
    // ================================================================

    @Test
    public void escapeJavaScript_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.escapeJavaScript((String) null));
    }

    @Test
    public void escapeJavaScript_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.escapeJavaScript(""));
    }

    @Test
    public void escapeJavaScript_singleQuoteIsEscaped() {
        // javadoc: in JavaScript "a single quote must be escaped".
        assertEquals("\\'", StringEscapeUtils.escapeJavaScript("'"));
    }

    @Test
    public void escapeJavaScript_doubleQuoteIsEscaped() {
        assertEquals("\\\"", StringEscapeUtils.escapeJavaScript("\""));
    }

    @Test
    public void escapeJavaScript_tabBecomesBackslashT() {
        assertEquals("\\t", StringEscapeUtils.escapeJavaScript("\t"));
    }

    @Test
    public void escapeJavaScript_backslashIsDoubled() {
        assertEquals("\\\\", StringEscapeUtils.escapeJavaScript("\\"));
    }

    @Test
    public void escapeJavaScript_javadocExample() {
        assertEquals("He didn\\'t say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJavaScript("He didn't say, \"Stop!\""));
    }

    @Test
    public void escapeJavaScript_differsFromEscapeJavaOnlyByTheSingleQuote() {
        // javadoc: "The only difference ... is that in JavaScript, a single quote
        // must be escaped." So escaping the single quotes of the Java form must
        // yield the JavaScript form.
        String input = "a'b\"c\td\\e";
        String asJava = StringEscapeUtils.escapeJava(input);
        String asJavaScript = StringEscapeUtils.escapeJavaScript(input);
        assertEquals(asJavaScript, asJava.replace("'", "\\'"));
    }

    // ================================================================
    // escapeJavaScript(Writer, String)
    // ================================================================

    @Test
    public void escapeJavaScriptWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJavaScript(writer, "it's a \"test\"");
        assertEquals(StringEscapeUtils.escapeJavaScript("it's a \"test\""), writer.toString());
        assertEquals("it\\'s a \\\"test\\\"", writer.toString());
    }

    @Test
    public void escapeJavaScriptWriter_nullString_writesNothing() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJavaScript(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void escapeJavaScriptWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.escapeJavaScript((Writer) null, "data");
            fail("expected IllegalArgumentException when the Writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ================================================================
    // unescapeJava(String)
    // ================================================================

    @Test
    public void unescapeJava_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.unescapeJava((String) null));
    }

    @Test
    public void unescapeJava_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJava(""));
    }

    @Test
    public void unescapeJava_backslashNBecomesNewline() {
        // javadoc: "it will turn a sequence of '\' and 'n' into a newline character"
        assertEquals("\n", StringEscapeUtils.unescapeJava("\\n"));
    }

    @Test
    public void unescapeJava_backslashTBecomesTab() {
        assertEquals("\t", StringEscapeUtils.unescapeJava("\\t"));
    }

    @Test
    public void unescapeJava_doubledBackslashBecomesSingleBackslash() {
        assertEquals("\\", StringEscapeUtils.unescapeJava("\\\\"));
    }

    @Test
    public void unescapeJava_escapedBackslashFollowedByN_isNotTurnedIntoNewline() {
        // javadoc: "...into a newline character, unless the '\' is preceded by another '\'."
        assertEquals("\\n", StringEscapeUtils.unescapeJava("\\\\n"));
    }

    @Test
    public void unescapeJava_unicodeEscapeBecomesCharacter() {
        // A '\\uXXXX' sequence is a Java literal, so "unescapes any Java literals" implies it.
        assertEquals("A", StringEscapeUtils.unescapeJava("\\u0041"));
    }

    @Test
    public void unescapeJava_escapedDoubleQuoteBecomesDoubleQuote() {
        assertEquals("\"", StringEscapeUtils.unescapeJava("\\\""));
    }

    @Test
    public void unescapeJava_roundTripsWithEscapeJava() {
        String original = "Tab\tCR\rLF\nquote\"backslash\\end";
        assertEquals(original,
                StringEscapeUtils.unescapeJava(StringEscapeUtils.escapeJava(original)));
    }

    // ================================================================
    // unescapeJava(Writer, String)
    // ================================================================

    @Test
    public void unescapeJavaWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, "line1\\nline2\\tend");
        assertEquals("line1\nline2\tend", writer.toString());
    }

    @Test
    public void unescapeJavaWriter_nullString_writesNothing() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void unescapeJavaWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.unescapeJava((Writer) null, "data");
            fail("expected IllegalArgumentException when the Writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ================================================================
    // unescapeJavaScript(String) / unescapeJavaScript(Writer, String)
    // ================================================================

    @Test
    public void unescapeJavaScript_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.unescapeJavaScript((String) null));
    }

    @Test
    public void unescapeJavaScript_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJavaScript(""));
    }

    @Test
    public void unescapeJavaScript_escapedSingleQuoteBecomesSingleQuote() {
        // Symmetric with escapeJavaScript, which escapes the single quote.
        assertEquals("'", StringEscapeUtils.unescapeJavaScript("\\'"));
    }

    @Test
    public void unescapeJavaScript_backslashNBecomesNewline() {
        assertEquals("\n", StringEscapeUtils.unescapeJavaScript("\\n"));
    }

    @Test
    public void unescapeJavaScript_roundTripsWithEscapeJavaScript() {
        String original = "It's a \"test\"\twith\\stuff";
        assertEquals(original,
                StringEscapeUtils.unescapeJavaScript(StringEscapeUtils.escapeJavaScript(original)));
    }

    @Test
    public void unescapeJavaScriptWriter_nullString_writesNothing() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJavaScript(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void unescapeJavaScriptWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.unescapeJavaScript((Writer) null, "data");
            fail("expected IllegalArgumentException when the Writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ================================================================
    // escapeHtml(String)
    // ================================================================

    @Test
    public void escapeHtml_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.escapeHtml((String) null));
    }

    @Test
    public void escapeHtml_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.escapeHtml(""));
    }

    @Test
    public void escapeHtml_plainText_isUnchanged() {
        assertEquals("plain text 123", StringEscapeUtils.escapeHtml("plain text 123"));
    }

    @Test
    public void escapeHtml_javadocExample() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml("\"bread\" & \"butter\""));
    }

    @Test
    public void escapeHtml_ampersandBecomesEntity() {
        assertEquals("&amp;", StringEscapeUtils.escapeHtml("&"));
    }

    @Test
    public void escapeHtml_angleBracketsBecomeEntities() {
        assertEquals("&lt;p&gt;", StringEscapeUtils.escapeHtml("<p>"));
    }

    @Test
    public void escapeHtml_apostropheIsNotEscaped() {
        // javadoc: "the commonly used apostrophe escape character (&apos;) is not a
        // legal entity and so is not supported".
        assertEquals("It's", StringEscapeUtils.escapeHtml("It's"));
    }

    @Test
    public void escapeHtml_accentedLetterUsesNamedEntity() {
        // javadoc: "Supports all known HTML 4.0 entities, including funky accents."
        assertEquals("&eacute;", StringEscapeUtils.escapeHtml(E_ACUTE));
    }

    @Test
    public void escapeHtml_copyrightSignUsesNamedEntity() {
        assertEquals("&copy;", StringEscapeUtils.escapeHtml(COPYRIGHT));
    }

    // ================================================================
    // escapeHtml(Writer, String)
    // ================================================================

    @Test
    public void escapeHtmlWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, "<b>Tom & Jerry</b>");
        assertEquals(StringEscapeUtils.escapeHtml("<b>Tom & Jerry</b>"), writer.toString());
        assertEquals("&lt;b&gt;Tom &amp; Jerry&lt;/b&gt;", writer.toString());
    }

    @Test
    public void escapeHtmlWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.escapeHtml((Writer) null, "data");
            fail("expected IllegalArgumentException when the writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void escapeHtmlWriter_propagatesWriterIOException() {
        try {
            StringEscapeUtils.escapeHtml(new BrokenWriter(), "data");
            fail("expected IOException to propagate from the underlying Writer");
        } catch (IOException expected) {
        }
    }

    // ================================================================
    // unescapeHtml(String)
    // ================================================================

    @Test
    public void unescapeHtml_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.unescapeHtml((String) null));
    }

    @Test
    public void unescapeHtml_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.unescapeHtml(""));
    }

    @Test
    public void unescapeHtml_javadocExample() {
        // javadoc: "&lt;Fran&ccedil;ais&gt;" becomes "<Francais>" (with a c-cedilla).
        assertEquals("<Fran" + C_CEDIL + "ais>",
                StringEscapeUtils.unescapeHtml("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    public void unescapeHtml_unrecognizedEntityIsLeftVerbatim() {
        // javadoc: "&gt;&zzzz;x" will become ">&zzzz;x".
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml("&gt;&zzzz;x"));
    }

    @Test
    public void unescapeHtml_basicEntitiesAreDecoded() {
        assertEquals("\"bread\" & \"butter\"",
                StringEscapeUtils.unescapeHtml("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    @Test
    public void unescapeHtml_numericEntityIsDecoded() {
        assertEquals("A", StringEscapeUtils.unescapeHtml("&#65;"));
    }

    @Test
    public void unescapeHtml_roundTripsWithEscapeHtml() {
        String original = "<div class=\"x\"> Fish & Chips " + E_ACUTE + E_GRAVE + " </div>";
        assertEquals(original,
                StringEscapeUtils.unescapeHtml(StringEscapeUtils.escapeHtml(original)));
    }

    // ================================================================
    // unescapeHtml(Writer, String)
    // ================================================================

    @Test
    public void unescapeHtmlWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeHtml(writer, "&lt;a&gt; &amp; &lt;b&gt;");
        assertEquals("<a> & <b>", writer.toString());
    }

    @Test
    public void unescapeHtmlWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.unescapeHtml((Writer) null, "data");
            fail("expected IllegalArgumentException when the writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ================================================================
    // escapeXml(String)
    // ================================================================

    @Test
    public void escapeXml_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.escapeXml((String) null));
    }

    @Test
    public void escapeXml_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.escapeXml(""));
    }

    @Test
    public void escapeXml_javadocExample() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    @Test
    public void escapeXml_theFiveBasicEntities() {
        // javadoc: "Supports only the five basic XML entities (gt, lt, quot, amp, apos)."
        assertEquals("&lt;&gt;&quot;&amp;&apos;", StringEscapeUtils.escapeXml("<>\"&'"));
    }

    @Test
    public void escapeXml_apostropheIsEscapedUnlikeHtml() {
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
        assertEquals("'", StringEscapeUtils.escapeHtml("'"));
    }

    @Test
    public void escapeXml_plainAsciiIsUnchanged() {
        assertEquals("abc ABC 123 -_.", StringEscapeUtils.escapeXml("abc ABC 123 -_."));
    }

    @Test
    public void escapeXml_doesNotEmitNamedHtmlEntities() {
        // Only the five basic XML entities are supported, so an accented letter must
        // never be turned into a named HTML entity such as &eacute;.
        assertEquals(-1, StringEscapeUtils.escapeXml(E_ACUTE).indexOf("eacute"));
    }

    // ================================================================
    // escapeXml(Writer, String)
    // ================================================================

    @Test
    public void escapeXmlWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, "<x a='1' b=\"2\">&</x>");
        assertEquals(StringEscapeUtils.escapeXml("<x a='1' b=\"2\">&</x>"), writer.toString());
        assertEquals("&lt;x a=&apos;1&apos; b=&quot;2&quot;&gt;&amp;&lt;/x&gt;", writer.toString());
    }

    @Test
    public void escapeXmlWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.escapeXml((Writer) null, "data");
            fail("expected IllegalArgumentException when the writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ================================================================
    // unescapeXml(String)
    // ================================================================

    @Test
    public void unescapeXml_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.unescapeXml((String) null));
    }

    @Test
    public void unescapeXml_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.unescapeXml(""));
    }

    @Test
    public void unescapeXml_theFiveBasicEntities() {
        assertEquals("<>\"&'", StringEscapeUtils.unescapeXml("&lt;&gt;&quot;&amp;&apos;"));
    }

    @Test
    public void unescapeXml_javadocExample() {
        assertEquals("\"bread\" & \"butter\"",
                StringEscapeUtils.unescapeXml("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    @Test
    public void unescapeXml_roundTripsWithEscapeXml() {
        String original = "<tag attr='v' other=\"w\"> a & b </tag>";
        assertEquals(original,
                StringEscapeUtils.unescapeXml(StringEscapeUtils.escapeXml(original)));
    }

    // ================================================================
    // unescapeXml(Writer, String)
    // ================================================================

    @Test
    public void unescapeXmlWriter_matchesStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeXml(writer, "&lt;p&gt;a&amp;b&lt;/p&gt;");
        assertEquals("<p>a&b</p>", writer.toString());
    }

    @Test
    public void unescapeXmlWriter_nullWriter_throwsIllegalArgumentException() throws IOException {
        try {
            StringEscapeUtils.unescapeXml((Writer) null, "data");
            fail("expected IllegalArgumentException when the writer is null");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ================================================================
    // escapeSql(String)
    // ================================================================

    @Test
    public void escapeSql_nullInput_returnsNull() {
        assertNull(StringEscapeUtils.escapeSql(null));
    }

    @Test
    public void escapeSql_emptyInput_returnsEmpty() {
        assertEquals("", StringEscapeUtils.escapeSql(""));
    }

    @Test
    public void escapeSql_textWithoutSingleQuote_isUnchanged() {
        assertEquals("McHale Navy", StringEscapeUtils.escapeSql("McHale Navy"));
    }

    @Test
    public void escapeSql_javadocExample() {
        // javadoc: "McHale's Navy" => "McHale''s Navy"
        assertEquals("McHale''s Navy", StringEscapeUtils.escapeSql("McHale's Navy"));
    }

    @Test
    public void escapeSql_everySingleQuoteIsDoubled() {
        assertEquals("''''", StringEscapeUtils.escapeSql("''"));
    }

    @Test
    public void escapeSql_leavesPercentAndUnderscoreUntouched() {
        // javadoc: "It does not handle the cases of percent (%) or underscore (_)".
        assertEquals("50% off_now", StringEscapeUtils.escapeSql("50% off_now"));
    }

    @Test
    public void escapeSql_doesNotEscapeDoubleQuote() {
        // javadoc: "this method only turns single-quotes into doubled single-quotes".
        assertEquals("say \"hi\"", StringEscapeUtils.escapeSql("say \"hi\""));
    }

    @Test
    public void escapeSql_doesNotEscapeBackslash() {
        assertEquals("back\\slash", StringEscapeUtils.escapeSql("back\\slash"));
    }

    // ================================================================
    // constructor
    // ================================================================

    @Test
    public void constructor_isPublicAndUsable() {
        // javadoc: "This constructor is public to permit tools that require a
        // JavaBean instance to operate."
        assertNotNull(new StringEscapeUtils());
    }
}
