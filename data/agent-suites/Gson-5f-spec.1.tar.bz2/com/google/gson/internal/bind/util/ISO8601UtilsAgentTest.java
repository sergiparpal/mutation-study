package com.google.gson.internal.bind.util;

import junit.framework.TestCase;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Self-contained JUnit 3 tests for {@link ISO8601Utils}, based solely on the
 * documented contract in the generated javadoc:
 *
 * Supported parse format:
 * [yyyy-MM-dd|yyyyMMdd][T(hh:mm[:ss[.sss]]|hhmm[ss[.sss]])]?[Z|[+-]hh[:]mm]]
 *
 * format(Date)                     -> 'yyyy-MM-ddThh:mm:ssZ'
 * format(Date,boolean)             -> 'yyyy-MM-ddThh:mm:ss[.sss]Z' (GMT)
 * format(Date,boolean,TimeZone)    -> 'yyyy-MM-ddThh:mm:ss[.sss][Z|[+-]hh:mm]'
 */
public class ISO8601UtilsAgentTest extends TestCase {

    private static Date utcDate(int year, int month, int day,
                                 int hour, int minute, int second, int millis) {
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.US);
        cal.clear();
        cal.set(year, month - 1, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    // ---- constructor ----

    public void testPublicNoArgConstructor() {
        // The javadoc documents a public no-arg constructor.
        ISO8601Utils utils = new ISO8601Utils();
        assertNotNull(utils);
    }

    // ---- format(Date) ----

    public void testFormatDate_epoch() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        assertEquals("1970-01-01T00:00:00Z", ISO8601Utils.format(date));
    }

    public void testFormatDate_paddedFields() {
        // Single-digit month/day/hour/minute/second must be zero-padded.
        Date date = utcDate(2018, 3, 5, 7, 8, 9, 0);
        assertEquals("2018-03-05T07:08:09Z", ISO8601Utils.format(date));
    }

    public void testFormatDate_maxFieldValues() {
        Date date = utcDate(2018, 12, 31, 23, 59, 59, 0);
        assertEquals("2018-12-31T23:59:59Z", ISO8601Utils.format(date));
    }

    public void testFormatDate_nullThrowsNullPointerException() {
        try {
            ISO8601Utils.format(null);
            fail("Expected NullPointerException for null date");
        } catch (NullPointerException expected) {
            // documented pattern requires operating on the date argument
        }
    }

    // ---- format(Date, boolean) ----

    public void testFormatDateMillis_trueIncludesFraction() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 45);
        assertEquals("1970-01-01T00:00:00.045Z", ISO8601Utils.format(date, true));
    }

    public void testFormatDateMillis_falseOmitsFraction() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 999);
        String formatted = ISO8601Utils.format(date, false);
        assertEquals("1970-01-01T00:00:00Z", formatted);
        assertTrue("no fraction separator expected", formatted.indexOf('.') < 0);
    }

    public void testFormatDateMillis_zeroIsZeroPadded() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        assertEquals("1970-01-01T00:00:00.000Z", ISO8601Utils.format(date, true));
    }

    public void testFormatDateMillis_maxValue() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 999);
        assertEquals("1970-01-01T00:00:00.999Z", ISO8601Utils.format(date, true));
    }

    // ---- format(Date, boolean, TimeZone) ----

    public void testFormatWithTimeZone_utcProducesLiteralZ() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("UTC"));
        assertEquals("1970-01-01T00:00:00Z", formatted);
    }

    public void testFormatWithTimeZone_gmtProducesLiteralZ() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT"));
        assertEquals("1970-01-01T00:00:00Z", formatted);
    }

    public void testFormatWithTimeZone_positiveOffset() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT+02:00"));
        assertEquals("1970-01-01T02:00:00+02:00", formatted);
    }

    public void testFormatWithTimeZone_negativeOffset() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT-08:00"));
        assertEquals("1969-12-31T16:00:00-08:00", formatted);
    }

    public void testFormatWithTimeZone_halfHourOffsetPadsHour() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 0);
        String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT+00:30"));
        assertEquals("1970-01-01T00:30:00+00:30", formatted);
    }

    public void testFormatWithTimeZone_millisAndOffsetCombined() {
        Date date = utcDate(1970, 1, 1, 0, 0, 0, 45);
        String formatted = ISO8601Utils.format(date, true, TimeZone.getTimeZone("GMT+02:00"));
        assertEquals("1970-01-01T02:00:00.045+02:00", formatted);
    }

    // ---- parse(String, ParsePosition) happy paths ----

    public void pruned_testParse_fullDateTimeUtc() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("1970-01-01T00:00:00Z", pos);
        assertEquals(0L, parsed.getTime());
        assertEquals(21, pos.getIndex());
    }

    public void testParse_withMillisFraction() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("1970-01-01T00:00:00.123Z", pos);
        assertEquals(123L, parsed.getTime());
    }

    public void testParse_dateOnlyWithZOffsetDefaultsToMidnight() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("1970-01-01Z", pos);
        assertEquals(0L, parsed.getTime());
        assertEquals(11, pos.getIndex());
    }

    public void pruned_testParse_compactDateAndTime() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("19700101T000000Z", pos);
        assertEquals(0L, parsed.getTime());
        assertEquals(17, pos.getIndex());
    }

    public void testParse_positiveOffsetWithColon() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("1970-01-01T02:00:00+02:00", pos);
        assertEquals(0L, parsed.getTime());
    }

    public void testParse_positiveOffsetWithoutColon() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("1970-01-01T02:00:00+0200", pos);
        assertEquals(0L, parsed.getTime());
    }

    public void testParse_negativeOffset() throws ParseException {
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse("1969-12-31T19:00:00-05:00", pos);
        assertEquals(0L, parsed.getTime());
    }

    public void testParse_honorsInitialPositionOffset() throws ParseException {
        String text = "xxx1970-01-01T00:00:00Z";
        ParsePosition pos = new ParsePosition(3);
        Date parsed = ISO8601Utils.parse(text, pos);
        assertEquals(0L, parsed.getTime());
        assertEquals(text.length(), pos.getIndex());
    }

    public void pruned_testParse_stopsAtTimezoneLeavingTrailingCharsUnconsumed() throws ParseException {
        String text = "1970-01-01T00:00:00Zxyz";
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse(text, pos);
        assertEquals(0L, parsed.getTime());
        assertEquals(21, pos.getIndex());
    }

    // ---- parse(String, ParsePosition) error cases ----

    public void testParse_missingTimezoneThrowsParseException() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("1970-01-01T00:00:00", pos);
            fail("Expected ParseException when timezone indicator is missing");
        } catch (ParseException expected) {
            // documented: "if the date is not in the appropriate format"
        }
    }

    public void testParse_invalidTextThrowsParseException() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("not-a-date", pos);
            fail("Expected ParseException for non ISO-8601 text");
        } catch (ParseException expected) {
            // expected
        }
    }

    public void testParse_emptyStringThrowsParseException() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("", pos);
            fail("Expected ParseException for empty string");
        } catch (ParseException expected) {
            // expected
        }
    }

    // ---- round trip: format() output must be understood by parse() ----

    public void testFormatThenParseRoundTrip() throws ParseException {
        Date original = utcDate(2018, 3, 5, 7, 8, 9, 45);
        String formatted = ISO8601Utils.format(original, true);

        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse(formatted, pos);

        assertEquals(original.getTime(), parsed.getTime());
        assertEquals(formatted.length(), pos.getIndex());
    }

    public void testFormatThenParseRoundTrip_withOffsetTimeZone() throws ParseException {
        Date original = utcDate(2018, 6, 25, 12, 0, 0, 0);
        String formatted = ISO8601Utils.format(original, false, TimeZone.getTimeZone("GMT-05:00"));

        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse(formatted, pos);

        assertEquals(original.getTime(), parsed.getTime());
    }
}
