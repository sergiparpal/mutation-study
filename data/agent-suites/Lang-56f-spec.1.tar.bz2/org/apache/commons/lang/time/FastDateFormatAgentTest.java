package org.apache.commons.lang.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained JUnit 4 tests for {@link org.apache.commons.lang.time.FastDateFormat}.
 *
 * <p>Every expectation is derived from the published javadoc contract:
 * <ul>
 *   <li>FastDateFormat "can be used as a direct replacement to SimpleDateFormat" and
 *       "all patterns are compatible with SimpleDateFormat (except time zones)".</li>
 *   <li>The pattern letter {@code 'Z'} yields RFC822 time zones (eg. {@code +0800}) and
 *       {@code 'ZZ'} yields ISO8601 full-format time zones (eg. {@code +08:00}).</li>
 *   <li>Style constants FULL/LONG/MEDIUM/SHORT are 0/1/2/3 (constant-values.html).</li>
 *   <li>Parsing is not supported; the two-arg parseObject returns {@code null}.</li>
 *   <li>Invalid / null patterns cause {@code IllegalArgumentException}.</li>
 * </ul>
 */
public class FastDateFormatAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone GMT_PLUS_8 = TimeZone.getTimeZone("GMT+08:00");
    private static final TimeZone GMT_MINUS_11 = TimeZone.getTimeZone("GMT-11:00");

    /** Unix time 1_000_000_000 seconds -> 2001-09-09T01:46:40.000Z */
    private static final long FIXED_MILLIS = 1000000000000L;
    private static final Date FIXED_DATE = new Date(FIXED_MILLIS);

    // ------------------------------------------------------------------
    // Style constants
    // ------------------------------------------------------------------

    @Test
    public void styleConstantsHaveDocumentedValues() {
        assertEquals(0, FastDateFormat.FULL);
        assertEquals(1, FastDateFormat.LONG);
        assertEquals(2, FastDateFormat.MEDIUM);
        assertEquals(3, FastDateFormat.SHORT);
        // ... and therefore line up with java.text.DateFormat's own constants.
        assertEquals(DateFormat.FULL, FastDateFormat.FULL);
        assertEquals(DateFormat.LONG, FastDateFormat.LONG);
        assertEquals(DateFormat.MEDIUM, FastDateFormat.MEDIUM);
        assertEquals(DateFormat.SHORT, FastDateFormat.SHORT);
    }

    // ------------------------------------------------------------------
    // getInstance(...) factory methods
    // ------------------------------------------------------------------

    @Test
    public void getInstanceNoArgReturnsUsableDefaultFormatter() {
        FastDateFormat fdf = FastDateFormat.getInstance();
        assertNotNull(fdf);
        assertNotNull(fdf.getPattern());
        assertTrue("default pattern must not be empty", fdf.getPattern().length() > 0);
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    @Test
    public void getInstanceNoArgIsSimpleDateFormatCompatible() {
        FastDateFormat fdf = FastDateFormat.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(fdf.getPattern());
        Date now = new Date();
        assertEquals(sdf.format(now), fdf.format(now));
    }

    @Test
    public void getInstanceWithPatternExposesThatPattern() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", fdf.getPattern());
    }

    @Test
    public void getInstanceStoresPatternTimeZoneAndLocale() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT_PLUS_8, Locale.US);
        assertEquals("yyyy-MM-dd HH:mm:ss", fdf.getPattern());
        assertEquals(GMT_PLUS_8, fdf.getTimeZone());
        assertEquals(Locale.US, fdf.getLocale());
    }

    @Test
    public void getInstanceRejectsInvalidPattern() {
        try {
            FastDateFormat.getInstance("bad pattern with 'unterminated quote");
            fail("expected IllegalArgumentException for an invalid pattern");
        } catch (IllegalArgumentException expected) {
            // documented: "throws IllegalArgumentException - if pattern is invalid"
        }
    }

    @Test
    public void getInstanceRejectsNullPattern() {
        try {
            FastDateFormat.getInstance(null, GMT, Locale.US);
            fail("expected IllegalArgumentException for a null pattern");
        } catch (IllegalArgumentException expected) {
            // documented: "throws IllegalArgumentException - if pattern is invalid or null"
        }
    }

    @Test
    public void getInstanceSingleArgRejectsNullPattern() {
        try {
            FastDateFormat.getInstance((String) null);
            fail("expected IllegalArgumentException for a null pattern");
        } catch (IllegalArgumentException expected) {
            // a null pattern is necessarily an invalid pattern
        }
    }

    @Test
    public void getInstanceWithNullTimeZoneUsesTheDefaultTimeZone() {
        // "timeZone - optional time zone" -> a null time zone means "use the default".
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", (TimeZone) null);
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
    }

    @Test
    public void getInstanceWithNullLocaleUsesTheDefaultLocale() {
        // "locale - optional locale" -> a null locale means "use the system locale".
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", (Locale) null);
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    // ------------------------------------------------------------------
    // format(...) - core behaviour
    // ------------------------------------------------------------------

    @Test
    public void formatProducesExpectedTextForAKnownInstant() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss", GMT, Locale.US);
        assertEquals("2001-09-09T01:46:40", fdf.format(FIXED_DATE));
    }

    @Test
    public void formatEpochInGmtIsMidnight19700101() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        assertEquals("1970-01-01 00:00:00", fdf.format(0L));
    }

    @Test
    public void formatDateMillisAndCalendarAgreeForTheSameInstant() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        Calendar cal = Calendar.getInstance(GMT);
        cal.setTimeInMillis(0L);

        String viaMillis = fdf.format(0L);
        String viaDate = fdf.format(new Date(0L));
        String viaCalendar = fdf.format(cal);

        assertEquals("1970-01-01 00:00:00", viaMillis);
        assertEquals(viaMillis, viaDate);
        assertEquals(viaMillis, viaCalendar);
    }

    @Test
    public void formatCalendarUsesTheCalendarFieldValues() {
        // Calendar zone == formatter zone, so the wall-clock reading is unambiguous.
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(2005, Calendar.MARCH, 7, 13, 5, 9);
        assertEquals("2005-03-07 13:05:09", fdf.format(cal));
    }

    @Test
    public void formatIntoStringBufferAppendsAndReturnsTheSameBuffer() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);

        StringBuffer dateBuf = new StringBuffer("PRE-");
        StringBuffer dateRet = fdf.format(new Date(0L), dateBuf);
        assertSame("format(Date, buf) must return the supplied buffer", dateBuf, dateRet);
        assertEquals("PRE-1970-01-01 00:00:00", dateBuf.toString());

        StringBuffer millisBuf = new StringBuffer("PRE-");
        assertSame(millisBuf, fdf.format(0L, millisBuf));
        assertEquals("PRE-1970-01-01 00:00:00", millisBuf.toString());

        Calendar cal = Calendar.getInstance(GMT);
        cal.setTimeInMillis(0L);
        StringBuffer calBuf = new StringBuffer("PRE-");
        assertSame(calBuf, fdf.format(cal, calBuf));
        assertEquals("PRE-1970-01-01 00:00:00", calBuf.toString());
    }

    @Test
    public void formatObjectDispatchesForDateCalendarAndLong() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        FieldPosition pos = new FieldPosition(0);

        StringBuffer dateBuf = new StringBuffer();
        assertSame(dateBuf, fdf.format((Object) new Date(0L), dateBuf, pos));
        assertEquals("1970-01-01 00:00:00", dateBuf.toString());

        StringBuffer longBuf = new StringBuffer();
        assertSame(longBuf, fdf.format((Object) Long.valueOf(0L), longBuf, pos));
        assertEquals("1970-01-01 00:00:00", longBuf.toString());

        Calendar cal = Calendar.getInstance(GMT);
        cal.setTimeInMillis(0L);
        StringBuffer calBuf = new StringBuffer();
        assertSame(calBuf, fdf.format((Object) cal, calBuf, pos));
        assertEquals("1970-01-01 00:00:00", calBuf.toString());
    }

    @Test
    public void formatObjectRejectsTypesOtherThanDateCalendarOrLong() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", GMT, Locale.US);
        FieldPosition pos = new FieldPosition(0);

        try {
            fdf.format("not a temporal value", new StringBuffer(), pos);
            fail("expected IllegalArgumentException for an unsupported object type");
        } catch (IllegalArgumentException expected) {
            // only Date / Calendar / Long are documented as accepted
        }

        try {
            fdf.format((Object) null, new StringBuffer(), pos);
            fail("expected an exception for a null object");
        } catch (IllegalArgumentException expected) {
            // acceptable
        } catch (NullPointerException alsoAcceptable) {
            // also acceptable - null is not one of the documented types
        }
    }

    // ------------------------------------------------------------------
    // format(...) - SimpleDateFormat compatibility
    // ------------------------------------------------------------------

    @Test
    public void formatMatchesSimpleDateFormatAcrossManyInstants() {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, GMT, Locale.US);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(GMT);

        long[] instants = {0L, 1000L, -1L, FIXED_MILLIS, 1234567890123L, 999999999999L};
        for (int i = 0; i < instants.length; i++) {
            Date d = new Date(instants[i]);
            assertEquals("instant " + instants[i], sdf.format(d), fdf.format(d));
        }
    }

    @Test
    public void formatSupportsMillisecondPatternLikeSimpleDateFormat() {
        String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, GMT, Locale.US);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(GMT);

        Date d = new Date(1234L); // 1970-01-01 00:00:01.234 GMT
        assertEquals("1970-01-01 00:00:01.234", fdf.format(d));
        assertEquals(sdf.format(d), fdf.format(d));
    }

    @Test
    public void formatEmitsRfc822TimeZoneForSingleZ() {
        // javadoc example: "eg. +0800 or -1100"
        assertEquals("+0000", FastDateFormat.getInstance("Z", GMT, Locale.US).format(0L));
        assertEquals("+0800", FastDateFormat.getInstance("Z", GMT_PLUS_8, Locale.US).format(0L));
        assertEquals("-1100", FastDateFormat.getInstance("Z", GMT_MINUS_11, Locale.US).format(0L));
    }

    @Test
    public void formatEmitsIso8601TimeZoneForDoubleZ() {
        // javadoc: "the pattern 'ZZ' has been made to represent ISO8601 full format time zones
        // (eg. +08:00 or -11:00)"
        assertEquals("+00:00", FastDateFormat.getInstance("ZZ", GMT, Locale.US).format(0L));
        assertEquals("+08:00", FastDateFormat.getInstance("ZZ", GMT_PLUS_8, Locale.US).format(0L));
        assertEquals("-11:00", FastDateFormat.getInstance("ZZ", GMT_MINUS_11, Locale.US).format(0L));
    }

    // ------------------------------------------------------------------
    // Localized "standard" instances
    // ------------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void getDateInstanceYieldsTheStandardLocalizedDatePattern() {
        FastDateFormat fdf = FastDateFormat.getDateInstance(FastDateFormat.MEDIUM, GMT, Locale.US);
        SimpleDateFormat reference =
                (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.US);
        reference.setTimeZone(GMT);

        assertEquals(reference.toPattern(), fdf.getPattern());
        assertEquals(Locale.US, fdf.getLocale());
        assertEquals(GMT, fdf.getTimeZone());
        assertEquals(reference.format(FIXED_DATE), fdf.format(FIXED_DATE));
    }

    @Test
    public void getTimeInstanceYieldsTheStandardLocalizedTimePattern() {
        FastDateFormat fdf = FastDateFormat.getTimeInstance(FastDateFormat.SHORT, GMT, Locale.US);
        SimpleDateFormat reference =
                (SimpleDateFormat) DateFormat.getTimeInstance(DateFormat.SHORT, Locale.US);
        reference.setTimeZone(GMT);

        assertEquals(reference.toPattern(), fdf.getPattern());
        assertEquals(reference.format(FIXED_DATE), fdf.format(FIXED_DATE));
    }

    // @Test  // pruned: failed on the fixed version
    public void getDateTimeInstanceYieldsTheStandardLocalizedDateTimePattern() {
        FastDateFormat fdf = FastDateFormat.getDateTimeInstance(
                FastDateFormat.MEDIUM, FastDateFormat.SHORT, GMT, Locale.US);
        SimpleDateFormat reference = (SimpleDateFormat) DateFormat.getDateTimeInstance(
                DateFormat.MEDIUM, DateFormat.SHORT, Locale.US);
        reference.setTimeZone(GMT);

        assertEquals(reference.toPattern(), fdf.getPattern());
        assertEquals(reference.format(FIXED_DATE), fdf.format(FIXED_DATE));
        // a date/time pattern carries more than a bare date pattern
        SimpleDateFormat dateOnly =
                (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.US);
        assertFalse(dateOnly.toPattern().equals(fdf.getPattern()));
    }

    @Test
    public void getDateInstanceRejectsAnUnknownStyle() {
        try {
            FastDateFormat.getDateInstance(99, Locale.US);
            fail("expected IllegalArgumentException for a style outside FULL/LONG/MEDIUM/SHORT");
        } catch (IllegalArgumentException expected) {
            // style must be one of the four documented constants
        }
    }

    // ------------------------------------------------------------------
    // parseObject(...) - not supported
    // ------------------------------------------------------------------

    @Test
    public void parseObjectWithPositionAlwaysReturnsNull() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertNull(fdf.parseObject("2001-09-09", new ParsePosition(0)));
        assertNull(fdf.parseObject("total nonsense", new ParsePosition(3)));
    }

    @Test
    public void parseObjectSingleArgThrowsBecauseParsingIsUnsupported() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        try {
            fdf.parseObject("2001-09-09");
            fail("expected ParseException - parsing is not supported");
        } catch (ParseException expected) {
            // Format.parseObject(String) fails because parseObject(String, pos) returns null
        }
    }

    // ------------------------------------------------------------------
    // equals / hashCode / toString
    // ------------------------------------------------------------------

    @Test
    public void formattersWithIdenticalConfigurationAreEqualWithEqualHashCodes() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        // hashCode is stable across invocations
        assertEquals(a.hashCode(), a.hashCode());
    }

    @Test
    public void formattersDifferingInConfigurationAreNotEqual() {
        FastDateFormat base = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertFalse(base.equals(FastDateFormat.getInstance("yyyy/MM/dd", GMT, Locale.US)));
        assertFalse(base.equals(FastDateFormat.getInstance("yyyy-MM-dd", GMT_PLUS_8, Locale.US)));
        assertFalse(base.equals(FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.UK)));
    }

    @Test
    public void equalsIsReflexiveAndRejectsNullAndForeignTypes() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertTrue(fdf.equals(fdf));
        assertFalse(fdf.equals(null));
        assertFalse(fdf.equals("yyyy-MM-dd"));
    }

    @Test
    public void toStringIsNonEmptyAndMentionsThePattern() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm", GMT, Locale.US);
        String text = fdf.toString();
        assertNotNull(text);
        assertTrue("debugging string should be non-empty", text.length() > 0);
        assertTrue("debugging string should identify the pattern: " + text,
                text.indexOf("yyyy-MM-dd HH:mm") >= 0);
    }

    // ------------------------------------------------------------------
    // getMaxLengthEstimate / getTimeZoneOverridesCalendar
    // ------------------------------------------------------------------

    @Test
    public void maxLengthEstimateIsPositiveAndBoundsTypicalOutput() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        int estimate = fdf.getMaxLengthEstimate();
        assertTrue("estimate should be positive but was " + estimate, estimate > 0);

        String out = fdf.format(new Date(0L));
        assertEquals("1970-01-01 00:00:00", out);
        assertTrue("estimate " + estimate + " should not be below the produced length " + out.length(),
                estimate >= out.length());
    }

    @Test
    public void timeZoneOverridesCalendarFlagIsStable() {
        FastDateFormat forcedZone = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        boolean flag = forcedZone.getTimeZoneOverridesCalendar();
        // whatever the value, it must be reported consistently
        assertEquals(flag, forcedZone.getTimeZoneOverridesCalendar());

        FastDateFormat defaultZone = FastDateFormat.getInstance("yyyy-MM-dd");
        boolean otherFlag = defaultZone.getTimeZoneOverridesCalendar();
        assertEquals(otherFlag, defaultZone.getTimeZoneOverridesCalendar());
    }

    // ------------------------------------------------------------------
    // Thread-safety (headline feature of the class)
    // ------------------------------------------------------------------

    @Test
    public void formatterProducesConsistentResultsFromMultipleThreads() throws InterruptedException {
        final FastDateFormat fdf =
                FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss", GMT, Locale.US);
        final String expected = "2001-09-09T01:46:40";
        assertEquals(expected, fdf.format(FIXED_DATE)); // single-threaded sanity check

        final List<String> mismatches = Collections.synchronizedList(new ArrayList<String>());
        Thread[] workers = new Thread[6];
        for (int i = 0; i < workers.length; i++) {
            workers[i] = new Thread(new Runnable() {
                public void run() {
                    for (int j = 0; j < 400; j++) {
                        String actual = fdf.format(FIXED_DATE);
                        if (!expected.equals(actual)) {
                            mismatches.add(actual);
                        }
                    }
                }
            });
        }
        for (int i = 0; i < workers.length; i++) {
            workers[i].start();
        }
        for (int i = 0; i < workers.length; i++) {
            workers[i].join();
        }
        assertTrue("concurrent formatting produced wrong output: " + mismatches, mismatches.isEmpty());
    }
}
