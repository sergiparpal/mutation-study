/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Unit tests for {@link org.apache.commons.lang3.text.ExtendedMessageFormat}.
 * <p>
 * These tests exercise the public API only: the four constructors, {@link
 * ExtendedMessageFormat#toPattern()}, {@link ExtendedMessageFormat#applyPattern(String)},
 * the disabled subformat mutators, {@link ExtendedMessageFormat#equals(Object)},
 * {@link ExtendedMessageFormat#hashCode()} and the inherited {@code format(Object)}
 * behaviour that the pattern parsing feeds into.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    //-----------------------------------------------------------------------
    // helpers
    //-----------------------------------------------------------------------

    /** Build a single entry format-factory registry. */
    private static Map<String, FormatFactory> registry(String name, FormatFactory factory) {
        Map<String, FormatFactory> map = new HashMap<String, FormatFactory>();
        map.put(name, factory);
        return map;
    }

    /** A {@link Format} that upper-cases the string value of its argument. */
    private static class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ENGLISH));
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /** Always hands back the same shared {@link UpperCaseFormat} instance. */
    private static class UpperCaseFormatFactory implements FormatFactory {
        private static final Format UPPER = new UpperCaseFormat();

        public Format getFormat(String name, String arguments, Locale locale) {
            return UPPER;
        }
    }

    /**
     * Produces a format that echoes the name/arguments it was created with, so
     * that tests can observe what the parser passed to the factory.
     */
    private static class EchoFormatFactory implements FormatFactory {
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new Format() {
                private static final long serialVersionUID = 1L;

                @Override
                public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
                    return toAppendTo.append("[").append(name).append("|")
                            .append(arguments).append("|").append(obj).append("]");
                }

                @Override
                public Object parseObject(String source, ParsePosition pos) {
                    throw new UnsupportedOperationException();
                }
            };
        }
    }

    /** Distinct concrete subclass, used to check the {@code getClass()} guard in equals(). */
    private static class OtherExtendedMessageFormat extends ExtendedMessageFormat {
        private static final long serialVersionUID = 1L;

        public OtherExtendedMessageFormat(String pattern) {
            super(pattern);
        }
    }

    //-----------------------------------------------------------------------
    // construction / formatting without a registry
    //-----------------------------------------------------------------------

    public void testFormatWithoutRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] { "World" }));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    public void testEmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    public void testDefaultLocaleConstructor() {
        Locale expected = Locale.getDefault();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(expected, emf.getLocale());
        assertEquals("value", emf.format(new Object[] { "value" }));
    }

    public void testConstructorWithLocaleAffectsNumberFormat() {
        Object[] args = new Object[] { Double.valueOf(1234.5) };

        ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number,#,##0.00}", Locale.US);
        assertEquals(Locale.US, us.getLocale());
        assertEquals("1,234.50", us.format(args));

        ExtendedMessageFormat de = new ExtendedMessageFormat("{0,number,#,##0.00}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, de.getLocale());
        assertEquals("1.234,50", de.format(args));
    }

    public void testNullRegistryBehavesLikeNoRegistry() {
        Map<String, FormatFactory> noRegistry = null;
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}", noRegistry);
        assertEquals("a b", emf.format(new Object[] { "a", "b" }));
        assertEquals("{0} {1}", emf.toPattern());
    }

    //-----------------------------------------------------------------------
    // construction / formatting with a registry
    //-----------------------------------------------------------------------

    public void testEmptyPatternWithRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    public void testLiteralOnlyPatternWithRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("just text",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("just text", emf.toPattern());
        assertEquals("just text", emf.format(new Object[0]));
    }

    public void testCustomFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Say {0,upper} now",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("Say HELLO now", emf.format(new Object[] { "hello" }));
        assertEquals("Say {0,upper} now", emf.toPattern());
    }

    public void testCustomFormatOverridesBuiltInFormatName() {
        // the registry claims the "number" name, so the built-in number format is bypassed
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}",
                registry("number", new UpperCaseFormatFactory()));
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
        assertEquals("{0,number}", emf.toPattern());
    }

    public void testCustomFormatArgumentsPassedToFactory() {
        Map<String, FormatFactory> registry = registry("echo", new EchoFormatFactory());

        ExtendedMessageFormat withStyle = new ExtendedMessageFormat("{0,echo,STYLE}", registry);
        assertEquals("[echo|STYLE|x]", withStyle.format(new Object[] { "x" }));
        assertEquals("{0,echo,STYLE}", withStyle.toPattern());

        ExtendedMessageFormat noStyle = new ExtendedMessageFormat("{0,echo}", registry);
        assertEquals("[echo|null|x]", noStyle.format(new Object[] { "x" }));
        assertEquals("{0,echo}", noStyle.toPattern());
    }

    public void testUnknownFormatNameDelegatesToSuper() {
        // "choice" is not in the registry, so MessageFormat's built-in choice format is used
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,choice,0#zero|1#one}",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("zero", emf.format(new Object[] { Integer.valueOf(0) }));
        assertEquals("one", emf.format(new Object[] { Integer.valueOf(1) }));
        assertEquals("one", emf.format(new Object[] { Integer.valueOf(2) }));
        assertTrue("toPattern should retain the choice format type: " + emf.toPattern(),
                emf.toPattern().indexOf("choice") >= 0);
    }

    public void testRepeatedArgumentWithCustomFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} {0}",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("HI hi", emf.format(new Object[] { "hi" }));
        assertEquals("{0,upper} {0}", emf.toPattern());
    }

    public void testToPatternRoundTripsWithCustomFormats() {
        Map<String, FormatFactory> reg = registry("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}-{1}-{2,upper}", reg);
        Object[] args = new Object[] { "a", "b", "c" };
        assertEquals("A-b-C", emf.format(args));

        String pattern = emf.toPattern();
        assertEquals("{0,upper}-{1}-{2,upper}", pattern);

        ExtendedMessageFormat reparsed = new ExtendedMessageFormat(pattern, reg);
        assertEquals("A-b-C", reparsed.format(args));
        assertEquals(emf, reparsed);
        assertEquals(emf.hashCode(), reparsed.hashCode());
    }

    public void testQuotedBracesAreLiteralWithRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}'",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("{0}", emf.format(new Object[] { "ignored" }));
        assertEquals(new MessageFormat("'{0}'").format(new Object[] { "ignored" }),
                emf.format(new Object[] { "ignored" }));
    }

    public void testEscapedQuoteWithRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("''{0}''",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("'x'", emf.format(new Object[] { "x" }));
    }

    //-----------------------------------------------------------------------
    // applyPattern
    //-----------------------------------------------------------------------

    public void testApplyPatternReplacesPreviousPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals("a", emf.format(new Object[] { "a" }));

        emf.applyPattern("[{0}] and [{1}]");
        assertEquals("[{0}] and [{1}]", emf.toPattern());
        assertEquals("[a] and [b]", emf.format(new Object[] { "a", "b" }));
    }

    public void testApplyPatternWithRegistryAddsCustomFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}",
                registry("upper", new UpperCaseFormatFactory()));
        assertEquals("plain", emf.format(new Object[] { "plain" }));

        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("PLAIN", emf.format(new Object[] { "plain" }));
    }

    //-----------------------------------------------------------------------
    // error / boundary cases in pattern parsing
    //-----------------------------------------------------------------------

    public void testUnterminatedFormatElementWithRegistry() {
        try {
            new ExtendedMessageFormat("{0", registry("upper", new UpperCaseFormatFactory()));
            fail("Expected IllegalArgumentException for an unterminated format element");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testUnterminatedFormatDescriptionWithRegistry() {
        try {
            new ExtendedMessageFormat("{0,upper", registry("upper", new UpperCaseFormatFactory()));
            fail("Expected IllegalArgumentException for an unterminated format description");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testInvalidArgumentIndexWithRegistry() {
        try {
            new ExtendedMessageFormat("{abc}", registry("upper", new UpperCaseFormatFactory()));
            fail("Expected IllegalArgumentException for a non-numeric argument index");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testInvalidPatternWithoutRegistry() {
        try {
            new ExtendedMessageFormat("{0");
            fail("Expected IllegalArgumentException for a malformed pattern");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testNullPatternThrows() {
        try {
            new ExtendedMessageFormat(null);
            fail("Expected NullPointerException for a null pattern");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    public void testNullPatternWithRegistryThrows() {
        try {
            new ExtendedMessageFormat(null, registry("upper", new UpperCaseFormatFactory()));
            fail("Expected NullPointerException for a null pattern");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // disabled subformat mutators
    //-----------------------------------------------------------------------

    public void testSetFormatThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new UpperCaseFormat());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    public void testSetFormatsThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new UpperCaseFormat() });
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new UpperCaseFormat() });
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // equals / hashCode
    //-----------------------------------------------------------------------

    public void testEqualsAndHashCodeForEqualInstances() {
        Map<String, FormatFactory> reg = registry("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper} {1}", Locale.US, reg);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper} {1}", Locale.US, reg);

        assertEquals(a, b);
        assertEquals(b, a);
        assertEquals(a.hashCode(), b.hashCode());
    }

    public void testEqualsForEquivalentButDistinctRegistryMaps() {
        FormatFactory shared = new UpperCaseFormatFactory();
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry("upper", shared));
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", Locale.US, registry("upper", shared));

        // different Map instances, but equal content -> the formats are equal
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    public void testNotEqualsWhenRegistriesDiffer() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US,
                registry("upper", new UpperCaseFormatFactory()));
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US,
                registry("upper", new UpperCaseFormatFactory()));

        // identical patterns and identical formatted output ...
        assertEquals("x", a.format(new Object[] { "x" }));
        assertEquals("x", b.format(new Object[] { "x" }));
        // ... but the registries are not equal (distinct factory instances)
        assertFalse(a.equals(b));
    }

    public void testNotEqualsWhenOneRegistryIsNull() {
        ExtendedMessageFormat withRegistry = new ExtendedMessageFormat("{0}", Locale.US,
                registry("upper", new UpperCaseFormatFactory()));
        ExtendedMessageFormat withoutRegistry = new ExtendedMessageFormat("{0}", Locale.US, null);

        assertFalse(withRegistry.equals(withoutRegistry));
        assertFalse(withoutRegistry.equals(withRegistry));
    }

    public void testNotEqualsDifferentPattern() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0}");
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0} {1}");
        assertFalse(a.equals(b));
    }

    public void testNotEqualsNullOtherTypeAndPlainMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("{0}"));
        // a plain MessageFormat with the same pattern must not be considered equal
        assertFalse(emf.equals(new MessageFormat("{0}")));
    }

    public void testNotEqualsSubclassInstance() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        OtherExtendedMessageFormat sub = new OtherExtendedMessageFormat("{0}");
        assertFalse(emf.equals(sub));
        assertFalse(sub.equals(emf));
    }

    public void testEqualsReflexiveAndHashCodeConsistent() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}");
        assertTrue(emf.equals(emf));
        assertEquals(emf.hashCode(), emf.hashCode());
    }
}
