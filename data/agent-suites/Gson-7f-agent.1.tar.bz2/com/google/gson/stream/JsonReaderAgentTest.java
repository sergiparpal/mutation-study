/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

@SuppressWarnings("resource")
public final class JsonReaderAgentTest extends TestCase {

  public void testNullReaderThrows() throws IOException {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testDefaultIsNotLenient() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    assertFalse(reader.isLenient());
  }

  public void testSetLenientTrue() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.setLenient(true);
    assertTrue(reader.isLenient());
  }

  public void testEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    assertEquals(JsonToken.END_ARRAY, reader.peek());
    reader.endArray();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testEmptyObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testReadArrayOfMixedTypes() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[1,2.5,true,false,null,\"text\"]"));
    reader.beginArray();
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(1, reader.nextInt());
    assertEquals(2.5, reader.nextDouble());
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.nextNull();
    assertEquals("text", reader.nextString());
    reader.endArray();
  }

  public void testReadObject() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("{\"a\":1,\"b\":\"two\",\"c\":true}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals(1, reader.nextInt());
    assertEquals("b", reader.nextName());
    assertEquals("two", reader.nextString());
    assertEquals("c", reader.nextName());
    assertTrue(reader.nextBoolean());
    reader.endObject();
  }

  public void testNestedArraysAndObjects() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("{\"a\":[1,2,{\"b\":3}]}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    reader.beginObject();
    assertEquals("b", reader.nextName());
    assertEquals(3, reader.nextInt());
    reader.endObject();
    reader.endArray();
    reader.endObject();
  }

  public void testHasNextWithinArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    assertTrue(reader.hasNext());
    reader.nextInt();
    assertFalse(reader.hasNext());
  }

  public void testIntegerMismatchWithLongThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[3000000000]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
    // The failed conversion does not consume the token: it can still be read as a long.
    assertEquals(3000000000L, reader.nextLong());
    reader.endArray();
  }

  public void testNextIntOnNonIntegralNumberThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testQuotedNumbersAreReadable() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"1\",\"2.5\",\"3\"]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2.5, reader.nextDouble());
    assertEquals(3L, reader.nextLong());
    reader.endArray();
  }

  public void testNumbersAsStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2.5]"));
    reader.beginArray();
    assertEquals("1", reader.nextString());
    assertEquals("2.5", reader.nextString());
    reader.endArray();
  }

  public void testNextStringOnBooleanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextBooleanOnStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"true\"]"));
    reader.beginArray();
    try {
      reader.nextBoolean();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNullOnNonNullThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextNull();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNameOnNonNameThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextName();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginArrayMismatchThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginObjectMismatchThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayMismatchThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectMismatchThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
    reader.beginObject();
    try {
      reader.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testPrematureEndOfInputThrowsEOFException() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{"));
    reader.beginObject();
    try {
      reader.nextName();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testUnterminatedArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 2]"));
    reader.beginArray();
    reader.nextInt();
    try {
      reader.nextInt();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testUnterminatedObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1 \"b\":2}"));
    reader.beginObject();
    reader.nextName();
    reader.nextInt();
    try {
      reader.nextName();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testStrictModeRejectsUnquotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[abc]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testLenientModeAcceptsUnquotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[abc]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals("abc", reader.nextString());
    reader.endArray();
  }

  public void testStrictModeRejectsSingleQuotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("['abc']"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testLenientModeAcceptsSingleQuotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("['abc']"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals("abc", reader.nextString());
    reader.endArray();
  }

  public void testStrictModeRejectsComments() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 // comment\n,2]"));
    reader.beginArray();
    try {
      reader.nextInt();
      reader.nextInt();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testLenientModeAcceptsComments() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 // comment\n,2]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testLenientModeAcceptsCStyleComments() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 /* comment */,2]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testStrictModeRejectsMultipleTopLevelValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[][]"));
    reader.beginArray();
    reader.endArray();
    try {
      reader.peek();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testLenientModeAcceptsMultipleTopLevelValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[][]"));
    reader.setLenient(true);
    reader.beginArray();
    reader.endArray();
    reader.beginArray();
    reader.endArray();
  }

  public void testStrictModeRejectsNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[]"));
    try {
      reader.beginArray();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testLenientModeAcceptsNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testTopLevelScalarAllowedWithoutLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    assertTrue(reader.nextBoolean());
  }

  public void testStrictModeRejectsNanAndInfinity() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testLenientModeAcceptsNanAndInfinity() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN,Infinity,-Infinity]"));
    reader.setLenient(true);
    reader.beginArray();
    assertTrue(Double.isNaN(reader.nextDouble()));
    assertEquals(Double.POSITIVE_INFINITY, reader.nextDouble());
    assertEquals(Double.NEGATIVE_INFINITY, reader.nextDouble());
    reader.endArray();
  }

  public void testCaseInsensitiveLiterals() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[TRUE,False,NULL]"));
    reader.beginArray();
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.nextNull();
    reader.endArray();
  }

  public void testEscapedCharactersInStrings() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[\"\\\"\\\\\\/\\b\\f\\n\\r\\t\\u0041\"]"));
    reader.beginArray();
    assertEquals("\"\\/\b\f\n\r\tA", reader.nextString());
    reader.endArray();
  }

  public void testUnterminatedStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"abc"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testSkipValueOnArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[[1,2,3],4]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(4, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueOnObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[{\"a\":[1,2,3]},4]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(4, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueOnScalarTypes() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[\"a\",true,1,1.5,null,'b',unquoted]"));
    reader.setLenient(true);
    reader.beginArray();
    for (int i = 0; i < 7; i++) {
      reader.skipValue();
    }
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testCloseClosesUnderlyingReaderAndPreventsFurtherUse() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    reader.close();
    try {
      reader.peek();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testGetPathAfterConstruction() {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    assertEquals("$", reader.getPath());
  }

  public void testGetPathTracksArrayIndices() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[10,20,30]"));
    reader.beginArray();
    assertEquals("$[0]", reader.getPath());
    reader.nextInt();
    assertEquals("$[1]", reader.getPath());
  }

  public void testToStringReportsLineAndColumn() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    assertEquals("JsonReader at line 1 column 1", reader.toString());
    reader.beginArray();
    reader.nextInt();
    assertEquals("JsonReader at line 1 column 3", reader.toString());
  }

  public void testMissingValueInArrayLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[,true]"));
    reader.setLenient(true);
    reader.beginArray();
    reader.nextNull();
    assertTrue(reader.nextBoolean());
    reader.endArray();
  }

  public void testStrictModeRejectsMissingValueInArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[,true]"));
    reader.beginArray();
    try {
      reader.peek();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testNegativeAndFloatingPointNumbers() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[-1,-2.5,1e10,-1.5e-3]"));
    reader.beginArray();
    assertEquals(-1, reader.nextInt());
    assertEquals(-2.5, reader.nextDouble());
    assertEquals(1e10, reader.nextDouble());
    assertEquals(-1.5e-3, reader.nextDouble());
    reader.endArray();
  }

  public void testLongBoundaryValues() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[" + Long.MIN_VALUE + "," + Long.MAX_VALUE + "]"));
    reader.beginArray();
    assertEquals(Long.MIN_VALUE, reader.nextLong());
    assertEquals(Long.MAX_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNameSurvivesAcrossPeekCalls() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
    reader.beginObject();
    assertEquals(JsonToken.NAME, reader.peek());
    assertEquals(JsonToken.NAME, reader.peek());
    assertEquals("a", reader.nextName());
    assertEquals(1, reader.nextInt());
    reader.endObject();
  }
}
