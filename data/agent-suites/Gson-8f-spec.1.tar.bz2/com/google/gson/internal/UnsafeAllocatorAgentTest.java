package com.google.gson.internal;

import junit.framework.TestCase;

/**
 * Tests for {@link UnsafeAllocator} based solely on its documented contract:
 * <ul>
 *   <li>{@code create()} returns a usable {@code UnsafeAllocator}.</li>
 *   <li>{@code newInstance(Class)} allocates an object of the requested type
 *       "without invoking their constructors", declaring {@code throws Exception}.</li>
 * </ul>
 */
public class UnsafeAllocatorAgentTest extends TestCase {

    /** A normal class whose constructor (and field initializers) assign non-default values. */
    public static class PlainFixture {
        private int value;
        private boolean constructorRan;

        public PlainFixture() {
            this.value = 42;
            this.constructorRan = true;
        }

        public int getValue() {
            return value;
        }

        public boolean didConstructorRun() {
            return constructorRan;
        }
    }

    /** A class whose constructor always throws, to prove the constructor is never run. */
    public static class ThrowingConstructorFixture {
        public ThrowingConstructorFixture() {
            throw new RuntimeException("constructor should not be invoked by UnsafeAllocator");
        }
    }

    /** A class with a private constructor and a final field, normally awkward to allocate via reflection. */
    public static class PrivateConstructorFixture {
        private final String marker;

        private PrivateConstructorFixture() {
            this.marker = "shouldNotBeSetByAllocator";
        }

        public String getMarker() {
            return marker;
        }
    }

    /** A base/derived pair, to check that constructors up the whole hierarchy are skipped. */
    public static class BaseFixture {
        protected int baseValue;

        public BaseFixture() {
            baseValue = 7;
        }
    }

    public static class DerivedFixture extends BaseFixture {
        protected int derivedValue;

        public DerivedFixture() {
            derivedValue = 9;
        }
    }

    public void testCreateReturnsNonNullAllocator() {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        assertNotNull("create() must return a usable allocator instance", allocator);
    }

    public void testCreateCanBeCalledRepeatedlyAndEachResultIsUsable() throws Exception {
        UnsafeAllocator first = UnsafeAllocator.create();
        UnsafeAllocator second = UnsafeAllocator.create();
        assertNotNull(first);
        assertNotNull(second);

        Object firstInstance = first.newInstance(PlainFixture.class);
        Object secondInstance = second.newInstance(PlainFixture.class);
        assertNotNull(firstInstance);
        assertNotNull(secondInstance);
        assertTrue(firstInstance instanceof PlainFixture);
        assertTrue(secondInstance instanceof PlainFixture);
    }

    public void testNewInstanceReturnsInstanceOfRequestedClass() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        Object instance = allocator.newInstance(PlainFixture.class);
        assertNotNull(instance);
        assertTrue("returned object must be an instance of the requested class",
                instance instanceof PlainFixture);
    }

    public void testNewInstanceDoesNotInvokeConstructor() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        // If the constructor ran, this would propagate the RuntimeException it throws.
        Object instance = allocator.newInstance(ThrowingConstructorFixture.class);
        assertNotNull(instance);
        assertTrue(instance instanceof ThrowingConstructorFixture);
    }

    public void testNewInstanceLeavesFieldsAtJvmDefaultsInsteadOfConstructorValues() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        PlainFixture instance = (PlainFixture) allocator.newInstance(PlainFixture.class);
        assertNotNull(instance);
        assertFalse("constructor must not run, so this flag must stay false",
                instance.didConstructorRun());
        assertEquals("field must retain the JVM default (0) rather than the constructor-assigned 42",
                0, instance.getValue());
    }

    public void testNewInstanceBypassesPrivateConstructorAndItsFieldInitializer() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        Object instance = allocator.newInstance(PrivateConstructorFixture.class);
        assertNotNull(instance);
        assertTrue(instance instanceof PrivateConstructorFixture);
        assertNull("final field initializer runs inside the constructor and must be skipped",
                ((PrivateConstructorFixture) instance).getMarker());
    }

    public void testNewInstanceSkipsConstructorsAcrossWholeHierarchy() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        Object raw = allocator.newInstance(DerivedFixture.class);
        assertNotNull(raw);
        assertTrue(raw instanceof DerivedFixture);
        DerivedFixture instance = (DerivedFixture) raw;
        assertEquals("superclass constructor must not run", 0, instance.baseValue);
        assertEquals("subclass constructor must not run", 0, instance.derivedValue);
    }

    public void testNewInstanceReturnsDistinctInstancesOnRepeatedCalls() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        Object first = allocator.newInstance(PlainFixture.class);
        Object second = allocator.newInstance(PlainFixture.class);
        assertNotNull(first);
        assertNotNull(second);
        assertNotSame("each call should allocate a fresh object", first, second);
    }

    public void testNewInstanceWithPlainObjectClass() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        Object instance = allocator.newInstance(Object.class);
        assertNotNull(instance);
        assertEquals(Object.class, instance.getClass());
    }

    public void testNewInstanceWithInterfaceThrowsException() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        try {
            Object instance = allocator.newInstance(Runnable.class);
            fail("expected an Exception when allocating an instance of an interface, but got: " + instance);
        } catch (Exception expected) {
            // An interface has no instantiable object representation, so allocation must fail.
        }
    }
}
