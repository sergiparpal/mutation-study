/*
 * Copyright (C) 2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // -- newParameterizedTypeWithOwner --------------------------------------

  public void testNewParameterizedTypeWithOwner_topLevelClass() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertNull(type.getOwnerType());
    assertEquals(List.class, type.getRawType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_multipleArguments() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    Type[] args = type.getActualTypeArguments();
    assertEquals(2, args.length);
    assertEquals(String.class, args[0]);
    assertEquals(Integer.class, args[1]);
  }

  public void testNewParameterizedTypeWithOwner_getActualTypeArgumentsReturnsClone() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type[] args = type.getActualTypeArguments();
    args[0] = Integer.class;
    // mutating the returned array must not affect internal state
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_staticNestedClassAllowedWithoutOwner() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, StaticHolder.class, String.class);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_localClassRequiresOwner() {
    class LocalHolder {
    }
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, LocalHolder.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_nullTypeArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, (Type) null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_primitiveTypeArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_toString() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals("java.util.List<java.lang.String>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_toStringNoArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals("java.util.List", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_toStringMultipleArguments() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    assertEquals("java.util.Map<java.lang.String, java.lang.Integer>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_equalsAndHashCode() {
    ParameterizedType a =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertTrue(a.equals(b));
    assertEquals(a.hashCode(), b.hashCode());
  }

  public void testNewParameterizedTypeWithOwner_notEqualsDifferentArgument() {
    ParameterizedType a =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertFalse(a.equals(b));
  }

  public void testNewParameterizedTypeWithOwner_isSerializable() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertTrue(type instanceof Serializable);
  }

  // -- arrayOf --------------------------------------------------------------

  public void testArrayOf_componentType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, type.getGenericComponentType());
  }

  public void testArrayOf_toString() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals("java.lang.String[]", type.toString());
  }

  public void testArrayOf_equals() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertEquals(a.hashCode(), b.hashCode());
  }

  public void testArrayOf_notEqualsDifferentComponent() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(Integer.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  public void testArrayOf_isSerializable() {
    assertTrue($Gson$Types.arrayOf(String.class) instanceof Serializable);
  }

  // -- subtypeOf --------------------------------------------------------------

  public void testSubtypeOf_bounds() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(String.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
  }

  public void testSubtypeOf_toStringWithBound() {
    WildcardType type = $Gson$Types.subtypeOf(CharSequence.class);
    assertEquals("? extends java.lang.CharSequence", type.toString());
  }

  public void testSubtypeOf_objectBoundToStringIsQuestionMark() {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertEquals("?", type.toString());
  }

  public void testSubtypeOf_wildcardBoundReusesUpperBounds() {
    WildcardType inner = $Gson$Types.subtypeOf(String.class);
    WildcardType outer = $Gson$Types.subtypeOf(inner);
    assertEquals(String.class, outer.getUpperBounds()[0]);
    assertEquals(0, outer.getLowerBounds().length);
  }

  public void testSubtypeOf_rejectsNull() {
    try {
      $Gson$Types.subtypeOf(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  // -- supertypeOf --------------------------------------------------------------

  public void testSupertypeOf_bounds() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(1, type.getLowerBounds().length);
    assertEquals(String.class, type.getLowerBounds()[0]);
  }

  public void testSupertypeOf_toString() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals("? super java.lang.String", type.toString());
  }

  public void testSupertypeOf_wildcardBoundReusesLowerBounds() {
    WildcardType inner = $Gson$Types.supertypeOf(String.class);
    WildcardType outer = $Gson$Types.supertypeOf(inner);
    assertEquals(String.class, outer.getLowerBounds()[0]);
    assertEquals(Object.class, outer.getUpperBounds()[0]);
  }

  public void testSupertypeOf_rejectsNull() {
    try {
      $Gson$Types.supertypeOf(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  // -- canonicalize --------------------------------------------------------------

  public void testCanonicalize_plainClassReturnedAsIs() {
    assertSame(String.class, $Gson$Types.canonicalize(String.class));
  }

  public void testCanonicalize_arrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) canonical).getGenericComponentType());
  }

  public void testCanonicalize_primitiveArrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(int[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(int.class, ((GenericArrayType) canonical).getGenericComponentType());
  }

  public void testCanonicalize_parameterizedTypeIsEqualButNotSame() {
    ParameterizedType original =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertNotSame(original, canonical);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_genericArrayType() {
    GenericArrayType original = $Gson$Types.arrayOf(String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_wildcardType() {
    WildcardType original = $Gson$Types.subtypeOf(String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_unsupportedTypeReturnedAsIs() {
    TypeVariable<?> typeVariable = List.class.getTypeParameters()[0];
    assertSame(typeVariable, $Gson$Types.canonicalize(typeVariable));
  }

  // -- getRawType --------------------------------------------------------------

  public void testGetRawType_class() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawType_parameterizedType() {
    Type type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_genericArrayType() {
    Type type = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_typeVariableResolvesToObject() {
    TypeVariable<?> typeVariable = List.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawType_wildcardTypeUsesUpperBound() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(String.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_nullRejected() {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // -- equals --------------------------------------------------------------

  public void testEquals_sameClassInstance() {
    assertTrue($Gson$Types.equals(String.class, String.class));
  }

  public void testEquals_differentClasses() {
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEquals_bothNull() {
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEquals_oneNull() {
    assertFalse($Gson$Types.equals(String.class, null));
  }

  public void testEquals_parameterizedTypesWithSameArguments() {
    Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertTrue($Gson$Types.equals(a, b));
  }

  public void testEquals_parameterizedTypesWithDifferentArguments() {
    Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  public void testEquals_parameterizedTypeAgainstNonParameterizedType() {
    Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_genericArrayTypes() {
    Type a = $Gson$Types.arrayOf(String.class);
    Type b = $Gson$Types.arrayOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
  }

  public void testEquals_genericArrayTypeAgainstNonArrayType() {
    Type a = $Gson$Types.arrayOf(String.class);
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_wildcardTypes() {
    Type a = $Gson$Types.subtypeOf(String.class);
    Type b = $Gson$Types.subtypeOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
  }

  public void testEquals_wildcardTypesDifferentBoundKind() {
    Type a = $Gson$Types.subtypeOf(String.class);
    Type b = $Gson$Types.supertypeOf(String.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  public void testEquals_typeVariablesSameDeclarationAndName() {
    TypeVariable<?> a = List.class.getTypeParameters()[0];
    TypeVariable<?> b = List.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(a, b));
  }

  public void testEquals_typeVariablesDifferentDeclaration() {
    TypeVariable<?> a = List.class.getTypeParameters()[0];
    TypeVariable<?> b = Map.class.getTypeParameters()[0];
    assertFalse($Gson$Types.equals(a, b));
  }

  // -- typeToString --------------------------------------------------------------

  public void testTypeToString_forClassUsesName() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
  }

  public void testTypeToString_forParameterizedTypeUsesToString() {
    Type type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(type.toString(), $Gson$Types.typeToString(type));
  }

  public void testTypeToString_forGenericArrayType() {
    Type type = $Gson$Types.arrayOf(String.class);
    assertEquals("java.lang.String[]", $Gson$Types.typeToString(type));
  }

  // -- getArrayComponentType --------------------------------------------------------------

  public void testGetArrayComponentType_class() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  public void testGetArrayComponentType_primitiveArrayClass() {
    assertEquals(int.class, $Gson$Types.getArrayComponentType(int[].class));
  }

  public void testGetArrayComponentType_genericArrayType() {
    Type array = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(array));
  }

  public void testGetArrayComponentType_nonArrayTypeThrows() {
    Type notAnArray = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    try {
      $Gson$Types.getArrayComponentType(notAnArray);
      fail();
    } catch (ClassCastException expected) {
    }
  }

  // -- getCollectionElementType --------------------------------------------------------------

  public void testGetCollectionElementType_parameterizedContext() {
    Type context = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type elementType = $Gson$Types.getCollectionElementType(context, List.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementType_rawContextDefaultsToObject() {
    Type elementType = $Gson$Types.getCollectionElementType(Collection.class, Collection.class);
    assertEquals(Object.class, elementType);
  }

  // -- getMapKeyAndValueTypes --------------------------------------------------------------

  public void testGetMapKeyAndValueTypes_parameterizedContext() {
    Type context =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(context, Map.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_rawContextDefaultsToObject() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Map.class, Map.class);
    assertEquals(2, types.length);
    assertEquals(Object.class, types[0]);
    assertEquals(Object.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_propertiesSpecialCased() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  // -- resolve --------------------------------------------------------------

  public void testResolve_typeVariableResolvedFromParameterizedContext() {
    Type context = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    TypeVariable<?> typeVariable = List.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(context, List.class, typeVariable);
    assertEquals(String.class, resolved);
  }

  public void testResolve_nonVariableTypeReturnedUnchanged() {
    Type context = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertSame(String.class, $Gson$Types.resolve(context, List.class, String.class));
  }

  public void testResolve_typeVariableDeclaredByMethodIsUnresolvable() throws Exception {
    Method method = Collections.class.getMethod("emptyList");
    TypeVariable<?> typeVariable = method.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(Object.class, Object.class, typeVariable);
    assertSame(typeVariable, resolved);
  }

  public void testResolve_genericArrayComponentIsResolved() {
    Type context = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    TypeVariable<?> typeVariable = List.class.getTypeParameters()[0];
    Type arrayOfVariable = $Gson$Types.arrayOf(typeVariable);
    Type resolved = $Gson$Types.resolve(context, List.class, arrayOfVariable);
    assertTrue(resolved instanceof GenericArrayType);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(resolved));
  }

  private static final class StaticHolder {
  }
}
