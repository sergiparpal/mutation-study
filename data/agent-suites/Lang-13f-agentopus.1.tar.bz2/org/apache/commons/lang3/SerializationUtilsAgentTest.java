/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.NotSerializableException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

/**
 * Unit tests {@link org.apache.commons.lang3.SerializationUtils}.
 *
 * @version $Id$
 */
public class SerializationUtilsAgentTest {

    private static final String KEY = "key";
    private static final String VALUE = "value";

    //-----------------------------------------------------------------------
    // Class / constructor
    //-----------------------------------------------------------------------
    @Test
    public void testConstructor() {
        assertNotNull(new SerializationUtils());
        Constructor<?>[] cons = SerializationUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(SerializationUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(SerializationUtils.class.getModifiers()));
    }

    //-----------------------------------------------------------------------
    // clone
    //-----------------------------------------------------------------------
    @Test
    public void testCloneNull() {
        assertNull(SerializationUtils.clone((Serializable) null));
    }

    @Test
    public void testCloneReturnsEqualButDistinctObject() {
        HashMap<String, String> original = new HashMap<String, String>();
        original.put(KEY, VALUE);

        HashMap<String, String> clone = SerializationUtils.clone(original);

        assertNotSame(original, clone);
        assertEquals(original, clone);
        assertEquals(1, clone.size());
        assertEquals(VALUE, clone.get(KEY));
        assertSame(HashMap.class, clone.getClass());
    }

    @Test
    public void testCloneIsDeepAndIndependentOfTheOriginal() {
        List<String> inner = new ArrayList<String>();
        inner.add("a");
        HashMap<String, List<String>> original = new HashMap<String, List<String>>();
        original.put(KEY, inner);

        HashMap<String, List<String>> clone = SerializationUtils.clone(original);

        assertNotSame(inner, clone.get(KEY));
        assertEquals(inner, clone.get(KEY));

        // mutating the clone must leave the original untouched, and vice versa
        clone.get(KEY).add("b");
        assertEquals(1, original.get(KEY).size());
        assertEquals(2, clone.get(KEY).size());

        inner.add("c");
        assertEquals(2, original.get(KEY).size());
        assertEquals(2, clone.get(KEY).size());
    }

    @Test
    public void testCloneKeepsSharedReferencesShared() {
        Bean shared = new Bean("shared", 7);
        List<Bean> original = new ArrayList<Bean>();
        original.add(shared);
        original.add(shared);

        ArrayList<Bean> clone = SerializationUtils.clone(new ArrayList<Bean>(original));

        assertEquals(2, clone.size());
        assertNotSame(shared, clone.get(0));
        assertSame(clone.get(0), clone.get(1));
    }

    @Test
    public void testCloneKeepsCycles() {
        Node node = new Node("root");
        node.next = node;

        Node clone = SerializationUtils.clone(node);

        assertNotSame(node, clone);
        assertEquals("root", clone.name);
        assertSame(clone, clone.next);
    }

    @Test
    public void testCloneDropsTransientState() {
        Bean original = new Bean("name", 42);
        assertEquals(42, original.getTransientValue());

        Bean clone = SerializationUtils.clone(original);

        assertEquals(original, clone);
        assertNotSame(original, clone);
        assertEquals("name", clone.getName());
        assertEquals(0, clone.getTransientValue());
        // the original keeps its transient state
        assertEquals(42, original.getTransientValue());
    }

    @Test
    public void testCloneUnserializableContentThrows() {
        Holder holder = new Holder(new Object());
        try {
            SerializationUtils.clone(holder);
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof NotSerializableException);
        }
    }

    /**
     * Cloning the {@code Class} object of a primitive type has to work: those names cannot
     * be resolved by {@code Class.forName}. See LANG-13 / LANG-626.
     */
    @Test
    public void testClonePrimitiveTypeClasses() {
        Class<?>[] primitives = new Class<?>[] {
                byte.class, short.class, int.class, long.class,
                float.class, double.class, boolean.class, char.class, void.class };

        for (Class<?> primitive : primitives) {
            Class<?> clone = SerializationUtils.clone(primitive);
            assertSame("clone of " + primitive.getName(), primitive, clone);
        }
    }

    @Test
    public void testCloneObjectAndArrayClasses() {
        assertSame(String.class, SerializationUtils.clone(String.class));
        assertSame(int[].class, SerializationUtils.clone(int[].class));
        assertSame(String[].class, SerializationUtils.clone(String[].class));
        assertSame(Bean.class, SerializationUtils.clone(Bean.class));
    }

    @Test
    public void testCloneEnumReturnsTheSameConstant() {
        // enum identity must survive a serialization round trip
        assertSame(Colour.RED, SerializationUtils.clone(Colour.RED));
    }

    @Test
    public void testCloneEmptyAndBoxedValues() {
        assertEquals("", SerializationUtils.clone(""));
        assertEquals(Integer.valueOf(0), SerializationUtils.clone(Integer.valueOf(0)));
        assertEquals(Long.valueOf(Long.MIN_VALUE), SerializationUtils.clone(Long.valueOf(Long.MIN_VALUE)));
        assertEquals(new ArrayList<String>(), SerializationUtils.clone(new ArrayList<String>()));
    }

    //-----------------------------------------------------------------------
    // serialize(Serializable)
    //-----------------------------------------------------------------------
    @Test
    public void testSerializeBytesRoundTrip() {
        Bean original = new Bean("round", 1);

        byte[] data = SerializationUtils.serialize(original);

        assertNotNull(data);
        assertTrue(data.length > 0);
        assertEquals(original, SerializationUtils.deserialize(data));
    }

    @Test
    public void testSerializeBytesIsRepeatableButReturnsFreshArrays() {
        Bean bean = new Bean("repeat", 0);

        byte[] first = SerializationUtils.serialize(bean);
        byte[] second = SerializationUtils.serialize(bean);

        assertNotSame(first, second);
        assertArrayEquals(first, second);
    }

    @Test
    public void testSerializeNullObjectProducesDeserializableNull() {
        byte[] data = SerializationUtils.serialize((Serializable) null);

        assertNotNull(data);
        assertTrue(data.length > 0);
        assertNull(SerializationUtils.deserialize(data));
    }

    @Test
    public void testSerializeBytesUnserializableThrows() {
        try {
            SerializationUtils.serialize(new Holder(new Object()));
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof NotSerializableException);
        }
    }

    //-----------------------------------------------------------------------
    // serialize(Serializable, OutputStream)
    //-----------------------------------------------------------------------
    @Test
    public void testSerializeToStreamWritesSameBytesAsByteArrayVariant() {
        Bean bean = new Bean("stream", 3);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        SerializationUtils.serialize(bean, out);

        assertArrayEquals(SerializationUtils.serialize(bean), out.toByteArray());
        assertEquals(bean, SerializationUtils.deserialize(out.toByteArray()));
    }

    @Test
    public void testSerializeToStreamClosesTheStream() {
        CloseRecordingOutputStream out = new CloseRecordingOutputStream();

        SerializationUtils.serialize(new Bean("close", 0), out);

        assertTrue("the output stream should have been closed", out.isClosed());
        assertTrue(out.toByteArray().length > 0);
    }

    @Test
    public void testSerializeNullObjectToStream() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        SerializationUtils.serialize(null, out);

        assertTrue(out.toByteArray().length > 0);
        assertNull(SerializationUtils.deserialize(out.toByteArray()));
    }

    @Test
    public void testSerializeToNullStreamThrows() {
        try {
            SerializationUtils.serialize(new Bean("x", 0), null);
            fail("IllegalArgumentException expected");
        } catch (IllegalArgumentException ex) {
            assertEquals("The OutputStream must not be null", ex.getMessage());
        }
    }

    @Test
    public void testSerializeNullObjectToNullStreamThrows() {
        try {
            SerializationUtils.serialize(null, null);
            fail("IllegalArgumentException expected");
        } catch (IllegalArgumentException ex) {
            assertEquals("The OutputStream must not be null", ex.getMessage());
        }
    }

    @Test
    public void testSerializeWrapsIOExceptionFromTheStream() {
        IOException failure = new IOException("stream is broken");
        try {
            SerializationUtils.serialize(new Bean("x", 0), new FailingOutputStream(failure));
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertSame(failure, ex.getCause());
        }
    }

    @Test
    public void testSerializeWrapsIOExceptionThrownByWriteObject() {
        try {
            SerializationUtils.serialize(new ExplodingBean());
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
            assertEquals("writeObject failed", ex.getCause().getMessage());
        }
    }

    /**
     * A partially written object still leaves the stream closed; the caller is not left
     * holding an open stream when serialization blows up.
     */
    @Test
    public void testSerializeClosesTheStreamEvenOnFailure() {
        CloseRecordingOutputStream out = new CloseRecordingOutputStream();
        try {
            SerializationUtils.serialize(new Holder(new Object()), out);
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof NotSerializableException);
        }
        assertTrue("the output stream should have been closed", out.isClosed());
    }

    //-----------------------------------------------------------------------
    // deserialize
    //-----------------------------------------------------------------------
    @Test
    public void testDeserializeStreamRoundTrip() {
        Bean bean = new Bean("in", 5);
        byte[] data = SerializationUtils.serialize(bean);

        Object result = SerializationUtils.deserialize(new ByteArrayInputStream(data));

        assertEquals(bean, result);
        assertSame(Bean.class, result.getClass());
    }

    @Test
    public void testDeserializeClosesTheStream() {
        byte[] data = SerializationUtils.serialize(new Bean("in", 5));
        CloseRecordingInputStream in = new CloseRecordingInputStream(data);

        assertNotNull(SerializationUtils.deserialize(in));
        assertTrue("the input stream should have been closed", in.isClosed());
    }

    @Test
    public void testDeserializeNullStreamThrows() {
        try {
            SerializationUtils.deserialize((InputStream) null);
            fail("IllegalArgumentException expected");
        } catch (IllegalArgumentException ex) {
            assertEquals("The InputStream must not be null", ex.getMessage());
        }
    }

    @Test
    public void testDeserializeNullByteArrayThrows() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("IllegalArgumentException expected");
        } catch (IllegalArgumentException ex) {
            assertEquals("The byte[] must not be null", ex.getMessage());
        }
    }

    @Test
    public void testDeserializeEmptyByteArrayThrows() {
        try {
            SerializationUtils.deserialize(new byte[0]);
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    @Test
    public void testDeserializeGarbageThrows() {
        try {
            SerializationUtils.deserialize(new byte[] { 0, 1, 2, 3, 4, 5, 6, 7 });
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    @Test
    public void testDeserializeTruncatedStreamThrows() {
        byte[] data = SerializationUtils.serialize(new Bean("truncated", 0));
        byte[] truncated = new byte[data.length / 2];
        System.arraycopy(data, 0, truncated, 0, truncated.length);

        try {
            SerializationUtils.deserialize(truncated);
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    @Test
    public void testDeserializeUnknownClassThrows() throws Exception {
        // rewrite the class name recorded in the stream to one that does not exist,
        // keeping the length (and therefore the stream layout) intact
        byte[] data = SerializationUtils.serialize(new Bean("unknown", 0));
        byte[] patched = replaceFirst(data, "$Bean", "$Nope");

        try {
            SerializationUtils.deserialize(patched);
            fail("SerializationException expected");
        } catch (SerializationException ex) {
            assertTrue("unexpected cause: " + ex.getCause(),
                    ex.getCause() instanceof ClassNotFoundException);
        }
    }

    @Test
    public void testDeserializeReadsOnlyTheFirstObjectOfAStream() throws Exception {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(buffer);
        out.writeObject(new Bean("first", 0));
        out.writeObject(new Bean("second", 0));
        out.close();

        Object result = SerializationUtils.deserialize(buffer.toByteArray());

        assertEquals(new Bean("first", 0), result);
    }

    //-----------------------------------------------------------------------
    // Helpers
    //-----------------------------------------------------------------------
    private static byte[] replaceFirst(byte[] data, String target, String replacement) throws Exception {
        byte[] from = target.getBytes("UTF-8");
        byte[] to = replacement.getBytes("UTF-8");
        assertEquals("target and replacement must have the same length", from.length, to.length);

        byte[] patched = data.clone();
        for (int i = 0; i <= patched.length - from.length; i++) {
            boolean match = true;
            for (int j = 0; j < from.length; j++) {
                if (patched[i + j] != from[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                System.arraycopy(to, 0, patched, i, to.length);
                return patched;
            }
        }
        fail("'" + target + "' was not found in the serialized form");
        return null;
    }

    public enum Colour {
        RED, GREEN
    }

    public static class Bean implements Serializable {
        private static final long serialVersionUID = 1L;

        private final String name;
        private transient int transientValue;

        public Bean(String name, int transientValue) {
            this.name = name;
            this.transientValue = transientValue;
        }

        public String getName() {
            return name;
        }

        public int getTransientValue() {
            return transientValue;
        }

        @Override
        public boolean equals(Object other) {
            if (!(other instanceof Bean)) {
                return false;
            }
            String otherName = ((Bean) other).name;
            return name == null ? otherName == null : name.equals(otherName);
        }

        @Override
        public int hashCode() {
            return name == null ? 0 : name.hashCode();
        }
    }

    public static class Node implements Serializable {
        private static final long serialVersionUID = 1L;

        private final String name;
        private Node next;

        public Node(String name) {
            this.name = name;
        }
    }

    public static class Holder implements Serializable {
        private static final long serialVersionUID = 1L;

        private final Object payload;

        public Holder(Object payload) {
            this.payload = payload;
        }
    }

    public static class ExplodingBean implements Serializable {
        private static final long serialVersionUID = 1L;

        private void writeObject(ObjectOutputStream out) throws IOException {
            throw new IOException("writeObject failed");
        }
    }

    private static class CloseRecordingOutputStream extends ByteArrayOutputStream {
        private boolean closed;

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }

        public boolean isClosed() {
            return closed;
        }
    }

    private static class CloseRecordingInputStream extends ByteArrayInputStream {
        private boolean closed;

        public CloseRecordingInputStream(byte[] data) {
            super(data);
        }

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }

        public boolean isClosed() {
            return closed;
        }
    }

    private static class FailingOutputStream extends OutputStream {
        private final IOException failure;

        public FailingOutputStream(IOException failure) {
            this.failure = failure;
        }

        @Override
        public void write(int b) throws IOException {
            throw failure;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            throw failure;
        }
    }
}
