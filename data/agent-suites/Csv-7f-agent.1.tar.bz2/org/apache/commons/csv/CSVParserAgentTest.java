/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Tests exercising the public API of {@link CSVParser}: the {@code parse(...)} factory methods, the
 * {@code Reader} constructor, {@link CSVParser#getRecords()}, {@link CSVParser#iterator()},
 * header handling, comment handling and the line / record counters.
 *
 * @version $Id$
 */
public class CSVParserAgentTest {

    private static final String THREE_BY_THREE = "a,b,c\n1,2,3\nx,y,z";

    private static File createTempCsvFile(final String content) throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        final Writer writer = new FileWriter(file);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    // ------------------------------------------------------------------
    // Factory / constructor argument validation
    // ------------------------------------------------------------------

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullStringThrowsException() throws Exception {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullFormatThrowsException() throws Exception {
        CSVParser.parse("a,b,c", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullFileThrowsException() throws Exception {
        CSVParser.parse((File) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullFormatThrowsException() throws Exception {
        CSVParser.parse(new File("src/test/resources/CSVFileParser"), null);
    }

    @Test(expected = FileNotFoundException.class)
    public void testParseMissingFileThrowsIOException() throws Exception {
        CSVParser.parse(new File("no-such-file-CSVParserAgentTest-12345.csv"), CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullUrlThrowsException() throws Exception {
        CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullCharsetThrowsException() throws Exception {
        CSVParser.parse(new URL("http://example.com"), null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullFormatThrowsException() throws Exception {
        CSVParser.parse(new URL("http://example.com"), Charset.forName("UTF-8"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrowsException() throws Exception {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrowsException() throws Exception {
        new CSVParser(new StringReader("a,b,c"), null);
    }

    @Test(expected = IllegalStateException.class)
    public void testConstructorRejectsInconsistentFormat() throws Exception {
        // delimiter == quoteChar is rejected by CSVFormat#validate(), invoked from the constructor
        new CSVParser(new StringReader("a,b,c"), CSVFormat.newFormat(',').withQuoteChar(','));
    }

    // ------------------------------------------------------------------
    // Factory / constructor happy path
    // ------------------------------------------------------------------

    @Test
    public void testParseStringFactoryReadsAllRecords() throws Exception {
        final CSVParser parser = CSVParser.parse(THREE_BY_THREE, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());

            final CSVRecord first = records.get(0);
            assertEquals(3, first.size());
            assertEquals("a", first.get(0));
            assertEquals("b", first.get(1));
            assertEquals("c", first.get(2));

            assertEquals("3", records.get(1).get(2));
            assertEquals("x", records.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseFileReadsAllRecords() throws Exception {
        final File file = createTempCsvFile("a,b,c\n1,2,3\n");
        try {
            final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("a", records.get(0).get(0));
                assertEquals("3", records.get(1).get(2));
            } finally {
                parser.close();
            }
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseUrlReadsAllRecords() throws Exception {
        final File file = createTempCsvFile("x,y\n1,2\n");
        try {
            final CSVParser parser =
                    CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("x", records.get(0).get(0));
                assertEquals("2", records.get(1).get(1));
            } finally {
                parser.close();
            }
        } finally {
            file.delete();
        }
    }

    // ------------------------------------------------------------------
    // getRecords / getRecords(Collection)
    // ------------------------------------------------------------------

    @Test
    public void testGetRecordsIsEmptyButNotNullOnSecondCall() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            assertEquals(2, parser.getRecords().size());
            final List<CSVRecord> second = parser.getRecords();
            assertNotNull(second);
            assertTrue(second.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsIntoProvidedCollection() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            final LinkedList<CSVRecord> target = new LinkedList<CSVRecord>();
            final LinkedList<CSVRecord> result = parser.getRecords(target);
            assertSame(target, result);
            assertEquals(2, result.size());
            assertEquals("a", result.getFirst().get(0));
            assertEquals("d", result.getLast().get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsStartsFromCurrentPosition() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals("a", it.next().get(0)); // consume the first record

            final List<CSVRecord> rest = parser.getRecords();
            assertEquals(2, rest.size());
            assertEquals("c", rest.get(0).get(0));
            assertEquals("e", rest.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws Exception {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertEquals(0, records.size());
            assertEquals(0, parser.getRecordNumber());
            assertFalse(parser.iterator().hasNext());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Field level parsing
    // ------------------------------------------------------------------

    @Test
    public void testAdjacentDelimitersProduceEmptyField() throws Exception {
        final CSVParser parser = CSVParser.parse("a,,c", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertEquals("a", record.get(0));
            assertEquals("", record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingDelimiterProducesTrailingEmptyField() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertEquals("", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedFieldWithDelimiterAndNewline() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a,b\",\"c\nd\"\n2,3", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a,b", records.get(0).get(0));
            assertEquals("c\nd", records.get(0).get(1));
            assertEquals("2", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDoubledQuoteIsUnescaped() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a\"\"b\",c", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("a\"b", record.get(0));
            assertEquals("c", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCustomDelimiter() throws Exception {
        final CSVParser parser = CSVParser.parse("a;b;c", CSVFormat.DEFAULT.withDelimiter(';'));
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTabDelimitedFormatTrimsSurroundingSpaces() throws Exception {
        final CSVParser parser = CSVParser.parse("a\t b \tc", CSVFormat.TDF);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIgnoreSurroundingSpaces() throws Exception {
        final CSVParser parser =
                CSVParser.parse("a , b , c ", CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true));
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testSurroundingSpacesKeptByDefault() throws Exception {
        final CSVParser parser = CSVParser.parse("a , b", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("a ", record.get(0));
            assertEquals(" b", record.get(1));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Line handling
    // ------------------------------------------------------------------

    @Test
    public void testIgnoreEmptyLinesByDefault() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n\n\nc,d\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyLinesPreservedWhenNotIgnored() throws Exception {
        final CSVParser parser =
                CSVParser.parse("a,b\n\nc,d", CSVFormat.DEFAULT.withIgnoreEmptyLines(false));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(1).size());
            assertEquals("", records.get(1).get(0));
            assertEquals("c", records.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCarriageReturnLineFeedEndings() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCarriageReturnEndings() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\rc,d\r", CSVFormat.DEFAULT);
        try {
            assertEquals(2, parser.getRecords().size());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Line number / record number counters
    // ------------------------------------------------------------------

    @Test
    public void testRecordNumberProgression() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> records = parser.iterator();
            assertEquals(0, parser.getRecordNumber());

            CSVRecord record = records.next();
            assertEquals(1, record.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());

            record = records.next();
            assertEquals(2, record.getRecordNumber());
            assertEquals(2, parser.getRecordNumber());

            record = records.next();
            assertEquals(3, record.getRecordNumber());
            assertEquals(3, parser.getRecordNumber());

            assertFalse(records.hasNext());
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCurrentLineNumberProgression() throws Exception {
        final CSVParser parser =
                CSVParser.parse("a\nb\nc", CSVFormat.DEFAULT.withRecordSeparator("\n"));
        try {
            final Iterator<CSVRecord> records = parser.iterator();
            assertEquals(0, parser.getCurrentLineNumber());
            assertNotNull(records.next());
            assertEquals(1, parser.getCurrentLineNumber());
            assertNotNull(records.next());
            assertEquals(2, parser.getCurrentLineNumber());
            assertNotNull(records.next());
            // the last line has no EOL, so the counter does not advance
            assertEquals(2, parser.getCurrentLineNumber());
            assertFalse(records.hasNext());
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // close() / isClosed()
    // ------------------------------------------------------------------

    @Test
    public void testIsClosedLifecycleAndIdempotentClose() throws Exception {
        final CSVParser parser = CSVParser.parse(THREE_BY_THREE, CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        parser.close(); // second close must be a harmless no-op
        assertTrue(parser.isClosed());
    }

    // ------------------------------------------------------------------
    // iterator()
    // ------------------------------------------------------------------

    @Test
    public void testForEachLoopVisitsEveryRecordInOrder() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f", CSVFormat.DEFAULT);
        try {
            final List<String> firsts = new ArrayList<String>();
            for (final CSVRecord record : parser) {
                firsts.add(record.get(0));
            }
            assertEquals(Arrays.asList("a", "c", "e"), firsts);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextIsIdempotent() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            assertEquals("a", it.next().get(0));
            assertEquals("d", it.next().get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testIteratorRemoveUnsupported() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            parser.iterator().remove();
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorThrowsAfterExhaustion() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertNotNull(it.next());
            assertFalse(it.hasNext());
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test(expected = NoSuchElementException.class)
    public void testCloseStopsIteration() throws Exception {
        final CSVParser parser =
                CSVFormat.DEFAULT.withHeader().parse(new StringReader(THREE_BY_THREE));
        final Iterator<CSVRecord> records = parser.iterator();
        assertTrue(records.hasNext());
        parser.close();
        assertTrue(parser.isClosed());
        assertFalse(records.hasNext());
        records.next();
    }

    @Test(expected = RuntimeException.class)
    public void testIteratorWrapsIOExceptionInRuntimeException() throws Exception {
        final CSVParser parser = CSVParser.parse("\"unterminated", CSVFormat.DEFAULT);
        try {
            parser.iterator().hasNext();
        } finally {
            parser.close();
        }
    }

    @Test
    public void testMultipleIteratorsShareTheUnderlyingStream() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it1 = parser.iterator();
            final Iterator<CSVRecord> it2 = parser.iterator();

            final CSVRecord first = it1.next();
            final CSVRecord second = it2.next();
            assertEquals("a", first.get(0));
            assertEquals("d", second.get(0));

            assertFalse(it1.hasNext());
            assertFalse(it2.hasNext());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Header handling
    // ------------------------------------------------------------------

    @Test
    public void testNoHeaderMapByDefault() throws Exception {
        final CSVParser parser = CSVParser.parse(THREE_BY_THREE, CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testProvidedHeaderMapIteratesInColumnOrder() throws Exception {
        final CSVParser parser =
                CSVParser.parse("1,2,3\nx,y,z", CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            final Iterator<String> names = headerMap.keySet().iterator();
            assertEquals("A", names.next());
            assertEquals("B", names.next());
            assertEquals("C", names.next());
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            // A provided (non-auto) header does not consume the first record.
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("z", records.get(1).get("C"));
            assertEquals(1, records.get(0).getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsAFreshCopy() throws Exception {
        final CSVParser parser =
                CSVParser.parse("1,2,3", CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> first = parser.getHeaderMap();
            first.put("EXTRA", Integer.valueOf(99));
            first.remove("A");

            final Map<String, Integer> second = parser.getHeaderMap();
            assertFalse(second.containsKey("EXTRA"));
            assertTrue(second.containsKey("A"));
            assertEquals(3, second.size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testAutoHeaderConsumesFirstRecord() throws Exception {
        final CSVParser parser = CSVParser.parse(THREE_BY_THREE, CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("a"));
            assertEquals(Integer.valueOf(1), headerMap.get("b"));
            assertEquals(Integer.valueOf(2), headerMap.get("c"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("a"));
            assertEquals("2", records.get(0).get("b"));
            assertEquals("z", records.get(1).get("c"));
            // the consumed header line is counted as record number 1
            assertEquals(2, records.get(0).getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testSkipHeaderRecordDropsFirstLine() throws Exception {
        final CSVParser parser = CSVParser.parse("h1,h2,h3\n1,2,3",
                CSVFormat.DEFAULT.withHeader("A", "B", "C").withSkipHeaderRecord(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("3", records.get(0).get("C"));
            assertEquals(2, records.get(0).getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalStateException.class)
    public void testDuplicateHeaderNamesFromRecordThrow() throws Exception {
        CSVParser.parse("a,b,a\n1,2,3", CSVFormat.DEFAULT.withHeader());
    }

    // ------------------------------------------------------------------
    // Comment handling
    // ------------------------------------------------------------------

    @Test
    public void testCommentBecomesRecordComment() throws Exception {
        final CSVParser parser =
                CSVParser.parse("# a header comment\na,b,c", CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals("a", record.get(0));
            assertEquals("a header comment", record.getComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testConsecutiveCommentsAreJoinedWithNewline() throws Exception {
        final CSVParser parser =
                CSVParser.parse("#c1\n#c2\na,b", CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("c1\nc2", record.getComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentOnlyInputProducesNoRecords() throws Exception {
        final CSVParser parser =
                CSVParser.parse("# just a comment", CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHashIsLiteralWithoutCommentFormat() throws Exception {
        final CSVParser parser = CSVParser.parse("a,#b,c", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("#b", record.get(1));
            assertNull(record.getComment());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Parse errors surfaced from getRecords()
    // ------------------------------------------------------------------

    @Test(expected = IOException.class)
    public void testUnterminatedQuoteThrowsIOException() throws Exception {
        final CSVParser parser = CSVParser.parse("\"unterminated,value", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
        } finally {
            parser.close();
        }
    }

    @Test(expected = IOException.class)
    public void testInvalidCharacterAfterClosingQuoteThrowsIOException() throws Exception {
        final CSVParser parser = CSVParser.parse("\"abc\"x,y", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
        } finally {
            parser.close();
        }
    }
}
