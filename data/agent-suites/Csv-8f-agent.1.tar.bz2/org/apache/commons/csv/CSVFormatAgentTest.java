/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.BACKSLASH;
import static org.apache.commons.csv.Constants.COMMA;
import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.CRLF;
import static org.apache.commons.csv.Constants.DOUBLE_QUOTE_CHAR;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.TAB;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringReader;
import java.util.List;

import org.junit.Test;

/**
 * Tests for the public API of {@link CSVFormat}.
 */
public class CSVFormatAgentTest {

    // ------------------------------------------------------------------
    // Predefined formats
    // ------------------------------------------------------------------

    @Test
    public void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(COMMA, format.getDelimiter());
        assertEquals(DOUBLE_QUOTE_CHAR, format.getQuoteChar());
        assertTrue(format.isQuoting());
        assertNull(format.getQuotePolicy());
        assertNull(format.getCommentStart());
        assertFalse(format.isCommentingEnabled());
        assertNull(format.getEscape());
        assertFalse(format.isEscaping());
        assertNull(format.getNullString());
        assertFalse(format.isNullHandling());
        assertEquals(CRLF, format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
    }

    @Test
    public void testRfc4180Properties() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertEquals(COMMA, format.getDelimiter());
        assertEquals(DOUBLE_QUOTE_CHAR, format.getQuoteChar());
        assertEquals(CRLF, format.getRecordSeparator());
        assertFalse("RFC4180 must not ignore empty lines", format.getIgnoreEmptyLines());
        assertNull(format.getCommentStart());
        assertNull(format.getEscape());
        // RFC4180 differs from DEFAULT only in the ignoreEmptyLines flag.
        assertFalse(CSVFormat.DEFAULT.equals(format));
    }

    @Test
    public void testExcelProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertEquals(COMMA, format.getDelimiter());
        assertEquals(DOUBLE_QUOTE_CHAR, format.getQuoteChar());
        assertEquals(CRLF, format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testMysqlProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals(TAB, format.getDelimiter());
        assertNull(format.getQuoteChar());
        assertFalse(format.isQuoting());
        assertEquals(Character.valueOf(BACKSLASH), format.getEscape());
        assertTrue(format.isEscaping());
        assertEquals("\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals(TAB, format.getDelimiter());
        assertEquals(DOUBLE_QUOTE_CHAR, format.getQuoteChar());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertEquals(CRLF, format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
    }

    // ------------------------------------------------------------------
    // newFormat factory
    // ------------------------------------------------------------------

    @Test
    public void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteChar());
        assertFalse(format.isQuoting());
        assertNull(format.getEscape());
        assertFalse(format.isEscaping());
        assertNull(format.getCommentStart());
        assertFalse(format.isCommentingEnabled());
        assertNull(format.getNullString());
        assertFalse(format.isNullHandling());
        assertNull(format.getQuotePolicy());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatWithCRThrows() {
        CSVFormat.newFormat(CR);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatWithLFThrows() {
        CSVFormat.newFormat(LF);
    }

    // ------------------------------------------------------------------
    // with* mutators: value change + immutability of the source object
    // ------------------------------------------------------------------

    @Test
    public void testWithDelimiterChangesValueAndKeepsImmutable() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.withDelimiter(';');
        assertEquals(';', modified.getDelimiter());
        assertEquals("original must be unchanged", COMMA, original.getDelimiter());
        assertNotSame(original, modified);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterLineBreakThrows() {
        CSVFormat.DEFAULT.withDelimiter(LF);
    }

    @Test
    public void testWithCommentStart() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        assertEquals(Character.valueOf('#'), format.getCommentStart());
        assertTrue(format.isCommentingEnabled());
        assertFalse("source object must be unchanged", CSVFormat.DEFAULT.isCommentingEnabled());
    }

    @Test
    public void testWithCommentStartNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#').withCommentStart((Character) null);
        assertNull(format.getCommentStart());
        assertFalse(format.isCommentingEnabled());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentStartLineBreakThrows() {
        CSVFormat.DEFAULT.withCommentStart(CR);
    }

    @Test
    public void testWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('!');
        assertEquals(Character.valueOf('!'), format.getEscape());
        assertTrue(format.isEscaping());
        assertFalse(CSVFormat.DEFAULT.isEscaping());
    }

    @Test
    public void testWithEscapeNullDisables() {
        final CSVFormat format = CSVFormat.MYSQL.withEscape((Character) null);
        assertNull(format.getEscape());
        assertFalse(format.isEscaping());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeLineBreakThrows() {
        CSVFormat.DEFAULT.withEscape(LF);
    }

    @Test
    public void testWithQuoteChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteChar());
        assertTrue(format.isQuoting());
    }

    @Test
    public void testWithQuoteCharNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar((Character) null);
        assertNull(format.getQuoteChar());
        assertFalse(format.isQuoting());
        assertTrue("source object must still be quoting", CSVFormat.DEFAULT.isQuoting());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteCharLineBreakThrows() {
        CSVFormat.DEFAULT.withQuoteChar(CR);
    }

    @Test
    public void testWithQuotePolicy() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC);
        assertEquals(Quote.NON_NUMERIC, format.getQuotePolicy());
        assertNull("source object policy must be unchanged", CSVFormat.DEFAULT.getQuotePolicy());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        assertEquals("\r\n", CSVFormat.newFormat(',').withRecordSeparator("\r\n").getRecordSeparator());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullHandling());
        assertFalse(CSVFormat.DEFAULT.isNullHandling());
    }

    @Test
    public void testWithNullStringNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("x").withNullString(null);
        assertNull(format.getNullString());
        assertFalse(format.isNullHandling());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(true).withSkipHeaderRecord(false).getSkipHeaderRecord());
        assertFalse("source object must be unchanged", CSVFormat.DEFAULT.getSkipHeaderRecord());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
    }

    // ------------------------------------------------------------------
    // Header handling
    // ------------------------------------------------------------------

    @Test
    public void testWithHeaderDistinctElements() {
        final String[] header = CSVFormat.DEFAULT.withHeader("A", "B", "C").getHeader();
        assertArrayEquals(new String[] { "A", "B", "C" }, header);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithHeaderDuplicateElementsThrows() {
        CSVFormat.DEFAULT.withHeader("A", "A");
    }

    @Test
    public void testWithHeaderEmptyIsNonNull() {
        assertArrayEquals(new String[0], CSVFormat.DEFAULT.withHeader().getHeader());
    }

    @Test
    public void testWithHeaderNull() {
        assertNull(CSVFormat.DEFAULT.withHeader((String[]) null).getHeader());
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        final String[] first = format.getHeader();
        first[0] = "MUTATED";
        assertArrayEquals("mutating the returned array must not affect the format",
                new String[] { "A", "B" }, format.getHeader());
        assertNotSame(format.getHeader(), format.getHeader());
    }

    @Test
    public void testWithHeaderCopiesInputArray() {
        final String[] input = { "A", "B" };
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(input);
        input[0] = "MUTATED";
        assertArrayEquals("mutating the input array must not affect the format",
                new String[] { "A", "B" }, format.getHeader());
    }

    @Test
    public void testChainedWithCallsPreserveAllSettings() {
        final CSVFormat format = CSVFormat.newFormat(';')
                .withQuoteChar('"')
                .withCommentStart('#')
                .withEscape('!')
                .withRecordSeparator("\r\n")
                .withNullString("NULL")
                .withIgnoreSurroundingSpaces(true)
                .withIgnoreEmptyLines(true)
                .withSkipHeaderRecord(true)
                .withQuotePolicy(Quote.MINIMAL)
                .withHeader("h1", "h2");
        assertEquals(';', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteChar());
        assertEquals(Character.valueOf('#'), format.getCommentStart());
        assertEquals(Character.valueOf('!'), format.getEscape());
        assertEquals("\r\n", format.getRecordSeparator());
        assertEquals("NULL", format.getNullString());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreEmptyLines());
        assertTrue(format.getSkipHeaderRecord());
        assertEquals(Quote.MINIMAL, format.getQuotePolicy());
        assertArrayEquals(new String[] { "h1", "h2" }, format.getHeader());
    }

    // ------------------------------------------------------------------
    // equals / hashCode
    // ------------------------------------------------------------------

    @Test
    public void testEqualsReflexive() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentInstances() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuoteChar('"').withRecordSeparator(CRLF)
                .withIgnoreEmptyLines(true);
        final CSVFormat b = CSVFormat.newFormat(',').withQuoteChar('"').withRecordSeparator(CRLF)
                .withIgnoreEmptyLines(true);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        assertNotSame(a, b);
        // The above configuration reconstructs CSVFormat.DEFAULT.
        assertTrue(a.equals(CSVFormat.DEFAULT));
        assertEquals(CSVFormat.DEFAULT.hashCode(), a.hashCode());
    }

    @Test
    public void testEqualsForDifferingDelimiter() {
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT.withDelimiter(';')));
    }

    @Test
    public void testEqualsForDifferingHeader() {
        assertFalse(CSVFormat.DEFAULT.withHeader("A").equals(CSVFormat.DEFAULT.withHeader("B")));
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT.withHeader("A")));
    }

    @Test
    public void testNoOpWithReturnsEqualInstance() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT.withDelimiter(','));
        assertEquals(CSVFormat.DEFAULT.hashCode(), CSVFormat.DEFAULT.withDelimiter(',').hashCode());
    }

    // ------------------------------------------------------------------
    // toString
    // ------------------------------------------------------------------

    @Test
    public void testToStringDefault() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s, s.contains("Delimiter=<,>"));
        assertTrue(s, s.contains("QuoteChar=<\">"));
        assertTrue(s, s.contains("EmptyLines:ignored"));
        assertTrue(s, s.contains("SkipHeaderRecord:false"));
        assertFalse(s, s.contains("Escape=<"));
        assertFalse(s, s.contains("Header:"));
    }

    @Test
    public void testToStringWithEscapeAndHeader() {
        final String s = CSVFormat.DEFAULT.withEscape('\\').withHeader("A", "B").withSkipHeaderRecord(true).toString();
        assertTrue(s, s.contains("Escape=<\\>"));
        assertTrue(s, s.contains("Header:[A, B]"));
        assertTrue(s, s.contains("SkipHeaderRecord:true"));
    }

    // ------------------------------------------------------------------
    // format(Object...)
    // ------------------------------------------------------------------

    @Test
    public void testFormatEmpty() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatSimple() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatValueContainingDelimiterGetsQuoted() {
        assertEquals("\"x,y\",z", CSVFormat.DEFAULT.format("x,y", "z"));
    }

    @Test
    public void testFormatWithQuotePolicyAll() {
        assertEquals("\"a\",\"b\"", CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL).format("a", "b"));
    }

    @Test
    public void testFormatLeadingSpaceGetsQuoted() {
        assertEquals("\" a\"", CSVFormat.DEFAULT.format(" a"));
    }

    @Test
    public void testFormatWithCustomDelimiter() {
        assertEquals("a;b", CSVFormat.newFormat(';').format("a", "b"));
    }

    @Test
    public void testFormatWithEscapingMysql() {
        // MYSQL: tab delimiter, backslash escape, no quoting -> the embedded tab is escaped.
        assertEquals("a\tb\\\tc", CSVFormat.MYSQL.format("a", "b\tc"));
    }

    @Test(expected = IllegalStateException.class)
    public void testFormatWithNoneQuotePolicyAndNoEscapeThrows() {
        CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE).format("a");
    }

    @Test(expected = NullPointerException.class)
    public void testFormatNullArrayThrows() {
        CSVFormat.DEFAULT.format((Object[]) null);
    }

    // ------------------------------------------------------------------
    // parse(Reader)
    // ------------------------------------------------------------------

    @Test
    public void testParseSimple() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\nd,e,f"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(0).get(2));
            assertEquals("d", records.get(1).get(0));
            assertEquals("f", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithHeader() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.withHeader("X", "Y", "Z").parse(new StringReader("1,2,3"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("X"));
            assertEquals("3", records.get(0).get("Z"));
            assertTrue(parser.getHeaderMap().containsKey("X"));
            assertEquals(Integer.valueOf(1), parser.getHeaderMap().get("Y"));
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullReaderThrows() throws IOException {
        CSVFormat.DEFAULT.parse(null);
    }

    // ------------------------------------------------------------------
    // Serializable contract
    // ------------------------------------------------------------------

    @Test
    public void testSerializationRoundTrip() throws Exception {
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        try {
            oos.writeObject(CSVFormat.DEFAULT);
        } finally {
            oos.close();
        }
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final CSVFormat copy;
        try {
            copy = (CSVFormat) ois.readObject();
        } finally {
            ois.close();
        }
        assertEquals(CSVFormat.DEFAULT.getDelimiter(), copy.getDelimiter());
        assertEquals(CSVFormat.DEFAULT.getQuoteChar(), copy.getQuoteChar());
        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), copy.getRecordSeparator());
        assertEquals(CSVFormat.DEFAULT.getIgnoreEmptyLines(), copy.getIgnoreEmptyLines());
        assertEquals(CSVFormat.DEFAULT.getSkipHeaderRecord(), copy.getSkipHeaderRecord());
    }
}
