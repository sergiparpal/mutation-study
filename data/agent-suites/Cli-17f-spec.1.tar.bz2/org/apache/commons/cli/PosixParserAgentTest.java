package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Tests for {@link PosixParser}, based solely on the documented contract of
 * its {@code flatten(Options, String[], boolean)} method (and, transitively,
 * {@code burstToken(String, boolean)}, which flatten delegates to for tokens
 * longer than two characters). Both methods are {@code protected}, so this
 * test lives in the same package to invoke them directly.
 */
public class PosixParserAgentTest extends TestCase {

    private PosixParser parser;

    protected void setUp() throws Exception {
        super.setUp();
        parser = new PosixParser();
    }

    private void assertTokens(String[] expected, String[] actual) {
        assertNotNull("flatten() must not return null", actual);
        assertEquals("token count", expected.length, actual.length);
        for (int i = 0; i < expected.length; i++) {
            assertEquals("token[" + i + "]", expected[i], actual[i]);
        }
    }

    // -----------------------------------------------------------------
    // Class identity / hierarchy, per the documented "Class PosixParser"
    // page: "extends org.apache.commons.cli.Parser" and
    // "All Implemented Interfaces: CommandLineParser".
    // -----------------------------------------------------------------

    public void testConstructorImplementsDocumentedHierarchy() {
        assertNotNull(parser);
        assertTrue("PosixParser must extend Parser",
                parser instanceof org.apache.commons.cli.Parser);
        assertTrue("PosixParser must implement CommandLineParser",
                parser instanceof org.apache.commons.cli.CommandLineParser);
    }

    // -----------------------------------------------------------------
    // flatten(): boundary case - no arguments at all.
    // -----------------------------------------------------------------

    public void testFlattenEmptyArgumentsReturnsEmptyArray() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[0], false);
        assertTokens(new String[0], result);
    }

    // -----------------------------------------------------------------
    // Rule 2: "--" alone is added to the processed tokens as-is.
    // -----------------------------------------------------------------

    public void testFlattenDoubleDashAloneIsPreserved() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[] { "--" }, false);
        assertTokens(new String[] { "--" }, result);
    }

    // "--" is the classic "stop parsing options" marker; per rule 1 ("do not
    // burst anymore of arguments entries, just add each successive entry
    // without further processing"), once encountered the remaining entries
    // are passed through unchanged. We check this with an entry ("-z") that
    // would otherwise be dropped by rule 4 (unknown 2-char option, not
    // stopAtNonOption) so the two behaviors are distinguishable.
    public void pruned_testFlattenDoubleDashCausesRemainingArgumentsToPassThroughUnprocessed() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[] { "--", "-z" }, false);
        assertTokens(new String[] { "--", "-z" }, result);
    }

    // -----------------------------------------------------------------
    // Rule 3: "-" alone is added to the processed tokens as-is, and (unlike
    // "--") does not cause later entries to be passed through unprocessed.
    // -----------------------------------------------------------------

    public void testFlattenSingleDashAloneIsPreserved() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[] { "-" }, false);
        assertTokens(new String[] { "-" }, result);
    }

    public void testFlattenSingleDashDoesNotConsumeFollowingArguments() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[] { "-", "foo" }, false);
        assertTokens(new String[] { "-", "foo" }, result);
    }

    // -----------------------------------------------------------------
    // Rule 4: two-character entry starting with "-".
    // -----------------------------------------------------------------

    public void testFlattenValidTwoCharOptionIsPreserved() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        String[] result = parser.flatten(options, new String[] { "-a" }, false);
        assertTokens(new String[] { "-a" }, result);
    }

    // Doc: "If it is not a valid id and stopAtNonOption is true, then the
    // remaining entries are copied to the list of processed tokens.
    // Otherwise, the current entry is ignored."
    public void testFlattenInvalidTwoCharOptionIsIgnoredWhenNotStopAtNonOption() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[] { "-z" }, false);
        assertTokens(new String[0], result);
    }

    public void pruned_testFlattenInvalidTwoCharOptionCopiesRemainingWhenStopAtNonOption() {
        Options options = new Options();
        String[] result = parser.flatten(
                options, new String[] { "-z", "foo", "bar" }, true);
        assertTokens(new String[] { "-z", "foo", "bar" }, result);
    }

    // Rule 1's second sentence: "Otherwise, ignore stopAtNonOption" - a
    // valid two-character option is processed the same way whether or not
    // stopAtNonOption is set.
    public void pruned_testFlattenStopAtNonOptionIsIrrelevantForValidOptions() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        String[] result = parser.flatten(
                options, new String[] { "-a", "value" }, true);
        assertTokens(new String[] { "-a", "value" }, result);
    }

    // -----------------------------------------------------------------
    // Rule 6: entries not covered by the earlier rules are added as-is.
    // -----------------------------------------------------------------

    public void testFlattenNonOptionArgumentsPassThroughUnchanged() {
        Options options = new Options();
        String[] result = parser.flatten(
                options, new String[] { "value1", "value2" }, false);
        assertTokens(new String[] { "value1", "value2" }, result);
    }

    // -----------------------------------------------------------------
    // Rule 5 + burstToken: entries longer than two characters starting
    // with "-" are burst into their constituent parts.
    // -----------------------------------------------------------------

    // burstToken: "foreach remaining character check if an Option exists
    // with that id. If an Option does exist then add that character
    // prepended with '-' to the list of processed tokens."
    public void testFlattenBurstsMultipleValidNoArgOptions() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("b", false, "flag b");
        String[] result = parser.flatten(options, new String[] { "-ab" }, false);
        assertTokens(new String[] { "-a", "-b" }, result);
    }

    // burstToken: "if the Option can have an argument value and there are
    // remaining characters in the token then add the remaining characters
    // as a token to the list of processed tokens."
    public void testFlattenBurstOptionWithArgumentConsumesRemainderAsSingleValue() {
        Options options = new Options();
        options.addOption("c", true, "option c takes a value");
        String[] result = parser.flatten(options, new String[] { "-cxy" }, false);
        assertTokens(new String[] { "-c", "xy" }, result);
    }

    // burstToken: "if an Option does NOT exist AND stopAtNonOption IS NOT
    // set then add that character prepended with '-'."
    public void pruned_testFlattenBurstAddsUnknownCharsIndividuallyWhenNotStopAtNonOption() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[] { "-xyz" }, false);
        assertTokens(new String[] { "-x", "-y", "-z" }, result);
    }

    public void pruned_testFlattenBurstContinuesPastUnknownCharWhenNotStopAtNonOption() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        String[] result = parser.flatten(options, new String[] { "-ab" }, false);
        assertTokens(new String[] { "-a", "-b" }, result);
    }

    // -----------------------------------------------------------------
    // Ordering / independence across multiple entries.
    // -----------------------------------------------------------------

    public void testFlattenPreservesOrderAcrossMixedEntryTypes() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("b", false, "flag b");
        String[] result = parser.flatten(
                options, new String[] { "-a", "value", "-b" }, false);
        assertTokens(new String[] { "-a", "value", "-b" }, result);
    }

    public void testFlattenIgnoredEntryDoesNotAffectSubsequentProcessing() {
        Options options = new Options();
        String[] result = parser.flatten(
                options, new String[] { "-z", "keep" }, false);
        assertTokens(new String[] { "keep" }, result);
    }

    // -----------------------------------------------------------------
    // flatten() is driven entirely by the Options/arguments passed to a
    // given call; reusing the same parser instance for an independent call
    // with different Options must not leak state from a prior call.
    // -----------------------------------------------------------------

    public void testFlattenDoesNotLeakOptionsStateAcrossCalls() {
        Options withA = new Options();
        withA.addOption("a", false, "flag a");
        String[] first = parser.flatten(withA, new String[] { "-a" }, false);
        assertTokens(new String[] { "-a" }, first);

        Options withoutA = new Options();
        String[] second = parser.flatten(withoutA, new String[] { "-a" }, false);
        assertTokens(new String[0], second);
    }
}
