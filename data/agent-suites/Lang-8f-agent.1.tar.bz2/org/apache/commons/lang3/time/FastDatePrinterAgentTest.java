/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.SerializationUtils;
import org.junit.Test;

/**
 * Tests the public API of {@link org.apache.commons.lang3.time.FastDatePrinter}.
 *
 * <p>{@code FastDatePrinter} is only exposed through its package/subclass visible
 * constructor, which is the same access path used by the existing
 * {@code FastDateParserTest} for {@code FastDateParser}.</p>
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone GMT_PLUS_5 = TimeZone.getTimeZone("GMT+05:00");

    // ------------------------------------------------------------------ helpers

    private static Calendar gmtCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final GregorianCalendar c = new GregorianCalendar(GMT, Locale.US);
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    /** Tuesday, 2004-02-03 05:06:07.008 GMT ; day-of-year 34 ; era AD. */
    private static Calendar canonicalCalendar() {
        return gmtCalendar(2004, Calendar.FEBRUARY, 3, 5, 6, 7, 8);
    }

    private static String fmt(final String pattern, final Calendar cal) {
        return new FastDatePrinter(pattern, GMT, Locale.US).format(cal);
    }

    private static void assertMatchesSimpleDateFormat(final String pattern, final TimeZone zone,
            final Locale locale, final Date date) {
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, locale);
        sdf.setTimeZone(zone);
        final FastDatePrinter fdp = new FastDatePrinter(pattern, zone, locale);
        final String message = "pattern=<" + pattern + "> zone=<" + zone.getID()
                + "> millis=" + date.getTime();
        assertEquals(message, sdf.format(date), fdp.format(date));
    }

    // --------------------------------------------------------------- accessors

    @Test
    public void testGettersReturnConstructorArguments() {
        final FastDatePrinter printer =
                new FastDatePrinter("yyyy-MM-dd HH:mm", GMT_PLUS_5, Locale.GERMANY);
        assertEquals("yyyy-MM-dd HH:mm", printer.getPattern());
        assertSame(GMT_PLUS_5, printer.getTimeZone());
        assertSame(Locale.GERMANY, printer.getLocale());
    }

    @Test
    public void testGetMaxLengthEstimate() {
        assertEquals(10, new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US).getMaxLengthEstimate());
        assertEquals(0, new FastDatePrinter("", GMT, Locale.US).getMaxLengthEstimate());

        final String[] safePatterns = {
            "yyyy-MM-dd",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm:ss.SSS",
            "dd/MM/yyyy",
        };
        final Date date = canonicalCalendar().getTime();
        for (final String pattern : safePatterns) {
            final FastDatePrinter fdp = new FastDatePrinter(pattern, GMT, Locale.US);
            final int estimate = fdp.getMaxLengthEstimate();
            final int actual = fdp.format(date).length();
            assertTrue(pattern + " estimate=" + estimate, estimate > 0);
            assertTrue(pattern + " estimate=" + estimate + " actual=" + actual, estimate >= actual);
        }
    }

    @Test
    public void testEmptyPattern() {
        final FastDatePrinter empty = new FastDatePrinter("", GMT, Locale.US);
        assertEquals("", empty.getPattern());
        assertEquals(0, empty.getMaxLengthEstimate());
        assertEquals("", empty.format(canonicalCalendar()));
        assertEquals("", empty.format(canonicalCalendar().getTime()));
        assertEquals("", empty.format(0L));
    }

    // ----------------------------------------------------------------- values

    @Test
    public void testFormatNumericFieldsAgainstFixedInstant() {
        final Calendar cal = canonicalCalendar();
        assertEquals("2004-02-03", fmt("yyyy-MM-dd", cal));
        assertEquals("2004-02-03 05:06:07.008", fmt("yyyy-MM-dd HH:mm:ss.SSS", cal));
        assertEquals("20040203050607008", fmt("yyyyMMddHHmmssSSS", cal));
        assertEquals("2004", fmt("yyyy", cal));
        assertEquals("04", fmt("yy", cal));
        assertEquals("2/3/04", fmt("M/d/yy", cal));
        assertEquals("02/03/2004", fmt("MM/dd/yyyy", cal));
        assertEquals("5:06", fmt("H:mm", cal));
        assertEquals("05:06", fmt("HH:mm", cal));
    }

    @Test
    public void testFormatTextFieldsAgainstFixedInstant() {
        final Calendar cal = canonicalCalendar();
        assertEquals("AD", fmt("G", cal));
        assertEquals("Tue", fmt("EEE", cal));
        assertEquals("Tuesday", fmt("EEEE", cal));
        assertEquals("Feb", fmt("MMM", cal));
        assertEquals("February", fmt("MMMM", cal));
        assertEquals("2", fmt("M", cal));
        assertEquals("02", fmt("MM", cal));
        assertEquals("5 AM", fmt("h a", cal));
    }

    @Test
    public void testFormatHourFieldsAtMidnightNoonAndEvening() {
        final Calendar midnight = gmtCalendar(2004, Calendar.FEBRUARY, 3, 0, 0, 0, 0);
        assertEquals("12", fmt("h", midnight));
        assertEquals("0", fmt("K", midnight));
        assertEquals("0", fmt("H", midnight));
        assertEquals("24", fmt("k", midnight));
        assertEquals("12:00 AM", fmt("h:mm a", midnight));

        final Calendar noon = gmtCalendar(2004, Calendar.FEBRUARY, 3, 12, 0, 0, 0);
        assertEquals("12", fmt("h", noon));
        assertEquals("0", fmt("K", noon));
        assertEquals("12", fmt("H", noon));
        assertEquals("12", fmt("k", noon));
        assertEquals("12:00 PM", fmt("h:mm a", noon));

        final Calendar evening = gmtCalendar(2004, Calendar.FEBRUARY, 3, 23, 0, 0, 0);
        assertEquals("11", fmt("h", evening));
        assertEquals("11", fmt("K", evening));
        assertEquals("23", fmt("H", evening));
        assertEquals("23", fmt("k", evening));
    }

    @Test
    public void testFormatMillisecondPadding() {
        final Calendar small = gmtCalendar(2004, Calendar.FEBRUARY, 3, 5, 6, 7, 8);
        assertEquals("8", fmt("S", small));
        assertEquals("08", fmt("SS", small));
        assertEquals("008", fmt("SSS", small));
        assertEquals("0008", fmt("SSSS", small));

        final Calendar big = gmtCalendar(2004, Calendar.FEBRUARY, 3, 5, 6, 7, 123);
        assertEquals("123", fmt("S", big));
        assertEquals("123", fmt("SSS", big));
        assertEquals("0123", fmt("SSSS", big));
    }

    @Test
    public void testFormatDayOfYearBoundaries() {
        assertEquals("1", fmt("D", gmtCalendar(2004, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("34", fmt("D", gmtCalendar(2004, Calendar.FEBRUARY, 3, 0, 0, 0, 0)));
        // 2004 is a leap year -> 366 days
        assertEquals("366", fmt("D", gmtCalendar(2004, Calendar.DECEMBER, 31, 0, 0, 0, 0)));
        assertEquals("365", fmt("D", gmtCalendar(2003, Calendar.DECEMBER, 31, 0, 0, 0, 0)));
        assertEquals("001", fmt("DDD", gmtCalendar(2004, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("366", fmt("DDD", gmtCalendar(2004, Calendar.DECEMBER, 31, 0, 0, 0, 0)));
    }

    @Test
    public void testLiteralsInPattern() {
        final Calendar cal = canonicalCalendar();
        assertEquals("It is 2004", fmt("'It is' yyyy", cal));
        assertEquals("2004'02", fmt("yyyy''MM", cal));
        assertEquals("2004X02", fmt("yyyy'X'MM", cal));
        assertEquals("no fields here", fmt("'no fields here'", cal));
        assertEquals("2004 o'clock", fmt("yyyy 'o''clock'", cal));
    }

    @Test
    public void testFormatTimeZoneName() {
        final Calendar gmtCal = canonicalCalendar();
        assertEquals("GMT", new FastDatePrinter("z", GMT, Locale.US).format(gmtCal));

        final String longName = new FastDatePrinter("zzzz", GMT, Locale.US).format(gmtCal);
        assertTrue("long time zone name was <" + longName + ">", longName.length() > "GMT".length());

        assertEquals("+0000", new FastDatePrinter("Z", GMT, Locale.US).format(gmtCal));
        assertEquals("+00:00", new FastDatePrinter("ZZ", GMT, Locale.US).format(gmtCal));

        final Calendar plus5 = Calendar.getInstance(GMT_PLUS_5, Locale.US);
        plus5.setTimeInMillis(gmtCal.getTimeInMillis());
        assertEquals("+0500", new FastDatePrinter("Z", GMT_PLUS_5, Locale.US).format(plus5));
        assertEquals("+05:00", new FastDatePrinter("ZZ", GMT_PLUS_5, Locale.US).format(plus5));
    }

    @Test
    public void testFormatMatchesSimpleDateFormat() {
        final String[] patterns = {
            "yyyy-MM-dd",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm:ss.SSS",
            "yyyyMMddHHmmssSSS",
            "yy/M/d",
            "MM/dd/yyyy G",
            "h:mm:ss a",
            "K:mm k H",
            "EEE, MMM d, yyyy",
            "EEEE MMMM",
            "D F w W",
            "yyyy''MM''dd",
            "'now' yyyy 'at' HH:mm",
            "yyyy-MM-dd'T'HH:mm:ssZ",
        };
        final Date[] dates = {
            canonicalCalendar().getTime(),
            gmtCalendar(2004, Calendar.FEBRUARY, 3, 0, 0, 0, 0).getTime(),
            gmtCalendar(2004, Calendar.FEBRUARY, 3, 12, 0, 0, 0).getTime(),
            gmtCalendar(2004, Calendar.DECEMBER, 31, 23, 59, 59, 999).getTime(),
            new Date(0L),
            new Date(1000000000000L),
            new Date(),
        };
        for (final String pattern : patterns) {
            for (final Date date : dates) {
                assertMatchesSimpleDateFormat(pattern, GMT, Locale.US, date);
                assertMatchesSimpleDateFormat(pattern, GMT_PLUS_5, Locale.US, date);
            }
        }
    }

    @Test
    public void testFormatMatchesSimpleDateFormatForGermanLocale() {
        final String[] patterns = { "dd.MM.yyyy", "EEEE, d. MMMM yyyy", "EEE MMM" };
        final Date[] dates = {
            canonicalCalendar().getTime(),
            gmtCalendar(2011, Calendar.MARCH, 15, 8, 0, 0, 0).getTime(),
            new Date(1000000000000L),
        };
        for (final String pattern : patterns) {
            for (final Date date : dates) {
                assertMatchesSimpleDateFormat(pattern, GMT, Locale.GERMANY, date);
            }
        }
    }

    // -------------------------------------------------------- overload contracts

    @Test
    public void testFormatDateLongCalendarAreConsistent() {
        final FastDatePrinter fdp = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS", GMT, Locale.US);
        final long millis = canonicalCalendar().getTimeInMillis();
        final Date date = new Date(millis);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTimeInMillis(millis);

        final String expected = "2004-02-03 05:06:07.008";
        assertEquals(expected, fdp.format(millis));
        assertEquals(expected, fdp.format(date));
        assertEquals(expected, fdp.format(cal));
        assertEquals(expected, fdp.format(millis, new StringBuffer()).toString());
        assertEquals(expected, fdp.format(date, new StringBuffer()).toString());
        assertEquals(expected, fdp.format(cal, new StringBuffer()).toString());
    }

    @Test
    public void testFormatAppendsToProvidedBufferAndReturnsSameInstance() {
        final FastDatePrinter fdp = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Date date = canonicalCalendar().getTime();
        final Calendar cal = canonicalCalendar();
        final long millis = cal.getTimeInMillis();

        final StringBuffer b1 = new StringBuffer("<<");
        assertSame(b1, fdp.format(date, b1));
        assertEquals("<<2004-02-03", b1.toString());

        final StringBuffer b2 = new StringBuffer("<<");
        assertSame(b2, fdp.format(cal, b2));
        assertEquals("<<2004-02-03", b2.toString());

        final StringBuffer b3 = new StringBuffer("<<");
        assertSame(b3, fdp.format(millis, b3));
        assertEquals("<<2004-02-03", b3.toString());

        final StringBuffer b4 = new StringBuffer("<<");
        assertSame(b4, fdp.format((Object) date, b4, new FieldPosition(0)));
        assertEquals("<<2004-02-03", b4.toString());
    }

    @Test
    public void testFormatObjectAcceptsDateCalendarAndLong() {
        final FastDatePrinter fdp = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        final Calendar cal = canonicalCalendar();
        final long millis = cal.getTimeInMillis();
        final Date date = new Date(millis);
        final FieldPosition pos = new FieldPosition(0);

        final String expected = "2004-02-03 05:06:07";
        assertEquals(expected, fdp.format((Object) date, new StringBuffer(), pos).toString());
        assertEquals(expected, fdp.format((Object) cal, new StringBuffer(), pos).toString());
        assertEquals(expected, fdp.format((Object) Long.valueOf(millis), new StringBuffer(), pos).toString());
    }

    @Test
    public void testFormatObjectRejectsUnsupportedType() {
        final FastDatePrinter fdp = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        try {
            fdp.format("2004-02-03", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for a String argument");
        } catch (final IllegalArgumentException ex) {
            assertTrue(ex.getMessage(), ex.getMessage().contains("String"));
        }
        try {
            fdp.format(Integer.valueOf(5), new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for an Integer argument");
        } catch (final IllegalArgumentException ex) {
            assertTrue(ex.getMessage(), ex.getMessage().contains("Integer"));
        }
    }

    @Test
    public void testFormatObjectRejectsNull() {
        final FastDatePrinter fdp = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        try {
            fdp.format(null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for a null argument");
        } catch (final IllegalArgumentException ex) {
            assertTrue(ex.getMessage(), ex.getMessage().contains("<null>"));
        }
    }

    // ------------------------------------------------------- time zone handling

    @Test
    public void testFormatCalendarUsesCalendarOwnTimeZone() {
        final FastDatePrinter printer =
                new FastDatePrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        final long millis = 1000000000000L; // 2001-09-09 01:46:40 UTC

        final Calendar plus5 = Calendar.getInstance(GMT_PLUS_5, Locale.US);
        plus5.setTimeInMillis(millis);
        assertEquals("2001-09-09 06:46:40", printer.format(plus5));

        // the Date / long overloads use the printer's own zone (GMT)
        assertEquals("2001-09-09 01:46:40", printer.format(new Date(millis)));
        assertEquals("2001-09-09 01:46:40", printer.format(millis));

        // a calendar already in the printer's zone matches the Date overload
        final Calendar gmtCal = Calendar.getInstance(GMT, Locale.US);
        gmtCal.setTimeInMillis(millis);
        assertEquals(printer.format(new Date(millis)), printer.format(gmtCal));
    }

    @Test
    public void testFormatDoesNotMutateSuppliedCalendar() {
        final FastDatePrinter printer =
                new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss.SSSZ", GMT, Locale.US);
        final Calendar cal = canonicalCalendar();
        final long millisBefore = cal.getTimeInMillis();
        final int hourBefore = cal.get(Calendar.HOUR_OF_DAY);
        final TimeZone zoneBefore = cal.getTimeZone();

        printer.format(cal);
        printer.format(cal, new StringBuffer());

        assertEquals(millisBefore, cal.getTimeInMillis());
        assertEquals(hourBefore, cal.get(Calendar.HOUR_OF_DAY));
        assertSame(zoneBefore, cal.getTimeZone());
    }

    // ------------------------------------------------------ constructor errors

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsUnknownLowercasePatternLetter() {
        new FastDatePrinter("yyyy-q", GMT, Locale.US);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsUnknownUppercasePatternLetter() {
        new FastDatePrinter("yyyy-U", GMT, Locale.US);
    }

    @Test(expected = NullPointerException.class)
    public void testConstructorRejectsNullPattern() {
        new FastDatePrinter(null, GMT, Locale.US);
    }

    @Test(expected = NullPointerException.class)
    public void testConstructorRejectsNullLocale() {
        new FastDatePrinter("yyyy-MM-dd", GMT, null);
    }

    // --------------------------------------------------- equals / hashCode / etc

    @Test
    public void testEqualsAndHashCode() {
        final FastDatePrinter a = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final FastDatePrinter b = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);

        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertTrue(a.equals(a));
        assertEquals(a.hashCode(), b.hashCode());

        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(new FastDatePrinter("yyyy/MM/dd", GMT, Locale.US)));
        assertFalse(a.equals(new FastDatePrinter("yyyy-MM-dd", GMT_PLUS_5, Locale.US)));
        assertFalse(a.equals(new FastDatePrinter("yyyy-MM-dd", GMT, Locale.GERMANY)));
    }

    @Test
    public void testToString() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("FastDatePrinter[yyyy-MM-dd,en_US,GMT]", printer.toString());
    }

    @Test
    public void testSerializationRoundTrip() {
        final FastDatePrinter original =
                new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss.SSS Z", GMT_PLUS_5, Locale.US);
        final FastDatePrinter copy =
                SerializationUtils.deserialize(SerializationUtils.serialize(original));

        assertTrue(original.equals(copy));
        assertEquals(original.hashCode(), copy.hashCode());
        assertEquals(original.getPattern(), copy.getPattern());
        assertEquals(original.getTimeZone(), copy.getTimeZone());
        assertEquals(original.getLocale(), copy.getLocale());
        assertEquals(original.getMaxLengthEstimate(), copy.getMaxLengthEstimate());

        final Date date = new Date(1000000000000L);
        assertEquals(original.format(date), copy.format(date));
        // proves the transient rules were rebuilt on deserialization
        assertEquals("2001-09-09T06:46:40.000 +0500", copy.format(date));
    }

    @Test
    public void testConcurrentFormattingIsConsistent() throws InterruptedException {
        final FastDatePrinter fdp =
                new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss.SSS Z", GMT, Locale.US);
        final Date date = new Date(1000000000000L);
        final String expected = fdp.format(date);
        assertEquals("2001-09-09T01:46:40.000 +0000", expected);

        final int threadCount = 8;
        final int iterations = 250;
        final AtomicInteger mismatches = new AtomicInteger(0);
        final ExecutorService pool = Executors.newFixedThreadPool(threadCount);
        for (int t = 0; t < threadCount; t++) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    for (int i = 0; i < iterations; i++) {
                        if (!expected.equals(fdp.format(date))) {
                            mismatches.incrementAndGet();
                        }
                    }
                }
            });
        }
        pool.shutdown();
        assertTrue("formatting tasks did not finish in time",
                pool.awaitTermination(30, TimeUnit.SECONDS));
        assertEquals("concurrent formatting produced inconsistent output", 0, mismatches.get());
    }
}
