package com.google.gson.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

/**
 * Tests for {@link com.google.gson.internal.$Gson$Types}, based solely on the
 * documented contract in the generated javadoc for that class.
 */
public class $Gson$TypesAgentTest {

  // ---------------------------------------------------------------------
  // Fixtures used only for extracting genuine java.lang.reflect Type
  // instances (produced by the JVM itself, not by $Gson$Types) so that the
  // methods under test can be exercised against realistic generic types.
  // ---------------------------------------------------------------------

  static class GenericFixtures {
    List<String> listField;
    List<String>[] arrayOfListField;
    List<? extends Number> wildcardField;
    Map<String, Integer> mapField;
  }

  static class Box<T> {
    T value;
  }

  static class StringBoxHolder {
    Box<String> box;
  }

  abstract static class IntegerSet implements Set<Integer> {
  }

  private static Type genericFieldType(String name) {
    try {
      Field field = GenericFixtures.class.getDeclaredField(name);
      return field.getGenericType();
    } catch (NoSuchFieldException e) {
      throw new RuntimeException(e);
    }
  }

  // ---------------------------------------------------------------------
  // EMPTY_TYPE_ARRAY
  // ---------------------------------------------------------------------

  @Test
  public void testEmptyTypeArrayIsEmpty() {
    Type[] empty = $Gson$Types.EMPTY_TYPE_ARRAY;
    assertNotNull(empty);
    assertEquals(0, empty.length);
  }

  // ---------------------------------------------------------------------
  // newParameterizedTypeWithOwner
  // ---------------------------------------------------------------------

  @Test
  public void testNewParameterizedTypeWithOwner_basic() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, type.getRawType());
    assertEquals(null, type.getOwnerType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  @Test
  public void testNewParameterizedTypeWithOwner_withOwnerAndMultipleArgs() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        String.class, Map.class, String.class, Integer.class);
    assertEquals(String.class, type.getOwnerType());
    assertEquals(Map.class, type.getRawType());
    Type[] args = type.getActualTypeArguments();
    assertEquals(2, args.length);
    assertEquals(String.class, args[0]);
    assertEquals(Integer.class, args[1]);
  }

  @Test
  public void testNewParameterizedTypeWithOwner_zeroTypeArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals(List.class, type.getRawType());
    assertEquals(0, type.getActualTypeArguments().length);
  }

  @Test
  public void testNewParameterizedTypeWithOwner_isSerializable() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertTrue(type instanceof Serializable);
  }

  // ---------------------------------------------------------------------
  // arrayOf
  // ---------------------------------------------------------------------

  @Test
  public void testArrayOf_componentType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, type.getGenericComponentType());
  }

  @Test
  public void testArrayOf_ofParameterizedType() {
    ParameterizedType listOfString =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    GenericArrayType type = $Gson$Types.arrayOf(listOfString);
    assertEquals(listOfString, type.getGenericComponentType());
  }

  @Test
  public void testArrayOf_isSerializable() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertTrue(type instanceof Serializable);
  }

  // ---------------------------------------------------------------------
  // subtypeOf
  // ---------------------------------------------------------------------

  @Test
  public void testSubtypeOf_regularBound() {
    WildcardType type = $Gson$Types.subtypeOf(CharSequence.class);
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(CharSequence.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
  }

  @Test
  public void testSubtypeOf_objectBoundIsShorthandForUnboundedWildcard() {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
  }

  // ---------------------------------------------------------------------
  // supertypeOf
  // ---------------------------------------------------------------------

  @Test
  public void testSupertypeOf() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals(1, type.getLowerBounds().length);
    assertEquals(String.class, type.getLowerBounds()[0]);
    // Per java.lang.reflect.WildcardType's contract, when no explicit upper
    // bound is declared the upper bound defaults to Object.
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(Object.class, type.getUpperBounds()[0]);
  }

  // ---------------------------------------------------------------------
  // canonicalize
  // ---------------------------------------------------------------------

  @Test
  public void testCanonicalize_classIsReturnedAsIs() {
    Type result = $Gson$Types.canonicalize(String.class);
    assertEquals(String.class, result);
  }

  @Test
  public void testCanonicalize_isFunctionallyEqualAndSerializable_parameterizedType() {
    Type jdkType = genericFieldType("listField");
    Type canonical = $Gson$Types.canonicalize(jdkType);
    assertTrue($Gson$Types.equals(jdkType, canonical));
    assertTrue(canonical instanceof Serializable);
  }

  @Test
  public void testCanonicalize_isFunctionallyEqualAndSerializable_genericArrayType() {
    Type jdkType = genericFieldType("arrayOfListField");
    Type canonical = $Gson$Types.canonicalize(jdkType);
    assertTrue($Gson$Types.equals(jdkType, canonical));
    assertTrue(canonical instanceof Serializable);
  }

  @Test
  public void testCanonicalize_isFunctionallyEqualAndSerializable_wildcardType() {
    ParameterizedType wildcardHolder = (ParameterizedType) genericFieldType("wildcardField");
    Type jdkType = wildcardHolder.getActualTypeArguments()[0];
    Type canonical = $Gson$Types.canonicalize(jdkType);
    assertTrue($Gson$Types.equals(jdkType, canonical));
    assertTrue(canonical instanceof Serializable);
  }

  // ---------------------------------------------------------------------
  // getRawType
  // ---------------------------------------------------------------------

  @Test
  public void testGetRawType_ofClass() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  @Test
  public void testGetRawType_ofParameterizedType() {
    ParameterizedType listOfString =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(listOfString));
  }

  @Test
  public void testGetRawType_ofGenericArrayType() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(arrayType));
  }

  @Test
  public void testGetRawType_null_throws() {
    try {
      $Gson$Types.getRawType(null);
      fail("Expected an exception for a null type");
    } catch (RuntimeException expected) {
      // A null Type cannot have a raw type; some RuntimeException is expected.
    }
  }

  // ---------------------------------------------------------------------
  // equal (package-private null-safe equality helper)
  // ---------------------------------------------------------------------

  @Test
  public void testEqual_bothNull() {
    assertTrue($Gson$Types.equal(null, null));
  }

  @Test
  public void testEqual_oneNull() {
    assertFalse($Gson$Types.equal(null, "x"));
    assertFalse($Gson$Types.equal("x", null));
  }

  @Test
  public void testEqual_equalButDistinctInstances() {
    String a = new String("hello");
    String b = new String("hello");
    assertTrue(a != b);
    assertTrue($Gson$Types.equal(a, b));
  }

  @Test
  public void testEqual_unequalValues() {
    assertFalse($Gson$Types.equal("x", "y"));
  }

  @Test
  public void testEqual_sameReference() {
    Object o = new Object();
    assertTrue($Gson$Types.equal(o, o));
  }

  // ---------------------------------------------------------------------
  // equals(Type, Type)
  // ---------------------------------------------------------------------

  @Test
  public void testEquals_sameClass() {
    assertTrue($Gson$Types.equals(String.class, String.class));
  }

  @Test
  public void testEquals_differentClasses() {
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  @Test
  public void testEquals_equalParameterizedTypesFromSeparateInstances() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertTrue($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_parameterizedTypesWithDifferentArguments() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_parameterizedTypesWithDifferentRawTypes() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, Set.class, String.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_equalGenericArrayTypes() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_differentGenericArrayTypes() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(Integer.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_equalWildcardTypes() {
    WildcardType a = $Gson$Types.subtypeOf(Number.class);
    WildcardType b = $Gson$Types.subtypeOf(Number.class);
    assertTrue($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_wildcardExtendsVsSuperAreDifferent() {
    WildcardType a = $Gson$Types.subtypeOf(Number.class);
    WildcardType b = $Gson$Types.supertypeOf(Number.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  @Test
  public void testEquals_differentKindsOfTypeAreNotEqual() {
    GenericArrayType arrayOfString = $Gson$Types.arrayOf(String.class);
    assertFalse($Gson$Types.equals(String.class, arrayOfString));
  }

  // ---------------------------------------------------------------------
  // hashCodeOrZero
  // ---------------------------------------------------------------------

  @Test
  public void testHashCodeOrZero_null() {
    assertEquals(0, $Gson$Types.hashCodeOrZero(null));
  }

  @Test
  public void testHashCodeOrZero_delegatesToHashCode() {
    Integer value = Integer.valueOf(42);
    assertEquals(value.hashCode(), $Gson$Types.hashCodeOrZero(value));
    String s = "abc";
    assertEquals(s.hashCode(), $Gson$Types.hashCodeOrZero(s));
  }

  // ---------------------------------------------------------------------
  // typeToString
  // ---------------------------------------------------------------------

  @Test
  public void testTypeToString_ofClassContainsClassName() {
    String result = $Gson$Types.typeToString(String.class);
    assertNotNull(result);
    assertTrue(result.length() > 0);
    assertTrue(result.indexOf("String") >= 0);
  }

  @Test
  public void testTypeToString_ofPrimitiveContainsPrimitiveName() {
    String result = $Gson$Types.typeToString(int.class);
    assertNotNull(result);
    assertTrue(result.indexOf("int") >= 0);
  }

  // ---------------------------------------------------------------------
  // getArrayComponentType
  // ---------------------------------------------------------------------

  @Test
  public void testGetArrayComponentType_ofObjectArrayClass() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  @Test
  public void testGetArrayComponentType_ofPrimitiveArrayClass() {
    assertEquals(int.class, $Gson$Types.getArrayComponentType(int[].class));
  }

  @Test
  public void testGetArrayComponentType_ofGenericArrayType() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(arrayType));
  }

  // @Test  // pruned: failed on the fixed version
  public void testGetArrayComponentType_notAnArray_throwsClassCastException() {
    try {
      $Gson$Types.getArrayComponentType(String.class);
      fail("Expected ClassCastException for a non-array type");
    } catch (ClassCastException expected) {
      // documented behavior
    }
  }

  // ---------------------------------------------------------------------
  // getCollectionElementType
  // ---------------------------------------------------------------------

  @Test
  public void testGetCollectionElementType_ofParameterizedList() {
    ParameterizedType listOfString =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type elementType = $Gson$Types.getCollectionElementType(listOfString, List.class);
    assertEquals(String.class, elementType);
  }

  @Test
  public void testGetCollectionElementType_ofRealGenericField() {
    Type listFieldType = genericFieldType("listField");
    Type elementType = $Gson$Types.getCollectionElementType(listFieldType, List.class);
    assertEquals(String.class, elementType);
  }

  @Test
  public void testGetCollectionElementType_notACollection_throwsIllegalArgumentException() {
    try {
      $Gson$Types.getCollectionElementType(String.class, String.class);
      fail("Expected IllegalArgumentException for a non-collection type");
    } catch (IllegalArgumentException expected) {
      // documented behavior
    }
  }

  // ---------------------------------------------------------------------
  // getMapKeyAndValueTypes
  // ---------------------------------------------------------------------

  @Test
  public void testGetMapKeyAndValueTypes_ofParameterizedMap() {
    ParameterizedType mapOfStringToInteger = $Gson$Types.newParameterizedTypeWithOwner(
        null, Map.class, String.class, Integer.class);
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(mapOfStringToInteger, Map.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  @Test
  public void testGetMapKeyAndValueTypes_ofRealGenericField() {
    Type mapFieldType = genericFieldType("mapField");
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(mapFieldType, Map.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  // ---------------------------------------------------------------------
  // resolve
  // ---------------------------------------------------------------------

  @Test
  public void testResolve_concreteTypeIsUnchanged() {
    Type resolved = $Gson$Types.resolve(String.class, String.class, String.class);
    assertTrue($Gson$Types.equals(String.class, resolved));
  }

  @Test
  public void testResolve_typeVariableIsResolvedFromContext() throws NoSuchFieldException {
    Field field = StringBoxHolder.class.getDeclaredField("box");
    Type context = field.getGenericType();
    TypeVariable<?> unknown = Box.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(context, Box.class, unknown);
    assertTrue($Gson$Types.equals(String.class, resolved));
  }

  // ---------------------------------------------------------------------
  // resolveTypeVariable
  // ---------------------------------------------------------------------

  @Test
  public void testResolveTypeVariable() throws NoSuchFieldException {
    Field field = StringBoxHolder.class.getDeclaredField("box");
    Type context = field.getGenericType();
    TypeVariable<?> unknown = Box.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolveTypeVariable(context, Box.class, unknown);
    assertTrue($Gson$Types.equals(String.class, resolved));
  }

  // ---------------------------------------------------------------------
  // getGenericSupertype -- matches the exact example from the javadoc:
  // "given a class IntegerSet, the result for when supertype is Set.class
  // is Set<Integer> and the result when the supertype is Collection.class
  // is Collection<Integer>."
  // ---------------------------------------------------------------------

  @Test
  public void testGetGenericSupertype_set() {
    Type result = $Gson$Types.getGenericSupertype(IntegerSet.class, IntegerSet.class, Set.class);
    assertEquals(Set.class, $Gson$Types.getRawType(result));
    assertTrue(result instanceof ParameterizedType);
    ParameterizedType parameterized = (ParameterizedType) result;
    assertEquals(1, parameterized.getActualTypeArguments().length);
    assertEquals(Integer.class, parameterized.getActualTypeArguments()[0]);
  }

  // @Test  // pruned: failed on the fixed version
  public void testGetGenericSupertype_collection() {
    Type result =
        $Gson$Types.getGenericSupertype(IntegerSet.class, IntegerSet.class, Collection.class);
    assertEquals(Collection.class, $Gson$Types.getRawType(result));
    assertTrue(result instanceof ParameterizedType);
    ParameterizedType parameterized = (ParameterizedType) result;
    assertEquals(1, parameterized.getActualTypeArguments().length);
    assertEquals(Integer.class, parameterized.getActualTypeArguments()[0]);
  }

  // ---------------------------------------------------------------------
  // getSupertype -- matches the exact example from the javadoc:
  // "if this is ArrayList<String>, this returns Iterable<String> given the
  // input Iterable.class."
  // ---------------------------------------------------------------------

  @Test
  public void testGetSupertype_iterable() {
    ParameterizedType arrayListOfString =
        $Gson$Types.newParameterizedTypeWithOwner(null, ArrayList.class, String.class);
    Type result = $Gson$Types.getSupertype(arrayListOfString, ArrayList.class, Iterable.class);
    assertEquals(Iterable.class, $Gson$Types.getRawType(result));
    assertTrue(result instanceof ParameterizedType);
    assertEquals(String.class, ((ParameterizedType) result).getActualTypeArguments()[0]);
  }

  @Test
  public void testGetSupertype_list() {
    ParameterizedType arrayListOfString =
        $Gson$Types.newParameterizedTypeWithOwner(null, ArrayList.class, String.class);
    Type result = $Gson$Types.getSupertype(arrayListOfString, ArrayList.class, List.class);
    assertEquals(List.class, $Gson$Types.getRawType(result));
    assertTrue(result instanceof ParameterizedType);
    assertEquals(String.class, ((ParameterizedType) result).getActualTypeArguments()[0]);
  }

  // ---------------------------------------------------------------------
  // checkNotPrimitive
  // ---------------------------------------------------------------------

  @Test
  public void testCheckNotPrimitive_nonPrimitiveDoesNotThrow() {
    $Gson$Types.checkNotPrimitive(String.class);
    $Gson$Types.checkNotPrimitive(Object.class);
    // reaching this point without an exception satisfies the check
    assertTrue(true);
  }

  @Test
  public void testCheckNotPrimitive_primitiveThrows() {
    try {
      $Gson$Types.checkNotPrimitive(int.class);
      fail("Expected an exception for a primitive type");
    } catch (RuntimeException expected) {
      // The method's name implies it rejects primitive types.
    }
  }
}
