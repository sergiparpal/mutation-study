package org.apache.commons.csv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

/**
 * Self-contained unit tests for {@link CSVParser}.
 *
 * <p>Every expectation below is taken from the published Javadoc contract of
 * {@code CSVParser} (see {@code api/org/apache/commons/csv/CSVParser.html}) and
 * from the {@code org.apache.commons.csv} package description. Where the Javadoc
 * is silent the tests assert only what the contract implies (for example that a
 * "copy" of the header map is independent of the parser).</p>
 *
 * <p>Written for JUnit 3.8 (the lowest common denominator available on the
 * class path): the class extends {@code junit.framework.TestCase} and uses only
 * {@code testXxx} methods and inherited assertions.</p>
 */
public class CSVParserAgentTest extends TestCase {

    // ------------------------------------------------------------------
    // Fixtures - defined here so the test file depends on nothing else.
    // ------------------------------------------------------------------

    /** A {@link Reader} whose every read attempt fails, to exercise I/O error paths. */
    private static final class BrokenReader extends Reader {
        public int read(final char[] cbuf, final int off, final int len) throws IOException {
            throw new IOException("simulated read failure");
        }

        public void close() throws IOException {
            // nothing to release
        }
    }

    /** A {@link Reader} that delegates to a string but records whether it was closed. */
    private static final class TrackingReader extends Reader {
        private final Reader delegate;
        private boolean closed;

        TrackingReader(final String content) {
            this.delegate = new StringReader(content);
        }

        public int read(final char[] cbuf, final int off, final int len) throws IOException {
            return this.delegate.read(cbuf, off, len);
        }

        public void close() throws IOException {
            this.closed = true;
            this.delegate.close();
        }

        boolean isClosed() {
            return this.closed;
        }
    }

    private File writeTempFile(final String content) throws IOException {
        final File file = File.createTempFile("csvParserAgentTest", ".csv");
        file.deleteOnExit();
        final Writer writer = new FileWriter(file);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    // ------------------------------------------------------------------
    // Constructor: CSVParser(Reader, CSVFormat)
    // ------------------------------------------------------------------

    public void testConstructorRejectsNullReader() throws Exception {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null reader");
        } catch (final IllegalArgumentException expected) {
            // contract: "if either reader or format are null"
        }
    }

    public void testConstructorRejectsNullFormat() throws Exception {
        try {
            new CSVParser(new StringReader("a,b,c"), null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // contract: "if either reader or format are null"
        }
    }

    public void testConstructorParsesUsingTheGivenFormat() throws Exception {
        final Reader in = new StringReader("a;b\nc;d");
        final CSVParser parser = new CSVParser(in, CSVFormat.DEFAULT.withDelimiter(';'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(1).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Static factory: parse(String, CSVFormat)
    // ------------------------------------------------------------------

    public void testParseStringRejectsNullString() throws Exception {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null string");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseStringRejectsNullFormat() throws Exception {
        try {
            CSVParser.parse("a,b,c", (CSVFormat) null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseStringReturnsAParserThatReadsTheContent() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        assertNotNull("parse must return a new parser", parser);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("c", records.get(0).get(2));
        assertEquals("2", records.get(1).get(1));
    }

    // ------------------------------------------------------------------
    // Static factory: parse(File, CSVFormat)
    // ------------------------------------------------------------------

    public void testParseFileRejectsNullFile() throws Exception {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null file");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseFileRejectsNullFormat() throws Exception {
        final File file = writeTempFile("a,b\n");
        try {
            CSVParser.parse(file, (CSVFormat) null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseFileReadsAllRecords() throws Exception {
        final File file = writeTempFile("a,b,c\n1,2,3\n");
        final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Static factory: parse(URL, Charset, CSVFormat)
    // ------------------------------------------------------------------

    public void testParseUrlRejectsNullUrl() throws Exception {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null URL");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseUrlRejectsNullCharset() throws Exception {
        final URL url = writeTempFile("a,b\n").toURI().toURL();
        try {
            CSVParser.parse(url, (Charset) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null charset");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseUrlRejectsNullFormat() throws Exception {
        final URL url = writeTempFile("a,b\n").toURI().toURL();
        try {
            CSVParser.parse(url, Charset.forName("UTF-8"), (CSVFormat) null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseUrlReadsAllRecords() throws Exception {
        final URL url = writeTempFile("x,y\nz,w\n").toURI().toURL();
        final CSVParser parser = CSVParser.parse(url, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("w", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // getRecords()
    // ------------------------------------------------------------------

    public void testGetRecordsOnEmptyInputReturnsEmptyList() throws Exception {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertNotNull("getRecords() must never return null", records);
        assertTrue("no input means no records", records.isEmpty());
        assertEquals(0L, parser.getRecordNumber());
    }

    public void testGetRecordsReturnsEveryRecordWithItsValues() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\ng,h,i\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(3, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("e", records.get(1).get(1));
        assertEquals("i", records.get(2).get(2));
    }

    public void testGetRecordsStartsAtTheCurrentStreamPosition() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc\nd\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertTrue(it.hasNext());
        assertEquals("a", it.next().get(0));

        final List<CSVRecord> rest = parser.getRecords();
        assertEquals("records already consumed must not reappear", 3, rest.size());
        assertEquals("b", rest.get(0).get(0));
        assertEquals("c", rest.get(1).get(0));
        assertEquals("d", rest.get(2).get(0));
    }

    public void testGetRecordsCalledTwiceReturnsNothingTheSecondTime() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        assertEquals(2, parser.getRecords().size());
        final List<CSVRecord> again = parser.getRecords();
        assertNotNull(again);
        assertTrue("stream is exhausted after the first getRecords()", again.isEmpty());
    }

    public void testGetRecordsIntoCollectionAddsToAndReturnsThatCollection() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        final ArrayList<CSVRecord> target = new ArrayList<CSVRecord>();
        final ArrayList<CSVRecord> returned = parser.getRecords(target);
        assertSame("the supplied collection must be the one returned", target, returned);
        assertEquals(2, target.size());
        assertEquals("a", target.get(0).get(0));
        assertEquals("d", target.get(1).get(1));
    }

    // ------------------------------------------------------------------
    // getRecordNumber() / getCurrentLineNumber()
    // ------------------------------------------------------------------

    public void testRecordNumberStartsAtZeroAndCountsRecords() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals("no record read yet", 0L, parser.getRecordNumber());

        final Iterator<CSVRecord> it = parser.iterator();
        final CSVRecord first = it.next();
        assertEquals(1L, parser.getRecordNumber());
        assertEquals("the record knows its own number", 1L, first.getRecordNumber());

        it.next();
        assertEquals(2L, parser.getRecordNumber());
        it.next();
        assertEquals(3L, parser.getRecordNumber());

        assertFalse(it.hasNext());
        assertEquals("hitting EOF must not bump the record number", 3L, parser.getRecordNumber());
    }

    public void testCurrentLineNumberAdvancesAsLinesAreConsumed() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        final long before = parser.getCurrentLineNumber();
        assertTrue("a fresh parser has not moved past the first line (was " + before + ")",
                before <= 1L);

        parser.getRecords();
        final long after = parser.getCurrentLineNumber();
        assertTrue("line number must advance while reading three lines (before=" + before
                + ", after=" + after + ")", after - before >= 2L);
    }

    public void testMultiLineValueDecouplesLineNumberFromRecordNumber() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a\nb\",c\nd,e\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        final CSVRecord first = it.next();
        assertEquals("a\nb", first.get(0));
        assertEquals("c", first.get(1));

        assertEquals("one record has been read", 1L, parser.getRecordNumber());
        assertTrue("a multi-line value pushes the line number past the record number",
                parser.getCurrentLineNumber() > parser.getRecordNumber());
    }

    // ------------------------------------------------------------------
    // getHeaderMap()
    // ------------------------------------------------------------------

    public void testHeaderMapIsParsedFromFirstRecordInColumnOrder() throws Exception {
        final CSVParser parser = CSVParser.parse("A,B,C\n1,2,3\n", CSVFormat.DEFAULT.withHeader());
        final Map<String, Integer> header = parser.getHeaderMap();
        assertNotNull(header);
        assertEquals(3, header.size());
        assertEquals("map values are 0-based indices", Integer.valueOf(0), header.get("A"));
        assertEquals(Integer.valueOf(1), header.get("B"));
        assertEquals(Integer.valueOf(2), header.get("C"));

        final Iterator<String> keys = header.keySet().iterator();
        assertEquals("iterates in column order", "A", keys.next());
        assertEquals("B", keys.next());
        assertEquals("C", keys.next());

        // the header row has been consumed; only the data row remains
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("1", records.get(0).get(0));
    }

    public void testGetHeaderMapReturnsAnIndependentCopy() throws Exception {
        final CSVParser parser = CSVParser.parse("A,B\n1,2\n", CSVFormat.DEFAULT.withHeader());
        final Map<String, Integer> first = parser.getHeaderMap();
        final Map<String, Integer> second = parser.getHeaderMap();
        assertNotSame("each call must hand back a distinct copy", first, second);
        assertEquals(first, second);

        first.clear();
        final Map<String, Integer> third = parser.getHeaderMap();
        assertEquals("mutating a returned copy must not affect the parser", 2, third.size());
    }

    public void testGetHeaderMapWithoutAHeaderFormat() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        final Map<String, Integer> header = parser.getHeaderMap();
        assertTrue("no header configured => the parser invents no column names",
                header == null || header.isEmpty());
    }

    public void testExplicitHeaderWithSkipHeaderRecord() throws Exception {
        final CSVParser parser = CSVParser.parse("h1,h2\n1,2\n3,4\n",
                CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true));
        final Map<String, Integer> header = parser.getHeaderMap();
        assertEquals(2, header.size());
        assertEquals(Integer.valueOf(0), header.get("A"));
        assertEquals(Integer.valueOf(1), header.get("B"));

        final List<CSVRecord> records = parser.getRecords();
        assertEquals("first physical line was skipped as the header", 2, records.size());
        assertEquals("1", records.get(0).get("A"));
        assertEquals("2", records.get(0).get("B"));
        assertEquals("3", records.get(1).get(0));
    }

    public void testExplicitHeaderWithoutSkipKeepsFirstRecordAsData() throws Exception {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n",
                CSVFormat.DEFAULT.withHeader("A", "B"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get("A"));
        assertEquals("4", records.get(1).get("B"));
    }

    public void testRecordValuesAreReachableByHeaderName() throws Exception {
        final CSVParser parser = CSVParser.parse("name,age\nalice,30\n",
                CSVFormat.DEFAULT.withHeader());
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        final CSVRecord record = records.get(0);
        assertEquals("alice", record.get("name"));
        assertEquals("30", record.get("age"));
        assertEquals("access by index still works", "alice", record.get(0));
        assertEquals("30", record.get(1));
    }

    // ------------------------------------------------------------------
    // iterator()
    // ------------------------------------------------------------------

    public void testIteratorVisitsEveryRecord() throws Exception {
        final CSVParser parser = CSVParser.parse("1,2,3\n4,5,6\n7,8,9\n", CSVFormat.DEFAULT);
        int recordCount = 0;
        int sum = 0;
        for (final CSVRecord record : parser) {
            recordCount++;
            for (final String value : record) {
                sum += Integer.parseInt(value);
            }
        }
        assertEquals(3, recordCount);
        assertEquals(45, sum);
    }

    public void testIteratorHasNextBecomesFalseAtEnd() throws Exception {
        final CSVParser parser = CSVParser.parse("only,one\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertTrue(it.hasNext());
        it.next();
        assertFalse("nothing left after the single record", it.hasNext());
    }

    public void testIteratorNextThrowsNoSuchElementAtEnd() throws Exception {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("expected NoSuchElementException past the end of the input");
        } catch (final NoSuchElementException expected) {
            // standard Iterator contract
        }
    }

    public void testIteratorOnAClosedParserYieldsNoElements() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse("a closed parser exposes no records", it.hasNext());
        try {
            it.next();
            fail("a closed parser must make iterator().next() throw NoSuchElementException");
        } catch (final NoSuchElementException expected) {
            // documented
        }
    }

    public void testIteratorWrapsIOExceptionInRuntimeException() throws Exception {
        final CSVParser parser = new CSVParser(new BrokenReader(), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        try {
            it.hasNext();
            fail("an I/O failure during iteration must surface as a RuntimeException");
        } catch (final NoSuchElementException bad) {
            fail("the I/O failure must be wrapped, not reported as a plain end-of-input");
        } catch (final RuntimeException expected) {
            if (expected.getCause() != null) {
                assertTrue("the wrapper should carry the original IOException",
                        expected.getCause() instanceof IOException);
            }
        }
    }

    // ------------------------------------------------------------------
    // close() / isClosed()
    // ------------------------------------------------------------------

    public void testCloseFlipsIsClosed() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse("a fresh parser is open", parser.isClosed());
        parser.close();
        assertTrue("after close() the parser reports closed", parser.isClosed());
    }

    public void testCloseReleasesTheUnderlyingReader() throws Exception {
        final TrackingReader reader = new TrackingReader("a,b,c\n");
        final CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        assertFalse(reader.isClosed());

        parser.close();
        assertTrue(parser.isClosed());
        assertTrue("CSVParser.close() must close the reader it was given", reader.isClosed());
    }

    public void testCloseIsIdempotent() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ------------------------------------------------------------------
    // nextRecord() - package-private, reachable from this same package
    // ------------------------------------------------------------------

    public void testNextRecordWalksTheStreamThenReturnsNull() throws Exception {
        final CSVParser parser = CSVParser.parse("x,y\nz,w\n", CSVFormat.DEFAULT);

        final CSVRecord r1 = parser.nextRecord();
        assertNotNull(r1);
        assertEquals("x", r1.get(0));
        assertEquals("y", r1.get(1));

        final CSVRecord r2 = parser.nextRecord();
        assertNotNull(r2);
        assertEquals("z", r2.get(0));
        assertEquals("w", r2.get(1));

        assertNull("nextRecord() returns null once the stream is exhausted", parser.nextRecord());
    }

    // ------------------------------------------------------------------
    // Format-driven parsing behaviour
    // ------------------------------------------------------------------

    public void testQuotedDelimiterIsKeptInsideTheValue() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("the quoted comma does not split the value", 2, records.get(0).size());
        assertEquals("a,b", records.get(0).get(0));
        assertEquals("c", records.get(0).get(1));
    }

    public void testDoubledQuoteBecomesASingleQuote() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a\"\"b\",c\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals(2, records.get(0).size());
        assertEquals("a\"b", records.get(0).get(0));
        assertEquals("c", records.get(0).get(1));
    }

    public void testQuotedNewlineYieldsOneMultiLineValue() throws Exception {
        final CSVParser parser = CSVParser.parse("\"line1\nline2\",c\nd,e\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals("the embedded newline stays inside the value", 2, records.size());
        assertEquals("line1\nline2", records.get(0).get(0));
        assertEquals("c", records.get(0).get(1));
        assertEquals("d", records.get(1).get(0));
        assertEquals("e", records.get(1).get(1));
    }

    public void testTabDelimitedFormat() throws Exception {
        final CSVParser parser = CSVParser.parse("a\tb\tc\n1\t2\t3\n", CSVFormat.TDF);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("2", records.get(1).get(1));
    }

    public void testCustomDelimiter() throws Exception {
        final CSVParser parser = CSVParser.parse("a;b;c\n", CSVFormat.DEFAULT.withDelimiter(';'));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("b", records.get(0).get(1));
        assertEquals("c", records.get(0).get(2));
    }

    public void testCommentLinesAreRemovedFromTheInput() throws Exception {
        final CSVParser parser = CSVParser.parse("# a comment\na,b\n# another\nc,d\n",
                CSVFormat.DEFAULT.withCommentStart('#'));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals("comment records are dropped", 2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("b", records.get(0).get(1));
        assertEquals("c", records.get(1).get(0));
        assertEquals("d", records.get(1).get(1));
    }

    public void testEmptyLinesAreSkippedByTheDefaultFormat() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n\n\nc,d\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("c", records.get(1).get(0));
    }

    public void testEmptyLinesArePreservedWhenNotIgnored() throws Exception {
        final CSVParser parser = CSVParser.parse("a\n\nb\n",
                CSVFormat.DEFAULT.withIgnoreEmptyLines(false));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(3, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("an empty line becomes a single empty value", 1, records.get(1).size());
        assertEquals("", records.get(1).get(0));
        assertEquals("b", records.get(2).get(0));
    }

    public void testIgnoreSurroundingSpacesTrimsSimpleValues() throws Exception {
        final CSVParser parser = CSVParser.parse(" a , b \n",
                CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true));
        final CSVRecord record = parser.getRecords().get(0);
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
    }

    public void testWithoutIgnoreSurroundingSpacesWhitespaceIsKept() throws Exception {
        final CSVParser parser = CSVParser.parse(" a , b \n",
                CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false));
        final CSVRecord record = parser.getRecords().get(0);
        assertEquals(" a ", record.get(0));
        assertEquals(" b ", record.get(1));
    }

    public void testRecordsMayHaveDifferentSizes() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e\nf\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(3, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals(2, records.get(1).size());
        assertEquals(1, records.get(2).size());
        assertEquals("f", records.get(2).get(0));
    }

    public void testExcelFormatParsesCommaSeparatedCrlfInput() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\r\n1,2,3\r\n", CSVFormat.EXCEL);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals("b", records.get(0).get(1));
        assertEquals("3", records.get(1).get(2));
    }

    public void testRfc4180FormatHonoursQuoting() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n\"c,d\",e\n", CSVFormat.RFC4180);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(2, records.get(0).size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("c,d", records.get(1).get(0));
        assertEquals("e", records.get(1).get(1));
    }

    public void testLastRecordWithoutTrailingNewlineIsStillParsed() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals("c", records.get(0).get(2));
        assertEquals(1L, parser.getRecordNumber());
    }
}
