/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Collections;

import junit.framework.TestCase;

public final class ReflectiveTypeAdapterFactoryAgentTest extends TestCase {
  private final Gson gson = new Gson();

  private static ReflectiveTypeAdapterFactory newFactory() {
    return new ReflectiveTypeAdapterFactory(
        new ConstructorConstructor(Collections.<Type, InstanceCreator<?>>emptyMap()),
        FieldNamingPolicy.IDENTITY,
        Excluder.DEFAULT);
  }

  static class Simple {
    String name;
    int count;
  }

  public void testCreateReturnsAdapterForPojo() throws Exception {
    TypeAdapter<Simple> adapter = newFactory().create(gson, TypeToken.get(Simple.class));
    assertNotNull(adapter);
    assertTrue(adapter instanceof ReflectiveTypeAdapterFactory.Adapter);
  }

  public void testCreateReturnsNullForPrimitiveType() {
    TypeAdapter<Integer> adapter = newFactory().create(gson, TypeToken.get(int.class));
    assertNull(adapter);
  }

  public void testCreateReturnsNonNullAdapterForInterfaceType() throws Exception {
    // Object.class.isAssignableFrom(Runnable.class) is true, so interfaces are not
    // rejected the way primitives are; they simply have no bound fields.
    TypeAdapter<Runnable> adapter = newFactory().create(gson, TypeToken.get(Runnable.class));
    assertNotNull(adapter);
  }

  public void testWriteAndReadRoundTrip() throws Exception {
    TypeAdapter<Simple> adapter = newFactory().create(gson, TypeToken.get(Simple.class));
    Simple value = new Simple();
    value.name = "hello";
    value.count = 3;
    assertEquals("{\"name\":\"hello\",\"count\":3}", adapter.toJson(value));

    Simple read = adapter.fromJson("{\"name\":\"world\",\"count\":7}");
    assertEquals("world", read.name);
    assertEquals(7, read.count);
  }

  public void testReadNullReturnsNull() throws Exception {
    TypeAdapter<Simple> adapter = newFactory().create(gson, TypeToken.get(Simple.class));
    assertNull(adapter.fromJson("null"));
  }

  public void testWriteNullWritesJsonNull() throws Exception {
    TypeAdapter<Simple> adapter = newFactory().create(gson, TypeToken.get(Simple.class));
    assertEquals("null", adapter.toJson(null));
  }

  public void testReadUnknownFieldIsSkipped() throws Exception {
    TypeAdapter<Simple> adapter = newFactory().create(gson, TypeToken.get(Simple.class));
    Simple read = adapter.fromJson("{\"name\":\"a\",\"unknown\":{\"x\":[1,2,3]},\"count\":1}");
    assertEquals("a", read.name);
    assertEquals(1, read.count);
  }

  static class WithSerializedName {
    @SerializedName("full_name")
    String name;
  }

  public void testSerializedNameOverridesFieldName() throws Exception {
    TypeAdapter<WithSerializedName> adapter =
        newFactory().create(gson, TypeToken.get(WithSerializedName.class));
    WithSerializedName value = new WithSerializedName();
    value.name = "Bob";
    assertEquals("{\"full_name\":\"Bob\"}", adapter.toJson(value));

    WithSerializedName read = adapter.fromJson("{\"full_name\":\"Alice\"}");
    assertEquals("Alice", read.name);
  }

  static class WithAlternateNames {
    @SerializedName(value = "primary", alternate = {"alt1", "alt2"})
    String value;
  }

  public void testAlternateNamesAreReadButOnlyPrimaryIsWritten() throws Exception {
    TypeAdapter<WithAlternateNames> adapter =
        newFactory().create(gson, TypeToken.get(WithAlternateNames.class));

    WithAlternateNames value = new WithAlternateNames();
    value.value = "x";
    assertEquals("{\"primary\":\"x\"}", adapter.toJson(value));

    assertEquals("y", adapter.fromJson("{\"alt1\":\"y\"}").value);
    assertEquals("z", adapter.fromJson("{\"alt2\":\"z\"}").value);
    assertEquals("w", adapter.fromJson("{\"primary\":\"w\"}").value);
  }

  static class DuplicateName {
    @SerializedName("value")
    String a;
    @SerializedName("value")
    String b;
  }

  public void testCreateThrowsForDuplicateJsonFieldNames() {
    ReflectiveTypeAdapterFactory factory = newFactory();
    try {
      factory.create(gson, TypeToken.get(DuplicateName.class));
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("declares multiple JSON fields named"));
    }
  }

  static class TransientAndStaticFields {
    String kept = "kept";
    transient String skippedTransient = "t";
    static String skippedStatic = "s";
  }

  public void testTransientAndStaticFieldsAreExcludedFromOutput() throws Exception {
    TypeAdapter<TransientAndStaticFields> adapter =
        newFactory().create(gson, TypeToken.get(TransientAndStaticFields.class));
    assertEquals("{\"kept\":\"kept\"}", adapter.toJson(new TransientAndStaticFields()));
  }

  static class SelfReferencing {
    SelfReferencing self;
    String label;
  }

  public void testWriteFieldAvoidsRecursionWhenFieldReferencesSameInstance() throws Exception {
    TypeAdapter<SelfReferencing> adapter =
        newFactory().create(gson, TypeToken.get(SelfReferencing.class));
    SelfReferencing value = new SelfReferencing();
    value.label = "loop";
    value.self = value;
    assertEquals("{\"label\":\"loop\"}", adapter.toJson(value));
  }

  static class PrimitiveAndBoxed {
    int i = 5;
    Integer boxed = 5;
  }

  public void testReadNullForPrimitiveFieldIsIgnoredButBoxedFieldIsSetToNull() throws Exception {
    TypeAdapter<PrimitiveAndBoxed> adapter =
        newFactory().create(gson, TypeToken.get(PrimitiveAndBoxed.class));
    PrimitiveAndBoxed read = adapter.fromJson("{\"i\":null,\"boxed\":null}");
    assertEquals(5, read.i);
    assertNull(read.boxed);
  }

  static class Base {
    String baseField = "base";
  }

  static class Derived extends Base {
    String derivedField = "derived";
  }

  public void testInheritedFieldsAreIncludedAfterOwnFields() throws Exception {
    TypeAdapter<Derived> adapter = newFactory().create(gson, TypeToken.get(Derived.class));
    assertEquals("{\"derivedField\":\"derived\",\"baseField\":\"base\"}",
        adapter.toJson(new Derived()));
  }

  public void testExcludeFieldIncludesRegularField() throws Exception {
    ReflectiveTypeAdapterFactory factory = newFactory();
    Field field = Simple.class.getDeclaredField("name");
    assertTrue(factory.excludeField(field, true));
    assertTrue(factory.excludeField(field, false));
  }

  public void testExcludeFieldExcludesTransientField() throws Exception {
    ReflectiveTypeAdapterFactory factory = newFactory();
    Field field = TransientAndStaticFields.class.getDeclaredField("skippedTransient");
    assertFalse(factory.excludeField(field, true));
    assertFalse(factory.excludeField(field, false));
  }

  public void testExcludeFieldExcludesStaticField() throws Exception {
    ReflectiveTypeAdapterFactory factory = newFactory();
    Field field = TransientAndStaticFields.class.getDeclaredField("skippedStatic");
    assertFalse(factory.excludeField(field, true));
    assertFalse(factory.excludeField(field, false));
  }
}
