/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import junit.framework.TestCase;

public final class JsonWriterAgentTest extends TestCase {

  public void testConstructorWithNullWriterThrows() {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testDefaultIsNotLenient() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isLenient());
  }

  public void testSetLenientTrue() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.setLenient(true);
    assertTrue(writer.isLenient());
  }

  public void testDefaultIsNotHtmlSafe() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isHtmlSafe());
  }

  public void testSetHtmlSafeTrue() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
  }

  public void testDefaultSerializeNullsIsTrue() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertTrue(writer.getSerializeNulls());
  }

  public void testSetSerializeNullsFalse() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
  }

  public void testEmptyArray() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    assertEquals("[]", stringWriter.toString());
  }

  public void testEmptyObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.endObject();
    assertEquals("{}", stringWriter.toString());
  }

  public void testArrayOfStrings() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a");
    writer.value("b");
    writer.value("c");
    writer.endArray();
    assertEquals("[\"a\",\"b\",\"c\"]", stringWriter.toString());
  }

  public void testObjectWithMultipleProperties() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1L);
    writer.name("b").value(2L);
    writer.endObject();
    assertEquals("{\"a\":1,\"b\":2}", stringWriter.toString());
  }

  public void testNestedArrayAndObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("array");
    writer.beginArray();
    writer.value(1L);
    writer.value(2L);
    writer.endArray();
    writer.endObject();
    assertEquals("{\"array\":[1,2]}", stringWriter.toString());
  }

  public void testValueBooleanPrimitive() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(true);
    writer.value(false);
    writer.endArray();
    assertEquals("[true,false]", stringWriter.toString());
  }

  public void testValueBooleanWrapper() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Boolean) Boolean.TRUE);
    writer.value((Boolean) null);
    writer.endArray();
    assertEquals("[true,null]", stringWriter.toString());
  }

  public void testValueDouble() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(1.5d);
    writer.endArray();
    assertEquals("[1.5]", stringWriter.toString());
  }

  public void testValueLong() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(Long.MAX_VALUE);
    writer.endArray();
    assertEquals("[" + Long.MAX_VALUE + "]", stringWriter.toString());
  }

  public void testValueNumber() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(Integer.valueOf(42));
    writer.value((Number) null);
    writer.endArray();
    assertEquals("[42,null]", stringWriter.toString());
  }

  public void testValueStringNullWritesNullLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((String) null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testNullValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.nullValue();
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testJsonValueWritesRawText() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"raw\":true}");
    writer.endArray();
    assertEquals("[{\"raw\":true}]", stringWriter.toString());
  }

  public void testJsonValueNullWritesNullLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue(null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testSerializeNullsFalseOmitsNullObjectMembers() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    writer.beginObject();
    writer.name("a").nullValue();
    writer.name("b").value(1L);
    writer.endObject();
    assertEquals("{\"b\":1}", stringWriter.toString());
  }

  public void testSerializeNullsFalseStillWritesNullArrayElements() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    writer.beginArray();
    writer.nullValue();
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testStringEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\"b\\c\td\ne");
    writer.endArray();
    assertEquals("[\"a\\\"b\\\\c\\td\\ne\"]", stringWriter.toString());
  }

  public void testControlCharacterEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("\u0001");
    writer.endArray();
    assertEquals("[\"\\u0001\"]", stringWriter.toString());
  }

  public void testHtmlSafeEscapesAngleBracketsAndAmpersand() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setHtmlSafe(true);
    writer.beginArray();
    writer.value("<html>&");
    writer.endArray();
    assertEquals("[\"\\u003chtml\\u003e\\u0026\"]", stringWriter.toString());
  }

  public void testNonHtmlSafeDoesNotEscapeAngleBrackets() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("<html>&");
    writer.endArray();
    assertEquals("[\"<html>&\"]", stringWriter.toString());
  }

  public void testIndentProducesPrettyPrintedOutput() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("   ");
    writer.beginObject();
    writer.name("a").value(1L);
    writer.endObject();
    assertEquals("{\n   \"a\": 1\n}", stringWriter.toString());
  }

  public void testEmptyIndentResetsToCompactOutput() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("   ");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a").value(1L);
    writer.endObject();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  public void testNameNullThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNameWithoutValueThenAnotherNameThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNameOutsideOfObjectThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.name("a");
    try {
      writer.value(true);
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testTwoNamesForOneValueThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("a");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testValueInsideObjectWithoutNameThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.value("a");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testMultipleTopLevelValuesForbiddenByDefault() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testLenientAllowsMultipleTopLevelValues() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.endArray();
    writer.beginArray();
    writer.endArray();
    assertEquals("[][]", stringWriter.toString());
  }

  public void testFirstTopLevelScalarValueIsAllowedEvenWhenStrict() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.value("a");
    assertEquals("\"a\"", stringWriter.toString());
  }

  public void testSecondTopLevelScalarValueIsRejectedByDefault() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.value("a");
    try {
      writer.value("b");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testLenientAllowsTopLevelStringValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value("a");
    assertEquals("\"a\"", stringWriter.toString());
  }

  public void testNonFiniteDoublesRejectedByDefault() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.NEGATIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNonFiniteDoublesAllowedWhenLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.value(Double.NaN);
    writer.value(Double.NEGATIVE_INFINITY);
    writer.value(Double.POSITIVE_INFINITY);
    writer.endArray();
    assertEquals("[NaN,-Infinity,Infinity]", stringWriter.toString());
  }

  public void testNonFiniteNumbersRejectedByDefault() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.valueOf(Double.NaN));
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNonFiniteNumbersAllowedWhenLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.value(Double.valueOf(Double.NaN));
    writer.endArray();
    assertEquals("[NaN]", stringWriter.toString());
  }

  public void testClosingIncompleteDocumentThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testClosingIncompleteObjectThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testCloseCompleteDocumentSucceeds() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    assertEquals("[]", stringWriter.toString());
  }

  public void testEndArrayMismatchWithObjectThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectMismatchWithArrayThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectWithDanglingNameThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayWithoutMatchingBeginThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testPrematureEndOfArrayInsideObjectThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testFlushAfterCloseThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testOperationsAfterCloseThrow() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNameAfterCloseThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.name("a");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testFlushDoesNotCloseWriter() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(1L);
    writer.flush();
    assertEquals("[1", stringWriter.toString());
    writer.endArray();
    writer.close();
    assertEquals("[1]", stringWriter.toString());
  }

  public void testBeginArrayReturnsThisForChaining() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    JsonWriter returned = writer.beginArray();
    assertSame(writer, returned);
  }

  public void testMethodChaining() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject().name("a").value(1L).endObject();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  public void testDeeplyNestedArrays() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    for (int i = 0; i < 40; i++) {
      writer.beginArray();
    }
    for (int i = 0; i < 40; i++) {
      writer.endArray();
    }
    StringBuilder expected = new StringBuilder();
    for (int i = 0; i < 40; i++) {
      expected.append('[');
    }
    for (int i = 0; i < 40; i++) {
      expected.append(']');
    }
    assertEquals(expected.toString(), stringWriter.toString());
  }

  public void testEmptyName() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("").value(true);
    writer.endObject();
    assertEquals("{\"\":true}", stringWriter.toString());
  }
}
