/*
 * Copyright 2002-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Independent unit tests for {@link org.apache.commons.lang.time.DateUtils}.
 *
 * <p>These tests exercise the public API only and assert on returned values and
 * on observable state (for example that inputs are not mutated), covering
 * boundary conditions and the documented error cases.</p>
 */
public class DateUtilsAgentTest extends TestCase {

    public DateUtilsAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(DateUtilsAgentTest.class);
    }

    //-----------------------------------------------------------------------
    // helpers
    //-----------------------------------------------------------------------

    /**
     * Builds a {@link Date} for the given Gregorian wall-clock fields in the
     * JVM default time zone.  The same construction path is used for the
     * "expected" values so results stay internally consistent regardless of
     * the default time zone in use.
     */
    private static Date makeDate(int year, int month, int day,
            int hour, int min, int sec, int millis) {
        return makeCalendar(year, month, day, hour, min, sec, millis).getTime();
    }

    private static Calendar makeCalendar(int year, int month, int day,
            int hour, int min, int sec, int millis) {
        Calendar cal = Calendar.getInstance(Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, min, sec);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    /** A distinct Calendar implementation used to exercise the class check in isSameLocalTime. */
    private static final class OtherCalendar extends GregorianCalendar {
        private static final long serialVersionUID = 1L;
        OtherCalendar(TimeZone zone) {
            super(zone);
        }
    }

    /**
     * Walks a day iterator produced by {@link DateUtils#iterator} and asserts
     * its first element, element count, last element and the exhaustion
     * behaviour of the returned {@link Iterator}.
     */
    private static void assertDayIterator(Iterator it, Date expectedFirst,
            int expectedCount, Date expectedLast) {
        assertTrue("iterator should have at least one element", it.hasNext());
        Calendar current = (Calendar) it.next();
        assertEquals("first day", expectedFirst, current.getTime());

        int count = 1;
        Date last = current.getTime();
        while (it.hasNext()) {
            Calendar next = (Calendar) it.next();
            assertTrue("days must advance strictly", last.before(next.getTime()));
            last = next.getTime();
            count++;
        }
        assertEquals("number of days", expectedCount, count);
        assertEquals("last day", expectedLast, last);

        try {
            it.next();
            fail("Expected NoSuchElementException once the iterator is exhausted");
        } catch (NoSuchElementException ex) {
            // expected
        }
        try {
            it.remove();
            fail("Expected UnsupportedOperationException from remove()");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // constructor / constants
    //-----------------------------------------------------------------------

    public void testConstructor() {
        assertNotNull(new DateUtils());
        Constructor[] cons = DateUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(DateUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(DateUtils.class.getModifiers()));
    }

    public void testConstants() {
        assertEquals("GMT", DateUtils.UTC_TIME_ZONE.getID());
        assertEquals(0, DateUtils.UTC_TIME_ZONE.getRawOffset());
        assertFalse(DateUtils.UTC_TIME_ZONE.useDaylightTime());

        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60L * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60L * 60L * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24L * 60L * 60L * 1000L, DateUtils.MILLIS_PER_DAY);

        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    //-----------------------------------------------------------------------
    // isSameDay
    //-----------------------------------------------------------------------

    public void testIsSameDay_Date() {
        Date d1 = makeDate(2004, Calendar.JULY, 4, 13, 45, 30, 500);
        Date d2 = makeDate(2004, Calendar.JULY, 4, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertTrue(DateUtils.isSameDay(d2, d1));

        assertFalse(DateUtils.isSameDay(d1, makeDate(2004, Calendar.JULY, 5, 13, 45, 30, 500)));
        assertFalse(DateUtils.isSameDay(d1, makeDate(2005, Calendar.JULY, 4, 13, 45, 30, 500)));
        assertFalse(DateUtils.isSameDay(d1, makeDate(2004, Calendar.AUGUST, 4, 13, 45, 30, 500)));
    }

    public void testIsSameDay_Date_null() {
        Date now = new Date();
        try {
            DateUtils.isSameDay((Date) null, (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameDay(now, (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameDay((Date) null, now);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIsSameDay_Calendar() {
        Calendar c1 = makeCalendar(2004, Calendar.JULY, 4, 23, 59, 59, 999);
        Calendar c2 = makeCalendar(2004, Calendar.JULY, 4, 0, 0, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));

        assertFalse(DateUtils.isSameDay(c1, makeCalendar(2004, Calendar.JULY, 5, 0, 0, 0, 0)));
        assertFalse(DateUtils.isSameDay(c1, makeCalendar(2003, Calendar.JULY, 4, 23, 59, 59, 999)));

        // isSameDay must not alter its arguments
        assertEquals(makeDate(2004, Calendar.JULY, 4, 23, 59, 59, 999), c1.getTime());
        assertEquals(makeDate(2004, Calendar.JULY, 4, 0, 0, 0, 0), c2.getTime());

        try {
            DateUtils.isSameDay((Calendar) null, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameDay(c1, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameInstant
    //-----------------------------------------------------------------------

    public void testIsSameInstant_Date() {
        Date d1 = new Date(1234567890000L);
        Date d2 = new Date(1234567890000L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, new Date(1234567890001L)));
        assertFalse(DateUtils.isSameInstant(d1, new Date(1234567889999L)));

        try {
            DateUtils.isSameInstant((Date) null, (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameInstant(d1, (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameInstant((Date) null, d2);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIsSameInstant_Calendar() {
        Calendar c1 = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"));
        c1.setTime(new Date(1234567890000L));
        Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("GMT-5"));
        c2.setTime(new Date(1234567890000L));

        // same instant, even though the two calendars use different zones
        assertTrue(DateUtils.isSameInstant(c1, c2));
        // ... and therefore they do NOT share the same local time
        assertFalse(DateUtils.isSameLocalTime(c1, c2));

        c2.setTime(new Date(1234567890001L));
        assertFalse(DateUtils.isSameInstant(c1, c2));

        try {
            DateUtils.isSameInstant((Calendar) null, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameInstant(c1, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameLocalTime
    //-----------------------------------------------------------------------

    public void testIsSameLocalTime_Calendar() {
        Calendar c1 = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"));
        c1.clear();
        c1.set(2004, Calendar.JULY, 9, 11, 22, 33);
        c1.set(Calendar.MILLISECOND, 0);

        Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("GMT-1"));
        c2.clear();
        c2.set(2004, Calendar.JULY, 9, 11, 22, 33);
        c2.set(Calendar.MILLISECOND, 0);

        // identical field values but a different instant -> same local time
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c2));

        // a single differing field is enough to make it false
        c2.set(Calendar.MILLISECOND, 500);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
        c2.set(Calendar.MILLISECOND, 0);
        c2.set(Calendar.MINUTE, 59);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));

        // identical fields but a different Calendar implementation class -> false
        OtherCalendar other = new OtherCalendar(TimeZone.getTimeZone("GMT-1"));
        other.clear();
        other.set(2004, Calendar.JULY, 9, 11, 22, 33);
        other.set(Calendar.MILLISECOND, 0);
        assertFalse(DateUtils.isSameLocalTime(c1, other));

        try {
            DateUtils.isSameLocalTime((Calendar) null, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameLocalTime(c1, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // parseDate
    //-----------------------------------------------------------------------

    public void testParseDate() throws Exception {
        String[] patterns = new String[] {"yyyy-MM-dd", "yyyy/MM/dd", "dd.MM.yyyy"};

        Date d1 = DateUtils.parseDate("2005-07-04", patterns);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d1);
        assertEquals(2005, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));

        // the same calendar day expressed with the 2nd and 3rd patterns
        assertEquals(d1, DateUtils.parseDate("2005/07/04", patterns));
        assertEquals(d1, DateUtils.parseDate("04.07.2005", patterns));
    }

    public void testParseDate_noPatternMatches() {
        try {
            DateUtils.parseDate("gibberish", new String[] {"yyyy-MM-dd", "yyyy/MM/dd"});
            fail("Expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    public void testParseDate_trailingText() {
        // SimpleDateFormat would parse a prefix; parseDate requires the whole string
        try {
            DateUtils.parseDate("2005-07-04 and some more", new String[] {"yyyy-MM-dd"});
            fail("Expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    public void testParseDate_emptyPatternArray() {
        try {
            DateUtils.parseDate("2005-07-04", new String[0]);
            fail("Expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    public void testParseDate_null() throws Exception {
        try {
            DateUtils.parseDate(null, new String[] {"yyyy-MM-dd"});
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.parseDate("2005-07-04", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // add / addXxx
    //-----------------------------------------------------------------------

    public void testAddYears() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2001, Calendar.JUNE, 15, 12, 30, 45, 500), DateUtils.addYears(base, 1));
        assertEquals(makeDate(1998, Calendar.JUNE, 15, 12, 30, 45, 500), DateUtils.addYears(base, -2));
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500), DateUtils.addYears(base, 0));
        // original must be untouched
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500), base);
    }

    public void testAddMonths() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JULY, 15, 12, 30, 45, 500), DateUtils.addMonths(base, 1));
        assertEquals(makeDate(1999, Calendar.NOVEMBER, 15, 12, 30, 45, 500), DateUtils.addMonths(base, -7));
    }

    public void testAddWeeks() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JUNE, 29, 12, 30, 45, 500), DateUtils.addWeeks(base, 2));
        assertEquals(makeDate(2000, Calendar.MAY, 25, 12, 30, 45, 500), DateUtils.addWeeks(base, -3));
    }

    public void testAddDays() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JULY, 5, 12, 30, 45, 500), DateUtils.addDays(base, 20));
        assertEquals(makeDate(2000, Calendar.MAY, 26, 12, 30, 45, 500), DateUtils.addDays(base, -20));
    }

    public void testAddHours() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JUNE, 16, 1, 30, 45, 500), DateUtils.addHours(base, 13));
        assertEquals(makeDate(2000, Calendar.JUNE, 14, 23, 30, 45, 500), DateUtils.addHours(base, -13));
    }

    public void testAddMinutes() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 13, 10, 45, 500), DateUtils.addMinutes(base, 40));
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 11, 45, 45, 500), DateUtils.addMinutes(base, -45));
    }

    public void testAddSeconds() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 12, 31, 5, 500), DateUtils.addSeconds(base, 20));
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 12, 29, 55, 500), DateUtils.addSeconds(base, -50));
    }

    public void testAddMilliseconds() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 750), DateUtils.addMilliseconds(base, 250));
        assertEquals(base.getTime() + 250L, DateUtils.addMilliseconds(base, 250).getTime());
        assertEquals(base.getTime() - 600L, DateUtils.addMilliseconds(base, -600).getTime());
    }

    public void testAdd_genericField() {
        Date base = makeDate(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertEquals(DateUtils.addYears(base, 3), DateUtils.add(base, Calendar.YEAR, 3));
        assertEquals(DateUtils.addDays(base, 10), DateUtils.add(base, Calendar.DAY_OF_MONTH, 10));
        assertEquals(base, DateUtils.add(base, Calendar.YEAR, 0));

        Date result = DateUtils.add(base, Calendar.HOUR_OF_DAY, 1);
        assertNotSame(base, result);
        assertEquals(base.getTime() + DateUtils.MILLIS_PER_HOUR, result.getTime());
    }

    public void testAdd_nullDate() {
        try { DateUtils.add(null, Calendar.YEAR, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addYears(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addMonths(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addWeeks(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addDays(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addHours(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addMinutes(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addSeconds(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.addMilliseconds(null, 1); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
    }

    //-----------------------------------------------------------------------
    // truncate
    //-----------------------------------------------------------------------

    public void testTruncate_Date_fields() {
        Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        assertEquals(base, DateUtils.truncate(base, Calendar.MILLISECOND));
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 0),
                DateUtils.truncate(base, Calendar.SECOND));
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0),
                DateUtils.truncate(base, Calendar.MINUTE));
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0),
                DateUtils.truncate(base, Calendar.HOUR));
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0),
                DateUtils.truncate(base, Calendar.HOUR_OF_DAY));
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0),
                DateUtils.truncate(base, Calendar.DATE));
        assertEquals(makeDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0),
                DateUtils.truncate(base, Calendar.MONTH));
        assertEquals(makeDate(2002, Calendar.JANUARY, 1, 0, 0, 0, 0),
                DateUtils.truncate(base, Calendar.YEAR));

        // truncate returns a new object and does not mutate the argument
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), base);
    }

    public void testTruncate_Date_amPmAndSemiMonth() {
        // AM -> start of day, PM -> noon
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0),
                DateUtils.truncate(makeDate(2002, Calendar.MARCH, 28, 9, 45, 30, 500), Calendar.AM_PM));
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 12, 0, 0, 0),
                DateUtils.truncate(makeDate(2002, Calendar.MARCH, 28, 21, 45, 30, 500), Calendar.AM_PM));

        // first half of the month -> the 1st, second half -> the 16th
        assertEquals(makeDate(2001, Calendar.FEBRUARY, 1, 0, 0, 0, 0),
                DateUtils.truncate(makeDate(2001, Calendar.FEBRUARY, 12, 10, 20, 30, 400), DateUtils.SEMI_MONTH));
        assertEquals(makeDate(2001, Calendar.FEBRUARY, 16, 0, 0, 0, 0),
                DateUtils.truncate(makeDate(2001, Calendar.FEBRUARY, 20, 10, 20, 30, 400), DateUtils.SEMI_MONTH));
    }

    public void testTruncate_idempotent() {
        Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date once = DateUtils.truncate(base, Calendar.HOUR);
        assertEquals(once, DateUtils.truncate(once, Calendar.HOUR));
    }

    public void testTruncate_Calendar_newObjectAndInputKept() {
        Calendar input = makeCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar copy = (Calendar) input.clone();

        Calendar result = DateUtils.truncate(input, Calendar.HOUR);
        assertNotSame(input, result);
        assertEquals("input must not be mutated", copy.getTime(), input.getTime());
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), result.getTime());
    }

    public void testTruncate_Object_dateAndCalendar() {
        Date d = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c = makeCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date expected = makeDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        assertEquals(expected, DateUtils.truncate((Object) d, Calendar.HOUR));
        assertEquals(expected, DateUtils.truncate((Object) c, Calendar.HOUR));
    }

    //-----------------------------------------------------------------------
    // round
    //-----------------------------------------------------------------------

    public void testRound_Date_hour() {
        assertEquals("29 minutes rounds down",
                makeDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 29, 0, 0), Calendar.HOUR));
        assertEquals("exactly 30 minutes rounds up",
                makeDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 30, 0, 0), Calendar.HOUR));
        assertEquals("45 minutes rounds up (sub-minute fields dropped)",
                makeDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), Calendar.HOUR));
    }

    public void testRound_Date_dayMonthYear() {
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 11, 0, 0, 0), Calendar.DATE));
        assertEquals(makeDate(2002, Calendar.MARCH, 29, 0, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), Calendar.DATE));

        assertEquals(makeDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 10, 0, 0, 0, 0), Calendar.MONTH));
        assertEquals(makeDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 20, 0, 0, 0, 0), Calendar.MONTH));

        assertEquals(makeDate(2002, Calendar.JANUARY, 1, 0, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.MARCH, 15, 0, 0, 0, 0), Calendar.YEAR));
        assertEquals(makeDate(2003, Calendar.JANUARY, 1, 0, 0, 0, 0),
                DateUtils.round(makeDate(2002, Calendar.OCTOBER, 15, 0, 0, 0, 0), Calendar.YEAR));
    }

    public void testRound_Date_semiMonth() {
        assertEquals(makeDate(2001, Calendar.FEBRUARY, 1, 0, 0, 0, 0),
                DateUtils.round(makeDate(2001, Calendar.FEBRUARY, 3, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
        assertEquals(makeDate(2001, Calendar.FEBRUARY, 16, 0, 0, 0, 0),
                DateUtils.round(makeDate(2001, Calendar.FEBRUARY, 12, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
        assertEquals(makeDate(2001, Calendar.FEBRUARY, 16, 0, 0, 0, 0),
                DateUtils.round(makeDate(2001, Calendar.FEBRUARY, 20, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
        assertEquals(makeDate(2001, Calendar.MARCH, 1, 0, 0, 0, 0),
                DateUtils.round(makeDate(2001, Calendar.FEBRUARY, 25, 0, 0, 0, 0), DateUtils.SEMI_MONTH));
    }

    public void testRound_Calendar_newObjectAndInputKept() {
        Calendar input = makeCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar copy = (Calendar) input.clone();

        Calendar result = DateUtils.round(input, Calendar.HOUR);
        assertNotSame(input, result);
        assertEquals(copy.getTime(), input.getTime());
        assertEquals(makeDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result.getTime());
    }

    public void testRound_Object_dateAndCalendar() {
        Date d = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c = makeCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date expected = makeDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0);
        assertEquals(expected, DateUtils.round((Object) d, Calendar.HOUR));
        assertEquals(expected, DateUtils.round((Object) c, Calendar.HOUR));
    }

    //-----------------------------------------------------------------------
    // round / truncate error handling
    //-----------------------------------------------------------------------

    public void testRoundTruncate_nulls() {
        try { DateUtils.round((Date) null, Calendar.SECOND); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.round((Calendar) null, Calendar.SECOND); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.round((Object) null, Calendar.SECOND); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate((Date) null, Calendar.SECOND); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate((Calendar) null, Calendar.SECOND); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.truncate((Object) null, Calendar.SECOND); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
    }

    public void testRoundTruncate_wrongObjectType() {
        try {
            DateUtils.round("not a date", Calendar.SECOND);
            fail("Expected ClassCastException");
        } catch (ClassCastException ex) {
            // expected
        }
        try {
            DateUtils.truncate(Integer.valueOf(42), Calendar.SECOND);
            fail("Expected ClassCastException");
        } catch (ClassCastException ex) {
            // expected
        }
    }

    public void testRoundTruncate_unsupportedField() {
        Date base = makeDate(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        try {
            DateUtils.round(base, Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException for an unsupported field");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.truncate(base, Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException for an unsupported field");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        // the argument was not consumed / left in a broken state visible to caller
        assertEquals(makeDate(2000, Calendar.JANUARY, 1, 0, 0, 0, 0), base);
    }

    public void testRoundTruncate_yearTooLarge() {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(280000001, Calendar.JANUARY, 1);
        try {
            DateUtils.round(cal, Calendar.MONTH);
            fail("Expected ArithmeticException for a year over 280 million");
        } catch (ArithmeticException ex) {
            // expected
        }
        try {
            DateUtils.truncate(cal, Calendar.MONTH);
            fail("Expected ArithmeticException for a year over 280 million");
        } catch (ArithmeticException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // iterator
    //-----------------------------------------------------------------------

    // Thursday, 4 July 2002 is used as the focus for every range style below.

    public void testIterator_weekSunday() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 12, 34, 56, 789);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertDayIterator(it,
                makeDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0),
                7,
                makeDate(2002, Calendar.JULY, 6, 0, 0, 0, 0));
        // the focus calendar must not be modified
        assertEquals(makeDate(2002, Calendar.JULY, 4, 12, 34, 56, 789), focus.getTime());
    }

    public void testIterator_weekMonday() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertDayIterator(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY),
                makeDate(2002, Calendar.JULY, 1, 0, 0, 0, 0),
                7,
                makeDate(2002, Calendar.JULY, 7, 0, 0, 0, 0));
    }

    public void testIterator_weekRelative() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertDayIterator(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE),
                makeDate(2002, Calendar.JULY, 4, 0, 0, 0, 0),
                7,
                makeDate(2002, Calendar.JULY, 10, 0, 0, 0, 0));
    }

    public void testIterator_weekCenter() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertDayIterator(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER),
                makeDate(2002, Calendar.JULY, 1, 0, 0, 0, 0),
                7,
                makeDate(2002, Calendar.JULY, 7, 0, 0, 0, 0));
    }

    public void testIterator_monthSunday() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertDayIterator(DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY),
                makeDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0),
                35,
                makeDate(2002, Calendar.AUGUST, 3, 0, 0, 0, 0));
    }

    public void testIterator_monthMonday() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertDayIterator(DateUtils.iterator(focus, DateUtils.RANGE_MONTH_MONDAY),
                makeDate(2002, Calendar.JULY, 1, 0, 0, 0, 0),
                35,
                makeDate(2002, Calendar.AUGUST, 4, 0, 0, 0, 0));
    }

    public void testIterator_dateAndObjectOverloads() {
        Date focusDate = makeDate(2002, Calendar.JULY, 4, 15, 0, 0, 0);
        Date expectedFirst = makeDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0);

        Iterator itDate = DateUtils.iterator(focusDate, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(expectedFirst, ((Calendar) itDate.next()).getTime());

        Iterator itObjDate = DateUtils.iterator((Object) focusDate, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(expectedFirst, ((Calendar) itObjDate.next()).getTime());

        Iterator itObjCal = DateUtils.iterator(
                (Object) makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0), DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(expectedFirst, ((Calendar) itObjCal.next()).getTime());
    }

    public void testIterator_consecutiveElementsAreDistinctOneDayApart() {
        Iterator it = DateUtils.iterator(
                makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0), DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = (Calendar) it.next();
        Calendar second = (Calendar) it.next();
        assertNotSame(first, second);
        assertEquals(DateUtils.MILLIS_PER_DAY, second.getTime().getTime() - first.getTime().getTime());
    }

    public void testIterator_nullFocus() {
        try { DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
        try { DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY); fail("Expected IllegalArgumentException"); }
        catch (IllegalArgumentException ex) { /* expected */ }
    }

    public void testIterator_invalidRangeStyle() {
        Calendar focus = makeCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        try {
            DateUtils.iterator(focus, -1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.iterator(focus, 100);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIterator_wrongObjectType() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException ex) {
            // expected
        }
    }
}
