/*
 * Copyright (C) 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.gson.internal.bind.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import junit.framework.TestCase;

public class ISO8601UtilsAgentTest extends TestCase {
  private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

  private static Date buildDate(TimeZone tz, int year, int month, int day, int hour, int minute,
      int second, int millis) {
    Calendar calendar = new GregorianCalendar(tz);
    calendar.clear();
    calendar.set(year, month - 1, day, hour, minute, second);
    calendar.set(Calendar.MILLISECOND, millis);
    return calendar.getTime();
  }

  // ---- format(Date) ----

  public void testFormat_defaultUsesUtcAndNoMillis() {
    Date date = buildDate(UTC, 2018, 6, 25, 10, 20, 30, 123);
    String formatted = ISO8601Utils.format(date);
    assertEquals("2018-06-25T10:20:30Z", formatted);
  }

  public void testFormat_zeroPadsSingleDigitFieldsAndSmallYear() {
    Date date = buildDate(UTC, 5, 1, 2, 3, 4, 5, 0);
    String formatted = ISO8601Utils.format(date);
    assertEquals("0005-01-02T03:04:05Z", formatted);
  }

  // ---- format(Date, boolean) ----

  public void testFormat_withMillisTrueIncludesThreeDigitMillis() {
    Date date = buildDate(UTC, 2018, 1, 1, 0, 0, 0, 5);
    String formatted = ISO8601Utils.format(date, true);
    assertEquals("2018-01-01T00:00:00.005Z", formatted);
  }

  public void testFormat_withMillisFalseOmitsFraction() {
    Date date = buildDate(UTC, 2018, 6, 25, 10, 20, 30, 999);
    String formatted = ISO8601Utils.format(date, false);
    assertEquals("2018-06-25T10:20:30Z", formatted);
    assertFalse(formatted.contains("."));
  }

  // ---- format(Date, boolean, TimeZone) ----

  public void testFormat_withPositiveOffsetTimeZone() {
    Date date = buildDate(UTC, 2018, 6, 25, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT+02:00"));
    assertEquals("2018-06-25T12:20:30+02:00", formatted);
  }

  public void testFormat_withNegativeOffsetTimeZone() {
    Date date = buildDate(UTC, 2018, 6, 25, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT-05:00"));
    assertEquals("2018-06-25T05:20:30-05:00", formatted);
  }

  public void testFormat_withMillisAndOffsetTimeZone() {
    Date date = buildDate(UTC, 2018, 6, 25, 10, 20, 30, 42);
    String formatted = ISO8601Utils.format(date, true, TimeZone.getTimeZone("GMT+02:00"));
    assertEquals("2018-06-25T12:20:30.042+02:00", formatted);
  }

  // ---- parse: date-only ----

  public void testParse_dateOnlyWithDashes() throws Exception {
    ParsePosition pos = new ParsePosition(0);
    Date result = ISO8601Utils.parse("2018-06-25", pos);
    Date expected = new GregorianCalendar(2018, Calendar.JUNE, 25).getTime();
    assertEquals(expected, result);
    assertEquals(10, pos.getIndex());
  }

  public void testParse_dateOnlyWithoutDashes() throws Exception {
    ParsePosition pos = new ParsePosition(0);
    Date result = ISO8601Utils.parse("20180625", pos);
    Date expected = new GregorianCalendar(2018, Calendar.JUNE, 25).getTime();
    assertEquals(expected, result);
    assertEquals(8, pos.getIndex());
  }

  // ---- parse: date-time with Z ----

  public void testParse_dateTimeWithZulu() throws Exception {
    ParsePosition pos = new ParsePosition(0);
    String input = "2018-06-25T10:20:30Z";
    Date result = ISO8601Utils.parse(input, pos);
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 0), result);
    assertEquals(input.length(), pos.getIndex());
  }

  public void testParse_dateTimeCompactFormWithoutSeparators() throws Exception {
    ParsePosition pos = new ParsePosition(0);
    Date result = ISO8601Utils.parse("2018-06-25T102030Z", pos);
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 0), result);
  }

  // ---- parse: milliseconds handling ----

  public void testParse_threeDigitMillis() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:30.123Z", new ParsePosition(0));
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 123), result);
  }

  public void testParse_twoDigitMillisScaledByTen() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:30.12Z", new ParsePosition(0));
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 120), result);
  }

  public void testParse_oneDigitMillisScaledByHundred() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:30.1Z", new ParsePosition(0));
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 100), result);
  }

  public void testParse_moreThanThreeDigitMillisTruncatedButFullyConsumed() throws Exception {
    ParsePosition pos = new ParsePosition(0);
    String input = "2018-06-25T10:20:30.1234Z";
    Date result = ISO8601Utils.parse(input, pos);
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 123), result);
    // the whole fractional digit run is consumed even though only 3 digits are used
    assertEquals(input.length(), pos.getIndex());
  }

  // ---- parse: timezone offset forms ----

  public void testParse_offsetWithColon() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:30+02:00", new ParsePosition(0));
    assertEquals(buildDate(TimeZone.getTimeZone("GMT+02:00"), 2018, 6, 25, 10, 20, 30, 0), result);
  }

  public void testParse_offsetWithoutColon() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:30+0200", new ParsePosition(0));
    assertEquals(buildDate(TimeZone.getTimeZone("GMT+02:00"), 2018, 6, 25, 10, 20, 30, 0), result);
  }

  public void testParse_offsetHourOnlyImpliesZeroMinutes() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:30+02", new ParsePosition(0));
    assertEquals(buildDate(TimeZone.getTimeZone("GMT+02:00"), 2018, 6, 25, 10, 20, 30, 0), result);
  }

  public void testParse_zeroOffsetFormsAreEquivalentToZulu() throws Exception {
    Date zulu = ISO8601Utils.parse("2018-06-25T10:20:30Z", new ParsePosition(0));
    Date plusColon = ISO8601Utils.parse("2018-06-25T10:20:30+00:00", new ParsePosition(0));
    Date plusCompact = ISO8601Utils.parse("2018-06-25T10:20:30+0000", new ParsePosition(0));
    assertEquals(zulu, plusColon);
    assertEquals(zulu, plusCompact);
  }

  // ---- parse: leap second handling ----

  public void testParse_leapSecondSixtyTruncatedToFiftyNine() throws Exception {
    Date result = ISO8601Utils.parse("2018-06-25T10:20:60Z", new ParsePosition(0));
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 59, 0), result);
  }

  // ---- parse: position tracking ----

  public void testParse_parsePositionAdvancesFromNonZeroStart() throws Exception {
    String input = "XX2018-06-25T10:20:30Z";
    ParsePosition pos = new ParsePosition(2);
    Date result = ISO8601Utils.parse(input, pos);
    assertEquals(buildDate(UTC, 2018, 6, 25, 10, 20, 30, 0), result);
    assertEquals(input.length(), pos.getIndex());
  }

  // ---- parse: error cases ----

  public void testParse_nullInputThrowsNullPointerException() throws Exception {
    try {
      ISO8601Utils.parse(null, new ParsePosition(0));
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testParse_emptyStringThrowsParseException() {
    try {
      ISO8601Utils.parse("", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("NumberFormatException"));
      assertEquals(0, expected.getErrorOffset());
    }
  }

  public void testParse_nonNumericFieldThrowsParseExceptionWithMessage() {
    try {
      ISO8601Utils.parse("2018-06-XXT10:20:30Z", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("Invalid number: XX"));
    }
  }

  public void testParse_missingTimeZoneIndicatorThrowsParseException() {
    try {
      ISO8601Utils.parse("2018-06-25T10:20:30", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("No time zone indicator"));
    }
  }

  public void testParse_invalidTimeZoneIndicatorThrowsParseException() {
    try {
      ISO8601Utils.parse("2018-06-25T10:20:30X", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("Invalid time zone indicator"));
    }
  }

  public void testParse_mismatchingTimeZoneOffsetThrowsParseException() {
    try {
      ISO8601Utils.parse("2018-06-25T10:20:30+25:00", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("Mismatching time zone indicator"));
    }
  }

  public void testParse_outOfRangeSecondsThrowsParseException() {
    try {
      // 63 is beyond the tolerated leap-second window (60-62), so it is not truncated
      // and fails calendar validation instead.
      ISO8601Utils.parse("2018-06-25T10:20:63Z", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("SECOND"));
    }
  }

  public void testParse_invalidHourThrowsParseException() {
    try {
      ISO8601Utils.parse("2018-06-25T25:00:00Z", new ParsePosition(0));
      fail();
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("HOUR_OF_DAY"));
    }
  }

  // ---- round trip ----

  public void testFormatThenParseRoundTripsToSameInstant() throws Exception {
    Date original = buildDate(UTC, 2018, 6, 25, 10, 20, 30, 123);
    String formatted = ISO8601Utils.format(original, true);
    Date parsed = ISO8601Utils.parse(formatted, new ParsePosition(0));
    assertEquals(original, parsed);
  }
}
