/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.text;

import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Test class for {@link org.apache.commons.lang3.text.ExtendedMessageFormat}.
 *
 * @version $Id$
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    private Map<String, FormatFactory> registry;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        registry.put("lower", new LowerCaseFormatFactory());
    }

    //-----------------------------------------------------------------------
    // Construction / toPattern
    //-----------------------------------------------------------------------

    public void testNoRegistryBehavesLikeMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}!");
        assertEquals("Hi {0}!", emf.toPattern());
        assertEquals("Hi World!", emf.format(new Object[] {"World"}));
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    public void testNoRegistryHonoursStandardFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#.##}", Locale.US);
        assertEquals("1.5", emf.format(new Object[] {new Double(1.5)}));
        assertEquals(1, emf.getFormats().length);
    }

    public void testNoRegistryHonoursQuoting() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{'0'}' is literal, {0} is not", Locale.US);
        assertEquals("{0} is literal, arg is not", emf.format(new Object[] {"arg"}));
    }

    public void testLocaleIsUsedForStandardFormats() {
        ExtendedMessageFormat german = new ExtendedMessageFormat("{0,number,#.##}", Locale.GERMANY);
        ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number,#.##}", Locale.US);
        assertEquals(Locale.GERMANY, german.getLocale());
        assertEquals("1,5", german.format(new Object[] {new Double(1.5)}));
        assertEquals("1.5", us.format(new Object[] {new Double(1.5)}));
    }

    public void testEmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.US, registry);
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
        assertEquals(0, emf.getFormats().length);
    }

    public void testPatternWithoutFormatElements() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("no elements here", Locale.US, registry);
        assertEquals("no elements here", emf.toPattern());
        assertEquals("no elements here", emf.format(new Object[0]));
        assertEquals(0, emf.getFormats().length);
    }

    public void testNullRegistryEquivalentToNoRegistry() {
        ExtendedMessageFormat withNull = new ExtendedMessageFormat("{0,number,#.##}", Locale.US, null);
        ExtendedMessageFormat without = new ExtendedMessageFormat("{0,number,#.##}", Locale.US);
        assertEquals(without.toPattern(), withNull.toPattern());
        assertEquals("1.5", withNull.format(new Object[] {new Double(1.5)}));
    }

    //-----------------------------------------------------------------------
    // Custom formats
    //-----------------------------------------------------------------------

    public void testCustomFormatIsApplied() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0,upper}!", Locale.US, registry);
        assertEquals("Hello WORLD!", emf.format(new Object[] {"world"}));
        assertEquals("Hello {0,upper}!", emf.toPattern());
    }

    public void testCustomFormatInstanceIsInstalled() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        Format[] formats = emf.getFormats();
        assertEquals(1, formats.length);
        assertSame(UpperCaseFormatFactory.INSTANCE, formats[0]);
    }

    public void testMultipleCustomFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1,lower}", Locale.US, registry);
        assertEquals("ONE and two", emf.format(new Object[] {"one", "TWO"}));
        assertEquals("{0,upper} and {1,lower}", emf.toPattern());
        assertEquals(2, emf.getFormats().length);
    }

    public void testCustomAndBuiltInFormatsMixed() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,upper} has {1,number,#} items", Locale.US, registry);
        assertEquals("BOX has 3 items", emf.format(new Object[] {"box", new Integer(3)}));
        Format[] formats = emf.getFormats();
        assertEquals(2, formats.length);
        assertSame(UpperCaseFormatFactory.INSTANCE, formats[0]);
        assertTrue("expected a NumberFormat, got " + formats[1], formats[1] instanceof NumberFormat);
    }

    public void testArgumentIndicesAreHonoured() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{2}{0,upper}{1}", Locale.US, registry);
        assertEquals("cAb", emf.format(new Object[] {"a", "b", "c"}));
    }

    public void testRepeatedArgumentIndex() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}-{0,lower}", Locale.US, registry);
        assertEquals("AB-ab", emf.format(new Object[] {"Ab"}));
    }

    public void testFormatStyleIsPassedToFactory() {
        RecordingFormatFactory factory = new RecordingFormatFactory(new PrefixFormat("<<"));
        Map<String, FormatFactory> reg = Collections.singletonMap("prefix", (FormatFactory) factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,prefix,ignored}", Locale.CANADA, reg);
        assertEquals("prefix", factory.name);
        assertEquals("ignored", factory.arguments);
        assertEquals(Locale.CANADA, factory.locale);
        assertEquals("<<value", emf.format(new Object[] {"value"}));
        assertEquals("{0,prefix,ignored}", emf.toPattern());
    }

    public void testFormatNameWithoutStylePassesNullArguments() {
        RecordingFormatFactory factory = new RecordingFormatFactory(new PrefixFormat("!"));
        Map<String, FormatFactory> reg = Collections.singletonMap("prefix", (FormatFactory) factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,prefix}", Locale.US, reg);
        assertEquals("prefix", factory.name);
        assertNull(factory.arguments);
        assertEquals("!x", emf.format(new Object[] {"x"}));
    }

    public void testWhitespaceAroundArgumentIndexAndFormatName() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 , upper}", Locale.US, registry);
        assertEquals("HI", emf.format(new Object[] {"hi"}));
        assertEquals("{0,upper}", emf.toPattern());
    }

    public void testFactoryReturningNullFallsBackToBuiltInFormat() {
        RecordingFormatFactory factory = new RecordingFormatFactory(null);
        Map<String, FormatFactory> reg = Collections.singletonMap("number", (FormatFactory) factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#.##}", Locale.US, reg);
        assertEquals("number", factory.name);
        assertEquals("#.##", factory.arguments);
        assertEquals("1.5", emf.format(new Object[] {new Double(1.5)}));
        assertTrue(emf.getFormats()[0] instanceof NumberFormat);
    }

    public void testUnknownFormatNameFallsBackToBuiltInFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#}", Locale.US, registry);
        assertEquals("2", emf.format(new Object[] {new Integer(2)}));
        assertEquals("{0,number,#}", emf.toPattern());
    }

    public void testEmptyRegistryStillParsesStandardPatterns() {
        Map<String, FormatFactory> empty = Collections.emptyMap();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} & {1}", Locale.US, empty);
        assertEquals("a & b", emf.format(new Object[] {"a", "b"}));
        assertEquals("{0} & {1}", emf.toPattern());
    }

    public void testEscapedQuoteWithRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("It''s {0,upper}", Locale.US, registry);
        assertEquals("It's HOT", emf.format(new Object[] {"hot"}));
    }

    public void testNestedChoiceFormat() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,choice,0#none|1#{1,upper}}", Locale.US, registry);
        assertEquals("none", emf.format(new Object[] {new Integer(0), "x"}));
    }

    public void testCustomFormatOfNonStringArgument() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals("TRUE", emf.format(new Object[] {Boolean.TRUE}));
    }

    //-----------------------------------------------------------------------
    // applyPattern
    //-----------------------------------------------------------------------

    public void testApplyPatternReplacesPreviousPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals("A", emf.format(new Object[] {"a"}));
        emf.applyPattern("<{0,lower}>");
        assertEquals("<{0,lower}>", emf.toPattern());
        assertEquals("<a>", emf.format(new Object[] {"A"}));
        assertSame(LowerCaseFormatFactory.INSTANCE, emf.getFormats()[0]);
    }

    public void testApplyPatternRemovingAllElements() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        emf.applyPattern("constant");
        assertEquals("constant", emf.toPattern());
        assertEquals("constant", emf.format(new Object[0]));
        assertEquals(0, emf.getFormats().length);
    }

    //-----------------------------------------------------------------------
    // Error cases
    //-----------------------------------------------------------------------

    public void testUnterminatedFormatElement() {
        try {
            new ExtendedMessageFormat("{0", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertTrue("unexpected message: " + ex.getMessage(),
                    ex.getMessage().indexOf("Unterminated format element") >= 0);
        }
    }

    public void testUnterminatedFormatDescription() {
        try {
            new ExtendedMessageFormat("text {0,upper", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertTrue("unexpected message: " + ex.getMessage(),
                    ex.getMessage().indexOf("Unterminated format element") >= 0);
        }
    }

    public void testInvalidArgumentIndex() {
        try {
            new ExtendedMessageFormat("{foo}", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertTrue("unexpected message: " + ex.getMessage(),
                    ex.getMessage().indexOf("Invalid format argument index") >= 0);
        }
    }

    public void testNegativeArgumentIndex() {
        try {
            new ExtendedMessageFormat("{-1}", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertTrue("unexpected message: " + ex.getMessage(),
                    ex.getMessage().indexOf("Invalid format argument index") >= 0);
        }
    }

    public void testUnknownFormatTypeIsRejected() {
        try {
            new ExtendedMessageFormat("{0,nosuchformat}", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected - neither the registry nor MessageFormat knows this type
        }
    }

    public void testNullPatternIsRejected() {
        try {
            new ExtendedMessageFormat(null, Locale.US, registry);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
        try {
            new ExtendedMessageFormat(null, Locale.US, null);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    public void testMissingArgumentsAreLeftAsPlaceholders() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} {1}", Locale.US, registry);
        assertEquals("ONLY-ONE {1}", emf.format(new Object[] {"only-one"}));
        assertEquals("{0} {1}", emf.format(new Object[0]));
    }

    public void testSurplusArgumentsAreIgnored() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals("A", emf.format(new Object[] {"a", "b", "c"}));
    }

    //-----------------------------------------------------------------------
    // Disabled mutators
    //-----------------------------------------------------------------------

    public void testSetFormatIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        try {
            emf.setFormat(0, new PrefixFormat("#"));
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
        assertSame(UpperCaseFormatFactory.INSTANCE, emf.getFormats()[0]);
        assertEquals("A", emf.format(new Object[] {"a"}));
    }

    public void testSetFormatByArgumentIndexIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        try {
            emf.setFormatByArgumentIndex(0, new PrefixFormat("#"));
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
        assertSame(UpperCaseFormatFactory.INSTANCE, emf.getFormats()[0]);
    }

    public void testSetFormatsIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        try {
            emf.setFormats(new Format[] {new PrefixFormat("#")});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
        assertSame(UpperCaseFormatFactory.INSTANCE, emf.getFormats()[0]);
    }

    public void testSetFormatsByArgumentIndexIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        try {
            emf.setFormatsByArgumentIndex(new Format[] {new PrefixFormat("#")});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
        assertSame(UpperCaseFormatFactory.INSTANCE, emf.getFormats()[0]);
    }

    public void testSetFormatsIsUnsupportedEvenForNull() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, registry);
        try {
            emf.setFormats(null);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // equals / hashCode
    //-----------------------------------------------------------------------

    public void testEqualsSameInstance() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertTrue(emf.equals(emf));
        assertEquals(emf.hashCode(), emf.hashCode());
    }

    public void testEqualsEquivalentInstances() {
        ExtendedMessageFormat one = new ExtendedMessageFormat("Pattern: {0,upper}", Locale.US, registry);
        ExtendedMessageFormat two = new ExtendedMessageFormat("Pattern: {0,upper}", Locale.US, registry);
        assertTrue(one.equals(two));
        assertTrue(two.equals(one));
        assertEquals(one.hashCode(), two.hashCode());
    }

    public void testEqualsEquivalentInstancesWithoutRegistry() {
        ExtendedMessageFormat one = new ExtendedMessageFormat("Pattern: {0}", Locale.US);
        ExtendedMessageFormat two = new ExtendedMessageFormat("Pattern: {0}", Locale.US);
        assertTrue(one.equals(two));
        assertEquals(one.hashCode(), two.hashCode());
    }

    public void testEqualsNull() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, registry);
        assertFalse(emf.equals(null));
    }

    public void testEqualsForeignType() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, registry);
        assertFalse(emf.equals("{0}"));
        assertFalse(emf.equals(new java.text.MessageFormat("{0}", Locale.US)));
    }

    public void testEqualsDifferentPattern() {
        ExtendedMessageFormat one = new ExtendedMessageFormat("Pattern: {0,upper}", Locale.US, registry);
        ExtendedMessageFormat two = new ExtendedMessageFormat("X Pattern: {0,upper}", Locale.US, registry);
        assertFalse(one.equals(two));
        assertFalse(two.equals(one));
        assertTrue(one.hashCode() != two.hashCode());
    }

    public void testEqualsDifferentRegistry() {
        Map<String, FormatFactory> other = new HashMap<String, FormatFactory>();
        other.put("upper", new LowerCaseFormatFactory());
        ExtendedMessageFormat one = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        ExtendedMessageFormat two = new ExtendedMessageFormat("{0,upper}", Locale.US, other);
        assertFalse(one.equals(two));
        assertFalse(two.equals(one));
    }

    public void testEqualsRegistryVersusNoRegistry() {
        Map<String, FormatFactory> empty = Collections.emptyMap();
        ExtendedMessageFormat withRegistry = new ExtendedMessageFormat("{0}", Locale.US, empty);
        ExtendedMessageFormat withoutRegistry = new ExtendedMessageFormat("{0}", Locale.US, null);
        assertEquals(withRegistry.toPattern(), withoutRegistry.toPattern());
        assertFalse(withRegistry.equals(withoutRegistry));
        assertFalse(withoutRegistry.equals(withRegistry));
    }

    public void testEqualsSubclass() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        ExtendedMessageFormat sub = new OtherExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertFalse(emf.equals(sub));
        assertFalse(sub.equals(emf));
    }

    public void testHashCodeChangesWithPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        int before = emf.hashCode();
        emf.applyPattern("{0,lower}");
        assertTrue(before != emf.hashCode());
        assertEquals(emf.hashCode(), new ExtendedMessageFormat("{0,lower}", Locale.US, registry).hashCode());
    }

    //-----------------------------------------------------------------------
    // Test fixtures
    //-----------------------------------------------------------------------

    /**
     * A subclass used to verify that equality is type sensitive.
     */
    private static class OtherExtendedMessageFormat extends ExtendedMessageFormat {
        private static final long serialVersionUID = 1L;

        public OtherExtendedMessageFormat(String pattern, Locale locale,
                Map<String, ? extends FormatFactory> registry) {
            super(pattern, locale, registry);
        }
    }

    /**
     * Formats any object by upper casing its string representation.
     */
    private static class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.US));
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * Formats any object by lower casing its string representation.
     */
    private static class LowerCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toLowerCase(Locale.US));
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * Formats any object by prepending a fixed prefix.
     */
    private static class PrefixFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String prefix;

        public PrefixFormat(String prefix) {
            this.prefix = prefix;
        }

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(prefix).append(String.valueOf(obj));
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    private static class UpperCaseFormatFactory implements FormatFactory {
        static final Format INSTANCE = new UpperCaseFormat();

        public Format getFormat(String name, String arguments, Locale locale) {
            return INSTANCE;
        }
    }

    private static class LowerCaseFormatFactory implements FormatFactory {
        static final Format INSTANCE = new LowerCaseFormat();

        public Format getFormat(String name, String arguments, Locale locale) {
            return INSTANCE;
        }
    }

    /**
     * Records the values the factory was called with and returns a fixed (possibly null) format.
     */
    private static class RecordingFormatFactory implements FormatFactory {
        private final Format format;
        String name;
        String arguments;
        Locale locale;

        public RecordingFormatFactory(Format format) {
            this.format = format;
        }

        public Format getFormat(String name, String arguments, Locale locale) {
            this.name = name;
            this.arguments = arguments;
            this.locale = locale;
            return format;
        }
    }
}
