package org.apache.commons.csv;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link CSVRecord}, written against the published
 * javadoc contract in {@code api/} only.
 *
 * <p>Uses the JUnit 3.8 style ({@code extends TestCase}) so it compiles against
 * {@code junit-3.8.1.jar}. No external test helpers are referenced; every
 * fixture is defined in this file. The {@link CSVRecord} constructor is
 * package-private, so this test lives in {@code org.apache.commons.csv} and
 * constructs records directly.</p>
 */
public class CSVRecordAgentTest extends TestCase {

    // ------------------------------------------------------------------
    // Inline fixtures / helpers (nothing external)
    // ------------------------------------------------------------------

    /** An enum used to exercise {@link CSVRecord#get(Enum)}. */
    private enum Header { A, B, C }

    private static CSVRecord newRecord(final String[] values,
            final Map<String, Integer> mapping, final String comment,
            final long recordNumber) {
        return new CSVRecord(values, mapping, comment, recordNumber);
    }

    /** Builds a header mapping {@code name -> position} for the supplied names. */
    private static Map<String, Integer> headerMapping(final String... names) {
        final Map<String, Integer> mapping = new HashMap<String, Integer>();
        for (int i = 0; i < names.length; i++) {
            mapping.put(names[i], Integer.valueOf(i));
        }
        return mapping;
    }

    // ------------------------------------------------------------------
    // size()
    // ------------------------------------------------------------------

    public void testSizeReturnsNumberOfValues() {
        final CSVRecord record = newRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        assertEquals(3, record.size());
    }

    public void testSizeOfEmptyRecordIsZero() {
        final CSVRecord record = newRecord(new String[0], null, null, 1L);
        assertEquals(0, record.size());
    }

    public void testSizeAgreesWithValuesLengthAndIteratorCount() {
        final CSVRecord record = newRecord(new String[] { "w", "x", "y", "z" }, null, null, 1L);
        assertEquals(record.size(), record.values().length);
        int count = 0;
        final Iterator<String> it = record.iterator();
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(record.size(), count);
    }

    // ------------------------------------------------------------------
    // get(int)
    // ------------------------------------------------------------------

    public void testGetByIndexReturnsValueAtThatColumn() {
        final CSVRecord record = newRecord(new String[] { "first", "second", "third" }, null, null, 1L);
        assertEquals("first", record.get(0));
        assertEquals("second", record.get(1));
        assertEquals("third", record.get(2));
    }

    public void testGetByIndexAtSizeThrows() {
        final CSVRecord record = newRecord(new String[] { "only" }, null, null, 1L);
        try {
            record.get(1);
            fail("expected an IndexOutOfBoundsException for index == size()");
        } catch (final IndexOutOfBoundsException expected) {
            // a 0-based column index outside the record is invalid
        }
    }

    public void testGetByNegativeIndexThrows() {
        final CSVRecord record = newRecord(new String[] { "only" }, null, null, 1L);
        try {
            record.get(-1);
            fail("expected an IndexOutOfBoundsException for a negative index");
        } catch (final IndexOutOfBoundsException expected) {
            // ok
        }
    }

    // ------------------------------------------------------------------
    // get(String)
    // ------------------------------------------------------------------

    public void testGetByNameReturnsMappedValue() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B"), null, 1L);
        assertEquals("alpha", record.get("A"));
        assertEquals("beta", record.get("B"));
    }

    public void testGetByNamePreservesNullValue() {
        // get(String) is documented to possibly return null.
        final CSVRecord record = newRecord(new String[] { null, "beta" },
                headerMapping("A", "B"), null, 1L);
        assertNull(record.get("A"));
        assertNull(record.get(0));
        assertEquals("beta", record.get("B"));
    }

    public void testGetByNameWithoutHeaderMappingThrowsIllegalState() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" }, null, null, 1L);
        try {
            record.get("A");
            fail("expected IllegalStateException when no header mapping was provided");
        } catch (final IllegalStateException expected) {
            // ok
        }
    }

    public void testGetByUnmappedNameThrowsIllegalArgument() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B"), null, 1L);
        try {
            record.get("NOPE");
            fail("expected IllegalArgumentException for a name that is not mapped");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    public void testGetByNameForInconsistentRecordThrowsIllegalArgument() {
        // "C" is mapped to column 2, but the record only has two values.
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B", "C"), null, 1L);
        try {
            record.get("C");
            fail("expected IllegalArgumentException when the record is inconsistent");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    // ------------------------------------------------------------------
    // get(Enum)
    // ------------------------------------------------------------------

    public void testGetByEnumReturnsValueForEnumName() {
        final CSVRecord record = newRecord(new String[] { "va", "vb", "vc" },
                headerMapping("A", "B", "C"), null, 1L);
        assertEquals("va", record.get(Header.A));
        assertEquals("vc", record.get(Header.C));
    }

    public void testGetByEnumMatchesGetByName() {
        final CSVRecord record = newRecord(new String[] { "va", "vb", "vc" },
                headerMapping("A", "B", "C"), null, 1L);
        assertEquals(record.get("A"), record.get(Header.A));
        assertEquals(record.get("B"), record.get(Header.B));
    }

    public void testGetByEnumWhoseNameIsNotMappedThrowsIllegalArgument() {
        final CSVRecord record = newRecord(new String[] { "va", "vb" },
                headerMapping("A", "B"), null, 1L);
        try {
            record.get(Header.C);
            fail("expected IllegalArgumentException for an enum name that is not mapped");
        } catch (final IllegalArgumentException expected) {
            // ok
        }
    }

    // ------------------------------------------------------------------
    // getComment()
    // ------------------------------------------------------------------

    public void testGetCommentReturnsSuppliedComment() {
        final CSVRecord record = newRecord(new String[] { "a", "b" }, null, "# a comment", 1L);
        assertEquals("# a comment", record.getComment());
    }

    public void testGetCommentIsNullWhenNoneSupplied() {
        final CSVRecord record = newRecord(new String[] { "a", "b" }, null, null, 1L);
        assertNull(record.getComment());
    }

    // ------------------------------------------------------------------
    // getRecordNumber()
    // ------------------------------------------------------------------

    public void testGetRecordNumberReturnsSuppliedValue() {
        assertEquals(42L, newRecord(new String[] { "a" }, null, null, 42L).getRecordNumber());
    }

    public void testGetRecordNumberBoundaryValues() {
        assertEquals(0L, newRecord(new String[] { "a" }, null, null, 0L).getRecordNumber());
        assertEquals(Long.MAX_VALUE,
                newRecord(new String[] { "a" }, null, null, Long.MAX_VALUE).getRecordNumber());
    }

    // ------------------------------------------------------------------
    // isConsistent()
    // ------------------------------------------------------------------

    public void testIsConsistentTrueWhenThereIsNoHeaderMapping() {
        final CSVRecord record = newRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        assertTrue(record.isConsistent());
    }

    public void testIsConsistentTrueWhenHeaderSizeMatchesRecordSize() {
        final CSVRecord record = newRecord(new String[] { "a", "b" },
                headerMapping("A", "B"), null, 1L);
        assertTrue(record.isConsistent());
    }

    public void testIsConsistentFalseWhenHeaderSizeDiffersFromRecordSize() {
        final CSVRecord record = newRecord(new String[] { "a", "b" },
                headerMapping("A", "B", "C"), null, 1L);
        assertFalse(record.isConsistent());
    }

    // ------------------------------------------------------------------
    // isMapped(String)
    // ------------------------------------------------------------------

    public void testIsMappedReflectsDefinedColumnNames() {
        final CSVRecord record = newRecord(new String[] { "a", "b" },
                headerMapping("A", "B"), null, 1L);
        assertTrue(record.isMapped("A"));
        assertTrue(record.isMapped("B"));
        assertFalse(record.isMapped("C"));
    }

    public void testIsMappedFalseWhenThereIsNoHeaderMapping() {
        final CSVRecord record = newRecord(new String[] { "a", "b" }, null, null, 1L);
        assertFalse(record.isMapped("A"));
    }

    // ------------------------------------------------------------------
    // isSet(String)
    // ------------------------------------------------------------------

    public void testIsSetTrueOnlyWhenColumnIsMappedAndHasAValue() {
        // "C" maps to column 2, but the record only has two values.
        final CSVRecord record = newRecord(new String[] { "a", "b" },
                headerMapping("A", "B", "C"), null, 1L);
        assertTrue(record.isSet("A"));
        assertTrue(record.isSet("B"));
        assertFalse(record.isSet("C"));        // mapped, but no value present
        assertFalse(record.isSet("NOT_THERE")); // not mapped at all
    }

    public void testIsSetFalseWhenThereIsNoHeaderMapping() {
        final CSVRecord record = newRecord(new String[] { "a", "b" }, null, null, 1L);
        assertFalse(record.isSet("A"));
    }

    // ------------------------------------------------------------------
    // iterator()
    // ------------------------------------------------------------------

    public void testIteratorYieldsEveryValueInOrder() {
        final CSVRecord record = newRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        final List<String> collected = new ArrayList<String>();
        final Iterator<String> it = record.iterator();
        while (it.hasNext()) {
            collected.add(it.next());
        }
        assertEquals(3, collected.size());
        assertEquals("a", collected.get(0));
        assertEquals("b", collected.get(1));
        assertEquals("c", collected.get(2));
    }

    public void testIteratorThrowsNoSuchElementWhenExhausted() {
        final CSVRecord record = newRecord(new String[] { "only" }, null, null, 1L);
        final Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("only", it.next());
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("expected NoSuchElementException once the iterator is exhausted");
        } catch (final NoSuchElementException expected) {
            // ok
        }
    }

    // ------------------------------------------------------------------
    // toMap()
    // ------------------------------------------------------------------

    public void testToMapContainsHeaderNameToValueEntries() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B"), null, 1L);
        final Map<String, String> map = record.toMap();
        assertEquals(2, map.size());
        assertEquals("alpha", map.get("A"));
        assertEquals("beta", map.get("B"));
    }

    public void pruned_testToMapIsEmptyWhenRecordHasNoHeaders() {
        final CSVRecord record = newRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        final Map<String, String> map = record.toMap();
        assertNotNull(map);
        assertTrue(map.isEmpty());
    }

    public void testToMapOmitsColumnsThatHaveNoValue() {
        // "C" maps to column 2, which does not exist in this record.
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B", "C"), null, 1L);
        final Map<String, String> map = record.toMap();
        assertEquals("alpha", map.get("A"));
        assertEquals("beta", map.get("B"));
        assertFalse(map.containsKey("C"));
    }

    public void testToMapReturnsAFreshDetachedMapEachCall() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B"), null, 1L);
        final Map<String, String> first = record.toMap();
        first.put("INJECTED", "x");
        first.remove("A");
        final Map<String, String> second = record.toMap();
        assertNotSame(first, second);
        assertFalse(second.containsKey("INJECTED"));
        assertEquals("alpha", second.get("A"));
    }

    // ------------------------------------------------------------------
    // putIn(Map)
    // ------------------------------------------------------------------

    public void testPutInPopulatesAndReturnsTheGivenMap() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" },
                headerMapping("A", "B"), null, 1L);
        final HashMap<String, String> target = new HashMap<String, String>();
        final Map<String, String> returned = record.putIn(target);
        assertSame(target, returned);
        assertEquals("alpha", target.get("A"));
        assertEquals("beta", target.get("B"));
    }

    public void pruned_testPutInLeavesExistingEntriesWhenRecordHasNoHeaders() {
        final CSVRecord record = newRecord(new String[] { "a", "b" }, null, null, 1L);
        final HashMap<String, String> target = new HashMap<String, String>();
        target.put("pre", "existing");
        final Map<String, String> returned = record.putIn(target);
        assertSame(target, returned);
        assertEquals(1, target.size());
        assertEquals("existing", target.get("pre"));
    }

    // ------------------------------------------------------------------
    // values()
    // ------------------------------------------------------------------

    public void testValuesReturnsTheRecordValuesInOrder() {
        final CSVRecord record = newRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        final String[] values = record.values();
        assertEquals(3, values.length);
        assertEquals("a", values[0]);
        assertEquals("b", values[1]);
        assertEquals("c", values[2]);
    }

    // ------------------------------------------------------------------
    // toString()
    // ------------------------------------------------------------------

    public void testToStringIsNonNullAndReflectsTheValues() {
        final CSVRecord record = newRecord(new String[] { "alpha", "beta" }, null, null, 1L);
        final String text = record.toString();
        assertNotNull(text);
        assertTrue(text.length() > 0);
        assertTrue("toString should mention the record values",
                text.indexOf("alpha") >= 0);
        assertTrue("toString should mention the record values",
                text.indexOf("beta") >= 0);
    }

    // ------------------------------------------------------------------
    // declared type contract
    // ------------------------------------------------------------------

    public void testRecordIsSerializableAndIterable() {
        final CSVRecord record = newRecord(new String[] { "a", "b" }, null, null, 1L);
        assertTrue(record instanceof java.io.Serializable);
        assertTrue(record instanceof Iterable);
    }
}
