package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

/**
 * Self-contained JUnit 3.8 tests for {@link JsonWriter}, derived solely from
 * the class's documented contract (javadoc under api/).
 */
public class JsonWriterAgentTest extends TestCase {

    /** A Writer whose every operation fails, used to verify IOException propagation. */
    private static class FailingWriter extends Writer {
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("simulated write failure");
        }
        public void flush() throws IOException {
            throw new IOException("simulated flush failure");
        }
        public void close() throws IOException {
            throw new IOException("simulated close failure");
        }
    }

    // ---- return-value / fluent chaining contract ("Returns: this writer.") ----

    public void testBeginArrayReturnsSameInstance() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        assertSame(jw, jw.beginArray());
    }

    public void testEndArrayReturnsSameInstance() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        assertSame(jw, jw.endArray());
    }

    public void testBeginObjectReturnsSameInstance() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        assertSame(jw, jw.beginObject());
    }

    public void testEndObjectReturnsSameInstance() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        assertSame(jw, jw.endObject());
    }

    public void testNameReturnsSameInstance() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        assertSame(jw, jw.name("a"));
    }

    public void testValueStringReturnsSameInstance() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        assertSame(jw, jw.value("x"));
    }

    public void testFluentChainingProducesExpectedJson() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        JsonWriter result = jw.beginObject().name("a").value(1L).name("b").value(true).endObject();
        assertSame(jw, result);
        assertEquals("{\"a\":1,\"b\":true}", sw.toString());
    }

    // ---- basic structural encoding ----

    public void testEmptyArray() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.endArray();
        assertEquals("[]", sw.toString());
    }

    public void testEmptyObject() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginObject();
        jw.endObject();
        assertEquals("{}", sw.toString());
    }

    public void testObjectWithSingleNameValue() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginObject();
        jw.name("a");
        jw.value(1L);
        jw.endObject();
        assertEquals("{\"a\":1}", sw.toString());
    }

    public void testObjectWithMultipleNameValues() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginObject();
        jw.name("a");
        jw.value(1L);
        jw.name("b");
        jw.value(2L);
        jw.endObject();
        assertEquals("{\"a\":1,\"b\":2}", sw.toString());
    }

    public void testArrayWithMultipleValues() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(1L);
        jw.value(2L);
        jw.value(3L);
        jw.endArray();
        assertEquals("[1,2,3]", sw.toString());
    }

    public void testNestedObjectsAndArrays() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginObject();
        jw.name("arr");
        jw.beginArray();
        jw.value(1L);
        jw.value(2L);
        jw.endArray();
        jw.endObject();
        assertEquals("{\"arr\":[1,2]}", sw.toString());
    }

    // ---- value(String) / null literal handling ----

    public void testValueStringNullEncodesNullLiteral() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value((String) null);
        jw.endArray();
        assertEquals("[null]", sw.toString());
    }

    public void testValueStringPlainText() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value("hello");
        jw.endArray();
        assertEquals("[\"hello\"]", sw.toString());
    }

    // ---- jsonValue: raw, unquoted, unescaped ----

    public void testJsonValueWritesRawWithoutQuoting() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.jsonValue("123");
        jw.endArray();
        assertEquals("[123]", sw.toString());
    }

    public void testJsonValueNullEncodesNullLiteral() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.jsonValue(null);
        jw.endArray();
        assertEquals("[null]", sw.toString());
    }

    // ---- nullValue() ----

    public void testNullValue() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        JsonWriter result = jw.nullValue();
        jw.endArray();
        assertSame(jw, result);
        assertEquals("[null]", sw.toString());
    }

    // ---- boolean values ----

    public void testValueBooleanPrimitiveTrue() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(true);
        jw.endArray();
        assertEquals("[true]", sw.toString());
    }

    public void testValueBooleanPrimitiveFalse() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(false);
        jw.endArray();
        assertEquals("[false]", sw.toString());
    }

    public void testValueBooleanWrapperTrue() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(Boolean.TRUE);
        jw.endArray();
        assertEquals("[true]", sw.toString());
    }

    public void testValueBooleanWrapperFalse() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(Boolean.FALSE);
        jw.endArray();
        assertEquals("[false]", sw.toString());
    }

    // ---- numeric values: double ----

    public void testValueDoubleFinite() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(3.5);
        jw.endArray();
        assertEquals("[3.5]", sw.toString());
    }

    public void testValueDoubleNaNRejectedWhenStrict() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.value(Double.NaN);
            fail("Expected IllegalArgumentException for non-finite double in strict mode");
        } catch (IllegalArgumentException expected) {
            // documented: "a finite value. May not be NaNs or infinities."
        }
    }

    public void testValueDoubleInfiniteRejectedWhenStrict() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.value(Double.POSITIVE_INFINITY);
            fail("Expected IllegalArgumentException for non-finite double in strict mode");
        } catch (IllegalArgumentException expected) {
            // documented: "a finite value. May not be NaNs or infinities."
        }
    }

    public void testValueDoubleNegativeInfiniteRejectedWhenStrict() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.value(Double.NEGATIVE_INFINITY);
            fail("Expected IllegalArgumentException for non-finite double in strict mode");
        } catch (IllegalArgumentException expected) {
            // documented: "a finite value. May not be NaNs or infinities."
        }
    }

    public void testValueDoubleNaNAllowedWhenLenient() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setLenient(true);
        // lenient mode documents: "Numbers may be NaNs or infinities."
        jw.value(Double.NaN);
        assertTrue(sw.toString().length() > 0);
    }

    // ---- numeric values: long ----

    public void testValueLongPositive() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(42L);
        jw.endArray();
        assertEquals("[42]", sw.toString());
    }

    public void testValueLongNegative() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(-7L);
        jw.endArray();
        assertEquals("[-7]", sw.toString());
    }

    public void testValueLongZero() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(0L);
        jw.endArray();
        assertEquals("[0]", sw.toString());
    }

    public void testValueLongMaxBoundary() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(Long.MAX_VALUE);
        jw.endArray();
        assertEquals("[9223372036854775807]", sw.toString());
    }

    public void testValueLongMinBoundary() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(Long.MIN_VALUE);
        jw.endArray();
        assertEquals("[-9223372036854775808]", sw.toString());
    }

    // ---- numeric values: Number ----

    public void testValueNumberInteger() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(Integer.valueOf(42));
        jw.endArray();
        assertEquals("[42]", sw.toString());
    }

    public void testValueNumberNaNRejectedWhenStrict() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.value((Number) Double.valueOf(Double.NaN));
            fail("Expected IllegalArgumentException for non-finite Number in strict mode");
        } catch (IllegalArgumentException expected) {
            // documented: "a finite value. May not be NaNs or infinities."
        }
    }

    // ---- lenient mode: top-level scalars ----

    public void testDefaultIsLenientFalse() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        assertFalse(jw.isLenient());
    }

    public void testSetLenientTrueIsReflectedByIsLenient() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.setLenient(true);
        assertTrue(jw.isLenient());
        jw.setLenient(false);
        assertFalse(jw.isLenient());
    }

    public void pruned_testStrictModeRejectsTopLevelScalarValue() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        try {
            jw.value(5L);
            fail("Expected IllegalStateException: strict top-level value must be object or array");
        } catch (IllegalStateException expected) {
            // documented: "With strict writing, the top-level value must be an object or an array."
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        }
    }

    public void pruned_testStrictModeRejectsTopLevelNull() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        try {
            jw.nullValue();
            fail("Expected IllegalStateException: strict top-level value must be object or array");
        } catch (IllegalStateException expected) {
            // same rule applies to any top-level scalar, including null
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        }
    }

    public void testLenientModeAllowsTopLevelScalarValue() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setLenient(true);
        jw.value(5L);
        assertEquals("5", sw.toString());
    }

    public void testWriteAfterTopLevelObjectCompleteThrows() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        jw.endObject();
        try {
            jw.beginArray();
            fail("Expected IllegalStateException: only one top-level value permitted when strict");
        } catch (IllegalStateException expected) {
            // documented: "Each JSON document must contain one top-level array or object."
        }
    }

    // ---- malformed structure -> IllegalStateException ----

    public void testEndArrayWithoutBeginThrows() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        try {
            jw.endArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // no matching beginArray()
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        }
    }

    public void testEndObjectWithoutBeginThrows() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        try {
            jw.endObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // no matching beginObject()
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        }
    }

    public void testMismatchedEndArrayForOpenObjectThrows() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        try {
            jw.endArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // currently open scope is an object, not an array
        }
    }

    public void testMismatchedEndObjectForOpenArrayThrows() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.endObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // currently open scope is an array, not an object
        }
    }

    public void pruned_testNameOutsideObjectThrows() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        try {
            jw.name("a");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // no object context is open
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        }
    }

    public void pruned_testNameInsideArrayThrows() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.name("a");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // name() is only valid while encoding object properties
        }
    }

    public void testValueWithoutPrecedingNameInObjectThrows() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        try {
            jw.value("v");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // object property values must be preceded by name()
        }
    }

    public void testNameCalledTwiceInARowThrows() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        jw.name("a");
        try {
            jw.name("b");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // a value must follow a name(), not another name()
        }
    }

    public void testNameMayNotBeNull() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginObject();
        try {
            jw.name(null);
            fail("Expected NullPointerException: name may not be null");
        } catch (NullPointerException expected) {
            // documented: "May not be null."
        }
    }

    // ---- close()/flush() ----

    public void testCloseWithIncompleteDocumentThrowsIOException() throws IOException {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.beginArray();
        try {
            jw.close();
            fail("Expected IOException: incomplete JSON document");
        } catch (IOException expected) {
            // documented: "Throws: IOException - if the JSON document is incomplete."
        }
    }

    public void testCloseWithCompleteDocumentSucceeds() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.endArray();
        jw.close();
        assertEquals("[]", sw.toString());
    }

    public void testFlushDoesNotThrowOnHealthyWriter() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value(1L);
        jw.flush();
        assertEquals("[1", sw.toString());
    }

    public void testFlushPropagatesUnderlyingIOException() {
        JsonWriter jw = new JsonWriter(new FailingWriter());
        try {
            jw.flush();
            fail("Expected IOException to propagate from underlying Writer.flush()");
        } catch (IOException expected) {
            // documented: "Throws: IOException"
        }
    }

    public void testBeginArrayPropagatesUnderlyingIOException() {
        JsonWriter jw = new JsonWriter(new FailingWriter());
        try {
            jw.beginArray();
            fail("Expected IOException to propagate from underlying Writer.write()");
        } catch (IOException expected) {
            // documented: "Throws: IOException"
        }
    }

    // ---- htmlSafe ----

    public void testDefaultIsHtmlSafeFalse() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        assertFalse(jw.isHtmlSafe());
    }

    public void testSetHtmlSafeIsReflectedByIsHtmlSafe() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.setHtmlSafe(true);
        assertTrue(jw.isHtmlSafe());
        jw.setHtmlSafe(false);
        assertFalse(jw.isHtmlSafe());
    }

    public void testHtmlUnsafeDefaultLeavesSpecialCharactersRaw() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginArray();
        jw.value("<a>&b=c");
        jw.endArray();
        assertEquals("[\"<a>&b=c\"]", sw.toString());
    }

    public void testSetHtmlSafeTrueEscapesSpecialCharacters() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setHtmlSafe(true);
        jw.beginArray();
        jw.value("<a>&b=c");
        jw.endArray();
        String result = sw.toString();
        // documented: escapes <, >, & and = before writing them to the stream.
        assertTrue("must not contain raw '<'", result.indexOf('<') == -1);
        assertTrue("must not contain raw '>'", result.indexOf('>') == -1);
        assertTrue("must not contain raw '&'", result.indexOf('&') == -1);
        assertTrue("must not contain raw '='", result.indexOf('=') == -1);
    }

    // ---- serializeNulls ----

    public void testDefaultGetSerializeNullsTrue() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        assertTrue(jw.getSerializeNulls());
    }

    public void testSetSerializeNullsIsReflectedByGetSerializeNulls() {
        JsonWriter jw = new JsonWriter(new StringWriter());
        jw.setSerializeNulls(false);
        assertFalse(jw.getSerializeNulls());
        jw.setSerializeNulls(true);
        assertTrue(jw.getSerializeNulls());
    }

    public void testSerializeNullsTrueWritesNullObjectMember() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.beginObject();
        jw.name("a");
        jw.nullValue();
        jw.endObject();
        assertEquals("{\"a\":null}", sw.toString());
    }

    public void testSerializeNullsFalseSkipsNullObjectMember() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setSerializeNulls(false);
        jw.beginObject();
        jw.name("a");
        jw.nullValue();
        jw.endObject();
        // documented: "Sets whether object members are serialized when their value is null."
        assertEquals("{}", sw.toString());
    }

    public void testSerializeNullsFalseHasNoImpactOnArrayElements() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setSerializeNulls(false);
        jw.beginArray();
        jw.nullValue();
        jw.endArray();
        // documented: "This has no impact on array elements."
        assertEquals("[null]", sw.toString());
    }

    // ---- indentation ----

    public void testSetIndentEmptyProducesCompactOutput() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setIndent("");
        jw.beginObject();
        jw.name("a");
        jw.value(1L);
        jw.endObject();
        // documented: "If indent.isEmpty() the encoded document will be compact."
        assertEquals("{\"a\":1}", sw.toString());
    }

    public void testSetIndentNonEmptyProducesMoreReadableOutput() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        jw.setIndent("  ");
        jw.beginObject();
        jw.name("a");
        jw.value(1L);
        jw.endObject();
        String result = sw.toString();
        // documented: "Otherwise the encoded document will be more human-readable."
        assertTrue("expected a newline for readability", result.indexOf('\n') >= 0);
        assertTrue("expected the indent string to appear", result.indexOf("  \"a\"") >= 0);
        assertTrue(result.indexOf("\"a\"") >= 0);
        assertTrue(result.indexOf('1') >= 0);
    }

    // ---- integration: structure mirroring the class-level javadoc example ----

    public void testMessageLikeStructureFromJavadocExample() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.beginObject();
        writer.name("id").value(912345678901L);
        writer.name("text").value("How do I stream JSON in Java?");
        writer.name("geo").nullValue();
        writer.name("user");
        writer.beginObject();
        writer.name("name").value("json_newb");
        writer.name("followers_count").value(41L);
        writer.endObject();
        writer.endObject();
        writer.endArray();

        String expected = "[{\"id\":912345678901,\"text\":\"How do I stream JSON in Java?\","
                + "\"geo\":null,\"user\":{\"name\":\"json_newb\",\"followers_count\":41}}]";
        assertEquals(expected, sw.toString());
    }
}
