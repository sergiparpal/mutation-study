package org.apache.commons.lang3.builder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;

import org.junit.Test;

/**
 * Self-contained tests for {@link ToStringStyle}.
 *
 * <p>Expectations are derived from the generated javadoc: the class description
 * (detail vs. summary array handling), the documented example output of each
 * predefined constant, the serialized-form field documentation (which pins down
 * every default: {@code contentStart='['}, {@code nullText='<null>'},
 * {@code useClassName} default {@code true}, {@code useShortClassName} default
 * {@code false}, and so on), and the per-method contracts such as
 * "null is accepted, but will be converted to an empty String" and
 * "The default format is '&lt;size=n&gt;'".</p>
 */
public class ToStringStyleAgentTest {

    // ------------------------------------------------------------------
    // Fixtures (defined here so the test needs no external helpers)
    // ------------------------------------------------------------------

    /** Stand-in for the javadoc's {@code Person} example object. */
    public static class Person {
        public String name;
        public int age;
        public boolean smoker;
    }

    /**
     * Minimal concrete subclass. {@link ToStringStyle} is abstract with a
     * {@code protected} constructor and no abstract methods, so an empty body
     * is enough to exercise the inherited (and {@code protected}) API.
     */
    private static final class TestStyle extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    private static final String LS = System.lineSeparator();

    /** Reconstruct a toString the way {@code ToStringBuilder} drives the style. */
    private static String render(final ToStringStyle style, final Object target) {
        final StringBuffer sb = new StringBuffer();
        style.appendStart(sb, target);
        style.append(sb, "name", "John Doe", null);
        style.append(sb, "age", 33);
        style.append(sb, "smoker", false);
        style.appendEnd(sb, target);
        return sb.toString();
    }

    private static int count(final String haystack, final String needle) {
        int n = 0;
        int i = haystack.indexOf(needle);
        while (i >= 0) {
            n++;
            i = haystack.indexOf(needle, i + needle.length());
        }
        return n;
    }

    private static Object serializeRoundTrip(final Object obj) throws Exception {
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        final ObjectOutputStream out = new ObjectOutputStream(bytes);
        try {
            out.writeObject(obj);
        } finally {
            out.close();
        }
        final ObjectInputStream in =
                new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()));
        try {
            return in.readObject();
        } finally {
            in.close();
        }
    }

    // ------------------------------------------------------------------
    // Predefined singletons
    // ------------------------------------------------------------------

    @Test
    public void predefinedStylesAreNonNull() {
        assertNotNull(ToStringStyle.DEFAULT_STYLE);
        assertNotNull(ToStringStyle.MULTI_LINE_STYLE);
        assertNotNull(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertNotNull(ToStringStyle.SHORT_PREFIX_STYLE);
        assertNotNull(ToStringStyle.SIMPLE_STYLE);
    }

    @Test
    public void defaultStyleMatchesDocumentedShape() {
        // Documented: Person@182f0db[name=John Doe,age=33,smoker=false]
        final Person p = new Person();
        final String r = render(ToStringStyle.DEFAULT_STYLE, p);

        assertTrue(r, r.contains("name=John Doe"));
        assertTrue(r, r.contains("age=33"));
        assertTrue(r, r.contains("smoker=false"));
        assertTrue(r, r.contains("@"));                 // identity hash code
        assertTrue(r, r.indexOf("[") > 0);              // class-name prefix then '['
        assertTrue(r, r.endsWith("]"));
        assertTrue(r, r.contains("John Doe,age=33"));    // ',' separated
        assertTrue(r, r.contains("age=33,smoker=false"));
        assertTrue(r, r.indexOf("name=") < r.indexOf("age=")); // order preserved
        assertEquals(r, 0, count(r, LS));               // single line

        // No hidden per-call state: same target -> identical rendering.
        assertEquals(r, render(ToStringStyle.DEFAULT_STYLE, p));
    }

    @Test
    public void shortPrefixStyleDropsIdentityHashButKeepsFieldNames() {
        // Documented: Person[name=John Doe,age=33,smoker=false]
        final Person p = new Person();
        final String r = render(ToStringStyle.SHORT_PREFIX_STYLE, p);

        assertTrue(r, r.contains("[name=John Doe,age=33,smoker=false]"));
        assertTrue(r, r.endsWith("]"));

        final String prefix = r.substring(0, r.indexOf("["));
        assertFalse(r, prefix.isEmpty());
        assertFalse(r, prefix.contains("@"));           // no identity hash code
        assertFalse(r, r.equals(render(ToStringStyle.DEFAULT_STYLE, p)));
    }

    @Test
    public void noFieldNamesStyleOmitsFieldNames() {
        // Documented: Person@182f0db[John Doe,33,false]
        final Person p = new Person();
        final String r = render(ToStringStyle.NO_FIELD_NAMES_STYLE, p);

        assertTrue(r, r.contains("[John Doe,33,false]"));
        assertTrue(r, r.contains("@"));
        assertFalse(r, r.contains("name="));
        assertFalse(r, r.contains("age="));
        assertFalse(r, r.contains("smoker="));
    }

    @Test
    public void simpleStyleMatchesDocumentedOutputExactly() {
        // Documented: John Doe,33,false
        assertEquals("John Doe,33,false", render(ToStringStyle.SIMPLE_STYLE, new Person()));
    }

    @Test
    public void multiLineStyleSpansMultipleLines() {
        // Documented: Person@182f0db[ \n name=John Doe \n age=33 \n smoker=false \n ]
        final Person p = new Person();
        final String r = render(ToStringStyle.MULTI_LINE_STYLE, p);

        assertTrue(r, r.contains("name=John Doe"));
        assertTrue(r, r.contains(LS));
        assertTrue(r, r.endsWith(LS + "]"));
        assertTrue(r, count(r, LS) >= 3);
        assertFalse(r, r.equals(render(ToStringStyle.DEFAULT_STYLE, p)));
        assertEquals("multi-line style must not collapse to one line",
                0, count(render(ToStringStyle.DEFAULT_STYLE, p), LS));
    }

    @Test
    public void predefinedStylesDeserializeToTheSameSingleton() throws Exception {
        // "These classes are intended to be used as Singletons."
        assertSame(ToStringStyle.DEFAULT_STYLE, serializeRoundTrip(ToStringStyle.DEFAULT_STYLE));
        assertSame(ToStringStyle.SIMPLE_STYLE, serializeRoundTrip(ToStringStyle.SIMPLE_STYLE));
        assertSame(ToStringStyle.MULTI_LINE_STYLE, serializeRoundTrip(ToStringStyle.MULTI_LINE_STYLE));
        assertSame(ToStringStyle.NO_FIELD_NAMES_STYLE,
                serializeRoundTrip(ToStringStyle.NO_FIELD_NAMES_STYLE));
        assertSame(ToStringStyle.SHORT_PREFIX_STYLE,
                serializeRoundTrip(ToStringStyle.SHORT_PREFIX_STYLE));
    }

    // ------------------------------------------------------------------
    // append(...) primitive and Object overloads
    // ------------------------------------------------------------------

    @Test
    public void appendPrimitiveValuesRenderFieldNameAndValue() {
        final StringBuffer sb = new StringBuffer();
        final ToStringStyle s = ToStringStyle.DEFAULT_STYLE;
        s.append(sb, "bool", true);
        s.append(sb, "ch", 'x');
        s.append(sb, "by", (byte) 7);
        s.append(sb, "sh", (short) 8);
        s.append(sb, "in", 9);
        s.append(sb, "lo", 10L);
        s.append(sb, "fl", 1.5f);
        s.append(sb, "db", 2.5d);
        final String r = sb.toString();

        assertTrue(r, r.contains("bool=true"));
        assertTrue(r, r.contains("ch=x"));
        assertTrue(r, r.contains("by=7"));
        assertTrue(r, r.contains("sh=8"));
        assertTrue(r, r.contains("in=9"));
        assertTrue(r, r.contains("lo=10"));
        assertTrue(r, r.contains("fl=1.5"));
        assertTrue(r, r.contains("db=2.5"));
    }

    @Test
    public void appendNullObjectValueUsesNullText() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(sb, "x", (Object) null, null);
        assertTrue(sb.toString(), sb.toString().contains("x=<null>"));
    }

    @Test
    public void appendWithNullFieldNameOmitsTheName() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(sb, null, "val", null);
        final String r = sb.toString();
        assertTrue(r, r.contains("val"));
        assertFalse(r, r.contains("="));
    }

    // ------------------------------------------------------------------
    // Array append: detail lists elements, summary shows the size
    // ------------------------------------------------------------------

    @Test
    public void objectArrayFullDetailListsEveryElement() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(sb, "arr",
                new String[] {"a", "b", "c"}, Boolean.TRUE);
        final String r = sb.toString();

        assertTrue(r, r.contains("a,b,c"));
        assertFalse(r, r.contains("<size="));
    }

    @Test
    public void objectArraySummaryShowsSizeNotElements() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(sb, "arr",
                new String[] {"a", "b", "c"}, Boolean.FALSE);
        final String r = sb.toString();

        assertTrue(r, r.contains("<size=3>"));
        assertFalse(r, r.contains("a,b,c"));
    }

    @Test
    public void nullFullDetailFallsBackToStyleDefaultWhichIsDetail() {
        // DEFAULT_STYLE has defaultFullDetail == true, so null means "detail".
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(sb, "arr",
                new String[] {"a", "b", "c"}, null);
        final String r = sb.toString();

        assertTrue(r, r.contains("a,b,c"));
        assertFalse(r, r.contains("<size="));
    }

    @Test
    public void nullArrayUsesNullText() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(sb, "arr", (Object[]) null, Boolean.TRUE);
        assertTrue(sb.toString(), sb.toString().contains("arr=<null>"));
    }

    @Test
    public void primitiveArrayDetailAndSummary() {
        final StringBuffer detail = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(detail, "a", new int[] {1, 2, 3}, Boolean.TRUE);
        assertTrue(detail.toString(), detail.toString().contains("1,2,3"));
        assertFalse(detail.toString(), detail.toString().contains("<size="));

        final StringBuffer summary = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(summary, "a", new int[] {1, 2, 3}, Boolean.FALSE);
        assertTrue(summary.toString(), summary.toString().contains("<size=3>"));

        final StringBuffer bools = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(bools, "a", new boolean[] {true, false}, Boolean.TRUE);
        assertTrue(bools.toString(), bools.toString().contains("true"));
        assertTrue(bools.toString(), bools.toString().contains("false"));
    }

    // ------------------------------------------------------------------
    // Documented default configuration (serialized-form.html)
    // ------------------------------------------------------------------

    @Test
    public void freshStyleExposesDocumentedTextDefaults() {
        final TestStyle s = new TestStyle();
        assertEquals("[", s.getContentStart());
        assertEquals("]", s.getContentEnd());
        assertEquals(",", s.getFieldSeparator());
        assertEquals("=", s.getFieldNameValueSeparator());
        assertEquals("{", s.getArrayStart());
        assertEquals("}", s.getArrayEnd());
        assertEquals(",", s.getArraySeparator());
        assertEquals("<null>", s.getNullText());
        assertEquals("<size=", s.getSizeStartText());
        assertEquals(">", s.getSizeEndText());
        assertEquals("<", s.getSummaryObjectStartText());
        assertEquals(">", s.getSummaryObjectEndText());
    }

    @Test
    public void freshStyleExposesDocumentedFlagDefaults() {
        final TestStyle s = new TestStyle();
        assertTrue(s.isUseClassName());          // documented default true
        assertFalse(s.isUseShortClassName());    // documented default false
        assertTrue(s.isUseIdentityHashCode());   // documented default true
        assertTrue(s.isUseFieldNames());         // documented default true
        assertTrue(s.isDefaultFullDetail());     // documented default true
        assertFalse(s.isFieldSeparatorAtStart());
        assertFalse(s.isFieldSeparatorAtEnd());
        assertTrue(s.isArrayContentDetail());
    }

    // ------------------------------------------------------------------
    // Setter / getter round trips
    // ------------------------------------------------------------------

    @Test
    public void booleanFlagSettersRoundTrip() {
        final TestStyle s = new TestStyle();

        s.setUseClassName(false);
        assertFalse(s.isUseClassName());
        s.setUseClassName(true);
        assertTrue(s.isUseClassName());

        s.setUseShortClassName(true);
        assertTrue(s.isUseShortClassName());
        s.setUseShortClassName(false);
        assertFalse(s.isUseShortClassName());

        s.setUseIdentityHashCode(false);
        assertFalse(s.isUseIdentityHashCode());
        s.setUseIdentityHashCode(true);
        assertTrue(s.isUseIdentityHashCode());

        s.setUseFieldNames(false);
        assertFalse(s.isUseFieldNames());
        s.setUseFieldNames(true);
        assertTrue(s.isUseFieldNames());

        s.setDefaultFullDetail(false);
        assertFalse(s.isDefaultFullDetail());
        s.setDefaultFullDetail(true);
        assertTrue(s.isDefaultFullDetail());

        s.setArrayContentDetail(false);
        assertFalse(s.isArrayContentDetail());
        s.setArrayContentDetail(true);
        assertTrue(s.isArrayContentDetail());

        s.setFieldSeparatorAtStart(true);
        assertTrue(s.isFieldSeparatorAtStart());
        s.setFieldSeparatorAtStart(false);
        assertFalse(s.isFieldSeparatorAtStart());

        s.setFieldSeparatorAtEnd(true);
        assertTrue(s.isFieldSeparatorAtEnd());
        s.setFieldSeparatorAtEnd(false);
        assertFalse(s.isFieldSeparatorAtEnd());
    }

    @Test
    public void stringSettersRoundTripNonNullValues() {
        final TestStyle s = new TestStyle();
        s.setArrayStart("<A");
        assertEquals("<A", s.getArrayStart());
        s.setArrayEnd("A>");
        assertEquals("A>", s.getArrayEnd());
        s.setArraySeparator(" | ");
        assertEquals(" | ", s.getArraySeparator());
        s.setContentStart("<<");
        assertEquals("<<", s.getContentStart());
        s.setContentEnd(">>");
        assertEquals(">>", s.getContentEnd());
        s.setFieldNameValueSeparator(":");
        assertEquals(":", s.getFieldNameValueSeparator());
        s.setFieldSeparator(";");
        assertEquals(";", s.getFieldSeparator());
        s.setNullText("NULL");
        assertEquals("NULL", s.getNullText());
        s.setSizeStartText("[n=");
        assertEquals("[n=", s.getSizeStartText());
        s.setSizeEndText("]");
        assertEquals("]", s.getSizeEndText());
        s.setSummaryObjectStartText("(");
        assertEquals("(", s.getSummaryObjectStartText());
        s.setSummaryObjectEndText(")");
        assertEquals(")", s.getSummaryObjectEndText());
    }

    @Test
    public void stringSettersConvertNullToEmptyString() {
        // Every text setter documents: "null is accepted, but will be
        // converted to an empty String."
        final TestStyle s = new TestStyle();
        s.setArrayStart(null);
        assertEquals("", s.getArrayStart());
        s.setArrayEnd(null);
        assertEquals("", s.getArrayEnd());
        s.setArraySeparator(null);
        assertEquals("", s.getArraySeparator());
        s.setContentStart(null);
        assertEquals("", s.getContentStart());
        s.setContentEnd(null);
        assertEquals("", s.getContentEnd());
        s.setFieldNameValueSeparator(null);
        assertEquals("", s.getFieldNameValueSeparator());
        s.setFieldSeparator(null);
        assertEquals("", s.getFieldSeparator());
        s.setNullText(null);
        assertEquals("", s.getNullText());
        s.setSizeStartText(null);
        assertEquals("", s.getSizeStartText());
        s.setSizeEndText(null);
        assertEquals("", s.getSizeEndText());
        s.setSummaryObjectStartText(null);
        assertEquals("", s.getSummaryObjectStartText());
        s.setSummaryObjectEndText(null);
        assertEquals("", s.getSummaryObjectEndText());
    }

    // ------------------------------------------------------------------
    // protected append helpers
    // ------------------------------------------------------------------

    @Test
    public void appendContentStartAndEndUseConfiguredText() {
        final TestStyle s = new TestStyle();
        final StringBuffer sb = new StringBuffer();
        s.appendContentStart(sb);
        assertEquals("[", sb.toString());
        s.appendContentEnd(sb);
        assertEquals("[]", sb.toString());
    }

    @Test
    public void appendFieldSeparatorUsesConfiguredText() {
        final TestStyle s = new TestStyle();
        final StringBuffer sb = new StringBuffer();
        s.appendFieldSeparator(sb);
        assertEquals(",", sb.toString());
        s.setFieldSeparator(" ~ ");
        s.appendFieldSeparator(sb);
        assertEquals(", ~ ", sb.toString());
    }

    @Test
    public void appendFieldStartHonoursUseFieldNamesAndNullName() {
        final TestStyle s = new TestStyle();

        final StringBuffer withName = new StringBuffer();
        s.appendFieldStart(withName, "field");
        assertEquals("field=", withName.toString());

        final StringBuffer nullName = new StringBuffer();
        s.appendFieldStart(nullName, null);
        assertEquals("", nullName.toString());

        s.setUseFieldNames(false);
        final StringBuffer noNames = new StringBuffer();
        s.appendFieldStart(noNames, "field");
        assertEquals("", noNames.toString());
    }

    @Test
    public void appendFieldEndAppendsSeparator() {
        final TestStyle s = new TestStyle();
        final StringBuffer sb = new StringBuffer("value");
        s.appendFieldEnd(sb, "field");
        assertEquals("value,", sb.toString());
    }

    @Test
    public void appendNullTextUsesDefaultThenConfiguredIndicator() {
        final TestStyle s = new TestStyle();
        final StringBuffer sb = new StringBuffer();
        s.appendNullText(sb, "field");
        assertEquals("<null>", sb.toString());          // documented default

        s.setNullText("NIL");
        final StringBuffer sb2 = new StringBuffer();
        s.appendNullText(sb2, "field");
        assertEquals("NIL", sb2.toString());
    }

    @Test
    public void appendSummarySizeUsesDefaultFormat() {
        // Documented: "The default format is '<size=n>'."
        final TestStyle s = new TestStyle();

        final StringBuffer five = new StringBuffer();
        s.appendSummarySize(five, "field", 5);
        assertEquals("<size=5>", five.toString());

        final StringBuffer zero = new StringBuffer();
        s.appendSummarySize(zero, "field", 0);
        assertEquals("<size=0>", zero.toString());
    }

    @Test
    public void removeLastFieldSeparatorStripsOnlyATrailingSeparator() {
        final TestStyle s = new TestStyle();

        final StringBuffer trailing = new StringBuffer("a=1,b=2,");
        s.removeLastFieldSeparator(trailing);
        assertEquals("a=1,b=2", trailing.toString());

        final StringBuffer none = new StringBuffer("a=1,b=2");
        s.removeLastFieldSeparator(none);
        assertEquals("a=1,b=2", none.toString());

        final StringBuffer empty = new StringBuffer();
        s.removeLastFieldSeparator(empty);
        assertEquals("", empty.toString());
    }

    // ------------------------------------------------------------------
    // appendClassName / appendIdentityHashCode / getShortClassName
    // ------------------------------------------------------------------

    @Test
    public void appendClassNameRespectsUseClassNameAndShortName() {
        final TestStyle s = new TestStyle();

        final Object a = new Object();
        final StringBuffer longName = new StringBuffer();
        s.appendClassName(longName, a);
        assertEquals("java.lang.Object", longName.toString());
        ToStringStyle.unregister(a);

        s.setUseShortClassName(true);
        final Object b = new Object();
        final StringBuffer shortName = new StringBuffer();
        s.appendClassName(shortName, b);
        assertEquals("Object", shortName.toString());
        ToStringStyle.unregister(b);

        s.setUseClassName(false);
        final StringBuffer disabled = new StringBuffer();
        s.appendClassName(disabled, new Object());
        assertEquals("", disabled.toString());

        s.setUseClassName(true);
        final StringBuffer nullObject = new StringBuffer();
        s.appendClassName(nullObject, null);
        assertEquals("", nullObject.toString());
    }

    @Test
    public void appendIdentityHashCodeRespectsFlagAndNull() {
        final TestStyle s = new TestStyle();

        final Object o = new Object();
        final StringBuffer sb = new StringBuffer();
        s.appendIdentityHashCode(sb, o);
        assertEquals("@" + Integer.toHexString(System.identityHashCode(o)), sb.toString());
        ToStringStyle.unregister(o);

        s.setUseIdentityHashCode(false);
        final StringBuffer disabled = new StringBuffer();
        s.appendIdentityHashCode(disabled, new Object());
        assertEquals("", disabled.toString());

        s.setUseIdentityHashCode(true);
        final StringBuffer nullObject = new StringBuffer();
        s.appendIdentityHashCode(nullObject, null);
        assertEquals("", nullObject.toString());
    }

    @Test
    public void getShortClassNameStripsThePackage() {
        final TestStyle s = new TestStyle();
        assertEquals("String", s.getShortClassName(String.class));
        assertEquals("Integer", s.getShortClassName(Integer.class));
        assertEquals("Object", s.getShortClassName(Object.class));
    }

    // ------------------------------------------------------------------
    // isFullDetail
    // ------------------------------------------------------------------

    @Test
    public void isFullDetailUsesRequestThenFallsBackToDefault() {
        final TestStyle s = new TestStyle();

        s.setDefaultFullDetail(true);
        assertTrue(s.isFullDetail(null));               // null -> default
        assertTrue(s.isFullDetail(Boolean.TRUE));
        assertFalse(s.isFullDetail(Boolean.FALSE));

        s.setDefaultFullDetail(false);
        assertFalse(s.isFullDetail(null));              // null -> default
        assertTrue(s.isFullDetail(Boolean.TRUE));
        assertFalse(s.isFullDetail(Boolean.FALSE));
    }

    // ------------------------------------------------------------------
    // appendSuper / appendToString
    // ------------------------------------------------------------------

    @Test
    public void appendSuperIgnoresNull() {
        final StringBuffer sb = new StringBuffer("existing");
        ToStringStyle.DEFAULT_STYLE.appendSuper(sb, null);
        assertEquals("existing", sb.toString());
    }

    @Test
    public void appendToStringIgnoresNull() {
        final StringBuffer sb = new StringBuffer("existing");
        ToStringStyle.DEFAULT_STYLE.appendToString(sb, null);
        assertEquals("existing", sb.toString());
    }

    @Test
    public void appendToStringIgnoresStringsWithoutFieldContent() {
        final StringBuffer noMarkers = new StringBuffer("keep");
        ToStringStyle.DEFAULT_STYLE.appendToString(noMarkers, "");
        assertEquals("keep", noMarkers.toString());

        final StringBuffer emptyContent = new StringBuffer("keep");
        ToStringStyle.DEFAULT_STYLE.appendToString(emptyContent, "Foo[]");
        assertEquals("keep", emptyContent.toString());
    }

    @Test
    public void appendSuperAppendsTheInnerFieldContent() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendSuper(sb, "Super@1a2b[a=1,b=2]");
        assertTrue(sb.toString(), sb.toString().contains("a=1,b=2"));
    }

    @Test
    public void appendToStringAppendsTheInnerFieldContent() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendToString(sb, "Foo@1[x=7,y=8]");
        assertTrue(sb.toString(), sb.toString().contains("x=7,y=8"));
    }

    // ------------------------------------------------------------------
    // Registry: register / isRegistered / unregister / getRegistry
    // ------------------------------------------------------------------

    @Test
    public void registryLifecycle() {
        final Object o = new Object();
        assertFalse(ToStringStyle.isRegistered(o));

        ToStringStyle.register(o);
        assertTrue(ToStringStyle.isRegistered(o));

        final Map<Object, Object> registry = ToStringStyle.getRegistry();
        assertNotNull(registry);
        assertTrue(registry.containsKey(o));

        ToStringStyle.unregister(o);
        assertFalse(ToStringStyle.isRegistered(o));
    }

    @Test
    public void isRegisteredIsFalseForAnUnknownObject() {
        assertFalse(ToStringStyle.isRegistered(new Object()));
    }

    @Test
    public void appendStartRegistersTargetAndAppendEndUnregistersIt() {
        final Person p = new Person();
        final StringBuffer sb = new StringBuffer();

        assertFalse(ToStringStyle.isRegistered(p));
        ToStringStyle.DEFAULT_STYLE.appendStart(sb, p);
        assertTrue(ToStringStyle.isRegistered(p));
        ToStringStyle.DEFAULT_STYLE.appendEnd(sb, p);
        assertFalse(ToStringStyle.isRegistered(p));
    }

    @Test
    public void appendStartWithNullObjectAppendsNothing() {
        final StringBuffer sb = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendStart(sb, null);
        assertEquals("", sb.toString());
    }
}
