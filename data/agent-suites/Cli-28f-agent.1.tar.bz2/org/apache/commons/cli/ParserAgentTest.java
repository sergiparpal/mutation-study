/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Tests for the public API of the abstract {@link Parser} class.
 *
 * <p>Because <code>Parser</code> is abstract, the tests exercise it through a
 * minimal concrete subclass whose <code>flatten</code> implementation simply
 * echoes the arguments it is given (the same strategy used by
 * <code>BasicParser</code>).  This keeps the focus on the token processing,
 * properties handling and required-option checking that <code>Parser</code>
 * itself provides.</p>
 */
public class ParserAgentTest extends TestCase
{
    /** Minimal concrete Parser used to drive the tests. */
    private static final class StubParser extends Parser
    {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption)
        {
            // echo the arguments unchanged
            return arguments;
        }
    }

    private Parser parser;

    private Options options;

    public void setUp()
    {
        parser = new StubParser();
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");
    }

    // ------------------------------------------------------------------
    // parse(Options, String[])
    // ------------------------------------------------------------------

    public void testParseSimpleShortOptions() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a", "-b", "toast", "foo", "bar" });

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-b should be set", cl.hasOption("b"));
        assertFalse("-c should not be set", cl.hasOption("c"));
        assertEquals("value of -b", "toast", cl.getOptionValue("b"));

        List argList = cl.getArgList();
        assertEquals("number of extra arguments", 2, argList.size());
        assertEquals("foo", argList.get(0));
        assertEquals("bar", argList.get(1));
        assertEquals("getArgs() must agree with getArgList()", 2, cl.getArgs().length);
    }

    public void testParseReturnsEmptyCommandLineForNoArgs() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertNotNull("parse must return a CommandLine", cl);
        assertEquals("no options expected", 0, cl.getOptions().length);
        assertEquals("no arguments expected", 0, cl.getArgs().length);
        assertFalse(cl.hasOption("a"));
    }

    public void testParseNullArgumentsTreatedAsEmpty() throws Exception
    {
        CommandLine cl = parser.parse(options, (String[]) null);

        assertNotNull("null arguments must not blow up", cl);
        assertEquals(0, cl.getArgs().length);
        assertEquals(0, cl.getOptions().length);
    }

    public void testParseUnrecognizedOptionThrows() throws Exception
    {
        try
        {
            parser.parse(options, new String[] { "-a", "-d" });
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-d", e.getOption());
        }
    }

    public void testParseMissingArgumentThrows() throws Exception
    {
        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertNotNull("the failing option must be reported", e.getOption());
            assertEquals("b", e.getOption().getOpt());
        }
    }

    public void testParseSingleDashTreatedAsArgument() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a", "-", "foo" });

        assertTrue("-a should be set", cl.hasOption("a"));

        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("-", argList.get(0));
        assertEquals("foo", argList.get(1));
    }

    public void testParseDoubleDashStopsOptionParsing() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a", "--", "-b", "toast" });

        assertTrue("-a should be set", cl.hasOption("a"));
        assertFalse("-b after -- must be treated as an argument", cl.hasOption("b"));

        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("-b", argList.get(0));
        assertEquals("toast", argList.get(1));
        assertFalse("-- itself must not be kept as an argument", argList.contains("--"));
    }

    // ------------------------------------------------------------------
    // parse(Options, String[], boolean)
    // ------------------------------------------------------------------

    public void testParseStopAtNonOptionKeepsUnknownOptionAsArgument() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a", "-d", "-b", "toast" }, true);

        assertTrue("-a should be set", cl.hasOption("a"));
        assertFalse("parsing must stop before -b", cl.hasOption("b"));

        List argList = cl.getArgList();
        assertEquals(3, argList.size());
        assertEquals("-d", argList.get(0));
        assertEquals("-b", argList.get(1));
        assertEquals("toast", argList.get(2));
    }

    public void testParseStopAtNonOptionStopsAtFirstBareArgument() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "foo", "-a" }, true);

        assertFalse("-a after a bare argument must not be parsed", cl.hasOption("a"));

        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("foo", argList.get(0));
        assertEquals("-a", argList.get(1));
    }

    public void testParseSingleDashWithStopAtNonOption() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a", "-", "-b" }, true);

        assertTrue("-a should be set", cl.hasOption("a"));
        assertFalse("-b must not be parsed after a lone dash", cl.hasOption("b"));

        List argList = cl.getArgList();
        assertEquals(1, argList.size());
        assertEquals("-b", argList.get(0));
    }

    public void testParseWithoutStopAtNonOptionKeepsParsingOptions() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "foo", "-a" }, false);

        assertTrue("-a following a bare argument is still parsed", cl.hasOption("a"));

        List argList = cl.getArgList();
        assertEquals(1, argList.size());
        assertEquals("foo", argList.get(0));
    }

    // ------------------------------------------------------------------
    // parse(Options, String[], Properties)
    // ------------------------------------------------------------------

    public void testParseWithPropertiesSetsOptionValue() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("b", "from-props");

        CommandLine cl = parser.parse(options, new String[] { "-a" }, props);

        assertTrue("-a from the command line", cl.hasOption("a"));
        assertTrue("-b from the properties", cl.hasOption("b"));
        assertEquals("from-props", cl.getOptionValue("b"));
    }

    public void testParseWithPropertiesSetsFlagsWhenAffirmative() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("a", "true");
        props.setProperty("c", "yes");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertTrue("'true' must enable the flag", cl.hasOption("a"));
        assertTrue("'yes' must enable the flag", cl.hasOption("c"));
    }

    public void testParseWithPropertiesIgnoresFlagWhenNotAffirmative() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("a", "false");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertFalse("a flag set to 'false' must not be added", cl.hasOption("a"));
        assertEquals(0, cl.getOptions().length);
    }

    public void testParseCommandLineTakesPrecedenceOverProperties() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("b", "from-props");

        CommandLine cl = parser.parse(options, new String[] { "-b", "from-cli" }, props);

        assertEquals("command line value must win", "from-cli", cl.getOptionValue("b"));
        assertEquals("no extra value must be appended from the properties",
                     1, cl.getOptionValues("b").length);
    }

    public void testParseWithNullPropertiesBehavesLikePlainParse() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a" }, (Properties) null);

        assertTrue(cl.hasOption("a"));
        assertFalse(cl.hasOption("b"));
    }

    // ------------------------------------------------------------------
    // parse(Options, String[], Properties, boolean)
    // ------------------------------------------------------------------

    public void testParseFourArgOverloadWithPropertiesAndStopAtNonOption() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("a", "true");

        CommandLine cl = parser.parse(options,
                new String[] { "-b", "toast", "extra", "-c" }, props, true);

        assertTrue("-b parsed from the command line", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertTrue("-a injected from the properties", cl.hasOption("a"));
        assertFalse("-c is past the first bare argument", cl.hasOption("c"));

        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("extra", argList.get(0));
        assertEquals("-c", argList.get(1));
    }

    // ------------------------------------------------------------------
    // required options
    // ------------------------------------------------------------------

    public void testParseMissingRequiredOptionThrows() throws Exception
    {
        Options opts = new Options();
        opts.addOption("a", "enable-a", false, null);
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));

        try
        {
            parser.parse(opts, new String[] { "-a" });
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: b", e.getMessage());
            assertTrue(e.getMissingOptions().contains("b"));
        }
    }

    public void testParseWithRequiredOptionPresent() throws Exception
    {
        Options opts = new Options();
        opts.addOption("a", "enable-a", false, null);
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));

        CommandLine cl = parser.parse(opts, new String[] { "-b", "file" });

        assertFalse("-a is NOT set", cl.hasOption("a"));
        assertTrue("-b is set", cl.hasOption("b"));
        assertEquals("file", cl.getOptionValue("b"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testParseTwoMissingRequiredOptionsReportsBoth() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));
        opts.addOption(OptionBuilder.withLongOpt("cfile").hasArg().isRequired().create('c'));

        try
        {
            parser.parse(opts, new String[0]);
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required options: b, c", e.getMessage());
            assertTrue(e.getMissingOptions().contains("b"));
            assertTrue(e.getMissingOptions().contains("c"));
        }
    }

    // ------------------------------------------------------------------
    // state that must be reset between successive parse() calls
    // ------------------------------------------------------------------

    public void testParseTwiceClearsPreviousValues() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArg().create("b"));

        CommandLine first = parser.parse(opts, new String[] { "-b", "one" });
        assertEquals("one", first.getOptionValue("b"));

        CommandLine second = parser.parse(opts, new String[] { "-b", "two" });
        assertEquals("stale value from the first parse must be cleared",
                     "two", second.getOptionValue("b"));
        assertEquals(1, second.getOptionValues("b").length);
    }

    public void testParseWithReusedRequiredOptionsFailsSecondTime() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().create('v'));

        parser.parse(opts, new String[] { "-v" });

        try
        {
            parser.parse(opts, new String[0]);
            fail("MissingOptionException expected on the second parse");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMissingOptions().contains("v"));
        }
    }

    public void testParseResetsOptionGroupBetweenCalls() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("c"));

        Options opts = new Options();
        opts.addOptionGroup(group);

        parser.parse(opts, new String[] { "-a" });
        assertEquals("a", group.getSelected());

        parser.parse(opts, new String[] { "-c" });
        assertEquals("group selection must be reset on the second parse",
                     "c", group.getSelected());
    }

    public void testParseThrowsWhenTwoOptionsFromSameGroup() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("c"));

        Options opts = new Options();
        opts.addOptionGroup(group);

        try
        {
            parser.parse(opts, new String[] { "-a", "-c" });
            fail("AlreadySelectedException expected");
        }
        catch (AlreadySelectedException e)
        {
            assertEquals("c", e.getOption().getOpt());
            assertSame(group, e.getOptionGroup());
        }
    }

    // ------------------------------------------------------------------
    // processArgs(Option, ListIterator)
    // ------------------------------------------------------------------

    public void testProcessArgsConsumesSingleValue() throws Exception
    {
        parser.parse(new Options(), new String[0]);

        Option opt = OptionBuilder.hasArg().create("x");
        List tokens = Arrays.asList(new String[] { "value1" });
        ListIterator it = tokens.listIterator();

        parser.processArgs(opt, it);

        assertEquals("value1", opt.getValue());
        assertFalse("iterator should be exhausted", it.hasNext());
    }

    public void testProcessArgsStripsQuotesFromValue() throws Exception
    {
        parser.parse(new Options(), new String[0]);

        Option opt = OptionBuilder.hasArg().create("x");
        List tokens = Arrays.asList(new String[] { "\"quoted\"" });

        parser.processArgs(opt, tokens.listIterator());

        assertEquals("quoted", opt.getValue());
    }

    public void testProcessArgsStopsAtKnownOptionAndThrowsForMissingArg() throws Exception
    {
        Options opts = new Options();
        opts.addOption("a", false, "flag a");
        parser.parse(opts, new String[0]);

        Option opt = OptionBuilder.hasArg().create("x");
        List tokens = Arrays.asList(new String[] { "-a" });
        ListIterator it = tokens.listIterator();

        try
        {
            parser.processArgs(opt, it);
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("x", e.getOption().getOpt());
        }

        assertNull("no value should have been consumed", opt.getValues());
        assertEquals("the option token must be pushed back", 0, it.nextIndex());
        assertEquals("-a", it.next());
    }

    public void testProcessArgsDoesNotThrowForOptionalArg() throws Exception
    {
        parser.parse(new Options(), new String[0]);

        Option opt = OptionBuilder.hasOptionalArg().create("x");
        List tokens = Arrays.asList(new String[0]);

        parser.processArgs(opt, tokens.listIterator());

        assertNull("an optional argument may legitimately be absent", opt.getValues());
    }

    public void testProcessArgsStopsWhenOptionCannotAcceptMoreValues() throws Exception
    {
        parser.parse(new Options(), new String[0]);

        Option opt = OptionBuilder.hasArg().create("x");
        List tokens = Arrays.asList(new String[] { "v1", "v2" });
        ListIterator it = tokens.listIterator();

        parser.processArgs(opt, it);

        assertEquals("v1", opt.getValue());
        assertEquals(1, opt.getValues().length);
        assertTrue("the surplus token must remain on the iterator", it.hasNext());
        assertEquals("v2", it.next());
    }
}
