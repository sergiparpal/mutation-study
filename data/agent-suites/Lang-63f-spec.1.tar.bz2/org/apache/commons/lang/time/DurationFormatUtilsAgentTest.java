package org.apache.commons.lang.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 *
 * <p>Every expectation here is derived from the published javadoc (api/): the token
 * table ({@code y M d H m s S}), the statement that the {@code formatDuration*} family
 * "formats durations using the days and lower fields ... Months and larger are not used",
 * the "padding with zeros" wording of the two-argument {@code formatDuration}, the ISO
 * examples for {@code formatDurationISO}/{@code formatPeriodISO}, the documented value of
 * {@code ISO_EXTENDED_FORMAT_PATTERN}, and the "plurialization correct" contract of
 * {@code formatDurationWords}. Where the javadoc is silent the tests assert only what the
 * contract implies (structure, cross-method consistency) rather than guessing internals.</p>
 */
public class DurationFormatUtilsAgentTest {

    private static final long SEC = 1000L;
    private static final long MIN = 60L * SEC;
    private static final long HOUR = 60L * MIN;
    private static final long DAY = 24L * HOUR;

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    /** Midnight of the given calendar date, in GMT, as epoch millis. */
    private static long gmtMillis(int year, int month, int day) {
        Calendar c = Calendar.getInstance(GMT);
        c.clear();
        c.set(year, month, day, 0, 0, 0);
        return c.getTimeInMillis();
    }

    // ------------------------------------------------------------------
    // constructor
    // ------------------------------------------------------------------

    @Test
    public void constructorIsPublicAndUsable() {
        // The javadoc states the constructor is public purely so bean tools can
        // instantiate it; it must therefore succeed and yield an object.
        assertNotNull(new DurationFormatUtils());
    }

    // ------------------------------------------------------------------
    // ISO_EXTENDED_FORMAT_PATTERN
    // ------------------------------------------------------------------

    @Test
    public void isoExtendedFormatPatternConstantValue() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.S'S'",
                DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    @Test
    public void isoExtendedFormatPatternIsAValidSimpleDateFormatPattern() {
        // The field javadoc says this pattern is "used with FastDateFormat and
        // SimpleDateFormat" -> constructing a SimpleDateFormat with it must not throw
        // and the surrounding literals ('P' ... 'S') must survive formatting.
        SimpleDateFormat sdf = new SimpleDateFormat(DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
        String out = sdf.format(new Date(0L));
        assertNotNull(out);
        assertTrue("expected literal 'P' prefix, was: " + out, out.startsWith("P"));
        assertTrue("expected literal 'S' suffix, was: " + out, out.endsWith("S"));
        assertTrue("expected the 'DT' literal, was: " + out, out.contains("DT"));
    }

    // ------------------------------------------------------------------
    // formatDurationHMS
    // ------------------------------------------------------------------

    @Test
    public void formatDurationHMSZero() {
        // javadoc: format is ISO8601-like "H:m:s.S"
        assertEquals("0:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
    }

    @Test
    public void formatDurationHMSKnownValues() {
        assertEquals("0:00:00.001", DurationFormatUtils.formatDurationHMS(1L));
        assertEquals("0:00:01.000", DurationFormatUtils.formatDurationHMS(SEC));
        assertEquals("0:01:01.000", DurationFormatUtils.formatDurationHMS(61L * SEC));
        assertEquals("1:00:00.000", DurationFormatUtils.formatDurationHMS(HOUR));
        assertEquals("1:02:03.004",
                DurationFormatUtils.formatDurationHMS(HOUR + 2L * MIN + 3L * SEC + 4L));
        assertEquals("10:00:00.000", DurationFormatUtils.formatDurationHMS(10L * HOUR));
    }

    @Test
    public void formatDurationHMSAccumulatesHoursBeyondOneDay() {
        // The H:m:s.S layout has no day field, so the hours element must carry the
        // whole elapsed span rather than wrapping at 24.
        assertEquals("24:00:00.000", DurationFormatUtils.formatDurationHMS(DAY));
        assertEquals("25:00:00.000", DurationFormatUtils.formatDurationHMS(DAY + HOUR));
        assertEquals("48:00:00.000", DurationFormatUtils.formatDurationHMS(2L * DAY));
    }

    @Test
    public void formatDurationHMSAlwaysHasHoursMinutesSecondsShape() {
        long[] values = { 0L, 1L, SEC, MIN, HOUR, DAY, 12345678L };
        for (long v : values) {
            String s = DurationFormatUtils.formatDurationHMS(v);
            assertNotNull(s);
            assertTrue("unexpected shape for " + v + ": " + s,
                    s.matches("\\d{1,2}:\\d{2}:\\d{2}\\.\\d{3}"));
        }
    }

    // ------------------------------------------------------------------
    // formatDurationISO
    // ------------------------------------------------------------------

    @Test
    public void formatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    @Test
    public void formatDurationISOKnownValue() {
        long span = DAY + 3L * HOUR + 4L * MIN + 5L * SEC + 6L;
        assertEquals("P0Y0M1DT3H4M5.006S", DurationFormatUtils.formatDurationISO(span));
    }

    @Test
    public void formatDurationISOMatchesTheIsoExtendedPattern() {
        // The javadoc says formatDurationISO "uses the ISO8601 period format"; that is
        // exactly ISO_EXTENDED_FORMAT_PATTERN, so its output must equal a formatDuration
        // call with that pattern (whichever padding flavour the method chose).
        long span = DAY + 3L * HOUR + 4L * MIN + 5L * SEC + 6L;
        long[] values = { 0L, SEC, span, 1234567L };
        for (long v : values) {
            String iso = DurationFormatUtils.formatDurationISO(v);
            String unpadded = DurationFormatUtils.formatDuration(
                    v, DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN, false);
            String padded = DurationFormatUtils.formatDuration(
                    v, DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN, true);
            assertTrue("ISO output for " + v + " (" + iso
                            + ") should match the ISO extended pattern",
                    iso.equals(unpadded) || iso.equals(padded));
        }
    }

    @Test
    public void formatDurationISOShape() {
        String s = DurationFormatUtils.formatDurationISO(1234567L);
        assertTrue(s, s.startsWith("P"));
        assertTrue(s, s.endsWith("S"));
        assertTrue(s, s.contains("DT"));
        assertTrue(s, s.matches("P\\d+Y\\d+M\\d+DT\\d+H\\d+M\\d+\\.\\d{3}S"));
    }

    // ------------------------------------------------------------------
    // formatPeriodISO
    // ------------------------------------------------------------------

    @Test
    public void formatPeriodISOZeroSpan() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(0L, 0L));
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(1000L, 1000L));
    }

    @Test
    public void formatPeriodISOShape() {
        long end = DAY + 3L * HOUR + 4L * MIN + 5L * SEC + 6L;
        String s = DurationFormatUtils.formatPeriodISO(0L, end);
        // Span is well under a month, so the year and month elements must be zero.
        assertTrue(s, s.startsWith("P0Y0M"));
        assertTrue(s, s.endsWith("S"));
        assertTrue(s, s.contains("DT"));
        assertTrue(s, s.matches("P0Y0M\\d+DT\\d+H\\d+M\\d+\\.\\d{3}S"));
    }

    // ------------------------------------------------------------------
    // formatDuration(long, String)
    // ------------------------------------------------------------------

    @Test
    public void formatDurationLargestTokenCarriesTheWholeDuration() {
        long twoHours = 2L * HOUR;
        assertEquals("7200000", DurationFormatUtils.formatDuration(twoHours, "S"));
        assertEquals("7200", DurationFormatUtils.formatDuration(twoHours, "s"));
        assertEquals("120", DurationFormatUtils.formatDuration(twoHours, "m"));
        assertEquals("2", DurationFormatUtils.formatDuration(twoHours, "H"));
        assertEquals("0", DurationFormatUtils.formatDuration(twoHours, "d"));
        assertEquals("2", DurationFormatUtils.formatDuration(2L * DAY, "d"));
        assertEquals("0", DurationFormatUtils.formatDuration(0L, "d"));
    }

    @Test
    public void formatDurationPadsEachTokenToItsWidthWithZeros() {
        // Two-arg overload: javadoc says it pads with zeros.
        assertEquals("0", DurationFormatUtils.formatDuration(0L, "S"));
        assertEquals("0000", DurationFormatUtils.formatDuration(0L, "SSSS"));
        assertEquals("0003", DurationFormatUtils.formatDuration(3L, "SSSS"));
        assertEquals("00", DurationFormatUtils.formatDuration(0L, "dd"));
    }

    @Test
    public void formatDurationCompositePattern() {
        long d = DAY + 2L * HOUR + 3L * MIN + 4L * SEC + 5L;
        assertEquals("1:02:03:04.005",
                DurationFormatUtils.formatDuration(d, "d:HH:mm:ss.SSS"));
        assertEquals("1234.567", DurationFormatUtils.formatDuration(1234567L, "s.SSS"));
    }

    @Test
    public void formatDurationIgnoresMonthsAndLargerFields() {
        // javadoc: "Months and larger are not used."
        long bigDuration = 500L * DAY;
        assertEquals("0", DurationFormatUtils.formatDuration(bigDuration, "y"));
        assertEquals("0", DurationFormatUtils.formatDuration(bigDuration, "M"));
        assertEquals("500", DurationFormatUtils.formatDuration(bigDuration, "d"));
        assertEquals("0-0-500", DurationFormatUtils.formatDuration(bigDuration, "y-M-d"));
    }

    @Test
    public void formatDurationPreservesLiteralText() {
        // Bare non-token characters and quoted literals both pass straight through.
        assertEquals("2 hours", DurationFormatUtils.formatDuration(2L * HOUR, "H' hours'"));
        assertEquals("0-0", DurationFormatUtils.formatDuration(0L, "H-m"));
        assertEquals("0:00", DurationFormatUtils.formatDuration(0L, "H:mm"));
    }

    @Test
    public void formatDurationEmptyPatternProducesEmptyString() {
        assertEquals("", DurationFormatUtils.formatDuration(0L, ""));
        assertEquals("", DurationFormatUtils.formatDuration(123456L, ""));
    }

    @Test
    public void formatDurationDropsUnitsBelowTheSmallestToken() {
        long t = HOUR + 30L * MIN + 45L * SEC + 123L;
        assertEquals("1:30:45", DurationFormatUtils.formatDuration(t, "H:mm:ss"));
        assertEquals("1:30", DurationFormatUtils.formatDuration(t, "H:mm"));
        assertEquals("1234", DurationFormatUtils.formatDuration(1234567L, "s"));
    }

    @Test
    public void formatDurationRejectsNullPattern() {
        // The contract is silent, but there is no defined result for a null pattern:
        // it cannot be lexed, so a NullPointerException is the only sensible outcome.
        try {
            DurationFormatUtils.formatDuration(1000L, null);
            fail("expected NullPointerException for a null format");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // ------------------------------------------------------------------
    // formatDuration(long, String, boolean)
    // ------------------------------------------------------------------

    @Test
    public void formatDurationPadFlagControlsLeadingZeros() {
        long t = HOUR + 5L * MIN;
        assertEquals("1:05", DurationFormatUtils.formatDuration(t, "H:mm", true));
        assertEquals("1:5", DurationFormatUtils.formatDuration(t, "H:mm", false));
        assertEquals("00", DurationFormatUtils.formatDuration(0L, "mm", true));
        assertEquals("0", DurationFormatUtils.formatDuration(0L, "mm", false));
    }

    @Test
    public void formatDurationTwoArgEqualsThreeArgWithPaddingOn() {
        // The two-arg overload is documented as "padding with zeros", i.e. the
        // three-arg overload with padWithZeros == true.
        long[] samples = { 0L, 1L, SEC, MIN, HOUR, DAY, 1234567L,
                HOUR + 2L * MIN + 3L * SEC + 4L };
        String[] formats = { "S", "s", "m", "H", "d", "mm",
                "H:mm:ss.SSS", "d:HH:mm:ss.SSS" };
        for (long s : samples) {
            for (String f : formats) {
                assertEquals("millis=" + s + " format=" + f,
                        DurationFormatUtils.formatDuration(s, f),
                        DurationFormatUtils.formatDuration(s, f, true));
            }
        }
    }

    // ------------------------------------------------------------------
    // formatDurationWords
    // ------------------------------------------------------------------

    @Test
    public void formatDurationWordsWithoutSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(0L, false, false));
        assertEquals("0 days 0 hours 0 minutes 50 seconds",
                DurationFormatUtils.formatDurationWords(50L * SEC, false, false));
        assertEquals("1 day 1 hour 1 minute 1 second",
                DurationFormatUtils.formatDurationWords(DAY + HOUR + MIN + SEC, false, false));
    }

    @Test
    public void formatDurationWordsSuppressesLeadingZeroElements() {
        assertEquals("50 seconds",
                DurationFormatUtils.formatDurationWords(50L * SEC, true, false));
        assertEquals("1 minute 5 seconds",
                DurationFormatUtils.formatDurationWords(65L * SEC, true, false));
        // Only the leading zero elements go; trailing zeros stay when the flag is off.
        assertEquals("1 day 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(DAY, true, false));
    }

    @Test
    public void formatDurationWordsSuppressesTrailingZeroElements() {
        assertEquals("0 days 0 hours 2 minutes",
                DurationFormatUtils.formatDurationWords(2L * MIN, false, true));
        assertEquals("2 minutes",
                DurationFormatUtils.formatDurationWords(2L * MIN, true, true));
        assertEquals("1 day",
                DurationFormatUtils.formatDurationWords(DAY, true, true));
    }

    @Test
    public void formatDurationWordsIsPluralizationCorrect() {
        assertEquals("2 minutes 1 second",
                DurationFormatUtils.formatDurationWords(121L * SEC, true, true));
        assertEquals("1 minute 5 seconds",
                DurationFormatUtils.formatDurationWords(65L * SEC, true, true));
    }

    // ------------------------------------------------------------------
    // formatPeriod(long, long, String)
    // ------------------------------------------------------------------

    @Test
    public void formatPeriodZeroSpan() {
        assertEquals("0", DurationFormatUtils.formatPeriod(0L, 0L, "d"));
        assertEquals("0000", DurationFormatUtils.formatPeriod(0L, 0L, "yyyy"));
        assertEquals("0:00:00.000",
                DurationFormatUtils.formatPeriod(5000L, 5000L, "H:mm:ss.SSS"));
    }

    @Test
    public void formatPeriodSubMinuteSpan() {
        assertEquals("45", DurationFormatUtils.formatPeriod(0L, 45L * SEC, "s"));
        assertEquals("0:45", DurationFormatUtils.formatPeriod(0L, 45L * SEC, "m:ss"));
    }

    @Test
    public void formatPeriodMatchesFormatDurationForSameDaySpans() {
        // Within a single day and using only day-and-lower fields, a period starting
        // at t=0 must render identically to a duration of the same length.
        long span = 5L * HOUR + 6L * MIN + 7L * SEC + 8L;
        assertEquals(
                DurationFormatUtils.formatDuration(span, "H:mm:ss.SSS"),
                DurationFormatUtils.formatPeriod(0L, span, "H:mm:ss.SSS"));
    }

    // ------------------------------------------------------------------
    // formatPeriod(long, long, String, boolean, TimeZone)
    // ------------------------------------------------------------------

    @Test
    public void formatPeriodWithTimeZoneHoursMinutesSeconds() {
        long span = 2L * HOUR + 3L * MIN + 4L * SEC + 5L;
        assertEquals("2:03:04.005",
                DurationFormatUtils.formatPeriod(0L, span, "H:mm:ss.SSS", true, GMT));
        assertEquals("1:05",
                DurationFormatUtils.formatPeriod(0L, HOUR + 5L * MIN, "H:mm", true, GMT));
        assertEquals("1:5",
                DurationFormatUtils.formatPeriod(0L, HOUR + 5L * MIN, "H:mm", false, GMT));
    }

    @Test
    public void formatPeriodWithTimeZoneYearsMonthsDays() {
        // 2000-01-01 -> 2002-03-04 is exactly 2 years, 2 months and 3 days with no
        // field borrowing required.
        long start = gmtMillis(2000, Calendar.JANUARY, 1);
        assertEquals("2 2 3", DurationFormatUtils.formatPeriod(
                start, gmtMillis(2002, Calendar.MARCH, 4), "y' 'M' 'd", true, GMT));
    }

    @Test
    public void formatPeriodWithTimeZoneSingleFieldPatterns() {
        long y2000 = gmtMillis(2000, Calendar.JANUARY, 1);
        assertEquals("3", DurationFormatUtils.formatPeriod(
                y2000, gmtMillis(2003, Calendar.JANUARY, 1), "y", true, GMT));
        assertEquals("3", DurationFormatUtils.formatPeriod(
                y2000, gmtMillis(2000, Calendar.APRIL, 1), "M", true, GMT));
        assertEquals("14", DurationFormatUtils.formatPeriod(
                y2000, gmtMillis(2000, Calendar.JANUARY, 15), "d", true, GMT));
    }

    @Test
    public void formatPeriodWithTimeZonePadFlag() {
        assertEquals("0000", DurationFormatUtils.formatPeriod(0L, 0L, "yyyy", true, GMT));
        assertEquals("0", DurationFormatUtils.formatPeriod(0L, 0L, "yyyy", false, GMT));
    }

    @Test
    public void formatPeriodWithTimeZoneEqualsThreeArgOverloadForDefaultCase() {
        // The three-arg formatPeriod is the five-arg one with padding on and the
        // default time zone; compare them for a span that is time-zone agnostic.
        long span = 45L * SEC;
        assertEquals(
                DurationFormatUtils.formatPeriod(0L, span, "m:ss"),
                DurationFormatUtils.formatPeriod(0L, span, "m:ss", true,
                        TimeZone.getDefault()));
    }
}
