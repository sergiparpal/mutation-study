package org.apache.commons.csv;

import java.io.Closeable;
import java.io.File;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link CSVFormat}.
 *
 * <p>Every expectation is taken from the published Javadoc contract in {@code api/}:
 * the documented "Settings are" blocks of the predefined formats, the documented
 * return values of the getters, the documented {@code IllegalArgumentException}
 * clauses and the class-level statement "This class is immutable".</p>
 *
 * <p>This class deliberately extends {@code junit.framework.TestCase} and uses no
 * external helper: it must compile against the JUnit 3.8.1 jar shipped in
 * {@code lib/}.</p>
 */
public class CSVFormatAgentTest extends TestCase {

    /** Header enum used to exercise {@link CSVFormat#withHeader(Class)}. */
    public enum SampleHeader {
        Name, Email, Phone
    }

    /** Compares two {@code char} values without depending on a primitive assertEquals overload. */
    private static void assertCharEquals(char expected, char actual) {
        assertEquals(String.valueOf(expected), String.valueOf(actual));
    }

    private static void closeIfPossible(Object o) throws Exception {
        if (o instanceof Closeable) {
            ((Closeable) o).close();
        }
    }

    // ------------------------------------------------------------------
    // newFormat(char)
    // ------------------------------------------------------------------

    public void testNewFormatSetsDelimiterAndLeavesEverythingElseUnset() {
        CSVFormat f = CSVFormat.newFormat('!');

        // "Creates a new CSV format with the specified delimiter."
        assertCharEquals('!', f.getDelimiter());

        // "All fields but the delimiter will be initialized with null/false."
        assertNull(f.getCommentMarker());
        assertFalse(f.isCommentMarkerSet());
        assertNull(f.getEscapeCharacter());
        assertFalse(f.isEscapeCharacterSet());
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
        assertNull(f.getQuoteMode());
        assertNull(f.getNullString());
        assertFalse(f.isNullStringSet());
        assertNull(f.getRecordSeparator());
        assertNull(f.getHeader());
        assertNull(f.getHeaderComments());

        assertFalse(f.getAllowMissingColumnNames());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.getIgnoreHeaderCase());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getSkipHeaderRecord());
        assertFalse(f.getTrailingDelimiter());
        assertFalse(f.getTrim());
    }

    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("expected IllegalArgumentException for LF delimiter");
        } catch (IllegalArgumentException expected) {
            // "if the delimiter is a line break character"
        }
        try {
            CSVFormat.newFormat('\r');
            fail("expected IllegalArgumentException for CR delimiter");
        } catch (IllegalArgumentException expected) {
            // as above
        }
    }

    // ------------------------------------------------------------------
    // Immutability
    // ------------------------------------------------------------------

    public void testWithMethodsDoNotMutateReceiver() {
        CSVFormat base = CSVFormat.newFormat(',');

        // Each call returns a *new* format; the receiver must be untouched.
        base.withDelimiter(';');
        base.withQuote('"');
        base.withCommentMarker('#');
        base.withEscape('\\');
        base.withHeader("a", "b");
        base.withHeaderComments("c");
        base.withNullString("NULL");
        base.withIgnoreEmptyLines();
        base.withTrim();
        base.withSkipHeaderRecord();

        assertCharEquals(',', base.getDelimiter());
        assertNull(base.getQuoteCharacter());
        assertFalse(base.isQuoteCharacterSet());
        assertNull(base.getCommentMarker());
        assertFalse(base.isCommentMarkerSet());
        assertNull(base.getEscapeCharacter());
        assertNull(base.getHeader());
        assertNull(base.getHeaderComments());
        assertNull(base.getNullString());
        assertFalse(base.isNullStringSet());
        assertFalse(base.getIgnoreEmptyLines());
        assertFalse(base.getTrim());
        assertFalse(base.getSkipHeaderRecord());
    }

    public void testWithDelimiterReturnsNewInstanceAndKeepsOtherSettings() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat modified = original.withDelimiter(';');

        assertCharEquals(';', modified.getDelimiter());
        assertCharEquals(',', original.getDelimiter());
        assertTrue(original != modified);

        // "equal to this with the specified character as delimiter": other
        // documented DEFAULT settings must survive the copy.
        assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
        assertEquals("\r\n", modified.getRecordSeparator());
        assertTrue(modified.getIgnoreEmptyLines());
    }

    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // "thrown if the specified character is a line break"
        }
        try {
            CSVFormat.DEFAULT.withDelimiter('\r');
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // as above
        }
    }

    // ------------------------------------------------------------------
    // Comment marker
    // ------------------------------------------------------------------

    public void testWithCommentMarker() {
        CSVFormat viaChar = CSVFormat.newFormat(',').withCommentMarker('#');
        assertEquals(Character.valueOf('#'), viaChar.getCommentMarker());
        assertTrue(viaChar.isCommentMarkerSet());

        CSVFormat viaCharacter = CSVFormat.newFormat(',').withCommentMarker(Character.valueOf('!'));
        assertEquals(Character.valueOf('!'), viaCharacter.getCommentMarker());
        assertTrue(viaCharacter.isCommentMarkerSet());
    }

    public void testWithCommentMarkerNullDisables() {
        CSVFormat f = CSVFormat.newFormat(',').withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(f.getCommentMarker());
        assertFalse(f.isCommentMarkerSet());
    }

    public void testWithCommentMarkerRejectsLineBreak() {
        try {
            CSVFormat.newFormat(',').withCommentMarker('\n');
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // "thrown if the specified character is a line break"
        }
    }

    // ------------------------------------------------------------------
    // Escape character
    // ------------------------------------------------------------------

    public void testWithEscape() {
        CSVFormat viaChar = CSVFormat.newFormat(',').withEscape('\\');
        assertEquals(Character.valueOf('\\'), viaChar.getEscapeCharacter());
        assertTrue(viaChar.isEscapeCharacterSet());

        CSVFormat viaCharacter = CSVFormat.newFormat(',').withEscape(Character.valueOf('/'));
        assertEquals(Character.valueOf('/'), viaCharacter.getEscapeCharacter());
        assertTrue(viaCharacter.isEscapeCharacterSet());
    }

    public void testWithEscapeNullDisables() {
        CSVFormat f = CSVFormat.MYSQL.withEscape((Character) null);
        assertNull(f.getEscapeCharacter());
        assertFalse(f.isEscapeCharacterSet());
    }

    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.newFormat(',').withEscape('\r');
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // "thrown if the specified character is a line break"
        }
    }

    // ------------------------------------------------------------------
    // Quote character
    // ------------------------------------------------------------------

    public void testWithQuote() {
        CSVFormat viaChar = CSVFormat.newFormat(',').withQuote('\'');
        assertEquals(Character.valueOf('\''), viaChar.getQuoteCharacter());
        assertTrue(viaChar.isQuoteCharacterSet());

        CSVFormat viaCharacter = CSVFormat.newFormat(',').withQuote(Character.valueOf('`'));
        assertEquals(Character.valueOf('`'), viaCharacter.getQuoteCharacter());
        assertTrue(viaCharacter.isQuoteCharacterSet());
    }

    public void testWithQuoteNullDisables() {
        CSVFormat f = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
    }

    public void testWithQuoteRejectsLineBreak() {
        try {
            CSVFormat.newFormat(',').withQuote('\r');
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // "thrown if the specified character is a line break"
        }
        try {
            CSVFormat.newFormat(',').withQuote(Character.valueOf('\n'));
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // as above
        }
    }

    // ------------------------------------------------------------------
    // Null string
    // ------------------------------------------------------------------

    public void testWithNullString() {
        CSVFormat f = CSVFormat.newFormat(',').withNullString("\\N");
        assertEquals("\\N", f.getNullString());
        assertTrue(f.isNullStringSet());
    }

    public void testWithNullStringNullClearsIt() {
        CSVFormat f = CSVFormat.MYSQL.withNullString(null);
        assertNull(f.getNullString());
        assertFalse(f.isNullStringSet());
    }

    // ------------------------------------------------------------------
    // Record separator
    // ------------------------------------------------------------------

    public void testWithRecordSeparatorAcceptsCrLfAndCrlf() {
        assertEquals("\n", CSVFormat.newFormat(',').withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\r", CSVFormat.newFormat(',').withRecordSeparator("\r").getRecordSeparator());
        assertEquals("\n", CSVFormat.newFormat(',').withRecordSeparator("\n").getRecordSeparator());
        assertEquals("\r\n", CSVFormat.newFormat(',').withRecordSeparator("\r\n").getRecordSeparator());
    }

    public void pruned_testWithRecordSeparatorRejectsOtherStrings() {
        try {
            CSVFormat.newFormat(',').withRecordSeparator("not-a-separator");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // "if recordSeparator is none of CR, LF or CRLF"
        }
    }

    // ------------------------------------------------------------------
    // Boolean "with" methods
    // ------------------------------------------------------------------

    public void testNoArgBooleanWithersSetTrue() {
        assertTrue(CSVFormat.newFormat(',').withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(CSVFormat.newFormat(',').withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertTrue(CSVFormat.newFormat(',').withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(CSVFormat.newFormat(',').withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.newFormat(',').withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.newFormat(',').withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.newFormat(',').withTrim().getTrim());
    }

    public void testExplicitBooleanWithersRoundTrip() {
        assertTrue(CSVFormat.newFormat(',').withAllowMissingColumnNames(true).getAllowMissingColumnNames());
        assertFalse(CSVFormat.newFormat(',').withAllowMissingColumnNames().withAllowMissingColumnNames(false)
                .getAllowMissingColumnNames());

        assertTrue(CSVFormat.newFormat(',').withIgnoreEmptyLines(true).getIgnoreEmptyLines());
        assertFalse(CSVFormat.newFormat(',').withIgnoreEmptyLines().withIgnoreEmptyLines(false).getIgnoreEmptyLines());

        assertTrue(CSVFormat.newFormat(',').withIgnoreHeaderCase(true).getIgnoreHeaderCase());
        assertFalse(CSVFormat.newFormat(',').withIgnoreHeaderCase().withIgnoreHeaderCase(false).getIgnoreHeaderCase());

        assertTrue(CSVFormat.newFormat(',').withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.newFormat(',').withIgnoreSurroundingSpaces().withIgnoreSurroundingSpaces(false)
                .getIgnoreSurroundingSpaces());

        assertTrue(CSVFormat.newFormat(',').withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.newFormat(',').withSkipHeaderRecord().withSkipHeaderRecord(false).getSkipHeaderRecord());

        assertTrue(CSVFormat.newFormat(',').withTrailingDelimiter(true).getTrailingDelimiter());
        assertFalse(CSVFormat.newFormat(',').withTrailingDelimiter().withTrailingDelimiter(false)
                .getTrailingDelimiter());

        assertTrue(CSVFormat.newFormat(',').withTrim(true).getTrim());
        assertFalse(CSVFormat.newFormat(',').withTrim().withTrim(false).getTrim());
    }

    // ------------------------------------------------------------------
    // Header
    // ------------------------------------------------------------------

    public void testWithHeaderStringVarargs() {
        CSVFormat f = CSVFormat.newFormat(',').withHeader("Col1", "Col2", "Col3");
        String[] header = f.getHeader();
        assertNotNull(header);
        assertEquals(3, header.length);
        assertEquals("Col1", header[0]);
        assertEquals("Col2", header[1]);
        assertEquals("Col3", header[2]);
    }

    public void testGetHeaderReturnsDefensiveCopy() {
        CSVFormat f = CSVFormat.newFormat(',').withHeader("a", "b");
        String[] first = f.getHeader();
        first[0] = "MUTATED";

        String[] second = f.getHeader();
        assertTrue(first != second);
        assertEquals("a", second[0]);
        assertEquals("b", second[1]);
    }

    public void testWithHeaderNoArgYieldsEmptyArray() {
        // "the empty array if to be read from the file"
        String[] header = CSVFormat.newFormat(',').withHeader().getHeader();
        assertNotNull(header);
        assertEquals(0, header.length);
    }

    public void testWithHeaderNullDisablesHeader() {
        assertNull(CSVFormat.newFormat(',').withHeader((String[]) null).getHeader());
    }

    public void testWithHeaderFromEnumClass() {
        CSVFormat f = CSVFormat.newFormat(',').withHeader(SampleHeader.class);
        String[] header = f.getHeader();
        assertNotNull(header);
        assertEquals(3, header.length);
        assertEquals("Name", header[0]);
        assertEquals("Email", header[1]);
        assertEquals("Phone", header[2]);
    }

    public void testWithFirstRecordAsHeader() {
        // Documented equivalent of: aFormat.withHeader().withSkipHeaderRecord()
        CSVFormat f = CSVFormat.newFormat(',').withFirstRecordAsHeader();
        assertTrue(f.getSkipHeaderRecord());
        String[] header = f.getHeader();
        assertNotNull(header);
        assertEquals(0, header.length);
    }

    // ------------------------------------------------------------------
    // Header comments
    // ------------------------------------------------------------------

    public void testWithHeaderComments() {
        CSVFormat f = CSVFormat.DEFAULT.withHeaderComments("First comment", "Second comment");
        String[] comments = f.getHeaderComments();
        assertNotNull(comments);
        assertEquals(2, comments.length);
        assertEquals("First comment", comments[0]);
        assertEquals("Second comment", comments[1]);

        // "a copy of the header comment array; null if disabled."
        assertNull(CSVFormat.newFormat(',').getHeaderComments());
    }

    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        CSVFormat f = CSVFormat.DEFAULT.withHeaderComments("x", "y");
        String[] first = f.getHeaderComments();
        first[0] = "MUTATED";
        assertEquals("x", f.getHeaderComments()[0]);
    }

    // ------------------------------------------------------------------
    // Quote mode
    // ------------------------------------------------------------------

    public void testWithQuoteMode() {
        CSVFormat f = CSVFormat.newFormat(',').withQuoteMode(QuoteMode.MINIMAL);
        assertEquals(QuoteMode.MINIMAL, f.getQuoteMode());

        // default (unset) after newFormat
        assertNull(CSVFormat.newFormat(',').getQuoteMode());
    }

    // ------------------------------------------------------------------
    // equals / hashCode / toString
    // ------------------------------------------------------------------

    public void testEqualsIsReflexiveAndValueBased() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));

        CSVFormat a = CSVFormat.DEFAULT.withDelimiter(';');
        CSVFormat b = CSVFormat.DEFAULT.withDelimiter(';');
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());

        // Re-applying the current value produces an equal format.
        assertTrue(CSVFormat.DEFAULT.withDelimiter(',').equals(CSVFormat.DEFAULT));
        assertEquals(CSVFormat.DEFAULT.hashCode(), CSVFormat.DEFAULT.withDelimiter(',').hashCode());
    }

    public void testEqualsDistinguishesDocumentedDifferences() {
        // A changed delimiter makes two formats unequal.
        CSVFormat a = CSVFormat.DEFAULT.withDelimiter(';');
        assertFalse(a.equals(CSVFormat.DEFAULT.withDelimiter('|')));

        // DEFAULT and RFC4180 differ only by the documented ignoreEmptyLines setting
        // (DEFAULT: true, RFC4180: false) and must therefore not be equal.
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.RFC4180));
    }

    public void testEqualsRejectsNullAndForeignTypes() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("a string"));
        assertFalse(CSVFormat.DEFAULT.equals(Integer.valueOf(7)));
    }

    public void testHashCodeIsConsistent() {
        assertEquals(CSVFormat.DEFAULT.hashCode(), CSVFormat.DEFAULT.hashCode());
    }

    public void testToStringIsNonEmptyAndFormatSpecific() {
        String s = CSVFormat.DEFAULT.toString();
        assertNotNull(s);
        assertTrue(s.length() > 0);
        // Different delimiters (',' vs tab) must yield different descriptions.
        assertFalse(CSVFormat.DEFAULT.toString().equals(CSVFormat.TDF.toString()));
    }

    // ------------------------------------------------------------------
    // valueOf / Predefined
    // ------------------------------------------------------------------

    public void testValueOfReturnsMatchingPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    public void testValueOfUnknownNameThrows() {
        try {
            CSVFormat.valueOf("ThisIsNotAPredefinedFormat");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // Predefined.valueOf throws for an unknown constant name.
        }
    }

    public void testValueOfIsCaseSensitive() {
        try {
            CSVFormat.valueOf("default");
            fail("expected IllegalArgumentException (name must match exactly)");
        } catch (IllegalArgumentException expected) {
            // "The string must match exactly an identifier used to declare an enum constant"
        }
    }

    public void testPredefinedEnumExposesItsFormat() {
        assertEquals(7, CSVFormat.Predefined.values().length);
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
    }

    // ------------------------------------------------------------------
    // Documented settings of the predefined formats
    // ------------------------------------------------------------------

    public void testDefaultFormatSettings() {
        CSVFormat f = CSVFormat.DEFAULT;
        assertCharEquals(',', f.getDelimiter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertTrue(f.isQuoteCharacterSet());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
    }

    public void testRfc4180FormatSettings() {
        CSVFormat f = CSVFormat.RFC4180;
        assertCharEquals(',', f.getDelimiter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
    }

    public void testExcelFormatSettings() {
        CSVFormat f = CSVFormat.EXCEL;
        assertCharEquals(',', f.getDelimiter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
        assertTrue(f.getAllowMissingColumnNames());
    }

    public void testMySqlFormatSettings() {
        CSVFormat f = CSVFormat.MYSQL;
        assertCharEquals('\t', f.getDelimiter());
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertTrue(f.isEscapeCharacterSet());
        assertEquals("\\N", f.getNullString());
        assertTrue(f.isNullStringSet());
        assertFalse(f.getIgnoreEmptyLines());
    }

    public void testTdfFormatSettings() {
        CSVFormat f = CSVFormat.TDF;
        assertCharEquals('\t', f.getDelimiter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    public void pruned_testInformixUnloadFormatSettings() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD;
        assertCharEquals(',', f.getDelimiter());
        assertEquals("\n", f.getRecordSeparator());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertTrue(f.isEscapeCharacterSet());
    }

    public void testInformixUnloadCsvFormatSettings() {
        CSVFormat f = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertCharEquals(',', f.getDelimiter());
        assertEquals("\n", f.getRecordSeparator());
        // Title: "(escaping is disabled.)" and the settings block lists no escape.
        assertFalse(f.isEscapeCharacterSet());
    }

    // ------------------------------------------------------------------
    // format(Object...)
    // ------------------------------------------------------------------

    public void testFormatJoinsValuesWithDelimiter() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
        assertEquals("solo", CSVFormat.DEFAULT.format("solo"));
        assertEquals("", CSVFormat.DEFAULT.format());
        assertEquals("x|y", CSVFormat.newFormat('|').format("x", "y"));
    }

    public void testFormatQuotesValueContainingDelimiter() {
        // DEFAULT uses ',' as delimiter and '"' as quote: "a,b" must be quoted.
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    public void testFormatWritesNullAsNullString() {
        assertEquals("a,NULL,b", CSVFormat.DEFAULT.withNullString("NULL").format("a", null, "b"));
    }

    // ------------------------------------------------------------------
    // print / printRecord / println (write to an Appendable)
    // ------------------------------------------------------------------

    public void testPrintRecordWritesValuesFollowedByRecordSeparator() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    public void testPrintRecordUsesConfiguredDelimiterAndSeparator() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.newFormat(';').withRecordSeparator("\n").printRecord(sb, "1", "2", "3");
        assertEquals("1;2;3\n", sb.toString());
    }

    public void testPrintRecordQuotesValueContainingDelimiter() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "x,y");
        assertEquals("\"x,y\"\r\n", sb.toString());
    }

    public void testPrintRecordAppliesNullString() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withNullString("N/A").printRecord(sb, "a", null, "b");
        assertEquals("a,N/A,b\r\n", sb.toString());
    }

    public void testPrintlnOutputsRecordSeparatorOnly() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());

        StringBuilder sb2 = new StringBuilder();
        CSVFormat.newFormat(',').withRecordSeparator('\n').println(sb2);
        assertEquals("\n", sb2.toString());
    }

    public void testPrintSingleValueThenContinuationValue() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("hello", sb, true);
        assertEquals("hello", sb.toString());

        // Not a new record: the delimiter separates it from the previous value.
        CSVFormat.DEFAULT.print("world", sb, false);
        assertEquals("hello,world", sb.toString());
    }

    public void testPrintToAppendableReturnsAPrinter() throws Exception {
        Object printer = CSVFormat.DEFAULT.print(new StringBuilder());
        assertNotNull(printer);
        closeIfPossible(printer);
    }

    public void testPrintToFileReturnsAPrinterAndCreatesTheFile() throws Exception {
        File file = File.createTempFile("csvformat-agent-file", ".csv");
        file.deleteOnExit();
        Object printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
        assertNotNull(printer);
        assertTrue(file.exists());
        closeIfPossible(printer);
    }

    public void testPrintToPathReturnsAPrinter() throws Exception {
        File file = File.createTempFile("csvformat-agent-path", ".csv");
        file.deleteOnExit();
        Path path = file.toPath();
        Object printer = CSVFormat.DEFAULT.print(path, StandardCharsets.UTF_8);
        assertNotNull(printer);
        closeIfPossible(printer);
    }

    // ------------------------------------------------------------------
    // parse(Reader)
    // ------------------------------------------------------------------

    public void testParseReturnsANonNullParser() throws Exception {
        StringReader reader = new StringReader("a,b,c\r\nd,e,f\r\n");
        Object parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
        closeIfPossible(parser);
    }
}
