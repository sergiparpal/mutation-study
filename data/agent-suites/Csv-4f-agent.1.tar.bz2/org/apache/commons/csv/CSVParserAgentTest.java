/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Test;

/**
 * Tests the public API of {@link CSVParser}: the static {@code parse} factory methods, the {@code Reader}
 * constructor, and the observable state exposed through {@code getRecords()}, {@code iterator()},
 * {@code getHeaderMap()}, {@code getRecordNumber()}, {@code getCurrentLineNumber()}, {@code isClosed()} and
 * {@code close()}.
 *
 * @version $Id$
 */
public class CSVParserAgentTest {

    private static final Charset UTF_8 = Charset.forName("UTF-8");

    private final List<File> tempFiles = new ArrayList<File>();

    @After
    public void deleteTempFiles() {
        for (final File file : tempFiles) {
            file.delete();
        }
        tempFiles.clear();
    }

    private File createTestFile(final String content) throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        tempFiles.add(file);
        final Writer writer = new FileWriter(file);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    private static void assertRecord(final CSVRecord record, final String... expectedValues) {
        assertEquals("record size", expectedValues.length, record.size());
        for (int i = 0; i < expectedValues.length; i++) {
            assertEquals("value at index " + i, expectedValues[i], record.get(i));
        }
    }

    // ----------------------------------------------------------------------
    // Reader constructor
    // ----------------------------------------------------------------------

    @Test
    public void testConstructorWithReaderParsesRecords() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\r\nd,e,f\r\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertRecord(records.get(0), "a", "b", "c");
            assertRecord(records.get(1), "d", "e", "f");
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrows() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrows() throws IOException {
        new CSVParser(new StringReader(""), null);
    }

    @Test(expected = IllegalStateException.class)
    public void testConstructorInconsistentFormatThrows() throws IOException {
        // delimiter and quoteChar are identical -> CSVFormat.validate() fails
        new CSVParser(new StringReader("a,b,c"), CSVFormat.DEFAULT.withDelimiter('!').withQuoteChar('!'));
    }

    // ----------------------------------------------------------------------
    // parse(String, CSVFormat)
    // ----------------------------------------------------------------------

    @Test
    public void testParseStringHappyPath() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertRecord(records.get(0), "a", "b", "c");
            assertRecord(records.get(1), "1", "2", "3");
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullStringThrows() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullFormatThrows() throws IOException {
        CSVParser.parse("a,b,c", (CSVFormat) null);
    }

    @Test(expected = IllegalStateException.class)
    public void testParseStringInconsistentFormatThrows() throws IOException {
        CSVParser.parse("a,b,c", CSVFormat.DEFAULT.withDelimiter('!').withQuoteChar('!'));
    }

    // ----------------------------------------------------------------------
    // parse(File, CSVFormat)
    // ----------------------------------------------------------------------

    @Test
    public void testParseFileHappyPath() throws IOException {
        final File file = createTestFile("a,b,c\nx,y,z\n");
        final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertRecord(records.get(0), "a", "b", "c");
            assertRecord(records.get(1), "x", "y", "z");
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullFileThrows() throws IOException {
        CSVParser.parse((File) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullFormatThrows() throws IOException {
        final File file = createTestFile("a,b,c\n");
        CSVParser.parse(file, null);
    }

    @Test(expected = IOException.class)
    public void testParseNonExistentFileThrows() throws IOException {
        CSVParser.parse(new File("no-such-file-CSVParserAgentTest-12345.csv"), CSVFormat.DEFAULT);
    }

    // ----------------------------------------------------------------------
    // parse(URL, Charset, CSVFormat)
    // ----------------------------------------------------------------------

    @Test
    public void testParseUrlHappyPath() throws Exception {
        final File file = createTestFile("one,two\nthree,four\n");
        final URL url = file.toURI().toURL();
        final CSVParser parser = CSVParser.parse(url, UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertRecord(records.get(0), "one", "two");
            assertRecord(records.get(1), "three", "four");
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullUrlThrows() throws IOException {
        CSVParser.parse((URL) null, UTF_8, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullCharsetThrows() throws Exception {
        CSVParser.parse(new File("x.csv").toURI().toURL(), null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullFormatThrows() throws Exception {
        CSVParser.parse(new File("x.csv").toURI().toURL(), UTF_8, null);
    }

    // ----------------------------------------------------------------------
    // getRecords()
    // ----------------------------------------------------------------------

    @Test
    public void testGetRecordsEmptyInput() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertEquals(0, records.size());
            assertEquals(0, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsWithoutTrailingNewline() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertRecord(records.get(1), "d", "e", "f");
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsAssignsSequentialRecordNumbers() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(0).getRecordNumber());
            assertEquals(2, records.get(1).getRecordNumber());
            assertEquals(3, records.get(2).getRecordNumber());
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsStartsAtCurrentPosition() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            final CSVRecord first = iterator.next();
            assertRecord(first, "a", "b");

            final List<CSVRecord> remaining = parser.getRecords();
            assertEquals(2, remaining.size());
            assertRecord(remaining.get(0), "c", "d");
            assertRecord(remaining.get(1), "e", "f");
        } finally {
            parser.close();
        }
    }

    @Test(expected = IOException.class)
    public void testGetRecordsAfterCloseThrows() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n", CSVFormat.DEFAULT);
        parser.close();
        parser.getRecords();
    }

    @Test(expected = IOException.class)
    public void testGetRecordsUnterminatedQuoteThrows() throws IOException {
        CSVParser.parse("\"unterminated", CSVFormat.DEFAULT).getRecords();
    }

    @Test(expected = IOException.class)
    public void testGetRecordsInvalidCharAfterQuoteThrows() throws IOException {
        CSVParser.parse("\"abc\"x,d\n", CSVFormat.DEFAULT).getRecords();
    }

    // ----------------------------------------------------------------------
    // Value handling
    // ----------------------------------------------------------------------

    @Test
    public void testQuotedValueContainingDelimiter() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertRecord(records.get(0), "a,b", "c");
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullStringConversion() throws IOException {
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", CSVFormat.DEFAULT.withNullString("NULL"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertNull(records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyLinesAreSkippedByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n\n\nc,d\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertRecord(records.get(0), "a", "b");
            assertRecord(records.get(1), "c", "d");
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyLinesBecomeRecordsForRfc4180() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n\nc,d\n", CSVFormat.RFC4180);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertRecord(records.get(0), "a", "b");
            assertRecord(records.get(1), "");
            assertRecord(records.get(2), "c", "d");
        } finally {
            parser.close();
        }
    }

    // ----------------------------------------------------------------------
    // getRecordNumber() / getCurrentLineNumber()
    // ----------------------------------------------------------------------

    @Test
    public void testLineAndRecordNumberStartAtZero() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            assertEquals(0, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCurrentLineNumberTracksConsumedLines() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testRecordNumberAdvancesDuringIteration() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            iterator.next();
            assertEquals(1, parser.getRecordNumber());
            iterator.next();
            assertEquals(2, parser.getRecordNumber());
            iterator.next();
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testLineNumberDivergesFromRecordNumberOnMultiLineValues() throws IOException {
        final CSVParser parser = CSVParser.parse("a,\"b\nb\",c\nd,e,f\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("b\nb", records.get(0).get(1));
            assertEquals(1, records.get(0).getRecordNumber());
            assertEquals(2, records.get(1).getRecordNumber());
            // three physical lines were consumed but only two records produced
            assertEquals(2, parser.getRecordNumber());
            assertEquals(3, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    // ----------------------------------------------------------------------
    // getHeaderMap()
    // ----------------------------------------------------------------------

    @Test
    public void testNoHeaderMap() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapFromExplicitHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2,3\n4,5,6\n", CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            assertEquals(3, headerMap.size());
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            // iteration order is column order
            final Iterator<String> keys = headerMap.keySet().iterator();
            assertEquals("A", keys.next());
            assertEquals("B", keys.next());
            assertEquals("C", keys.next());

            // an explicit header is not consumed from the input
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("6", records.get(1).get("C"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapReadFromFirstRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("A,B,C\n1,2,3\n4,5,6\n", CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            // the first record was consumed as the header
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("5", records.get(1).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapWithSkipHeaderRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("ignored1,ignored2\n1,2\n",
                CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("2", records.get(0).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsIndependentCopy() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2,3\n", CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> first = parser.getHeaderMap();
            first.remove("A");
            first.put("D", Integer.valueOf(99));

            final Map<String, Integer> second = parser.getHeaderMap();
            assertEquals(3, second.size());
            assertTrue(second.containsKey("A"));
            assertFalse(second.containsKey("D"));
        } finally {
            parser.close();
        }
    }

    // ----------------------------------------------------------------------
    // iterator() / Iterable
    // ----------------------------------------------------------------------

    @Test
    public void testForEachIteratesAllRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n5,6\n", CSVFormat.DEFAULT);
        try {
            int count = 0;
            for (final CSVRecord record : parser) {
                assertEquals(2, record.size());
                count++;
            }
            assertEquals(3, count);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            assertTrue(iterator.hasNext());
            assertTrue(iterator.hasNext());
            assertEquals("a", iterator.next().get(0));
            assertTrue(iterator.hasNext());
            assertEquals("b", iterator.next().get(0));
            assertFalse(iterator.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test(expected = NoSuchElementException.class)
    public void testIteratorNextBeyondEndThrows() throws IOException {
        final CSVParser parser = CSVParser.parse("only,one,record\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        iterator.next(); // consumes the single record
        iterator.next(); // nothing left
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testIteratorRemoveIsUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n", CSVFormat.DEFAULT);
        parser.iterator().remove();
    }

    @Test
    public void testIteratorAfterCloseStopsIterating() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        parser.close();

        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException after the parser was closed");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    // ----------------------------------------------------------------------
    // close() / isClosed()
    // ----------------------------------------------------------------------

    @Test
    public void testIsClosedReflectsCloseState() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close(); // must not throw
        assertTrue(parser.isClosed());
    }
}
