/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import junit.framework.TestCase;

/**
 * Tests for the public API of {@link HelpFormatter}.
 *
 * Written against the JUnit 3.8 style used by the rest of this project
 * (extend {@link TestCase}, no annotations).
 */
public class HelpFormatterAgentTest extends TestCase
{
    /** platform line separator, used both by PrintWriter.println and by the formatter internally */
    private static final String EOL = System.getProperty("line.separator");

    // ------------------------------------------------------------------ helpers

    /**
     * Splits the given text on the platform line separator.  A trailing
     * separator (as produced by {@code println}) does not yield an empty
     * trailing element.
     */
    private static String[] getLines(String text)
    {
        List lines = new ArrayList();
        int start = 0;
        int idx;

        while ((idx = text.indexOf(EOL, start)) != -1)
        {
            lines.add(text.substring(start, idx));
            start = idx + EOL.length();
        }

        if (start < text.length())
        {
            lines.add(text.substring(start));
        }

        return (String[]) lines.toArray(new String[lines.size()]);
    }

    // --------------------------------------------------------------- constants

    public void testPublicConstants()
    {
        assertEquals(74, HelpFormatter.DEFAULT_WIDTH);
        assertEquals(1, HelpFormatter.DEFAULT_LEFT_PAD);
        assertEquals(3, HelpFormatter.DEFAULT_DESC_PAD);
        assertEquals("usage: ", HelpFormatter.DEFAULT_SYNTAX_PREFIX);
        assertEquals("-", HelpFormatter.DEFAULT_OPT_PREFIX);
        assertEquals("--", HelpFormatter.DEFAULT_LONG_OPT_PREFIX);
        assertEquals(" ", HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR);
        assertEquals("arg", HelpFormatter.DEFAULT_ARG_NAME);
    }

    // ------------------------------------------------------- defaults & accessors

    public void testDefaultValues()
    {
        HelpFormatter formatter = new HelpFormatter();

        assertEquals(HelpFormatter.DEFAULT_WIDTH, formatter.getWidth());
        assertEquals(HelpFormatter.DEFAULT_LEFT_PAD, formatter.getLeftPadding());
        assertEquals(HelpFormatter.DEFAULT_DESC_PAD, formatter.getDescPadding());
        assertEquals("usage: ", formatter.getSyntaxPrefix());
        assertEquals("-", formatter.getOptPrefix());
        assertEquals("--", formatter.getLongOptPrefix());
        assertEquals(" ", formatter.getLongOptSeparator());
        assertEquals("arg", formatter.getArgName());
        assertEquals(EOL, formatter.getNewLine());
        assertNotNull(formatter.getOptionComparator());
    }

    public void testSettersAndGettersRoundTrip()
    {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(120);
        assertEquals(120, formatter.getWidth());

        formatter.setLeftPadding(5);
        assertEquals(5, formatter.getLeftPadding());

        formatter.setDescPadding(7);
        assertEquals(7, formatter.getDescPadding());

        formatter.setSyntaxPrefix("Usage: ");
        assertEquals("Usage: ", formatter.getSyntaxPrefix());

        formatter.setNewLine("\r\n");
        assertEquals("\r\n", formatter.getNewLine());

        formatter.setOptPrefix("/");
        assertEquals("/", formatter.getOptPrefix());

        formatter.setLongOptPrefix("++");
        assertEquals("++", formatter.getLongOptPrefix());

        formatter.setLongOptSeparator("=");
        assertEquals("=", formatter.getLongOptSeparator());

        formatter.setArgName("value");
        assertEquals("value", formatter.getArgName());
    }

    public void testBoundarySetterValues()
    {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(0);
        assertEquals(0, formatter.getWidth());

        formatter.setWidth(-10);
        assertEquals(-10, formatter.getWidth());

        formatter.setLeftPadding(0);
        assertEquals(0, formatter.getLeftPadding());

        formatter.setDescPadding(0);
        assertEquals(0, formatter.getDescPadding());

        formatter.setSyntaxPrefix("");
        assertEquals("", formatter.getSyntaxPrefix());
    }

    public void testDeprecatedPublicFieldsAndAccessorsAreConsistent()
    {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(99);
        assertEquals(99, formatter.defaultWidth);

        formatter.defaultWidth = 55;
        assertEquals(55, formatter.getWidth());

        formatter.setLeftPadding(4);
        assertEquals(4, formatter.defaultLeftPad);

        formatter.setDescPadding(6);
        assertEquals(6, formatter.defaultDescPad);

        formatter.setSyntaxPrefix(">> ");
        assertEquals(">> ", formatter.defaultSyntaxPrefix);

        formatter.setArgName("A");
        assertEquals("A", formatter.defaultArgName);
    }

    public void testSetOptionComparatorKeepsCustomComparator()
    {
        HelpFormatter formatter = new HelpFormatter();

        Comparator custom = new Comparator()
        {
            public int compare(Object o1, Object o2)
            {
                return 0;
            }
        };

        formatter.setOptionComparator(custom);
        assertSame(custom, formatter.getOptionComparator());
    }

    public void testSetOptionComparatorNullRestoresDefault()
    {
        HelpFormatter formatter = new HelpFormatter();
        Comparator original = formatter.getOptionComparator();
        assertNotNull(original);

        Comparator custom = new Comparator()
        {
            public int compare(Object o1, Object o2)
            {
                return 0;
            }
        };
        formatter.setOptionComparator(custom);
        assertSame(custom, formatter.getOptionComparator());

        formatter.setOptionComparator(null);
        assertNotNull(formatter.getOptionComparator());
        assertNotSame(custom, formatter.getOptionComparator());
    }

    // --------------------------------------------------------------- printUsage

    public void testPrintUsagePlainSyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        formatter.printUsage(pw, 74, "myapp");
        pw.flush();

        assertEquals("usage: myapp" + EOL, out.toString());
    }

    public void testPrintUsageUsesSyntaxPrefix()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setSyntaxPrefix("Usage: ");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 74, "app");
        pw.flush();

        assertEquals("Usage: app" + EOL, out.toString());
    }

    public void testPrintUsageWithEmptySyntaxPrefix()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setSyntaxPrefix("");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 74, "app");
        pw.flush();

        assertEquals("app" + EOL, out.toString());
    }

    public void testPrintUsageGeneratedFromOptions()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "first");
        options.addOption("b", true, "second");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 74, "myapp", options);
        pw.flush();

        assertEquals("usage: myapp [-a] [-b <arg>]" + EOL, out.toString());
    }

    public void testPrintUsageRequiredOptionIsNotBracketed()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption(OptionBuilder.isRequired().create("r"));
        options.addOption(OptionBuilder.create("o"));

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 74, "app", options);
        pw.flush();

        assertEquals("usage: app [-o] -r", out.toString().trim());
    }

    public void testPrintUsageWithOptionGroup()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.withDescription("enable foo").create("f"));
        group.addOption(OptionBuilder.withDescription("enable bar").create("b"));
        options.addOptionGroup(group);

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 74, "app", options);
        pw.flush();

        assertEquals("usage: app [-b | -f]", out.toString().trim());
    }

    public void testPrintUsageOptionComparatorControlsOrder()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "first");
        options.addOption("b", false, "second");
        options.addOption("c", false, "third");

        formatter.setOptionComparator(new Comparator()
        {
            public int compare(Object o1, Object o2)
            {
                Option opt1 = (Option) o1;
                Option opt2 = (Option) o2;
                return opt2.getKey().compareToIgnoreCase(opt1.getKey());
            }
        });

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 74, "app", options);
        pw.flush();

        assertEquals("usage: app [-c] [-b] [-a]", out.toString().trim());
    }

    public void testPrintUsageWrapsLongSyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        formatter.printUsage(pw, 30, "myapp -a -b -c -d -e -f -g -h -i -j");
        pw.flush();

        String[] lines = getLines(out.toString());
        assertTrue("expected the usage line to wrap: " + out.toString(), lines.length > 1);
        assertTrue(lines[0].startsWith("usage: myapp"));
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line exceeds requested width: '" + lines[i] + "'", lines[i].length() <= 30);
        }
    }

    // ------------------------------------------------------------- printOptions

    public void testPrintOptionsSingleOptionExactLayout()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "desc a");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 74, options, 1, 3);
        pw.flush();

        assertEquals(" -a   desc a" + EOL, out.toString());
    }

    public void testPrintOptionsRendersShortAndLongOptAndDescription()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", "alpha", false, "The alpha option");
        options.addOption("b", false, "The beta option");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 74, options, 1, 3);
        pw.flush();

        String result = out.toString();
        assertTrue(result, result.indexOf("-a,--alpha") >= 0);
        assertTrue(result, result.indexOf("The alpha option") >= 0);
        assertTrue(result, result.indexOf("-b") >= 0);
        assertTrue(result, result.indexOf("The beta option") >= 0);
        // -a sorts before -b
        assertTrue(result.indexOf("-a,--alpha") < result.indexOf("The beta option"));
    }

    public void testPrintOptionsUsesCustomPrefixes()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setOptPrefix("/");
        formatter.setLongOptPrefix("::");

        Options options = new Options();
        options.addOption("v", "verbose", false, "be verbose");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 74, options, 1, 3);
        pw.flush();

        String result = out.toString();
        assertTrue(result, result.indexOf("/v") >= 0);
        assertTrue(result, result.indexOf("::verbose") >= 0);
        assertTrue(result, result.indexOf("be verbose") >= 0);
    }

    public void testPrintOptionsUsesLongOptSeparator()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setLongOptSeparator("=");

        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("file").hasArg().withArgName("FILE")
                .withDescription("the file").create("f"));

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 74, options, 1, 3);
        pw.flush();

        assertTrue(out.toString(), out.toString().indexOf("-f,--file=<FILE>") >= 0);
    }

    public void testPrintOptionsUsesDefaultArgNameWhenOptionHasNone()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setArgName("PARAM");

        Options options = new Options();
        options.addOption(OptionBuilder.hasArg().withDescription("an option with arg").create("o"));

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 74, options, 1, 3);
        pw.flush();

        assertTrue(out.toString(), out.toString().indexOf("<PARAM>") >= 0);
    }

    public void testPrintOptionsWrapsLongDescription()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("x", false,
                "this is a fairly long description that should be wrapped across several lines");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 30, options, 1, 3);
        pw.flush();

        String[] lines = getLines(out.toString());
        assertTrue("expected description to wrap: " + out.toString(), lines.length > 1);
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line exceeds requested width: '" + lines[i] + "'", lines[i].length() <= 30);
        }
        assertTrue(lines[0].indexOf("-x") >= 0);
    }

    // ------------------------------------------------------------- printWrapped

    public void testPrintWrappedShortTextIsUnchanged()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        formatter.printWrapped(pw, 74, "a short line");
        pw.flush();

        assertEquals("a short line" + EOL, out.toString());
    }

    public void testPrintWrappedWrapsAtWhitespace()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        String text = "The quick brown fox jumped over the lazy dog";
        formatter.printWrapped(pw, 20, text);
        pw.flush();

        String rendered = out.toString();
        assertTrue(rendered.endsWith(EOL));

        String[] lines = getLines(rendered);
        assertTrue("expected multiple lines but got: " + rendered, lines.length > 1);

        StringBuffer joined = new StringBuffer();
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line too long: '" + lines[i] + "'", lines[i].length() <= 20);
            if (i > 0)
            {
                joined.append(' ');
            }
            joined.append(lines[i]);
        }
        assertEquals(text, joined.toString());
    }

    public void testPrintWrappedHardChopWhenWordExceedsWidth()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        formatter.printWrapped(pw, 5, "abcdefghij klmno");
        pw.flush();

        String[] lines = getLines(out.toString());
        assertEquals(3, lines.length);
        assertEquals("abcde", lines[0]);
        assertEquals("fghij", lines[1]);
        assertEquals("klmno", lines[2]);
    }

    public void testPrintWrappedPadsContinuationLines()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        formatter.printWrapped(pw, 20, 5, "aaaaaa bbbbbb cccccc dddddd eeeeee ffffff");
        pw.flush();

        String[] lines = getLines(out.toString());
        assertTrue("expected wrapping: " + out.toString(), lines.length > 1);
        assertFalse("first line must not be padded", lines[0].startsWith(" "));
        for (int i = 1; i < lines.length; i++)
        {
            assertTrue("continuation line not padded with 5 spaces: '" + lines[i] + "'",
                    lines[i].startsWith("     "));
        }
    }

    public void testPrintWrappedRespectsEmbeddedNewline()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);

        formatter.printWrapped(pw, 80, "line one\nline two");
        pw.flush();

        String[] lines = getLines(out.toString());
        assertEquals(2, lines.length);
        assertEquals("line one", lines[0]);
        assertEquals("line two", lines[1]);
    }

    // ---------------------------------------------------------------- printHelp

    public void testPrintHelpFullLayout()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", "all", false, "do not hide entries starting with .");
        options.addOption("b", "block-size", true, "use SIZE-byte blocks");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "ls", "List directory contents", options, 2, 4,
                "Report bugs to dev@example.com", false);
        pw.flush();

        String result = out.toString();
        assertTrue(result, result.startsWith("usage: ls" + EOL));
        assertTrue(result, result.indexOf("List directory contents") >= 0);
        assertTrue(result, result.indexOf("-a,--all") >= 0);
        assertTrue(result, result.indexOf("-b,--block-size") >= 0);
        assertTrue(result, result.indexOf("do not hide entries starting with .") >= 0);
        assertTrue(result, result.indexOf("Report bugs to dev@example.com") >= 0);

        // header before options before footer
        assertTrue(result.indexOf("List directory contents") < result.indexOf("-a,--all"));
        assertTrue(result.indexOf("-a,--all") < result.indexOf("Report bugs to dev@example.com"));
    }

    public void testPrintHelpAutoUsageGeneratesSyntaxFromOptions()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("x", false, "the x option");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "prog", null, options, 1, 3, null, true);
        pw.flush();

        String[] lines = getLines(out.toString());
        assertEquals("usage: prog [-x]", lines[0]);
    }

    public void testPrintHelpWithoutAutoUsageKeepsGivenSyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("x", false, "the x option");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "prog", null, options, 1, 3, null, false);
        pw.flush();

        String[] lines = getLines(out.toString());
        assertEquals("usage: prog", lines[0]);
    }

    public void testPrintHelpBlankHeaderAndFooterAreSkipped()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "alpha");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "app", "   ", options, 1, 3, "   ", false);
        pw.flush();

        String[] lines = getLines(out.toString());
        assertEquals("usage: app", lines[0]);
        assertEquals(2, lines.length);
        assertTrue(lines[1], lines[1].indexOf("-a") >= 0);
        assertTrue(lines[1], lines[1].indexOf("alpha") >= 0);
    }

    public void testPrintHelpNullSyntaxThrows()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "desc");
        PrintWriter pw = new PrintWriter(new StringWriter());

        try
        {
            formatter.printHelp(pw, 80, null, "header", options, 1, 3, "footer", false);
            fail("expected IllegalArgumentException for null cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            assertEquals("cmdLineSyntax not provided", e.getMessage());
        }
    }

    public void testPrintHelpEmptySyntaxThrows()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "desc");

        try
        {
            formatter.printHelp("", options);
            fail("expected IllegalArgumentException for empty cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            assertEquals("cmdLineSyntax not provided", e.getMessage());
        }
    }

    public void testPrintHelpWritesToSystemOut()
    {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setOut(new PrintStream(captured));
        try
        {
            HelpFormatter formatter = new HelpFormatter();
            Options options = new Options();
            options.addOption("a", "all", false, "show all");
            formatter.printHelp("myapp", options);
        }
        finally
        {
            System.setOut(originalOut);
        }

        String result = captured.toString();
        assertTrue(result, result.indexOf("usage: myapp") >= 0);
        assertTrue(result, result.indexOf("-a,--all") >= 0);
        assertTrue(result, result.indexOf("show all") >= 0);
    }

    public void testPrintHelpWidthOverloadWrapsHeader()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "alpha");

        StringWriter out = new StringWriter();
        PrintWriter pw = new PrintWriter(out);
        String header = "aaaa bbbb cccc dddd eeee ffff gggg hhhh iiii jjjj kkkk llll";
        formatter.printHelp(pw, 20, "app", header, options, 1, 3, null);
        pw.flush();

        String[] lines = getLines(out.toString());
        // usage line + at least two wrapped header lines + one option line
        assertTrue("expected wrapped output: " + out.toString(), lines.length >= 4);
        assertEquals("usage: app", lines[0]);
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line exceeds requested width: '" + lines[i] + "'", lines[i].length() <= 20);
        }
    }
}
