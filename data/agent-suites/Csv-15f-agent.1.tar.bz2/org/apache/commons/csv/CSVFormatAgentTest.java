/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.StringReader;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.List;

import org.junit.Test;

/**
 * Independently written tests for the public API of {@link CSVFormat}.
 *
 * <p>
 * These tests exercise the immutable "wither" builders, the predefined formats, the accessors, the
 * {@code equals}/{@code hashCode}/{@code toString} contract and the printing/parsing entry points, including a number of
 * boundary and error conditions.
 * </p>
 */
public class CSVFormatAgentTest {

    /** Builds a minimal {@link ResultSetMetaData} that only answers column count and label queries. */
    private static ResultSetMetaData metaDataWithLabels(final String... labels) {
        return (ResultSetMetaData) Proxy.newProxyInstance(CSVFormatAgentTest.class.getClassLoader(),
                new Class<?>[] { ResultSetMetaData.class }, new InvocationHandler() {
                    @Override
                    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
                        final String name = method.getName();
                        if ("getColumnCount".equals(name)) {
                            return Integer.valueOf(labels.length);
                        }
                        if ("getColumnLabel".equals(name)) {
                            return labels[((Integer) args[0]).intValue() - 1];
                        }
                        if ("toString".equals(name)) {
                            return "metaDataWithLabels";
                        }
                        if ("hashCode".equals(name)) {
                            return Integer.valueOf(System.identityHashCode(proxy));
                        }
                        if ("equals".equals(name)) {
                            return Boolean.valueOf(proxy == args[0]);
                        }
                        throw new UnsupportedOperationException(name);
                    }
                });
    }

    // ------------------------------------------------------------------
    // Predefined formats and static factories
    // ------------------------------------------------------------------

    @Test
    public void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getAutoFlush());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
    }

    @Test
    public void testRFC4180FormatProperties() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getQuoteMode());
        assertEquals("\r\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getTrailingDelimiter());
    }

    @Test
    public void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertNull(format.getQuoteMode());
    }

    @Test
    public void testMySQLFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals('\t', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testTDFFormatProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals('\t', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    public void testNewFormatHasMinimalState() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals('|', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getAutoFlush());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatRejectsCarriageReturnDelimiter() {
        CSVFormat.newFormat('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatRejectsLineFeedDelimiter() {
        CSVFormat.newFormat('\n');
    }

    @Test
    public void testValueOfReturnsThePredefinedSingletons() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertSame(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertSame(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValueOfUnknownNameThrows() {
        CSVFormat.valueOf("no-such-format");
    }

    @Test
    public void testPredefinedEnumExposesNonNullFormats() {
        for (final CSVFormat.Predefined predefined : CSVFormat.Predefined.values()) {
            assertNotNull(predefined.name(), predefined.getFormat());
        }
        assertSame(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertSame(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertSame(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
    }

    // ------------------------------------------------------------------
    // Character-valued "wither" builders
    // ------------------------------------------------------------------

    @Test
    public void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', format.getDelimiter());
        // original is untouched (immutability)
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertNotSame(CSVFormat.DEFAULT, format);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterRejectsCarriageReturn() {
        CSVFormat.DEFAULT.withDelimiter('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterRejectsLineFeed() {
        CSVFormat.DEFAULT.withDelimiter('\n');
    }

    @Test
    public void testWithQuoteCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertTrue(format.isQuoteCharacterSet());
    }

    @Test
    public void testWithQuoteCharacterDisabled() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteRejectsLineBreak() {
        CSVFormat.DEFAULT.withQuote('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteEqualToDelimiterThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withQuote('!');
    }

    @Test
    public void testWithCommentMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
    }

    @Test
    public void testWithCommentMarkerDisabled() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerRejectsLineBreak() {
        CSVFormat.DEFAULT.withCommentMarker('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerEqualToQuoteThrows() {
        // CSVFormat.DEFAULT uses '"' as the quote character.
        CSVFormat.DEFAULT.withCommentMarker('"');
    }

    @Test
    public void testWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test
    public void testWithEscapeDisabled() {
        final CSVFormat format = CSVFormat.MYSQL.withEscape((Character) null);
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeRejectsLineBreak() {
        CSVFormat.DEFAULT.withEscape('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeEqualToDelimiterThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withEscape('!');
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertFalse(CSVFormat.MYSQL.withNullString(null).isNullStringSet());
    }

    @Test
    public void testWithQuoteMode() {
        assertEquals(QuoteMode.ALL, CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).getQuoteMode());
        assertEquals(QuoteMode.NON_NUMERIC, CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC).getQuoteMode());
        // clearing a previously-set mode is allowed as long as it is not NONE
        assertNull(CSVFormat.MYSQL.withQuoteMode(null).getQuoteMode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteModeNoneWithoutEscapeThrows() {
        CSVFormat.newFormat('!').withQuoteMode(QuoteMode.NONE);
    }

    @Test
    public void testWithQuoteModeNoneRequiresEscape() {
        final CSVFormat format = CSVFormat.newFormat('!').withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
    }

    @Test
    public void testWithRecordSeparator() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\r", CSVFormat.DEFAULT.withRecordSeparator('\r').getRecordSeparator());
        assertEquals("\r\n", CSVFormat.DEFAULT.withRecordSeparator("\r\n").getRecordSeparator());
    }

    // ------------------------------------------------------------------
    // Header related builders
    // ------------------------------------------------------------------

    @Test
    public void testWithHeaderCopiesTheArray() {
        final String[] header = { "a", "b", "c" };
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
        header[0] = "mutated";
        assertArrayEquals(new String[] { "a", "b", "c" }, format.getHeader());
        // every accessor call returns a fresh copy
        assertNotSame(format.getHeader(), format.getHeader());
    }

    @Test
    public void testWithHeaderNullAndEmpty() {
        assertNull(CSVFormat.DEFAULT.withHeader((String[]) null).getHeader());
        final String[] parsed = CSVFormat.DEFAULT.withHeader().getHeader();
        assertNotNull(parsed);
        assertEquals(0, parsed.length);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithHeaderRejectsDuplicates() {
        CSVFormat.DEFAULT.withHeader("A", "B", "A");
    }

    @Test
    public void testWithHeaderFromEnum() {
        assertArrayEquals(new String[] { "Alpha", "Beta", "Gamma" },
                CSVFormat.DEFAULT.withHeader(HeaderEnum.class).getHeader());
    }

    @Test
    public void testWithHeaderFromNullEnum() {
        assertNull(CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null).getHeader());
    }

    @Test
    public void testWithHeaderFromEmptyEnum() {
        assertEquals(0, CSVFormat.DEFAULT.withHeader(EmptyHeaderEnum.class).getHeader().length);
    }

    @Test
    public void testWithHeaderFromResultSetMetaData() throws Exception {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(metaDataWithLabels("ID", "NAME", "AGE"));
        assertArrayEquals(new String[] { "ID", "NAME", "AGE" }, format.getHeader());
    }

    @Test
    public void testWithHeaderFromNullResultSetAndMetaData() throws Exception {
        assertNull(CSVFormat.DEFAULT.withHeader((ResultSet) null).getHeader());
        assertNull(CSVFormat.DEFAULT.withHeader((ResultSetMetaData) null).getHeader());
    }

    @Test
    public void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("Generated", Integer.valueOf(2016));
        // non-String values are converted via toString()
        assertArrayEquals(new String[] { "Generated", "2016" }, format.getHeaderComments());
        assertNotSame(format.getHeaderComments(), format.getHeaderComments());
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    // ------------------------------------------------------------------
    // Boolean "wither" builders and their accessors
    // ------------------------------------------------------------------

    @Test
    public void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.withAutoFlush(false).getAutoFlush());
    }

    @Test
    public void testWithMethodsAlwaysReturnANewInstance() {
        final CSVFormat base = CSVFormat.DEFAULT;
        assertNotSame(base, base.withDelimiter(';'));
        assertNotSame(base, base.withQuote('\''));
        assertNotSame(base, base.withCommentMarker('#'));
        assertNotSame(base, base.withEscape('\\'));
        assertNotSame(base, base.withNullString("x"));
        assertNotSame(base, base.withHeader("h"));
        assertNotSame(base, base.withHeaderComments("c"));
        assertNotSame(base, base.withRecordSeparator('\n'));
        assertNotSame(base, base.withQuoteMode(QuoteMode.ALL));
        assertNotSame(base, base.withIgnoreEmptyLines(false));
        assertNotSame(base, base.withIgnoreSurroundingSpaces(true));
        assertNotSame(base, base.withIgnoreHeaderCase(true));
        assertNotSame(base, base.withSkipHeaderRecord(true));
        assertNotSame(base, base.withTrailingDelimiter(true));
        assertNotSame(base, base.withTrim(true));
        assertNotSame(base, base.withAllowMissingColumnNames(true));
        assertNotSame(base, base.withAutoFlush(true));
        // and the shared singleton is never mutated
        assertEquals(',', base.getDelimiter());
        assertEquals("\r\n", base.getRecordSeparator());
        assertFalse(base.getTrim());
    }

    // ------------------------------------------------------------------
    // equals / hashCode / toString
    // ------------------------------------------------------------------

    @Test
    public void testEqualsIsReflexiveAndRejectsNullAndOtherTypes() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertTrue(format.equals(format));
        assertFalse(format.equals(null));
        assertFalse(format.equals("not a CSVFormat"));
        assertFalse(format.equals(Integer.valueOf(42)));
    }

    @Test
    public void testEqualsAndHashCodeForACopy() {
        final CSVFormat base = CSVFormat.newFormat(';')
                .withQuote('"')
                .withRecordSeparator("\r\n")
                .withCommentMarker('#')
                .withEscape('\\')
                .withNullString("NULL")
                .withHeader("x", "y")
                .withIgnoreEmptyLines(true)
                .withIgnoreSurroundingSpaces(true)
                .withSkipHeaderRecord(true)
                .withQuoteMode(QuoteMode.MINIMAL);
        final CSVFormat copy = base.withDelimiter(base.getDelimiter());
        assertNotSame(base, copy);
        assertTrue(base.equals(copy));
        assertTrue(copy.equals(base));
        assertEquals(base.hashCode(), copy.hashCode());
    }

    @Test
    public void testEqualsDistinguishesDelimiter() {
        assertFalse(CSVFormat.newFormat(',').equals(CSVFormat.newFormat(';')));
    }

    @Test
    public void testEqualsDistinguishesQuoteMode() {
        final CSVFormat all = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        final CSVFormat minimal = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        assertFalse(all.equals(minimal));
    }

    @Test
    public void testEqualsDistinguishesHeader() {
        final CSVFormat ab = CSVFormat.DEFAULT.withHeader("A", "B");
        final CSVFormat ba = CSVFormat.DEFAULT.withHeader("B", "A");
        final CSVFormat ab2 = CSVFormat.DEFAULT.withHeader("A", "B");
        assertFalse(ab.equals(ba));
        assertTrue(ab.equals(ab2));
        assertEquals(ab.hashCode(), ab2.hashCode());
    }

    @Test
    public void testEqualsDistinguishesIgnoreEmptyLines() {
        // DEFAULT ignores empty lines, RFC4180 does not; every other compared field is identical.
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.RFC4180));
    }

    @Test
    public void testEqualsIgnoresFieldsThatAreNotPartOfTheContract() {
        final CSVFormat base = CSVFormat.DEFAULT;
        assertTrue(base.equals(base.withTrim(true)));
        assertTrue(base.equals(base.withTrailingDelimiter(true)));
        assertTrue(base.equals(base.withIgnoreHeaderCase(true)));
        assertTrue(base.equals(base.withAllowMissingColumnNames(true)));
        assertTrue(base.equals(base.withAutoFlush(true)));
    }

    @Test
    public void testToStringForDefault() {
        assertEquals(
                "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> EmptyLines:ignored SkipHeaderRecord:false",
                CSVFormat.DEFAULT.toString());
    }

    @Test
    public void testToStringForNewFormat() {
        assertEquals("Delimiter=<;> SkipHeaderRecord:false", CSVFormat.newFormat(';').toString());
    }

    // ------------------------------------------------------------------
    // format(Object...)
    // ------------------------------------------------------------------

    @Test
    public void testFormatEmptyProducesEmptyString() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatUsesConfiguredDelimiter() {
        assertEquals("a;b;c", CSVFormat.DEFAULT.withDelimiter(';').format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    public void testFormatDoublesEmbeddedQuoteCharacter() {
        assertEquals("\"a\"\"b\"", CSVFormat.DEFAULT.format("a\"b"));
    }

    @Test
    public void testFormatWithoutQuoteCharacterLeavesValueRaw() {
        assertEquals("a,b,c", CSVFormat.newFormat(',').format("a", "b", "c"));
    }

    @Test
    public void testFormatWithEscapeCharacter() {
        assertEquals("a\\,b,c", CSVFormat.newFormat(',').withEscape('\\').format("a,b", "c"));
    }

    @Test
    public void testFormatWithEscapedNewline() {
        assertEquals("a\\nb", CSVFormat.newFormat(',').withEscape('\\').format("a\nb"));
    }

    @Test
    public void testFormatQuoteModeAll() {
        assertEquals("\"a\",\"b\"", CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).format("a", "b"));
    }

    @Test
    public void testFormatQuoteModeNonNumeric() {
        assertEquals("\"a\",1",
                CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC).format("a", Integer.valueOf(1)));
    }

    @Test
    public void testFormatQuoteModeNone() {
        assertEquals("a\\,b", CSVFormat.DEFAULT.withEscape('\\').withQuoteMode(QuoteMode.NONE).format("a,b"));
    }

    @Test
    public void testFormatNullWithoutNullStringProducesEmptyField() {
        assertEquals("x,,y", CSVFormat.DEFAULT.format("x", null, "y"));
    }

    @Test
    public void testFormatNullWithNullString() {
        assertEquals("x,NULL,y", CSVFormat.DEFAULT.withNullString("NULL").format("x", null, "y"));
    }

    @Test
    public void testFormatMySqlEscapesAndNullString() {
        assertEquals("a\tb\t\\N", CSVFormat.MYSQL.format("a", "b", null));
    }

    @Test(expected = NullPointerException.class)
    public void testFormatNullArrayThrowsNullPointerException() {
        CSVFormat.DEFAULT.format((Object[]) null);
    }

    // ------------------------------------------------------------------
    // parse / print entry points
    // ------------------------------------------------------------------

    @Test
    public void testParseReader() throws Exception {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\nx,y,z\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(0).get(2));
            assertEquals("z", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithSuppliedHeaderKeepsFirstRowAsData() throws Exception {
        final CSVParser parser = CSVFormat.DEFAULT.withHeader("A", "B").parse(new StringReader("1,2\r\n3,4\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("2", records.get(0).get("B"));
            assertEquals("4", records.get(1).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullReaderThrows() throws Exception {
        CSVFormat.DEFAULT.parse(null);
    }

    @Test
    public void testPrintToAppendable() throws Exception {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        printer.printRecord("a", "b");
        printer.close();
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPrintNullAppendableThrows() throws Exception {
        CSVFormat.DEFAULT.print((Appendable) null);
    }

    @Test
    public void testPrintEmitsHeaderWhenTheFormatDefinesOne() throws Exception {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = CSVFormat.DEFAULT.withHeader("H1", "H2").print(sb);
        printer.close();
        assertEquals("H1,H2\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordToAppendable() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWritesRecordSeparator() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withTrailingDelimiter().println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithoutRecordSeparatorWritesNothing() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.newFormat(',').println(sb);
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintSingleValueAtStartOfRecord() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testPrintSingleValueMidRecordPrependsDelimiter() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("x", sb, false);
        assertEquals(",x", sb.toString());
    }

    @Test
    public void testPrintSingleNullValue() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintSingleNullValueWithNullString() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withNullString("N/A").print(null, sb, true);
        assertEquals("N/A", sb.toString());
    }

    @Test
    public void testPrintValueAppliesTrim() throws Exception {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withTrim().print("  hello  ", sb, true);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testPrinterWritesToSystemOut() throws Exception {
        final PrintStream original = System.out;
        final ByteArrayOutputStream captured = new ByteArrayOutputStream();
        try {
            System.setOut(new PrintStream(captured, true, "UTF-8"));
            final CSVPrinter printer = CSVFormat.DEFAULT.printer();
            printer.printRecord("x", "y");
            printer.flush();
        } finally {
            System.setOut(original);
        }
        assertEquals("x,y\r\n", new String(captured.toByteArray(), "UTF-8"));
    }

    @Test
    public void testPrintToFile() throws Exception {
        final File file = File.createTempFile("csvformatagent", ".csv");
        file.deleteOnExit();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
        try {
            printer.printRecord("a", "b", "c");
        } finally {
            printer.close();
        }
        assertEquals("a,b,c\r\n", new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
    }

    @Test
    public void testPrintToPath() throws Exception {
        final File file = File.createTempFile("csvformatagent", ".csv");
        file.deleteOnExit();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(file.toPath(), StandardCharsets.UTF_8);
        try {
            printer.printRecord("1", "2");
        } finally {
            printer.close();
        }
        assertEquals("1,2\r\n", new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
    }

    // ------------------------------------------------------------------
    // Fixtures
    // ------------------------------------------------------------------

    public enum HeaderEnum {
        Alpha, Beta, Gamma
    }

    public enum EmptyHeaderEnum {
    }
}
