package org.apache.commons.cli2.commandline;

import junit.framework.TestCase;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class WriteableCommandLineImplAgentTest extends TestCase {

    private DefaultOptionBuilder obuilder;
    private GroupBuilder gbuilder;

    private Option optA;
    private Option optB;
    private Option optC;
    private Group root;

    protected void setUp() throws Exception {
        super.setUp();
        obuilder = new DefaultOptionBuilder();
        gbuilder = new GroupBuilder();

        optA = obuilder.withShortName("a").withLongName("alpha").withDescription("Alpha option").create();
        optB = obuilder.withShortName("b").withLongName("beta").withDescription("Beta option").create();
        optC = obuilder.withShortName("c").withLongName("gamma").withDescription("Gamma option").create();

        root = gbuilder.withOption(optA).withOption(optB).withOption(optC).withName("root").create();
    }

    private WriteableCommandLineImpl newCommandLine() {
        List arguments = new ArrayList();
        arguments.add("-a");
        return new WriteableCommandLineImpl(root, arguments);
    }

    public void testConstructor() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli);
        assertNotNull(wcli.getOptions());
        assertNotNull(wcli.getOptionTriggers());
        assertNotNull(wcli.getProperties());
    }

    public void testAddOptionAndHasOption() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertFalse(wcli.hasOption(optA));

        wcli.addOption(optA);
        assertTrue(wcli.hasOption(optA));
        assertFalse(wcli.hasOption(optB));

        assertTrue(wcli.getOptions().contains(optA));
    }

    public void testAddOptionMultiple() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addOption(optA);
        wcli.addOption(optB);

        List options = wcli.getOptions();
        assertTrue(options.contains(optA));
        assertTrue(options.contains(optB));
        assertFalse(options.contains(optC));
    }

    public void testGetOptionUnknownTriggerReturnsNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNull(wcli.getOption("--this-trigger-does-not-exist"));
    }

    public void testGetOptionFindsAddedOptionByTrigger() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addOption(optA);

        Set triggers = optA.getTriggers();
        assertFalse(triggers.isEmpty());
        String trigger = (String) triggers.iterator().next();

        assertSame(optA, wcli.getOption(trigger));
    }

    public void testGetOptionTriggersIncludesAddedOptionTriggers() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addOption(optA);

        Set triggers = optA.getTriggers();
        String trigger = (String) triggers.iterator().next();

        assertTrue(wcli.getOptionTriggers().contains(trigger));
    }

    public void testAddValueAndGetUndefaultedValues() {
        WriteableCommandLineImpl wcli = newCommandLine();

        List none = wcli.getUndefaultedValues(optA);
        assertNotNull(none);
        assertTrue(none.isEmpty());

        wcli.addValue(optA, "value1");
        List values = wcli.getUndefaultedValues(optA);
        assertEquals(1, values.size());
        assertEquals("value1", values.get(0));

        wcli.addValue(optA, "value2");
        values = wcli.getUndefaultedValues(optA);
        assertEquals(2, values.size());
        assertEquals("value1", values.get(0));
        assertEquals("value2", values.get(1));
    }

    public void testAddValueIsScopedToOption() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addValue(optA, "onlyForA");

        assertTrue(wcli.getUndefaultedValues(optA).contains("onlyForA"));
        assertTrue(wcli.getUndefaultedValues(optB).isEmpty());
    }

    public void testGetValuesReturnsDefaultWhenNoneFound() {
        WriteableCommandLineImpl wcli = newCommandLine();
        List defaults = new ArrayList();
        defaults.add("fallback");

        List result = wcli.getValues(optA, defaults);
        assertEquals(defaults, result);
    }

    public void testGetValuesReturnsAddedValuesOverDefault() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addValue(optA, "real-value");

        List defaults = new ArrayList();
        defaults.add("fallback");

        List result = wcli.getValues(optA, defaults);
        assertTrue(result.contains("real-value"));
        assertFalse(result.contains("fallback"));
    }

    public void pruned_testSetDefaultValuesUsedByGetValuesButNotUndefaulted() {
        WriteableCommandLineImpl wcli = newCommandLine();
        List setDefaults = new ArrayList();
        setDefaults.add("d1");
        setDefaults.add("d2");

        wcli.setDefaultValues(optC, setDefaults);

        List callerDefault = new ArrayList();
        callerDefault.add("shouldNotAppear");

        List values = wcli.getValues(optC, callerDefault);
        assertTrue(values.contains("d1"));
        assertTrue(values.contains("d2"));

        List undefaulted = wcli.getUndefaultedValues(optC);
        assertNotNull(undefaulted);
        assertTrue(undefaulted.isEmpty());
    }

    public void testSetDefaultValuesEmptyList() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.setDefaultValues(optA, new ArrayList());

        List callerDefault = new ArrayList();
        callerDefault.add("shouldStillAppearSinceNoDefaultsSet");
        List values = wcli.getValues(optA, callerDefault);
        assertNotNull(values);
    }

    public void testAddSwitchAndGetSwitch() {
        WriteableCommandLineImpl wcli = newCommandLine();

        assertEquals(Boolean.FALSE, wcli.getSwitch(optA, Boolean.FALSE));

        wcli.addSwitch(optA, true);
        assertEquals(Boolean.TRUE, wcli.getSwitch(optA, Boolean.FALSE));
    }

    public void testAddSwitchFalseValue() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addSwitch(optB, false);
        assertEquals(Boolean.FALSE, wcli.getSwitch(optB, Boolean.TRUE));
    }

    public void pruned_testSetDefaultSwitchUsedWhenNoneAdded() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.setDefaultSwitch(optC, Boolean.TRUE);

        assertEquals(Boolean.TRUE, wcli.getSwitch(optC, Boolean.FALSE));
    }

    public void testAddPropertyDefaultSet() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNull(wcli.getProperty("missing.key"));

        wcli.addProperty("key1", "value1");
        assertEquals("value1", wcli.getProperty("key1"));

        wcli.addProperty("key1", "value2");
        assertEquals("value2", wcli.getProperty("key1"));
    }

    public void testGetPropertiesDefaultSet() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getProperties());

        wcli.addProperty("key1", "value1");
        assertTrue(wcli.getProperties().contains("key1"));
    }

    public void testAddPropertyForOption() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertEquals("def", wcli.getProperty(optA, "p1", "def"));

        wcli.addProperty(optA, "p1", "v1");
        assertEquals("v1", wcli.getProperty(optA, "p1", "def"));
    }

    public void testAddPropertyForOptionReplacesExistingValue() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addProperty(optA, "p1", "v1");
        wcli.addProperty(optA, "p1", "v2");
        assertEquals("v2", wcli.getProperty(optA, "p1", "def"));
    }

    public void testGetPropertiesForOption() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getProperties(optA));
        assertTrue(wcli.getProperties(optA).isEmpty());

        wcli.addProperty(optA, "p1", "v1");
        assertTrue(wcli.getProperties(optA).contains("p1"));
    }

    public void testOptionPropertiesAreIndependentFromDefaultPropertySet() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addProperty(optA, "shared", "optionScoped");

        assertNull(wcli.getProperty("shared"));
        assertEquals("optionScoped", wcli.getProperty(optA, "shared", null));
    }

    public void testOptionPropertiesAreIndependentBetweenOptions() {
        WriteableCommandLineImpl wcli = newCommandLine();
        wcli.addProperty(optA, "p", "forA");

        assertEquals("def", wcli.getProperty(optB, "p", "def"));
    }

    public void testLooksLikeOptionForKnownTrigger() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Set triggers = optA.getTriggers();
        String trigger = (String) triggers.iterator().next();

        assertTrue(wcli.looksLikeOption(trigger));
    }

    public void testLooksLikeOptionForPlainArgument() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertFalse(wcli.looksLikeOption("plainArgumentWithoutPrefix"));
    }

    public void testToStringNotNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.toString());
    }

    public void testGetNormalisedNotNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getNormalised());
    }

    public void testGetOptionsInitiallyEmptyBeforeAdd() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getOptions());
        assertFalse(wcli.getOptions().contains(optA));
    }

    public void testGetSwitchReturnsSuppliedDefaultForUnknownOption() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Boolean def = Boolean.TRUE;
        assertEquals(def, wcli.getSwitch(optA, def));
    }
}
