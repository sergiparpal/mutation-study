/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Tests the public API of {@link CSVParser}: the static {@code parse} factory methods, the two public
 * constructors and the observable accessors ({@code getRecords}, {@code iterator}, {@code getHeaderMap},
 * {@code getRecordNumber}, {@code getCurrentLineNumber}, {@code getFirstEndOfLine}, {@code isClosed}).
 */
public class CSVParserAgentTest {

    private static File tempCsv(final String content) throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        Files.write(file.toPath(), content.getBytes(StandardCharsets.UTF_8));
        return file;
    }

    // ------------------------------------------------------------------
    // parse(String, CSVFormat)
    // ------------------------------------------------------------------

    @Test
    public void testParseStringSingleRecord() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertArrayEquals(new String[] { "a", "b", "c" }, records.get(0).values());
            assertEquals(1L, records.get(0).getRecordNumber());
        }
    }

    @Test
    public void testParseStringMultipleRecordsAssignsSequentialRecordNumbers() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertArrayEquals(new String[] { "a", "b" }, records.get(0).values());
            assertArrayEquals(new String[] { "c", "d" }, records.get(1).values());
            assertArrayEquals(new String[] { "e", "f" }, records.get(2).values());
            assertEquals(1L, records.get(0).getRecordNumber());
            assertEquals(2L, records.get(1).getRecordNumber());
            assertEquals(3L, records.get(2).getRecordNumber());
            assertEquals(3L, parser.getRecordNumber());
        }
    }

    @Test
    public void testParseEmptyStringYieldsNoRecords() throws IOException {
        try (final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertTrue(records.isEmpty());
            assertEquals(0L, parser.getRecordNumber());
            assertFalse(parser.iterator().hasNext());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullStringThrows() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullFormatThrows() throws IOException {
        CSVParser.parse("a,b,c", null);
    }

    // ------------------------------------------------------------------
    // parse(Reader, CSVFormat) and the constructors
    // ------------------------------------------------------------------

    @Test
    public void testParseReader() throws IOException {
        try (final CSVParser parser = CSVParser.parse(new StringReader("x,y,z\n"), CSVFormat.DEFAULT)) {
            assertArrayEquals(new String[] { "x", "y", "z" }, parser.getRecords().get(0).values());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullReaderThrows() throws IOException {
        CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrows() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrows() throws IOException {
        new CSVParser(new StringReader("a"), null);
    }

    @Test
    public void testConstructorWithCharacterOffsetAndRecordNumber() throws IOException {
        try (final CSVParser parser = new CSVParser(new StringReader("a,b,c\nd,e,f\n"), CSVFormat.DEFAULT, 100, 5)) {
            // recordNumber is stored as (start - 1) until the first record is produced
            assertEquals(4L, parser.getRecordNumber());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(5L, records.get(0).getRecordNumber());
            assertEquals(6L, records.get(1).getRecordNumber());
            // character position is offset by the supplied characterOffset
            assertEquals(100L, records.get(0).getCharacterPosition());
            assertEquals(106L, records.get(1).getCharacterPosition());
            assertEquals(6L, parser.getRecordNumber());
        }
    }

    // ------------------------------------------------------------------
    // parse(File / Path / InputStream / URL, Charset, CSVFormat)
    // ------------------------------------------------------------------

    @Test
    public void testParseFile() throws IOException {
        final File file = tempCsv("a,b,c\n1,2,3\n");
        try (final CSVParser parser = CSVParser.parse(file, StandardCharsets.UTF_8, CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertArrayEquals(new String[] { "a", "b", "c" }, records.get(0).values());
            assertArrayEquals(new String[] { "1", "2", "3" }, records.get(1).values());
        }
    }

    @Test
    public void testParsePath() throws IOException {
        final File file = tempCsv("p,q\n");
        try (final CSVParser parser = CSVParser.parse(file.toPath(), StandardCharsets.UTF_8, CSVFormat.DEFAULT)) {
            assertArrayEquals(new String[] { "p", "q" }, parser.getRecords().get(0).values());
        }
    }

    @Test
    public void testParseInputStream() throws IOException {
        final InputStream in = new ByteArrayInputStream("m,n\n1,2\n".getBytes(StandardCharsets.UTF_8));
        try (final CSVParser parser = CSVParser.parse(in, StandardCharsets.UTF_8, CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertArrayEquals(new String[] { "1", "2" }, records.get(1).values());
        }
    }

    @Test
    public void testParseUrl() throws IOException {
        final URL url = tempCsv("u,v,w\n").toURI().toURL();
        try (final CSVParser parser = CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT)) {
            assertArrayEquals(new String[] { "u", "v", "w" }, parser.getRecords().get(0).values());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullFileThrows() throws IOException {
        CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullPathThrows() throws IOException {
        CSVParser.parse((java.nio.file.Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullInputStreamThrows() throws IOException {
        CSVParser.parse((InputStream) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullUrlThrows() throws IOException {
        CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
    }

    // ------------------------------------------------------------------
    // getRecords()
    // ------------------------------------------------------------------

    @Test
    public void testGetRecordsStartsAtCurrentPosition() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a\nb\nc\nd\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals("a", it.next().get(0));
            assertEquals("b", it.next().get(0));
            final List<CSVRecord> rest = parser.getRecords();
            assertEquals(2, rest.size());
            assertEquals("c", rest.get(0).get(0));
            assertEquals("d", rest.get(1).get(0));
            assertEquals(3L, rest.get(0).getRecordNumber());
            assertEquals(4L, rest.get(1).getRecordNumber());
        }
    }

    @Test
    public void testGetRecordsDrainsSoSecondCallIsEmpty() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT)) {
            assertEquals(2, parser.getRecords().size());
            assertTrue(parser.getRecords().isEmpty());
        }
    }

    @Test(expected = IOException.class)
    public void testGetRecordsThrowsIOExceptionOnUnterminatedQuote() throws IOException {
        try (final CSVParser parser = CSVParser.parse("\"a,b\nc,d", CSVFormat.DEFAULT)) {
            parser.getRecords();
        }
    }

    // ------------------------------------------------------------------
    // iterator()
    // ------------------------------------------------------------------

    @Test
    public void testIteratorReturnsSameInstance() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT)) {
            assertSame(parser.iterator(), parser.iterator());
        }
    }

    @Test
    public void testEnhancedForLoopVisitsEveryRecord() throws IOException {
        final String[][] expected = { { "a", "b" }, { "c", "d" }, { "e", "f" } };
        try (final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT)) {
            int i = 0;
            for (final CSVRecord record : parser) {
                assertArrayEquals(expected[i], record.values());
                assertEquals((long) (i + 1), record.getRecordNumber());
                i++;
            }
            assertEquals(3, i);
        }
    }

    @Test
    public void testIteratorHasNextIsIdempotentAndDoesNotSkipRecords() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            assertEquals("a", it.next().get(0));
            // next() without a preceding hasNext() call must still advance in order
            assertEquals("b", it.next().get(0));
            assertTrue(it.hasNext());
            assertEquals("c", it.next().get(0));
            assertFalse(it.hasNext());
        }
    }

    @Test
    public void testIteratorNextThrowsWhenExhausted() throws IOException {
        try (final CSVParser parser = CSVParser.parse("only\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals("only", it.next().get(0));
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testIteratorRemoveIsUnsupported() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT)) {
            parser.iterator().remove();
        }
    }

    @Test
    public void testIteratorWrapsIOExceptionInIllegalStateException() throws IOException {
        try (final CSVParser parser = CSVParser.parse("\"a,b\nc,d", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.hasNext();
                fail("Expected IllegalStateException");
            } catch (final IllegalStateException e) {
                assertTrue(e.getCause() instanceof IOException);
            }
        }
    }

    @Test
    public void testIteratorAfterGetRecordsHasNoNext() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT)) {
            parser.getRecords();
            assertFalse(parser.iterator().hasNext());
        }
    }

    // ------------------------------------------------------------------
    // close() / isClosed()
    // ------------------------------------------------------------------

    @Test
    public void testIsClosedTransitionsOnClose() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testCloseStopsIteration() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertEquals("a", it.next().get(0));
        parser.close();
        assertTrue(parser.isClosed());
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException after close");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    // ------------------------------------------------------------------
    // getHeaderMap()
    // ------------------------------------------------------------------

    @Test
    public void testGetHeaderMapNullWhenFormatHasNoHeader() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT)) {
            assertNull(parser.getHeaderMap());
        }
    }

    @Test
    public void testGetHeaderMapWithExplicitHeaderKeepsColumnOrderAndDoesNotConsumeData() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        try (final CSVParser parser = CSVParser.parse("1,2,3\n", format)) {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Arrays.asList("A", "B", "C"), new ArrayList<>(headerMap.keySet()));
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));
            // an explicit header does not skip the first line unless asked to
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("3", records.get(0).get("C"));
        }
    }

    @Test
    public void testGetHeaderMapReturnsIndependentCopy() throws IOException {
        try (final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT.withHeader("A"))) {
            final Map<String, Integer> first = parser.getHeaderMap();
            final Map<String, Integer> second = parser.getHeaderMap();
            assertNotSame(first, second);
            first.put("INJECTED", Integer.valueOf(99));
            assertFalse(parser.getHeaderMap().containsKey("INJECTED"));
        }
    }

    @Test
    public void testHeaderReadFromFirstRecordWhenHeaderIsEmpty() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        try (final CSVParser parser = CSVParser.parse("A,B,C\n1,2,3\n4,5,6\n", format)) {
            assertEquals(Arrays.asList("A", "B", "C"), new ArrayList<>(parser.getHeaderMap().keySet()));
            // the header line is consumed during construction; it does not count towards getRecordNumber()
            assertEquals(0L, parser.getRecordNumber());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("6", records.get(1).get("C"));
            assertEquals(1L, records.get(0).getRecordNumber());
            assertEquals(2L, records.get(1).getRecordNumber());
            assertEquals(2L, parser.getRecordNumber());
        }
    }

    @Test
    public void testSkipHeaderRecordWithExplicitHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C").withSkipHeaderRecord();
        try (final CSVParser parser = CSVParser.parse("A,B,C\n1,2,3\n", format)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
        }
    }

    @Test
    public void testIgnoreHeaderCaseAllowsCaseInsensitiveLookup() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("One", "Two").withIgnoreHeaderCase();
        try (final CSVParser parser = CSVParser.parse("1,2\n", format)) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("1", record.get("one"));
            assertEquals("2", record.get("TWO"));
        }
    }

    @Test
    public void testDuplicateHeaderNameFromDataRecordThrows() throws IOException {
        // A duplicate coming from the parsed header line is detected by the CSVParser constructor itself.
        try {
            CSVParser.parse("A,A\n1,2\n", CSVFormat.DEFAULT.withHeader());
            fail("Expected IllegalArgumentException for duplicate header name");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage(), e.getMessage().contains("duplicate name"));
        }
    }

    // ------------------------------------------------------------------
    // getCurrentLineNumber()
    // ------------------------------------------------------------------

    @Test
    public void testCurrentLineNumberProgressesWithRecords() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b,c\r\nx,y,z\r\n", CSVFormat.DEFAULT)) {
            assertEquals(0L, parser.getCurrentLineNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(1L, parser.getCurrentLineNumber());
            it.next();
            assertEquals(2L, parser.getCurrentLineNumber());
        }
    }

    @Test
    public void testCurrentLineNumberDiffersFromRecordNumberForMultiLineValues() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,\"b\nb\",c\nx,y,z\n", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("b\nb", records.get(0).get(1));
            assertEquals(2L, records.get(1).getRecordNumber());
            // three physical lines were consumed to produce two records
            assertEquals(3L, parser.getCurrentLineNumber());
        }
    }

    // ------------------------------------------------------------------
    // getFirstEndOfLine()
    // ------------------------------------------------------------------

    @Test
    public void testFirstEndOfLineIsNullBeforeAnyLineTerminatorIsSeen() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT)) {
            assertNull(parser.getFirstEndOfLine());
            parser.getRecords();
            assertNull(parser.getFirstEndOfLine());
        }
    }

    @Test
    public void testFirstEndOfLineDetectsCrLf() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\r\nc,d\n", CSVFormat.DEFAULT)) {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        }
    }

    @Test
    public void testFirstEndOfLineDetectsLf() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT)) {
            parser.getRecords();
            assertEquals("\n", parser.getFirstEndOfLine());
        }
    }

    @Test
    public void testFirstEndOfLineDetectsCr() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\rc,d\r", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("\r", parser.getFirstEndOfLine());
        }
    }

    // ------------------------------------------------------------------
    // Format-driven parsing behaviour visible through the public API
    // ------------------------------------------------------------------

    @Test
    public void testWithTrimRemovesSurroundingWhitespace() throws IOException {
        try (final CSVParser parser = CSVParser.parse(" a , b , c \n", CSVFormat.DEFAULT.withTrim())) {
            assertArrayEquals(new String[] { "a", "b", "c" }, parser.getRecords().get(0).values());
        }
    }

    @Test
    public void testDefaultFormatPreservesSurroundingWhitespace() throws IOException {
        try (final CSVParser parser = CSVParser.parse(" a , b \n", CSVFormat.DEFAULT)) {
            assertArrayEquals(new String[] { " a ", " b " }, parser.getRecords().get(0).values());
        }
    }

    @Test
    public void testWithNullStringMapsTokenToNull() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,NULL,c\n", CSVFormat.DEFAULT.withNullString("NULL"))) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        }
    }

    @Test
    public void testCommentMarkerCapturesCommentAndKeepsDataRecord() throws IOException {
        try (final CSVParser parser = CSVParser.parse("# a comment\na,b,c\n", CSVFormat.DEFAULT.withCommentMarker('#'))) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a comment", records.get(0).getComment());
            assertArrayEquals(new String[] { "a", "b", "c" }, records.get(0).values());
        }
    }

    @Test
    public void testQuotedValueContainingDelimiter() throws IOException {
        try (final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT)) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(2, record.size());
            assertEquals("a,b", record.get(0));
            assertEquals("c", record.get(1));
        }
    }

    @Test
    public void testDefaultFormatIgnoresEmptyLines() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\n\n\nc,d\n", CSVFormat.DEFAULT)) {
            assertEquals(2, parser.getRecords().size());
        }
    }

    @Test
    public void testKeepEmptyLinesYieldsEmptyRecord() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b\n\nc,d\n", CSVFormat.DEFAULT.withIgnoreEmptyLines(false))) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(1).size());
            assertEquals("", records.get(1).get(0));
        }
    }

    @Test
    public void testTrailingDelimiterDropsTrailingEmptyField() throws IOException {
        try (final CSVParser parser = CSVParser.parse("a,b,c,\n", CSVFormat.DEFAULT.withTrailingDelimiter())) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertArrayEquals(new String[] { "a", "b", "c" }, record.values());
        }
    }

    @Test
    public void testInvalidCharAfterQuotedTokenThrowsIOException() throws IOException {
        try (final CSVParser parser = CSVParser.parse("\"a\"x,b\n", CSVFormat.DEFAULT)) {
            try {
                parser.getRecords();
                fail("Expected IOException for invalid char after closing quote");
            } catch (final IOException expected) {
                // expected
            }
        }
    }
}
