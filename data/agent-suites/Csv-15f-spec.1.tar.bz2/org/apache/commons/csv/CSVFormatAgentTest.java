package org.apache.commons.csv;

import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Self-contained JUnit 3.8 test for {@link CSVFormat}, based solely on the
 * documented contract in the generated javadoc under api/.
 */
public class CSVFormatAgentTest extends TestCase {

    /** Local fixture used to test {@link CSVFormat#withHeader(Class)}. */
    private enum Header {
        Name, Email, Phone
    }

    // ---------------------------------------------------------------
    // Predefined format field settings
    // ---------------------------------------------------------------

    public void testDefaultFieldSettings() {
        CSVFormat fmt = CSVFormat.DEFAULT;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertTrue(fmt.getIgnoreEmptyLines());
    }

    public void testExcelFieldSettings() {
        CSVFormat fmt = CSVFormat.EXCEL;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertTrue(fmt.getAllowMissingColumnNames());
    }

    public void testRfc4180FieldSettings() {
        CSVFormat fmt = CSVFormat.RFC4180;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
    }

    public void testTdfFieldSettings() {
        CSVFormat fmt = CSVFormat.TDF;
        assertEquals('\t', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertTrue(fmt.getIgnoreSurroundingSpaces());
    }

    public void testMySqlFieldSettings() {
        CSVFormat fmt = CSVFormat.MYSQL;
        assertEquals('\t', fmt.getDelimiter());
        assertNull(fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertEquals("\\N", fmt.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    public void pruned_testInformixUnloadFieldSettings() {
        CSVFormat fmt = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
    }

    public void testInformixUnloadCsvFieldSettings() {
        CSVFormat fmt = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertFalse(fmt.isEscapeCharacterSet());
        assertNull(fmt.getEscapeCharacter());
    }

    public void pruned_testPostgresqlCsvFieldSettings() {
        CSVFormat fmt = CSVFormat.POSTGRESQL_CSV;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertEquals("", fmt.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    public void pruned_testPostgresqlTextFieldSettings() {
        CSVFormat fmt = CSVFormat.POSTGRESQL_TEXT;
        assertEquals('\t', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertEquals("\\N", fmt.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    // ---------------------------------------------------------------
    // newFormat(char)
    // ---------------------------------------------------------------

    public void testNewFormatInitializesOtherFieldsToNullOrFalse() {
        CSVFormat fmt = CSVFormat.newFormat(';');
        assertEquals(';', fmt.getDelimiter());
        assertNull(fmt.getQuoteCharacter());
        assertFalse(fmt.isQuoteCharacterSet());
        assertNull(fmt.getEscapeCharacter());
        assertFalse(fmt.isEscapeCharacterSet());
        assertNull(fmt.getCommentMarker());
        assertFalse(fmt.isCommentMarkerSet());
        assertNull(fmt.getHeader());
        assertNull(fmt.getHeaderComments());
        assertNull(fmt.getNullString());
        assertFalse(fmt.isNullStringSet());
        assertNull(fmt.getQuoteMode());
        assertNull(fmt.getRecordSeparator());
        assertFalse(fmt.getAllowMissingColumnNames());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertFalse(fmt.getIgnoreHeaderCase());
        assertFalse(fmt.getIgnoreSurroundingSpaces());
        assertFalse(fmt.getSkipHeaderRecord());
        assertFalse(fmt.getTrailingDelimiter());
        assertFalse(fmt.getTrim());
        assertFalse(fmt.getAutoFlush());
    }

    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException for LF delimiter");
        } catch (IllegalArgumentException expected) {
            // pass
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException for CR delimiter");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // valueOf(String)
    // ---------------------------------------------------------------

    public void testValueOfKnownNames() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.valueOf("InformixUnload"));
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.valueOf("InformixUnloadCsv"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.POSTGRESQL_CSV, CSVFormat.valueOf("PostgreSQLCsv"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));

        // Verify by its documented settings, since PostgreSQLText and
        // PostgreSQLCsv are distinct formats (different delimiters).
        CSVFormat pgText = CSVFormat.valueOf("PostgreSQLText");
        assertEquals('\t', pgText.getDelimiter());
        assertEquals(Character.valueOf('"'), pgText.getQuoteCharacter());
        assertEquals("\n", pgText.getRecordSeparator());
        assertEquals("\\N", pgText.getNullString());
    }

    public void testValueOfUnknownNameThrowsIllegalArgumentException() {
        try {
            CSVFormat.valueOf("NoSuchPredefinedFormat");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    public void testValueOfNullThrowsNullPointerException() {
        try {
            CSVFormat.valueOf(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    public void testEqualsBasicContract() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.EXCEL));
    }

    public void testEqualsAndHashCodeForEquivalentlyBuiltFormats() {
        CSVFormat rebuilt = CSVFormat.newFormat(',')
                .withQuote('"')
                .withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        assertTrue(rebuilt.equals(CSVFormat.DEFAULT));
        assertTrue(CSVFormat.DEFAULT.equals(rebuilt));
        assertEquals(CSVFormat.DEFAULT.hashCode(), rebuilt.hashCode());
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    public void testFormatJoinsValuesWithDelimiter() {
        assertEquals("a,b,c", CSVFormat.RFC4180.format("a", "b", "c"));
    }

    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.RFC4180.format("a,b", "c"));
    }

    public void testFormatDoublesEmbeddedQuoteCharacter() {
        assertEquals("\"a\"\"b\"", CSVFormat.RFC4180.format("a\"b"));
    }

    public void testFormatWithNoValuesIsEmpty() {
        assertEquals("", CSVFormat.RFC4180.format());
    }

    // ---------------------------------------------------------------
    // header
    // ---------------------------------------------------------------

    public void testGetHeaderReturnsIndependentCopy() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("a", "b");
        String[] header1 = fmt.getHeader();
        assertNotNull(header1);
        assertEquals(2, header1.length);
        assertEquals("a", header1[0]);
        assertEquals("b", header1[1]);

        header1[0] = "mutated";
        String[] header2 = fmt.getHeader();
        assertEquals("a", header2[0]);
    }

    public void testWithHeaderNoArgsIsEmptyArray() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader();
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
    }

    public void testWithHeaderNullDisablesHeader() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader((String[]) null);
        assertNull(fmt.getHeader());
    }

    public void testWithHeaderEnumClass() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader(Header.class);
        String[] header = fmt.getHeader();
        assertNotNull(header);
        assertEquals(3, header.length);
        assertEquals("Name", header[0]);
        assertEquals("Email", header[1]);
        assertEquals("Phone", header[2]);
    }

    public void testWithFirstRecordAsHeaderEquivalence() {
        CSVFormat fmt = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(fmt.getSkipHeaderRecord());
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
    }

    // ---------------------------------------------------------------
    // header comments
    // ---------------------------------------------------------------

    public void testWithHeaderCommentsStoresStringRepresentation() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeaderComments("first", Integer.valueOf(2));
        String[] comments = fmt.getHeaderComments();
        assertNotNull(comments);
        assertEquals(2, comments.length);
        assertEquals("first", comments[0]);
        assertEquals("2", comments[1]);
    }

    public void testHeaderCommentsNullByDefault() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // ---------------------------------------------------------------
    // comment marker
    // ---------------------------------------------------------------

    public void testWithCommentMarkerChar() {
        CSVFormat fmt = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), fmt.getCommentMarker());
        assertTrue(fmt.isCommentMarkerSet());
    }

    public void testWithCommentMarkerCharacterNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(fmt.getCommentMarker());
        assertFalse(fmt.isCommentMarkerSet());
    }

    public void testWithCommentMarkerRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withCommentMarker('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
        try {
            CSVFormat.DEFAULT.withCommentMarker(Character.valueOf('\r'));
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // delimiter
    // ---------------------------------------------------------------

    public void testWithDelimiter() {
        CSVFormat fmt = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', fmt.getDelimiter());
    }

    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
        try {
            CSVFormat.DEFAULT.withDelimiter('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // escape
    // ---------------------------------------------------------------

    public void testWithEscapeChar() {
        CSVFormat fmt = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertTrue(fmt.isEscapeCharacterSet());
    }

    public void testWithEscapeCharacterNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withEscape('\\').withEscape((Character) null);
        assertNull(fmt.getEscapeCharacter());
        assertFalse(fmt.isEscapeCharacterSet());
    }

    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // quote
    // ---------------------------------------------------------------

    public void testWithQuoteChar() {
        CSVFormat fmt = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), fmt.getQuoteCharacter());
        assertTrue(fmt.isQuoteCharacterSet());
    }

    public void testWithQuoteCharacterNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(fmt.getQuoteCharacter());
        assertFalse(fmt.isQuoteCharacterSet());
    }

    public void testWithQuoteRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuote('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // quote mode
    // ---------------------------------------------------------------

    public void testWithQuoteMode() {
        CSVFormat fmt = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    // ---------------------------------------------------------------
    // record separator
    // ---------------------------------------------------------------

    public void testWithRecordSeparatorChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withRecordSeparator('\n');
        assertEquals("\n", fmt.getRecordSeparator());
    }

    public void testWithRecordSeparatorStringValidValues() {
        assertEquals("\r", CSVFormat.newFormat(',').withRecordSeparator("\r").getRecordSeparator());
        assertEquals("\n", CSVFormat.newFormat(',').withRecordSeparator("\n").getRecordSeparator());
        assertEquals("\r\n", CSVFormat.newFormat(',').withRecordSeparator("\r\n").getRecordSeparator());
    }

    public void pruned_testWithRecordSeparatorStringRejectsInvalidValue() {
        try {
            CSVFormat.newFormat(',').withRecordSeparator(";");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
        try {
            CSVFormat.newFormat(',').withRecordSeparator("");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // pass
        }
    }

    // ---------------------------------------------------------------
    // skip header record
    // ---------------------------------------------------------------

    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
    }

    // ---------------------------------------------------------------
    // allow missing column names
    // ---------------------------------------------------------------

    public void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
    }

    // ---------------------------------------------------------------
    // ignore empty lines
    // ---------------------------------------------------------------

    public void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    // ---------------------------------------------------------------
    // ignore header case
    // ---------------------------------------------------------------

    public void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
    }

    // ---------------------------------------------------------------
    // ignore surrounding spaces
    // ---------------------------------------------------------------

    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.TDF.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
    }

    // ---------------------------------------------------------------
    // trailing delimiter
    // ---------------------------------------------------------------

    public void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
    }

    // ---------------------------------------------------------------
    // trim
    // ---------------------------------------------------------------

    public void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
    }

    // ---------------------------------------------------------------
    // auto flush
    // ---------------------------------------------------------------

    public void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.withAutoFlush(false).getAutoFlush());
    }

    // ---------------------------------------------------------------
    // null string
    // ---------------------------------------------------------------

    public void testWithNullString() {
        CSVFormat fmt = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", fmt.getNullString());
        assertTrue(fmt.isNullStringSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
    }

    // ---------------------------------------------------------------
    // is*Set defaults on DEFAULT
    // ---------------------------------------------------------------

    public void testIsSetFlagsOnDefaultFormat() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
    }

    // ---------------------------------------------------------------
    // toString
    // ---------------------------------------------------------------

    public void testToStringIsNotEmpty() {
        String s = CSVFormat.DEFAULT.toString();
        assertNotNull(s);
        assertTrue(s.length() > 0);
    }

    // ---------------------------------------------------------------
    // print(Appendable)
    // ---------------------------------------------------------------

    public void testPrintAppendableWithoutHeaderWritesNothing() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        assertNotNull(printer);
        assertEquals("", sb.toString());
    }

    public void pruned_testPrintAppendableWritesHeaderImmediately() throws IOException {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("a", "b");
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = fmt.print(sb);
        assertNotNull(printer);
        assertEquals(fmt.format("a", "b") + fmt.getRecordSeparator(), sb.toString());
    }

    // ---------------------------------------------------------------
    // printer()
    // ---------------------------------------------------------------

    public void pruned_testPrinterWritesHeaderToSystemOut() throws IOException {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("x", "y");
        PrintStream originalOut = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        CSVPrinter printer;
        try {
            System.setOut(new PrintStream(captured));
            printer = fmt.printer();
            System.out.flush();
        } finally {
            System.setOut(originalOut);
        }
        assertNotNull(printer);
        assertEquals(fmt.format("x", "y") + fmt.getRecordSeparator(), captured.toString());
    }

    // ---------------------------------------------------------------
    // print(File, Charset) / print(Path, Charset)
    // ---------------------------------------------------------------

    public void testPrintToFileReturnsPrinterAndCreatesFile() throws IOException {
        File file = File.createTempFile("CSVFormatAgentTest", ".csv");
        file.deleteOnExit();
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
            assertNotNull(printer);
            assertTrue(file.exists());
        } finally {
            file.delete();
        }
    }

    public void testPrintToPathReturnsPrinterAndCreatesFile() throws IOException {
        Path path = Files.createTempFile("CSVFormatAgentTest", ".csv");
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(path, StandardCharsets.UTF_8);
            assertNotNull(printer);
            assertTrue(Files.exists(path));
        } finally {
            Files.deleteIfExists(path);
        }
    }

    // ---------------------------------------------------------------
    // print(Object, Appendable, boolean)
    // ---------------------------------------------------------------

    public void testPrintSingleValueAsFirstFieldOfRecord() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a", sb, true);
        assertEquals("a", sb.toString());
    }

    public void testPrintSecondValuePrependsDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat fmt = CSVFormat.DEFAULT;
        fmt.print("a", sb, true);
        fmt.print("b", sb, false);
        assertEquals("a" + fmt.getDelimiter() + "b", sb.toString());
    }

    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    // ---------------------------------------------------------------
    // println(Appendable)
    // ---------------------------------------------------------------

    public void testPrintlnWithTrailingDelimiterAndRecordSeparator() throws IOException {
        CSVFormat fmt = CSVFormat.DEFAULT.withTrailingDelimiter();
        StringBuilder sb = new StringBuilder();
        fmt.println(sb);
        assertEquals("" + fmt.getDelimiter() + fmt.getRecordSeparator(), sb.toString());
    }

    public void testPrintlnWithNeitherTrailingDelimiterNorRecordSeparator() throws IOException {
        CSVFormat fmt = CSVFormat.newFormat(',');
        StringBuilder sb = new StringBuilder();
        fmt.println(sb);
        assertEquals("", sb.toString());
    }

    public void testPrintlnWithOnlyRecordSeparator() throws IOException {
        CSVFormat fmt = CSVFormat.newFormat(',').withRecordSeparator("\n");
        StringBuilder sb = new StringBuilder();
        fmt.println(sb);
        assertEquals("\n", sb.toString());
    }

    public void testPrintlnWithOnlyTrailingDelimiter() throws IOException {
        CSVFormat fmt = CSVFormat.newFormat(',').withTrailingDelimiter();
        StringBuilder sb = new StringBuilder();
        fmt.println(sb);
        assertEquals(",", sb.toString());
    }

    // ---------------------------------------------------------------
    // printRecord(Appendable, Object...)
    // ---------------------------------------------------------------

    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        CSVFormat fmt = CSVFormat.RFC4180;
        StringBuilder sb = new StringBuilder();
        fmt.printRecord(sb, "a", "b");
        assertEquals("a,b" + fmt.getRecordSeparator(), sb.toString());
    }

    public void testPrintRecordWithNoValuesStillAddsRecordSeparator() throws IOException {
        CSVFormat fmt = CSVFormat.RFC4180;
        StringBuilder sb = new StringBuilder();
        fmt.printRecord(sb);
        assertEquals(fmt.getRecordSeparator(), sb.toString());
    }

    // ---------------------------------------------------------------
    // parse(Reader)
    // ---------------------------------------------------------------

    public void testParseSingleRecordWithoutHeader() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c"));
        Iterator<CSVRecord> it = parser.iterator();
        assertTrue(it.hasNext());
        CSVRecord record = it.next();
        List<String> values = new ArrayList<String>();
        for (String field : record) {
            values.add(field);
        }
        assertEquals(3, values.size());
        assertEquals("a", values.get(0));
        assertEquals("b", values.get(1));
        assertEquals("c", values.get(2));
        assertFalse(it.hasNext());
    }

    public void testParseTwoRecords() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("1,2\r\n3,4\r\n"));
        Iterator<CSVRecord> it = parser.iterator();

        assertTrue(it.hasNext());
        List<String> firstValues = new ArrayList<String>();
        for (String field : it.next()) {
            firstValues.add(field);
        }
        assertEquals(2, firstValues.size());
        assertEquals("1", firstValues.get(0));
        assertEquals("2", firstValues.get(1));

        assertTrue(it.hasNext());
        List<String> secondValues = new ArrayList<String>();
        for (String field : it.next()) {
            secondValues.add(field);
        }
        assertEquals(2, secondValues.size());
        assertEquals("3", secondValues.get(0));
        assertEquals("4", secondValues.get(1));

        assertFalse(it.hasNext());
    }
}
