package org.apache.commons.csv;

import java.io.Reader;
import java.io.StringReader;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link CSVFormat}.
 *
 * <p>Every expectation below is taken from the published javadoc contract in
 * {@code api/org/apache/commons/csv/CSVFormat.html}: the documented settings of
 * the predefined formats, the "immutable" / "A new CSVFormat that is equal to
 * this but with ..." wording of the {@code with*} methods, the documented
 * {@code IllegalArgumentException} for line-break characters, and the
 * "Verifies the consistency of the parameters" contract of {@code validate()}.</p>
 *
 * <p>The test lives in {@code org.apache.commons.csv} so that it can exercise the
 * package-private {@code validate()} method described in the javadoc.</p>
 */
public class CSVFormatAgentTest extends TestCase {

    // ------------------------------------------------------------------
    // newFormat(char)
    // ------------------------------------------------------------------

    public void testNewFormatSetsTheGivenDelimiter() {
        assertEquals(',', CSVFormat.newFormat(',').getDelimiter());
        assertEquals('\t', CSVFormat.newFormat('\t').getDelimiter());
        assertEquals(';', CSVFormat.newFormat(';').getDelimiter());
        assertEquals('|', CSVFormat.newFormat('|').getDelimiter());
    }

    /**
     * The contract says the format is created "with the specified delimiter" and
     * nothing else, so no other feature should be configured.
     */
    public void testNewFormatLeavesEveryOtherOptionUnset() {
        CSVFormat f = CSVFormat.newFormat('|');
        assertEquals('|', f.getDelimiter());
        assertNull("no quote char expected", f.getQuoteChar());
        assertFalse("quoting disabled", f.isQuoting());
        assertNull("no escape char expected", f.getEscape());
        assertFalse("escaping disabled", f.isEscaping());
        assertNull("no comment marker expected", f.getCommentStart());
        assertFalse("commenting disabled", f.isCommentingEnabled());
        assertNull("no null string expected", f.getNullString());
        assertFalse("null handling disabled", f.isNullHandling());
        assertNull("no header expected", f.getHeader());
        assertFalse("empty lines not ignored", f.getIgnoreEmptyLines());
        assertFalse("surrounding spaces not ignored", f.getIgnoreSurroundingSpaces());
        assertFalse("header record not skipped", f.getSkipHeaderRecord());
    }

    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("newFormat('\\n') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            CSVFormat.newFormat('\r');
            fail("newFormat('\\r') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    // ------------------------------------------------------------------
    // Predefined formats
    // ------------------------------------------------------------------

    public void testDefaultFormatMatchesDocumentedSettings() {
        CSVFormat f = CSVFormat.DEFAULT;
        assertEquals("delimiter", ',', f.getDelimiter());
        assertNotNull("quote char", f.getQuoteChar());
        assertEquals("quote char", '"', f.getQuoteChar().charValue());
        assertTrue("isQuoting", f.isQuoting());
        assertEquals("record separator is CRLF", "\r\n", f.getRecordSeparator());
        assertTrue("DEFAULT additionally ignores empty lines", f.getIgnoreEmptyLines());
        assertNull("no escape char", f.getEscape());
        assertFalse("not escaping", f.isEscaping());
        assertNull("no comment marker", f.getCommentStart());
        assertFalse("commenting disabled", f.isCommentingEnabled());
        assertNull("no null string", f.getNullString());
        assertFalse("null handling disabled", f.isNullHandling());
        assertNull("no header", f.getHeader());
    }

    public void testRfc4180FormatMatchesDocumentedSettings() {
        CSVFormat f = CSVFormat.RFC4180;
        assertEquals(',', f.getDelimiter());
        assertNotNull(f.getQuoteChar());
        assertEquals('"', f.getQuoteChar().charValue());
        assertEquals("\r\n", f.getRecordSeparator());
        // DEFAULT is documented as "RFC4180 but allowing empty lines" with the
        // "Additional" setting withIgnoreEmptyLines(true); plain RFC4180 does not.
        assertFalse("RFC4180 does not add empty-line skipping", f.getIgnoreEmptyLines());
    }

    public void testExcelFormatMatchesDocumentedSettings() {
        CSVFormat f = CSVFormat.EXCEL;
        assertEquals(',', f.getDelimiter());
        assertNotNull(f.getQuoteChar());
        assertEquals('"', f.getQuoteChar().charValue());
        assertEquals("\r\n", f.getRecordSeparator());
    }

    public void testTdfFormatMatchesDocumentedSettings() {
        CSVFormat f = CSVFormat.TDF;
        assertEquals("tab-delimited", '\t', f.getDelimiter());
        assertTrue("leading/trailing spaces ignored", f.getIgnoreSurroundingSpaces());
        assertNotNull("TDF uses a quote char", f.getQuoteChar());
        assertTrue("TDF is quoting", f.isQuoting());
    }

    public void testMysqlFormatMatchesDocumentedSettings() {
        CSVFormat f = CSVFormat.MYSQL;
        assertEquals("tab-delimited", '\t', f.getDelimiter());
        assertNotNull("MYSQL escapes special characters with '\\'", f.getEscape());
        assertEquals('\\', f.getEscape().charValue());
        assertTrue("MYSQL is escaping", f.isEscaping());
        assertNull("MYSQL values are not quoted", f.getQuoteChar());
        assertFalse("MYSQL is not quoting", f.isQuoting());
        assertEquals("MYSQL uses LF as line separator", "\n", f.getRecordSeparator());
    }

    // ------------------------------------------------------------------
    // withDelimiter
    // ------------------------------------------------------------------

    public void testWithDelimiterReturnsNewInstanceAndDoesNotMutateOriginal() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat modified = original.withDelimiter(';');
        assertEquals("returned format uses the new delimiter", ';', modified.getDelimiter());
        assertEquals("original is immutable / unchanged", ',', original.getDelimiter());
        assertNotSame(original, modified);
    }

    public void testWithDelimiterRejectsLineBreaks() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("withDelimiter('\\n') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
        try {
            CSVFormat.DEFAULT.withDelimiter('\r');
            fail("withDelimiter('\\r') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testFormatOutputReflectsWithDelimiter() {
        CSVFormat f = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals("1;2;3", f.format("1", "2", "3"));
    }

    // ------------------------------------------------------------------
    // withQuoteChar
    // ------------------------------------------------------------------

    public void testWithQuoteCharSetsCharAndEnablesQuoting() {
        CSVFormat f = CSVFormat.newFormat(',').withQuoteChar('\'');
        assertNotNull(f.getQuoteChar());
        assertEquals('\'', f.getQuoteChar().charValue());
        assertTrue(f.isQuoting());
    }

    public void testWithQuoteCharacterNullDisablesQuoting() {
        CSVFormat f = CSVFormat.DEFAULT.withQuoteChar((Character) null);
        assertNull(f.getQuoteChar());
        assertFalse(f.isQuoting());
        assertNotNull("original DEFAULT still has a quote char", CSVFormat.DEFAULT.getQuoteChar());
    }

    public void testWithQuoteCharRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuoteChar('\n');
            fail("withQuoteChar('\\n') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
        try {
            CSVFormat.DEFAULT.withQuoteChar(Character.valueOf('\r'));
            fail("withQuoteChar((Character) '\\r') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ------------------------------------------------------------------
    // withEscape
    // ------------------------------------------------------------------

    public void testWithEscapeSetsCharAndEnablesEscaping() {
        assertNull("precondition: DEFAULT has no escape char", CSVFormat.DEFAULT.getEscape());
        assertFalse("precondition: DEFAULT is not escaping", CSVFormat.DEFAULT.isEscaping());
        CSVFormat f = CSVFormat.DEFAULT.withEscape('\\');
        assertNotNull(f.getEscape());
        assertEquals('\\', f.getEscape().charValue());
        assertTrue(f.isEscaping());
        assertNull("original DEFAULT unchanged", CSVFormat.DEFAULT.getEscape());
    }

    public void testWithEscapeCharacterNullDisablesEscaping() {
        // MYSQL ships with an escape character; clearing it must disable escaping.
        CSVFormat f = CSVFormat.MYSQL.withEscape((Character) null);
        assertNull(f.getEscape());
        assertFalse(f.isEscaping());
        assertNotNull("original MYSQL unchanged", CSVFormat.MYSQL.getEscape());
    }

    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\r');
            fail("withEscape('\\r') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
        try {
            CSVFormat.DEFAULT.withEscape(Character.valueOf('\n'));
            fail("withEscape((Character) '\\n') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ------------------------------------------------------------------
    // withCommentStart
    // ------------------------------------------------------------------

    public void testWithCommentStartSetsMarkerAndEnablesCommenting() {
        assertNull("precondition: DEFAULT has no comment marker", CSVFormat.DEFAULT.getCommentStart());
        assertFalse("precondition: commenting disabled", CSVFormat.DEFAULT.isCommentingEnabled());
        CSVFormat f = CSVFormat.DEFAULT.withCommentStart('#');
        assertNotNull(f.getCommentStart());
        assertEquals('#', f.getCommentStart().charValue());
        assertTrue(f.isCommentingEnabled());
        assertNull("original DEFAULT unchanged", CSVFormat.DEFAULT.getCommentStart());
    }

    public void testWithCommentStartCharacterNullDisablesCommenting() {
        CSVFormat withMarker = CSVFormat.DEFAULT.withCommentStart('#');
        CSVFormat cleared = withMarker.withCommentStart((Character) null);
        assertNull(cleared.getCommentStart());
        assertFalse(cleared.isCommentingEnabled());
        // the intermediate format is untouched
        assertTrue(withMarker.isCommentingEnabled());
    }

    public void testWithCommentStartRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withCommentStart('\n');
            fail("withCommentStart('\\n') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
        try {
            CSVFormat.DEFAULT.withCommentStart(Character.valueOf('\r'));
            fail("withCommentStart((Character) '\\r') must throw IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ------------------------------------------------------------------
    // withNullString
    // ------------------------------------------------------------------

    public void testWithNullStringStoresValueAndEnablesNullHandling() {
        assertNull("precondition", CSVFormat.DEFAULT.getNullString());
        assertFalse("precondition", CSVFormat.DEFAULT.isNullHandling());
        CSVFormat f = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", f.getNullString());
        assertTrue(f.isNullHandling());
        assertNull("original DEFAULT unchanged", CSVFormat.DEFAULT.getNullString());
    }

    public void testFormatWritesNullUsingNullString() {
        CSVFormat f = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("a,NULL,c", f.format("a", null, "c"));
    }

    // ------------------------------------------------------------------
    // withRecordSeparator
    // ------------------------------------------------------------------

    public void testWithRecordSeparatorString() {
        CSVFormat f = CSVFormat.newFormat(',').withRecordSeparator("\r\n");
        assertEquals("\r\n", f.getRecordSeparator());
    }

    public void testWithRecordSeparatorChar() {
        CSVFormat f = CSVFormat.newFormat(',').withRecordSeparator('\n');
        assertEquals("\n", f.getRecordSeparator());
    }

    // ------------------------------------------------------------------
    // boolean toggles
    // ------------------------------------------------------------------

    public void testWithIgnoreEmptyLinesToggle() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue("DEFAULT itself still ignores empty lines", CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    public void testWithIgnoreSurroundingSpacesToggle() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.TDF.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
        assertTrue("TDF itself unchanged", CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    public void testWithSkipHeaderRecordToggle() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(true).withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    // ------------------------------------------------------------------
    // withHeader / getHeader
    // ------------------------------------------------------------------

    public void testWithHeaderStoresUserSpecifiedNames() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader("name", "email", "phone");
        String[] header = f.getHeader();
        assertNotNull(header);
        assertEquals(3, header.length);
        assertEquals("name", header[0]);
        assertEquals("email", header[1]);
        assertEquals("phone", header[2]);
    }

    public void testGetHeaderReturnsADefensiveCopy() {
        CSVFormat f = CSVFormat.DEFAULT.withHeader("a", "b");
        String[] first = f.getHeader();
        first[0] = "MUTATED";
        String[] second = f.getHeader();
        assertEquals("getHeader() must return a fresh copy each call", "a", second[0]);
        assertNotSame(first, second);
    }

    public void testWithHeaderNoArgumentsYieldsEmptyNonNullHeader() {
        String[] header = CSVFormat.DEFAULT.withHeader().getHeader();
        assertNotNull("auto (parsed) header is empty, not null", header);
        assertEquals(0, header.length);
    }

    public void testWithHeaderDoesNotMutateOriginal() {
        CSVFormat original = CSVFormat.DEFAULT;
        original.withHeader("x", "y");
        assertNull("DEFAULT still has no header", original.getHeader());
    }

    // ------------------------------------------------------------------
    // equals / hashCode / toString
    // ------------------------------------------------------------------

    public void testEqualsIsReflexiveAndRejectsNullAndForeignTypes() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    public void testEqualsIsValueBased() {
        assertTrue("two formats with identical configuration are equal",
                CSVFormat.newFormat(',').equals(CSVFormat.newFormat(',')));
        assertFalse("different delimiter -> not equal",
                CSVFormat.newFormat(',').equals(CSVFormat.newFormat(';')));
    }

    public void testDefaultIsNotEqualToRfc4180() {
        // They differ (only) in the documented empty-line handling.
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.RFC4180));
        assertFalse(CSVFormat.RFC4180.equals(CSVFormat.DEFAULT));
    }

    public void testEqualityAfterWithMethods() {
        assertFalse("changing the delimiter breaks equality",
                CSVFormat.DEFAULT.withDelimiter(';').equals(CSVFormat.DEFAULT));
        assertTrue("re-setting the same delimiter keeps equality",
                CSVFormat.DEFAULT.withDelimiter(',').equals(CSVFormat.DEFAULT));
    }

    public void testHashCodeIsConsistentAndAgreesWithEquals() {
        assertEquals("hashCode must be self-consistent",
                CSVFormat.DEFAULT.hashCode(), CSVFormat.DEFAULT.hashCode());
        CSVFormat a = CSVFormat.newFormat(',');
        CSVFormat b = CSVFormat.newFormat(',');
        assertTrue(a.equals(b));
        assertEquals("equal objects must have equal hash codes", a.hashCode(), b.hashCode());
    }

    public void testToStringProducesNonEmptyText() {
        String s = CSVFormat.DEFAULT.toString();
        assertNotNull(s);
        assertTrue("toString() should not be empty", s.length() > 0);
    }

    // ------------------------------------------------------------------
    // format(Object...)
    // ------------------------------------------------------------------

    public void testFormatJoinsValuesWithTheDelimiter() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
        assertEquals("single", CSVFormat.DEFAULT.format("single"));
    }

    public void testFormatUsesTheConfiguredDelimiter() {
        assertEquals("a\tb", CSVFormat.TDF.format("a", "b"));
        assertEquals("x\ty", CSVFormat.MYSQL.format("x", "y"));
    }

    public void testFormatQuotesAValueContainingTheDelimiter() {
        // DEFAULT follows RFC 4180: a field containing the delimiter is enclosed
        // in the quote character.
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    public void testFormatDoublesAnEmbeddedQuoteCharacter() {
        // RFC 4180: a quote character inside a field is escaped by doubling it,
        // and the field is quoted.
        assertEquals("\"a\"\"b\"", CSVFormat.DEFAULT.format("a\"b"));
    }

    public void testFormatWithNoValuesReturnsEmptyString() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    // ------------------------------------------------------------------
    // parse(Reader)
    // ------------------------------------------------------------------

    public void testParseReturnsANonNullParserForValidInput() throws Exception {
        Reader in = new StringReader("a,b,c\r\n1,2,3\r\n");
        CSVParser parser = CSVFormat.DEFAULT.parse(in);
        assertNotNull(parser);
    }

    public void testParseAcceptsEmptyInput() throws Exception {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader(""));
        assertNotNull(parser);
    }

    // ------------------------------------------------------------------
    // validate()  (package-private; documented to check parameter consistency)
    // ------------------------------------------------------------------

    public void testValidatePassesForEveryPredefinedFormat() {
        CSVFormat[] formats = new CSVFormat[] {
            CSVFormat.DEFAULT, CSVFormat.RFC4180, CSVFormat.EXCEL, CSVFormat.TDF, CSVFormat.MYSQL
        };
        for (int i = 0; i < formats.length; i++) {
            formats[i].validate(); // documented predefined formats must be consistent
        }
        // and the formats are still usable afterwards
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    public void testValidateRejectsQuoteCharEqualToDelimiter() {
        try {
            CSVFormat f = CSVFormat.newFormat(',').withQuoteChar(',');
            f.validate();
            fail("validate() must reject a quote char equal to the delimiter");
        } catch (IllegalStateException expected) {
            // inconsistent parameters
        }
    }

    public void testValidateRejectsEscapeEqualToDelimiter() {
        try {
            CSVFormat f = CSVFormat.newFormat(',').withEscape(',');
            f.validate();
            fail("validate() must reject an escape char equal to the delimiter");
        } catch (IllegalStateException expected) {
            // inconsistent parameters
        }
    }

    public void testValidateRejectsCommentStartEqualToDelimiter() {
        try {
            CSVFormat f = CSVFormat.newFormat(',').withCommentStart(',');
            f.validate();
            fail("validate() must reject a comment marker equal to the delimiter");
        } catch (IllegalStateException expected) {
            // inconsistent parameters
        }
    }

    // ------------------------------------------------------------------
    // Immutability of the whole with* family
    // ------------------------------------------------------------------

    public void testWithMethodsReturnANewInstanceAndNeverMutateTheReceiver() {
        CSVFormat base = CSVFormat.newFormat(',');

        assertNotSame(base, base.withDelimiter(';'));
        assertNotSame(base, base.withQuoteChar('"'));
        assertNotSame(base, base.withEscape('\\'));
        assertNotSame(base, base.withCommentStart('#'));
        assertNotSame(base, base.withNullString("NULL"));
        assertNotSame(base, base.withRecordSeparator('\n'));
        assertNotSame(base, base.withIgnoreEmptyLines(true));
        assertNotSame(base, base.withIgnoreSurroundingSpaces(true));
        assertNotSame(base, base.withSkipHeaderRecord(true));
        assertNotSame(base, base.withHeader("h1"));

        // none of the above changed 'base'
        assertEquals(',', base.getDelimiter());
        assertFalse(base.isQuoting());
        assertFalse(base.isEscaping());
        assertFalse(base.isCommentingEnabled());
        assertFalse(base.isNullHandling());
        assertNull(base.getHeader());
        assertFalse(base.getIgnoreEmptyLines());
        assertFalse(base.getIgnoreSurroundingSpaces());
        assertFalse(base.getSkipHeaderRecord());
    }

    // ------------------------------------------------------------------
    // getQuotePolicy / withQuotePolicy round-trip
    // ------------------------------------------------------------------

    public void testWithQuotePolicyRoundTrips() {
        Quote policy = CSVFormat.RFC4180.getQuotePolicy();
        CSVFormat f = CSVFormat.RFC4180.withQuotePolicy(policy);
        assertEquals(policy, f.getQuotePolicy());
    }
}
