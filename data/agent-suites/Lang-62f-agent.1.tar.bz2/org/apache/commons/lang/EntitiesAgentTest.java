/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Tests the public API of {@link org.apache.commons.lang.Entities}.
 *
 * <p>Only the package/public surface of <code>Entities</code> is exercised:
 * the three prebuilt instances ({@link Entities#XML}, {@link Entities#HTML32},
 * {@link Entities#HTML40}), plus <code>addEntity</code>, <code>addEntities</code>,
 * <code>entityName</code>, <code>entityValue</code>, <code>escape</code> and
 * <code>unescape</code> (both the <code>String</code> and <code>Writer</code>
 * flavours).</p>
 *
 * <p>The source of this class is kept strictly ASCII; every non-ASCII character
 * is written as a <code>&#92;uXXXX</code> escape so the assertions do not depend
 * on the compiler's source encoding.</p>
 */
public class EntitiesAgentTest extends TestCase {

    public EntitiesAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(EntitiesAgentTest.class);
    }

    // -----------------------------------------------------------------------
    // Prebuilt XML entity set
    // -----------------------------------------------------------------------

    public void testXmlPredefinedEntityValues() {
        assertEquals(34, Entities.XML.entityValue("quot"));
        assertEquals(38, Entities.XML.entityValue("amp"));
        assertEquals(60, Entities.XML.entityValue("lt"));
        assertEquals(62, Entities.XML.entityValue("gt"));
        assertEquals(39, Entities.XML.entityValue("apos"));
    }

    public void testXmlPredefinedEntityNames() {
        assertEquals("quot", Entities.XML.entityName(34));
        assertEquals("amp", Entities.XML.entityName(38));
        assertEquals("lt", Entities.XML.entityName(60));
        assertEquals("gt", Entities.XML.entityName(62));
        assertEquals("apos", Entities.XML.entityName(39));
    }

    public void testXmlDoesNotContainHtmlEntities() {
        assertEquals(-1, Entities.XML.entityValue("copy"));
        assertEquals(-1, Entities.XML.entityValue("nbsp"));
        assertEquals(-1, Entities.XML.entityValue("euro"));
        assertNull(Entities.XML.entityName(169));
        assertNull(Entities.XML.entityName(160));
    }

    // -----------------------------------------------------------------------
    // Prebuilt HTML 3.2 entity set (basic + ISO-8859-1, but no apos)
    // -----------------------------------------------------------------------

    public void testHtml32ContainsBasicAndIso8859() {
        assertEquals(38, Entities.HTML32.entityValue("amp"));
        assertEquals(160, Entities.HTML32.entityValue("nbsp"));
        assertEquals(169, Entities.HTML32.entityValue("copy"));
        assertEquals(255, Entities.HTML32.entityValue("yuml"));
        assertEquals("copy", Entities.HTML32.entityName(169));
        assertEquals("nbsp", Entities.HTML32.entityName(160));
    }

    public void testHtml32ExcludesAposAndHtml40Entities() {
        assertEquals(-1, Entities.HTML32.entityValue("apos"));
        assertEquals(-1, Entities.HTML32.entityValue("euro"));
        assertEquals(-1, Entities.HTML32.entityValue("Alpha"));
        assertNull(Entities.HTML32.entityName(8364));
    }

    // -----------------------------------------------------------------------
    // Prebuilt HTML 4.0 entity set (basic + ISO-8859-1 + HTML 4.0 extended)
    // -----------------------------------------------------------------------

    public void testHtml40ContainsExtendedEntities() {
        assertEquals(169, Entities.HTML40.entityValue("copy"));
        assertEquals(402, Entities.HTML40.entityValue("fnof"));
        assertEquals(913, Entities.HTML40.entityValue("Alpha"));
        assertEquals(8364, Entities.HTML40.entityValue("euro"));
        assertEquals(9830, Entities.HTML40.entityValue("diams"));
        assertEquals("euro", Entities.HTML40.entityName(8364));
        assertEquals("Alpha", Entities.HTML40.entityName(913));
        assertEquals("diams", Entities.HTML40.entityName(9830));
    }

    public void testHtml40ExcludesApos() {
        assertEquals(-1, Entities.HTML40.entityValue("apos"));
    }

    // -----------------------------------------------------------------------
    // addEntity / entityName / entityValue
    // -----------------------------------------------------------------------

    public void testAddEntityRoundTripsBothDirections() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1); // 161
        assertEquals(161, entities.entityValue("foo"));
        assertEquals("foo", entities.entityName(161));
    }

    public void testAddEntityAboveLookupTableSize() {
        Entities entities = new Entities();
        entities.addEntity("highValue", 8364);
        assertEquals(8364, entities.entityValue("highValue"));
        assertEquals("highValue", entities.entityName(8364));
    }

    public void testAddEntityAcrossLookupTableBoundary() {
        Entities entities = new Entities();
        entities.addEntity("at255", 255); // last slot served by the lookup table
        entities.addEntity("at256", 256); // first slot served by the backing map
        assertEquals("at255", entities.entityName(255));
        assertEquals("at256", entities.entityName(256));
        assertEquals(255, entities.entityValue("at255"));
        assertEquals(256, entities.entityValue("at256"));
    }

    public void testEntityValueUnknownReturnsMinusOne() {
        Entities entities = new Entities();
        assertEquals(-1, entities.entityValue("doesNotExist"));
        entities.addEntity("known", 65);
        assertEquals(65, entities.entityValue("known"));
        assertEquals(-1, entities.entityValue("unknown"));
        assertEquals(-1, entities.entityValue(""));
    }

    public void testEntityValueNullNameReturnsMinusOne() {
        Entities entities = new Entities();
        assertEquals(-1, entities.entityValue(null));
    }

    public void testEntityNameUnknownReturnsNull() {
        Entities entities = new Entities();
        assertNull(entities.entityName(65));    // below lookup-table size, not present
        assertNull(entities.entityName(70000)); // above lookup-table size, not present
    }

    public void testInstancesDoNotShareState() {
        Entities a = new Entities();
        Entities b = new Entities();
        a.addEntity("foo", 200);
        assertEquals(200, a.entityValue("foo"));
        assertEquals(-1, b.entityValue("foo"));
        assertNull(b.entityName(200));
    }

    // -----------------------------------------------------------------------
    // addEntities
    // -----------------------------------------------------------------------

    public void testAddEntitiesFromArray() {
        Entities entities = new Entities();
        String[][] array = { { "alpha", "913" }, { "beta", "914" } };
        entities.addEntities(array);
        assertEquals(913, entities.entityValue("alpha"));
        assertEquals(914, entities.entityValue("beta"));
        assertEquals("alpha", entities.entityName(913));
        assertEquals("beta", entities.entityName(914));
    }

    public void testAddEntitiesEmptyArrayIsNoOp() {
        Entities entities = new Entities();
        entities.addEntities(new String[0][0]);
        assertEquals(-1, entities.entityValue("anything"));
    }

    public void testAddEntitiesWithNonNumericValueThrows() {
        Entities entities = new Entities();
        try {
            entities.addEntities(new String[][] { { "bad", "notanumber" } });
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testAddEntitiesNullArrayThrows() {
        Entities entities = new Entities();
        try {
            entities.addEntities(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // escape(String)
    // -----------------------------------------------------------------------

    public void testEscapeBasicXmlMarkup() {
        assertEquals("&lt;hello&gt;&amp;&quot;&apos;", Entities.XML.escape("<hello>&\"'"));
    }

    public void testEscapeLeavesPlainAsciiUnchanged() {
        assertEquals("plain text 123", Entities.XML.escape("plain text 123"));
        assertEquals("", Entities.XML.escape(""));
    }

    public void testEscapeAsciiBoundary() {
        // 0x7F is still "plain" ASCII and is passed through verbatim ...
        assertEquals("\u007F", Entities.XML.escape("\u007F"));
        // ... 0x80 is the first code point that gets a numeric reference.
        assertEquals("&#128;", Entities.XML.escape("\u0080"));
    }

    public void testEscapeUnmappedHighCharBecomesNumericReference() {
        // U+00A1 has no entity in the XML set, so it falls back to "&#161;".
        assertEquals("&#161;", Entities.XML.escape("\u00A1"));
    }

    public void testEscapeUsesHtml40NamedEntities() {
        assertEquals("&nbsp;", Entities.HTML40.escape("\u00A0"));
        assertEquals("&copy;", Entities.HTML40.escape("\u00A9"));
        assertEquals("&euro;", Entities.HTML40.escape("\u20AC"));
        assertEquals("&permil;", Entities.HTML40.escape("\u2030"));
    }

    public void testEscapeMixedContent() {
        assertEquals("caf&eacute; &amp; tea", Entities.HTML40.escape("caf\u00E9 & tea"));
    }

    public void testEscapeNullStringThrows() {
        try {
            Entities.XML.escape((String) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // escape(Writer, String)
    // -----------------------------------------------------------------------

    public void testEscapeToWriter() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.escape(writer, "<a> & </a>");
        assertEquals("&lt;a&gt; &amp; &lt;/a&gt;", writer.toString());
    }

    public void testEscapeToWriterHighChars() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.escape(writer, "\u00A1");
        assertEquals("&#161;", writer.toString());

        StringWriter namedWriter = new StringWriter();
        Entities.HTML40.escape(namedWriter, "\u20AC");
        assertEquals("&euro;", namedWriter.toString());
    }

    public void testEscapeToWriterEmptyString() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.escape(writer, "");
        assertEquals("", writer.toString());
    }

    public void testEscapeToWriterPropagatesIOException() {
        Writer failing = new ThrowingWriter();
        try {
            Entities.XML.escape(failing, "<test>");
            fail("Expected IOException");
        } catch (IOException expected) {
            assertEquals("boom", expected.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // unescape(String)
    // -----------------------------------------------------------------------

    public void testUnescapeNamedEntities() {
        assertEquals("<hello>", Entities.XML.unescape("&lt;hello&gt;"));
        assertEquals("\"quoted\"", Entities.XML.unescape("&quot;quoted&quot;"));
        assertEquals("&", Entities.XML.unescape("&amp;"));
    }

    public void testUnescapeNumericDecimal() {
        assertEquals("A", Entities.XML.unescape("&#65;"));
        assertEquals(" ", Entities.XML.unescape("&#32;"));
        assertEquals("\u00A0", Entities.XML.unescape("&#160;"));
    }

    public void testUnescapeNumericHex() {
        assertEquals("A", Entities.XML.unescape("&#x41;"));
        assertEquals("A", Entities.XML.unescape("&#X41;"));
        assertEquals("\u00FF", Entities.XML.unescape("&#xff;"));
        assertEquals("\uFFFF", Entities.XML.unescape("&#xFFFF;"));
    }

    public void testUnescapeNumberOverflowLeavesTextUnchanged() {
        // Value does not fit into an int -> NumberFormatException -> left verbatim.
        assertEquals("&#12345678901234567890;",
                Entities.XML.unescape("&#12345678901234567890;"));
        assertEquals("&#999999999999;", Entities.XML.unescape("&#999999999999;"));
        // Value fits into an int but exceeds 0xFFFF -> rejected, left verbatim.
        assertEquals("&#x110000;", Entities.XML.unescape("&#x110000;"));
        assertEquals("&#66000;", Entities.XML.unescape("&#66000;"));
    }

    public void testUnescapeUnknownOrMalformedEntitiesLeftUnchanged() {
        assertEquals("&unknown;", Entities.XML.unescape("&unknown;"));
        assertEquals("&copy;", Entities.XML.unescape("&copy;")); // not in the XML set
        assertEquals("&#;", Entities.XML.unescape("&#;"));
        assertEquals("&;", Entities.XML.unescape("&;"));
    }

    public void testUnescapeWithoutAmpersandReturnsSameString() {
        assertEquals("no entities here", Entities.XML.unescape("no entities here"));
        assertEquals("", Entities.XML.unescape(""));
    }

    public void testUnescapeAmpersandWithoutSemicolon() {
        assertEquals("&amp", Entities.XML.unescape("&amp"));
        assertEquals("a & b", Entities.XML.unescape("a & b"));
    }

    public void testUnescapeSecondAmpersandBeforeSemicolon() {
        // "&...&...;" : the first ampersand is emitted verbatim, the second is decoded.
        assertEquals("&&", Entities.XML.unescape("&&amp;"));
    }

    public void testUnescapeNullStringThrows() {
        try {
            Entities.XML.unescape((String) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // unescape(Writer, String)
    // -----------------------------------------------------------------------

    public void testUnescapeToWriterNamedEntities() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "&lt;a&gt;&amp;&quot;");
        assertEquals("<a>&\"", writer.toString());
    }

    public void testUnescapeToWriterNumeric() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "&#65;&#x42;");
        assertEquals("AB", writer.toString());
    }

    public void testUnescapeToWriterWithoutAmpersand() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "plain string");
        assertEquals("plain string", writer.toString());
    }

    public void testUnescapeToWriterOverflowLeavesTextUnchanged() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "&#12345678901234567890;");
        assertEquals("&#12345678901234567890;", writer.toString());
    }

    public void testUnescapeToWriterUnknownEntity() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "x&unknown;y");
        assertEquals("x&unknown;y", writer.toString());
    }

    public void testUnescapeToWriterPropagatesIOException() {
        Writer failing = new ThrowingWriter();
        try {
            Entities.XML.unescape(failing, "plain string");
            fail("Expected IOException");
        } catch (IOException expected) {
            assertEquals("boom", expected.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // round trips
    // -----------------------------------------------------------------------

    public void testEscapeThenUnescapeRoundTripXml() {
        String original = "<p class=\"x\">Fish & chips</p>";
        String escaped = Entities.XML.escape(original);
        assertEquals("&lt;p class=&quot;x&quot;&gt;Fish &amp; chips&lt;/p&gt;", escaped);
        assertEquals(original, Entities.XML.unescape(escaped));
    }

    public void testEscapeThenUnescapeRoundTripHtml40HighChars() {
        String original = "caf\u00E9 \u20AC \u2030";
        String escaped = Entities.HTML40.escape(original);
        assertEquals("caf&eacute; &euro; &permil;", escaped);
        assertEquals(original, Entities.HTML40.unescape(escaped));
    }

    public void testCustomEntityEscapeUnescapeRoundTrip() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);
        assertEquals("&foo;", entities.escape("\u00A1"));
        assertEquals("\u00A1", entities.unescape("&foo;"));
    }

    // -----------------------------------------------------------------------
    // helpers
    // -----------------------------------------------------------------------

    /** A {@link Writer} whose every write operation fails with a known message. */
    private static class ThrowingWriter extends Writer {
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("boom");
        }

        public void write(int c) throws IOException {
            throw new IOException("boom");
        }

        public void write(String str) throws IOException {
            throw new IOException("boom");
        }

        public void write(String str, int off, int len) throws IOException {
            throw new IOException("boom");
        }

        public void flush() throws IOException {
        }

        public void close() throws IOException {
        }
    }
}
