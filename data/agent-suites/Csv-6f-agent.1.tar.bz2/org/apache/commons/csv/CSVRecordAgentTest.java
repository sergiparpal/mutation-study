/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests the public API of {@link CSVRecord}.
 *
 * @version $Id$
 */
public class CSVRecordAgentTest {

    /** An enum whose constant names match the header names used by the tests. */
    public enum Column {
        A, B, C
    }

    private Map<String, Integer> headerMap;

    /** Fully populated record, header A=0 B=1 C=2, no comment, record number 1. */
    private CSVRecord record;

    /** Fully populated record carrying a comment, record number 6. */
    private CSVRecord recordWithComment;

    /** Record parsed without a header mapping. */
    private CSVRecord recordNoHeader;

    /** Record with only two values but a three column header (inconsistent / short). */
    private CSVRecord shortRecord;

    @Before
    @SuppressWarnings("boxing")
    public void setUp() {
        headerMap = new HashMap<String, Integer>();
        headerMap.put("A", 0);
        headerMap.put("B", 1);
        headerMap.put("C", 2);
        record = new CSVRecord(new String[] { "a", "b", "c" }, headerMap, null, 1L);
        recordWithComment = new CSVRecord(new String[] { "a", "b", "c" }, headerMap, "row comment", 6L);
        recordNoHeader = new CSVRecord(new String[] { "x", "y", "z" }, null, null, 2L);
        shortRecord = new CSVRecord(new String[] { "a", "b" }, headerMap, null, 3L);
    }

    // ------------------------------------------------------------------
    // get(int)
    // ------------------------------------------------------------------

    @Test
    public void testGetStringByIndex() {
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        assertEquals("c", record.get(2));
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testGetByIndexPastEndThrows() {
        record.get(record.size());
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testGetByNegativeIndexThrows() {
        record.get(-1);
    }

    // ------------------------------------------------------------------
    // get(String)
    // ------------------------------------------------------------------

    @Test
    public void testGetStringByName() {
        assertEquals("a", record.get("A"));
        assertEquals("b", record.get("B"));
        assertEquals("c", record.get("C"));
    }

    @Test
    public void testGetStringByNameWhenNotMapped() {
        try {
            record.get("NOT_A_COLUMN");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage(), e.getMessage().contains("NOT_A_COLUMN"));
        }
    }

    @Test
    public void testGetStringByNameWhenNoHeader() {
        try {
            recordNoHeader.get("A");
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test
    public void testGetStringByNameWithMissingValueThrows() {
        // "C" is mapped to index 2 but the short record only holds 2 values.
        try {
            shortRecord.get("C");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage(), e.getMessage().contains("C"));
        }
    }

    // ------------------------------------------------------------------
    // get(Enum)
    // ------------------------------------------------------------------

    @Test
    public void testGetByEnum() {
        assertEquals("a", record.get(Column.A));
        assertEquals("b", record.get(Column.B));
        assertEquals("c", record.get(Column.C));
        // get(Enum) must be equivalent to get(String) using the enum name.
        assertEquals(record.get("C"), record.get(Column.C));
    }

    @Test(expected = IllegalStateException.class)
    public void testGetByEnumWhenNoHeaderThrows() {
        recordNoHeader.get(Column.A);
    }

    @Test(expected = NullPointerException.class)
    public void testGetByNullEnumThrows() {
        record.get((Column) null);
    }

    // ------------------------------------------------------------------
    // getComment()
    // ------------------------------------------------------------------

    @Test
    public void testGetComment() {
        assertEquals("row comment", recordWithComment.getComment());
    }

    @Test
    public void testGetCommentWhenNonePresent() {
        assertNull(record.getComment());
        assertNull(recordNoHeader.getComment());
    }

    // ------------------------------------------------------------------
    // getRecordNumber()
    // ------------------------------------------------------------------

    @Test
    public void testGetRecordNumber() {
        assertEquals(1L, record.getRecordNumber());
        assertEquals(6L, recordWithComment.getRecordNumber());
        assertEquals(2L, recordNoHeader.getRecordNumber());
    }

    // ------------------------------------------------------------------
    // size()
    // ------------------------------------------------------------------

    @Test
    public void testSize() {
        assertEquals(3, record.size());
        assertEquals(2, shortRecord.size());
    }

    @Test
    public void testSizeOfEmptyRecord() {
        assertEquals(0, new CSVRecord(new String[0], null, null, 0L).size());
    }

    @Test
    public void testSizeWhenValuesAreNull() {
        // The constructor substitutes an empty array for null values.
        assertEquals(0, new CSVRecord(null, null, null, 0L).size());
    }

    // ------------------------------------------------------------------
    // isConsistent()
    // ------------------------------------------------------------------

    @Test
    public void testIsConsistentWithMatchingHeader() {
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentWithoutHeader() {
        assertTrue(recordNoHeader.isConsistent());
    }

    @Test
    public void testIsConsistentIsFalseForShortRecord() {
        assertFalse(shortRecord.isConsistent());
    }

    // ------------------------------------------------------------------
    // isMapped()
    // ------------------------------------------------------------------

    @Test
    public void testIsMapped() {
        assertTrue(record.isMapped("A"));
        assertTrue(record.isMapped("C"));
    }

    @Test
    public void testIsMappedForUnknownName() {
        assertFalse(record.isMapped("NOT_A_COLUMN"));
    }

    @Test
    public void testIsMappedWithoutHeader() {
        assertFalse(recordNoHeader.isMapped("A"));
    }

    // ------------------------------------------------------------------
    // isSet()
    // ------------------------------------------------------------------

    @Test
    public void testIsSetForMappedNameWithValue() {
        assertTrue(record.isSet("A"));
        assertTrue(record.isSet("C"));
    }

    @Test
    public void testIsSetIsFalseWhenValueMissing() {
        // "C" is mapped to index 2, but the short record has no value there.
        assertTrue(shortRecord.isSet("B"));
        assertFalse(shortRecord.isSet("C"));
    }

    @Test
    public void testIsSetIsFalseForUnknownName() {
        assertFalse(record.isSet("NOT_A_COLUMN"));
    }

    @Test
    public void testIsSetWithoutHeader() {
        assertFalse(recordNoHeader.isSet("A"));
    }

    // ------------------------------------------------------------------
    // iterator() / Iterable
    // ------------------------------------------------------------------

    @Test
    public void testIterator() {
        final Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("a", it.next());
        assertEquals("b", it.next());
        assertEquals("c", it.next());
        assertFalse(it.hasNext());
    }

    @Test(expected = NoSuchElementException.class)
    public void testIteratorThrowsWhenExhausted() {
        final Iterator<String> it = new CSVRecord(new String[0], null, null, 0L).iterator();
        it.next();
    }

    @Test
    public void testForEachIteratesEveryValueInOrder() {
        final List<String> collected = new ArrayList<String>();
        for (final String value : record) {
            collected.add(value);
        }
        assertEquals(Arrays.asList("a", "b", "c"), collected);
    }

    @Test
    public void testIteratorsAreIndependent() {
        final Iterator<String> first = record.iterator();
        final Iterator<String> second = record.iterator();
        assertNotSame(first, second);
        assertEquals("a", first.next());
        // Advancing the first iterator must not advance the second.
        assertEquals("a", second.next());
    }

    // ------------------------------------------------------------------
    // toMap()
    // ------------------------------------------------------------------

    @Test
    public void testToMap() {
        final Map<String, String> map = record.toMap();
        assertEquals(3, map.size());
        assertEquals("a", map.get("A"));
        assertEquals("b", map.get("B"));
        assertEquals("c", map.get("C"));
    }

    @Test
    public void testToMapReturnsDetachedCopy() {
        final Map<String, String> map = record.toMap();
        map.put("A", "mutated");
        map.remove("B");
        // Mutating the returned map must not affect the record.
        assertEquals("a", record.get("A"));
        assertEquals("b", record.get("B"));
        assertNotSame(map, record.toMap());
    }

    @Test
    public void testToMapWithShortRecord() {
        // Header column "C" (index 2) has no value in this record, so it is omitted.
        final Map<String, String> map = shortRecord.toMap();
        assertEquals(2, map.size());
        assertEquals("a", map.get("A"));
        assertEquals("b", map.get("B"));
        assertFalse(map.containsKey("C"));
    }

    @Test(expected = NullPointerException.class)
    public void testToMapWithoutHeaderThrows() {
        // A record parsed without a header has no mapping to build a map from.
        recordNoHeader.toMap();
    }

    // ------------------------------------------------------------------
    // toString()
    // ------------------------------------------------------------------

    @Test
    public void testToString() {
        assertEquals("[a, b, c]", record.toString());
        assertEquals("[a, b]", shortRecord.toString());
        assertEquals("[]", new CSVRecord(new String[0], null, null, 0L).toString());
    }

    // ------------------------------------------------------------------
    // constructor edge cases observable through the public API
    // ------------------------------------------------------------------

    @Test
    public void testNullValuesBehaveAsEmptyRecord() {
        final CSVRecord empty = new CSVRecord(null, null, null, 9L);
        assertEquals(0, empty.size());
        assertEquals("[]", empty.toString());
        assertFalse(empty.iterator().hasNext());
        assertEquals(9L, empty.getRecordNumber());
        assertTrue(empty.isConsistent());
    }

    // ------------------------------------------------------------------
    // Serializable
    // ------------------------------------------------------------------

    @Test
    public void testSerialization() throws Exception {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(out);
        oos.writeObject(recordWithComment);
        oos.flush();
        oos.close();

        final ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(out.toByteArray()));
        final CSVRecord deserialized = (CSVRecord) in.readObject();

        assertNotNull(deserialized);
        assertEquals(3, deserialized.size());
        assertEquals("a", deserialized.get(0));
        assertEquals("c", deserialized.get(2));
        assertEquals("row comment", deserialized.getComment());
        assertEquals(6L, deserialized.getRecordNumber());
        assertEquals("[a, b, c]", deserialized.toString());
        // The header mapping survives serialization.
        assertEquals("b", deserialized.get("B"));
        assertTrue(deserialized.isMapped("A"));
    }
}
