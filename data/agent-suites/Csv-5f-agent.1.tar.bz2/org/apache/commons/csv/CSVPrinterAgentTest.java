/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * Additional tests for {@link CSVPrinter}, exercising only the public API.
 *
 * @version $Id$
 */
public class CSVPrinterAgentTest {

    /** The record separator used by {@link CSVFormat#DEFAULT} ("\r\n"). */
    private final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();

    /**
     * An {@link Appendable} that is also {@link java.io.Closeable} and {@link java.io.Flushable} and records whether
     * those methods were invoked, so that delegation from {@link CSVPrinter} can be observed.
     */
    private static final class TrackingWriter extends Writer {
        private final StringBuilder content = new StringBuilder();
        private boolean closed;
        private boolean flushed;

        @Override
        public void write(final char[] cbuf, final int off, final int len) {
            content.append(cbuf, off, len);
        }

        @Override
        public void flush() {
            flushed = true;
        }

        @Override
        public void close() {
            closed = true;
        }

        boolean isClosed() {
            return closed;
        }

        boolean isFlushed() {
            return flushed;
        }

        @Override
        public String toString() {
            return content.toString();
        }
    }

    // ------------------------------------------------------------------
    // Constructor
    // ------------------------------------------------------------------

    @Test
    public void testGetOutReturnsUnderlyingAppendable() {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullAppendable() {
        new CSVPrinter(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullFormat() {
        new CSVPrinter(new StringWriter(), null);
    }

    @Test(expected = IllegalStateException.class)
    public void testConstructorRejectsInconsistentFormat() {
        // Quote.NONE without an escape character is an invalid combination and validate() must reject it.
        new CSVPrinter(new StringWriter(), CSVFormat.newFormat(',').withQuotePolicy(Quote.NONE));
    }

    // ------------------------------------------------------------------
    // print(Object)
    // ------------------------------------------------------------------

    @Test
    public void testPrintSingleValueHasNoLeadingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        assertEquals("a", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintInsertsDelimiterBetweenValuesButNoTrailingSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        printer.print("c");
        assertEquals("a,b,c", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintUsesObjectToStringForNonStringValues() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(Integer.valueOf(123));
        assertEquals("123", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintNullFirstOnLineIsWrittenAsQuotedEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("\"\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintNullNotFirstOnLineIsWrittenAsEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print(null);
        assertEquals("a,", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintNullUsesConfiguredNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withNullString("NULL"));
        printer.print(null);
        assertEquals("NULL", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintEmptyStringFirstOnLineIsQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("");
        assertEquals("\"\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintDoublesEmbeddedQuoteCharacter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintQuotesValueContainingNewline() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a\nb");
        assertEquals("\"a\nb\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintQuotesValueWithLeadingSpace() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(" a");
        assertEquals("\" a\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintQuotesValueWithTrailingSpace() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a ");
        assertEquals("\"a \"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintQuotesValueStartingWithCommentCharacter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("#foo");
        assertEquals("\"#foo\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintPlainValueIsNotQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("abc");
        printer.print("xyz");
        assertEquals("abc,xyz", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintWithQuotingDisabledWritesRawValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuoteChar(null));
        printer.print("a,b");
        printer.print("xyz");
        assertEquals("a,b,xyz", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintWithEscapingEscapesDelimiterAndNewline() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuoteChar(null).withEscape('!'));
        printer.print("a,b\nc");
        assertEquals("a!,b!nc", sw.toString());
        printer.close();
    }

    @Test
    public void testQuotePolicyAllQuotesEveryValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL));
        printer.printRecord("a", "b");
        assertEquals("\"a\",\"b\"" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testQuotePolicyNonNumericLeavesNumbersUnquoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.printRecord("a", Integer.valueOf(1));
        assertEquals("\"a\",1" + recordSeparator, sw.toString());
        printer.close();
    }

    // ------------------------------------------------------------------
    // println()
    // ------------------------------------------------------------------

    @Test
    public void testPrintlnWritesSeparatorAndResetsNewRecordState() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a" + recordSeparator + "b", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintlnOnFreshPrinterWritesOnlySeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.println();
        assertEquals(recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testNullRecordSeparatorWritesNothingOnPrintln() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withRecordSeparator((String) null));
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c", sw.toString());
        printer.close();
    }

    @Test
    public void testCustomRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withRecordSeparator('\n'));
        printer.printRecord("a", "b");
        assertEquals("a,b\n", sw.toString());
        printer.close();
    }

    // ------------------------------------------------------------------
    // printRecord(...)
    // ------------------------------------------------------------------

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("x", "y", "z");
        assertEquals("x,y,z" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("x", "y", "z"));
        assertEquals("x,y,z" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordNoValuesWritesOnlySeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals(recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordWithNullElementYieldsEmptyField() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("a", null, "b"));
        assertEquals("a,,b" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordQuotesFieldsThatNeedIt() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("plain", "has,comma", "has\"quote");
        assertEquals("plain,\"has,comma\",\"has\"\"quote\"" + recordSeparator, sw.toString());
        printer.close();
    }

    // ------------------------------------------------------------------
    // printRecords(...)
    // ------------------------------------------------------------------

    @Test
    public void testPrintRecordsArrayOfArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { new String[] { "a", "b" }, new String[] { "c", "d" } });
        assertEquals("a,b" + recordSeparator + "c,d" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsIterableWithMixedElementTypes() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object> rows = new ArrayList<Object>();
        rows.add(new String[] { "a", "b" });
        rows.add(Arrays.asList("c", "d"));
        rows.add("e");
        printer.printRecords(rows);
        assertEquals("a,b" + recordSeparator + "c,d" + recordSeparator + "e" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsArrayWithMixedElementTypes() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { new String[] { "a", "b" }, Arrays.asList("c", "d"), "e" });
        assertEquals("a,b" + recordSeparator + "c,d" + recordSeparator + "e" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsEmptyIterableWritesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    public void testJdbcResultSetPrinting() throws IOException, ClassNotFoundException, SQLException {
        final StringWriter sw = new StringWriter();
        Class.forName("org.h2.Driver");
        final Connection connection =
                DriverManager.getConnection("jdbc:h2:mem:csvprinteragenttest;", "sa", "");
        try {
            final Statement stmt = connection.createStatement();
            stmt.execute("CREATE TABLE TEST(ID INT PRIMARY KEY, NAME VARCHAR(255))");
            stmt.execute("insert into TEST values(1, 'r1')");
            stmt.execute("insert into TEST values(2, 'r2')");
            final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
            printer.printRecords(stmt.executeQuery("select ID, NAME from TEST"));
            assertEquals("1,r1" + recordSeparator + "2,r2" + recordSeparator, sw.toString());
            printer.close();
        } finally {
            connection.close();
        }
    }

    // ------------------------------------------------------------------
    // printComment(String)
    // ------------------------------------------------------------------

    @Test
    public void testPrintCommentIsNoOpWhenCommentsDisabled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("this must not appear");
        assertEquals("", sw.toString());
        // The no-op must not consume the "new record" state either.
        printer.print("a");
        assertEquals("a", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentSingleLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("Hello");
        assertEquals("# Hello" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentMultiLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("line1\nline2");
        assertEquals("# line1" + recordSeparator + "# line2" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentNormalizesCrLf() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("a\r\nb");
        assertEquals("# a" + recordSeparator + "# b" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentAfterValueStartsOnNewLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.print("a");
        printer.printComment("c");
        assertEquals("a" + recordSeparator + "# c" + recordSeparator, sw.toString());
        printer.close();
    }

    // ------------------------------------------------------------------
    // close() / flush()
    // ------------------------------------------------------------------

    @Test
    public void testCloseDelegatesToUnderlyingCloseable() throws IOException {
        final TrackingWriter tw = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(tw, CSVFormat.DEFAULT);
        assertFalse(tw.isClosed());
        printer.close();
        assertTrue(tw.isClosed());
    }

    @Test
    public void testFlushDelegatesToUnderlyingFlushable() throws IOException {
        final TrackingWriter tw = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(tw, CSVFormat.DEFAULT);
        assertFalse(tw.isFlushed());
        printer.flush();
        assertTrue(tw.isFlushed());
        printer.close();
    }

    @Test
    public void testFlushAndCloseAreSafeWhenAppendableIsNotCloseable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("x");
        printer.flush();
        printer.close();
        assertEquals("x", sb.toString());
    }

    // ------------------------------------------------------------------
    // Predefined formats
    // ------------------------------------------------------------------

    @Test
    public void testMysqlFormatUsesTabDelimiterAndLineFeed() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.MYSQL);
        printer.printRecord("a", "b");
        assertEquals("a\tb\n", sw.toString());
        printer.close();
    }

    @Test
    public void testMysqlFormatEscapesTabInsideValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.MYSQL);
        printer.print("a\tb");
        assertEquals("a\\\tb", sw.toString());
        printer.close();
    }

    @Test
    public void testTdfFormatQuotesValueContainingTab() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.TDF);
        printer.print("a\tb");
        assertEquals("\"a\tb\"", sw.toString());
        printer.close();
    }
}
