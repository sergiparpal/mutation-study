package org.apache.commons.csv;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link org.apache.commons.csv.CSVParser}.
 *
 * <p>Every expectation here is derived from the published javadoc contract in
 * {@code api/org/apache/commons/csv/CSVParser.html} and the package description
 * in {@code api/org/apache/commons/csv/package-summary.html}. The test lives in
 * the {@code org.apache.commons.csv} package on purpose so that the
 * package-private {@code nextRecord()} method can be exercised directly.</p>
 */
public class CSVParserAgentTest extends TestCase {

    private static final Charset UTF_8 = Charset.forName("UTF-8");

    /** Writes {@code content} to a fresh temp file (UTF-8) and returns it. */
    private static File writeTempFile(final String content) throws IOException {
        final File file = File.createTempFile("csvparser-agent-", ".csv");
        file.deleteOnExit();
        final FileOutputStream out = new FileOutputStream(file);
        try {
            out.write(content.getBytes("UTF-8"));
        } finally {
            out.close();
        }
        return file;
    }

    // ------------------------------------------------------------------
    // Construction & argument validation
    // ------------------------------------------------------------------

    public void testConstructorRejectsNullReader() throws Exception {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for null reader");
        } catch (final IllegalArgumentException expected) {
            // documented: "if either reader or format are null"
        }
    }

    public void testConstructorRejectsNullFormat() throws Exception {
        try {
            new CSVParser(new StringReader(""), null);
            fail("expected IllegalArgumentException for null format");
        } catch (final IllegalArgumentException expected) {
            // documented: "if either reader or format are null"
        }
    }

    public void testFourArgConstructorRejectsNullFormat() throws Exception {
        try {
            new CSVParser(new StringReader(""), null, 0L, 1L);
            fail("expected IllegalArgumentException for null format");
        } catch (final IllegalArgumentException expected) {
            // documented on the 4-arg constructor as well
        }
    }

    public void testConstructorProducesUsableParser() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    /**
     * The 4-arg constructor documents {@code recordNumber} as "The next record
     * number to assign", so the first record parsed must carry exactly that
     * number and subsequent records continue from there.
     */
    public void testFourArgConstructorSeedsRecordNumber() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT, 0L, 10L);
        try {
            final CSVRecord r1 = parser.nextRecord();
            assertNotNull(r1);
            assertEquals(10L, r1.getRecordNumber());
            assertEquals(10L, parser.getRecordNumber());

            final CSVRecord r2 = parser.nextRecord();
            assertNotNull(r2);
            assertEquals(11L, r2.getRecordNumber());
            assertEquals(11L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Static factory methods
    // ------------------------------------------------------------------

    public void testParseStringFactory() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(3, records.get(0).size());
        } finally {
            parser.close();
        }
    }

    public void testParseReaderFactory() throws Exception {
        final CSVParser parser = CSVParser.parse(new StringReader("a,b,c\nd,e,f"), CSVFormat.DEFAULT);
        try {
            assertEquals(2, parser.getRecords().size());
        } finally {
            parser.close();
        }
    }

    public void testParseFileFactory() throws Exception {
        final File file = writeTempFile("a,b,c\nd,e,f\n");
        final CSVParser parser = CSVParser.parse(file, UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("f", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    public void testParsePathFactory() throws Exception {
        final File file = writeTempFile("p,q\nr,s\n");
        final CSVParser parser = CSVParser.parse(file.toPath(), UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("q", records.get(0).get(1));
            assertEquals("r", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    public void testParseInputStreamFactory() throws Exception {
        final InputStream in = new ByteArrayInputStream("m,n\no,p\n".getBytes("UTF-8"));
        final CSVParser parser = CSVParser.parse(in, UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("o", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    public void testParseUrlFactory() throws Exception {
        final File file = writeTempFile("u,v\nw,x\n");
        final CSVParser parser = CSVParser.parse(file.toURI().toURL(), UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    public void testParseStringFactoryRejectsNullString() throws Exception {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for null string");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseStringFactoryRejectsNullFormat() throws Exception {
        try {
            CSVParser.parse("a,b,c", (CSVFormat) null);
            fail("expected IllegalArgumentException for null format");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseReaderFactoryRejectsNullReader() throws Exception {
        try {
            CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for null reader");
        } catch (final IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseFileFactoryRejectsNullFile() throws Exception {
        try {
            CSVParser.parse((File) null, UTF_8, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for null file");
        } catch (final IllegalArgumentException expected) {
            // documented: "if either file or format are null"
        }
    }

    public void testParseUrlFactoryRejectsNullUrl() throws Exception {
        try {
            CSVParser.parse((URL) null, UTF_8, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for null url");
        } catch (final IllegalArgumentException expected) {
            // documented: "if either url, charset or format are null"
        }
    }

    public void testCsvFormatParseShortcutReturnsParser() throws Exception {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c"));
        try {
            assertNotNull(parser);
            assertEquals(1, parser.getRecords().size());
        } finally {
            parser.close();
        }
    }

    public void testPredefinedFormatsAreAccepted() throws Exception {
        final CSVParser excel = CSVParser.parse("a,b,c", CSVFormat.EXCEL);
        try {
            assertEquals(1, excel.getRecords().size());
        } finally {
            excel.close();
        }
        final CSVParser rfc = CSVParser.parse("x,y,z\n1,2,3", CSVFormat.RFC4180);
        try {
            final List<CSVRecord> records = rfc.getRecords();
            assertEquals(2, records.size());
            assertEquals("z", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
        } finally {
            rfc.close();
        }
    }

    // ------------------------------------------------------------------
    // getRecords()
    // ------------------------------------------------------------------

    public void testGetRecordsReturnsEveryRecord() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("d", records.get(1).get(0));
            assertEquals("f", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsMayBeEmpty() throws Exception {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    /** "The returned content starts at the current parse-position in the stream." */
    public void testGetRecordsStartsAtCurrentPosition() throws Exception {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals("1", it.next().get(0));

            final List<CSVRecord> rest = parser.getRecords();
            assertEquals(3, rest.size());
            assertEquals("2", rest.get(0).get(0));
            assertEquals("3", rest.get(1).get(0));
            assertEquals("4", rest.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsAgainYieldsEmptyList() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            assertEquals(2, parser.getRecords().size());
            final List<CSVRecord> again = parser.getRecords();
            assertNotNull(again);
            assertTrue(again.isEmpty());
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsDoesNotCloseParser() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.isClosed());
        } finally {
            parser.close();
        }
        assertTrue(parser.isClosed());
    }

    /** "throws IOException - on parse error or input read-failure" */
    public void testGetRecordsThrowsIOExceptionOnParseError() throws Exception {
        final CSVParser parser = CSVParser.parse("\"unterminated", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("expected IOException for a value whose closing quote is missing");
        } catch (final IOException expected) {
            // documented
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Value parsing (package description contract)
    // ------------------------------------------------------------------

    public void testSimpleValuesWithDefaultDelimiter() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals(3, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    public void testConfigurableDelimiter() throws Exception {
        final CSVParser parser = CSVParser.parse("a;b;c", CSVFormat.newFormat(';'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }

    /** Complex value: encapsulated, containing the delimiter. */
    public void testQuotedValueContainingDelimiter() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a,a\",b", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
            assertEquals("a,a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    /** "The encapsulator itself must be escaped or doubled when used inside complex values." */
    public void testQuotedValueWithDoubledQuote() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a\"\"b\",c", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
            assertEquals("a\"b", records.get(0).get(0));
            assertEquals("c", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    /** "Complex values preserve all kind of formatting (including newlines -> multiline-values)". */
    public void testQuotedValueSpanningMultipleLines() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a\nb\",c", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
            assertEquals("a\nb", records.get(0).get(0));
            assertEquals("c", records.get(0).get(1));
            assertEquals(1L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    /** "Keep in mind that not all records must have an equal number of values". */
    public void testRecordsMayHaveDifferentSizes() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e\nf", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals(2, records.get(1).size());
            assertEquals(1, records.get(2).size());
            assertEquals("f", records.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    public void testRecordSeparatorsAreHardcoded() throws Exception {
        // '\r', '\n' and '\r\n' all terminate a record on input.
        final CSVParser lf = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            assertEquals(2, lf.getRecords().size());
        } finally {
            lf.close();
        }
        final CSVParser cr = CSVParser.parse("a,b\rc,d", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = cr.getRecords();
            assertEquals(2, records.size());
            assertEquals("c", records.get(1).get(0));
        } finally {
            cr.close();
        }
        final CSVParser crlf = CSVParser.parse("a,b\r\nc,d", CSVFormat.DEFAULT);
        try {
            assertEquals(2, crlf.getRecords().size());
        } finally {
            crlf.close();
        }
    }

    // ------------------------------------------------------------------
    // Empty line handling
    // ------------------------------------------------------------------

    public void testEmptyLinesSkippedByDefaultFormat() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n\n\nc,d\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    /** "Otherwise, empty lines will return a record with a single empty value." */
    public void testEmptyLinePreservedWhenNotIgnored() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\n\nc,d", CSVFormat.DEFAULT.withIgnoreEmptyLines(false));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(1).size());
            assertEquals("", records.get(1).get(0));
            assertEquals("c", records.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Comments
    // ------------------------------------------------------------------

    public void testCommentLinesAreRemovedFromInput() throws Exception {
        final CSVParser parser = CSVParser.parse("#comment line\na,b,c\n",
                CSVFormat.DEFAULT.withCommentMarker('#'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals("a", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    public void testCommentTextIsExposedOnFollowingRecord() throws Exception {
        final CSVParser parser = CSVParser.parse("#the comment\na,b\n",
                CSVFormat.DEFAULT.withCommentMarker('#'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertTrue(record.hasComment());
            assertEquals("the comment", record.getComment());
        } finally {
            parser.close();
        }
    }

    public void testNoCommentMarkerMeansHashIsData() throws Exception {
        final CSVParser parser = CSVParser.parse("#x,y\na,b", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("#x", records.get(0).get(0));
            assertEquals("y", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Surrounding whitespace
    // ------------------------------------------------------------------

    public void testIgnoreSurroundingSpacesEnabled() throws Exception {
        final CSVParser parser = CSVParser.parse(" a , b ,c ",
                CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }

    public void testIgnoreSurroundingSpacesDisabled() throws Exception {
        final CSVParser parser = CSVParser.parse(" a , b ",
                CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
            assertEquals(" a ", records.get(0).get(0));
            assertEquals(" b ", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Header handling & getHeaderMap()
    // ------------------------------------------------------------------

    public void testHeaderMapFromExplicitHeader() throws Exception {
        final CSVParser parser = CSVParser.parse("x,y,z\n1,2,3",
                CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            assertEquals(3, headerMap.size());
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            // "iterates in column order"
            final Iterator<String> keys = headerMap.keySet().iterator();
            assertEquals("A", keys.next());
            assertEquals("B", keys.next());
            assertEquals("C", keys.next());

            // explicit header does not consume the first data row
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get("A"));
            assertEquals("z", records.get(0).get("C"));
            assertEquals("2", records.get(1).get("B"));
        } finally {
            parser.close();
        }
    }

    /** "Returns a copy of the header map" - mutating the result must not affect the parser. */
    public void testHeaderMapIsADefensiveCopy() throws Exception {
        final CSVParser parser = CSVParser.parse("1,2,3",
                CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> first = parser.getHeaderMap();
            first.clear();
            assertTrue(first.isEmpty());

            final Map<String, Integer> second = parser.getHeaderMap();
            assertEquals(3, second.size());
            assertEquals(Integer.valueOf(1), second.get("B"));
        } finally {
            parser.close();
        }
    }

    public void testHeaderMapIsNullWithoutHeader() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    public void testSkipHeaderRecordDropsFirstRow() throws Exception {
        final CSVParser parser = CSVParser.parse("A,B,C\n1,2,3\n4,5,6",
                CSVFormat.DEFAULT.withHeader("A", "B", "C").withSkipHeaderRecord(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("3", records.get(0).get("C"));
            assertEquals("4", records.get(1).get("A"));
            assertEquals("6", records.get(1).get("C"));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // Line / record counters
    // ------------------------------------------------------------------

    public void testRecordNumberStartsAtZeroThenCounts() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc", CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(1L, parser.getRecordNumber());
            it.next();
            assertEquals(2L, parser.getRecordNumber());
            it.next();
            assertEquals(3L, parser.getRecordNumber());
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    public void testCurrentLineNumberStartsAtZero() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getCurrentLineNumber());
            parser.getRecords();
            // a single line with no end-of-line marker: nothing counted
            assertEquals(0L, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    public void testCurrentLineNumberCountsEndOfLines() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(3L, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    /**
     * The javadoc ATTENTION note: with multi-line values the line number does not
     * match the record number - it runs ahead of it.
     */
    public void testLineNumberRunsAheadOfRecordNumberForMultiLineValues() throws Exception {
        final CSVParser parser = CSVParser.parse("\"a\nb\nc\"\nx,y\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(1, records.get(0).size());
            assertEquals("a\nb\nc", records.get(0).get(0));
            assertEquals(2, records.get(1).size());

            assertEquals(2L, parser.getRecordNumber());
            assertEquals(4L, parser.getCurrentLineNumber());
            assertTrue(parser.getCurrentLineNumber() > parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // getFirstEndOfLine()
    // ------------------------------------------------------------------

    public void testFirstEndOfLineCrLf() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    public void testFirstEndOfLineLf() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    public void testFirstEndOfLineCr() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\rc,d", CSVFormat.DEFAULT);
        try {
            assertEquals(2, parser.getRecords().size());
            assertEquals("\r", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    public void testFirstEndOfLineNullWhenNoneEncountered() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertNull(parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // close() / isClosed()
    // ------------------------------------------------------------------

    public void testIsClosedReflectsCloseAndIsIdempotent() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        // Closeable contract: closing again has no effect
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ------------------------------------------------------------------
    // iterator()
    // ------------------------------------------------------------------

    public void testIteratorWalksAllRecordsThenThrows() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertEquals("a", it.next().get(0));
            assertTrue(it.hasNext());
            assertEquals("d", it.next().get(1));
            assertTrue(it.hasNext());
            assertEquals("f", it.next().get(1));
            assertFalse(it.hasNext());
            try {
                it.next();
                fail("expected NoSuchElementException past the last record");
            } catch (final NoSuchElementException expected) {
                // standard iterator contract
            }
        } finally {
            parser.close();
        }
    }

    /** "If the parser is closed a call to Iterator.next() will throw a NoSuchElementException." */
    public void testIteratorNextAfterCloseThrowsNoSuchElement() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("expected NoSuchElementException on a closed parser");
        } catch (final NoSuchElementException expected) {
            // documented
        }
    }

    public void testIteratorRemoveIsUnsupported() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            it.next();
            try {
                it.remove();
                fail("expected UnsupportedOperationException from remove()");
            } catch (final UnsupportedOperationException expected) {
                // records cannot be removed from the underlying stream
            }
        } finally {
            parser.close();
        }
    }

    /** "An IOException caught during the iteration are re-thrown as an IllegalStateException." */
    public void testIteratorWrapsParseErrorInIllegalStateException() throws Exception {
        final CSVParser parser = CSVParser.parse("\"unterminated", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.hasNext();
                it.next();
                fail("expected IllegalStateException wrapping the parse error");
            } catch (final IllegalStateException expected) {
                // documented
            }
        } finally {
            parser.close();
        }
    }

    public void testIterableReturnsRecordsInDocumentedForEachStyle() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\ng,h,i", CSVFormat.DEFAULT);
        try {
            int count = 0;
            String lastFirstField = null;
            for (final CSVRecord record : parser) {
                assertEquals(3, record.size());
                lastFirstField = record.get(0);
                count++;
            }
            assertEquals(3, count);
            assertEquals("g", lastFirstField);
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // nextRecord() (package-private)
    // ------------------------------------------------------------------

    public void testNextRecordReturnsNullAtEndOfStream() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            final CSVRecord r1 = parser.nextRecord();
            assertNotNull(r1);
            assertEquals("a", r1.get(0));
            assertEquals("b", r1.get(1));

            final CSVRecord r2 = parser.nextRecord();
            assertNotNull(r2);
            assertEquals("c", r2.get(0));
            assertEquals("d", r2.get(1));

            assertNull(parser.nextRecord());
            // stays null on further calls
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    public void testNextRecordAssignsIncreasingRecordNumbers() throws Exception {
        final CSVParser parser = CSVParser.parse("a\nb\nc", CSVFormat.DEFAULT);
        try {
            assertEquals(1L, parser.nextRecord().getRecordNumber());
            assertEquals(2L, parser.nextRecord().getRecordNumber());
            assertEquals(3L, parser.nextRecord().getRecordNumber());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }
}
