/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import java.math.BigDecimal;
import java.math.BigInteger;

import junit.framework.TestCase;

/**
 * Independent unit tests for {@link org.apache.commons.lang3.math.NumberUtils}.
 *
 * <p>These tests exercise the public API only and assert on returned values and
 * observable state (types produced, thrown exception classes), covering
 * boundary and error conditions as well as the happy path.</p>
 */
public class NumberUtilsAgentTest extends TestCase {

    public NumberUtilsAgentTest(String name) {
        super(name);
    }

    private static final double DELTA = 0.00001d;

    //-----------------------------------------------------------------------
    public void testConstructorIsPublic() {
        assertNotNull(new NumberUtils());
    }

    public void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());

        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());

        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());

        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());

        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);

        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    //-----------------------------------------------------------------------
    // toInt
    //-----------------------------------------------------------------------
    public void testToInt_String() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(0, NumberUtils.toInt("   "));
        assertEquals(0, NumberUtils.toInt("abc"));
        assertEquals(0, NumberUtils.toInt("1.5"));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(-1, NumberUtils.toInt("-1"));
        assertEquals(Integer.MAX_VALUE, NumberUtils.toInt(Integer.toString(Integer.MAX_VALUE)));
        assertEquals(Integer.MIN_VALUE, NumberUtils.toInt(Integer.toString(Integer.MIN_VALUE)));
        // overflow -> 0
        assertEquals(0, NumberUtils.toInt("2147483648"));
    }

    public void testToInt_String_int() {
        assertEquals(5, NumberUtils.toInt(null, 5));
        assertEquals(5, NumberUtils.toInt("", 5));
        assertEquals(5, NumberUtils.toInt("not a number", 5));
        assertEquals(5, NumberUtils.toInt("2147483648", 5)); // overflow -> default
        assertEquals(123, NumberUtils.toInt("123", 5));
        assertEquals(-123, NumberUtils.toInt("-123", 5));
    }

    //-----------------------------------------------------------------------
    // toLong
    //-----------------------------------------------------------------------
    public void testToLong_String() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(0L, NumberUtils.toLong("abc"));
        assertEquals(0L, NumberUtils.toLong("1.5"));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(-12345678901L, NumberUtils.toLong("-12345678901"));
        assertEquals(Long.MAX_VALUE, NumberUtils.toLong(Long.toString(Long.MAX_VALUE)));
        // overflow -> 0
        assertEquals(0L, NumberUtils.toLong("9223372036854775808"));
    }

    public void testToLong_String_long() {
        assertEquals(42L, NumberUtils.toLong(null, 42L));
        assertEquals(42L, NumberUtils.toLong("", 42L));
        assertEquals(42L, NumberUtils.toLong("SixtyFour", 42L));
        assertEquals(42L, NumberUtils.toLong("99999999999999999999999", 42L));
        assertEquals(64L, NumberUtils.toLong("64", 42L));
    }

    //-----------------------------------------------------------------------
    // toFloat
    //-----------------------------------------------------------------------
    public void testToFloat_String() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("abc"), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), DELTA);
        assertEquals(-2.25f, NumberUtils.toFloat("-2.25"), DELTA);
    }

    public void testToFloat_String_float() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("bad", 1.1f), 0.0f);
        assertEquals(2.7f, NumberUtils.toFloat("2.7", 1.1f), DELTA);
    }

    //-----------------------------------------------------------------------
    // toDouble
    //-----------------------------------------------------------------------
    public void testToDouble_String() {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("abc"), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), DELTA);
        assertEquals(-2.25d, NumberUtils.toDouble("-2.25"), DELTA);
    }

    public void testToDouble_String_double() {
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("bad", 1.1d), 0.0d);
        assertEquals(2.7d, NumberUtils.toDouble("2.7", 1.1d), DELTA);
    }

    //-----------------------------------------------------------------------
    // toByte
    //-----------------------------------------------------------------------
    public void testToByte_String() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 0, NumberUtils.toByte("abc"));
        assertEquals((byte) 0, NumberUtils.toByte("128")); // overflow -> 0
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) -128, NumberUtils.toByte("-128"));
        assertEquals((byte) 127, NumberUtils.toByte("127"));
    }

    public void testToByte_String_byte() {
        assertEquals((byte) 3, NumberUtils.toByte(null, (byte) 3));
        assertEquals((byte) 3, NumberUtils.toByte("", (byte) 3));
        assertEquals((byte) 3, NumberUtils.toByte("bad", (byte) 3));
        assertEquals((byte) 3, NumberUtils.toByte("128", (byte) 3)); // overflow -> default
        assertEquals((byte) 12, NumberUtils.toByte("12", (byte) 3));
    }

    //-----------------------------------------------------------------------
    // toShort
    //-----------------------------------------------------------------------
    public void testToShort_String() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 0, NumberUtils.toShort("abc"));
        assertEquals((short) 0, NumberUtils.toShort("32768")); // overflow -> 0
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) -32768, NumberUtils.toShort("-32768"));
        assertEquals((short) 32767, NumberUtils.toShort("32767"));
    }

    public void testToShort_String_short() {
        assertEquals((short) 3, NumberUtils.toShort(null, (short) 3));
        assertEquals((short) 3, NumberUtils.toShort("", (short) 3));
        assertEquals((short) 3, NumberUtils.toShort("bad", (short) 3));
        assertEquals((short) 3, NumberUtils.toShort("32768", (short) 3)); // overflow -> default
        assertEquals((short) 1234, NumberUtils.toShort("1234", (short) 3));
    }

    //-----------------------------------------------------------------------
    // createNumber
    //-----------------------------------------------------------------------
    public void testCreateNumber_null() {
        assertNull(NumberUtils.createNumber(null));
    }

    public void testCreateNumber_integers() {
        Number n = NumberUtils.createNumber("123");
        assertTrue("expected Integer but was " + n.getClass(), n instanceof Integer);
        assertEquals(Integer.valueOf(123), n);

        assertEquals(Integer.valueOf(-123), NumberUtils.createNumber("-123"));
        assertTrue(NumberUtils.createNumber("-123") instanceof Integer);
    }

    public void testCreateNumber_promotesToLong() {
        Number n = NumberUtils.createNumber("12345678901234");
        assertTrue("expected Long but was " + n.getClass(), n instanceof Long);
        assertEquals(Long.valueOf(12345678901234L), n);
    }

    public void testCreateNumber_promotesToBigInteger() {
        Number n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue("expected BigInteger but was " + n.getClass(), n instanceof BigInteger);
        assertEquals(new BigInteger("123456789012345678901234567890"), n);
    }

    public void testCreateNumber_hex() {
        assertEquals(Integer.valueOf(0x1F), NumberUtils.createNumber("0x1F"));
        assertTrue(NumberUtils.createNumber("0x1F") instanceof Integer);
        assertEquals(Integer.valueOf(-0x1F), NumberUtils.createNumber("-0x1F"));
    }

    public void testCreateNumber_typeQualifiers() {
        assertEquals(Long.valueOf(1234L), NumberUtils.createNumber("1234L"));
        assertTrue(NumberUtils.createNumber("1234L") instanceof Long);

        assertTrue(NumberUtils.createNumber("1.5F") instanceof Float);
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5F"));

        assertTrue(NumberUtils.createNumber("1.5D") instanceof Double);
        assertEquals(Double.valueOf(1.5d), NumberUtils.createNumber("1.5D"));
    }

    public void testCreateNumber_decimalDefaultsToFloat() {
        Number n = NumberUtils.createNumber("1.5");
        assertTrue("expected Float but was " + n.getClass(), n instanceof Float);
        assertEquals(Float.valueOf(1.5f), n);
    }

    public void testCreateNumber_scientificNotation() {
        Number n = NumberUtils.createNumber("1.23E3");
        assertTrue("expected Float but was " + n.getClass(), n instanceof Float);
        assertEquals(1230.0f, n.floatValue(), DELTA);

        Number m = NumberUtils.createNumber("1e10");
        assertTrue("expected Float but was " + m.getClass(), m instanceof Float);
        assertEquals(1.0e10f, m.floatValue(), 1.0f);
    }

    public void testCreateNumber_doubleDash() {
        assertNull(NumberUtils.createNumber("--1"));
    }

    public void testCreateNumber_blankThrows() {
        try {
            NumberUtils.createNumber("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    public void testCreateNumber_invalidThrows() {
        String[] invalid = new String[] { "abc", "1a", "1b2", "1.2.3", "12.5.6" };
        for (int i = 0; i < invalid.length; i++) {
            try {
                Number result = NumberUtils.createNumber(invalid[i]);
                fail("expecting NumberFormatException for \"" + invalid[i] + "\" but got " + result);
            } catch (NumberFormatException ex) {
                // expected
            }
        }
    }

    //-----------------------------------------------------------------------
    // createFloat / createDouble
    //-----------------------------------------------------------------------
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertEquals(Float.valueOf(-1.5f), NumberUtils.createFloat("-1.5"));
        try {
            NumberUtils.createFloat("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createFloat("bad");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertEquals(Double.valueOf(-1.5d), NumberUtils.createDouble("-1.5"));
        try {
            NumberUtils.createDouble("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createDouble("bad");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // createInteger / createLong
    //-----------------------------------------------------------------------
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(-123), NumberUtils.createInteger("-123"));
        assertEquals(Integer.valueOf(0x1F), NumberUtils.createInteger("0x1F"));
        try {
            NumberUtils.createInteger("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createInteger("99999999999"); // out of int range
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(-123L), NumberUtils.createLong("-123"));
        assertEquals(Long.valueOf(12345678901L), NumberUtils.createLong("12345678901"));
        try {
            NumberUtils.createLong("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createLong("1.5");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // createBigInteger / createBigDecimal
    //-----------------------------------------------------------------------
    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("12345678901234567890"),
                     NumberUtils.createBigInteger("12345678901234567890"));
        assertEquals(new BigInteger("-42"), NumberUtils.createBigInteger("-42"));
        try {
            NumberUtils.createBigInteger("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createBigInteger("1.5");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("123.456"), NumberUtils.createBigDecimal("123.456"));
        assertEquals(new BigDecimal("-0.5"), NumberUtils.createBigDecimal("-0.5"));
        try {
            NumberUtils.createBigDecimal("");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("   ");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not-a-number");
            fail("expecting NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // min / max : arrays
    //-----------------------------------------------------------------------
    public void testMinMax_longArray() {
        assertEquals(2L, NumberUtils.min(new long[] { 5, 2, 7 }));
        assertEquals(-7L, NumberUtils.min(new long[] { -5, -2, -7 }));
        assertEquals(42L, NumberUtils.min(new long[] { 42 }));
        assertEquals(7L, NumberUtils.max(new long[] { 5, 2, 7 }));
        assertEquals(-2L, NumberUtils.max(new long[] { -5, -2, -7 }));
        assertEquals(42L, NumberUtils.max(new long[] { 42 }));
        assertMinMaxArrayValidation(long.class);
    }

    public void testMinMax_intArray() {
        assertEquals(2, NumberUtils.min(new int[] { 5, 2, 7 }));
        assertEquals(-7, NumberUtils.min(new int[] { -5, -2, -7 }));
        assertEquals(42, NumberUtils.min(new int[] { 42 }));
        assertEquals(7, NumberUtils.max(new int[] { 5, 2, 7 }));
        assertEquals(-2, NumberUtils.max(new int[] { -5, -2, -7 }));
        assertMinMaxArrayValidation(int.class);
    }

    public void testMinMax_shortArray() {
        assertEquals((short) 2, NumberUtils.min(new short[] { 5, 2, 7 }));
        assertEquals((short) -7, NumberUtils.min(new short[] { -5, -2, -7 }));
        assertEquals((short) 7, NumberUtils.max(new short[] { 5, 2, 7 }));
        assertEquals((short) -2, NumberUtils.max(new short[] { -5, -2, -7 }));
        assertMinMaxArrayValidation(short.class);
    }

    public void testMinMax_byteArray() {
        assertEquals((byte) 2, NumberUtils.min(new byte[] { 5, 2, 7 }));
        assertEquals((byte) -7, NumberUtils.min(new byte[] { -5, -2, -7 }));
        assertEquals((byte) 7, NumberUtils.max(new byte[] { 5, 2, 7 }));
        assertEquals((byte) -2, NumberUtils.max(new byte[] { -5, -2, -7 }));
        assertMinMaxArrayValidation(byte.class);
    }

    public void testMinMax_doubleArray() {
        assertEquals(0.5d, NumberUtils.min(new double[] { 1.2, 3.4, 0.5 }), DELTA);
        assertEquals(3.4d, NumberUtils.max(new double[] { 1.2, 3.4, 0.5 }), DELTA);
        assertEquals(5.0d, NumberUtils.min(new double[] { 5.0 }), DELTA);
        // NaN is propagated
        assertTrue(Double.isNaN(NumberUtils.min(new double[] { 1.2, Double.NaN, 3.4 })));
        assertTrue(Double.isNaN(NumberUtils.max(new double[] { 1.2, Double.NaN, 3.4 })));
        assertMinMaxArrayValidation(double.class);
    }

    public void testMinMax_floatArray() {
        assertEquals(0.5f, NumberUtils.min(new float[] { 1.2f, 3.4f, 0.5f }), DELTA);
        assertEquals(3.4f, NumberUtils.max(new float[] { 1.2f, 3.4f, 0.5f }), DELTA);
        assertTrue(Float.isNaN(NumberUtils.min(new float[] { 1.2f, Float.NaN, 3.4f })));
        assertTrue(Float.isNaN(NumberUtils.max(new float[] { 1.2f, Float.NaN, 3.4f })));
        assertMinMaxArrayValidation(float.class);
    }

    /** Asserts that both min and max reject null and empty arrays of the given primitive type. */
    private void assertMinMaxArrayValidation(Class<?> primitive) {
        Runnable[] calls = buildInvalidArrayCalls(primitive);
        for (int i = 0; i < calls.length; i++) {
            try {
                calls[i].run();
                fail("expecting IllegalArgumentException (call index " + i + ", type " + primitive + ")");
            } catch (IllegalArgumentException ex) {
                // expected
            }
        }
    }

    private Runnable[] buildInvalidArrayCalls(Class<?> primitive) {
        if (primitive == long.class) {
            return new Runnable[] {
                new Runnable() { public void run() { NumberUtils.min((long[]) null); } },
                new Runnable() { public void run() { NumberUtils.min(new long[0]); } },
                new Runnable() { public void run() { NumberUtils.max((long[]) null); } },
                new Runnable() { public void run() { NumberUtils.max(new long[0]); } },
            };
        }
        if (primitive == int.class) {
            return new Runnable[] {
                new Runnable() { public void run() { NumberUtils.min((int[]) null); } },
                new Runnable() { public void run() { NumberUtils.min(new int[0]); } },
                new Runnable() { public void run() { NumberUtils.max((int[]) null); } },
                new Runnable() { public void run() { NumberUtils.max(new int[0]); } },
            };
        }
        if (primitive == short.class) {
            return new Runnable[] {
                new Runnable() { public void run() { NumberUtils.min((short[]) null); } },
                new Runnable() { public void run() { NumberUtils.min(new short[0]); } },
                new Runnable() { public void run() { NumberUtils.max((short[]) null); } },
                new Runnable() { public void run() { NumberUtils.max(new short[0]); } },
            };
        }
        if (primitive == byte.class) {
            return new Runnable[] {
                new Runnable() { public void run() { NumberUtils.min((byte[]) null); } },
                new Runnable() { public void run() { NumberUtils.min(new byte[0]); } },
                new Runnable() { public void run() { NumberUtils.max((byte[]) null); } },
                new Runnable() { public void run() { NumberUtils.max(new byte[0]); } },
            };
        }
        if (primitive == double.class) {
            return new Runnable[] {
                new Runnable() { public void run() { NumberUtils.min((double[]) null); } },
                new Runnable() { public void run() { NumberUtils.min(new double[0]); } },
                new Runnable() { public void run() { NumberUtils.max((double[]) null); } },
                new Runnable() { public void run() { NumberUtils.max(new double[0]); } },
            };
        }
        if (primitive == float.class) {
            return new Runnable[] {
                new Runnable() { public void run() { NumberUtils.min((float[]) null); } },
                new Runnable() { public void run() { NumberUtils.min(new float[0]); } },
                new Runnable() { public void run() { NumberUtils.max((float[]) null); } },
                new Runnable() { public void run() { NumberUtils.max(new float[0]); } },
            };
        }
        throw new IllegalArgumentException("unsupported: " + primitive);
    }

    //-----------------------------------------------------------------------
    // min / max : three arguments
    //-----------------------------------------------------------------------
    public void testMinMax_threeLongs() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(3L, 2L, 1L));
        assertEquals(1L, NumberUtils.min(2L, 1L, 3L));
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(3L, NumberUtils.max(3L, 1L, 2L));
        assertEquals(3L, NumberUtils.max(1L, 3L, 2L));
    }

    public void testMinMax_threeInts() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
        assertEquals(1, NumberUtils.min(2, 1, 3));
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 1, 2));
        assertEquals(3, NumberUtils.max(1, 3, 2));
    }

    public void testMinMax_threeShorts() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 2, (short) 1));
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
        assertEquals((short) 3, NumberUtils.max((short) 3, (short) 1, (short) 2));
    }

    public void testMinMax_threeBytes() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 2, (byte) 1));
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 1, (byte) 2));
    }

    public void testMinMax_threeDoubles() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 2.0d, 3.0d), DELTA);
        assertEquals(1.0d, NumberUtils.min(3.0d, 2.0d, 1.0d), DELTA);
        assertEquals(3.0d, NumberUtils.max(1.0d, 2.0d, 3.0d), DELTA);
        assertEquals(3.0d, NumberUtils.max(3.0d, 1.0d, 2.0d), DELTA);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, 2.0d, Double.NaN)));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, 2.0d, Double.NaN)));
    }

    public void testMinMax_threeFloats() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f), DELTA);
        assertEquals(1.0f, NumberUtils.min(3.0f, 2.0f, 1.0f), DELTA);
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f), DELTA);
        assertEquals(3.0f, NumberUtils.max(3.0f, 1.0f, 2.0f), DELTA);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, 2.0f, Float.NaN)));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, 2.0f, Float.NaN)));
    }

    //-----------------------------------------------------------------------
    // isDigits
    //-----------------------------------------------------------------------
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("0"));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("1234.5"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12 34"));
        assertFalse(NumberUtils.isDigits("12a34"));
    }

    //-----------------------------------------------------------------------
    // isNumber
    //-----------------------------------------------------------------------
    public void testIsNumber_nullAndEmpty() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertFalse(NumberUtils.isNumber(" "));
    }

    public void testIsNumber_validForms() {
        assertTrue(NumberUtils.isNumber("0"));
        assertTrue(NumberUtils.isNumber("123"));
        assertTrue(NumberUtils.isNumber("-123"));
        assertTrue(NumberUtils.isNumber("123.45"));
        assertTrue(NumberUtils.isNumber("-123.45"));
        assertTrue(NumberUtils.isNumber(".5"));
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertTrue(NumberUtils.isNumber("1e10"));
        assertTrue(NumberUtils.isNumber("1E10"));
        assertTrue(NumberUtils.isNumber("1.5e-10"));
        assertTrue(NumberUtils.isNumber("1.5E+10"));
        assertTrue(NumberUtils.isNumber("123L"));
        assertTrue(NumberUtils.isNumber("12.5D"));
        assertTrue(NumberUtils.isNumber("12.5f"));
    }

    public void testIsNumber_invalidForms() {
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber("12 34"));
        assertFalse(NumberUtils.isNumber("1.2.3"));
        assertFalse(NumberUtils.isNumber("--1"));
        assertFalse(NumberUtils.isNumber("0x"));
        assertFalse(NumberUtils.isNumber("0xG1"));
        assertFalse(NumberUtils.isNumber("1e"));
        assertFalse(NumberUtils.isNumber("1e10L")); // L not allowed with an exponent
        assertFalse(NumberUtils.isNumber("."));
        assertFalse(NumberUtils.isNumber("-"));
        assertFalse(NumberUtils.isNumber("1E--5"));
    }

    //-----------------------------------------------------------------------
    // Cross-check: values accepted by isNumber that createNumber should parse
    //-----------------------------------------------------------------------
    public void testCreateNumber_matchesIsNumberForCommonForms() {
        String[] good = new String[] { "0", "123", "-123", "123.45", "1e10", "123L", "12.5D" };
        for (int i = 0; i < good.length; i++) {
            assertTrue("isNumber(\"" + good[i] + "\")", NumberUtils.isNumber(good[i]));
            assertNotNull("createNumber(\"" + good[i] + "\")", NumberUtils.createNumber(good[i]));
        }
    }
}
