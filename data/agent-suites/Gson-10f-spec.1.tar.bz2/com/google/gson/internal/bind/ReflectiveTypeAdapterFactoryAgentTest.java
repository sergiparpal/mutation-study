package com.google.gson.internal.bind;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.Expose;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link ReflectiveTypeAdapterFactory}, based solely on the documented contract:
 * the class reflects over the fields of a plain class to build a {@code TypeAdapter}, and
 * {@code create} returns null when the factory does not support a given type.
 */
public class ReflectiveTypeAdapterFactoryAgentTest {

    // ---- Fixtures -----------------------------------------------------------------------

    private static class Pojo {
        String name;
        int age;
        transient String ignoredTransient = "secret";
        static String staticField = "static";

        public Pojo() {}

        public Pojo(String name, int age) {
            this.name = name;
            this.age = age;
        }
    }

    private static class PojoWithNullableField {
        String name;

        public PojoWithNullableField() {}
    }

    private static class Empty {
        public Empty() {}
    }

    private static class Named {
        String myValue = "x";

        public Named() {}
    }

    private static class ExposePojo {
        @Expose
        String shown = "visible";
        String hidden = "secret";

        public ExposePojo() {}
    }

    private static class Holder {
        public Holder() {}
    }

    // ---- Common test state ---------------------------------------------------------------

    private Gson gson;
    private ConstructorConstructor constructorConstructor;
    private Excluder excluder;
    private ReflectiveTypeAdapterFactory factory;

    @Before
    public void setUp() {
        gson = new Gson();
        constructorConstructor =
                new ConstructorConstructor(new HashMap<Type, InstanceCreator<?>>());
        excluder = Excluder.DEFAULT;
        factory = new ReflectiveTypeAdapterFactory(
                constructorConstructor, FieldNamingPolicy.IDENTITY, excluder);
    }

    // ---- create(Gson, TypeToken) ----------------------------------------------------------

    @Test
    public void testCreateReturnsNullForPrimitiveInt() {
        TypeAdapter<Integer> adapter = factory.create(gson, TypeToken.get(int.class));
        assertNull(adapter);
    }

    @Test
    public void testCreateReturnsNullForPrimitiveBoolean() {
        TypeAdapter<Boolean> adapter = factory.create(gson, TypeToken.get(boolean.class));
        assertNull(adapter);
    }

    @Test
    public void testCreateReturnsNonNullAdapterForPlainClass() {
        TypeAdapter<Pojo> adapter = factory.create(gson, TypeToken.get(Pojo.class));
        assertNotNull(adapter);
    }

    @Test
    public void testCreateAdapterRoundTripsFieldsAndSkipsTransientAndStatic() throws IOException {
        TypeAdapter<Pojo> adapter = factory.create(gson, TypeToken.get(Pojo.class));
        assertNotNull(adapter);

        Pojo original = new Pojo("Alice", 30);
        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        adapter.write(jw, original);
        jw.flush();
        String json = sw.toString();

        assertTrue("expected name field in: " + json, json.contains("\"name\":\"Alice\""));
        assertTrue("expected age field in: " + json, json.contains("\"age\":30"));
        assertFalse("transient field must be excluded: " + json, json.contains("ignoredTransient"));
        assertFalse("static field must be excluded: " + json, json.contains("staticField"));

        JsonReader jr = new JsonReader(new StringReader(json));
        Pojo roundTripped = adapter.read(jr);
        assertNotNull(roundTripped);
        assertEquals("Alice", roundTripped.name);
        assertEquals(30, roundTripped.age);
    }

    @Test
    public void testCreateAdapterOnEmptyClassWritesEmptyObject() throws IOException {
        TypeAdapter<Empty> adapter = factory.create(gson, TypeToken.get(Empty.class));
        assertNotNull(adapter);

        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        adapter.write(jw, new Empty());
        jw.flush();
        assertEquals("{}", sw.toString());
    }

    @Test
    public void testCreateAppliesFieldNamingPolicy() throws IOException {
        ReflectiveTypeAdapterFactory namingFactory = new ReflectiveTypeAdapterFactory(
                constructorConstructor, FieldNamingPolicy.UPPER_CAMEL_CASE, excluder);
        TypeAdapter<Named> adapter = namingFactory.create(gson, TypeToken.get(Named.class));
        assertNotNull(adapter);

        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        adapter.write(jw, new Named());
        jw.flush();
        String json = sw.toString();

        assertTrue("expected renamed key in: " + json, json.contains("\"MyValue\":\"x\""));
        assertFalse("original field name should not appear verbatim: " + json,
                json.contains("\"myValue\""));
    }

    // @Test  // pruned: failed on the fixed version
    public void testCreateAdapterOmitsNullFieldByDefault() throws IOException {
        TypeAdapter<PojoWithNullableField> adapter =
                factory.create(gson, TypeToken.get(PojoWithNullableField.class));
        assertNotNull(adapter);

        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        adapter.write(jw, new PojoWithNullableField());
        jw.flush();
        assertEquals("{}", sw.toString());
    }

    @Test(expected = NullPointerException.class)
    public void testCreateWithNullTypeThrows() {
        factory.create(gson, null);
    }

    // ---- excludeField(Field, boolean) / excludeField(Field, boolean, Excluder) -----------

    // @Test  // pruned: failed on the fixed version
    public void testExcludeFieldTransientFieldIsExcludedByDefault() throws NoSuchFieldException {
        Field f = Pojo.class.getDeclaredField("ignoredTransient");
        assertTrue(factory.excludeField(f, true));
        assertTrue(factory.excludeField(f, false));
    }

    // @Test  // pruned: failed on the fixed version
    public void testExcludeFieldStaticFieldIsExcludedByDefault() throws NoSuchFieldException {
        Field f = Pojo.class.getDeclaredField("staticField");
        assertTrue(factory.excludeField(f, true));
        assertTrue(factory.excludeField(f, false));
    }

    // @Test  // pruned: failed on the fixed version
    public void testExcludeFieldRegularFieldIsNotExcludedByDefault() throws NoSuchFieldException {
        Field f = Pojo.class.getDeclaredField("name");
        assertFalse(factory.excludeField(f, true));
        assertFalse(factory.excludeField(f, false));
    }

    @Test
    public void testExcludeFieldInstanceMatchesStaticOverloadWithSameExcluder()
            throws NoSuchFieldException {
        Field transientField = Pojo.class.getDeclaredField("ignoredTransient");
        Field regularField = Pojo.class.getDeclaredField("name");

        assertEquals(
                ReflectiveTypeAdapterFactory.excludeField(transientField, true, excluder),
                factory.excludeField(transientField, true));
        assertEquals(
                ReflectiveTypeAdapterFactory.excludeField(regularField, true, excluder),
                factory.excludeField(regularField, true));
    }

    // @Test  // pruned: failed on the fixed version
    public void testExcludeFieldWithExposeRequirement() throws NoSuchFieldException {
        Excluder requireExpose = Excluder.DEFAULT.excludeFieldsWithoutExposeAnnotation();
        Field shown = ExposePojo.class.getDeclaredField("shown");
        Field hidden = ExposePojo.class.getDeclaredField("hidden");

        assertFalse(ReflectiveTypeAdapterFactory.excludeField(shown, true, requireExpose));
        assertTrue(ReflectiveTypeAdapterFactory.excludeField(hidden, true, requireExpose));
    }

    @Test(expected = NullPointerException.class)
    public void testExcludeFieldInstanceWithNullFieldThrows() {
        factory.excludeField(null, true);
    }

    @Test(expected = NullPointerException.class)
    public void testExcludeFieldStaticWithNullExcluderThrows() throws NoSuchFieldException {
        Field f = Pojo.class.getDeclaredField("name");
        ReflectiveTypeAdapterFactory.excludeField(f, true, null);
    }

    // ---- Nested class: BoundField ----------------------------------------------------------

    private static ReflectiveTypeAdapterFactory.BoundField newNoOpBoundField(
            String name, boolean serialized, boolean deserialized) {
        return new ReflectiveTypeAdapterFactory.BoundField(name, serialized, deserialized) {
            boolean writeField(Object value) throws IOException, IllegalAccessException {
                return serialized;
            }

            void write(JsonWriter writer, Object value) throws IOException, IllegalAccessException {
                writer.value(String.valueOf(value));
            }

            void read(JsonReader reader, Object value) throws IOException, IllegalAccessException {
                reader.skipValue();
            }
        };
    }

    @Test
    public void testBoundFieldStoresConstructorArguments() {
        ReflectiveTypeAdapterFactory.BoundField field = newNoOpBoundField("foo", true, false);
        assertEquals("foo", field.name);
        assertTrue(field.serialized);
        assertFalse(field.deserialized);
    }

    @Test
    public void testBoundFieldAllowsEmptyNameAndBothFlagsFalse() {
        ReflectiveTypeAdapterFactory.BoundField field = newNoOpBoundField("", false, false);
        assertEquals("", field.name);
        assertFalse(field.serialized);
        assertFalse(field.deserialized);
    }

    // ---- Nested class: Adapter --------------------------------------------------------------

    @Test
    public void testAdapterReadReturnsNullForJsonNull() throws IOException {
        ObjectConstructor<Holder> ctor = new ObjectConstructor<Holder>() {
            public Holder construct() {
                return new Holder();
            }
        };
        Map<String, ReflectiveTypeAdapterFactory.BoundField> boundFields =
                new LinkedHashMap<String, ReflectiveTypeAdapterFactory.BoundField>();
        ReflectiveTypeAdapterFactory.Adapter<Holder> adapter =
                new ReflectiveTypeAdapterFactory.Adapter<Holder>(ctor, boundFields);

        JsonReader reader = new JsonReader(new StringReader("null"));
        reader.setLenient(true);
        Holder result = adapter.read(reader);
        assertNull(result);
    }

    @Test
    public void testAdapterWriteNullWritesJsonNull() throws IOException {
        ObjectConstructor<Holder> ctor = new ObjectConstructor<Holder>() {
            public Holder construct() {
                return new Holder();
            }
        };
        Map<String, ReflectiveTypeAdapterFactory.BoundField> boundFields =
                new LinkedHashMap<String, ReflectiveTypeAdapterFactory.BoundField>();
        ReflectiveTypeAdapterFactory.Adapter<Holder> adapter =
                new ReflectiveTypeAdapterFactory.Adapter<Holder>(ctor, boundFields);

        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setLenient(true);
        adapter.write(writer, null);
        writer.flush();
        assertEquals("null", sw.toString());
    }

    @Test
    public void testAdapterRoundTripsWithCustomBoundFieldAndSkipsUnknownKey() throws IOException {
        ReflectiveTypeAdapterFactory.BoundField xField =
                new ReflectiveTypeAdapterFactory.BoundField("x", true, true) {
                    boolean writeField(Object value) throws IOException, IllegalAccessException {
                        return true;
                    }

                    void write(JsonWriter writer, Object value)
                            throws IOException, IllegalAccessException {
                        writer.value(((int[]) value)[0]);
                    }

                    void read(JsonReader reader, Object value)
                            throws IOException, IllegalAccessException {
                        ((int[]) value)[0] = reader.nextInt();
                    }
                };
        Map<String, ReflectiveTypeAdapterFactory.BoundField> boundFields =
                new LinkedHashMap<String, ReflectiveTypeAdapterFactory.BoundField>();
        boundFields.put("x", xField);
        ObjectConstructor<int[]> ctor = new ObjectConstructor<int[]>() {
            public int[] construct() {
                return new int[1];
            }
        };
        ReflectiveTypeAdapterFactory.Adapter<int[]> adapter =
                new ReflectiveTypeAdapterFactory.Adapter<int[]>(ctor, boundFields);

        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        adapter.write(jw, new int[] {42});
        jw.flush();
        assertEquals("{\"x\":42}", sw.toString());

        JsonReader reader = new JsonReader(new StringReader("{\"y\":5,\"x\":7}"));
        int[] result = adapter.read(reader);
        assertNotNull(result);
        assertEquals(7, result[0]);
    }

    @Test
    public void testAdapterWriteSkipsFieldWhenWriteFieldReturnsFalse() throws IOException {
        ReflectiveTypeAdapterFactory.BoundField includedField =
                new ReflectiveTypeAdapterFactory.BoundField("a", true, true) {
                    boolean writeField(Object value) throws IOException, IllegalAccessException {
                        return serialized;
                    }

                    void write(JsonWriter writer, Object value)
                            throws IOException, IllegalAccessException {
                        writer.value("A");
                    }

                    void read(JsonReader reader, Object value)
                            throws IOException, IllegalAccessException {
                        reader.skipValue();
                    }
                };
        ReflectiveTypeAdapterFactory.BoundField excludedField =
                new ReflectiveTypeAdapterFactory.BoundField("b", false, true) {
                    boolean writeField(Object value) throws IOException, IllegalAccessException {
                        return serialized;
                    }

                    void write(JsonWriter writer, Object value)
                            throws IOException, IllegalAccessException {
                        writer.value("B");
                    }

                    void read(JsonReader reader, Object value)
                            throws IOException, IllegalAccessException {
                        reader.skipValue();
                    }
                };
        Map<String, ReflectiveTypeAdapterFactory.BoundField> boundFields =
                new LinkedHashMap<String, ReflectiveTypeAdapterFactory.BoundField>();
        boundFields.put("a", includedField);
        boundFields.put("b", excludedField);
        ObjectConstructor<Holder> ctor = new ObjectConstructor<Holder>() {
            public Holder construct() {
                return new Holder();
            }
        };
        ReflectiveTypeAdapterFactory.Adapter<Holder> adapter =
                new ReflectiveTypeAdapterFactory.Adapter<Holder>(ctor, boundFields);

        StringWriter sw = new StringWriter();
        JsonWriter jw = new JsonWriter(sw);
        adapter.write(jw, new Holder());
        jw.flush();
        String json = sw.toString();

        assertTrue(json.contains("\"a\":\"A\""));
        assertFalse(json.contains("\"b\""));
    }

    @Test
    public void testAdapterReadSkipsFieldMarkedNotDeserialized() throws IOException {
        ReflectiveTypeAdapterFactory.BoundField notDeserialized =
                new ReflectiveTypeAdapterFactory.BoundField("c", true, false) {
                    boolean writeField(Object value) throws IOException, IllegalAccessException {
                        return true;
                    }

                    void write(JsonWriter writer, Object value)
                            throws IOException, IllegalAccessException {
                        writer.value("C");
                    }

                    void read(JsonReader reader, Object value)
                            throws IOException, IllegalAccessException {
                        throw new AssertionError("read() must not be invoked for a field marked deserialized=false");
                    }
                };
        Map<String, ReflectiveTypeAdapterFactory.BoundField> boundFields =
                new LinkedHashMap<String, ReflectiveTypeAdapterFactory.BoundField>();
        boundFields.put("c", notDeserialized);
        ObjectConstructor<Holder> ctor = new ObjectConstructor<Holder>() {
            public Holder construct() {
                return new Holder();
            }
        };
        ReflectiveTypeAdapterFactory.Adapter<Holder> adapter =
                new ReflectiveTypeAdapterFactory.Adapter<Holder>(ctor, boundFields);

        JsonReader reader = new JsonReader(new StringReader("{\"c\":5}"));
        Holder result = adapter.read(reader);
        assertNotNull(result);
    }
}
