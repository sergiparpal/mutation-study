package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}, written only against the
 * published javadoc contract of the class and of its {@code DatePrinter}
 * interface.
 *
 * <p>{@code FastDatePrinter} has no public constructor; the documented way to
 * obtain one is through {@code FastDateFormat}. Its {@code (String, TimeZone,
 * Locale)} constructor is {@code protected}, so this test — which lives in the
 * same package, {@code org.apache.commons.lang3.time} — is able to invoke it
 * directly to exercise the class in isolation.</p>
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final Locale US = Locale.US;

    private static FastDatePrinter printer(final String pattern, final TimeZone tz, final Locale locale) {
        return new FastDatePrinter(pattern, tz, locale);
    }

    private static FastDatePrinter gmtPrinter(final String pattern) {
        return new FastDatePrinter(pattern, GMT, US);
    }

    /** Builds a calendar holding a fully specified wall-clock time in {@code tz}. */
    private static Calendar cal(final TimeZone tz, final int year, final int month0, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final GregorianCalendar c = new GregorianCalendar(tz, US);
        c.clear();
        c.set(year, month0, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    // ------------------------------------------------------------------
    // getPattern / getTimeZone / getLocale
    // ------------------------------------------------------------------

    @Test
    public void gettersReturnConstructionParameters() {
        final TimeZone tz = TimeZone.getTimeZone("GMT-05:00");
        final FastDatePrinter p = printer("yyyy-MM-dd", tz, Locale.CANADA);
        assertEquals("yyyy-MM-dd", p.getPattern());
        assertEquals(tz, p.getTimeZone());
        assertEquals(Locale.CANADA, p.getLocale());
    }

    @Test
    public void patternIsReportedVerbatimIncludingEmptyPattern() {
        assertEquals("", gmtPrinter("").getPattern());
        assertEquals("yyyy", gmtPrinter("yyyy").getPattern());
    }

    // ------------------------------------------------------------------
    // format(long)
    // ------------------------------------------------------------------

    @Test
    public void formatLongProducesDocumentedString() {
        final long millis = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 0).getTimeInMillis();
        assertEquals("2005-07-04 13:05:30", gmtPrinter("yyyy-MM-dd HH:mm:ss").format(millis));
    }

    @Test
    public void formatsEpochInGmt() {
        assertEquals("1970-01-01 00:00:00", gmtPrinter("yyyy-MM-dd HH:mm:ss").format(0L));
    }

    @Test
    public void formatsInstantBeforeEpoch() {
        assertEquals("1969-12-31 23:59:59", gmtPrinter("yyyy-MM-dd HH:mm:ss").format(-1L));
    }

    @Test
    public void emptyPatternProducesEmptyOutput() {
        final FastDatePrinter p = gmtPrinter("");
        assertEquals("", p.format(0L));
        assertEquals("", p.format(new Date(0L)));
        assertEquals("", p.format(cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0)));
    }

    // ------------------------------------------------------------------
    // format(Date) / format(Calendar) agreement
    // ------------------------------------------------------------------

    @Test
    public void formatDateCalendarLongAgreeForSameInstant() {
        final Calendar c = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 123);
        final long millis = c.getTimeInMillis();
        final FastDatePrinter p = gmtPrinter("yyyy-MM-dd HH:mm:ss.SSS");
        final String expected = "2005-07-04 13:05:30.123";
        assertEquals(expected, p.format(millis));
        assertEquals(expected, p.format(new Date(millis)));
        assertEquals(expected, p.format(c));
    }

    @Test
    public void datePrintingAlwaysUsesPrinterTimeZone() {
        // getTimeZone() javadoc: "This zone is always used for Date printing."
        final FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("GMT+08:00"), US);
        assertEquals("1970-01-01 08:00:00", p.format(new Date(0L)));
        assertEquals("1970-01-01 08:00:00", p.format(0L));
    }

    // ------------------------------------------------------------------
    // StringBuffer overloads: must return the *same* buffer and append to it
    // ------------------------------------------------------------------

    @Test
    public void formatLongIntoStringBufferAppendsAndReturnsSameBuffer() {
        final long millis = cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0).getTimeInMillis();
        final StringBuffer buf = new StringBuffer("PRE:");
        final StringBuffer result = gmtPrinter("yyyy-MM-dd").format(millis, buf);
        assertSame(buf, result);
        assertEquals("PRE:2005-07-04", result.toString());
    }

    @Test
    public void formatDateIntoStringBufferReturnsSameBuffer() {
        final long millis = cal(GMT, 1999, Calendar.DECEMBER, 31, 0, 0, 0, 0).getTimeInMillis();
        final StringBuffer buf = new StringBuffer();
        final StringBuffer result = gmtPrinter("yyyy-MM-dd").format(new Date(millis), buf);
        assertSame(buf, result);
        assertEquals("1999-12-31", result.toString());
    }

    @Test
    public void formatCalendarIntoStringBufferReturnsSameBuffer() {
        final Calendar c = cal(GMT, 2012, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        final StringBuffer buf = new StringBuffer(">");
        final StringBuffer result = gmtPrinter("yyyy-MM-dd").format(c, buf);
        assertSame(buf, result);
        assertEquals(">2012-02-29", result.toString());
    }

    // ------------------------------------------------------------------
    // format(Object, StringBuffer, FieldPosition)
    // ------------------------------------------------------------------

    @Test
    public void formatObjectAcceptsDateCalendarLongAndReturnsPassedBuffer() {
        final Calendar c = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 0);
        final long millis = c.getTimeInMillis();
        final FastDatePrinter p = gmtPrinter("yyyy-MM-dd HH:mm:ss");
        final String expected = "2005-07-04 13:05:30";

        StringBuffer buf = new StringBuffer();
        assertSame(buf, p.format((Object) new Date(millis), buf, new FieldPosition(0)));
        assertEquals(expected, buf.toString());

        buf = new StringBuffer();
        assertSame(buf, p.format((Object) Long.valueOf(millis), buf, new FieldPosition(0)));
        assertEquals(expected, buf.toString());

        buf = new StringBuffer();
        assertSame(buf, p.format((Object) c, buf, new FieldPosition(0)));
        assertEquals(expected, buf.toString());
    }

    @Test
    public void formatObjectIgnoresFieldPosition() {
        final Date d = new Date(cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0).getTimeInMillis());
        final FastDatePrinter p = gmtPrinter("yyyy-MM-dd");
        final String withZero = p.format((Object) d, new StringBuffer(), new FieldPosition(0)).toString();
        final String withYear = p.format((Object) d, new StringBuffer(),
                new FieldPosition(DateFormat.YEAR_FIELD)).toString();
        assertEquals("2005-07-04", withZero);
        assertEquals(withZero, withYear);
    }

    @Test
    public void formatObjectRejectsUnsupportedType() {
        try {
            gmtPrinter("yyyy-MM-dd").format((Object) "2005-07-04", new StringBuffer(), new FieldPosition(0));
            fail("expected IllegalArgumentException for an argument that is not Date/Calendar/Long");
        } catch (final IllegalArgumentException expected) {
            // documented: only Date, Calendar or Long (milliseconds) objects are supported
        }
    }

    // ------------------------------------------------------------------
    // Compatibility with SimpleDateFormat (promised by the class javadoc,
    // "except time zones and some year patterns")
    // ------------------------------------------------------------------

    @Test
    public void matchesSimpleDateFormatForNumericDateTimePattern() {
        final String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS";
        final long millis = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 123).getTimeInMillis();
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, US);
        sdf.setTimeZone(GMT);
        assertEquals(sdf.format(new Date(millis)), printer(pattern, GMT, US).format(millis));
    }

    @Test
    public void matchesSimpleDateFormatForLocaleSensitiveTextPattern() {
        final String pattern = "EEEE, MMMM d, yyyy h:mm:ss a";
        final long millis = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 0).getTimeInMillis();
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, US);
        sdf.setTimeZone(GMT);
        assertEquals(sdf.format(new Date(millis)), printer(pattern, GMT, US).format(millis));
    }

    // ------------------------------------------------------------------
    // Literal / quoted text handling
    // ------------------------------------------------------------------

    @Test
    public void quotedLiteralTextIsEmittedVerbatim() {
        final Calendar c = cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0);
        assertEquals("Year 2005 Month 07", gmtPrinter("'Year' yyyy 'Month' MM").format(c));
    }

    @Test
    public void escapedSingleQuoteIsEmitted() {
        final Calendar c = cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0);
        assertEquals("'2005'", gmtPrinter("''yyyy''").format(c));
    }

    // ------------------------------------------------------------------
    // Year-pattern semantics described in the class javadoc
    // ------------------------------------------------------------------

    @Test
    public void twoLetterYearIsTruncatedToTwoDigits() {
        assertEquals("05", gmtPrinter("yy").format(cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0)));
    }

    @Test
    public void fourLetterYearIsInterpretedAsNumber() {
        assertEquals("2005", gmtPrinter("yyyy").format(cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0)));
    }

    @Test
    public void singleLetterYearIsInterpretedAsNumber() {
        assertEquals("2005", gmtPrinter("y").format(cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0)));
    }

    @Test
    public void threeLetterYearUsesJava7FullYearBehavior() {
        // javadoc: "a pattern of 'Y' or 'YYY' will be formatted as '2003' [...]
        // FastDatePrinter implements the behavior of Java 7."
        assertEquals("2005", gmtPrinter("yyy").format(cal(GMT, 2005, Calendar.JULY, 4, 0, 0, 0, 0)));
    }

    @Test
    public void twoDigitYearZeroPadsAndFourDigitYearZeroPads() {
        final Calendar c = cal(GMT, 7, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("07", gmtPrinter("yy").format(c));
        assertEquals("0007", gmtPrinter("yyyy").format(c));
    }

    // ------------------------------------------------------------------
    // Time-zone pattern letters 'Z' and 'ZZ' (documented examples)
    // ------------------------------------------------------------------

    @Test
    public void rfc822TimeZonePatternZMatchesDocumentedExamples() {
        // javadoc: 'Z' -> RFC822 format, "eg. +0800 or -1100"
        assertEquals("+0800", printer("Z", TimeZone.getTimeZone("GMT+08:00"), US).format(0L));
        assertEquals("-1100", printer("Z", TimeZone.getTimeZone("GMT-11:00"), US).format(0L));
    }

    @Test
    public void iso8601TimeZonePatternZZMatchesDocumentedExamples() {
        // javadoc: 'ZZ' -> ISO8601 full format, "eg. +08:00 or -11:00"
        assertEquals("+08:00", printer("ZZ", TimeZone.getTimeZone("GMT+08:00"), US).format(0L));
        assertEquals("-11:00", printer("ZZ", TimeZone.getTimeZone("GMT-11:00"), US).format(0L));
    }

    // ------------------------------------------------------------------
    // getMaxLengthEstimate
    // ------------------------------------------------------------------

    @Test
    public void maxLengthEstimateIsAtLeastActualLength() {
        final FastDatePrinter p = gmtPrinter("yyyy-MM-dd HH:mm:ss");
        final String formatted = p.format(cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 0).getTimeInMillis());
        assertEquals(19, formatted.length());
        assertTrue("estimate " + p.getMaxLengthEstimate() + " should be >= actual " + formatted.length(),
                p.getMaxLengthEstimate() >= formatted.length());
    }

    @Test
    public void maxLengthEstimateIsNonNegativeAndStable() {
        final FastDatePrinter p = gmtPrinter("");
        assertTrue(p.getMaxLengthEstimate() >= 0);
        assertEquals(p.getMaxLengthEstimate(), p.getMaxLengthEstimate());
    }

    // ------------------------------------------------------------------
    // equals / hashCode
    // ------------------------------------------------------------------

    @Test
    public void equalWhenPatternTimeZoneAndLocaleMatch() {
        final FastDatePrinter a = printer("yyyy-MM-dd", GMT, US);
        final FastDatePrinter b = printer("yyyy-MM-dd", GMT, US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void reflexiveEqualityAndStableHashCode() {
        final FastDatePrinter a = printer("yyyy-MM-dd", GMT, US);
        assertTrue(a.equals(a));
        assertEquals(a.hashCode(), a.hashCode());
    }

    @Test
    public void notEqualWhenPatternDiffers() {
        assertFalse(printer("yyyy-MM-dd", GMT, US).equals(printer("yyyy/MM/dd", GMT, US)));
    }

    @Test
    public void notEqualWhenTimeZoneDiffers() {
        assertFalse(printer("yyyy-MM-dd", GMT, US)
                .equals(printer("yyyy-MM-dd", TimeZone.getTimeZone("GMT-05:00"), US)));
    }

    @Test
    public void notEqualWhenLocaleDiffers() {
        assertFalse(printer("EEEE", GMT, US).equals(printer("EEEE", GMT, Locale.GERMANY)));
    }

    @Test
    public void notEqualToNullOrUnrelatedType() {
        final FastDatePrinter a = printer("yyyy-MM-dd", GMT, US);
        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
    }

    // ------------------------------------------------------------------
    // toString
    // ------------------------------------------------------------------

    @Test
    public void toStringIsNonEmptyDebugStringMentioningThePattern() {
        final String s = gmtPrinter("yyyy-MM-dd").toString();
        assertNotNull(s);
        assertTrue(s.length() > 0);
        assertTrue("debugging string should mention the pattern: " + s, s.contains("yyyy-MM-dd"));
    }

    // ------------------------------------------------------------------
    // Serializable contract
    // ------------------------------------------------------------------

    @Test
    public void isSerializableAndRoundTripsToAnEquivalentPrinter() throws Exception {
        final FastDatePrinter original =
                printer("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("GMT-05:00"), US);
        final long millis = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 0).getTimeInMillis();
        final String before = original.format(millis);

        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        final ObjectOutputStream out = new ObjectOutputStream(bytes);
        out.writeObject(original);
        out.close();

        final ObjectInputStream in =
                new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()));
        final FastDatePrinter restored = (FastDatePrinter) in.readObject();
        in.close();

        assertTrue(original.equals(restored));
        assertEquals(original.hashCode(), restored.hashCode());
        assertEquals(original.getPattern(), restored.getPattern());
        assertEquals(original.getTimeZone().getID(), restored.getTimeZone().getID());
        assertEquals(original.getLocale(), restored.getLocale());
        assertEquals(before, restored.format(millis));
    }

    // ------------------------------------------------------------------
    // Interface + polymorphism
    // ------------------------------------------------------------------

    @Test
    public void isUsableThroughDatePrinterInterface() {
        final FastDatePrinter p = gmtPrinter("yyyy-MM-dd");
        assertTrue(p instanceof DatePrinter);
        assertTrue(p instanceof Serializable);
        final DatePrinter dp = p;
        assertEquals("yyyy-MM-dd", dp.getPattern());
        assertEquals(GMT, dp.getTimeZone());
        assertEquals(US, dp.getLocale());
        assertEquals("1970-01-01", dp.format(0L));
    }

    // ------------------------------------------------------------------
    // Error handling
    // ------------------------------------------------------------------

    @Test
    public void constructorRejectsNullPattern() {
        try {
            new FastDatePrinter(null, GMT, US);
            fail("expected NullPointerException when the pattern is null");
        } catch (final NullPointerException expected) {
            // a printer cannot be constructed without a pattern
        }
    }

    @Test
    public void constructorRejectsUnknownPatternLetter() {
        try {
            new FastDatePrinter("yyyy-b-dd", GMT, US);
            fail("expected IllegalArgumentException for an illegal pattern letter");
        } catch (final IllegalArgumentException expected) {
            // 'b' is not a valid SimpleDateFormat-compatible pattern letter
        }
    }

    // ------------------------------------------------------------------
    // Thread safety (explicitly promised by the class javadoc)
    // ------------------------------------------------------------------

    @Test
    public void concurrentFormattingIsConsistent() throws Exception {
        final FastDatePrinter p = gmtPrinter("yyyy-MM-dd HH:mm:ss.SSS");
        final long millis = cal(GMT, 2005, Calendar.JULY, 4, 13, 5, 30, 123).getTimeInMillis();
        final String expected = "2005-07-04 13:05:30.123";

        final AtomicReference<String> failure = new AtomicReference<String>();
        final Thread[] workers = new Thread[4];
        for (int t = 0; t < workers.length; t++) {
            workers[t] = new Thread(new Runnable() {
                public void run() {
                    try {
                        for (int i = 0; i < 500; i++) {
                            final String actual = p.format(millis);
                            if (!expected.equals(actual)) {
                                failure.compareAndSet(null, "wrong output: " + actual);
                                return;
                            }
                        }
                    } catch (final Throwable ex) {
                        failure.compareAndSet(null, ex.toString());
                    }
                }
            });
        }
        for (final Thread w : workers) {
            w.start();
        }
        for (final Thread w : workers) {
            w.join();
        }
        assertNull("concurrent formatting misbehaved: " + failure.get(), failure.get());
    }
}
