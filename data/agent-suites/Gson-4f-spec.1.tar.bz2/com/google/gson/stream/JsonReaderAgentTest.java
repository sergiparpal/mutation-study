package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringReader;

/**
 * Self-contained tests for {@link JsonReader}, based solely on the documented
 * contract in the generated javadoc (api/com/google/gson/stream/JsonReader.html).
 */
public class JsonReaderAgentTest extends TestCase {

    private static JsonReader newReader(String json) {
        return new JsonReader(new StringReader(json));
    }

    // ---- Basic structural traversal ----------------------------------

    public void testBeginArrayEndArrayEmpty() throws IOException {
        JsonReader reader = newReader("[]");
        reader.beginArray();
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    public void testBeginObjectEndObjectEmpty() throws IOException {
        JsonReader reader = newReader("{}");
        reader.beginObject();
        assertFalse(reader.hasNext());
        reader.endObject();
    }

    public void testReadArrayOfInts() throws IOException {
        JsonReader reader = newReader("[1,2,3]");
        reader.beginArray();
        assertTrue(reader.hasNext());
        assertEquals(1, reader.nextInt());
        assertEquals(2, reader.nextInt());
        assertEquals(3, reader.nextInt());
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    public void testReadObjectNameValuePairs() throws IOException {
        JsonReader reader = newReader("{\"a\":1,\"b\":2}");
        reader.beginObject();
        assertTrue(reader.hasNext());
        assertEquals("a", reader.nextName());
        assertEquals(1, reader.nextInt());
        assertTrue(reader.hasNext());
        assertEquals("b", reader.nextName());
        assertEquals(2, reader.nextInt());
        assertFalse(reader.hasNext());
        reader.endObject();
    }

    public void testNestedObjectsAndArrays() throws IOException {
        JsonReader reader = newReader("{\"id\":1,\"user\":{\"name\":\"joe\"}}");
        reader.beginObject();
        assertEquals("id", reader.nextName());
        assertEquals(1, reader.nextInt());
        assertEquals("user", reader.nextName());
        reader.beginObject();
        assertEquals("name", reader.nextName());
        assertEquals("joe", reader.nextString());
        reader.endObject();
        reader.endObject();
    }

    public void testPeekDoesNotConsumeToken() throws IOException {
        JsonReader reader = newReader("[1]");
        reader.beginArray();
        JsonToken first = reader.peek();
        JsonToken second = reader.peek();
        assertEquals(first, second);
        assertEquals(JsonToken.NUMBER, first);
        assertEquals(1, reader.nextInt());
        reader.endArray();
    }

    public void testPeekReturnsNullToken() throws IOException {
        JsonReader reader = newReader("[null]");
        reader.beginArray();
        assertEquals(JsonToken.NULL, reader.peek());
        reader.nextNull();
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    public void testSkipValueSkipsNestedObject() throws IOException {
        JsonReader reader = newReader("{\"a\":{\"nested\":[1,2,3]},\"b\":1}");
        reader.beginObject();
        assertEquals("a", reader.nextName());
        reader.skipValue();
        assertTrue(reader.hasNext());
        assertEquals("b", reader.nextName());
        assertEquals(1, reader.nextInt());
        assertFalse(reader.hasNext());
        reader.endObject();
    }

    public void testSkipValueSkipsScalarInArray() throws IOException {
        JsonReader reader = newReader("[1,2]");
        reader.beginArray();
        reader.skipValue();
        assertEquals(2, reader.nextInt());
        reader.endArray();
    }

    // ---- Number Handling: numbers as strings and strings as numbers --

    public void testNextStringReturnsStringFormOfNumber() throws IOException {
        JsonReader reader = newReader("[1,\"1\"]");
        reader.beginArray();
        assertEquals("1", reader.nextString());
        assertEquals("1", reader.nextString());
        reader.endArray();
    }

    public void testNextIntParsesStringToken() throws IOException {
        JsonReader reader = newReader("[\"42\"]");
        reader.beginArray();
        assertEquals(42, reader.nextInt());
        reader.endArray();
    }

    public void testNextDoubleParsesStringToken() throws IOException {
        JsonReader reader = newReader("[\"3.5\"]");
        reader.beginArray();
        assertEquals(3.5, reader.nextDouble(), 0.0);
        reader.endArray();
    }

    public void testNextLongParsesStringToken() throws IOException {
        JsonReader reader = newReader("[\"123456789012345\"]");
        reader.beginArray();
        assertEquals(123456789012345L, reader.nextLong());
        reader.endArray();
    }

    public void testNextBooleanValues() throws IOException {
        JsonReader reader = newReader("[true,false]");
        reader.beginArray();
        assertTrue(reader.nextBoolean());
        assertFalse(reader.nextBoolean());
        reader.endArray();
    }

    // ---- Documented IllegalStateException / IOException / NumberFormatException ----

    public void pruned_testNextNameThrowsIOExceptionIfNotName() throws IOException {
        JsonReader reader = newReader("[1]");
        reader.beginArray();
        try {
            reader.nextName();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testNextStringThrowsIllegalStateIfNotStringOrNumber() throws IOException {
        JsonReader reader = newReader("[true]");
        reader.beginArray();
        try {
            reader.nextString();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testNextBooleanThrowsIllegalStateIfNotBoolean() throws IOException {
        JsonReader reader = newReader("[1]");
        reader.beginArray();
        try {
            reader.nextBoolean();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testNextNullThrowsIllegalStateIfNotNull() throws IOException {
        JsonReader reader = newReader("[1]");
        reader.beginArray();
        try {
            reader.nextNull();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testNextDoubleThrowsIllegalStateIfNotLiteral() throws IOException {
        JsonReader reader = newReader("[{}]");
        reader.beginArray();
        try {
            reader.nextDouble();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void pruned_testNextDoubleThrowsNumberFormatIfNonFinite() throws IOException {
        JsonReader reader = newReader("[\"NaN\"]");
        reader.beginArray();
        try {
            reader.nextDouble();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
        }
    }

    public void pruned_testNextLongThrowsNumberFormatIfNotExactLong() throws IOException {
        JsonReader reader = newReader("[\"9223372036854775808\"]");
        reader.beginArray();
        try {
            reader.nextLong();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
        }
    }

    public void testNextIntThrowsNumberFormatIfNotExactInt() throws IOException {
        JsonReader reader = newReader("[\"2147483648\"]");
        reader.beginArray();
        try {
            reader.nextInt();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
        }
    }

    public void testNextStringAfterCloseThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("[\"a\"]");
        reader.close();
        try {
            reader.nextString();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testNextBooleanAfterCloseThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("[true]");
        reader.close();
        try {
            reader.nextBoolean();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testNextNullAfterCloseThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("[null]");
        reader.close();
        try {
            reader.nextNull();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- Structural mismatches: begin/end asserts the expected token ----

    public void testBeginArrayOnObjectThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("{}");
        try {
            reader.beginArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testBeginObjectOnArrayThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("[]");
        try {
            reader.beginObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testEndArrayBeforeExhaustedThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("[1,2]");
        reader.beginArray();
        try {
            reader.endArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testEndObjectBeforeExhaustedThrowsIllegalState() throws IOException {
        JsonReader reader = newReader("{\"a\":1}");
        reader.beginObject();
        try {
            reader.endObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- Lenient vs strict parsing (documented setLenient bullet list) ----

    public void testStrictRejectsNonExecutePrefix() {
        JsonReader reader = newReader(")]}'\n[]");
        try {
            reader.beginArray();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientAllowsNonExecutePrefix() throws IOException {
        JsonReader reader = newReader(")]}'\n[]");
        reader.setLenient(true);
        reader.beginArray();
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    public void pruned_testStrictRejectsTopLevelScalar() {
        JsonReader reader = newReader("true");
        try {
            reader.nextBoolean();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientAllowsTopLevelScalar() throws IOException {
        JsonReader reader = newReader("true");
        reader.setLenient(true);
        assertTrue(reader.nextBoolean());
    }

    public void testStrictRejectsUnquotedString() throws IOException {
        JsonReader reader = newReader("[abc]");
        reader.beginArray();
        try {
            reader.nextString();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientAllowsUnquotedString() throws IOException {
        JsonReader reader = newReader("[abc]");
        reader.setLenient(true);
        reader.beginArray();
        assertEquals("abc", reader.nextString());
        reader.endArray();
    }

    public void testStrictRejectsCStyleComment() throws IOException {
        JsonReader reader = newReader("[/* c */1]");
        reader.beginArray();
        try {
            reader.nextInt();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientAllowsCStyleComment() throws IOException {
        JsonReader reader = newReader("[/* c */1]");
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        reader.endArray();
    }

    public void testStrictRejectsUnnecessaryArraySeparator() throws IOException {
        JsonReader reader = newReader("[1,,3]");
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        try {
            reader.peek();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientTreatsUnnecessaryArraySeparatorAsNull() throws IOException {
        JsonReader reader = newReader("[1,,3]");
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        assertEquals(JsonToken.NULL, reader.peek());
        reader.nextNull();
        assertEquals(3, reader.nextInt());
        reader.endArray();
    }

    public void pruned_testStrictRejectsSemicolonArraySeparator() throws IOException {
        JsonReader reader = newReader("[1;2]");
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        try {
            reader.nextInt();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientAllowsSemicolonArraySeparator() throws IOException {
        JsonReader reader = newReader("[1;2]");
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        assertEquals(2, reader.nextInt());
        reader.endArray();
    }

    public void testStrictRejectsEqualsNameValueSeparator() throws IOException {
        JsonReader reader = newReader("{\"a\"=1}");
        reader.beginObject();
        assertEquals("a", reader.nextName());
        try {
            reader.nextInt();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    public void testLenientAllowsEqualsNameValueSeparator() throws IOException {
        JsonReader reader = newReader("{\"a\"=1}");
        reader.setLenient(true);
        reader.beginObject();
        assertEquals("a", reader.nextName());
        assertEquals(1, reader.nextInt());
        reader.endObject();
    }

    // ---- isLenient / setLenient ----------------------------------------

    public void testIsLenientDefaultFalse() {
        JsonReader reader = newReader("[]");
        assertFalse(reader.isLenient());
    }

    public void testSetLenientReflectedInIsLenient() {
        JsonReader reader = newReader("[]");
        reader.setLenient(true);
        assertTrue(reader.isLenient());
    }

    // ---- getPath --------------------------------------------------------

    public void testGetPathInitiallyRoot() {
        JsonReader reader = newReader("[1,2,3]");
        assertEquals("$", reader.getPath());
    }

    public void testGetPathTracksLocation() throws IOException {
        JsonReader reader = newReader("[1,2,3]");
        String initialPath = reader.getPath();
        reader.beginArray();
        String pathAfterBegin = reader.getPath();
        reader.nextInt();
        String pathAfterFirstElement = reader.getPath();
        assertEquals("$", initialPath);
        assertTrue(pathAfterBegin.startsWith("$"));
        assertTrue(pathAfterFirstElement.startsWith("$"));
        assertFalse(pathAfterFirstElement.equals(pathAfterBegin));
    }
}
