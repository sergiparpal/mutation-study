package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigDecimal;

/**
 * Self-contained tests for {@link JsonWriter}, based solely on the documented
 * contract in the generated javadoc (api/com/google/gson/stream/JsonWriter.html).
 */
public class JsonWriterAgentTest extends TestCase {

    /** Writer that counts flush()/close() calls, to observe JsonWriter's flush/close contract. */
    private static class CountingWriter extends Writer {
        final StringWriter target = new StringWriter();
        int flushCount = 0;
        int closeCount = 0;

        public void write(char[] cbuf, int off, int len) throws IOException {
            target.write(cbuf, off, len);
        }

        public void flush() throws IOException {
            flushCount++;
            target.flush();
        }

        public void close() throws IOException {
            closeCount++;
            target.close();
        }
    }

    // ---- Basic structural encoding --------------------------------------

    public void testBeginArrayEndArrayEmpty() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.endArray();
        writer.close();
        assertEquals("[]", out.toString());
    }

    public void testBeginObjectEndObjectEmpty() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginObject();
        writer.endObject();
        writer.close();
        assertEquals("{}", out.toString());
    }

    public void testArrayOfLongValues() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value(1L);
        writer.value(2L);
        writer.value(3L);
        writer.endArray();
        writer.close();
        assertEquals("[1,2,3]", out.toString());
    }

    public void testObjectWithNameValuePairs() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginObject();
        writer.name("a").value(1L);
        writer.name("b").value("text");
        writer.endObject();
        writer.close();
        assertEquals("{\"a\":1,\"b\":\"text\"}", out.toString());
    }

    public void testNestedArraysAndObjects() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginObject();
        writer.name("id").value(1L);
        writer.name("geo");
        writer.beginArray();
        writer.value(1.5);
        writer.value(2.5);
        writer.endArray();
        writer.name("user");
        writer.beginObject();
        writer.name("name").value("joe");
        writer.endObject();
        writer.endObject();
        writer.close();
        assertEquals("{\"id\":1,\"geo\":[1.5,2.5],\"user\":{\"name\":\"joe\"}}", out.toString());
    }

    public void testFluentChainReturnsSameWriterAndProducesExpectedOutput() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        JsonWriter afterBeginObject = writer.beginObject();
        assertSame(writer, afterBeginObject);
        JsonWriter afterName = writer.name("a");
        assertSame(writer, afterName);
        JsonWriter afterValue = writer.value(1L);
        assertSame(writer, afterValue);
        JsonWriter afterEndObject = writer.endObject();
        assertSame(writer, afterEndObject);
        writer.close();
        assertEquals("{\"a\":1}", out.toString());
    }

    // ---- value() encoding -------------------------------------------------

    public void testValueStringEncodesQuotesAndBackslashes() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value("a\"b\\c");
        writer.endArray();
        writer.close();
        assertEquals("[\"a\\\"b\\\\c\"]", out.toString());
    }

    public void testValueStringNullWritesNullLiteral() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value((String) null);
        writer.endArray();
        writer.close();
        assertEquals("[null]", out.toString());
    }

    public void testNullValueWritesNullLiteral() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.nullValue();
        writer.endArray();
        writer.close();
        assertEquals("[null]", out.toString());
    }

    public void testValueBooleanTrueFalse() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value(true);
        writer.value(false);
        writer.endArray();
        writer.close();
        assertEquals("[true,false]", out.toString());
    }

    public void testValueLong() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value(123456789012345L);
        writer.endArray();
        writer.close();
        assertEquals("[123456789012345]", out.toString());
    }

    public void testValueDoubleFinite() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value(3.5);
        writer.endArray();
        writer.close();
        assertEquals("[3.5]", out.toString());
    }

    public void testValueDoubleRejectsNaNWhenStrict() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        try {
            writer.value(Double.NaN);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    public void testValueDoubleRejectsInfinityWhenStrict() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        try {
            writer.value(Double.POSITIVE_INFINITY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    public void testValueNumber() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value(new BigDecimal("10.5"));
        writer.endArray();
        writer.close();
        assertEquals("[10.5]", out.toString());
    }

    public void testNameNullThrowsNullPointerException() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginObject();
        try {
            writer.name(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
        }
    }

    public void testJsonValueWritesRawUnescaped() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.jsonValue("{\"raw\":true}");
        writer.endArray();
        writer.close();
        assertEquals("[{\"raw\":true}]", out.toString());
    }

    public void testJsonValueNullWritesNullLiteral() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.jsonValue(null);
        writer.endArray();
        writer.close();
        assertEquals("[null]", out.toString());
    }

    // ---- setIndent --------------------------------------------------------

    public void testSetIndentPrettyPrints() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.setIndent("  ");
        writer.beginObject();
        writer.name("a").value(1L);
        writer.endObject();
        writer.close();
        assertEquals("{\n  \"a\": 1\n}", out.toString());
    }

    public void testSetIndentEmptyStringIsCompact() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.setIndent("   ");
        writer.setIndent("");
        writer.beginObject();
        writer.name("a").value(1L);
        writer.endObject();
        writer.close();
        assertEquals("{\"a\":1}", out.toString());
    }

    // ---- isLenient / setLenient --------------------------------------------

    public void testIsLenientDefaultFalse() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertFalse(writer.isLenient());
    }

    public void testSetLenientReflectedInIsLenient() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.setLenient(true);
        assertTrue(writer.isLenient());
    }

    public void pruned_testStrictRejectsTopLevelScalarThrowsIllegalState() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.value(1L);
            fail("Expected IllegalStateException");
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        } catch (IllegalStateException expected) {
        }
    }

    public void testLenientAllowsTopLevelScalar() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.setLenient(true);
        writer.value(1L);
        writer.close();
        assertEquals("1", out.toString());
    }

    // ---- Malformed JSON calls fail with IllegalStateException (class contract) ----

    public void testEndArrayWithoutBeginThrowsIllegalState() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.endArray();
            fail("Expected IllegalStateException");
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        } catch (IllegalStateException expected) {
        }
    }

    public void pruned_testNameOutsideObjectThrowsIllegalState() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.name("x");
            fail("Expected IllegalStateException");
        } catch (IOException e) {
            fail("Expected IllegalStateException, got IOException: " + e);
        } catch (IllegalStateException expected) {
        }
    }

    public void testValueAfterTopLevelDocumentCompleteThrowsIllegalState() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        writer.endObject();
        try {
            writer.value(1L);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testEndObjectWhenInArrayThrowsIllegalState() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.endObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }

    public void testCloseIncompleteDocumentThrowsIOException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        try {
            writer.close();
            fail("Expected IOException");
        } catch (IOException expected) {
        }
    }

    // ---- flush() / close() delegate to the underlying Writer ---------------

    public void testFlushDelegatesToUnderlyingWriter() throws IOException {
        CountingWriter counting = new CountingWriter();
        JsonWriter writer = new JsonWriter(counting);
        writer.beginArray();
        writer.value(1L);
        writer.endArray();
        assertEquals(0, counting.flushCount);
        writer.flush();
        assertTrue(counting.flushCount >= 1);
    }

    public void testCloseFlushesAndClosesUnderlyingWriter() throws IOException {
        CountingWriter counting = new CountingWriter();
        JsonWriter writer = new JsonWriter(counting);
        writer.beginArray();
        writer.endArray();
        writer.close();
        assertTrue(counting.closeCount >= 1);
        assertEquals("[]", counting.target.toString());
    }

    // ---- HTML-safe mode -----------------------------------------------------

    public void testIsHtmlSafeDefaultFalse() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertFalse(writer.isHtmlSafe());
    }

    public void testValueStringNotEscapedByDefaultForHtmlChars() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.beginArray();
        writer.value("<>&=");
        writer.endArray();
        writer.close();
        assertEquals("[\"<>&=\"]", out.toString());
    }

    public void testSetHtmlSafeEscapesSpecialCharacters() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.setHtmlSafe(true);
        assertTrue(writer.isHtmlSafe());
        writer.beginArray();
        writer.value("<>&=");
        writer.endArray();
        writer.close();
        assertEquals("[\"\\u003c\\u003e\\u0026\\u003d\"]", out.toString());
    }

    // ---- serializeNulls -------------------------------------------------------

    public void testGetSerializeNullsDefaultTrue() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertTrue(writer.getSerializeNulls());
    }

    public void testSetSerializeNullsFalseOmitsNullObjectMember() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.setSerializeNulls(false);
        writer.beginObject();
        writer.name("a").nullValue();
        writer.name("b").value(1L);
        writer.endObject();
        writer.close();
        assertEquals("{\"b\":1}", out.toString());
    }

    public void testSerializeNullsFalseStillWritesArrayNulls() throws IOException {
        StringWriter out = new StringWriter();
        JsonWriter writer = new JsonWriter(out);
        writer.setSerializeNulls(false);
        writer.beginArray();
        writer.nullValue();
        writer.value(1L);
        writer.endArray();
        writer.close();
        assertEquals("[null,1]", out.toString());
    }
}
