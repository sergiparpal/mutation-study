/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.BACKSPACE;
import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.END_OF_STREAM;
import static org.apache.commons.csv.Constants.FF;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.TAB;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.csv.Token.Type.COMMENT;
import static org.apache.commons.csv.Token.Type.EOF;
import static org.apache.commons.csv.Token.Type.EORECORD;
import static org.apache.commons.csv.Token.Type.TOKEN;
import static org.apache.commons.csv.TokenMatchers.hasContent;
import static org.apache.commons.csv.TokenMatchers.isReady;
import static org.apache.commons.csv.TokenMatchers.matches;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;

/**
 * Tests the package-visible behaviour of the abstract {@link Lexer} through its concrete
 * production subclass {@link CSVLexer}.
 */
public class LexerAgentTest {

    private Lexer createLexer(final String input, final CSVFormat format) {
        return new CSVLexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    // -----------------------------------------------------------------------
    // readEscape()
    // -----------------------------------------------------------------------

    @Test
    public void testReadEscapeMapsControlLetters() throws IOException {
        assertEquals(CR, createLexer("r", CSVFormat.DEFAULT).readEscape());
        assertEquals(LF, createLexer("n", CSVFormat.DEFAULT).readEscape());
        assertEquals(TAB, createLexer("t", CSVFormat.DEFAULT).readEscape());
        assertEquals(BACKSPACE, createLexer("b", CSVFormat.DEFAULT).readEscape());
        assertEquals(FF, createLexer("f", CSVFormat.DEFAULT).readEscape());
    }

    @Test
    public void testReadEscapePreservesLiteralControlCharacters() throws IOException {
        assertEquals(CR, createLexer("\r", CSVFormat.DEFAULT).readEscape());
        assertEquals(LF, createLexer("\n", CSVFormat.DEFAULT).readEscape());
        assertEquals(TAB, createLexer("\t", CSVFormat.DEFAULT).readEscape());
    }

    @Test
    public void testReadEscapeReturnsMetaCharacterVerbatim() throws IOException {
        // an escaped delimiter is returned as the plain delimiter
        assertEquals(',', createLexer(",", CSVFormat.DEFAULT).readEscape());
        // an escaped quote character is returned as the plain quote character
        assertEquals('"', createLexer("\"", CSVFormat.DEFAULT).readEscape());
    }

    @Test
    public void testReadEscapeWithUnknownCharacterSignalsEndOfStream() throws IOException {
        final ExtendedBufferedReader in = new ExtendedBufferedReader(new StringReader("z"));
        final Lexer lexer = new CSVLexer(CSVFormat.DEFAULT, in);
        assertEquals(END_OF_STREAM, lexer.readEscape());
        // the offending (consumed) character remains available from the reader
        assertEquals('z', in.getLastChar());
    }

    @Test
    public void testReadEscapeAtEndOfStreamThrows() throws IOException {
        try {
            createLexer("", CSVFormat.DEFAULT).readEscape();
            fail("Expected IOException when the stream ends inside an escape sequence");
        } catch (final IOException e) {
            assertEquals("EOF whilst processing escape sequence", e.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // readEndOfLine(int)
    // -----------------------------------------------------------------------

    @Test
    public void testReadEndOfLineRecognisesLineTerminators() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine(LF));
        assertTrue(lexer.readEndOfLine(CR));
        assertFalse(lexer.readEndOfLine('a'));
        assertFalse(lexer.readEndOfLine(' '));
        assertFalse(lexer.readEndOfLine(END_OF_STREAM));
    }

    @Test
    public void testReadEndOfLineConsumesPairedLineFeed() throws IOException {
        final ExtendedBufferedReader in = new ExtendedBufferedReader(new StringReader("\nX"));
        final Lexer lexer = new CSVLexer(CSVFormat.DEFAULT, in);
        // CR immediately followed by LF: the LF is silently swallowed
        assertTrue(lexer.readEndOfLine(CR));
        assertEquals('X', in.read());
        assertEquals(1, in.getLineNumber());
    }

    @Test
    public void testReadEndOfLineDoesNotConsumeLoneCarriageReturnFollower() throws IOException {
        final ExtendedBufferedReader in = new ExtendedBufferedReader(new StringReader("X"));
        final Lexer lexer = new CSVLexer(CSVFormat.DEFAULT, in);
        assertTrue(lexer.readEndOfLine(CR));
        // the following non-LF char must not have been consumed
        assertEquals('X', in.read());
    }

    // -----------------------------------------------------------------------
    // trimTrailingSpaces(StringBuilder)
    // -----------------------------------------------------------------------

    @Test
    public void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);

        StringBuilder buffer = new StringBuilder("foo   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("foo", buffer.toString());

        buffer = new StringBuilder("bar");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("bar", buffer.toString());

        buffer = new StringBuilder("   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
        assertEquals(0, buffer.length());

        buffer = new StringBuilder();
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());

        // trailing tab/CR/LF are whitespace and stripped; leading spaces are kept
        buffer = new StringBuilder("  x y\t\r\n");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("  x y", buffer.toString());
    }

    // -----------------------------------------------------------------------
    // getLineNumber()
    // -----------------------------------------------------------------------

    @Test
    public void testGetLineNumberTracksConsumedLines() throws IOException {
        final Lexer lexer = createLexer("a\nb\nc", CSVFormat.DEFAULT);
        assertEquals(0, lexer.getLineNumber());

        assertThat(lexer.nextToken(new Token()), matches(EORECORD, "a"));
        assertEquals(1, lexer.getLineNumber());

        assertThat(lexer.nextToken(new Token()), matches(EORECORD, "b"));
        assertEquals(2, lexer.getLineNumber());

        assertThat(lexer.nextToken(new Token()), matches(EOF, "c"));
        assertEquals(2, lexer.getLineNumber());
    }

    // -----------------------------------------------------------------------
    // character classification helpers
    // -----------------------------------------------------------------------

    @Test
    public void testIsWhitespace() {
        final Lexer defaultLexer = createLexer("", CSVFormat.DEFAULT); // delimiter ','
        assertTrue(defaultLexer.isWhitespace(' '));
        assertTrue(defaultLexer.isWhitespace('\t'));
        assertFalse(defaultLexer.isWhitespace('x'));
        assertFalse("the delimiter is never treated as whitespace", defaultLexer.isWhitespace(','));

        final Lexer tabLexer = createLexer("", CSVFormat.TDF); // delimiter '\t'
        assertFalse("the tab delimiter is not whitespace here", tabLexer.isWhitespace('\t'));
        assertTrue(tabLexer.isWhitespace(' '));
    }

    @Test
    public void testIsStartOfLine() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isStartOfLine(LF));
        assertTrue(lexer.isStartOfLine(CR));
        assertTrue(lexer.isStartOfLine(UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        assertFalse(lexer.isStartOfLine(END_OF_STREAM));
    }

    @Test
    public void testIsEndOfFile() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isEndOfFile(END_OF_STREAM));
        assertFalse(lexer.isEndOfFile(UNDEFINED));
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(LF));
    }

    @Test
    public void testIsDelimiter() {
        final Lexer defaultLexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(defaultLexer.isDelimiter(','));
        assertFalse(defaultLexer.isDelimiter(';'));
        assertFalse(defaultLexer.isDelimiter('\t'));

        final Lexer tabLexer = createLexer("", CSVFormat.TDF);
        assertTrue(tabLexer.isDelimiter('\t'));
        assertFalse(tabLexer.isDelimiter(','));
    }

    @Test
    public void testIsQuoteChar() {
        final Lexer defaultLexer = createLexer("", CSVFormat.DEFAULT); // quote '"'
        assertTrue(defaultLexer.isQuoteChar('"'));
        assertFalse(defaultLexer.isQuoteChar('\''));

        final Lexer noQuoteLexer = createLexer("", CSVFormat.MYSQL); // quoting disabled (null)
        assertFalse(noQuoteLexer.isQuoteChar('"'));

        final Lexer customLexer = createLexer("", CSVFormat.newBuilder(',').withQuoteChar('\'').build());
        assertTrue(customLexer.isQuoteChar('\''));
        assertFalse(customLexer.isQuoteChar('"'));
    }

    @Test
    public void testIsEscape() {
        final Lexer noEscapeLexer = createLexer("", CSVFormat.DEFAULT); // escaping disabled
        assertFalse(noEscapeLexer.isEscape('\\'));

        final Lexer mysqlLexer = createLexer("", CSVFormat.MYSQL); // escape '\\'
        assertTrue(mysqlLexer.isEscape('\\'));
        assertFalse(mysqlLexer.isEscape('/'));
    }

    @Test
    public void testIsCommentStart() {
        final Lexer noCommentLexer = createLexer("", CSVFormat.DEFAULT); // commenting disabled
        assertFalse(noCommentLexer.isCommentStart('#'));

        final Lexer commentLexer = createLexer("", CSVFormat.newBuilder(',').withCommentStart('#').build());
        assertTrue(commentLexer.isCommentStart('#'));
        assertFalse(commentLexer.isCommentStart('!'));
    }

    // -----------------------------------------------------------------------
    // nextToken(Token) - the abstract contract of Lexer
    // -----------------------------------------------------------------------

    @Test
    public void testNextTokenParsesSimpleRecord() throws IOException {
        final Lexer lexer = createLexer("a,b,c", CSVFormat.DEFAULT);
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "a"));
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "b"));
        final Token last = lexer.nextToken(new Token());
        assertThat(last, matches(EOF, "c"));
        assertThat("content is present at EOF", last, isReady());
    }

    @Test
    public void testNextTokenHandlesEndOfLine() throws IOException {
        final Lexer lexer = createLexer("a,b\nc,d", CSVFormat.DEFAULT);
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "a"));
        assertThat(lexer.nextToken(new Token()), matches(EORECORD, "b"));
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "c"));
        assertThat(lexer.nextToken(new Token()), matches(EOF, "d"));
    }

    @Test
    public void testNextTokenOnEmptyInputReturnsEofRepeatedly() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertThat(lexer.nextToken(new Token()), matches(EOF, ""));
        // asking again keeps returning EOF rather than failing
        assertThat(lexer.nextToken(new Token()), matches(EOF, ""));
    }

    @Test
    public void testNextTokenUnwrapsEncapsulatedValue() throws IOException {
        final Lexer lexer = createLexer("\"a,b\",c", CSVFormat.DEFAULT);
        // the delimiter inside the quotes is part of the value
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "a,b"));
        assertThat(lexer.nextToken(new Token()), matches(EOF, "c"));
    }

    @Test
    public void testNextTokenHandlesDoubledQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"\"b\"", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertThat(token, matches(EOF, "a\"b"));
        assertThat(token, isReady());
    }

    @Test
    public void testNextTokenSkipsEmptyLinesByDefault() throws IOException {
        final Lexer lexer = createLexer("\n\nlast", CSVFormat.DEFAULT); // ignoreEmptyLines == true
        final Token token = lexer.nextToken(new Token());
        assertThat(token, matches(EOF, "last"));
        assertThat(token, isReady());
    }

    @Test
    public void testNextTokenKeepsEmptyLinesWhenNotIgnored() throws IOException {
        final Lexer lexer = createLexer("\nlast", CSVFormat.RFC4180); // ignoreEmptyLines == false
        assertThat(lexer.nextToken(new Token()), matches(EORECORD, ""));
        assertThat(lexer.nextToken(new Token()), matches(EOF, "last"));
    }

    @Test
    public void testNextTokenReadsComment() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withCommentStart('#').build();
        final Lexer lexer = createLexer("#Comment\nvalue", format);
        assertThat(lexer.nextToken(new Token()), matches(COMMENT, "Comment"));
        assertThat(lexer.nextToken(new Token()), matches(EOF, "value"));
    }

    @Test
    public void testNextTokenDoesNotTreatMidLineCommentCharAsComment() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withCommentStart('#').build();
        final Lexer lexer = createLexer("a#b", format);
        // '#' is only a comment marker at the start of a line
        assertThat(lexer.nextToken(new Token()), matches(EOF, "a#b"));
    }

    @Test
    public void testNextTokenProcessesEscapeSequences() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();
        final Lexer lexer = createLexer("a\\,b\\nc", format);
        final Token token = lexer.nextToken(new Token());
        // "\," -> literal comma, "\n" -> line feed
        assertThat(token, matches(EOF, "a,b\nc"));
        assertThat(token, isReady());
    }

    @Test
    public void testNextTokenTrimsSurroundingSpaces() throws IOException {
        final Lexer lexer = createLexer("  a  \tb  ", CSVFormat.TDF); // ignoreSurroundingSpaces == true
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "a"));
        assertThat(lexer.nextToken(new Token()), matches(EOF, "b"));
    }

    @Test
    public void testNextTokenKeepsSurroundingSpacesWhenNotIgnored() throws IOException {
        final Lexer lexer = createLexer("  a  ,b", CSVFormat.DEFAULT); // ignoreSurroundingSpaces == false
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "  a  "));
        assertThat(lexer.nextToken(new Token()), matches(EOF, "b"));
    }

    @Test
    public void testNextTokenReturnsEmptyTrailingTokenAfterDelimiter() throws IOException {
        final Lexer lexer = createLexer("a,", CSVFormat.DEFAULT);
        assertThat(lexer.nextToken(new Token()), matches(TOKEN, "a"));
        final Token token = lexer.nextToken(new Token());
        assertThat(token, matches(EOF, ""));
    }

    @Test
    public void testNextTokenThrowsOnUnterminatedEncapsulatedToken() throws IOException {
        final Lexer lexer = createLexer("\"abc", CSVFormat.DEFAULT);
        try {
            lexer.nextToken(new Token());
            fail("Expected IOException for an encapsulated token that is never closed");
        } catch (final IOException e) {
            assertTrue(e.getMessage(),
                    e.getMessage().contains("EOF reached before encapsulated token finished"));
        }
    }

    @Test
    public void testNextTokenThrowsOnInvalidCharAfterClosingQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"b", CSVFormat.DEFAULT);
        try {
            lexer.nextToken(new Token());
            fail("Expected IOException for a stray character after the closing quote");
        } catch (final IOException e) {
            assertTrue(e.getMessage(),
                    e.getMessage().contains("invalid char between encapsulated token and delimiter"));
        }
    }

    @Test
    public void testNextTokenReusesProvidedTokenInstance() throws IOException {
        final Lexer lexer = createLexer("x,y", CSVFormat.DEFAULT);
        final Token reusable = new Token();
        assertThat(lexer.nextToken(reusable), matches(TOKEN, "x"));

        reusable.reset();
        assertThat("reset() must clear the previous content", reusable, hasContent(""));

        final Token result = lexer.nextToken(reusable);
        assertSame("nextToken fills and returns the same instance", reusable, result);
        assertThat(result, matches(EOF, "y"));
    }
}
