package org.apache.commons.lang;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

/**
 * Self-contained JUnit 4 tests for {@link org.apache.commons.lang.Entities}.
 *
 * <p>Every expectation is derived from the generated javadoc under {@code api/}:</p>
 * <ul>
 *   <li>the class "Provides HTML and XML entity utilities";</li>
 *   <li>{@code escape(String)}: if you have called {@code addEntity("foo", 0xA1)},
 *       {@code escape} of the character with code point 0xA1 returns {@code "&foo;"};</li>
 *   <li>{@code unescape(String)}: if you have called {@code addEntity("foo", 0xA1)},
 *       {@code unescape("&foo;")} returns the character with code point 0xA1;</li>
 *   <li>{@code entityName(int)} returns "entity name associated with the specified value";</li>
 *   <li>{@code entityValue(String)} returns "entity value associated with the specified name";</li>
 *   <li>{@code XML}, {@code HTML32} and {@code HTML40} are the entity sets
 *       "supported by standard XML", "HTML 3.2" and "HTML 4.0".</li>
 * </ul>
 *
 * <p>The test lives in package {@code org.apache.commons.lang} because both the
 * {@code Entities} class and its no-arg constructor are package-private.</p>
 *
 * <p>Non-ASCII characters are built from their code points via {@link #ch(int)}
 * so nothing depends on the compiler's source encoding. The shared
 * {@code Entities.XML} / {@code Entities.HTML32} / {@code Entities.HTML40}
 * instances are only read here, never mutated, so the tests stay independent of
 * ordering.</p>
 */
public class EntitiesAgentTest {

    /** Code point used by the javadoc's own {@code addEntity} example (161). */
    private static final int FOO_VALUE = 0xA1;

    /** Returns the one-character String for the given code point. */
    private static String ch(int codePoint) {
        return String.valueOf((char) codePoint);
    }

    /** The single character whose code point is {@link #FOO_VALUE}. */
    private static final String FOO_CHAR = ch(FOO_VALUE);

    private static Entities newFooEntities() {
        Entities e = new Entities();
        e.addEntity("foo", FOO_VALUE);
        return e;
    }

    // ------------------------------------------------------------------
    // addEntity / entityName / entityValue
    // ------------------------------------------------------------------

    @Test
    public void entityValueReturnsValueRegisteredWithAddEntity() {
        Entities e = newFooEntities();
        assertEquals(FOO_VALUE, e.entityValue("foo"));
    }

    @Test
    public void entityNameReturnsNameRegisteredWithAddEntity() {
        Entities e = newFooEntities();
        assertEquals("foo", e.entityName(FOO_VALUE));
    }

    @Test
    public void nameAndValueRoundTripForSeveralEntries() {
        Entities e = new Entities();
        e.addEntity("alpha", 945);
        e.addEntity("beta", 946);
        e.addEntity("gamma", 947);

        assertEquals(945, e.entityValue("alpha"));
        assertEquals(946, e.entityValue("beta"));
        assertEquals(947, e.entityValue("gamma"));
        assertEquals("alpha", e.entityName(945));
        assertEquals("beta", e.entityName(946));
        assertEquals("gamma", e.entityName(947));
    }

    @Test
    public void twoNamesMayShareOneValue() {
        Entities e = new Entities();
        e.addEntity("first", 0x2603);
        e.addEntity("second", 0x2603);
        // Both names resolve to the shared value...
        assertEquals(0x2603, e.entityValue("first"));
        assertEquals(0x2603, e.entityValue("second"));
        // ...and the value resolves back to one of the registered names.
        String name = e.entityName(0x2603);
        assertNotNull(name);
        assertTrue("unexpected name: " + name,
                "first".equals(name) || "second".equals(name));
    }

    @Test
    public void entityNameForUnregisteredValueIsNull() {
        Entities e = newFooEntities();
        assertNull(e.entityName(0x2603)); // never registered
    }

    // ------------------------------------------------------------------
    // addEntities
    // ------------------------------------------------------------------

    @Test
    public void addEntitiesRegistersEveryPairInTheArray() {
        // Each row is {name, value}; the value is the decimal code point -- the
        // only reading consistent with addEntity(String, int) and with the
        // String[][] entity tables the class is documented to use.
        Entities e = new Entities();
        e.addEntities(new String[][] { { "alpha", "945" }, { "omega", "969" } });

        assertEquals(945, e.entityValue("alpha"));
        assertEquals(969, e.entityValue("omega"));
        assertEquals("alpha", e.entityName(945));
        assertEquals("omega", e.entityName(969));
        assertEquals("&alpha;", e.escape(ch(945)));
        assertEquals("&omega;", e.escape(ch(969)));
    }

    @Test
    public void addEntitiesWithEmptyArrayAddsNothing() {
        Entities e = new Entities();
        e.addEntities(new String[][] {});
        assertNull(e.entityName(945));
    }

    // ------------------------------------------------------------------
    // escape(String) / unescape(String) -- the documented example
    // ------------------------------------------------------------------

    @Test
    public void escapeReplacesRegisteredCharacterWithNamedEntity() {
        Entities e = newFooEntities();
        assertEquals("&foo;", e.escape(FOO_CHAR));
    }

    @Test
    public void unescapeReplacesNamedEntityWithRegisteredCharacter() {
        Entities e = newFooEntities();
        assertEquals(FOO_CHAR, e.unescape("&foo;"));
    }

    @Test
    public void escapeOnlyRewritesRegisteredCharacters() {
        Entities e = newFooEntities();
        assertEquals("x&foo;y", e.escape("x" + FOO_CHAR + "y"));
    }

    @Test
    public void unescapeOnlyRewritesRegisteredEntities() {
        Entities e = newFooEntities();
        assertEquals("x" + FOO_CHAR + "y", e.unescape("x&foo;y"));
    }

    @Test
    public void escapeThenUnescapeRoundTrips() {
        Entities e = newFooEntities();
        String original = "a" + FOO_CHAR + "b" + FOO_CHAR + "c";
        assertEquals(original, e.unescape(e.escape(original)));
    }

    @Test
    public void escapeLeavesPlainAsciiUnchanged() {
        Entities e = newFooEntities();
        assertEquals("plain ASCII text 123", e.escape("plain ASCII text 123"));
    }

    @Test
    public void escapeOfEmptyStringIsEmpty() {
        assertEquals("", newFooEntities().escape(""));
    }

    @Test
    public void unescapeOfEmptyStringIsEmpty() {
        assertEquals("", newFooEntities().unescape(""));
    }

    @Test
    public void unescapeLeavesTextWithoutEntitiesUnchanged() {
        assertEquals("a & b < c", Entities.XML.unescape("a & b < c"));
    }

    @Test
    public void unescapeLeavesUnknownNamedEntityUnchanged() {
        assertEquals("&notareal;", Entities.XML.unescape("&notareal;"));
    }

    @Test
    public void unescapeLeavesEntityWithoutTrailingSemicolonUnchanged() {
        assertEquals("&lt", Entities.XML.unescape("&lt"));
    }

    // ------------------------------------------------------------------
    // Writer overloads
    // ------------------------------------------------------------------

    @Test
    public void escapeWritesEntitiesToTheWriter() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.escape(writer, "<x>");
        assertEquals("&lt;x&gt;", writer.toString());
    }

    @Test
    public void unescapeWritesPlainTextToTheWriter() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "&lt;x&gt;");
        assertEquals("<x>", writer.toString());
    }

    @Test
    public void escapeToWriterMatchesTheStringOverload() throws IOException {
        Entities e = newFooEntities();
        String input = "x" + FOO_CHAR + "y";
        StringWriter writer = new StringWriter();
        e.escape(writer, input);
        assertEquals(e.escape(input), writer.toString());
    }

    @Test
    public void unescapeToWriterMatchesTheStringOverload() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "&amp;&lt;&gt;");
        assertEquals(Entities.XML.unescape("&amp;&lt;&gt;"), writer.toString());
    }

    // ------------------------------------------------------------------
    // Entities.XML -- the entities of standard XML
    // ------------------------------------------------------------------

    @Test
    public void xmlFieldIsInitialised() {
        assertNotNull(Entities.XML);
    }

    @Test
    public void xmlEscapesTheCoreMarkupCharacters() {
        assertEquals("&quot;", Entities.XML.escape("\""));
        assertEquals("&amp;", Entities.XML.escape("&"));
        assertEquals("&lt;", Entities.XML.escape("<"));
        assertEquals("&gt;", Entities.XML.escape(">"));
    }

    @Test
    public void xmlEscapesApostrophe() {
        assertEquals("&apos;", Entities.XML.escape("'"));
    }

    @Test
    public void xmlEscapesAllPredefinedEntitiesInOnePass() {
        assertEquals("&quot;&amp;&lt;&gt;&apos;", Entities.XML.escape("\"&<>'"));
    }

    @Test
    public void xmlUnescapesAllPredefinedEntitiesInOnePass() {
        assertEquals("\"&<>'", Entities.XML.unescape("&quot;&amp;&lt;&gt;&apos;"));
    }

    @Test
    public void xmlUnescapesTwoAdjacentAmpEntities() {
        assertEquals("& &", Entities.XML.unescape("&amp; &amp;"));
    }

    @Test
    public void xmlEntityNameAndValueForAmp() {
        assertEquals(38, Entities.XML.entityValue("amp"));
        assertEquals("amp", Entities.XML.entityName(38));
    }

    @Test
    public void xmlEntityNameAndValueForLtGtQuot() {
        assertEquals(60, Entities.XML.entityValue("lt"));
        assertEquals(62, Entities.XML.entityValue("gt"));
        assertEquals(34, Entities.XML.entityValue("quot"));
        assertEquals("lt", Entities.XML.entityName(60));
        assertEquals("gt", Entities.XML.entityName(62));
        assertEquals("quot", Entities.XML.entityName(34));
    }

    @Test
    public void xmlLeavesTextWithoutMarkupCharactersUnchanged() {
        assertEquals("hello world", Entities.XML.escape("hello world"));
    }

    @Test
    public void xmlEscapeUnescapeRoundTrips() {
        String original = "<a href=\"x&y\">it's here</a>";
        assertEquals(original, Entities.XML.unescape(Entities.XML.escape(original)));
    }

    // ------------------------------------------------------------------
    // Entities.HTML32 / Entities.HTML40
    // ------------------------------------------------------------------

    @Test
    public void htmlFieldsAreInitialised() {
        assertNotNull(Entities.HTML32);
        assertNotNull(Entities.HTML40);
    }

    @Test
    public void theThreeEntitySetsAreDistinctInstances() {
        assertNotSame(Entities.XML, Entities.HTML32);
        assertNotSame(Entities.XML, Entities.HTML40);
        assertNotSame(Entities.HTML32, Entities.HTML40);
    }

    @Test
    public void html40EscapesNonBreakingSpace() {
        assertEquals("&nbsp;", Entities.HTML40.escape(ch(160)));
    }

    @Test
    public void html40UnescapesNonBreakingSpace() {
        assertEquals(ch(160), Entities.HTML40.unescape("&nbsp;"));
    }

    @Test
    public void html40EntityNameAndValueForNbsp() {
        assertEquals(160, Entities.HTML40.entityValue("nbsp"));
        assertEquals("nbsp", Entities.HTML40.entityName(160));
    }

    @Test
    public void html32AndHtml40ShareTheLatin1Entities() {
        assertEquals("&copy;", Entities.HTML32.escape(ch(169)));
        assertEquals("&copy;", Entities.HTML40.escape(ch(169)));
        assertEquals(ch(169), Entities.HTML32.unescape("&copy;"));
        assertEquals(ch(169), Entities.HTML40.unescape("&copy;"));
        assertEquals(169, Entities.HTML32.entityValue("copy"));
        assertEquals(169, Entities.HTML40.entityValue("copy"));
    }

    @Test
    public void html40AlsoEscapesTheBasicMarkupCharacters() {
        assertEquals("&amp;", Entities.HTML40.escape("&"));
        assertEquals("&lt;", Entities.HTML40.escape("<"));
        assertEquals("&gt;", Entities.HTML40.escape(">"));
        assertEquals("&quot;", Entities.HTML40.escape("\""));
    }

    @Test
    public void html40DoesNotDefineTheApostropheEntity() {
        // &apos; is a standard-XML entity, not an HTML 3.2 / 4.0 one.
        assertEquals("'", Entities.HTML40.escape("'"));
        assertEquals("&apos;", Entities.HTML40.unescape("&apos;"));
    }

    @Test
    public void html40KnowsASymbolEntityThatHtml32DoesNot() {
        // "forall" (code point 0x2200) is an HTML 4.0 symbol entity, not an HTML 3.2 one.
        assertEquals(ch(0x2200), Entities.HTML40.unescape("&forall;"));
        assertEquals("&forall;", Entities.HTML32.unescape("&forall;"));
    }

    @Test
    public void html40EscapeUnescapeRoundTripsForLatin1Text() {
        // eacute (233), copy (169) and frac12 (189) are all ISO-8859-1 entities.
        String original = "caf" + ch(233) + " " + ch(169) + " " + ch(189) + " price";
        assertEquals(original, Entities.HTML40.unescape(Entities.HTML40.escape(original)));
    }
}
