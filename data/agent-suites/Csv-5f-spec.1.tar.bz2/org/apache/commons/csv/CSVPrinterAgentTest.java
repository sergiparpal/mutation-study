package org.apache.commons.csv;

import java.io.Writer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link org.apache.commons.csv.CSVPrinter}.
 *
 * <p>Every expectation below is taken from the published javadoc contract in
 * {@code api/org/apache/commons/csv/CSVPrinter.html}:</p>
 * <ul>
 *   <li>the constructor rejects a {@code null} {@code out} or {@code format}
 *       with {@link IllegalArgumentException};</li>
 *   <li>{@link org.apache.commons.csv.CSVPrinter#getOut()} "Gets the target
 *       Appendable" and "Returns: the target Appendable";</li>
 *   <li>{@code print(Object)} "Prints the string as the next value on the line.
 *       The value will be escaped or encapsulated as needed";</li>
 *   <li>{@code println()} "Outputs the record separator";</li>
 *   <li>{@code printComment(String)} - "If comments are disabled in the current
 *       CSV format this method does nothing";</li>
 *   <li>{@code printRecord(...)} "Prints a single line of delimiter separated
 *       values. The values will be quoted if needed";</li>
 *   <li>{@code printRecords(...)} "Prints all the objects in the given
 *       collection / array / JDBC result set";</li>
 *   <li>{@code flush()} "Flushes the underlying stream" and {@code close()}
 *       (specified by {@link java.io.Closeable}).</li>
 * </ul>
 *
 * <p>Only {@link org.apache.commons.csv.CSVFormat#DEFAULT},
 * {@link org.apache.commons.csv.CSVFormat#RFC4180} and the long-standing
 * {@code withDelimiter(char)} builder method are relied on for fixtures; both
 * predefined formats follow RFC&nbsp;4180 (comma delimiter, {@code "} quote,
 * CRLF record separator, comments disabled).</p>
 */
public class CSVPrinterAgentTest extends TestCase {

    /** Record separator used by CSVFormat.DEFAULT / RFC4180. */
    private static final String CRLF = "\r\n";

    // ------------------------------------------------------------------
    // Constructor contract
    // ------------------------------------------------------------------

    public void testConstructorRejectsNullOut() throws Exception {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("javadoc: IllegalArgumentException expected when out is null");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    public void testConstructorRejectsNullFormat() throws Exception {
        try {
            new CSVPrinter(new StringBuilder(), null);
            fail("javadoc: IllegalArgumentException expected when format is null");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    public void testConstructorEmitsNothingBeforeFirstPrint() throws Exception {
        StringBuilder sb = new StringBuilder();
        new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertEquals("no output expected before the first print call", 0, sb.length());
    }

    // ------------------------------------------------------------------
    // getOut()
    // ------------------------------------------------------------------

    public void testGetOutReturnsTheGivenAppendable() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertSame(sb, printer.getOut());
    }

    public void testGetOutReturnsTheGivenWriter() throws Exception {
        RecordingWriter writer = new RecordingWriter();
        CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertSame(writer, printer.getOut());
    }

    public void testGetOutExposesWrittenState() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        assertEquals("a,b" + CRLF, printer.getOut().toString());
    }

    // ------------------------------------------------------------------
    // print(Object)
    // ------------------------------------------------------------------

    public void testPrintSingleValueWrittenVerbatim() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("abc");
        assertEquals("abc", sb.toString());
    }

    public void testPrintInsertsDelimiterBetweenConsecutiveValues() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        printer.print("c");
        assertEquals("a,b,c", sb.toString());
    }

    public void testPrintDoesNotEmitRecordSeparator() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        String out = sb.toString();
        assertEquals("no LF expected from print()", -1, out.indexOf('\n'));
        assertEquals("no CR expected from print()", -1, out.indexOf('\r'));
    }

    public void testPrintEncapsulatesValueContainingDelimiter() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
    }

    public void testPrintEscapesEmbeddedQuoteByDoubling() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("x\"y");
        assertEquals("\"x\"\"y\"", sb.toString());
    }

    public void testPrintEncapsulatesValueContainingNewline() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a\nb");
        assertEquals("\"a\nb\"", sb.toString());
    }

    public void testPrintLeavesPlainValueUnquoted() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("plain");
        assertEquals("plain", sb.toString());
        assertEquals("no quoting expected for a plain value", -1, sb.toString().indexOf('"'));
    }

    public void testPrintWithCustomDelimiter() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withDelimiter(';'));
        printer.print("a");
        printer.print("b");
        assertEquals("a;b", sb.toString());
    }

    public void testPrintQuotesCustomDelimiterAndLeavesCommaAlone() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withDelimiter(';'));
        printer.print("a;b");
        printer.print("c,d");
        assertEquals("\"a;b\";c,d", sb.toString());
    }

    // ------------------------------------------------------------------
    // println()
    // ------------------------------------------------------------------

    public void testPrintlnEmitsRecordSeparator() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        assertEquals(CRLF, sb.toString());
    }

    public void testPrintlnStartsAFreshRecord() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a" + CRLF + "b", sb.toString());
    }

    public void testMultiplePrintlnEmitMultipleSeparators() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        printer.println();
        assertEquals(CRLF + CRLF, sb.toString());
    }

    // ------------------------------------------------------------------
    // printRecord(Object...) / printRecord(Iterable)
    // ------------------------------------------------------------------

    public void testPrintRecordVarargs() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c" + CRLF, sb.toString());
    }

    public void testPrintRecordVarargsQuotesWhereNeeded() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a,b", "c\"d");
        assertEquals("\"a,b\",\"c\"\"d\"" + CRLF, sb.toString());
    }

    public void testPrintRecordVarargsKeepsInteriorEmptyFields() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "", "b");
        assertEquals("a,,b" + CRLF, sb.toString());
    }

    public void testPrintRecordEmptyVarargsEmitsOnlyRecordSeparator() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        assertEquals(CRLF, sb.toString());
    }

    public void testPrintRecordIterable() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("x", "y", "z"));
        assertEquals("x,y,z" + CRLF, sb.toString());
    }

    public void testPrintRecordEmptyIterableEmitsOnlyRecordSeparator() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(new ArrayList<Object>());
        assertEquals(CRLF, sb.toString());
    }

    public void testPrintRecordConsecutiveRecords() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.printRecord("c", "d");
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
    }

    public void testPrintRecordWithRfc4180Format() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.RFC4180);
        printer.printRecord("a", "b");
        assertEquals("a,b" + CRLF, sb.toString());
    }

    // ------------------------------------------------------------------
    // printRecords(Object[]) / printRecords(Iterable)
    // ------------------------------------------------------------------

    public void testPrintRecordsFlatArrayPrintsOneRecordPerElement() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { "a", "b" });
        assertEquals("a" + CRLF + "b" + CRLF, sb.toString());
    }

    public void testPrintRecordsArrayOfArrays() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { new Object[] { "a", "b" }, new Object[] { "c", "d" } });
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
    }

    public void testPrintRecordsArrayOfIterables() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        List<String> row = Arrays.asList("a", "b");
        printer.printRecords(new Object[] { row });
        assertEquals("a,b" + CRLF, sb.toString());
    }

    public void testPrintRecordsEmptyArrayEmitsNothing() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new Object[0]);
        assertEquals("", sb.toString());
    }

    public void testPrintRecordsIterableFlat() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Arrays.asList("a", "b"));
        assertEquals("a" + CRLF + "b" + CRLF, sb.toString());
    }

    public void testPrintRecordsIterableOfIterables() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        List<List<String>> rows = new ArrayList<List<String>>();
        rows.add(Arrays.asList("a", "b"));
        rows.add(Arrays.asList("c"));
        printer.printRecords(rows);
        assertEquals("a,b" + CRLF + "c" + CRLF, sb.toString());
    }

    public void testPrintRecordsEmptyIterableEmitsNothing() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", sb.toString());
    }

    // ------------------------------------------------------------------
    // printRecords(ResultSet)
    // ------------------------------------------------------------------

    public void testPrintRecordsResultSet() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        ResultSet rs = new FakeResultSet(2, new Object[][] {
                { "a", "b" },
                { "c", "d" }
        }).newProxy();
        printer.printRecords(rs);
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
    }

    public void testPrintRecordsResultSetQuotesValues() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        ResultSet rs = new FakeResultSet(2, new Object[][] {
                { "a,b", "c" }
        }).newProxy();
        printer.printRecords(rs);
        assertEquals("\"a,b\",c" + CRLF, sb.toString());
    }

    public void testPrintRecordsEmptyResultSetEmitsNothing() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        ResultSet rs = new FakeResultSet(3, new Object[0][]).newProxy();
        printer.printRecords(rs);
        assertEquals("", sb.toString());
    }

    // ------------------------------------------------------------------
    // flush()
    // ------------------------------------------------------------------

    public void testFlushDelegatesToUnderlyingStream() throws Exception {
        RecordingWriter writer = new RecordingWriter();
        CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.flush();
        assertTrue("flush() should flush the underlying stream", writer.flushCount >= 1);
    }

    public void testFlushOnNonFlushableTargetKeepsOutputIntact() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.flush();
        assertEquals("a,b" + CRLF, sb.toString());
    }

    // ------------------------------------------------------------------
    // close()
    // ------------------------------------------------------------------

    public void testCloseDelegatesToUnderlyingStream() throws Exception {
        RecordingWriter writer = new RecordingWriter();
        CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close();
        assertTrue("close() should close the underlying stream", writer.closeCount >= 1);
    }

    public void testCloseOnNonCloseableTargetIsHarmless() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("x");
        printer.close();
        printer.close();
        assertEquals("x" + CRLF, sb.toString());
    }

    // ------------------------------------------------------------------
    // printComment(String) -- comments are disabled in CSVFormat.DEFAULT
    // ------------------------------------------------------------------

    public void testPrintCommentIsNoOpWhenCommentsDisabled() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("nothing to see here");
        assertEquals("", sb.toString());
    }

    public void testPrintCommentDoesNotDisturbSurroundingRecords() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.printComment("ignored");
        printer.printRecord("c", "d");
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
    }

    public void testPrintCommentNoOpAcceptsEmptyString() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("");
        assertEquals("", sb.toString());
    }

    // ==================================================================
    // Self-contained fixtures
    // ==================================================================

    /**
     * A {@link Writer} that captures everything written to it and counts the
     * number of {@code flush()} / {@code close()} invocations, so delegation
     * from {@link org.apache.commons.csv.CSVPrinter} can be observed.
     */
    private static final class RecordingWriter extends Writer {

        private final StringBuilder buffer = new StringBuilder();
        int flushCount = 0;
        int closeCount = 0;

        public void write(char[] cbuf, int off, int len) {
            buffer.append(cbuf, off, len);
        }

        public void flush() {
            flushCount++;
        }

        public void close() {
            closeCount++;
        }

        String written() {
            return buffer.toString();
        }
    }

    /**
     * Minimal {@link java.sql.ResultSet} stand-in implemented with a dynamic
     * proxy so this test file stays completely self-contained. Only the methods
     * exercised while printing a result set are handled
     * ({@code getMetaData}/{@code getColumnCount}, {@code next},
     * {@code getObject}/{@code getString}, {@code wasNull}); every other call
     * returns a type-appropriate default.
     */
    private static final class FakeResultSet implements InvocationHandler {

        private final int columnCount;
        private final Object[][] rows;
        private int cursor = -1;

        FakeResultSet(int columnCount, Object[][] rows) {
            this.columnCount = columnCount;
            this.rows = rows;
        }

        ResultSet newProxy() {
            return (ResultSet) Proxy.newProxyInstance(
                    getClass().getClassLoader(),
                    new Class[] { ResultSet.class },
                    this);
        }

        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String name = method.getName();

            if (method.getDeclaringClass() == Object.class) {
                if ("toString".equals(name)) {
                    return "FakeResultSet";
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(System.identityHashCode(proxy));
                }
                if ("equals".equals(name)) {
                    return Boolean.valueOf(proxy == (args == null ? null : args[0]));
                }
            }

            if ("getMetaData".equals(name)) {
                return Proxy.newProxyInstance(
                        getClass().getClassLoader(),
                        new Class[] { ResultSetMetaData.class },
                        this);
            }
            if ("getColumnCount".equals(name)) {
                return Integer.valueOf(columnCount);
            }
            if ("next".equals(name)) {
                cursor++;
                return Boolean.valueOf(cursor < rows.length);
            }
            if ("getObject".equals(name) || "getString".equals(name)) {
                int index = ((Number) args[0]).intValue() - 1;
                Object value = rows[cursor][index];
                if ("getString".equals(name) && value != null) {
                    return value.toString();
                }
                return value;
            }
            if ("wasNull".equals(name) || "isClosed".equals(name) || "isAfterLast".equals(name)) {
                return Boolean.FALSE;
            }

            Class<?> returnType = method.getReturnType();
            if (returnType == Boolean.TYPE) {
                return Boolean.FALSE;
            }
            if (returnType == Integer.TYPE) {
                return Integer.valueOf(0);
            }
            if (returnType == Long.TYPE) {
                return Long.valueOf(0L);
            }
            if (returnType == Short.TYPE) {
                return Short.valueOf((short) 0);
            }
            if (returnType == Byte.TYPE) {
                return Byte.valueOf((byte) 0);
            }
            if (returnType == Double.TYPE) {
                return Double.valueOf(0.0d);
            }
            if (returnType == Float.TYPE) {
                return Float.valueOf(0.0f);
            }
            if (returnType == Character.TYPE) {
                return Character.valueOf((char) 0);
            }
            return null;
        }
    }
}
